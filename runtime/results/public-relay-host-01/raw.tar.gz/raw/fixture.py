import json,subprocess,sys,time,traceback
from pathlib import Path
r=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(r),str(r/'research/live_control'),str(r/'research/observation_gating')]
from run_native_six_task_self_use_v1 import PrivateSession
out=r/'results-local/public-relay-host-primary-01';out.mkdir(exist_ok=False)
def save(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n')
class LoggedSession(PrivateSession):
 def _popen(self,args,**kwargs):
  name=f'{len(getattr(self,"procs",[]))}-{Path(args[0]).name}'
  with (out/(name+'.stdout.log')).open('w') as stdout,(out/(name+'.stderr.log')).open('w') as stderr:
   kwargs.update(stdout=stdout,stderr=stderr)
   process=super()._popen(args,**kwargs)
  save(name+'.launch.json',{'pid':process.pid,'args':args,'display':getattr(self,'name',None)})
  return process
 def close(self):
  super().close();save('setup-cleanup.json',[{'pid':p.pid,'returncode':p.poll()} for p in getattr(self,'procs',[])])
s=None
try:
 s=LoggedSession()
 save('setup-readiness.json',s.window_manager_readiness)
 subprocess.run(['setxkbmap','-layout','jp'],env=s.env,check=True)
 targets={}
 original=(r/'runtime/backends/x11_v1/fixture_app.py').read_text()
 for name,title,x in [('left','Left editor',80),('right','Right editor',520)]:
  source=original.replace('AgentInterfaceX11Fixture',title).replace('400x180+80+90',f'400x180+{x}+90')
  (out/f'{name}-fixture.py').write_text(source)
  s._popen(['/usr/bin/python3',str(out/f'{name}-fixture.py'),'--meta',str(out/f'{name}-meta.json'),'--effect',str(out/f'{name}-effect.json'),'--events',str(out/f'{name}-events.jsonl')],cwd=r)
  deadline=time.monotonic()+10
  while not (out/f'{name}-meta.json').exists():
   if time.monotonic()>deadline:raise TimeoutError('fixture ready')
   time.sleep(.05)
  targets[name]=json.loads((out/f'{name}-meta.json').read_text())['window_id']
 save('targets.json',targets)
 save('allocation.json',{'display':s.name,'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'screen':[s.d.screen().width_in_pixels,s.d.screen().height_in_pixels],'task':'Save http://c_d in Left only. Use packaged public relay from outside the checkout. Focus and observe before text; inspect Left after input and save. Right receives no input.','expected':{'left':'http://c_d','right':None}})
 print(json.dumps({'ready':True,'display':s.name,'screen':[s.d.screen().width_in_pixels,s.d.screen().height_in_pixels]}),flush=True)
 deadline=time.monotonic()+900
 while not (out/'finish.json').exists():
  if time.monotonic()>deadline:raise TimeoutError('primary allocation expired')
  time.sleep(.05)
 actual={name:json.loads((out/f'{name}-effect.json').read_text()) if (out/f'{name}-effect.json').exists() else None for name in targets}
 expected={'left':{'saved':True,'text':'http://c_d'},'right':None}
 save('evaluation.json',{'actual':actual,'success':actual==expected,'scope':'independent saved-file check after primary control ended'})
except BaseException as e:
 save('failure.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
finally:
 if s is not None:
  s.close();save('cleanup.json',[{'pid':p.pid,'returncode':p.poll()} for p in s.procs])

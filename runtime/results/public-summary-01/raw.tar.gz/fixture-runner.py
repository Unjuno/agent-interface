import sys,json,time,subprocess,traceback
from pathlib import Path
r=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(r),str(r/'research/live_control'),str(r/'research/observation_gating')]
from run_native_six_task_self_use_v1 import PrivateSession
out=r/'results-local/public-summary-primary-01';out.mkdir(exist_ok=False)
save=lambda n,v:(out/n).write_text(json.dumps(v,indent=2)+'\n')
s=None
try:
 s=PrivateSession()
 subprocess.run(['setxkbmap','-layout','jp'],env=s.env,check=True)
 s._popen(['/usr/bin/python3','-m','runtime.backends.x11_v1.fixture_app','--meta',str(out/'meta.json'),'--effect',str(out/'effect.json'),'--events',str(out/'app-events.jsonl')],cwd=r)
 deadline=time.monotonic()+10
 while not (out/'meta.json').exists():
  if time.monotonic()>deadline:raise TimeoutError('fixture ready')
  time.sleep(.05)
 meta=json.loads((out/'meta.json').read_text())
 save('targets.json',{'app':meta['window_id']})
 save('allocation.json',{'display':s.name,'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'task':'Primary enters http://v_w on JP, reviews unsaved value, then saves using summary mode. Full retrieval must not input; a refused verify stays full. Independent final oracle after close.'})
 print(json.dumps({'ready':True,'display':s.name}),flush=True)
 deadline=time.monotonic()+900;changed=False
 while not (out/'finish.json').exists():
  if time.monotonic()>deadline:raise TimeoutError('allocation expired')
  if (out/'switch-us.json').exists() and not changed:
   subprocess.run(['setxkbmap','-layout','us'],env=s.env,check=True);changed=True
   save('switched.json',{'layout':'us','monotonic_ns':time.monotonic_ns()})
  time.sleep(.05)
 actual=json.loads((out/'effect.json').read_text()) if (out/'effect.json').exists() else None
 save('evaluation.json',{'success':actual=={'saved':True,'text':'http://v_w'},'actual':actual,'scope':'independent final saved-file check after control ended'})
except BaseException as e:
 save('failure.json',{'error':str(e),'traceback':traceback.format_exc()});raise
finally:
 if s is not None:
  s.close();save('cleanup.json',[{'pid':p.pid,'returncode':p.poll()} for p in s.procs])

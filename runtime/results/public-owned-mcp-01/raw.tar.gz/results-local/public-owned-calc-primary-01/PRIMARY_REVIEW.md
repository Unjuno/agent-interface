# Primary public MCP Calc trial — HOLD

Source: 2fce524d5a8cd7f3f1f8a0bd06108fb5db465f8f
Session: 167fef12d88e4d74a4b883daf0225d0f
Goal: A1=666, A2=820, saved XLSX.

The primary agent viewed initial and action-1/2/4 images. The first input dispatch completed and reported verified input release. The action-1 image showed a partially drawn format confirmation dialog. A fresh explicit observation (action-2) showed the Excel-format button at screen (784,463).

Action-3 attempted to focus the configured main Calc target before clicking the visible format confirmation button. It failed at operation 0 with focus verification failed. Its report marks the failed operation effect unknown, possibly partial input; it does not prove zero input. No click or successful save is claimed.

Action-4 explicitly recaptured the screen and showed the same modal. Action-5 was a new decision omitting main-window focus, not a replay. It was refused: pointer_move requires focused target. The current public contract and immutable main-window target mapping do not suffice for this modal transition. No constraints were disabled or production source changed during the trial.

Action-6 explicitly closed the same session: release verified, keys_down=[], buttons_down=[], connection_close_attempted=true. The client/fixture runner subsequently exited 0, and fixture-cleanup.json records that fixture close returned. This is not proof that every descendant process was independently checked.

Independent saved-file evaluation found [null,null], success=false. Treat this as a failed end-to-end save trial, not successful integration or a latency improvement. All requests, responses, call artifacts, images and the saved workbook remain in this directory. Next integration work must define and test explicit modal target admission/focus behavior before another primary-operated save trial. Caller-provided source/lease assertions remain construction-only and are not server-issued visual freshness authority.
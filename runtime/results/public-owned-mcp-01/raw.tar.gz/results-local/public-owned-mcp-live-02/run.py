import sys,asyncio,json,base64,subprocess
from pathlib import Path
sys.path.insert(0, '/tmp/agent-interface-mcp-venv/lib/python3.12/site-packages')
sys.path[:0]=['research/live_control','research/observation_gating']
from run_native_six_task_self_use_v1 import PrivateSession
from Xlib import X
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
root=Path(__file__).resolve().parent
repo=root.parents[1]
(root/'source.json').write_text(json.dumps({'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'private read-only X11 through actual public stdio MCP; no task input'})+'\n')
async def main():
 session=PrivateSession()
 try:
  d=session.d;s=d.screen();win=s.root.create_window(50,50,300,200,0,s.root_depth,X.InputOutput,X.CopyFromParent,background_pixel=s.white_pixel,override_redirect=True)
  win.map();d.sync()
  (root/'targets.json').write_text(json.dumps({'fixture':win.id}))
  params=StdioServerParameters(command='/tmp/agent-interface-mcp-venv/bin/python',args=['-m','runtime.cli_v1.mcp_server','--targets',str(root/'targets.json'),'--output-directory',str(root/'calls'),'--display',session.name,'--session-mode','persistent-x11'],cwd=str(repo))
  with (root/'server.stderr').open('w') as log:
   async with stdio_client(params,errlog=log) as (reader,writer):
    async with ClientSession(reader,writer) as client:
     await client.initialize();(root/'tools.json').write_text(json.dumps((await client.list_tools()).model_dump(mode='json'),indent=2))
     async def call(label,name,args):
      (root/(label+'-request.json')).write_text(json.dumps({'tool':name,'arguments':args}))
      reply=await client.call_tool(name,args)
      (root/(label+'-response.json')).write_text(json.dumps(reply.model_dump(mode='json'),indent=2))
      row=json.loads(reply.content[0].text)
      for block in reply.content:
       if block.type=='image': (root/(label+'.png')).write_bytes(base64.b64decode(block.data))
      return row
     args={'target':'fixture','frame':'window_client','region':[0,0,300,200]}
     a=await call('observe1','interface_observe',args)
     b=await call('observe2','interface_observe',args)
     assert a['session']['session_id']==b['session']['session_id']
     for r in (a,b):
      report=json.loads(Path(r['call_directory'],'report.json').read_text())
      assert report['status']=='returned' and report['input_dispatched'] is False
     c=await call('close','interface_close',{})
     assert c['status']=='closed' and c['release_attempted'] is False
     refused=await call('after-close','interface_observe',args)
     assert refused['status']=='session_closed' and refused['operation_invoked'] is False
     retained=await call('retained','interface_results',{'call_id':a['call_id']})
     assert retained['operation_invoked'] is False
     (root/'result.json').write_text(json.dumps({'status':'PASS','session_id':a['session']['session_id'],'observations':2,'input_dispatches':0,'close':c,'after_close':refused},indent=2)+'\n')
  print('PASS actual public stdio: same session, two observations, close, refused new capture, retained read')
 finally:
  session.close();(root/'fixture-cleanup.json').write_text(json.dumps({'session_close_returned':True})+'\n')
asyncio.run(main())

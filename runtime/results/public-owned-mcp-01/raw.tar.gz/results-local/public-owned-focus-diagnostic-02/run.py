import sys,json,time,subprocess
from pathlib import Path
sys.path[:0]=['research/live_control','research/observation_gating']
from run_native_six_task_self_use_v1 import PrivateSession
import gui_suite as suite
from runtime.backends.x11_v1.backend import X11Backend
from Xlib import X
root=Path(__file__).resolve().parent
s=PrivateSession(); backend=None
rows=[]
def inspect(label):
 f=backend.d.get_input_focus().focus; chain=[]
 for _ in range(32):
  if not getattr(f,'id',None):break
  chain.append({'id':f.id,'name':f.get_wm_name(),'class':f.get_wm_class()})
  if f.id==backend.root.id:break
  f=f.query_tree().parent
 rows.append({'label':label,'chain':chain,'windows':s.windows()})
try:
 goal,output,_=suite.prepare(s,'calc',991303,'')
 target=int(next(line.split()[0] for line in s.windows().splitlines() if output.name in line),16)
 backend=X11Backend(s.name,{'app':target})
 inspect('initial')
 backend.focus('app');backend.text(str(goal['a']));backend.key_chord(['Return']);backend.text(str(goal['b']));backend.key_chord(['Return']);backend.key_chord(['CTRL','s']);backend.release_all()
 time.sleep(.5);inspect('format_modal')
 try:backend.focus('app');rows.append({'label':'focus_result','success':True})
 except Exception as e:rows.append({'label':'focus_result','error':repr(e)})
 inspect('after_focus_attempt')
 (root/'result.json').write_text(json.dumps({'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'target':target,'rows':rows},indent=2,default=repr))
 print(json.dumps(rows,indent=2,default=repr))
finally:
 if backend is not None:backend.release_all();backend.close()
 s.close()
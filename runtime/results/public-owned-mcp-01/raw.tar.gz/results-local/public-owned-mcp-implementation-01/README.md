# Public MCP owned-session implementation checks

Implementation source62c63931a (full commit available in live-02/source.json). Default one-shot remains available; persistent-x11 is opt-in and not yet promoted by a primary input task.

Development failures retained: initial portable MCP could not import the unpackaged mcp_session module; adding it to the build closure fixed that. Distribution tests initially referenced pre-commit source; after committing they exposed an actual optional-dependency diagnostic regression (AnyIO imported before MCP). Moving the AnyIO import after MCP fixed that. Focused-01 retains the latter failure; earlier command output is only in the conversation. Focused-02:31 tests PASS. Shared native checks PASS (protocol includes the five new owner tests).

Live-01 failed importing SDK dependencies before fixture allocation because system typing_extensions shadowed the venv version. Live-02 explicitly prioritized that venv's dependencies; real stdio MCP observed a private X11 window twice with the same session ID, closed without releasing input, refused observation after close, and reread retained results without invocation. No task/input or performance result is claimed. Live-02 fixture cleanup returned; full descendants were not audited.

Remaining: primary-operated input/save on this public path, actual shutdown after input, exact-head broader checks and review before remote integration. Do not infer native research visual guards or server-issued leases from connection reuse.

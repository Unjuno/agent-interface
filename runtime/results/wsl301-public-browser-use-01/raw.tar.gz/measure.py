import json,hashlib,platform,subprocess
from pathlib import Path
p=Path(__file__).resolve().parent;d=p/'direct';h=d/'host'
load=lambda n:json.loads(n.read_text())
events=[json.loads(x) for x in (h/'host-events.jsonl').read_text().splitlines()]
rows=[]
for i in range(1,6):
 r=load(h/f'reply-{i}.json'); a=load(h/f'request-{i}.json')
 ev={e['kind']:e for e in events if e.get('attempt')==i}
 m=json.loads(next(x['text'] for x in r['result']['content'] if x['type']=='text'))
 row={'attempt':i,'tool':a['tool'],'call_id':m.get('call_id'),'images':sum(x['type']=='image' for x in r['result']['content']),'host_send_to_image_callback_ms':ev['presentation_callbacks_completed']['host_monotonic_ms']-ev['send_requested']['host_monotonic_ms'],'reply_to_callbacks_ms':ev['presentation_callbacks_completed']['host_monotonic_ms']-ev['reply_available']['host_monotonic_ms']}
 if 'review_recorded' in ev:row['callback_to_primary_review_annotation_ms']=ev['review_recorded']['host_monotonic_ms']-ev['presentation_callbacks_completed']['host_monotonic_ms']
 if row['tool']=='interface_dispatch':
  raw=load(d/'server'/row['call_id']/'report.json');ex=raw['result']['execution']
  row['execution_ms']=(ex['ended_ns']-ex['started_ns'])/1e6
  row['fixed_wait_ms']=sum(w['requested_ms'] for w in ex['waits'])
  row['program_emissions']=ex['program_emissions']
  row['release_verified']=all(x['verified'] and not x['keys_down'] and not x['buttons_down'] for x in ex['releases'])
 rows.append(row)
submissions=[json.loads(x) for x in (d/'submission-history.jsonl').read_text().splitlines()]
exact=(len(submissions)==1 and submissions[0]['task_id']=='task-1' and submissions[0]['exact'] is True and submissions[0]['submitted_values']==['t1001026-1'])
checks={'one_exact_task1_save':exact,'four_images':sum(r['images'] for r in rows)==4,'all_three_dispatches_released':sum(r.get('release_verified') is True for r in rows)==3,'transport_exit_zero':load(h/'exit.json')['code']==0,'fixture_children_terminal':all(type(x['returncode']) is int for x in load(d/'cleanup.json'))}
metrics={'status':'PASS_ONE_PRIMARY_BROWSER_TASK_SCOPED' if all(checks.values()) else 'HOLD_ACCOUNTING','checks':checks,'rows':rows,'task_index':0,'input_replay':0,'extra_observation':0,'fixture_six_task_oracle':load(d/'evaluation-at-close.json'),'cleanup':load(d/'cleanup.json'),'environment':{'kernel':platform.release(),'python':platform.python_version()},'limits':'One task requested out of six fixture tasks. No all-six success, matched speedup, isolated inference/perception latency, token or human-tempo claim. Host callbacks are delivery endpoints; review annotations include primary/tools work. Data accounting is not independent visual re-review.'}
(p/'metrics.json').write_text(json.dumps(metrics,indent=2)+'\n');print(json.dumps(metrics,indent=2))
raise SystemExit(0 if all(checks.values()) else 1)

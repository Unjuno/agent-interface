import {spawnSync} from 'node:child_process';
export function createDirectCaller(host, goal, archive, show) {
 let sequence=1;
 const click=(x,y)=>[{op:'pointer_move',frame:'screen_physical_px',x,y},{op:'pointer_button',button:'left',down:true},{op:'pointer_button',button:'left',down:false}];
 const make=(ops,expires)=>({schema:'agent-interface/program-v1',program_id:'wsl301-use-'+Date.now(),source:{observation_seq:sequence,binding_revision:1},authority:{lease_id:'wsl301-use-01',expires_at_ns:expires},terminal:{release_all_required:true},ops:[{op:'focus',target:'browser'},...ops,{op:'observe',target:'browser',frame:'screen_physical_px',region:[0,0,1280,800]},{op:'release_all'}]});
 const patterns={navigate:i=>[{op:'key_chord',keys:['CTRL','l']},{op:'wait_update',timeout_ms:100},{op:'text',text:goal.tasks[i].url},{op:'wait_update',timeout_ms:100},{op:'key_chord',keys:['ENTER']},{op:'wait_update',timeout_ms:200}],enter:(i,x,y)=>[...click(x,y),{op:'key_chord',keys:['CTRL','a']},{op:'wait_update',timeout_ms:100},{op:'text',text:goal.tasks[i].token},{op:'wait_update',timeout_ms:100}],save:(x,y)=>[...click(x,y),{op:'wait_update',timeout_ms:100}]};
 const dispatch=async ops=>{
  const clock=spawnSync('wsl.exe',['-d','Ubuntu','--exec','python3','-c','import time;print(time.monotonic_ns())'],{encoding:'utf8',windowsHide:true});if(clock.status!==0)throw Error(clock.stderr);
  const program=make(ops,Number(clock.stdout.trim())+5000000000);
  const reply=await host.send('interface_dispatch',{program,current_observation_seq:sequence,current_binding_revision:1});
  const m=JSON.parse(reply.result.content[0].text);if(m.receipt?.source?.raw_report?.result?.status!=='completed')throw Error('STOP: '+JSON.stringify(m));sequence++;await show(reply);return reply;
 };
 return {preflightPrograms:()=>[make(patterns.navigate(0),999999999999999),make(patterns.enter(0,300,401),999999999999999),make(patterns.save(375,401),999999999999999)],navigate:i=>dispatch(patterns.navigate(i)),enter:(i,x,y)=>dispatch(patterns.enter(i,x,y)),save:(x,y)=>dispatch(patterns.save(x,y))};
}


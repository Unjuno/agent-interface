import json,subprocess,sys,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent;attempt=root/'attempts/action-3'
archive=root.parent/'cli-retention-portable-01/runtime.pyz'
files={str(p.relative_to(attempt)):hashlib.sha256(p.read_bytes()).hexdigest() for p in attempt.rglob('*') if p.is_file()}
cmd=[sys.executable,str(archive),'review','--report',str(attempt/'report.json'),'--run-directory',str(attempt),'--compact']
p=subprocess.run(cmd,cwd='/tmp',capture_output=True,check=True);(root/'recovered-stdout.json').write_bytes(p.stdout)
x=json.loads(p.stdout);old=json.loads((root/'action-3-stdout.json').read_bytes())
assert x['outcome_summary']==old['outcome_summary'];assert x['image']==old['image']
assert files=={str(p.relative_to(attempt)):hashlib.sha256(p.read_bytes()).hexdigest() for p in attempt.rglob('*') if p.is_file()}
result={'same_outcome':True,'same_image':True,'attempt_bytes_unchanged':True,'new_dispatches':0,'new_observations':0,'freshness':x['image_reference']['freshness']}
(root/'recovery-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))

import json,sys,traceback
from pathlib import Path
r=Path.cwd();sys.path[:0]=[str(r),str(r/'research/live_control'),str(r/'research/observation_gating')]
from run_native_six_task_self_use_v1 import PrivateSession
out=r/'results-local/portable-relay-setup-diagnostic-01';out.mkdir(exist_ok=False)
class LoggedSession(PrivateSession):
 def _popen(self,args,**kwargs):
  name=f'{len(getattr(self,"procs",[]))}-{Path(args[0]).name}'
  with (out/(name+'.stdout.log')).open('w') as stdout,(out/(name+'.stderr.log')).open('w') as stderr:
   kwargs.update(stdout=stdout,stderr=stderr)
   process=super()._popen(args,**kwargs)
  (out/(name+'.launch.json')).write_text(json.dumps({'pid':process.pid,'args':args,'display':getattr(self,'name',None)},indent=2))
  return process
 def close(self):
  super().close();(out/'cleanup.json').write_text(json.dumps([{'pid':p.pid,'returncode':p.poll()} for p in getattr(self,'procs',[])],indent=2))
s=None
try:
 s=LoggedSession();(out/'result.json').write_text(json.dumps({'status':'ready','display':s.name,'readiness':s.window_manager_readiness},indent=2))
except Exception as e:
 (out/'result.json').write_text(json.dumps({'status':'setup_failed','error':repr(e),'traceback':traceback.format_exc()},indent=2))
finally:
 if s:s.close()
for p in sorted(out.glob('*')):print(p.name,p.read_text()[:1600])

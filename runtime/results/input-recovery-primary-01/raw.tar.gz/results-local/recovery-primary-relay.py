import sys,asyncio,json,os
from pathlib import Path
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
r=Path(__file__).resolve().parents[1];sys.path.insert(0,str(r/'research/live_control'))
from native_mcp_relay_v1 import Relay,PUBLIC_TOOLS
out=r/'results-local/recovery-primary-01';allocation=json.loads((out/'allocation.json').read_text())
async def main():
 params=StdioServerParameters(command=sys.executable,args=[str(r/'results-local/x11-explicit-recovery-mcp-host.py'),str(r/'results-local/explicit-input-recovery-build-01/runtime.pyz'),'--targets',str(out/'targets.json'),'--output-directory',str(out/'server'),'--display',allocation['display'],'--session-mode','persistent-x11'],env=dict(os.environ))
 async with stdio_client(params) as (reader,writer):
  async with ClientSession(reader,writer) as client:
   await client.initialize();relay=Relay(client,tools=PUBLIC_TOOLS)
   while True:
    line=await asyncio.to_thread(sys.stdin.readline)
    if not line:break
    print(json.dumps(await relay.request(line)),flush=True)
asyncio.run(main())

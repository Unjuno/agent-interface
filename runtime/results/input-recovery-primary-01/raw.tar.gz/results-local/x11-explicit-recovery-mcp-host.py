import sys,runpy
from unittest import mock
archive=sys.argv.pop(1);sys.path.insert(0,archive)
from runtime.backends.x11_v1.backend import X11Backend
original=X11Backend.key_state
injected=False
def key_state(self,key,down):
 global injected
 if down and not injected:
  injected=True
  sync=self.d.sync
  def lost_reply():
   sync();raise OSError('construction: lost acknowledgement after processed key press')
  with mock.patch.object(self.d,'sync',side_effect=lost_reply):return original(self,key,down)
 return original(self,key,down)
X11Backend.key_state=key_state
from Xlib import X
from Xlib.ext import xtest
original_release=X11Backend.release_all
cleanup_fault_pending=True
def release_all(self):
 global cleanup_fault_pending
 if cleanup_fault_pending:
  cleanup_fault_pending=False
  emit=xtest.fake_input
  def omit_release(display,event,*args,**kwargs):
   if event in (X.KeyRelease,X.ButtonRelease):return None
   return emit(display,event,*args,**kwargs)
  with mock.patch.object(xtest,'fake_input',side_effect=omit_release):return original_release(self)
 return original_release(self)
X11Backend.release_all=release_all
runpy.run_module('runtime.cli_v1.mcp_server',run_name='__main__')
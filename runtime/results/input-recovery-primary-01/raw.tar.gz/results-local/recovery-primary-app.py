import tkinter as tk
import json,sys,time
from pathlib import Path
out=Path(sys.argv[1]);root=tk.Tk();root.title('Input Recovery Check');root.geometry('560x260')
count=0;events=[]
label=tk.Label(root,font=('Sans',20),text='Count: 0');label.pack(pady=25)
tk.Label(root,text='Goal: save Count 2.\nW adds one. S saves.\nReview the count after recovery before choosing input.',font=('Sans',13)).pack()
status=tk.Label(root,text='Not saved',font=('Sans',16));status.pack(pady=15)
def key(event):
 global count
 if event.keysym.lower()=='w':
  count+=1;label.config(text=f'Count: {count}')
 elif event.keysym.lower()=='s':
  (out/'saved.json').write_text(json.dumps({'count':count,'saved_at_ns':time.monotonic_ns()})+'\n');status.config(text=f'Saved Count {count}')
 events.append({'key':event.keysym,'count':count,'time_ns':time.monotonic_ns()})
 (out/'events.json').write_text(json.dumps(events,indent=2)+'\n')
root.bind('<KeyPress>',key);root.mainloop()

import sys,json,time,subprocess
from pathlib import Path
r=Path(__file__).resolve().parents[1];sys.path[:0]=[str(r),str(r/'research/live_control')]
from run_native_six_task_self_use_v1 import PrivateSession
out=r/'results-local/recovery-primary-01';out.mkdir(exist_ok=False)
def save(n,v):(out/n).write_text(json.dumps(v,indent=2)+'\n')
s=PrivateSession()
try:
 subprocess.run(['xset','-display',s.name,'r','off'],check=True)
 app=s.spawn(['/usr/bin/python3',str(r/'results-local/recovery-primary-app.py'),str(out)])
 s.wait_window('Input Recovery Check',10);s.focus('Input Recovery Check')
 line=next(x for x in s.windows().splitlines() if 'Input Recovery Check' in x)
 targets={'counter':int(line.split()[0],16)};save('targets.json',targets)
 save('allocation.json',{'display':s.name,'targets':targets,'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'autorrepeat':'disabled on private X server','scope':'primary operated construction; known app and injected fault, not benchmark or latency comparison'})
 print(json.dumps({'ready':True,'display':s.name}),flush=True)
 deadline=time.monotonic()+600
 while app.poll() is None and not (out/'finish.json').exists():
  if time.monotonic()>deadline:raise TimeoutError('600s allocation expired')
  time.sleep(.1)
finally:
 s.close();save('cleanup.json',[{'pid':p.pid,'returncode':p.poll()} for p in s.procs])

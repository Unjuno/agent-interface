import hashlib,json,tarfile,subprocess
from pathlib import Path
r=Path(__file__).resolve().parents[1];out=r/'runtime/results/input-recovery-primary-01';out.mkdir(exist_ok=False)
paths=list((r/'results-local/recovery-primary-01').rglob('*'))
paths += [r/'results-local'/n for n in ('recovery-primary-app.py','recovery-primary-fixture.py','recovery-primary-relay.py','x11-explicit-recovery-mcp-host.py','bundle-recovery-primary.py')]
paths += list((r/'results-local/explicit-input-recovery-build-01').iterdir())
paths += [r/'research/live_control'/n for n in ('native_mcp_relay_v1.py','native_relay_client_v1.mjs','relay_host_timeline_v1.mjs')]
manifest={}
with tarfile.open(out/'raw.tar.gz','w:gz') as archive:
 for p in sorted(paths):
  if not p.is_file():continue
  data=p.read_bytes();name=p.relative_to(r).as_posix()
  manifest[name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)};archive.add(p,arcname=name)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(manifest),'archive_bytes':(out/'raw.tar.gz').stat().st_size}))

import base64,copy,hashlib,json,re
from pathlib import Path
p=Path(__file__).resolve().parent
def load(x):return json.loads(x.read_text())
def need(v,m):
 if not v:raise ValueError(m)
def meta(r):return json.loads(next(c['text'] for c in r['result']['content'] if c['type']=='text'))
out={};programs=[]
for arm in ['inline','post']:
 h=p/arm/'host';s=p/arm/'session';hist=[json.loads(x) for x in (s/'submission-history.jsonl').read_text().splitlines()]
 need(len(hist)==1 and hist[0]['exact'] and hist[0]['submitted_values']==['t1001036-4'],'exact once')
 ev=load(s/'evaluation-at-close.json');need(ev['success'] is False,'all six not requested')
 events=[json.loads(x) for x in (h/'host-events.jsonl').read_text().splitlines()]
 calls=[];ops=[]
 for i in range(1,13):
  q=load(h/f'request-{i}.json');r=load(h/f'reply-{i}.json');v=meta(r)
  need(r['status']=='returned' and not r['result']['isError'],'normal reply')
  ts={e['kind']:e['host_monotonic_ms'] for e in events if e.get('attempt')==i}
  c={'attempt':i,'tool':q['tool'],'text_bytes':sum(len(x['text'].encode()) for x in r['result']['content'] if x['type']=='text'),'host_send_to_reply_ms':ts['reply_available']-ts['send_requested']}
  if i in [4,6,8]:
   report=load(Path(v['call_directory'])/'report.json');ex=report['result']['execution']
   need(report['result']['status']=='completed' and all(x['verified'] and x['keys_down']==[] and x['buttons_down']==[] for x in ex['releases']),'release')
   if arm=='post':
    context=report['post_dispatch_inspection'];ob=context['observation_report']['observation']
    need(ex['observations']==[] and context['observation_report']['input_dispatched'] is False and context['authority_granted'] is False,'read-only')
    need(v['image_reference']['post_dispatch_observation_id']==context['observation_report']['observation_id'] and v['image_reference']['capture_phase']=='after_dispatch_release','selected phase')
    need(ob['capture_started_ns']>=ex['ended_ns']>=ex['releases'][-1]['monotonic_ns'],'post order')
   else:
    ob=ex['observations'][-1];need(ob['capture_started_ns']<ex['releases'][-1]['monotonic_ns'],'inline order')
   png=base64.b64decode(next(x['data'] for x in r['result']['content'] if x['type']=='image'))
   need(hashlib.sha256(png).hexdigest()==ob['artifact']['sha256']==v['image_reference']['sha256'],'exact png')
   need(load(h/f'review-{i}.json')['images'][0]['sha256']==v['image_reference']['sha256'],'primary review')
   c.update(capture_start_after_release_ms=(ob['capture_started_ns']-ex['releases'][-1]['monotonic_ns'])/1e6,requested_wait_ms=sum(x['requested_ms'] for x in ex['waits']),post_inspection_ms=(context['ended_ns']-context['started_ns'])/1e6 if arm=='post' else None,image_bytes=len(png),image_sha256=hashlib.sha256(png).hexdigest(),call_id=v['call_id'])
   args=copy.deepcopy(q['arguments']);region=args.pop('inspect_after_region',None);args.pop('inspect_after',None);args['program'].pop('program_id');args['program']['authority'].pop('expires_at_ns')
   if arm=='inline':region=next(x['region'] for x in args['program']['ops'] if x['op']=='observe')
   args['program']['ops']=[x for x in args['program']['ops'] if x['op']!='observe']
   for op in args['program']['ops']:
    if op.get('op')=='text':op['text']=re.sub(r'127\.0\.0\.1:\d+','127.0.0.1:PORT',op['text'])
   ops.append({'arguments':args,'region':region})
  if i==9:
   save=meta(load(h/'reply-8.json'))
   need(v['operation_invoked'] is False and v['image_reference']==save['image_reference'] and all(x['type']!='image' for x in r['result']['content']),'lookup no recapture/delivery')
  if i==11:
   raw=v['receipt']['source']['raw_report'];need(raw['result']['error']=='LEASE_EXPIRED' and raw['result']['backend_emissions']==98,'expired no input')
   if arm=='post':need(raw['post_dispatch_inspection']['status']=='skipped' and 'observation_report' not in raw['post_dispatch_inspection'],'skip post')
  if i==12:need(v['status']=='closed' and v['release']['verified'],'close')
  calls.append(c)
 programs.append(ops);need(load(h/'exit.json')['code']==0,'transport')
 out[arm]={'calls':calls,'exact_task4_once':True,'six_task_aggregate_success':ev['success'],'cleanup':[x['returncode'] for x in load(s/'cleanup.json')]}
need(programs[0]==programs[1],'matched input/waits/regions')
result={'schema':'agent-interface/post-release-primary-comparison-v1','source_revision':'d13e2fe3b99e922de8173b81dfaaebf3dafb459e','seed':1001036,'task':'task-4','order':['inline','post'],'arms':out,'limits':['One fixed-order known-family pair; not a causal speed/token or human-tempo result.','All six fixture rows retained but only task-4 requested.','Capture after release does not acknowledge redraw or task success.']}
(p/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({arm:{'reply_ms':[c['host_send_to_reply_ms'] for c in a['calls'] if c['attempt'] in [4,6,8]],'text_bytes':[c['text_bytes'] for c in a['calls'] if c['attempt'] in [4,6,8]],'capture_after_release_ms':[c['capture_start_after_release_ms'] for c in a['calls'] if c['attempt'] in [4,6,8]],'cleanup':a['cleanup']} for arm,a in out.items()}))

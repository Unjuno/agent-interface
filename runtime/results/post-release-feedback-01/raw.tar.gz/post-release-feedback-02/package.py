import hashlib,json,tarfile
from pathlib import Path
repo=Path(__file__).resolve().parents[2];dest=repo/'runtime/results/post-release-feedback-01'
rows=[]
with tarfile.open(dest/'raw.tar.gz','w:gz') as archive:
 for name in ['post-release-feedback-01','post-release-feedback-02']:
  root=repo/'results-local'/name
  for f in sorted(root.rglob('*')):
   if f.is_file():
    data=f.read_bytes();path=name+'/'+f.relative_to(root).as_posix();rows.append({'path':path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()});archive.add(f,arcname=path,recursive=False)
data=(dest/'raw.tar.gz').read_bytes()
(dest/'manifest.json').write_text(json.dumps({'schema':'agent-interface/post-release-feedback-evidence-v1','sources':['d13e2fe3b99e922de8173b81dfaaebf3dafb459e','52ac21f4ecf9360a6c8a7e253cb04069196c253a'],'archive':{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()},'files':rows},indent=2)+'\n')
print(json.dumps({'files':len(rows),'archive_bytes':len(data)}))

import hashlib
import json
from pathlib import Path
import sys
root = Path(__file__).resolve().parent
sys.path.insert(0, str(root/'source'))
from runtime.cli_v1.receipt_references import expand_receipt

def read(name):
    return json.loads((root/name).read_text(encoding='utf-8-sig'))

compressed = read('action-1-metadata.json')
plain = read('action-2-metadata.json')
assert compressed['receipt']['schema'] == 'agent-interface/receipt-view-v3-report-ref'
assert plain['receipt']['schema'] == 'agent-interface/receipt-view-v1'
assert expand_receipt(compressed['receipt']) == plain['receipt']
assert compressed['outcome_summary'] == plain['outcome_summary']
assert plain['operation_invoked'] is False
assert compressed['outcome_summary']['input_release_verified'] is True
assert (root/'action-1.png').read_bytes() == (root/'action-2.png').read_bytes()
before = {r['path'].replace('\\','/'):r['sha256'].lower() for r in read('before-lookup-hashes.json')}
after = {p.relative_to(root/'calls').as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
         for p in (root/'calls').rglob('*') if p.is_file()}
assert before == after
assert sorted(json.loads(p.read_bytes())['operation'] for p in (root/'calls').glob('*/request.json')) == ['dispatch','observe']
assert read('effect.json') == {'saved':True,'text':'refs-83'}
assert read('primary-declaration.json')['primary_complete'] is True
size = lambda v: len(json.dumps(v,sort_keys=True,separators=(',',':')).encode())
result = {'status':'PASS_SCOPED_PRIMARY_V3_USE', 'receipt_v3_bytes':size(compressed['receipt']),
          'receipt_v1_bytes':size(plain['receipt']), 'image_bytes_equal':True,
          'v1_exact_reconstruction':True, 'retained_files_unchanged':len(after),
          'dispatch_count':1,'observe_count':1,'lookup_count':1,
          'saved_effect':read('effect.json'),'cleanup':read('cleanup.json'),
          'scope':'one private Tk fixture, SDK-mediated; no actual token, latency comparison or host-registered claim'}
(root/'RESULT.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))

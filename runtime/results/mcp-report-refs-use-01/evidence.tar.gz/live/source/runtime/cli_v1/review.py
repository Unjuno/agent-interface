"""Read a retained receipt and its referenced PNG without executing input."""
import base64
import hashlib
import json
from pathlib import Path

from .receipt import receipt_view, receipt_bytes
from .receipt_image import select_image


def review(report_path, run_directory, *, compact=False, report_refs=False):
    view = receipt_view(report_path)
    # Parse the same bytes whose digest is presented to the caller.
    data = Path(view['source']['path']).read_bytes()
    if hashlib.sha256(data).hexdigest() != view['source']['sha256']:
        raise ValueError('report changed during review')
    return _review(data, view, run_directory, compact=compact, report_refs=report_refs)


def review_bytes(data: bytes, run_directory, *, compact=False, report_refs=False):
    """Review a complete received response without a temporary report file."""
    return _review(data, receipt_bytes(data), run_directory, compact=compact, report_refs=report_refs)


def present_result(report, run_directory, *, compact=False, report_refs=False):
    """Shared transport presentation; a review error never discards the action result."""
    try:
        return review_bytes(json.dumps(report, allow_nan=False).encode('utf-8'),
                            run_directory, compact=compact, report_refs=report_refs)
    except Exception as error:
        return {'schema': 'agent-interface/review-v1', 'authority': 'none',
                'image': None, 'image_status': 'needs_review',
                'image_error': str(error), 'raw_result': report,
                'outcome_summary': outcome_summary(report)}


def _failure_source(report, failed):
    """Map a recorded failure only when the retained expansion is consistent."""
    compilation = report.get('compilation')
    if isinstance(compilation, dict) and compilation.get('kind') == 'bounded_text_gap':
        from runtime.core_v1.sequence import expand_text_gaps
        try:
            source = compilation['source_program']['ops']
            _, mapping = expand_text_gaps(source)
            if (json.dumps(mapping, sort_keys=True) != json.dumps(compilation['operation_sources'], sort_keys=True)
                    or type(failed) is not int or not 0 <= failed < len(mapping)):
                return None
            return mapping[failed]
        except (ValueError, TypeError, KeyError):
            return None
    if not isinstance(compilation, dict) or compilation.get('kind') != 'bounded_key_repeat':
        return None
    source = compilation.get('source_program')
    ops = source.get('ops') if isinstance(source, dict) else None
    mapping = compilation.get('operation_sources')
    if not isinstance(ops, list) or not isinstance(mapping, list):
        return None
    from runtime.core_v1.sequence import expand_key_repeats
    try:
        expand_key_repeats(ops, max_ops=128)
    except ValueError:
        return None
    expected = [index for index, op in enumerate(ops) for _ in range(op.get('repeat', 1))]
    if (any(type(index) is not int for index in mapping) or mapping != expected or
            type(failed) is not int or not 0 <= failed < len(mapping)):
        return None
    index = mapping[failed]
    return {'source_operation_index': index,
            'occurrence': failed - mapping.index(index) + 1,
            'occurrence_count': ops[index].get('repeat', 1)}


def _input_release_verified(execution):
    """Summarize retained release evidence without inferring missing state."""
    releases = execution.get('releases')
    if not isinstance(releases, list) or not releases:
        return None
    states = []
    for row in releases:
        if not isinstance(row, dict):
            states.append(None)
        elif row.get('verified') is False:
            states.append(False)
        elif (row.get('verified') is True and
              row.get('keys_down') == [] and row.get('buttons_down') == []):
            states.append(True)
        else:
            states.append(None)
    return False if False in states else (True if all(s is True for s in states) else None)


def outcome_summary(report):
    """Expose recorded statuses, never infer task success or absence of effects."""
    def text(row, name):
        value = row.get(name)
        return value if isinstance(value, str) and value else None

    summary = {'reported_status': text(report, 'status'),
               'error': text(report, 'error'),
               'failure_phase': text(report, 'failure_phase'),
               'cleanup_error': text(report, 'cleanup_error')}
    if report.get('schema') == 'agent-interface/runtime-dispatch-result-v1':
        dispatch = report.get('result')
        dispatch = dispatch if isinstance(dispatch, dict) else {}
        recovery = dispatch.get('recovery_required')
        execution = dispatch.get('execution')
        execution = execution if isinstance(execution, dict) else {}
        failed = execution.get('failed_op')
        invalid = dispatch.get('validation_operation_index')
        release_evidence = execution
        if dispatch.get('status') == 'refused' and 'release' in dispatch:
            # Backend preflight refusal retains its cleanup outside execution.
            # Combine records: a successful refusal cleanup must not conceal an
            # earlier failed or malformed release record.
            releases = execution.get('releases', [])
            releases = releases if isinstance(releases, list) else [None]
            release_evidence = {'releases': [*releases, dispatch['release']]}
        summary.update(
            input_release_verified=_input_release_verified(release_evidence),
            failure_detail=text(execution, 'error'),
            validation_operation_index=(invalid if type(invalid) is int and 0 <= invalid < 128
                                        and dispatch.get('status') == 'refused'
                                        and dispatch.get('error') == 'INVALID_PROGRAM'
                                        and dispatch.get('detail_source') == 'program_validation' else None),
            failed_operation_index=failed if type(failed) is int and failed >= 0 else None,
            failed_operation_effect=text(execution, 'failed_op_effect'))
        summary.update(execution_status=text(dispatch, 'status'),
                       execution_error=text(dispatch, 'error'),
                       execution_detail=text(dispatch, 'detail'),
                       recovery_required=recovery if type(recovery) is bool else None)
        if 'compilation' in report:
            summary['failed_source_operation'] = _failure_source(report, failed)
            summary['validation_source_operation'] = _failure_source(
                report, summary['validation_operation_index'])
    return summary


def _review(data, view, run_directory, *, compact=False, report_refs=False):
    if type(report_refs) is not bool or (report_refs and not compact):
        raise ValueError('report_refs requires compact=True and must be a bool')
    if compact:
        from .receipt_references import compact_receipt
        candidate = compact_receipt(view, report_refs=report_refs)
        encoded_size = lambda value: len(json.dumps(value, sort_keys=True, separators=(',', ':')).encode('utf-8'))
        if encoded_size(candidate) < encoded_size(view):
            view = candidate
    report = json.loads(data)
    result = {'schema': 'agent-interface/review-v1', 'receipt': view,
              'image': None, 'authority': 'none', 'outcome_summary': outcome_summary(report)}
    try:
        native = None
        native_reference = {}
        schema = report.get('schema')
        if schema == 'agent-interface/runtime-observation-v1':
            native = report.get('observation')
            native_reference = {'observation_id': report.get('observation_id')}
        elif schema == 'agent-interface/runtime-dispatch-result-v1':
            dispatch = report.get('result', {})
            if not isinstance(dispatch, dict):
                raise ValueError('invalid dispatch result')
            execution = dispatch.get('execution', {})
            if not isinstance(execution, dict):
                raise ValueError('invalid dispatch execution')
            observations = execution.get('observations', [])
            if not isinstance(observations, list) or any(not isinstance(o, dict) for o in observations):
                raise ValueError('invalid dispatch observations')
            if observations:
                # Backend execution appends observations in program order.
                # Preserve the list index; no synthetic exchange sequence.
                native = observations[-1]
                native_reference = {'execution_observation_index': len(observations) - 1}
        if schema in ('agent-interface/runtime-observation-v1', 'agent-interface/runtime-dispatch-result-v1'):
            if native is None:
                result['image_status'] = 'no_observation'
                return result
            if not isinstance(native, dict):
                raise ValueError('invalid runtime observation')
            artifact = native.get('artifact')
            if not isinstance(artifact, dict):
                raise ValueError('runtime observation has no PNG artifact')
            if (artifact.get('mime_type') != 'image/png' or
                    not isinstance(native.get('sha256'), str) or
                    artifact.get('source_raw_sha256') != native['sha256']):
                raise ValueError('runtime capture identity mismatch')
            # Public captures do not carry an exchange sequence.
            # Use a local singleton selector index; never expose it as sequence.
            selected = select_image({'records': [{'event': 'observation',
                'sequence': 1, 'capture_ns': native.get('capture_started_ns'),
                'image': artifact.get('path')}]}, run_directory)
            selected.pop('sequence')
            selected.update(native_reference)
            # Copy only recorded facts from this selected capture. Missing fields
            # remain absent; historical coordinates never grant input authority.
            selected['recorded_capture'] = {key: native[key] for key in (
                'target', 'native_window_id', 'frame', 'region', 'width', 'height',
                'capture_started_ns', 'capture_ended_ns', 'operation_index') if key in native}
            if selected['sha256'] != artifact.get('sha256'):
                raise ValueError('runtime image sha256 mismatch')
        else:
            selected = select_image(report, run_directory)
        if selected['status'] != 'image':
            result['image_status'] = 'no_observation'
            return result
        recorded = report.get('image')
        if isinstance(recorded, dict) and recorded.get('status') == 'image':
            for field in ('sequence', 'capture_ns', 'path', 'sha256'):
                if recorded.get(field) != selected.get(field):
                    raise ValueError('report image identity mismatch: ' + field)
        image_bytes = Path(selected['path']).read_bytes()
        if hashlib.sha256(image_bytes).hexdigest() != selected['sha256']:
            raise ValueError('image changed during review')
        if not image_bytes.startswith(b'\x89PNG\r\n\x1a\n'):
            raise ValueError('referenced file is not a PNG')
        result['image'] = {'type': 'image', 'mimeType': 'image/png',
                           'data': base64.b64encode(image_bytes).decode('ascii')}
        result['image_reference'] = selected
        result['image_status'] = 'image'
    except Exception as error:
        # An unavailable image must never erase the action result or replay it.
        result.update(image_status='needs_review', image_error=str(error))
    return result

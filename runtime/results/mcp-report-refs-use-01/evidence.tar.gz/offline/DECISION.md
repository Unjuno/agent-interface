# Local integration decision

On the existing source at 09caefb54475808c196794e058717f4d28981bd1,
the read-only Docker check covered 11 retained real-use reports in three modes
(33 projections). Every selected representation reconstructed the original v1
receipt exactly and preserved the outcome summary. The normal compact option
selected plain v1 for all 11 inputs; explicit report_refs selected v3 for all 11.

For the latest primary MCP action, receipt JSON was 11224 bytes in plain/compact
and 6083 bytes with report_refs. The latest observation was 2105 vs 1523 bytes.
These are canonical JSON receipt sizes, excluding images, MCP envelope and
transport formatting; they are not measured model tokens or latency.

Decision: use the already implemented opt-in report_refs in the next compatible
primary MCP session. Do not implement another compressor or change defaults.
The decoder requires no external fetch: /source/raw_report is in the same
response. Unknown formats must remain explicit rather than silently interpreted.
The real-use selection is convenience coverage, not a balanced benchmark.

This complements PR #4414's synthetic processing/byte tradeoff evidence without
claiming to have independently audited that unmerged research artifact. No GUI,
input action, model or provider was invoked here. The existing report image
files were not read or transformed. Full pipeline/image parity and actual
primary interpretation of v3 remain the next live-use checks.

Original script, PLAN, inputs, all projected views and RESULT are retained
locally. Container ai-receipt-real-use-projection-01 exited 0. This record is a
local construction check, not a pre-registered formal allocation or independent
review. No remote publication is needed for this step alone.

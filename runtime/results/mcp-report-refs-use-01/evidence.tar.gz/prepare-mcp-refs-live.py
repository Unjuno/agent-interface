from pathlib import Path
import hashlib
import json
import subprocess

repo = Path(__file__).resolve().parents[1]
root = repo/'results-local/mcp-refs-live-01'
root.mkdir(exist_ok=False)
previous = repo/'results-local/mcp-retention-live-01'
owner = (previous/'owner.py').read_text().replace("'compact': True})", "'compact': True, 'report_refs': True})")
(root/'owner.py').write_text(owner, encoding='utf-8')
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip()
sources = {}
for name in json.loads((previous/'FREEZE.json').read_text())['sources']:
    data = subprocess.check_output(['git', 'show', revision+':'+name], cwd=repo)
    target = root/'source'/name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    sources[name] = hashlib.sha256(data).hexdigest()
(root/'FREEZE.json').write_text(json.dumps({'revision': revision, 'sources': sources,
    'owner_sha256': hashlib.sha256((root/'owner.py').read_bytes()).hexdigest()}, indent=2))
(root/'PLAN.json').write_text(json.dumps({
    'task': 'primary sees initial state, enters refs-83 and saves',
    'route': 'SDK-mediated public MCP; compact=true report_refs=true for observation and dispatch',
    'checks': 'primary reads v3 plus image, declares completion before effect readback; lookup plain result without input and compare expanded receipt and image identity',
    'limits': 'one input dispatch, max four decisions, 300 seconds each; no replay on uncertainty',
    'scope': 'one private fixture; caller source/binding1/0 and owner deadline10s; no matched speed or model-token claim'
}, indent=2))
print(root)

"""Offline compatibility check of existing opt-in projection on retained real use."""
import copy
import hashlib
import json
from pathlib import Path
import tarfile
from runtime.cli_v1.receipt import receipt_bytes
from runtime.cli_v1.receipt_references import compact_receipt, expand_receipt
from runtime.cli_v1.review import outcome_summary

ROOT = Path('/src')
OUT = Path('/out/receipt-real-use-projection-01')
OUT.mkdir(exist_ok=False)
plan = {'scope': 'offline existing projection on retained real reports; no GUI, latency or model-token measurement',
        'selection': 'all request-independent report.json files in the MCP retention calls; all report.json archive members in two named Calc bundles',
        'archives': ['cli-retained-calc-01', 'main-compact-calc-01'],
        'modes': ['plain', 'compact', 'report_refs'],
        'gate': 'exact v1 reconstruction and unchanged outcomes for every input; no default promotion'}
(OUT/'PLAN.json').write_text(json.dumps(plan, indent=2))
inputs = []
for p in sorted((ROOT/'runtime/results/mcp-retention-integration-01/live/calls').glob('*/report.json')):
    inputs.append((str(p.relative_to(ROOT)), p.read_bytes()))
for name in plan['archives']:
    path = ROOT/'runtime/results'/name/'evidence.tar.gz'
    with tarfile.open(path, 'r:gz') as archive:
        for member in sorted(archive.getmembers(), key=lambda m: m.name):
            if member.isfile() and member.name.endswith('/report.json'):
                inputs.append((name+':'+member.name, archive.extractfile(member).read()))
rows = []
encode = lambda value: json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
for index, (name, data) in enumerate(inputs):
    (OUT/f'input-{index}.json').write_bytes(data)
    base = receipt_bytes(data)
    summary = outcome_summary(json.loads(data))
    for mode in plan['modes']:
        candidate = copy.deepcopy(base) if mode == 'plain' else compact_receipt(base, report_refs=mode == 'report_refs')
        # Same smaller-only choice as the production review path.
        selected = candidate if len(encode(candidate)) < len(encode(base)) else copy.deepcopy(base)
        expanded = expand_receipt(selected)
        assert expanded == base, (name, mode)
        assert outcome_summary(expanded['source']['raw_report']) == summary
        (OUT/f'view-{index}-{mode}.json').write_bytes(encode(selected))
        rows.append({'input': name, 'sha256': hashlib.sha256(data).hexdigest(), 'mode': mode,
                     'schema': selected['schema'], 'receipt_json_bytes': len(encode(selected)),
                     'v1_exact': True, 'outcomes_equal': True})
assert inputs, 'no retained input'
(OUT/'RESULT.json').write_text(json.dumps({'scope': plan['scope'], 'inputs': len(inputs), 'rows': rows}, indent=2))
print(json.dumps({'inputs': len(inputs), 'rows': rows}))

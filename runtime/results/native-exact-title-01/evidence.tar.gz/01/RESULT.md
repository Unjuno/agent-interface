# Native Inkscape use through the existing WSL fallback

One new private allocation completed the requested move-right-preserve-geometry
task using existing Native MCP. The primary viewed initial.png, requested an
input-free observation, viewed action-1.png, then clicked the rectangle's
observed left edge, requested three Right chords and Ctrl+S, and viewed the
returned image. It declared the visible result before finish/evaluation and
before the separate saved-SVG readback.

- Source: 4d3cb6adc32877cc4b270bf1c186173982553a21. No runtime source edits while live.
- WSL Ubuntu, Inkscape 1.2.2, Python 3.12.3, MCP 1.30.0. Full inventory in versions.json.
- Seed991284, max8 stages, text gap2ms, explicit250ms wait in the input request.
- Observe stage1/source1 dispatched no input and returned stage2/source2.
- Initial and input-free-observe image hashes are identical. This trial did not
  reproduce or recover the earlier Docker layout change.
- One input request completed with release verified and no held keys/buttons.
  Feedback stayed pending; returned image and continuation supplied stage3/source8.
- The primary viewed X=54.000/Y=50.000/W=40.000/H=30.000 in the toolbar.
- Finish evaluation succeeded. A separate parse of the saved SVG confirmed
  x=54, y=50, width=40, height=30, transform absent.
- SVG SHA256: cc5d7d02d38ae45ff821d2fc6423fd8388480b0768b729e433995e04599d7409.
- Native owner822 subsequently exited0. Client/WSL invocation exited0.
  Cleanup records tracked processes terminal, with no errors, but does not
  verify all descendants; native_status retains cleanup_verified=false.

This was SDK-mediated primary use on a new private Xvfb display. It used the
continuation returned in each response without additional source-N file reads.
No input replay, helper agent, new sensor or readiness implementation was used.
The consumed Docker refusal is retained in the predecessor published bundle;
the prepared Docker native-02 successor was never launched. WSL has a different
Inkscape version and environment, so this is not a matched comparison or proof
that explicit observe fixes readiness. It is a functional completion of this
one task with the existing interface. Timing, actual model-token improvements,
human-speed claims and the six-task integration spine remain unproven.

PR #4526 merged as ade7adb1d5e41c1af45fd3388a7a97c5b08932a8 after all5 CI checks
passed. This new WSL trial was performed locally after that merge and is not
part of its already-frozen three-allocation archive. Keep this result for the
next coherent integration batch; do not rewrite the old archive.

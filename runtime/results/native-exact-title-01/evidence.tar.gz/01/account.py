"""Read the completed trial only, then retain consistency checks and file hashes."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
def read(name):
    return json.loads((root / name).read_text(encoding='utf-8-sig'))

initial = read('initial-metadata.json')
observe = read('action-1-metadata.json')
action = read('action-2-metadata.json')
finish = read('action-3-metadata.json')
status = read('action-4-metadata.json')
saved = read('saved-file-check.json')
assert observe['receipt']['native_result']['observation_only']['input_dispatched'] is False
assert initial['image_reference']['sha256'] == observe['image_reference']['sha256']
for number, reply in [(1, observe), (2, action)]:
    continuation = reply['continuation']
    next_decision = read(f'decision-{number+1}.json')['arguments']
    assert continuation['status'] == 'source_available'
    assert continuation['stage'] == next_decision['stage']
    assert continuation['source_sequence'] == next_decision['decision']['source_sequence']
    assert continuation['source_sequence'] == reply['image_reference']['sequence']
    image = (root / f'action-{number}.png').read_bytes()
    assert hashlib.sha256(image).hexdigest() == reply['image_reference']['sha256']
release = action['receipt']['native_result']['action']['result']['execution']['releases'][-1]
assert release['verified'] and release['keys_down'] == [] and release['buttons_down'] == []
assert action['outcome_summary']['action_status'] == 'completed'
assert action['outcome_summary']['feedback_status'] == 'pending'
assert finish['outcome_summary']['evaluation_success'] is True
assert finish['receipt']['native_result']['evaluation']['actual'] == saved['actual']
assert saved['status'] == 'PASS_SAVED_GEOMETRY'
assert saved['sha256'] == hashlib.sha256((root/'allocation/run/shape.svg').read_bytes()).hexdigest()
assert status['allocation']['status'] == 'terminal' and status['allocation']['returncode'] == 0
assert read('client-exit.json')['exit_code'] == 0
assert finish['receipt']['native_result']['cleanup']['tracked_processes_terminal'] is True
assert status['allocation']['cleanup_verified'] is False
timings = [read(f'action-{i}-timing.json') for i in (1, 2, 3)]
span = (timings[-1]['end_ns'] - timings[0]['start_ns']) / 1e9
inside = sum(t['end_ns'] - t['start_ns'] for t in timings) / 1e9
report = {'status': 'PASS_RECORDED_CONSISTENCY', 'input_requests': 1,
          'observation_only_requests': 1, 'feedback_status': 'pending',
          'saved_geometry': saved['actual'], 'owner_exit': 0, 'client_exit': 0,
          'full_descendant_cleanup_verified': False,
          'client_span_first_observe_through_finish_s': span,
          'inside_three_sdk_calls_s': inside, 'between_calls_s': span-inside,
          'scope': 'local completed-trial audit; not independent model/performance validation'}
(root / 'accounting.json').write_text(json.dumps(report, indent=2))
manifest = {}
for path in sorted(root.rglob('*')):
    if path.is_file() and path.name != 'manifest.json':
        data = path.read_bytes()
        if path.suffix == '.json':
            json.loads(data.decode('utf-8-sig'))
        manifest[path.relative_to(root).as_posix()] = hashlib.sha256(data).hexdigest()
(root / 'manifest.json').write_text(json.dumps(manifest, indent=2))
print(json.dumps({'accounting': report, 'manifest_files': len(manifest)}))

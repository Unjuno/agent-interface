"""Record the actual WSL environment; do not launch a GUI allocation."""
import importlib.metadata
import json
import platform
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
commands = {
    'inkscape': ['/usr/bin/inkscape', '--version'],
    'libreoffice': ['/usr/bin/libreoffice', '--version'],
    'packages': ['dpkg-query', '-W', 'xvfb', 'openbox', 'wmctrl', 'python3-numpy', 'python3-openpyxl', 'python3-pil', 'python3-xlib'],
}
records = {}
for name, command in commands.items():
    result = subprocess.run(command, text=True, capture_output=True, timeout=20)
    records[name] = {'command': command, 'returncode': result.returncode,
                     'stdout': result.stdout, 'stderr': result.stderr}
value = {'python': sys.version, 'platform': platform.platform(),
         'mcp': importlib.metadata.version('mcp'), 'records': records,
         'scope': 'WSL fallback; differs from the prior Docker allocations'}
(root / 'versions.json').write_text(json.dumps(value, indent=2))
print(json.dumps(value))

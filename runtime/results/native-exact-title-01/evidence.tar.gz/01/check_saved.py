"""Separate saved-SVG readback after the primary declaration and finish."""
import hashlib
import json
from pathlib import Path
import time
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent
assert (root / 'primary-declaration.md').is_file()
assert (root / 'action-3-metadata.json').is_file()
data = (root / 'allocation/run/shape.svg').read_bytes()
document = ET.fromstring(data)
rectangles = document.findall('.//{http://www.w3.org/2000/svg}rect')
assert len(rectangles) == 1, len(rectangles)
rectangle = rectangles[0]
actual = {k: rectangle.get(k) for k in ('x', 'y', 'width', 'height', 'transform')}
assert float(actual['x']) > 50.5
for key, target in [('y', 50), ('width', 40), ('height', 30)]:
    assert abs(float(actual[key]) - target) < .1, actual
assert actual['transform'] is None, actual
result = {'status': 'PASS_SAVED_GEOMETRY', 'actual': actual,
          'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data),
          'known_ns': time.monotonic_ns(),
          'scope': 'separate post-finish SVG parse, not another evaluator decision'}
(root / 'saved-file-check.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result))

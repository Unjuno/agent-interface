Before finish/evaluator and saved SVG readback, I viewed action-2.png.
The selected red rectangle toolbar shows X54, Y50, W40, H30 in px, and the
title is shape.svg - Inkscape. The visible status bar says the SVG was saved.
This meets the visible geometry goal; saved transform remains to be checked.
The action completed with verified release, feedback matched, and the same
response continuation supplies stage3/source8. No additional source-N read.

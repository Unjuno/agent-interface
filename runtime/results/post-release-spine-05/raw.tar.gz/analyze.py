"""Audit interrupted primary self-use; deliberately never returns product acceptance."""
import base64, hashlib, json
from pathlib import Path

def require(ok, why):
    if not ok:
        raise ValueError(why)

def analyze(root):
    root = Path(root)
    load = lambda p: json.loads((root / p).read_text())
    plan = load('PLAN.json')
    for name, digest in plan['hashes'].items():
        require(hashlib.sha256((root/name).read_bytes()).hexdigest() == digest, 'frozen source '+name)
    result = {'status':'HOLD_PRIMARY_PROTOCOL_DEVIATIONS', 'source':plan['source'], 'seed':plan['seed'], 'routes':{}}
    for route, expected_calls, expected_counts in [('guarded-local',41,[1,1,1,0,0,0]),('direct-post',4,[0]*6)]:
        directory = root/route/'host'
        requests = sorted(directory.glob('request-*.json'), key=lambda p:int(p.stem.split('-')[-1]))
        require(len(requests)==expected_calls, 'call inventory '+route)
        inputs=[]; pictures=0; errors=[]; parsed={}
        for index, path in enumerate(requests,1):
            request=json.loads(path.read_text()); require(request['id']==index,'request sequence')
            reply=json.loads((directory/f'reply-{index}.json').read_text())
            content=reply['result']['content']
            texts=[c['text'] for c in content if c['type']=='text']
            try: meta=json.loads(texts[0])
            except json.JSONDecodeError: meta={'text':texts[0]}
            parsed[index]=meta
            if reply['result'].get('isError'): errors.append(index)
            for c in content:
                if c['type']=='image':
                    require(base64.b64decode(c['data']).startswith(b'\x89PNG\r\n\x1a\n'),'original PNG')
                    pictures+=1
            if request['tool'] in ('interface_dispatch','interface_guarded_input'):
                require(meta.get('status')=='completed','input outcome')
                releases=meta['result']['execution']['releases']
                require(releases and all(r['verified'] and not r['keys_down'] and not r['buttons_down'] for r in releases),'neutral input')
                inputs.append(index)
        score=load(route+'/session/evaluation-at-close.json')
        require([score['exact_counts'][f'task-{i}'] for i in range(1,7)]==expected_counts,'independent score')
        require(not score['success'] and not score['duplicates'] and not score['unexpected'],'scorer scope')
        terminal=load(route+'/original-terminal.json');require(terminal['exit_code']==0,'original terminal')
        transport=load(route+'/host/exit.json');require(transport['code']==0 and transport['signal'] is None,'transport terminal')
        result['routes'][route]={'calls':len(requests),'input_attempts':inputs,'original_reply_images':pictures,'error_attempts':errors,'score':score,'cleanup':load(route+'/session/cleanup.json')}
        if route=='guarded-local':
            require(errors==[30] and parsed[30]['text']=='Unknown tool: interface_observe','wrong tool refusal')
            require(inputs==[4,8,10,13,16,18,20,23,26,28,34,37,40],'all launched input retained')
            close=parsed[41];require(close['status']=='closed' and close['release']['verified'] and not close['release']['keys_down'] and not close['release']['buttons_down'],'public neutral close')
            lifetime=parsed[6]['lifetime'];clock=parsed[29]
            require(lifetime['expires_ns']-lifetime['minted_ns']==300000000000,'original finite expiry')
            remaining=lifetime['expires_ns']-clock['monotonic_ns']
            require(remaining==-143856943400 and clock['authority_granted'] is False and clock['lease_issued'] is False,'expiry precheck')
            require(parsed[31]['status']=='observed' and parsed[32]['alias']=='save_off_a_refresh3','primary remint record')
            finish=load(route+'/session/finish.json');require(finish['stopAtAttempt']==30,'declared deviation')
            for attempt in [4,8,10,13,16,18,20,23,26,28,31,34,37,40]:
                receipt=json.loads((directory/f'review-{attempt}.json').read_text())
                require(receipt['reply_sha256']==hashlib.sha256((directory/f'reply-{attempt}.json').read_bytes()).hexdigest(),'review original reply')
                images=[hashlib.sha256(base64.b64decode(c['data'])).hexdigest() for c in json.loads((directory/f'reply-{attempt}.json').read_text())['result']['content'] if c['type']=='image']
                require([i['sha256'] for i in receipt['images']]==images,'review image attribution')
            result['expiry_precheck']={'clock_attempt':29,'remaining_ns':remaining,'input_sent_for_expired_alias':False,'remint_attempt':32,'post_refusal_input_attempts':[34,37,40],'protocol_valid':False}
        else:
            require(not inputs and not errors,'direct input not sent')
            require(not (directory/'review-4.json').exists(),'review failed before receipt')
            close_files=list((root/route/'session/server').glob('session-*-close.json'))
            require(len(close_files)==1,'server close inventory')
            close=json.loads(close_files[0].read_text())
            require(close['status']=='closed' and close['release_attempted'] is False,'direct no release proof')
            result['routes'][route]['public_close_returned']=False
    result.update({'matched_comparison':False,'model_tokens':None,'dollars':None,'human_tempo_proven':False,'scope':'Original launched allocations retained; no retries. Primary tool-name and review-argument failures invalidate comparison.'})
    return result

if __name__=='__main__':
    import sys
    print(json.dumps(analyze(sys.argv[1] if len(sys.argv)>1 else Path(__file__).parent),indent=2))

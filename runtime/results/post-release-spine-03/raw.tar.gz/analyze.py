import base64,hashlib,json,statistics
from pathlib import Path
from PIL import Image,ImageChops
def need(ok,why):
 if not ok:raise ValueError(why)
def load(p):return json.loads(p.read_text())
def meta(r):return json.loads(next(x['text'] for x in r['result']['content'] if x['type']=='text'))
def analyze(root):
 plan=load(root/'PLAN.json');out={}
 for name,digest in plan['hashes'].items():need(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,'pinned '+name)
 need(load(root/'build-manifest.json')['source_revision']==plan['source'],'build pin')
 for route in plan['order']:
  path=root/route;host=path/'host';session=path/'session';goal=load(session/'goal.json')
  need(load(session/'allocation.json')['source']==plan['source'] and load(session/'allocation.json')['seed']==plan['seed'],'allocation')
  replies={int(p.stem.split('-')[1]):load(p) for p in host.glob('reply-*.json')}
  requests={int(p.stem.split('-')[1]):load(p) for p in host.glob('request-*.json')}
  need(set(replies)==set(requests)==set(range(1,len(replies)+1)),'attempt completeness')
  events=[json.loads(l) for l in (host/'host-events.jsonl').read_text().splitlines()]
  def event(kind,a):
   found=[e for e in events if e['kind']==kind and e.get('attempt')==a];need(len(found)==1,'event '+kind);return found[0]
  images=0;bytes_text=0;emissions=0;reviews=0
  for a,r in replies.items():
   need(r['id']==requests[a]['id'] and r['tool']==requests[a]['tool'] and r['status']=='returned','request identity')
   digest=hashlib.sha256((host/f'reply-{a}.json').read_bytes()).hexdigest()
   timeline=[event(k,a) for k in ['send_requested','reply_available','presentation_started','presentation_callbacks_completed']]
   need([x['sequence'] for x in timeline]==sorted(x['sequence'] for x in timeline),'presentation ordering')
   need(all(x.get('reply_sha256',digest)==digest for x in timeline),'reply digest')
   m=meta(r);content=r['result']['content'];pics=[x for x in content if x['type']=='image']
   images+=len(pics);bytes_text+=sum(len(x['text'].encode()) for x in content if x['type']=='text')
   execution=m.get('result',{}).get('execution') or m.get('receipt',{}).get('execution_summary')
   if execution:
    need(all(x['verified'] is True and x['keys_down']==x['buttons_down']==[] for x in execution['releases']),'release')
    emissions+=execution['program_emissions']
   if pics:
    need(len(pics)==1,'one PNG');png=base64.b64decode(pics[0]['data'],validate=True);ih=hashlib.sha256(png).hexdigest()
    rv=load(host/f'review-{a}.json');need(rv['reply_sha256']==digest and rv['images']==[{'mime_type':'image/png','sha256':ih}],'actual image review')
    need(any(p.read_bytes()==png for p in (session/'server'/m['call_id']/'images').glob('*.png')),'native handoff');reviews+=1
  history=[json.loads(l) for l in (session/'submission-history.jsonl').read_text().splitlines()];expected=goal['tasks'][:1] if route=='guarded-local' else goal['tasks']
  need(len(history)==len(expected),'independent history count')
  for h,t in zip(history,expected):need(h['exact'] is True and h['task_id']==t['task_id'] and h['submitted_values']==[t['token']],'actual submitted token')
  score=load(session/'evaluation-at-close.json');need(score['record_count']==len(expected) and not score['unexpected'] and not score['duplicates'],'oracle')
  need(score['exact_counts']=={f'task-{i}':int(route=='direct-post' or i==1) for i in range(1,7)},'six-task accounting')
  need(score['missing']==([] if route=='direct-post' else [f'task-{i}' for i in range(2,7)]),'missing rows')
  close=meta(replies[len(replies)]);need(close['status']=='closed' and close['release']['verified'] is True and close['release']['keys_down']==close['release']['buttons_down']==[],'neutral close')
  need(load(host/'exit.json')['code']==0 and load(root/('guarded-terminal.json' if route=='guarded-local' else 'direct-terminal.json'))['exit_code']==0,'terminal handles')
  rows=[]
  for i in range(6):
   submit=[a for a,q in requests.items() if q['tool']=='interface_dispatch' and any(o.get('text')==goal['tasks'][i]['token'] for o in q['arguments']['program']['ops'])] if route=='direct-post' else [6] if i==0 else [9] if i==1 else []
   if submit:
    a=submit[0];first=a-1 if route=='guarded-local' else a;m=meta(replies[a]);shown=event('presentation_callbacks_completed',a)['host_monotonic_ms'];started=event('send_requested',first)['host_monotonic_ms']
    rows.append({'task':f'task-{i+1}','start_attempt':first,'submit_attempt':a,'status':m.get('status') or m['outcome_summary']['execution_status'],'batch_to_feedback_delivery_ms':shown-started,'completion_review_ms':event('review_recorded',a)['host_monotonic_ms']-started,'independent_saved':i<len(expected)})
   else:rows.append({'task':f'task-{i+1}','status':'skipped_after_stop','independent_saved':False})
  out[route]={'calls':len(replies),'images':images,'image_reviews':reviews,'text_bytes':bytes_text,'retained_pngs':len(list((session/'server').rglob('*.png'))),'emissions':emissions,'rows':rows,'score':score,'cleanup':load(session/'cleanup.json')}
 fail=meta(load(root/'guarded-local/host/reply-9.json'));need(fail['status']=='execution_failed' and fail['result']['execution']['failed_op']==2 and fail['result']['execution']['program_emissions']==1 and fail['result']['guard_checks'][-1]['reason']=='region_pixels_missing','original failure')
 image_dir=root/'guarded-local/session/server'/fail['call_id']/'images';files=sorted(image_dir.glob('*.png'),key=lambda p:p.stat().st_mtime_ns);need(len(files)==5,'failure captures')
 before=Image.open(files[2]).convert('RGB');after=Image.open(files[3]).convert('RGB');diff=ImageChops.difference(before,after)
 crop_before=before.crop((364,394,388,408));crop_after=after.crop((364,394,388,408))
 delta={'ordering_scope':'Filesystem creation timestamps; diagnostic association of five captures with four checks plus final feedback. No standalone stage-ID attestation.','before_file':files[2].name,'after_file':files[3].name,'full_rgb_diff_bbox':diff.getbbox(),'guard_crop_equal':crop_before.tobytes()==crop_after.tobytes(),'guard_crop_before_sha256':hashlib.sha256(crop_before.tobytes()).hexdigest(),'guard_crop_after_sha256':hashlib.sha256(crop_after.tobytes()).hexdigest(),'interpretation':'Hover rendering candidate; needs a separate controlled experiment, no semantic identity or safe acceptance inferred.'}
 return {'status':'HOLD_INTEGRATION_EXECUTION_FAILED','source':plan['source'],'seed':plan['seed'],'routes':out,'failure':{'attempt':9,'mcp_isError':load(root/'guarded-local/host/reply-9.json')['result']['isError'],'status':fail['status'],'failed_op_effect':fail['result']['execution']['failed_op_effect'],'delta':delta},'limits':['Unequal completion; no full-route speed or token-efficiency comparison.','Serial same-primary known-family execution; context/cache confounded.','Recovery/task4 not reached in guarded arm.','No replay, restart or scientific acceptance.']}
if __name__=='__main__':
 import sys
 root=Path(sys.argv[1]);result=analyze(root)
 if len(sys.argv)>2:
  with Path(sys.argv[2]).open('x') as f:json.dump(result,f,indent=2)
 print(json.dumps(result,indent=2))

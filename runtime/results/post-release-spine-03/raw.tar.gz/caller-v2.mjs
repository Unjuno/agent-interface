import {writeFile} from 'node:fs/promises';
export const meta=r=>JSON.parse(r.result.content.find(x=>x.type==='text').text);
const tap=p=>[{op:'pointer_move',frame:'screen_physical_px',x:p[0],y:p[1]},{op:'pointer_button',button:'left',down:true},{op:'pointer_button',button:'left',down:false}];
export const nav=url=>[{op:'key_chord',keys:['CTRL','l']},{op:'wait_update',timeout_ms:100},{op:'text',text:url},{op:'wait_update',timeout_ms:100},{op:'key_chord',keys:['ENTER']},{op:'wait_update',timeout_ms:200}];
const field=token=>[{op:'key_chord',keys:['CTRL','a']},{op:'wait_update',timeout_ms:100},{op:'text',text:token},{op:'wait_update',timeout_ms:100}];
export const program=(seq,id,expires,ops)=>({schema:'agent-interface/program-v1',program_id:id,source:{observation_seq:seq,binding_revision:1},authority:{lease_id:'spine-direct',expires_at_ns:expires},terminal:{release_all_required:true},ops:[{op:'focus',target:'browser'},...ops,{op:'release_all'}]});
const batch=(token,a,b)=>[...tap(a),...field(token),...tap(b),{op:'wait_update',timeout_ms:100}];
export function createCaller(host,goal,dir,show,route){
 let seq=1,n=0;const rows=[],guarded=route==='guarded-local';const displayed=async()=>{};
 const checked=async(tool,args,expectedRefusal=false)=>{const r=await host.sendPresented(tool,args,show);if(r.result.isError&&!expectedRefusal){const error=Error('tool error '+tool);error.reply=r;throw error;}if(expectedRefusal&&r.result.isError!==true)throw Error('planned refusal did not occur');return r;};
 const direct=async(i,phase,ops)=>{const clock=await checked('interface_clock',{}),c=meta(clock);if(c.authority_granted!==false||c.lease_issued!==false||!Number.isSafeInteger(c.monotonic_ns))throw Error('clock');await writeFile(dir+'/author-clock-'+(++n)+'.json',JSON.stringify({i,phase,clock})+'\n',{flag:'wx'});const r=await checked('interface_dispatch',{program:program(seq,'spine-'+i+'-'+phase+'-'+n,c.monotonic_ns+5000000000,ops),current_observation_seq:seq,current_binding_revision:1,compact:true,report_refs:true,detail:'summary',inspect_after:'browser',inspect_after_region:[0,0,1280,800]});seq++;await displayed(r);return r;};
 const capture=()=>checked(guarded?'interface_guarded_observe':'interface_observe',guarded?{}:{target:'browser',frame:'screen_physical_px',region:[0,0,1280,800],compact:true,report_refs:true});
 return {rows,
 initial:async()=>{const r=await capture();await displayed(r);return r;},
 navigate:async(i,alias)=>{const row={task:goal.tasks[i].task_id,index:i};rows.push(row);row.navigation=guarded?await checked('interface_guarded_input',{alias,offset:[12,12],interaction:'keyboard',tail:nav(goal.tasks[i].url),detail:'brief'}):await direct(i,'navigate',nav(goal.tasks[i].url));if(guarded)await displayed(row.navigation);return row.navigation;},
 mint:async(source,references)=>{const r=await checked('interface_guarded_mint_many',{source_sequence:source,references});await displayed(r);return r;},
 probe:async(alias)=>{const r=await checked('interface_guarded_input',{alias,offset:[12,19],tail:[],detail:'brief'},true);await displayed(r);return r;},
 reviewWindow:async(window)=>{const r=await checked('interface_guarded_review_window',{window_id:window});await displayed(r);return r;},
 staleMint:async(source)=>{const r=await checked('interface_guarded_mint',{alias:'stale_source_control',source_sequence:source,point:[230,401],region_size:[24,38]},true);await displayed(r);return r;},
 submit:async(i,a,b)=>{const row=rows[i];let r;if(guarded){row.field=await checked('interface_guarded_input',{alias:a,offset:[12,19],tail:field(goal.tasks[i].token),observe_after:false,detail:'brief'});const m=meta(row.field),e=m.result?.execution;if(m.status!=='completed'||!e?.releases?.length||e.releases.some(x=>x.verified!==true||x.keys_down.length||x.buttons_down.length)||m.result?.recovery_required){row.stop='FIELD_NOT_COMPLETED_NEUTRAL';await displayed(row.field);return row.field;}r=await checked('interface_guarded_input',{alias:b,offset:[12,7],tail:[{op:'wait_update',timeout_ms:100}],detail:'brief'});await displayed(r);}else r=await direct(i,'submit',batch(goal.tasks[i].token,a,b));row.saved=r;return r;},
 confirm:async(i)=>{const r=await capture();seq++;rows[i].confirmation=r;await displayed(r);return r;},
 preflight:async()=>{if(guarded)return [];const replies=[];for(const [i,ops] of [nav(goal.tasks[0].url),batch(goal.tasks[0].token,[230,401],[376,401]),batch(goal.tasks[3].token,[630,558],[689,634])].entries()){const r=await checked('interface_validate',{program:program(1,'spine-preflight-'+i,5000000000,ops)});await displayed(r);replies.push(r);if(meta(r).status!=='valid')throw Error('static program invalid');}return replies;},
 lookup:async(call)=>{const r=await checked('interface_results',{call_id:call,include_image:false,compact:true,report_refs:true});if(meta(r).operation_invoked!==false)throw Error('lookup invoked');return r;},
 close:async()=>{const r=await checked('interface_close',{});await displayed(r);return r;}};
}

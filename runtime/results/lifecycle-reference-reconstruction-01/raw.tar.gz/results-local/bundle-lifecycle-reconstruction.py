import hashlib,json,tarfile
from pathlib import Path
r=Path(__file__).resolve().parents[1];out=r/'runtime/results/lifecycle-reference-reconstruction-01';out.mkdir(exist_ok=False)
paths=list((r/'results-local/lifecycle-reference-reconstruction-01').rglob('*'))
paths += [r/'results-local/reconstruct-lifecycle-reference-bytes.py',Path(__file__)]
manifest={}
with tarfile.open(out/'raw.tar.gz','w:gz') as archive:
 for p in sorted(paths):
  if not p.is_file():continue
  name=p.relative_to(r).as_posix();data=p.read_bytes()
  manifest[name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)};archive.add(p,arcname=name)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(manifest),'archive_bytes':(out/'raw.tar.gz').stat().st_size}))

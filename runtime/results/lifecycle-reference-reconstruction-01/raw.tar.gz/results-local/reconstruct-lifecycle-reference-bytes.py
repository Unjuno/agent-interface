"""Explicit additive reconstruction, never a formal timing rerun."""
import hashlib,json,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parents[1];prior=r/'results-local/lifecycle-intake-01'
out=r/'results-local/lifecycle-reference-reconstruction-01';out.mkdir(exist_ok=False)
sha=lambda data:hashlib.sha256(data).hexdigest()
def require(value,message):
 if not value:raise ValueError(message)
manifest=json.loads((prior/'source-manifest.json').read_text())
diagnostic=json.loads((prior/'reference-diagnostic.json').read_text())
mapping={row['path']:row for row in diagnostic};changed=[]
for name,record in manifest['files'].items():
 data=(prior/'source'/name).read_bytes();require(sha(data)==record['sha256'],'original source changed: '+name)
 if name in mapping:
  row=mapping[name];require(sha(data)==row['current'],'mapping input')
  restored=data.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')
  require(sha(restored)==row['expected'],'mapping output must equal frozen digest')
  changed.append({'path':name,'input_sha256':sha(data),'output_sha256':sha(restored),'operation':'LF to CRLF; exact frozen hash required'})
  data=restored
 target=out/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
require(len(changed)==2,'exact two-reference reconstruction')
(out/'reconstruction.json').write_text(json.dumps({'source_commit':manifest['commit'],'changes':changed,'scope':'derived copy only; original frozen records and shared dependencies unchanged; no formal rerun'},indent=2)+'\n')
suite=out/'source/research/analysis/needle_role_skill_lifecycle_5133_v2'
commands=[['python3','-B','-m','unittest','discover','-s',str(suite),'-p','test_*.py','-v'],['python3','-B',str(suite/'audit_correction.py'),'--raw',str(suite/'results/formal-04/raw.json'),'--prior-audit',str(suite/'results/audit-04/audit.json'),'--out',str(out/'correction.json')]]
results=[]
for n,command in enumerate(commands,1):
 with (out/f'check-{n}.stdout').open('w') as stdout,(out/f'check-{n}.stderr').open('w') as stderr:
  result=subprocess.run(command,cwd=out/'source',stdout=stdout,stderr=stderr)
 results.append({'command':command,'returncode':result.returncode})
 if result.returncode:break
(out/'checks.json').write_text(json.dumps(results,indent=2)+'\n')
if len(results)==2 and not any(x['returncode'] for x in results):
 original=json.loads((suite/'results/audit-correction-04/correction.json').read_text());current=json.loads((out/'correction.json').read_text())
 differences={k:{'retained':original.get(k),'linux':current.get(k)} for k in set(original)|set(current) if original.get(k)!=current.get(k)}
 (out/'comparison.json').write_text(json.dumps({'differences':differences,'identical_except_python_version':set(differences)<= {'auditor_python'}},indent=2)+'\n')
 require(set(differences)<= {'auditor_python'},'unexpected corrected audit difference')
print(json.dumps(results));sys.exit(any(x['returncode'] for x in results))

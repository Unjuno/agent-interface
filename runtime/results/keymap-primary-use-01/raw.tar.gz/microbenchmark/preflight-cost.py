import subprocess,time,json,statistics
from runtime.backends.x11_v1.backend import X11Backend
ns={'__name__':'baseline_backend'}
exec(compile(subprocess.check_output(['git','show','1314d8d0113fcef1b72694e6ca0431b5420f74c5:runtime/backends/x11_v1/backend.py'],text=True),'baseline_backend','exec'),ns)
old=ns['X11Backend'](None,{})
new=X11Backend(None,{})
program={'ops':[{'op':'text','text':'http://a_b'},{'op':'release_all'}]}
samples={'baseline':[],'candidate':[]}
try:
 for i in range(220):
  pairs=[('baseline',old),('candidate',new)]
  if i%2:pairs.reverse()
  for label,b in pairs:
   t=time.perf_counter_ns();b.preflight(program);dt=time.perf_counter_ns()-t
   if i>=20:samples[label].append(dt)
 result={'unit':'ns','samples':samples,'summary':{k:{'median':statistics.median(v),'p95':sorted(v)[189]} for k,v in samples.items()},'scope':'single private Xvfb; preflight only; no emitted input; warmup 20 and measured 200 per arm; alternated order; not model/task latency'}
 print(json.dumps(result))
finally:
 old.close();new.close()

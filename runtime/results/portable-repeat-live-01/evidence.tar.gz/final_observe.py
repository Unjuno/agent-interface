import json,subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parent
args=json.loads((root/'observe-command.json').read_text())
t0=time.monotonic_ns(); r=subprocess.run(args,cwd='/tmp',capture_output=True); t1=time.monotonic_ns()
(root/'final-observe.json').write_bytes(r.stdout)
(root/'final-observe-stderr.txt').write_bytes(r.stderr)
(root/'final-observe-call.json').write_text(json.dumps({'command':args,'returncode':r.returncode,'started_ns':t0,'returned_ns':t1}))
print(r.returncode)

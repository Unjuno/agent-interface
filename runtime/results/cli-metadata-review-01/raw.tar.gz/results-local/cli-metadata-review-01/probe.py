from pathlib import Path
import json,sys,subprocess,hashlib
archive,original,destination=sys.argv[1:];sys.path.insert(0,archive)
from runtime.cli_v1.review import present_result
from runtime.cli_v1.public_summary import summarize_cli_dispatch,SCHEMA
root=Path(original);out=Path(destination);raw=(root/'report.json').read_bytes();digest=hashlib.sha256(raw).hexdigest()
view=present_result(json.loads(raw),root,compact=True,report_refs=True)
summary=summarize_cli_dispatch(view,root)
if summary['receipt']['schema']!=SCHEMA:raise RuntimeError('summary fallback')
recipe=summary['presentation']['retrieve'];(out/'retrieval-recipe.json').write_text(json.dumps(recipe,indent=2)+'\n')
arguments=recipe['arguments'];args=[sys.executable,'-I',archive,recipe['command']]
for key,value in arguments.items():
 flag='--'+key.replace('_','-')
 if value is True:args.append(flag)
 elif value is not False:args.extend([flag,str(value)])
base=args[:];base.remove('--no-image')
commands=[]
def run(name,argv,input=None):
 result=subprocess.run(argv,input=input,cwd='/tmp',capture_output=True)
 (out/(name+'.stdout.json')).write_bytes(result.stdout);(out/(name+'.stderr.txt')).write_bytes(result.stderr)
 commands.append({'case':name,'arguments':argv,'exit_code':result.returncode,'stdout_bytes':len(result.stdout)})
 return result,json.loads(result.stdout)
full,a=run('included-file',base);omitted,b=run('omitted-file',args)
if full.returncode or omitted.returncode or b!=dict(a,image=None,image_delivery='omitted_by_request'):raise RuntimeError('file parity')
stdin=args[:];stdin[stdin.index('--report')+1]='-'
received,c=run('omitted-stdin',stdin,raw)
if received.returncode or c['receipt']['source']['sha256']!=digest or c['image_reference']!=b['image_reference'] or c['outcome_summary']!=b['outcome_summary']:raise RuntimeError('stdin parity')
changed=out/'changed-report.json';changed.write_bytes(raw+b' ');bad_args=args[:];bad_args[bad_args.index('--report')+1]=str(changed)
refused,d=run('changed-report',bad_args)
if refused.returncode!=2 or d['status']!='invalid_receipt':raise RuntimeError('digest refusal')
if (root/'report.json').read_bytes()!=raw:raise RuntimeError('original changed')
(out/'probe.json').write_text(json.dumps({'source_sha256':digest,'commands':commands,'recipe_executed':True,'default_image_preserved':True,'metadata_parity':True,'original_unchanged':True,'scope':'read-only retained CLI primary record, no live input/capture or model timing'},indent=2)+'\n')
print(json.dumps({'cases':commands,'stdout_bytes_removed':len(full.stdout)-len(omitted.stdout)}))

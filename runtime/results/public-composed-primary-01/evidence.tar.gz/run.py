import asyncio,base64,hashlib,json,os,subprocess,sys,time
from pathlib import Path
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
root=Path(__file__).resolve().parent;repo=root.parents[1]
def save(name,obj): (root/name).write_text(json.dumps(obj,indent=2)+'\n')
async def run():
 env=dict(os.environ,PYTHONPATH=str(repo),PYTHONDONTWRITEBYTECODE='1')
 log=(root/'owner.log').open('wb')
 owner=subprocess.Popen(['/usr/bin/python3',str(root/'owner.py')],cwd=repo,env=env,stdout=log,stderr=log)
 try:
  for _ in range(100):
   if (root/'targets.json').exists(): break
   if owner.poll() is not None: raise RuntimeError('owner stopped')
   await asyncio.sleep(.05)
  assert (root/'targets.json').exists()
  params=StdioServerParameters(command=sys.executable,cwd=str(repo),args=['-m','runtime.cli_v1.mcp_server','--targets',str(root/'targets.json'),'--output-directory',str(root/'calls'),'--display',':248'])
  with (root/'server.log').open('w') as err:
   async with stdio_client(params,errlog=err) as (reader,writer):
    async with ClientSession(reader,writer) as client:
     await client.initialize()
     request={'target':'fixture','frame':'window_client','region':[0,0,400,180]};save('observe-request.json',request)
     original=await client.call_tool('interface_observe',request);save('original.json',original.model_dump(mode='json'))
     metadata=json.loads(original.content[0].text);call_id=Path(metadata['call_directory']).name
     assert not original.isError and metadata['image_status']=='image'
     (root/'initial.png').write_bytes(base64.b64decode(next(b for b in original.content if b.type=='image').data))
     print('initial image ready',flush=True)
     for _ in range(1800):
      if (root/'decision.json').exists(): break
      await asyncio.sleep(.1)
     program=json.loads((root/'decision.json').read_text())
     program['authority']['expires_at_ns']=time.monotonic_ns()+10_000_000_000
     args={'program':program,'current_observation_seq':1,'current_binding_revision':0}
     save('dispatch-request.json',args)
     original=await client.call_tool('interface_dispatch',args);save('dispatch-reply.json',original.model_dump(mode='json'))
     metadata=json.loads(original.content[0].text);call_id=Path(metadata['call_directory']).name
     assert not original.isError and metadata['image_status']=='image'
     before={p.relative_to(root/'calls').as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'calls').rglob('*') if p.is_file()}
     retained=await client.call_tool('interface_results',{'call_id':call_id});save('retained.json',retained.model_dump(mode='json'))
     later=json.loads(retained.content[0].text)
     after={p.relative_to(root/'calls').as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'calls').rglob('*') if p.is_file()}
     first=next(b for b in original.content if b.type=='image');second=next(b for b in retained.content if b.type=='image')
     assert first.data==second.data and before==after and not retained.isError
     assert later['operation_invoked'] is False and later['outcome_summary']==metadata['outcome_summary']
     (root/'image.png').write_bytes(base64.b64decode(first.data))
     print('action image ready; awaiting primary read-only continuation decision',flush=True)
     for _ in range(1800):
      if (root/'observe-again').exists(): break
      await asyncio.sleep(.1)
     assert (root/'observe-again').exists(), 'no primary continuation decision'
     post=await client.call_tool('interface_observe',request)
     save('post-observe.json',post.model_dump(mode='json'))
     post_metadata=json.loads(post.content[0].text)
     assert not post.isError and post_metadata['image_status']=='image'
     (root/'post.png').write_bytes(base64.b64decode(next(b for b in post.content if b.type=='image').data))
     assert len(list((root/'calls').glob('*/request.json')))==3
     print('post image ready; awaiting primary review',flush=True)
     for _ in range(600):
      if (root/'review-complete').exists(): break
      await asyncio.sleep(.1)
     assert (root/'review-complete').exists(), 'no primary review'
     save('verification.json',{'same_image':True,'same_outcome':True,'retained_files_unchanged':True,'file_hashes':before,'image_sha256':hashlib.sha256(base64.b64decode(first.data)).hexdigest(),'observation_calls':2,'retrieval_calls':1,'input_dispatch_calls':1,'scope':'primary image-based decisions over SDK stdio; WSL functional use only; no registered-host or comparative performance claim'})
 finally:
  (root/'stop').touch()
  try: await asyncio.to_thread(owner.wait,10)
  except subprocess.TimeoutExpired:
   owner.terminate();await asyncio.to_thread(owner.wait,3)
  save('owner-exit.json',{'pid':owner.pid,'returncode':owner.returncode});log.close()
asyncio.run(run())

import hashlib,json,sys
from pathlib import Path
r=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent
def require(ok,why):
    if not ok: raise ValueError(why)
def read(p): return json.loads((r/p).read_text())
def digest(p): return hashlib.sha256((r/p).read_bytes()).hexdigest()
for p,h in read('RAW_MANIFEST.json')['files'].items(): require(digest(p)==h,'raw digest '+p)
source=read('source.json')['source']
require(source=='265649efd946337659ef1459073c7e2acad4a61d','candidate identity')
for name in ['relay_client.mjs','relay_host.mjs']:
    require(digest('windows-candidate/'+name)==digest('candidate-source/'+name),'Windows source identity')
require(read('build-manifest.json')['source_revision']==source,'archive source identity')
require(digest('runtime.pyz')==read('build-manifest.json')['sha256'],'runtime archive digest')
bundle=read('host-bundle/HOST_MANIFEST.json')
require(bundle['source_revision']==source,'bundle source identity')
for row in bundle['files']:
    require(digest('host-bundle/'+row['path'])==row['sha256'],'bundle digest')
    require(digest('candidate-source/'+row['path'])==row['sha256'],'committed host bytes')
for label,exitcode in [('red',1),('red2',1),('green',0),('node-full',0),('consumer',0),('native-final',0)]:
    require((r/(label+'.exit')).read_text().strip()==str(exitcode),'retained exit '+label)
require('pass 0' in (r/'red2.stdout').read_text() and 'fail 5' in (r/'red2.stdout').read_text(),'red regression denominator')
require('pass 5' in (r/'green.stdout').read_text() and 'fail 0' in (r/'green.stdout').read_text(),'green regression denominator')
require('pass 77' in (r/'node-full.stdout').read_text() and 'fail 0' in (r/'node-full.stdout').read_text(),'full Node checks')
native=read('native-final/result.json'); require(native['status']=='PASS','native status')
for suite,count in zip(native['suites'],[337,149]):
    require(suite['returncode']==0,'native suite return')
    for stream in suite['logs'].values(): require(digest('native-final/'+stream['file'])==stream['sha256'],'native log digest')
    require(f'Ran {count} tests' in (r/'native-final'/suite['logs']['stderr']['file']).read_text(),'native counts')
refused=read('windows-zero-capacity.json')
require(len(refused)==2 and all(x['code']=='EVIDENCE_CAPACITY' and x['availableBytes']=='0' and x['minimumEvidenceFreeBytes']==33554432 for x in refused),'Windows actual zero-space refusal')
prefix='bundle-consumer-evidence/'
preflight=read(prefix+'storage-preflight.json')
require(preflight['schema']=='agent-interface/evidence-storage-preflight-v1' and preflight['minimum_free_bytes']==33554432,'startup receipt')
require(int(preflight['available_bytes'])>=33554432 and preflight['child_started'] is False and preflight['capacity_reserved'] is False and preflight['future_writes_guaranteed'] is False,'bounded capacity receipt')
requests=[read(prefix+f'request-{i}.json') for i in [1,2,3]]
require([x['tool'] for x in requests]==['interface_guarded_observe','interface_guarded_observe','interface_close'],'inert consumer tool scope')
require(all(x['arguments']=={} for x in requests),'no-target helper arguments')
for i in [1,2,3]:
    reply=read(prefix+f'reply-{i}.json'); ack=read(prefix+f'text-acknowledgment-{i}.json')
    require(ack['reply_sha256']==digest(prefix+f'reply-{i}.json'),'original text attribution')
    require(reply['status']=='returned' and all(x['type']=='text' for x in reply['result']['content']),'inert original reply')
    require(json.loads(reply['result']['content'][0]['text'])['input_dispatched'] is False,'inert no input')
require(read(prefix+'exit.json')['code']==0,'consumer transport exit')
require(read(prefix+'consumer-result.json')['stopped'] is None,'consumer policy state')
print(json.dumps({'audit':'PASS_SCOPED_INTEGRATION_RETENTION','node_tests':77,'capacity_regressions':5,'protocol_tests':337,'harness_tests':149,'windows_zero_space_refusals':2,'inert_consumer_calls':3,'live_gui_comparison':False}))

import json,sys,time,subprocess,traceback,shutil
from pathlib import Path
r=Path('/var/tmp/agent-interface-integrated-main')
sys.path[:0]=[str(r),str(r/'research/live_control'),str(r/'research/observation_gating')]
from run_native_six_task_self_use_v1 import PrivateSession
import integrated_efficiency_runtime_v1 as integrated
out=r/'results-local/guarded-metadata-no-encode-01'/sys.argv[1];out.mkdir()
def save(n,v):(out/n).write_text(json.dumps(v,indent=2)+'\n')
s=fixture=None
try:
 s=PrivateSession();save('readiness.json',s.window_manager_readiness)
 goal,history,_=integrated.prepare(s,'chromium',992004,'/home/taka/.cache/ms-playwright/chromium-1208/chrome-linux64/chrome')
 fixture=integrated._ACTIVE[str(history)]
 wid=int(next(line.split()[0] for line in s.windows().splitlines() if 'about:blank' in line),16)
 save('targets.json',{'browser':wid});save('goal.json',goal)
 save('allocation.json',{'display':s.name,'window':wid,'route':sys.argv[1],'history':str(history),'screen':[s.d.screen().width_in_pixels,s.d.screen().height_in_pixels]})
 print(json.dumps({'ready':True,'display':s.name,'window':wid}),flush=True)
 end=time.monotonic()+1800
 while not (out/'finish.json').exists():
  if time.monotonic()>end:raise TimeoutError('primary allocation expired; no replay')
  save('evaluation-current.json',fixture.evaluate())
  time.sleep(.2)
except BaseException as e:save('failure.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
finally:
 if fixture:
  save('evaluation-at-close.json',fixture.evaluate())
  if fixture.history.exists():shutil.copyfile(fixture.history,out/'submission-history.jsonl')
  fixture.close()
 if s:s.close();save('cleanup.json',[{'pid':p.pid,'returncode':p.poll()} for p in s.procs])

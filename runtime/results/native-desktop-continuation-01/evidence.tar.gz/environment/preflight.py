"""Environment inventory only; imports do not start an allocation."""
import importlib
import json
import shutil
import subprocess
import sys

programs = ['Xvfb','openbox','wmctrl','libreoffice','inkscape']
found = {name: shutil.which(name) for name in programs}
assert all(found.values()), found
modules = ['PIL', 'Xlib', 'numpy', 'openpyxl']
for module in modules:
    importlib.import_module(module)
import run_native_calc_self_use_v1
print(json.dumps({'status':'PASS_IMPORT_AND_PROGRAM_INVENTORY',
                  'python':sys.version,'programs':found,'modules':modules,
                  'scope':'no app, private display, allocation or input started'}))

# Primary-use finding: consume the existing continuation

Both action responses retain action_status=completed and feedback_status=needs_review.
They also deliver image_status=image and continuation.status=source_available.
Stage 1 already provided next stage2/source5; stage2 already provided stage3/source10.
The primary unnecessarily read source-2.json and source-3.json through shell calls
to obtain those same identities. No new continuation API is required.

Local follow-up only adds discovery/documentation guidance to native_submit.
It preserves the feedback error, image validation, source comparisons and all
admission checks. No default wait, sensor, retry or input policy changes.
Next primary use should consume the returned continuation directly. Reduced
caller file reads are a mechanism hypothesis; the new wording has not been
tested in a matched live comparison and does not establish a time/token gain.

The earlier 72.653-second first-submit-to-finish span includes our unnecessary
inspection plus host/tool/presentation/deliberation gaps. It must not be used as
a clean baseline for attributing the entire gap to the interface or this wording.

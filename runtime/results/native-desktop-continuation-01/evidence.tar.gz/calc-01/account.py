import json
from pathlib import Path
root=Path(__file__).resolve().parent
def read(name):return json.loads((root/name).read_text(encoding='utf-8-sig'))
def releases(value):
    rows=[]
    if isinstance(value,dict):
        if isinstance(value.get('releases'),list):rows.extend(value['releases'])
        for v in value.values():rows.extend(releases(v))
    elif isinstance(value,list):
        for v in value:rows.extend(releases(v))
    return rows
actions=[]
for n in (1,2):
    value=read(f'action-{n}-metadata.json')
    found=releases(value)
    assert found and all(r.get('verified') is True and r.get('keys_down')==[] and r.get('buttons_down')==[] for r in found)
    actions.append(value['outcome_summary'])
assert read('action-4-metadata.json')['allocation']['status']=='terminal'
assert read('action-4-metadata.json')['allocation']['returncode']==0
assert read('action-3-metadata.json')['outcome_summary']['evaluation_success'] is True
times=[read(f'action-{n}-timing.json') for n in (1,2,3)]
span=(times[-1]['end_ns']-times[0]['start_ns'])/1e9
inside=sum(t['end_ns']-t['start_ns'] for t in times)/1e9
result={'status':'PASS_SAVED_CALC_TASK_WITH_FEEDBACK_REVIEW',
        'actions':actions,'saved_file':read('saved-file-check.json'),
        'input_actions':2,'finish_calls':1,'status_calls':1,
        'release_verified_for_both_inputs':True,'owner_exit_code':0,
        'container_exit_code':0,'container_exit_provenance':'observed docker inspect after client terminal',
        'client_span_first_submit_through_finish_s':span,'inside_three_sdk_calls_s':inside,
        'between_calls_s':span-inside,
        'limits':'SDK-mediated use, setup excluded; between calls combines tools/presentation/deliberation; no isolated model latency, matched baseline, tokens or general cleanup proof'}
(root/'RESULT.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))

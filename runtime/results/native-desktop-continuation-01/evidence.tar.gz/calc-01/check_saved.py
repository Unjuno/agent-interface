import hashlib
import json
from pathlib import Path
from openpyxl import load_workbook
root=Path('/evidence')
path=root/'allocation/run/sheet.xlsx'
book=load_workbook(path,data_only=True,read_only=True)
actual=[book.active['A1'].value,book.active['A2'].value]
book.close()
assert actual == [763,660],actual
result={'saved_cells':actual,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'scope':'read saved workbook after primary declaration; no GUI input'}
(root/'saved-file-check.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))

import asyncio
import base64
import json
import os
from pathlib import Path
import sys
import time
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

root = Path('/evidence')
def save(name, value):
    (root/name).write_text(json.dumps(value, indent=2))

async def main():
    params = StdioServerParameters(command=sys.executable, args=[
        '/workspace/research/live_control/native_mcp_v1.py',
        '--allocation-directory','/evidence/allocation','--app','inkscape',
        '--seed','991284','--max-stages','8','--text-gap-ms','2',
        '--harness-python','/usr/bin/python3'],env=dict(os.environ))
    with (root/'server.log').open('w') as log:
        async with stdio_client(params,errlog=log) as (reader,writer):
            async with ClientSession(reader,writer) as client:
                await client.initialize()
                save('tools.json',(await client.list_tools()).model_dump(mode='json'))
                async def call(label,name,args):
                    save(label+'-request.json',{'tool':name,'arguments':args})
                    started=time.monotonic_ns()
                    reply=await client.call_tool(name,args)
                    save(label+'-timing.json',{'start_ns':started,'end_ns':time.monotonic_ns()})
                    save(label+'-response.json',reply.model_dump(mode='json'))
                    for block in reply.content:
                        if block.type=='image':(root/(label+'.png')).write_bytes(base64.b64decode(block.data))
                        elif block.type=='text':save(label+'-metadata.json',json.loads(block.text))
                    print(label+' ready',flush=True)
                await call('initial','native_start',{'timeout':30})
                for n in range(1,16):
                    path=root/f'decision-{n}.json'
                    deadline=time.monotonic()+300
                    while not path.exists() and not (root/'finish').exists():
                        if time.monotonic()>deadline:raise TimeoutError('primary decision timeout')
                        await asyncio.sleep(.1)
                    if (root/'finish').exists():break
                    decision=json.loads(path.read_text())
                    await call(f'action-{n}',decision['tool'],decision['arguments'])
    print('client finished',flush=True)

asyncio.run(main())


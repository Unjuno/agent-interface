# Inkscape primary-use refusal retained

Fresh seed991284 allocation on Docker image44634c6599b9; source19909111c.
Primary viewed the initial red rectangle and requested one click plus three
Right keys, save and250ms wait. The native guard refused before admission:
region_pixels_missing / MISSING, input_dispatched=false. No action was replayed.
There was no returned image and continuation was unavailable, not_a_stage_boundary.
The first attempt to display action-1.png therefore failed; raw metadata was
then inspected and preserved. No image was fabricated or substituted as its reply.

The initial screenshot has the rectangle around x514..641; the retained
pre-admission observation2 has a Fill and Stroke sidebar and rectangle around
x310..417. These are visibly different layouts. The cause of the sidebar change
is not independently established. Do not attribute it to GTK pixel noise,
tool input, or external interference without evidence.

The existing setup predicate only requires a red target to be visible; it does
not promise the layout will stay fixed. The refusal is consistent with the
changed layout, not evidence that guards should be relaxed. No new sensor,
classifier or automatic retry is introduced.

Owner terminal exit1, cleanup routine completed with tracked processes terminal;
full descendants remain unverified. SDK client/container exited0 after reading
native_status and closing; that is not task success. No saved-goal evaluation
success was obtained. The allocation is consumed and will not be restarted.

Issue4489's retained GTK temporal-stability study was read as context. It is a
no-input fixture calibration, not an Inkscape readiness or application-effect
qualification, so it is not adopted as an authoritative fix. Next useful work
is an explicit observation/review boundary before input on a fresh allocation,
using the existing interface and a newly grounded primary decision. Retain this
failed run alongside any successor.

This memo was reconstructed after storage recovered. Its original write failed
when C: had zero free bytes; the raw responses, images and process evidence had
already been saved. This memo is not contemporaneous pre-run evidence.

# Ordered primary-use comparison

Same primary agent, seed991283, Docker image44634c6599b9, Calc25.2.3,
text gap2ms, two input decisions and explicit250ms waits. The successor uses
the existing continuation in each response, avoiding the prior two extra
source-file reads; it does not remove a native operation or MCP call.

Both runs saved A1=763/A2=660, verified both input releases, retained
feedback_status=needs_review, and ended owner/container0. The successor's
primary declaration precedes its independent saved-workbook readback.

First-submit through finish-return (setup/status/readback excluded):

| Run | Total s | Inside 3 SDK calls s | Between calls s |
| --- | ---: | ---: | ---: |
| 01 | 72.653278 | 1.813533 | 70.839745 |
| 02 | 74.639052 | 1.950276 | 72.688775 |

No speed benefit was observed: successor elapsed span was about1.99s longer.
The two ordered uses do not isolate the wording or file-read effect. Learning,
host latency, deliberation and tool orchestration are uncontrolled, with no
replication, randomization, human baseline or actual model-token accounting.
The mechanism result is reduced caller source-file inspection with preserved
task correctness, not reduced tool turns or faster task completion.

Retain the guidance for usability, but do not promote it as a tempo improvement.
Further runtime micro-tuning is not justified by these outer intervals alone.

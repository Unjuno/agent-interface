import hashlib,json,base64
from pathlib import Path
from PIL import Image,ImageChops
def need(ok,why):
 if not ok:raise ValueError(why)
def load(p):return json.loads(p.read_text())
def meta(r):return json.loads(next(b['text'] for b in r['result']['content'] if b['type']=='text'))
def analyze(root):
 plan=load(root/'PLAN.json')
 for name,digest in plan['hashes'].items():need(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,'source '+name)
 host=root/'direct-post/host';session=root/'direct-post/session'
 alloc=load(session/'allocation.json');need(alloc['source']==plan['source'] and alloc['seed']==plan['seed'],'allocation')
 reply=load(host/'reply-6.json');m=meta(reply);e=m['receipt']['execution_summary']
 need(m['outcome_summary']['execution_status']=='completed' and e['program_emissions']==8 and e['completed_operation_count']==26,'execution')
 req=load(host/'request-6.json');program=req['arguments']['program'];need(program==load(root/'invoked-program.json'),'invocation identity')
 ops=load(root/'controlled-ops.json');need(program['ops']==[{'op':'focus','target':'browser'},*ops,{'op':'release_all'}],'only declared moves/waits/captures')
 observations=e['observations'];need([o['operation_index'] for o in observations]==list(range(3,25,3)),'capture operation mapping')
 need(all(r['verified'] is True and r['keys_down']==r['buttons_down']==[] for r in e['releases']),'neutral release')
 rows=[];imgs=[]
 for i,o in enumerate(observations):
  name=Path(o['artifact']['path']).name;path=session/'server'/m['call_id']/'images'/name;data=path.read_bytes()
  need(hashlib.sha256(data).hexdigest()==o['artifact']['sha256'],'actual PNG')
  image=Image.open(path).convert('RGB');need(image.size==(1280,800) and o['native_window_id']==6291459 and o['target']=='browser','target dimensions')
  crop=image.crop((364,394,388,408));digest=hashlib.sha256(crop.tobytes()).hexdigest();imgs.append(image)
  rows.append({'index':i,'state':'off' if i%2==0 else 'on','operation_index':o['operation_index'],'native_png':name,'native_png_sha256':o['artifact']['sha256'],'guard_crop_sha256':digest,'capture_ns':o['capture_started_ns']})
 off={r['guard_crop_sha256'] for r in rows[::2]};on={r['guard_crop_sha256'] for r in rows[1::2]}
 scoped=len(off)==len(on)==1 and off!=on
 score=load(session/'evaluation-at-close.json');need(score['record_count']==0 and score['success'] is False and len(score['missing'])==6 and not score['duplicates'] and not score['unexpected'],'zero submissions')
 need(load(host/'exit.json')['code']==0 and load(root/'terminal.json')['exit_code']==0,'terminal')
 events=[json.loads(l) for l in (host/'host-events.jsonl').read_text().splitlines()]
 expected=['interface_observe','interface_clock','interface_dispatch','interface_validate','interface_clock','interface_dispatch','interface_close']
 for a,tool in enumerate(expected,1):
  q=load(host/f'request-{a}.json');r=load(host/f'reply-{a}.json');need(q['tool']==r['tool']==tool and q['id']==r['id']==a,'call schedule')
  digest=hashlib.sha256((host/f'reply-{a}.json').read_bytes()).hexdigest();ev=[v for v in events if v.get('attempt')==a]
  need([v['kind'] for v in ev][:4]==['send_requested','reply_available','presentation_started','presentation_callbacks_completed'] and all(v.get('reply_sha256',digest)==digest for v in ev),'presentation identity/order')
 close=meta(load(host/'reply-7.json'));need(close['status']=='closed' and close['release']['verified'] is True and close['release']['keys_down']==close['release']['buttons_down']==[],'close')
 delivered=base64.b64decode(next(b['data'] for b in reply['result']['content'] if b['type']=='image'),validate=True);need(hashlib.sha256(delivered).hexdigest()==rows[-1]['native_png_sha256'],'selected capture identity')
 review=load(host/'review-6.json');need(review['reply_sha256']==hashlib.sha256((host/'reply-6.json').read_bytes()).hexdigest() and review['images'][0]['sha256']==rows[-1]['native_png_sha256'],'primary image review')
 return {'status':'PASS_SCOPED_POINTER_STATE_PIXEL_CHANGE' if scoped else 'HOLD_PIXEL_STATES_NOT_REPRODUCIBLE','source':plan['source'],'seed':plan['seed'],'rows':rows,'off_crop_hashes':sorted(off),'on_crop_hashes':sorted(on),'pair_diff_bboxes':[ImageChops.difference(imgs[i],imgs[i+1]).getbbox() for i in range(0,8,2)],'independent_submissions':0,'public_calls':7,'controlled_moves':8,'fixed_wait_ms':800,'local_execution_ms':(e['ended_ns']-e['started_ns'])/1e6,'fixture_exit':0,'relay_exit':0,'cleanup':load(session/'cleanup.json'),'integration_gate':'HOLD_INTEGRATION_INCOMPLETE','scope':'Four off/on cycles in one unchanged Chromium button. Supports pointer-induced rendering diagnosis; not changed-target acceptance, safe mask, automatic recovery, latency benefit or six-task pass.'}
if __name__=='__main__':
 import sys
 result=analyze(Path(sys.argv[1]))
 if len(sys.argv)>2:
  with Path(sys.argv[2]).open('x') as f:json.dump(result,f,indent=2)
 print(json.dumps(result,indent=2))

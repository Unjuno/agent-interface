export async function open(ctx,route){
const root=ctx.root+'/'+route;
const allocation=JSON.parse(await ctx.fs.readFile(root+'/session/allocation.json','utf8'));
const goal=JSON.parse(await ctx.fs.readFile(root+'/session/goal.json','utf8'));
if(allocation.source!==ctx.source||allocation.seed!==ctx.seed)throw Error('allocation drift');
const directory=ctx.parent+'/pointer-hover-contract-01-'+route+'-host';
const run={route,root,allocation,goal,directory};ctx[route]=run;
const factory=(await import(ctx.url.pathToFileURL(ctx.root+'/host-bundle/relay_host.mjs').href)).createInstrumentedRelayClient;
run.host=await factory({command:'wsl.exe',args:['-d','Ubuntu','-u','taka','--exec','/tmp/agent-interface-mcp-venv/bin/python',ctx.linux+'/runtime.pyz','relay','--','--targets',ctx.linux+'/'+route+'/session/targets.json','--output-directory',ctx.linux+'/'+route+'/session/server','--session-mode',route==='guarded-local'?'guarded-x11':'persistent-x11','--display',allocation.display],evidenceDirectory:directory,reuseReviewedImages:false});
run.caller=(await import(ctx.url.pathToFileURL(ctx.root+'/caller-v2.mjs').href)).createCaller(run.host,goal,directory,ctx.sinks,route);
return run;
}
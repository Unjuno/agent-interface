export async function open(ctx,sinks){
 const root=ctx.root+'/guarded-local/session';
 const allocation=JSON.parse(await ctx.fs.readFile(root+'/allocation.json','utf8'));
 const goal=JSON.parse(await ctx.fs.readFile(root+'/goal.json','utf8'));
 if(allocation.source!==ctx.source||allocation.seed!==ctx.seed)throw Error('allocation drift');
 const directory=ctx.parent+'/guarded-pointer-move-03-host';
 const factory=(await import(ctx.url.pathToFileURL(ctx.root+'/host-bundle/relay_host.mjs').href)).createInstrumentedRelayClient;
 const host=await factory({command:'wsl.exe',args:['-d','Ubuntu','-u','taka','--exec','/tmp/agent-interface-mcp-venv/bin/python',ctx.linux+'/runtime.pyz','relay','--','--targets',ctx.linux+'/guarded-local/session/targets.json','--output-directory',ctx.linux+'/guarded-local/session/server','--session-mode','guarded-x11','--display',allocation.display],evidenceDirectory:directory,reuseReviewedImages:false});
 return {host,goal,allocation,directory,call:async(tool,args)=>{const r=await host.sendPresented(tool,args,sinks);if(r.result.isError){const error=Error('tool error '+tool);error.reply=r;throw error;}return r;}};
}
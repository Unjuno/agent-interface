import hashlib,json,pathlib,tarfile,sys
repo=pathlib.Path('/var/tmp/agent-interface-integrated-main')
root=repo/'results-local/guarded-pointer-move-publication'
out=repo/'runtime/results/guarded-pointer-move-01'
sys.path.insert(0,str(out))
from analyze import analyze
result=analyze(root)
(out/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
files=sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
with tarfile.open(out/'raw.tar.gz','x:gz') as tf:
 for p in files:tf.add(p,arcname=str(p.relative_to(root)),recursive=False)
manifest={'archive_sha256':hashlib.sha256((out/'raw.tar.gz').read_bytes()).hexdigest(),'members':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'members':len(files),'bytes':(out/'raw.tar.gz').stat().st_size}))

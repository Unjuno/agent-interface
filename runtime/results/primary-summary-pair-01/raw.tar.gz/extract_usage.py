import pathlib,json,hashlib
p=pathlib.Path(__file__).resolve().parent
log=pathlib.Path('/mnt/c/Users/junny/.codex/sessions/2026/09/12/rollout-2026-09-12T23-46-37-01a09615-a96c-7b70-8284-e6391b885be5.jsonl')
size=log.stat().st_size;offset=max(0,size-32*1024*1024)
context=None;pending={};selected=[];contexts=[];recent_usage=None
with log.open('rb') as f:
 f.seek(offset)
 if offset:f.readline()
 for line in f:
  try:r=json.loads(line)
  except (ValueError,UnicodeError):continue
  payload=r.get('payload',{})
  if r.get('type')=='turn_context':context={k:payload.get(k) for k in ['model','effort','turn_id']};contexts.append(context)
  if r.get('type')=='response_item' and payload.get('type')=='custom_tool_call':
   code=payload.get('input','')
   # Include only prior live pair creation/action/review calls, exclude analysis/setup code writes.
   if 'tools.mcp__node_repl__js' in code and 'summaryPair' in code and not any(x in code for x in ['writeFile','analyze.py','extract_usage.py','readFile','readdir','typeof','Object.keys','fs.cp']):
    route='summary' if 'summaryPair.summary' in code or "start('summary')" in code else 'full' if 'summaryPair.full' in code or "start('full')" in code else 'setup_or_shared'
    phase='finish' if 'finish(' in code else 'save' if '.save(' in code else 'entry' if '.enter(' in code else 'navigation' if '.navigate(' in code else 'review' if '.review(' in code else 'initial_or_setup'
    row={'call_id':payload['call_id'],'timestamp':r.get('timestamp'),'input_sha256':hashlib.sha256(code.encode()).hexdigest(),'local_context':context,'route':route,'phase':phase,'usage_records_before_output':[]}
    selected.append(row);pending[payload['call_id']]=row
  if r.get('type')=='token_usage_record':
   usage={'ordinal':r.get('ordinal'),'timestamp':r.get('timestamp'),'response_id':payload.get('response_id'),'usage':payload.get('usage')}
   for row in pending.values():row['usage_records_before_output'].append(usage)
   # first subsequent usage record after output, useful as chronology, not isolated ingestion charge
   for row in selected:
    if 'output_timestamp' in row and 'first_usage_after_output' not in row:row['first_usage_after_output']=usage
  if r.get('type')=='response_item' and payload.get('type')=='custom_tool_call_output' and payload.get('call_id') in pending:
   pending.pop(payload['call_id'])['output_timestamp']=r.get('timestamp')
record={'schema':'agent-interface/primary-usage-projection-v1','source':'Local Codex usage records, bounded 32MiB tail; private conversation excluded.','scan_bytes':size-offset,'context_observed_in_tail':bool(contexts),'association':'Call-id matches request/output. Usage ordinals between them are chronological association, not a provider-attested foreign key. Before-output usage authors the request, cannot include its new result. First later usage may include the result in whole context; not isolated image/receipt/SDK cost.','limits':['Fixed order full then summary; earlier full results remain in later context. Cache and context growth confound any arm token comparison.','Usage includes full primary conversation, model output and reasoning; counters do not measure only this interface.','Local context may be missing before first turn_context in the bounded tail; missing context stays null.','No actual dollar billing record available.'],'dollars':None,'calls':selected}
(p/'model-usage-projection.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'selected':len(selected),'contexts':list({json.dumps(x['local_context'],sort_keys=True) for x in selected}),'usage_records_per_call':sorted(set(len(x['usage_records_before_output']) for x in selected)),'routes':[x['route'] for x in selected],'usage_keys':list(next((u['usage'] for x in selected for u in x['usage_records_before_output']),{}))}))

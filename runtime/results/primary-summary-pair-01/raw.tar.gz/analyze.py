import json,sys,hashlib,base64,copy,re
from pathlib import Path
p=Path(__file__).resolve().parent
repo=p.parents[1];sys.path.insert(0,str(repo))
from runtime.cli_v1.review import present_result
from runtime.cli_v1.public_summary import summarize_public_dispatch
def need(v,m):
 if not v:raise ValueError(m)
def load(x):return json.loads(x.read_text())
def rows(x):return [json.loads(s) for s in x.read_text().splitlines()]
def meta(reply):return json.loads(next(c['text'] for c in reply['result']['content'] if c['type']=='text'))
def wire(v):return json.dumps(v,allow_nan=False).encode()
arms={}
for route in ['full','summary']:
 root=p/route;host=root/'host';session=root/'session';events=rows(host/'host-events.jsonl')
 history=rows(session/'submission-history.jsonl');ev=load(session/'evaluation-at-close.json')
 need(len(history)==1 and history[0]['exact'] and history[0]['task_id']=='task-4' and history[0]['submitted_values']==['t1001035-4'],'exact once')
 need(ev['success'] is False and ev['exact_counts']['task-4']==1,'six-task aggregate not claimed')
 need(load(host/'exit.json')['code']==0,'transport close')
 calls=[];programs=[]
 for i in range(1,12):
  q=load(host/f'request-{i}.json');reply=load(host/f'reply-{i}.json');v=meta(reply)
  need(reply['status']=='returned' and not reply['result']['isError'],'normal reply')
  es=[e for e in events if e.get('attempt')==i]
  times={e['kind']:e['host_monotonic_ms'] for e in es}
  entry={'attempt':i,'tool':q['tool'],'text_bytes':sum(len(c['text'].encode()) for c in reply['result']['content'] if c['type']=='text'),'host_send_to_reply_ms':times['reply_available']-times['send_requested']}
  if 'presentation_completed' in times:entry['host_send_to_presentation_ms']=times['presentation_completed']-times['send_requested']
  if 'review_recorded' in times:entry['host_send_to_review_record_ms']=times['review_recorded']-times['send_requested']
  imgs=[base64.b64decode(c['data']) for c in reply['result']['content'] if c['type']=='image'];entry['image_bytes']=[len(b) for b in imgs];entry['image_sha256']=[hashlib.sha256(b).hexdigest() for b in imgs]
  if q['tool']=='interface_dispatch':
   rawroot=Path(v['call_directory']);report=load(rawroot/'report.json');raw=report['result']
   if raw['status']=='completed':
    need(i in [4,6,8],'three input programs');need(bool(raw['execution']['releases']) and all(x['verified'] and x['keys_down']==[] and x['buttons_down']==[] for x in raw['execution']['releases']),'neutral release')
    full=present_result(report,rawroot,compact=True,report_refs=True);full.pop('image',None);full.update(session=report['session'],call_directory=str(rawroot),call_id=v['call_id'])
    summary=summarize_public_dispatch(full)
    need(summary['receipt']['schema']=='agent-interface/receipt-view-dispatch-summary-v1','eligible')
    need(v==(full if route=='full' else summary),'exact delivered rendering')
    need(full['image_reference']==summary['image_reference'] and full['outcome_summary']==summary['outcome_summary'] and full['session']==summary['session'],'kept decision records')
    for c,b in zip(reply['result']['content'][1:],imgs):need(hashlib.sha256(b).hexdigest()==v['image_reference']['sha256'],'exact image')
    entry.update(full_text_bytes=len(wire(full)),summary_text_bytes=len(wire(summary)),requested_wait_ms=sum(w['requested_ms'] for w in raw['execution']['waits']),runtime_execution_ms=(raw['execution']['ended_ns']-raw['execution']['started_ns'])/1e6,capture_end_after_execution_start_ms=(raw['execution']['observations'][-1]['capture_ended_ns']-raw['execution']['started_ns'])/1e6,call_id=v['call_id'],receipt_schema=v['receipt']['schema'])
    author=load(root/f'author-clock-{len(programs)+1}.json');entry['clock_authoring_ms']=author['duration_ms']
    review=load(host/f'review-{i}.json');need(review['images'][0]['sha256']==entry['image_sha256'][0],'declared review exact capture')
    program=copy.deepcopy(q['arguments']);program['program'].pop('program_id');program['program']['authority'].pop('expires_at_ns');program.pop('detail')
    for op in program['program']['ops']:
     if op.get('op')=='text':op['text']=re.sub(r'127\.0\.0\.1:\d+','127.0.0.1:PORT',op['text'])
    programs.append(program)
   else:
    need(i==10 and raw['status']=='refused' and raw['error']=='LEASE_EXPIRED' and raw['backend_emissions']==98 and 'execution' not in raw,'expired no added input')
    need(v['receipt']['schema']=='agent-interface/receipt-view-v3-report-ref','failure full')
  if q['tool']=='interface_close':need(v['status']=='closed' and v['release']['verified'],'explicit close')
  calls.append(entry)
 need(len(programs)==3,'input program count')
 arms[route]={'calls':calls,'programs':programs,'exact_task4_once':True,'six_task_aggregate_success':ev['success'],'child_returncodes':[x['returncode'] for x in load(session/'cleanup.json')],'transport_exit':load(host/'exit.json'),'no_results_calls':all(x['tool']!='interface_results' for x in calls)}
need(arms['full']['programs']==arms['summary']['programs'],'same operation arguments except per-allocation identity/deadline/presentation')
for arm in arms.values():arm.pop('programs')
out={'schema':'agent-interface/primary-summary-pair-analysis-v1','source_revision':'8ee4ff891a54827b3df3df297cdb849e2aea428e','task':'task-4','seed':1001035,'fixed_order':['full','summary'],'presentation_difference':'detail only; compact=true, report_refs=true for both','arms':arms,'limits':['One known-family task, fixed order, growing primary context/cache, not a causal speed/token trial.','Host presentation/review timestamps are instrumentation/caller declarations, not model-only perception latency.','All six tasks were allocated but only task-4 was requested; aggregate success remains false.','Child cleanup return codes retained as returned, not all zero.']}
(p/'analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:{'dispatch_text_bytes':[c['text_bytes'] for c in v['calls'] if c['attempt'] in [4,6,8]],'same_report_full_total':sum(c.get('full_text_bytes',0) for c in v['calls']),'same_report_summary_total':sum(c.get('summary_text_bytes',0) for c in v['calls']),'child_returncodes':v['child_returncodes']} for k,v in arms.items()}))

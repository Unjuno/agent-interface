import asyncio, base64, hashlib, json, os, signal, socket, subprocess, sys, time
from pathlib import Path
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

root = Path(__file__).resolve().parent
archive = root / 'runtime.pyz'
display = ':249'
def save(name, value):
    (root / name).write_text(json.dumps(value, indent=2), encoding='utf-8')

async def main():
    (root / 'started').open('x').close()
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == 'c1ce9980224abe07c7186e42768027cb8801554799cf20661744a6e6a331352b'
    assert Path('/usr/lib/libreoffice/program/soffice.bin').is_file()
    assert not Path('/tmp/.X249-lock').exists(), 'occupied display'
    for address in ('/tmp/.X11-unix/X249', '\0/tmp/.X11-unix/X249'):
        with socket.socket(socket.AF_UNIX) as probe:
            try: probe.connect(address)
            except OSError: pass
            else: raise RuntimeError('occupied display')
    private = Path('/tmp/agent-interface-main-compact-calc-01')
    private.mkdir(exist_ok=False)
    env = dict(os.environ, DISPLAY=display, GDK_BACKEND='x11', SAL_USE_VCLPLUGIN='gen',
               HOME=str(private), XDG_CONFIG_HOME=str(private/'config'),
               XDG_CACHE_HOME=str(private/'cache'), XDG_DATA_HOME=str(private/'data'),
               LANG='C.UTF-8', PYTHONDONTWRITEBYTECODE='1')
    for key in ('WAYLAND_DISPLAY', 'DBUS_SESSION_BUS_ADDRESS', 'PYTHONPATH'):
        env.pop(key, None)
    document = root / 'invoice.fods'
    document.write_text('''<?xml version="1.0" encoding="UTF-8"?>
<office:document xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0"
 xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0"
 office:version="1.2" office:mimetype="application/vnd.oasis.opendocument.spreadsheet">
 <office:body><office:spreadsheet><table:table table:name="Invoice">
 <table:table-row><table:table-cell/></table:table-row>
 </table:table></office:spreadsheet></office:body></office:document>''', encoding='utf-8')
    (root/'initial.fods').write_bytes(document.read_bytes())
    save('task.json', {'task':'Enter Quantity, Unit price, Total in A1:C1; 8 and 17 in A2:B2; formula =B2*A2 in C2; save. Expected total 136.',
        'source_revision':'b732fa5c3d4c828ea50f81c36522a61e7803e473',
        'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
        'scope':'Primary model uses retained screenshots through view_image, public portable MCP through SDK. No direct registered-host route or performance comparison.'})
    children = []; conn = None
    with (root/'process.log').open('w') as log:
        try:
            def launch(args):
                p = subprocess.Popen(args, env=env, stdout=log, stderr=log, start_new_session=True)
                children.append(p); return p
            launch(['Xvfb',display,'-screen','0','1024x768x24','-nolisten','tcp','-nolisten','unix'])
            from Xlib.display import Display
            for _ in range(100):
                try: conn=Display(display); break
                except Exception: await asyncio.sleep(.05)
            assert conn, 'display unavailable'
            launch(['openbox'])
            app=launch(['libreoffice',
                '-env:UserInstallation='+ (private/'profile').as_uri(),
                '--norestore','--nofirststartwizard','--calc',str(document)])
            inventory=[]
            def find(window):
                try:
                    title=window.get_wm_name() or ''
                    if isinstance(title,bytes): title=title.decode('utf-8','replace')
                    net=window.get_full_property(conn.intern_atom('_NET_WM_NAME'),0)
                    if net is not None and isinstance(net.value,bytes):title=net.value.decode('utf-8','replace')
                    if title:inventory.append({'id':window.id,'title':title,'mapped':window.get_attributes().map_state})
                    if 'invoice' in title.lower() and 'LibreOffice' in title and window.get_attributes().map_state==2:
                        return window
                    for child in window.query_tree().children:
                        found=find(child)
                        if found:return found
                except Exception: pass
            target=None
            for _ in range(900):
                assert app.poll() is None, 'application exited'
                target=find(conn.screen().root)
                if target:break
                await asyncio.sleep(.05)
            save('window-inventory.json',inventory)
            if not target:
                from PIL import Image
                from Xlib import X
                capture=conn.screen().root.get_image(0,0,1024,768,X.ZPixmap,0xffffffff)
                Image.frombytes('RGB',(1024,768),capture.data,'raw','BGRX').save(root/'setup-failure.png')
            assert target, 'no task window found; diagnostic retained'
            geo=target.get_geometry()
            save('targets.json',{'calc':target.id})
            save('allocation.json',{'pids':[p.pid for p in children], 'target':target.id,
                'display':display,'width':geo.width,'height':geo.height})
            params=StdioServerParameters(command=sys.executable,cwd='/tmp',env=env,
                args=[str(archive),'mcp','--targets',str(root/'targets.json'),
                      '--output-directory',str(root/'calls'),'--display',display])
            with (root/'server.log').open('w') as err:
                async with stdio_client(params,errlog=err) as (reader,writer):
                    async with ClientSession(reader,writer) as client:
                        await client.initialize()
                        save('tools.json',(await client.list_tools()).model_dump(mode='json'))
                        async def call(name,args,label):
                            args=dict(args,compact=True,report_refs=True)
                            started_ns=time.monotonic_ns()
                            save(label+'-request.json',{'tool':name,'arguments':args})
                            result=await client.call_tool(name,args)
                            save(label+'-reply.json',result.model_dump(mode='json'))
                            save(label+'-timing.json',{'call_start_ns':started_ns,'reply_received_ns':time.monotonic_ns(),'scope':'SDK roundtrip, not model-useful feedback'})
                            for block in result.content:
                                if block.type=='text':save(label+'-metadata.json',json.loads(block.text))
                            for b in result.content:
                                if b.type=='image': (root/(label+'.png')).write_bytes(base64.b64decode(b.data))
                            print(label+' ready',flush=True)
                        observe={'target':'calc','frame':'screen_physical_px','region':[0,0,1024,768]}
                        await call('interface_observe',observe,'initial')
                        for stage in range(1,7):
                            path=root/f'decision-{stage}.json'
                            for _ in range(3000):
                                if path.exists() or (root/'finish').exists():break
                                await asyncio.sleep(.1)
                            if (root/'finish').exists():break
                            assert path.exists(), 'primary decision deadline'
                            decision=json.loads(path.read_text())
                            if decision['tool']=='interface_dispatch':
                                # Explicit lease lifetime for this private test, after each primary decision.
                                decision['arguments']['program']['authority']['expires_at_ns']=time.monotonic_ns()+10_000_000_000
                            await call(decision['tool'],decision['arguments'],f'action-{stage}')
        finally:
            if conn:conn.close()
            rows=[]
            for p in reversed(children):
                members=[]
                for candidate in Path('/proc').iterdir():
                    if not candidate.name.isdigit():continue
                    try:
                        pid=int(candidate.name)
                        if os.getpgid(pid)==p.pid:
                            members.append({'pid':pid,'stat':(candidate/'stat').read_text()})
                    except (OSError,ProcessLookupError):pass
                if p.poll() is None:
                    assert os.getpgid(p.pid)==p.pid
                    os.killpg(p.pid,signal.SIGTERM)
                try:p.wait(timeout=5)
                except subprocess.TimeoutExpired:p.kill();p.wait(timeout=3)
                await asyncio.sleep(.1)
                rows.append({'pid':p.pid,'returncode':p.returncode,'group_members_before':members,
                             'remaining_member_paths':[m['pid'] for m in members if Path('/proc',str(m['pid'])).exists()]})
            save('cleanup.json',{'tracked_processes':rows,'descendants_verified':False})
    print('owner finished',flush=True)

asyncio.run(main())

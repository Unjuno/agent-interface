import json,sys
from pathlib import Path
from native_exchange_v1 import run
root=Path('/tmp/agent-interface-native-linux-991202')
stage=int(sys.argv[1]); decision=json.loads((Path(__file__).parent/f'decision-{stage}.json').read_bytes())
result=run(root/'run',stage,decision,timeout=5,compact=True)
with (root/f'response-{stage}.json').open('x') as f: json.dump(result,f)
print(json.dumps(result))

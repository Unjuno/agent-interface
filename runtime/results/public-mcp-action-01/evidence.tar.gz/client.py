import asyncio,json,sys,time
from pathlib import Path
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
root=Path(__file__).resolve().parent
async def main():
 params=StdioServerParameters(command=sys.executable,args=['-m','runtime.cli_v1.mcp_server','--targets',str(root/'targets.json'),'--output-directory',str(root/'calls'),'--display',':248'])
 with (root/'server-stderr.txt').open('w') as err:
  async with stdio_client(params,errlog=err) as (reader,writer):
   async with ClientSession(reader,writer) as client:
    init=await client.initialize(); (root/'initialize.json').write_text(init.model_dump_json())
    async def call(name,args,label):
     (root/(label+'-request.json')).write_text(json.dumps({'tool':name,'arguments':args}))
     start=time.monotonic_ns(); result=await client.call_tool(name,args); end=time.monotonic_ns()
     (root/(label+'-reply.json')).write_text(result.model_dump_json())
     (root/(label+'-clock.json')).write_text(json.dumps({'started_ns':start,'returned_ns':end}))
     print(label,flush=True)
    await call('interface_observe',{'target':'fixture','frame':'window_client','region':[0,0,400,180]},'initial')
    deadline=time.monotonic()+180
    while not (root/'decision.json').exists():
     if time.monotonic()>deadline: raise TimeoutError('no primary decision')
     await asyncio.sleep(.1)
    program=json.loads((root/'decision.json').read_text())
    program['authority']['expires_at_ns']=time.monotonic_ns()+10_000_000_000
    await call('interface_dispatch',{'program':program,'current_observation_seq':1,'current_binding_revision':0},'dispatch')
asyncio.run(main())

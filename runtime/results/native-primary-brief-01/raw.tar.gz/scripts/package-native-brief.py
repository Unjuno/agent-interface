import hashlib,json,tarfile,subprocess
from pathlib import Path
root=Path.cwd(); out=root/'runtime/results/native-primary-brief-01';out.mkdir(exist_ok=False)
c=root/'results-local/native-primary-brief-01'
t=[json.loads(x) for x in (c/'timing.jsonl').read_text().splitlines()]
rows=[];images=0;errors=0
for i in range(1,len(t)+1):
    r=json.loads((c/f'transport/reply-{i}.json').read_text())['result']
    images+=sum(b['type']=='image' for b in r['content']); errors+=bool(r.get('isError'))
    if not r.get('isError'):
        v=json.loads(r['content'][0]['text'])
        rows.append({'call':i,'presentation':v.get('presentation'), 'outcome':v.get('outcome_summary')})
finish=next(n for n,row in enumerate(t) if row['args'].get('decision',{}).get('finish'))
summary={'mcp_calls':len(t),'image_blocks':images,'schema_errors':errors,'input_programs':5,'explicit_observations':2,
 'brief_responses':sum(r['presentation'] is not None and r['presentation']['returned']=='brief' for r in rows),
 'first_send_to_finish_callback_ms':t[finish]['delivered']-t[0]['start'],
 'sum_send_to_callback_through_finish_ms':sum(r['delivered']-r['start'] for r in t[:finish+1]),
 'scope':'host send/presentation callbacks, not render onset, pure inference, or matched performance comparison',
 'actual_model_tokens':None,'rows':rows}
(c/'SUMMARY.json').write_text(json.dumps(summary,indent=2))
files={}
for folder in ('native-primary-brief-01','native-primary-brief-01-allocation','native-brief-stdio-01','native-brief-retained-01','native-brief-retained-02','native-brief-check-01','native-brief-check-02'):
    for p in sorted((root/'results-local'/folder).rglob('*')):
        if p.is_file():files[folder+'/'+p.relative_to(root/'results-local'/folder).as_posix()]=p
for name in ('check-native-brief.py','check-native-brief-02.py','verify-native-brief-stdio.py','package-native-brief.py'):
    files['scripts/'+name]=root/'results-local'/name
source={'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'files':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ('research/live_control/native_brief_review_v1.py','research/live_control/native_mcp_v1.py','research/live_control/native_relay_client_v1.mjs')}}
p=root/'results-local/native-brief-source.json';p.write_text(json.dumps(source,indent=2));files['SOURCE.json']=p
with tarfile.open(out/'raw.tar.gz','w:gz') as archive:
    for n,p in sorted(files.items()):archive.add(p,arcname=n,recursive=False)
(out/'manifest.json').write_text(json.dumps({n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in sorted(files.items())},indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='rows'},indent=2));print('files',len(files))

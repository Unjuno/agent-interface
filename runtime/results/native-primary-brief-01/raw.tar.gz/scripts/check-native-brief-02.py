import hashlib,json
from pathlib import Path
from native_brief_review_v1 import brief_native_review
root=Path('results-local/native-primary-twoapp-client-01/transport')
out=Path('results-local/native-brief-retained-02');out.mkdir(exist_ok=False)
rows=[]
for i in range(1,12):
    path=root/f'reply-{i}.json';raw=path.read_bytes();response=json.loads(raw)
    view=json.loads(response['result']['content'][0]['text'])
    supported=response['tool'] in ('native_submit','native_resume')
    brief=brief_native_review(view) if supported else view
    (out/f'projection-{i}.json').write_text(json.dumps(brief,ensure_ascii=False,indent=2))
    size=lambda v:len(json.dumps(v,ensure_ascii=True,separators=(',',':')).encode())
    for key in ('outcome_summary','image_status','image_reference','continuation','allocation','window_inventory','session_context'):
        if brief.get(key)!=view.get(key):raise ValueError(key)
    if path.read_bytes()!=raw:raise ValueError('source changed')
    rows.append({'call':i,'full_bytes':size(view),'requested_brief_bytes':size(brief),'returned':brief.get('presentation',{}).get('returned','unchanged'),'source_sha256':hashlib.sha256(raw).hexdigest()})
(out/'RESULT.json').write_text(json.dumps({'rows':rows,'full_bytes':sum(r['full_bytes'] for r in rows),'brief_bytes':sum(r['requested_brief_bytes'] for r in rows),'scope':'serialized metadata bytes only; images unchanged; no model token measurement'},indent=2))
print((out/'RESULT.json').read_text())
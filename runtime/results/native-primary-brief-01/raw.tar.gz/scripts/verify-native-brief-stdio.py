import asyncio, hashlib, json, os, sys
from pathlib import Path
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

async def main():
    run = Path('results-local/native-primary-twoapp-client-01-allocation/run').resolve()
    out = Path('results-local/native-brief-stdio-01')
    out.mkdir(exist_ok=False)
    files = {p: (p.read_bytes(), p.stat().st_mtime_ns) for p in run.glob('request-*.json')}
    rows = []
    params = StdioServerParameters(command=sys.executable, args=[
        'research/live_control/native_mcp_v1.py', '--run-directory', str(run)], env=dict(os.environ))
    async with stdio_client(params) as (reader, writer):
        async with ClientSession(reader, writer) as client:
            await client.initialize()
            for stage in (1, 2, 3, 4, 6):
                digest = hashlib.sha256((run/f'request-{stage}.json').read_bytes()).hexdigest()
                args = dict(stage=stage, decision_sha256=digest, timeout=0)
                replies = {}
                for detail in ('full', 'brief'):
                    result = await client.call_tool('native_resume', dict(args, detail=detail))
                    assert not result.isError, result
                    replies[detail] = result
                    (out/f'stage-{stage}-{detail}.json').write_text(result.model_dump_json(indent=2))
                full = json.loads(replies['full'].content[0].text)
                brief = json.loads(replies['brief'].content[0].text)
                assert [b.model_dump() for b in replies['full'].content[1:]] == [b.model_dump() for b in replies['brief'].content[1:]]
                for key in ('outcome_summary', 'image_status', 'image_reference', 'continuation', 'window_inventory', 'session_context'):
                    assert full.get(key) == brief.get(key), key
                if brief['presentation']['returned'] == 'brief':
                    retrieval = brief['presentation']['retrieve']
                    restored = await client.call_tool(retrieval['tool'], retrieval['arguments'])
                    assert not restored.isError
                    assert [b.type for b in restored.content] == ['text']
                    assert json.loads(restored.content[0].text)['receipt'] == full['receipt']
                    (out/f'stage-{stage}-retrieved.json').write_text(restored.model_dump_json(indent=2))
                else:
                    assert brief['receipt'] == full['receipt']
                rows.append(dict(stage=stage, returned=brief['presentation']['returned'], image_equal=True, receipt_retrievable_or_unchanged=True))
    for p, (data, modified) in files.items():
        assert (p.read_bytes(), p.stat().st_mtime_ns) == (data, modified), p
    (out/'CHECK.json').write_text(json.dumps(dict(status='PASS', rows=rows, requests_unchanged=True,
        scope='read-only real MCP against retained live receipts; no new GUI, token or latency comparison'), indent=2))
    print((out/'CHECK.json').read_text())

asyncio.run(main())

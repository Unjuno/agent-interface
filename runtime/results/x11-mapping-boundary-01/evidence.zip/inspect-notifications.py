import json
from pathlib import Path
p=Path(__file__).resolve().parent/'notification-diagnostic'
for case in p.iterdir():
 if not case.is_dir():continue
 rows=[json.loads(x) for x in (case/'mapping-notifications.jsonl').read_text().splitlines()];base=rows[0]['after']
 print(json.dumps({'case':case.name,'notifications':[x['notified'] for x in rows],'same_map_each':[x['before']==base for x in rows],'changed_codes_each':[[i+8 for i,(a,b) in enumerate(zip(base['keys'],x['before']['keys'])) if a!=b] for x in rows],'modifiers_equal':[x['before']['modifiers']==base['modifiers'] for x in rows]}))
import os,json,time,subprocess,sys,traceback,platform
from pathlib import Path
r=Path('/var/tmp/agent-interface-integrated-main');sys.path[:0]=[str(r),str(r/'research/live_control'),str(r/'research/observation_gating')]
sys.path.insert(0,str(r/'results-local/midprogram-keymap-integration-01/packaged/agent-interface-runtime.pyz'))
from run_native_six_task_self_use_v1 import PrivateSession
from runtime.backends.x11_v1.backend import X11Backend
from runtime.backends.x11_v1.session import X11RuntimeSession
p=r/'results-local/midprogram-keymap-integration-01';out=p/sys.argv[1];out.mkdir()
def save(n,v):(out/n).write_text(json.dumps(v,indent=2)+'\n')
rows=[]
try:
 for name,initial,changed in [('stable_us','us',None),('jp_to_us_between_ops','jp','us'),('us_to_jp_between_ops','us','jp')]:
  d=out/name;d.mkdir();s=backend=app=None;actor=[]
  try:
   s=PrivateSession()
   def map_to(layout):
    args=['setxkbmap','-display',s.name,'-layout',layout];started=time.monotonic_ns();x=subprocess.run(args,env=s.env,capture_output=True,text=True,timeout=10);q=subprocess.run(['setxkbmap','-display',s.name,'-query'],env=s.env,capture_output=True,text=True,timeout=10)
    receipt={'args':args,'exit':x.returncode,'stdout':x.stdout,'stderr':x.stderr,'query_exit':q.returncode,'query':q.stdout,'started_ns':started,'ended_ns':time.monotonic_ns()};actor.append(receipt)
    if x.returncode or q.returncode or f'layout:     {layout}' not in q.stdout:raise RuntimeError('actor/layout gate')
   map_to(initial)
   with (d/'app.stdout').open('w') as stdout,(d/'app.stderr').open('w') as stderr:
    app=subprocess.Popen([sys.executable,'-m','runtime.backends.x11_v1.fixture_app','--meta',str(d/'meta.json'),'--effect',str(d/'effect.json'),'--events',str(d/'events.jsonl')],cwd=r,env=s.env,stdout=stdout,stderr=stderr)
    deadline=time.monotonic()+5
    while not (d/'meta.json').exists():
     if app.poll() is not None or time.monotonic()>deadline:raise RuntimeError('fixture readiness failed')
     time.sleep(.02)
    wid=json.loads((d/'meta.json').read_text())['window_id']
    class TestBoundary(X11Backend):
     def _wait_update(self,ms):
      if ms==111 and changed is not None:map_to(changed)
      super()._wait_update(ms)
    backend=TestBoundary(s.name,{'fixture':wid});session=X11RuntimeSession(backend)
    program={'schema':'agent-interface/program-v1','program_id':name,'source':{'observation_seq':1,'binding_revision':1},'authority':{'lease_id':'keymap-engineering','expires_at_ns':time.monotonic_ns()+10_000_000_000},'terminal':{'release_all_required':True},'ops':[{'op':'focus','target':'fixture'},{'op':'pointer_move','frame':'window_client','x':50,'y':55},{'op':'pointer_button','button':'left','down':True},{'op':'pointer_button','button':'left','down':False},{'op':'wait_update','timeout_ms':100},{'op':'text','text':'a'},{'op':'wait_update','timeout_ms':111},{'op':'text','text':'_'},{'op':'key_chord','keys':['CTRL','s']},{'op':'wait_update','timeout_ms':250},{'op':'release_all'}]}
    result=session.dispatch(program,current_observation_seq=1,current_binding_revision=1);time.sleep(.15)
    row={'name':name,'initial':initial,'changed':changed,'program':program,'result':result,'effect':json.loads((d/'effect.json').read_text()) if (d/'effect.json').exists() else None,'actor':actor,'window':wid,'display':s.name,'independent_buttons':s.d.screen().root.query_pointer().mask,'independent_keymap':list(s.d.query_keymap()),'readiness':s.window_manager_readiness}
    (d/'row.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row)
  finally:
   if backend:backend.close()
   if app:
    app.terminate();app.wait(timeout=5)
   if s:s.close()
   (d/'cleanup.json').write_text(json.dumps({'app_exit':app.poll() if app else None,'children':[x.poll() for x in s.procs] if s else []})+'\n')
 save('rows.json',rows);save('environment.json',{'backend_file':sys.modules['runtime.backends.x11_v1.backend'].__file__,'python':platform.python_version(),'kernel':platform.release(),'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()})
 good=rows[0]['effect']=={'saved':True,'text':'a_'} and rows[0]['result']['status']=='completed'
 for row in rows[1:]:
  e=row['result'].get('execution',{});good=good and row['result']['status']=='execution_failed' and e.get('failed_op')==7 and row['effect'] is None and e['releases'][-1]['verified']
 good=good and all(not any(row['independent_keymap']) and not (row['independent_buttons'] & ((1<<8)|(1<<9)|(1<<10))) for row in rows)
 save('decision.json',{'candidate_boundary_pass':good,'scope':'Directed engineering regression; no formal study or generic layout claim'})
 print(json.dumps({'candidate_boundary_pass':good,'rows':[{'name':x['name'],'status':x['result']['status'],'effect':x['effect'],'failed_op':x['result'].get('execution',{}).get('failed_op')} for x in rows]}));raise SystemExit(0 if good else 1)
except BaseException as e:
 save('outer.json',{'error':repr(e),'traceback':traceback.format_exc()});raise

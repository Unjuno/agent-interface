import subprocess,json
from pathlib import Path
p=Path('/var/tmp/agent-interface-integrated-main/results-local/midprogram-keymap-integration-01')
a=['/usr/bin/python3','-m','unittest','runtime.backends.x11_v1.test_text_plan','runtime.backends.x11_v1.test_partial_execution','runtime.backends.x11_v1.test_focus','runtime.backends.x11_v1.test_mapping_boundary'];r=subprocess.run(a,cwd=p.parents[1],capture_output=True,text=True)
(p/'broad-first-failure.stdout.txt').write_text(r.stdout);(p/'broad-first-failure.stderr.txt').write_text(r.stderr);(p/'broad-first-failure.receipt.json').write_text(json.dumps({'args':a,'exit':r.returncode})+'\n');print(json.dumps({'exit':r.returncode,'fixture_errors':'Mock' in r.stderr}))
import subprocess,json
from pathlib import Path
p=Path('/var/tmp/agent-interface-integrated-main/results-local/midprogram-keymap-integration-01')
a=['/usr/bin/python3','-m','unittest','runtime.backends.x11_v1.test_mapping_boundary'];r=subprocess.run(a,cwd=p.parents[1],capture_output=True,text=True)
(p/'unit-red.stdout.txt').write_text(r.stdout);(p/'unit-red.stderr.txt').write_text(r.stderr);(p/'unit-red.receipt.json').write_text(json.dumps({'args':a,'exit':r.returncode})+'\n');print(json.dumps({'exit':r.returncode,'failed_assertions':r.stderr.count('X11ExecutionError not raised')}))
raise SystemExit(0 if r.returncode==1 and r.stderr.count('X11ExecutionError not raised')==3 else 1)
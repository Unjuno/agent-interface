import asyncio, hashlib, json, os, platform, subprocess, sys, time, traceback
from pathlib import Path
R=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(R),str(R/'research/live_control'),str(R/'research/observation_gating')]
sys.path.append('/usr/lib/python3/dist-packages')
from run_native_six_task_self_use_v1 import PrivateSession
from runtime.cli_v1.mcp_server import create_server
OUT=R/'results-local/click-text-comparison-01'
OUT.mkdir(exist_ok=False)
def save(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n')
schedule=[0,50,50,0]*3
sources=['runtime/cli_v1/mcp_server.py','runtime/backends/x11_v1/backend.py','runtime/backends/x11_v1/fixture_app.py','runtime/core_v1/sequence.py']
save(OUT/'plan.json',{'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'sha256':{p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in sources},'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'schedule_ms':schedule,'payload':'http://m_n','layout':'jp','new_app_per_row':True,'task':'Click empty Entry, type paced text, Ctrl+S; post-close file equality','kind':'scripted public MCP tool integration comparison, not primary-model or stdio-host timing','no_retry':True,'scope':'one private WSL Xvfb/Tk host; no universal delay or natural failure-rate claim'})
async def main():
    s=None;rows=[]
    try:
        s=PrivateSession()
        subprocess.run(['setxkbmap','-layout','jp'],env=s.env,check=True)
        save(OUT/'environment.json',{'platform':platform.platform(),'python':sys.version,'display':s.name,'wm':s.window_manager_readiness})
        for index,gap in enumerate(schedule):
            out=OUT/f'case-{index:02d}';out.mkdir()
            proc=None;server=None
            try:
                proc=s._popen(['/usr/bin/python3','-m','runtime.backends.x11_v1.fixture_app','--meta',str(out/'meta.json'),'--effect',str(out/'effect.json'),'--events',str(out/'events.jsonl')],cwd=R)
                deadline=time.monotonic()+10
                while not (out/'meta.json').exists():
                    if proc.poll() is not None or time.monotonic()>deadline:raise RuntimeError('fixture startup failed')
                    await asyncio.sleep(.02)
                await asyncio.sleep(.1)
                target=json.loads((out/'meta.json').read_text())['window_id']
                server=create_server({'app':target},out/'mcp',display_name=s.name,session_mode='persistent-x11')
                observed=await server.call_tool('interface_observe',{'target':'app','frame':'window_client','region':[0,0,400,180],'compact':True,'report_refs':True})
                save(out/'observe.json',observed.model_dump(mode='json'))
                ops=[{'op':'focus','target':'app'},{'op':'pointer_move','frame':'window_client','x':100,'y':55},{'op':'pointer_button','button':'left','down':True},{'op':'pointer_button','button':'left','down':False}]
                if gap:ops.append({'op':'wait_update','timeout_ms':gap})
                ops += [{'op':'text','text':'http://m_n','gap_ms':20},{'op':'key_chord','keys':['CTRL','S']},{'op':'wait_update','timeout_ms':100},{'op':'observe','frame':'window_client','region':[0,0,400,180]},{'op':'release_all'}]
                program={'schema':'agent-interface/program-v1','program_id':f'click-{index}','source':{'observation_seq':1,'binding_revision':1},'authority':{'lease_id':'click-comparison','expires_at_ns':time.monotonic_ns()+30_000_000_000},'terminal':{'release_all_required':True},'ops':ops}
                save(out/'program.json',program)
                start=time.monotonic_ns()
                reply=await server.call_tool('interface_dispatch',{'program':program,'current_observation_seq':1,'current_binding_revision':1,'compact':True,'report_refs':True})
                ended=time.monotonic_ns()
                save(out/'dispatch.json',reply.model_dump(mode='json'))
                closed=await server.call_tool('interface_close',{})
                save(out/'close.json',closed.model_dump(mode='json'));server=None
                effect=json.loads((out/'effect.json').read_text()) if (out/'effect.json').exists() else None
                text=next(b.text for b in reply.content if b.type=='text')
                view=json.loads(text);raw=view['receipt']['source']['raw_report']
                save(out/'raw-report.json',raw)
                row={'case':index,'post_click_wait_ms':gap,'tool_return_ns':ended-start,'effect':effect,'correct':effect=={'saved':True,'text':'http://m_n'},'status':raw['result']['status'],'execution':raw['result'].get('execution'),'mcp_calls':3,'repair_calls':0}
                rows.append(row);save(out/'result.json',row)
                print(json.dumps({k:v for k,v in row.items() if k!='execution'}),flush=True)
            finally:
                if server is not None:
                    closed=await server.call_tool('interface_close',{})
                    save(out/'emergency-close.json',closed.model_dump(mode='json'))
                if proc is not None:
                    proc.terminate()
                    try:proc.wait(timeout=3)
                    except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=3)
                    save(out/'app-exit.json',{'pid':proc.pid,'returncode':proc.returncode})
        save(OUT/'results.json',rows)
    except BaseException as e:
        save(OUT/'failure.json',{'error':repr(e),'traceback':traceback.format_exc(),'finished_rows':len(rows)})
        raise
    finally:
        if s is not None:
            s.close();save(OUT/'cleanup.json',[{'pid':p.pid,'returncode':p.poll()} for p in s.procs])
asyncio.run(main())

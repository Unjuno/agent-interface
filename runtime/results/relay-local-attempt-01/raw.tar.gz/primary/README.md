# Current-main primary summary use

Task: enter and save `http://n_p` under JP keymap using portable main bd58ffb40. Primary reviewed the empty field, entered text, reviewed exact text, saved, reviewed saved label, and closed. Independent effect file was checked only after close and matched.

Failure retained: host/reply-1.json is a successfully delivered read-only observation, but the caller incorrectly passed reply.attempt (undefined) to present. The wrapper blocked further actions; transport close exited zero. host-02 is a new explicit connection to the same fixture, with a new observation before any input. This extra observation and connection are part of the trial, not excluded as a successful-only run. No uncertain input was replayed. Both transports exited zero; fixture owner exited zero; cleanup.json records all owned children terminal.

Three images were rendered and reviewed in host-02; two input programs used detail=summary. No full retrieval was needed to choose save or completion. Five MCP calls total across both connections (two observations, two dispatches, one close). Caller source sequence 1 is supplied metadata, not server-issued freshness. Fixed waits and gaps remain explicit and are not app readiness acknowledgements.

This single fresh example verifies scoped use and identifies a host API footgun: send returns protocol id but present requires a distinct local attempt number; reply.attempt is absent. A follow-up should make the delivered local attempt explicit without guessing from protocol id, because refusal may reuse ids. No token, cost, human-tempo or comparative performance claim. host-timing.json covers only the second connection and must not be reported as complete task time.

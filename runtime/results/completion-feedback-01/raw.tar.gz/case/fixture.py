import http.server, json, subprocess, sys, threading, time, traceback
from pathlib import Path

root = Path(__file__).resolve().parent
repo = root.parents[1]
sys.path[:0] = [str(repo), str(repo/'research/live_control'), str(repo/'research/observation_gating')]
from run_native_six_task_self_use_v1 import PrivateSession

out = root/'session'
out.mkdir(exist_ok=False)
token = 'completion1001063'
def save(name, value):
    (out/name).write_text(json.dumps(value, indent=2)+'\n')

class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *args): pass
    def reply(self, body):
        data = body.encode()
        self.send_response(200)
        self.send_header('Content-Type','text/html; charset=utf-8')
        self.send_header('Content-Length',str(len(data)))
        self.end_headers()
        self.wfile.write(data)
    def do_GET(self):
        if self.path != '/task':
            self.send_error(404); return
        self.reply("<!doctype html><title>COMPLETION READY</title><style>main{margin:180px 0 0 55px}input{width:210px}button{margin-left:18px}</style><main><h1>Completion feedback</h1><form method=post action='/save'><label>Value <input name=value autofocus autocomplete=off></label><button>Save</button></form></main>")
    def do_POST(self):
        data = self.rfile.read(int(self.headers['Content-Length']))
        with (out/'submission-history.jsonl').open('a') as log:
            log.write(json.dumps(dict(path=self.path, body=data.decode(), received_monotonic_ns=time.monotonic_ns()))+'\n')
        self.reply("<!doctype html><title>COMPLETION PENDING</title><h1 id=cue>SAVE ACCEPTED — completion display pending</h1><script>setTimeout(()=>{document.title='COMPLETION SAVED';document.getElementById('cue').textContent='COMPLETION SAVED completion1001063'},1500)</script>")

session = server = None
try:
    session = PrivateSession()
    server = http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler)
    threading.Thread(target=server.serve_forever,daemon=True).start()
    with (out/'browser.log').open('w') as log:
        session.spawn(['/home/taka/.cache/ms-playwright/chromium-1208/chrome-linux64/chrome','--no-sandbox','--disable-gpu','--disable-dev-shm-usage','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-sync','--password-store=basic',f'--user-data-dir={session.tmp}/profile','about:blank'],stdout=log,stderr=log)
    session.wait_window('about:blank',20)
    session.focus('about:blank')
    window = int(next(line.split()[0] for line in session.windows().splitlines() if 'about:blank' in line),16)
    save('targets.json',{'browser':window})
    save('goal.json',dict(url=f'http://127.0.0.1:{server.server_port}/task', token=token, cue='COMPLETION SAVED completion1001063'))
    save('allocation.json',dict(display=session.name,source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),delay_ms=1500))
    save('readiness.json',session.window_manager_readiness)
    print(json.dumps(dict(ready=True,display=session.name,target=window)),flush=True)
    deadline=time.monotonic()+600
    while not (out/'finish.json').exists():
        if time.monotonic()>deadline:raise TimeoutError('allocation deadline')
        time.sleep(.05)
except BaseException as error:
    save('failure.json',dict(error=repr(error),traceback=traceback.format_exc()))
    raise
finally:
    if server:server.shutdown();server.server_close()
    if session:
        session.close()
        save('cleanup.json',[dict(pid=p.pid,returncode=p.poll()) for p in session.procs])

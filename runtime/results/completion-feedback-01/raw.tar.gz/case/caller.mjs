import {createPrimaryCaller} from './host-bundle/primary_caller.mjs';
import {createInstrumentedRelayClient} from './host-bundle/relay_host.mjs';
export async function open(fs, root, parent, sinks) {
  const allocation=JSON.parse(await fs.readFile(root+'/session/allocation.json','utf8'));
  const goal=JSON.parse(await fs.readFile(root+'/session/goal.json','utf8'));
  const linux='/var/tmp/agent-interface-evidence-storage-main/results-local/completion-feedback-01';
  const host=await createInstrumentedRelayClient({command:'wsl.exe',args:['-d','Ubuntu','-u','taka','--exec','/tmp/agent-interface-mcp-venv/bin/python',linux+'/runtime.pyz','relay','--','--targets',linux+'/session/targets.json','--output-directory',linux+'/session/server','--session-mode','persistent-x11','--display',allocation.display],evidenceDirectory:parent+'/completion-feedback-01-host',minimumEvidenceFreeBytes:128*1024*1024,reuseReviewedImages:false});
  const policy=createPrimaryCaller(host,'direct',sinks,[],{observationArguments:{target:'browser',frame:'screen_physical_px',region:[0,0,1280,800],compact:true,report_refs:true}});
  const meta=r=>JSON.parse(r.result.content.find(c=>c.type==='text').text);
  let sequence=1,number=0;
  return {host,goal,allocation,observe:policy.observe,state:policy.state,
    review:(r,reason)=>policy.review(r.attempt,{task:'completion1001063',phase:'primary',reason}),
    ack:(r,reason)=>policy.acknowledgeText(r.attempt,{task:'completion1001063',phase:'primary',reason}),
    dispatch:async(phase,ops)=>{
      const sampled=await policy.call('interface_clock',{}),clock=meta(sampled);
      await policy.acknowledgeText(sampled.attempt,{task:'completion1001063',phase:'clock',reason:'Same-host explicit lease sample; no input authority issued by clock.'});
      if(clock.authority_granted!==false||clock.lease_issued!==false||!Number.isSafeInteger(clock.monotonic_ns))throw Error('clock contract');
      const r=await policy.call('interface_dispatch',{program:{schema:'agent-interface/program-v1',program_id:'completion-feedback-'+phase+'-'+(++number),source:{observation_seq:sequence,binding_revision:1},authority:{lease_id:'completion-feedback01',expires_at_ns:clock.monotonic_ns+5000000000},terminal:{release_all_required:true},ops:[{op:'focus',target:'browser'},...ops,{op:'release_all'}]},current_observation_seq:sequence,current_binding_revision:1,compact:true,report_refs:true,detail:'summary',inspect_after:'browser',inspect_after_region:[0,0,1280,800]});
      sequence++;return r;
    },
    close:()=>policy.call('interface_close',{})};
}

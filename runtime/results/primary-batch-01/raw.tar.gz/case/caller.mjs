import {createPrimaryCaller} from './host-bundle/primary_caller.mjs';
import {createInstrumentedRelayClient} from './host-bundle/relay_host.mjs';
export async function open(fs,root,parent,sinks) {
  const allocation=JSON.parse(await fs.readFile(root+'/session/allocation.json','utf8'));
  const goal=JSON.parse(await fs.readFile(root+'/session/goal.json','utf8'));
  const linux='/var/tmp/agent-interface-evidence-storage-main/results-local/primary-batch-01';
  const host=await createInstrumentedRelayClient({command:'wsl.exe',args:['-d','Ubuntu','-u','taka','--exec','/tmp/agent-interface-mcp-venv/bin/python',linux+'/runtime.pyz','relay','--','--targets',linux+'/session/targets.json','--output-directory',linux+'/session/server','--session-mode','guarded-x11','--display',allocation.display],evidenceDirectory:parent+'/primary-batch-01-host',minimumEvidenceFreeBytes:128*1024*1024,reuseReviewedImages:false});
  return {host,goal,allocation,policy:createPrimaryCaller(host,'guarded-local',sinks)};
}

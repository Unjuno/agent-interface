import os,sys,json,time,subprocess,hashlib
from pathlib import Path
r=Path('/var/tmp/agent-interface-integrated-main');sys.path[:0]=[str(r),str(r/'research/live_control'),str(r/'research/observation_gating')]
from run_native_six_task_self_use_v1 import PrivateSession
from runtime.backends.x11_v1.backend import X11Backend
from runtime.backends.x11_v1.session import X11RuntimeSession
from runtime.backends.x11_v1.test_integration import make_program
p=r/'results-local/release-readback-diagnostic-01'
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
plan={'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_sha256':hashlib.sha256((r/'runtime/backends/x11_v1/backend.py').read_bytes()).hexdigest(),'cases':['normal']*20+['withheld_release'],'samples_ms':[0,2,10,50],'one_private_server':True,'scope':'Engineering diagnostic, no formal rerun, no production replay or authority from a later sample'}
write(p/'PLAN.json',plan)
s=None;rows=[]
try:
 s=PrivateSession();write(p/'server.json',{'display':s.name,'readiness':s.window_manager_readiness,'pids':[x.pid for x in s.procs]})
 for i,mode in enumerate(plan['cases']):
  d=p/f'case-{i:02}-{mode}';d.mkdir();app=backend=None
  try:
   with (d/'app.stdout').open('w') as so,(d/'app.stderr').open('w') as se:
    app=subprocess.Popen([sys.executable,'-m','runtime.backends.x11_v1.fixture_app','--meta',str(d/'meta.json'),'--effect',str(d/'effect.json'),'--events',str(d/'events.jsonl')],env=s.env,stdout=so,stderr=se)
    deadline=time.monotonic()+5
    while not (d/'meta.json').exists():
     if app.poll() is not None or time.monotonic()>deadline:raise RuntimeError('fixture readiness')
     time.sleep(.02)
    class FailAfterPress(X11Backend):
     suppress_release=mode=='withheld_release'
     def pointer_button(self,button,down):
      super().pointer_button(button,down)
      if down:raise RuntimeError('injected failure after native press')
     def release_all(self):
      if self.suppress_release:return {'verified':False,'keys_down':[],'buttons_down':['left'],'error':'withheld release engineering control'}
      return super().release_all()
    backend=FailAfterPress(s.name,{'fixture':json.loads((d/'meta.json').read_text())['window_id']});session=X11RuntimeSession(backend)
    program=make_program(f'release-diagnostic-{i}')
    started=time.monotonic_ns();result=session.dispatch(program,current_observation_seq=7,current_binding_revision=3);returned=time.monotonic_ns();before=backend.emissions
    samples=[]
    for offset in plan['samples_ms']:
     due=returned+offset*1000000;remaining=(due-time.monotonic_ns())/1e9
     if remaining>0:time.sleep(remaining)
     a=time.monotonic_ns();mask=s.d.screen().root.query_pointer().mask;keys=list(s.d.query_keymap());b=time.monotonic_ns()
     samples.append({'target_ms':offset,'started_ns':a,'ended_ns':b,'mask':mask,'keymap':keys})
    read_emissions=backend.emissions-before;blocked=None
    if session.recovery_required:
     blocked=session.dispatch(program,current_observation_seq=7,current_binding_revision=3)
    row={'mode':mode,'started_ns':started,'returned_ns':returned,'program':program,'result':result,'samples':samples,'diagnostic_emissions':read_emissions,'recovery_required_after_samples':session.recovery_required,'blocked':blocked,'effect_exists':(d/'effect.json').exists()}
    backend.suppress_release=False
    row['explicit_recovery']=session.recover_input() if session.recovery_required else None
    row['final_independent_mask']=s.d.screen().root.query_pointer().mask;row['final_independent_keymap']=list(s.d.query_keymap())
    write(d/'row.json',row);rows.append(row)
  finally:
   if backend:backend.close()
   if app:app.terminate();app.wait(timeout=5)
   write(d/'cleanup.json',{'app_exit':app.poll() if app else None})
 write(p/'rows.json',rows)
 transient=[i for i,x in enumerate(rows[:-1]) if not x['result']['execution']['releases'][-1]['verified'] and not x['samples'][-1]['mask'] & (1<<8)]
 retained=[i for i,x in enumerate(rows[:-1]) if x['samples'][-1]['mask'] & (1<<8)]
 unverified=[i for i,x in enumerate(rows[:-1]) if not x['result']['execution']['releases'][-1]['verified']]
 summary={'normal_count':20,'normal_unverified':unverified,'later_neutral_without_emission':transient,'still_down_50ms':retained,'diagnostic_emissions':sum(x['diagnostic_emissions'] for x in rows),'control_held_all_samples':all(x['mask']&(1<<8) for x in rows[-1]['samples']),'control_blocked':rows[-1]['blocked'],'control_explicit_recovery':rows[-1]['explicit_recovery']}
 write(p/'summary.json',summary);print(json.dumps(summary))
finally:
 if s:s.close();write(p/'cleanup.json',{'children':[x.poll() for x in s.procs]})
import os,sys,json,unittest,importlib.util,traceback
from pathlib import Path
r=Path('/var/tmp/agent-interface-integrated-main');sys.path[:0]=[str(r),str(r/'research/live_control'),str(r/'research/observation_gating')]
from run_native_six_task_self_use_v1 import PrivateSession
p=r/'results-local/release-readback-diagnostic-01';label=sys.argv[1];d=p/label;d.mkdir();s=None
try:
 s=PrivateSession();os.environ.update(DISPLAY=s.name,XAUTHORITY=str(s.env.get('XAUTHORITY','')))
 if label=='live-baseline':
  name='runtime.backends.x11_v1.backend';spec=importlib.util.spec_from_file_location(name,p/'baseline-backend.py');module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
 target='runtime.backends.x11_v1.test_integration.X11IntegrationTests.test_midprogram_keymap_change_stops_before_suffix_and_save' if label=='live-baseline' else 'runtime.backends.x11_v1.test_integration'
 with (d/'unittest.stderr.txt').open('w') as stream:
  targets=[target,'runtime.backends.x11_v1.test_mapping_boundary','runtime.backends.x11_v1.test_text_plan','runtime.backends.x11_v1.test_partial_execution','runtime.backends.x11_v1.test_capture_artifacts','runtime.cli_v1.test_native_golden_boundary']
  result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(targets))
 record={'label':label,'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'passed':result.wasSuccessful(),'display':s.name}
 (d/'result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));raise SystemExit(0 if result.wasSuccessful() else 1)
finally:
 if s:
  s.close();(d/'cleanup.json').write_text(json.dumps([x.poll() for x in s.procs])+'\n')
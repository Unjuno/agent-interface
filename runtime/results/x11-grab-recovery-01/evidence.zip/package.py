from pathlib import Path
import json,zipfile,hashlib
r=Path('/var/tmp/agent-interface-integrated-main');p=r/'results-local/release-readback-diagnostic-01';out=r/'runtime/results/x11-grab-recovery-01';out.mkdir()
source=p/'final-source';source.mkdir()
for name in ['runtime/backends/x11_v1/backend.py','runtime/backends/x11_v1/session.py','runtime/backends/x11_v1/test_integration.py','runtime/cli_v1/mcp_session.py','runtime/host_v1/README.md']:
 target=source/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((r/name).read_bytes())
load=lambda name:json.loads((p/name).read_text())
control=load('rows.json');grab=load('grab-discriminator-01/rows.json')[1]
metrics={'schema':'agent-interface/real-x11-grab-recovery-engineering-v1','base':load('PLAN.json')['base'],'ordinary_cases':20,'ordinary_unverified':load('summary.json')['normal_unverified'],'grab_result':grab['result'],'grab_mask_samples':[s['mask'] for s in grab['samples']],'grab_sample_elapsed_ms':[(s['ended_ns']-grab['returned_ns'])/1e6 for s in grab['samples']],'after_allow_mask':grab['after_allow_mask'],'allow_input_emissions':grab['emissions_after_allow'],'recovery_required_after_allow':grab['recovery_required_after_allow'],'blocked':grab['blocked'],'explicit_recovery':grab['explicit_recovery'],'live_tests':load('live-regression-01/result.json'),'scope':'Real X11 discriminator/regression, not cause proof for previous spontaneous failure; no automatic recovery or performance claim'}
(out/'metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
files=sorted(x for x in p.rglob('*') if x.is_file() and '__pycache__' not in x.parts)
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(f,f.relative_to(p).as_posix())
manifest={'archive':'evidence.zip','sha256':hashlib.sha256((out/'evidence.zip').read_bytes()).hexdigest(),'files':[{'path':f.relative_to(p).as_posix(),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files]}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'files':len(files),'zip_bytes':(out/'evidence.zip').stat().st_size}))
import asyncio,json,time,base64
from pathlib import Path
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
root=Path('/var/tmp/agent-interface-integrated-main');out=root/'results-local/native-sdk-primary-04'
async def main():
 params=StdioServerParameters(command='/tmp/agent-interface-mcp-venv/bin/python',args=['research/live_control/native_mcp_v1.py','--allocation-directory','results-local/native-sdk-allocation-04','--app','calc','--seed','991316','--max-stages','8','--text-gap-ms','2','--harness-python','/usr/bin/python3'],cwd=str(root),env={'PYTHONPATH':'.:research/live_control','PYTHONDONTWRITEBYTECODE':'1'})
 async with stdio_client(params) as (rd,wr):
  async with ClientSession(rd,wr) as client:
   await client.initialize()
   async def call(label,name,args):
    (out/(label+'-request.json')).write_text(json.dumps({'name':name,'arguments':args}))
    start=time.monotonic_ns(); result=await client.call_tool(name,args)
    (out/(label+'-response.json')).write_text(result.model_dump_json())
    (out/(label+'-timing.json')).write_text(json.dumps({'start_ns':start,'end_ns':time.monotonic_ns()}))
    for idx,c in enumerate(result.content):
     if c.type=='image':(out/f'{label}-{idx}.png').write_bytes(base64.b64decode(c.data))
     elif c.type=='text': print(label,c.text,flush=True)
   await call('start','native_start',{'timeout':10})
   for n in range(1,20):
    path=out/f'decision-{n}.json'
    while not path.exists():
     if (out/'finish').exists():return
     await asyncio.sleep(.1)
    row=json.loads(path.read_text());await call(f'action-{n}',row['name'],row['arguments'])
asyncio.run(main())

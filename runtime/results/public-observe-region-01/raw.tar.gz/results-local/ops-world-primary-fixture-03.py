import json,sys,time,signal,hashlib,subprocess
from pathlib import Path
r=Path(__file__).resolve().parents[1];sys.path.insert(0,str(r));sys.path.insert(0,str(r/'research/live_control'))
from run_native_six_task_self_use_v1 import PrivateSession
out=r/'results-local/ops-world-primary-03';out.mkdir(exist_ok=False)
world=r/'results-local/ops-world-integration-build-02/source/research/procedural_operations_world_v0/ops_world'
args=[str(world),'--seed','42','--family-key','99173','--set','watcher_count=0','--set','required_alerts=0','--set','event_rate=0','--set','episode_seconds=600','--runtime','600','--report',str(out/'evaluator-report.json')]
def save(name,value): (out/name).write_text(json.dumps(value,indent=2)+'\n')
save('plan.json',{'scope':'construction/usability; source and debug seed known; no hidden evaluation or success threshold','actions':'primary chooses from rendered framebuffer through public persistent MCP; no source-derived policy; evaluator report read only after exit','goal':'verify public observe region syntax with movement and camera; no task completion or speed comparison','command':args,'real_time':True,'fixed_step':False,'controller_lease':'caller-asserted source and 120s admission expiry from prior relay return; no hard runtime bound; input holds explicitly <=1000ms','source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'fixture_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
session=app=None
try:
 session=PrivateSession()
 with (out/'app.stdout').open('wb') as stdout,(out/'app.stderr').open('wb') as stderr:
  app=session.spawn(args,stdout=stdout,stderr=stderr)
 session.wait_window('Procedural Operations World',10);session.focus('Procedural Operations World')
 line=next(line for line in session.windows().splitlines() if 'Procedural Operations World' in line)
 targets={'world':int(line.split()[0],16)};save('targets.json',targets)
 save('allocation.json',{'display':session.name,'targets':targets,'app_pid':app.pid,'window_manager_readiness':session.window_manager_readiness})
 print(json.dumps({'ready':True,'display':session.name,'targets':targets}),flush=True)
 deadline=time.monotonic()+620
 while app.poll() is None and not (out/'finish.json').exists():
  if time.monotonic()>deadline: raise TimeoutError('fixture deadline')
  time.sleep(.1)
 if app.poll() is None: app.send_signal(signal.SIGTERM)
 code=app.wait(timeout=10);save('app-exit.json',{'returncode':code});print(json.dumps({'app_exit':code}),flush=True)
finally:
 if session:
  session.close();save('cleanup.json',[{'pid':p.pid,'returncode':p.poll()} for p in session.procs])

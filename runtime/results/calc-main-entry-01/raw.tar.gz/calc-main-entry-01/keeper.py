import json,os,subprocess,time,shutil
from pathlib import Path
from Xlib import display as xd
import openpyxl
root=Path(__file__).resolve().parent;session=root/'session';session.mkdir(exist_ok=False)
processes=[]
def connected(name):
 try:d=xd.Display(name);d.close();return True
 except Exception:return False
def wait(test):
 end=time.monotonic()+20
 while not test():
  if time.monotonic()>end:raise TimeoutError('readiness')
  time.sleep(.05)
display=next(':'+str(n) for n in range(153,190) if not connected(':'+str(n)) and not Path(f'/tmp/.X{n}-lock').exists())
env=dict(os.environ,DISPLAY=display)
try:
 for name,command in [('xvfb',['Xvfb',display,'-screen','0','1280x800x24','-ac','-nolisten','tcp']),('wm',['openbox','--config-file','/etc/xdg/openbox/rc.xml'])]:
  if name=='wm':wait(lambda:connected(display))
  p=subprocess.Popen(command,env=env,stdout=(session/(name+'.stdout')).open('wb'),stderr=(session/(name+'.stderr')).open('wb'));processes.append(p)
 d=xd.Display(display)
 def managed():
  return d.screen().root.get_full_property(d.intern_atom('_NET_SUPPORTING_WM_CHECK'),0) is not None
 wait(managed)
 workbook=session/'primary-values.xlsx';openpyxl.Workbook().save(workbook)
 p=subprocess.Popen(['libreoffice','-env:UserInstallation='+ (session/'lo-profile').as_uri(),'--calc','--norestore',str(workbook)],env=env,stdout=(session/'calc.stdout').open('wb'),stderr=(session/'calc.stderr').open('wb'));processes.append(p)
 def find_target():
  clients=d.screen().root.get_full_property(d.intern_atom('_NET_CLIENT_LIST'),0)
  for wid in ([] if clients is None else clients.value):
   w=d.create_resource_object('window',int(wid));title=w.get_full_property(d.intern_atom('_NET_WM_NAME'),0)
   if title is not None and b'primary-values.xlsx' in bytes(title.value):return int(wid)
  return None
 wait(lambda:find_target() is not None);target=find_target();d.close()
 (session/'targets.json').write_text(json.dumps({'app':target}))
 (session/'allocation.json').write_text(json.dumps({'source':'443bcb63333c4614d9a6fee5cb3ca3f9f6ea9710','display':display,'target':target,'goal':{'A1':731,'A2':864},'deadline_ns':time.monotonic_ns()+900_000_000_000}))
 print(json.dumps({'ready':True,'display':display,'target':target}),flush=True)
 end=time.monotonic()+900
 while not (session/'finish.json').exists():
  if time.monotonic()>end:raise TimeoutError('primary deadline')
  time.sleep(.1)
 shutil.copy2(workbook,session/'saved.xlsx');book=openpyxl.load_workbook(session/'saved.xlsx',data_only=True)
 actual={'A1':book.active['A1'].value,'A2':book.active['A2'].value}
 (session/'independent-effect.json').write_text(json.dumps({'actual':actual,'passed':actual=={'A1':731,'A2':864}},indent=2)+'\n')
finally:
 for p in reversed(processes):
  if p.poll() is None:p.terminate()
  try:p.wait(timeout=3)
  except subprocess.TimeoutExpired:p.kill();p.wait()
 (session/'cleanup.json').write_text(json.dumps([{'pid':p.pid,'returncode':p.returncode} for p in processes]))

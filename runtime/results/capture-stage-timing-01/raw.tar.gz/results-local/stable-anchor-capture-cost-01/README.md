# Historical capture cost boundary

Read-only analysis of stable-anchor-six-pair-01. Original reports remain unchanged. Each row names and hashes its source report.

The backend timestamps bracket only X11 get_image. They do not measure PNG encoding, file persistence, bridge read/decode, transport to the primary model, or model processing. Summed times span the complete arm, including navigation, guarding, result review and repair; they are not an action-feedback decomposition. The direct and persistent arms are one sequential construction pair, not randomized replications.

Decision: retain current guard captures and compression default. The earlier PNG delivery study #4401 did not establish a production delivery advantage. Capture count alone does not justify removing fresh visual checks or changing compression. A next live measurement must separately bracket artifact preparation and bridge observation before attributing the latency difference to PNG or disk I/O.

from pathlib import Path
import sys,json,time
sys.path[:0]=['research/live_control','research/observation_gating']
from run_native_six_task_self_use_v1 import PrivateSession
from native_handle_bridge_v1 import NativeHandleBridge
from Xlib import X
out=Path(__file__).resolve().parent
session=bridge=None
try:
 session=PrivateSession();d=session.d;screen=d.screen()
 win=screen.root.create_window(50,50,640,400,0,screen.root_depth,X.InputOutput,X.CopyFromParent,background_pixel=screen.white_pixel)
 win.set_wm_name('Capture stage timing private fixture');win.map();d.sync()
 bridge=NativeHandleBridge(session.name,{'fixture':win.id},'fixture',out/'bridge')
 readiness=[]
 for i in range(50):
  readiness.append(bridge._binding())
  if len(readiness)>=10 and all(x==readiness[-1] for x in readiness[-10:]): break
  time.sleep(.1)
 else: raise RuntimeError('window binding did not settle')
 (out/'readiness.json').write_text(json.dumps(readiness,indent=2)+'\n')
 rows=[]
 for _ in range(5):
  o=bridge.observe();t=o['timing_ns'];a=o['native']['artifact']['timing_ns']
  assert list(t.values())==sorted(t.values()) and list(a.values())==sorted(a.values())
  assert t['started']<=o['native']['capture_started_ns']<=o['native']['capture_ended_ns']<=a['started']<=a['hashed']<=t['public_returned']
  rows.append({'sequence':o['sequence'],'bridge_to_decoded_ms':(t['decoded']-t['started'])/1e6,'artifact_ms':{f'{l}_to_{rr}':(a[rr]-a[l])/1e6 for l,rr in zip(list(a),list(a)[1:])}})
 (out/'summary.json').write_text(json.dumps({'scope':'five read-only captures of private static X11 window; not model or task latency','rows':rows},indent=2)+'\n')
 print(json.dumps(rows,indent=2))
except Exception as e:
 (out/'failure.json').write_text(json.dumps({'error':repr(e)})+'\n');raise
finally:
 if bridge: bridge.close()
 if session:
  session.close()
  (out/'cleanup.json').write_text(json.dumps({'session_close_returned':True})+'\n')

import asyncio, base64, hashlib, json, os, signal, socket, subprocess, sys, time
from pathlib import Path
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

root = Path(__file__).resolve().parent
archive = root.parent / 'current-runtime-delivery-3729/agent-interface-runtime.pyz'
display = ':252'
def save(name, value):
    (root / name).write_text(json.dumps(value, indent=2), encoding='utf-8')

async def main():
    (root / 'started').open('x').close()
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == 'aa9024a5eea4384bdbba349b907f9f2a279ca2d041e50418a7820e778591aae0'
    assert Path('/usr/lib/libreoffice/program/soffice.bin').is_file()
    assert not Path('/tmp/.X252-lock').exists(), 'occupied display'
    for address in ('/tmp/.X11-unix/X252', '\0/tmp/.X11-unix/X252'):
        with socket.socket(socket.AF_UNIX) as probe:
            try: probe.connect(address)
            except OSError: pass
            else: raise RuntimeError('occupied display')
    private = Path('/tmp/agent-interface-cli-inline-calc-02')
    private.mkdir(exist_ok=False)
    env = dict(os.environ, DISPLAY=display, GDK_BACKEND='x11', SAL_USE_VCLPLUGIN='gen',
               HOME=str(private), XDG_CONFIG_HOME=str(private/'config'),
               XDG_CACHE_HOME=str(private/'cache'), XDG_DATA_HOME=str(private/'data'),
               LANG='C.UTF-8', PYTHONDONTWRITEBYTECODE='1')
    for key in ('WAYLAND_DISPLAY', 'DBUS_SESSION_BUS_ADDRESS', 'PYTHONPATH'):
        env.pop(key, None)
    document = root / 'invoice.fods'
    document.write_text('''<?xml version="1.0" encoding="UTF-8"?>
<office:document xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0"
 xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0"
 office:version="1.2" office:mimetype="application/vnd.oasis.opendocument.spreadsheet">
 <office:body><office:spreadsheet><table:table table:name="Invoice">
 <table:table-row><table:table-cell/></table:table-row>
 </table:table></office:spreadsheet></office:body></office:document>''', encoding='utf-8')
    (root/'initial.fods').write_bytes(document.read_bytes())
    save('task.json', {'task':'Enter Quantity, Unit price, Total in A1:C1; 6 and 23 in A2:B2; formula =B2*A2 in C2; save. Expected total 138.',
        'source_revision':'2dff80852292cc82fd5c23a449c8244bea94bc25',
        'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
        'scope':'Primary model uses complete CLI response with inline image forwarding, public portable CLI with retained run directories. No direct registered-host route or performance comparison.'})
    children = []; conn = None
    with (root/'process.log').open('w') as log:
        try:
            def launch(args):
                p = subprocess.Popen(args, env=env, stdout=log, stderr=log, start_new_session=True)
                children.append(p); return p
            launch(['Xvfb',display,'-screen','0','1024x768x24','-nolisten','tcp','-nolisten','unix'])
            from Xlib.display import Display
            for _ in range(100):
                try: conn=Display(display); break
                except Exception: await asyncio.sleep(.05)
            assert conn, 'display unavailable'
            launch(['openbox'])
            app=launch(['libreoffice',
                '-env:UserInstallation='+ (private/'profile').as_uri(),
                '--norestore','--nofirststartwizard','--calc',str(document)])
            inventory=[]
            def find(window):
                try:
                    title=window.get_wm_name() or ''
                    if isinstance(title,bytes): title=title.decode('utf-8','replace')
                    net=window.get_full_property(conn.intern_atom('_NET_WM_NAME'),0)
                    if net is not None and isinstance(net.value,bytes):title=net.value.decode('utf-8','replace')
                    if title:inventory.append({'id':window.id,'title':title,'mapped':window.get_attributes().map_state})
                    if 'invoice' in title.lower() and 'LibreOffice' in title and window.get_attributes().map_state==2:
                        return window
                    for child in window.query_tree().children:
                        found=find(child)
                        if found:return found
                except Exception: pass
            target=None
            for _ in range(900):
                assert app.poll() is None, 'application exited'
                target=find(conn.screen().root)
                if target:break
                await asyncio.sleep(.05)
            save('window-inventory.json',inventory)
            if not target:
                from PIL import Image
                from Xlib import X
                capture=conn.screen().root.get_image(0,0,1024,768,X.ZPixmap,0xffffffff)
                Image.frombytes('RGB',(1024,768),capture.data,'raw','BGRX').save(root/'setup-failure.png')
            assert target, 'no task window found; diagnostic retained'
            geo=target.get_geometry()
            save('targets.json',{'calc':target.id})
            save('allocation.json',{'pids':[p.pid for p in children], 'target':target.id,
                'display':display,'width':geo.width,'height':geo.height})
            async def call(name,args,label):
                operation=name.removeprefix('interface_')
                cmd=[sys.executable,str(archive),operation,'--targets',str(root/'targets.json'),
                     '--display',display,'--run-directory',str(root/'attempts'/label),
                     '--review','--compact','--report-refs']
                if operation=='observe':
                    cmd+=['--target',args['target'],'--frame',args['frame'],'--region',*[str(v) for v in args['region']]]
                else:
                    save(label+'-program.json',args['program'])
                    cmd+=['--program',str(root/(label+'-program.json')),
                          '--current-observation-seq',str(args['current_observation_seq']),
                          '--current-binding-revision',str(args['current_binding_revision'])]
                save(label+'-command.json',cmd)
                started_ns=time.monotonic_ns()
                process=await asyncio.create_subprocess_exec(*cmd,cwd='/tmp',env=env,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE)
                stdout,stderr=await process.communicate()
                (root/(label+'-stdout.json')).write_bytes(stdout)
                (root/(label+'-stderr.txt')).write_bytes(stderr)
                save(label+'-timing.json',{'started_ns':started_ns,'ended_ns':time.monotonic_ns(),'exit_code':process.returncode,'scope':'CLI process roundtrip only'})
                result=json.loads(stdout)
                save(label+'-metadata.json',{k:v for k,v in result.items() if k!='image'})
                if result.get('image'):(root/(label+'.png')).write_bytes(base64.b64decode(result['image']['data']))
                print(label+' ready',flush=True)
            (root/'attempts').mkdir()
            await call('interface_observe',{'target':'calc','frame':'screen_physical_px','region':[0,0,1024,768]},'initial')
            for stage in range(1,7):
                path=root/f'decision-{stage}.json'
                for _ in range(3000):
                    if path.exists() or (root/'finish').exists():break
                    await asyncio.sleep(.1)
                if (root/'finish').exists():break
                assert path.exists(),'primary decision deadline'
                decision=json.loads(path.read_text())
                if decision['tool']=='interface_dispatch':
                    decision['arguments']['program']['authority']['expires_at_ns']=time.monotonic_ns()+10_000_000_000
                await call(decision['tool'],decision['arguments'],f'action-{stage}')
        finally:
            if conn:conn.close()
            rows=[]
            for p in reversed(children):
                members=[]
                for candidate in Path('/proc').iterdir():
                    if not candidate.name.isdigit():continue
                    try:
                        pid=int(candidate.name)
                        if os.getpgid(pid)==p.pid:
                            members.append({'pid':pid,'stat':(candidate/'stat').read_text()})
                    except (OSError,ProcessLookupError):pass
                if p.poll() is None:
                    assert os.getpgid(p.pid)==p.pid
                    os.killpg(p.pid,signal.SIGTERM)
                try:p.wait(timeout=5)
                except subprocess.TimeoutExpired:p.kill();p.wait(timeout=3)
                await asyncio.sleep(.1)
                rows.append({'pid':p.pid,'returncode':p.returncode,'group_members_before':members,
                             'remaining_member_paths':[m['pid'] for m in members if Path('/proc',str(m['pid'])).exists()]})
            save('cleanup.json',{'tracked_processes':rows,'descendants_verified':False})
    print('owner finished',flush=True)

asyncio.run(main())

import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent
ns = {'table': 'urn:oasis:names:tc:opendocument:xmlns:table:1.0',
      'office': 'urn:oasis:names:tc:opendocument:xmlns:office:1.0'}
rows = ET.parse(root / 'invoice.fods').findall('.//table:table-row', ns)
cells = rows[1].findall('table:table-cell', ns)
values = [cell.get('{'+ns['office']+'}value') for cell in cells[:3]]
formula = cells[2].get('{'+ns['table']+'}formula')
assert values == ['6', '23', '138'], values
assert formula == 'of:=[.B2]*[.A2]', formula
attempts = []
for path in sorted((root / 'attempts').iterdir()):
    report = json.loads((path / 'report.json').read_bytes())
    metadata = json.loads((root / (path.name + '-metadata.json')).read_bytes())
    assert metadata['receipt']['source']['raw_report'] == report
    assert metadata['retention']['report_persisted']
    timing = json.loads((root / (path.name + '-timing.json')).read_bytes())
    assert timing['exit_code'] == 0
    attempts.append({'name': path.name, 'cli_roundtrip_ms':
                     (timing['ended_ns']-timing['started_ns'])/1e6})
cleanup = json.loads((root / 'cleanup.json').read_bytes())
assert all(not p['remaining_member_paths'] for p in cleanup['tracked_processes'])
result = {'saved_values': values, 'saved_formula': formula, 'attempts': attempts,
          'dispatches': 2, 'observations': 2, 'extra_final_observation': 1,
          'primary_visual_confirmation': '6, 23, 138 in action-3; action-2 showed Saving',
          'cleanup': cleanup, 'owner_exit_code': 0,
          'scope': 'Fresh primary CLI use with complete inline image/metadata forwarding; no separate view_image calls; no matched performance or model-usage measurement.'}
(root / 'verification.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
hashes = {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
          for p in root.rglob('*') if p.is_file() and p.name != 'evidence-sha256.json'}
(root / 'evidence-sha256.json').write_text(json.dumps(hashes, indent=2), encoding='utf-8')
print(json.dumps(result))

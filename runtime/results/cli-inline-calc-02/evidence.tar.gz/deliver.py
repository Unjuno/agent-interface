"""Bounded host delivery helper; a timeout never resubmits an action."""
import argparse, json, time
from pathlib import Path
root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('label')
parser.add_argument('--decision')
args = parser.parse_args()
assert args.label in ['initial'] + [f'action-{i}' for i in range(1,7)]
if args.decision:
    assert args.label.startswith('action-')
    data = Path(args.decision).read_bytes()
    json.loads(data)
    path = root / ('decision-' + args.label.split('-')[1] + '.json')
    temporary = path.with_suffix('.pending')
    assert not path.exists()
    with temporary.open('xb') as stream:
        stream.write(data)
    temporary.rename(path)
deadline = time.monotonic() + 20
while not (root / (args.label + '-metadata.json')).exists():
    if time.monotonic() >= deadline:
        print(json.dumps({'delivery': 'pending', 'label': args.label,
                          'instruction': 'Read same label without --decision; never resubmit.'}))
        raise SystemExit(2)
    time.sleep(.02)
raw = (root / (args.label + '-stdout.json')).read_bytes()
json.loads(raw)
print(raw.decode('utf-8'))

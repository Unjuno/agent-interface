import subprocess,json,hashlib,sys
from pathlib import Path
r=Path(__file__).resolve().parents[1];out=r/'results-local/lifecycle-intake-01';out.mkdir(exist_ok=False)
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
prefix='research/analysis/needle_role_skill_lifecycle_5133_v2'
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',commit,'--',prefix],cwd=r,text=True).splitlines()
paths+=['research/analysis/needle_role_skill_lifecycle_4916_v2/lifecycle.py','research/needle_role_skill_reload_3780_v1/loader.py','research/needle_role_skill_reload_3780_v1/formal/seed-3788/builder/skill.json','research/needle_role_skill_reload_3780_v1/formal/seed-3788/builder/expected.json']
manifest={}
for name in paths:
 data=subprocess.check_output(['git','show',commit+':'+name],cwd=r)
 target=out/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 manifest[name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
(out/'source-manifest.json').write_text(json.dumps({'commit':commit,'files':manifest},indent=2)+'\n')
suite=out/'source'/prefix
commands=[['python3','-B','-m','unittest','discover','-s',str(suite),'-p','test_*.py','-v'],['python3','-B',str(suite/'audit_correction.py'),'--raw',str(suite/'results/formal-04/raw.json'),'--prior-audit',str(suite/'results/audit-04/audit.json'),'--out',str(out/'correction.json')]]
results=[]
for n,command in enumerate(commands,1):
 with (out/f'check-{n}.stdout').open('w') as stdout,(out/f'check-{n}.stderr').open('w') as stderr:
  result=subprocess.run(command,cwd=out/'source',stdout=stdout,stderr=stderr)
 results.append({'command':command,'returncode':result.returncode})
 if result.returncode:break
(out/'checks.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results))
sys.exit(any(x['returncode'] for x in results))

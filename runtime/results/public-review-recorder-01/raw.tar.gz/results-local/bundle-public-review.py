import json,hashlib,tarfile,subprocess
from pathlib import Path
r=Path(__file__).resolve().parents[1];out=r/'runtime/results/public-review-recorder-01';out.mkdir(exist_ok=False)
paths=list((r/'results-local/public-review-retained-01').rglob('*'))+list((r/'results-local/public-review-tests-01').rglob('*'))
paths += [r/'results-local/check-public-review-retained.mjs',Path(__file__)]
paths += [r/'research/live_control'/n for n in ('native_relay_client_v1.mjs','relay_host_timeline_v1.mjs','test_native_relay_client_v1.mjs','test_relay_host_timeline_v1.mjs')]
manifest={}
with tarfile.open(out/'raw.tar.gz','w:gz') as archive:
 for p in sorted(paths):
  if not p.is_file():continue
  data=p.read_bytes();name=p.relative_to(r).as_posix();manifest[name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)};archive.add(p,arcname=name)
(out/'manifest.json').write_text(json.dumps({'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'files':manifest},indent=2)+'\n')
print(len(manifest))

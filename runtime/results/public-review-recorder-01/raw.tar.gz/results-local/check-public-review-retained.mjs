import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {join,dirname} from 'node:path';
import {recordRelayReview} from '../research/live_control/native_relay_client_v1.mjs';
const local=dirname(fileURLToPath(import.meta.url)),out=join(local,'public-review-retained-01');
await mkdir(out);const rows=[];
for(let n=1;n<=8;n++) {
 const replyPath=join(local,'calc-compact-primary-01','host',`reply-${n}.json`);
 const bytes=await readFile(replyPath);const reply=JSON.parse(bytes);
 const hasImage=reply.result.content.some(c=>c.type==='image');
 const args={replyPath,receiptPath:join(out,`review-${n}.json`),task:'calc-991351',phase:'retrospective-recorder-check',reason:'Offline recorder validation on an earlier primary reply; original review notes remain separate. No new live review or timing measurement.'};
 let accepted=false,error=null;
 try {await recordRelayReview(args);accepted=true;}catch(e){error=String(e);}
 if(accepted!==hasImage)throw new Error(`unexpected acceptance for reply ${n}`);
 rows.push({attempt:n,tool:reply.tool,reply_sha256:createHash('sha256').update(bytes).digest('hex'),hasImage,accepted,error});
}
await writeFile(join(out,'result.json'),JSON.stringify({scope:'offline retained-response recorder check; no new GUI/model review',rows},null,2)+'\n');
console.log(JSON.stringify({accepted:rows.filter(r=>r.accepted).length,rejected:rows.filter(r=>!r.accepted).length}));

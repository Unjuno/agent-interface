import hashlib,json,tarfile
from pathlib import Path
root=Path(__file__).resolve().parent
out=Path('runtime/results/portable-live-compact-01')
out.mkdir(parents=True,exist_ok=False)
dispatch=json.loads((root/'dispatch-stdout.json').read_bytes())
effect=json.loads((root/'effect.json').read_bytes())
assert effect=={'saved':True,'text':'portable-3514'}
assert dispatch['outcome_summary']['execution_status']=='completed'
assert dispatch['receipt']['report']['result']['execution']['releases'][-1]['verified'] is True
files=[]
with tarfile.open(out/'evidence.tar.gz','w:gz') as archive:
    for path in sorted(root.rglob('*')):
        if path.is_file():
            data=path.read_bytes(); name=path.relative_to(root).as_posix()
            files.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
            archive.add(path,arcname=name,recursive=False)
with tarfile.open(out/'evidence.tar.gz') as archive:
    for item in files:
        data=archive.extractfile(item['path']).read()
        assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
result={'source_commit':'7d12e7afc1b1db163b74a54a821658c8c867e5c7',
        'recorded_root':str(root),'effect':effect,'dispatch_count':1,'observe_count':2,
        'receipt_schema':dispatch['receipt']['schema'],
        'cleanup':json.loads((root/'cleanup.json').read_bytes()),
        'call':json.loads((root/'dispatch-call.json').read_bytes()),'inventory':files}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'files':len(files),'effect':effect,'receipt_schema':result['receipt_schema']}))

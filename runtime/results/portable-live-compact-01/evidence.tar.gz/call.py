import json, subprocess, sys, time
from pathlib import Path
root=Path(__file__).resolve().parent
mode=sys.argv[1]
args=[sys.executable,str(root/'agent-interface-runtime.pyz'),mode,'--targets',str(root/'targets.json'),'--display',':248','--capture-directory',str(root/'images'),'--review','--compact']
if mode=='observe':
    args+=['--target','fixture','--frame','window_client','--region','0','0','400','180']
elif mode=='dispatch':
    program=json.loads((root/'decision.json').read_bytes())
    program['authority']['expires_at_ns']=time.monotonic_ns()+10_000_000_000
    (root/'program.json').write_text(json.dumps(program))
    args+=['--program',str(root/'program.json'),'--current-observation-seq','1','--current-binding-revision','0']
else: raise ValueError(mode)
(root/(mode+'-command.json')).write_text(json.dumps(args))
started=time.monotonic_ns()
result=subprocess.run(args,cwd=root,capture_output=True)
ended=time.monotonic_ns()
(root/(mode+'-stdout.json')).write_bytes(result.stdout)
(root/(mode+'-stderr.txt')).write_bytes(result.stderr)
(root/(mode+'-call.json')).write_text(json.dumps({'returncode':result.returncode,'started_ns':started,'returned_ns':ended}))
print(json.dumps({'returncode':result.returncode,'path':str(root/(mode+'-stdout.json'))}))

import json,hashlib,xml.etree.ElementTree as ET,subprocess
from pathlib import Path
root=Path('results-local/calc-3700-matched-01'); plan=json.loads((root/'PLAN.json').read_text());results=[]
ns={'t':'urn:oasis:names:tc:opendocument:xmlns:table:1.0','o':'urn:oasis:names:tc:opendocument:xmlns:office:1.0'}
for name,digest in json.loads((root/'FREEZE.json').read_text()).items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for spec in plan['rows']:
 r=root/f"row-{spec['row']}"
 declared=json.loads((r/'primary-declaration.json').read_text())
 cells=ET.fromstring((r/'invoice.fods').read_bytes()).findall('.//t:table-row',ns)[1].findall('t:table-cell',ns)[:3]
 values=[c.get('{'+ns['o']+'}value') for c in cells];formula=cells[2].get('{'+ns['t']+'}formula')
 assert values==[str(spec['a']),str(spec['b']),str(spec['expected'])]
 assert formula=='of:=[.B2]*[.A2]'
 raw=json.loads((r/'attempts/action-1/report.json').read_bytes());ex=raw['result']['execution']
 assert raw['result']['status']=='completed' and ex['releases'][-1]['verified'] is True
 assert ex['waits'][-1]['requested_ms']==spec['wait_ms']
 expected=json.loads((r/'prepared-request.json').read_text())['arguments']['program']
 actual=raw['compilation']['source_program'];actual['authority']['expires_at_ns']=expected['authority']['expires_at_ns'];assert actual==expected
 for f in r.glob('*-stdout.json'):
  meta=json.loads(f.read_bytes()); assert meta.get('image_status')=='image'
  assert meta['receipt']['source']['raw_report']==json.loads((r/'attempts'/f.name.removesuffix('-stdout.json')/'report.json').read_bytes())
 command_time=json.loads((r/'action-1-timing.json').read_text())
 state=json.loads(subprocess.check_output(['docker','inspect',f"ai-calc-3700-row-{spec['row']}"]))[0]['State']
 assert state['Status']=='exited' and state['ExitCode']==0
 (r/'container-state.json').write_text(json.dumps(state,indent=2))
 results.append(dict(spec,saved_correct=True,release_verified=True,extra_observations=declared['extra_observations'],cli_roundtrip_ms=(command_time['ended_ns']-command_time['started_ns'])/1e6,runtime_ms=(ex['ended_ns']-ex['started_ns'])/1e6,actual_final_wait_ms=(ex['waits'][-1]['ended_ns']-ex['waits'][-1]['started_ns'])/1e6,initial_png_sha256=hashlib.sha256((r/'initial.png').read_bytes()).hexdigest(),container_exit=0))
report={'decision':'HOLD_PRODUCTION_ADOPTION','rows':results,'scope':'two paired tasks; same primary host; descriptive observation counts and correctness only','unavailable':['exact provider build/config','actual model tokens/cost','host image-render endpoint','separate host receipt timestamp'],'warning':'CLI/runtime intervals do not measure model-useful feedback. Fixed order, cache and model context/order effects not removed. No held-out validation.'}
(root/'RESULT.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
(root/'EVIDENCE_SHA256.json').write_text(json.dumps({str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file() and p.name!='EVIDENCE_SHA256.json'},indent=2))

import subprocess,json,sys
from pathlib import Path
commands={
 'audit':['python3','-B','/input/source/source/audit.py','/input/evidence'],
 'controls':['python3','-B','/input/source/source/controls.py','/input/evidence','formal','/tmp/controls'],
 'policy_tests':['python3','-B','-m','unittest','-v','test_policy']}
rows={}
for name,command in commands.items():
 r=subprocess.run(command,cwd='/input/source/source',capture_output=True,text=True)
 rows[name]={'command':command,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
print(json.dumps({'python':sys.version,'runs':rows},indent=2))
raise SystemExit(any(r['returncode'] for r in rows.values()))

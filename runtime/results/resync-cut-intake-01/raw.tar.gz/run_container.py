import subprocess,json
from pathlib import Path
root=Path(__file__).resolve().parent
image='sha256:2f17fc044b579bab302c2e8054d3a686e2cb9a83de48e70534b94cd8ebbe06a9'
args=['docker','create','--name','agent-interface-resync-intake-01','--network','none','--read-only',
 '--cpus','1','--memory','256m','--pids-limit','64','--cap-drop','ALL',
 '--security-opt','no-new-privileges','--tmpfs','/tmp:rw,nosuid,noexec,size=16m',
 '--mount',f'type=bind,src={root},dst=/input,readonly',
 image,'python3','-B','/input/run_inside.py']
(root/'container-command.json').write_text(json.dumps(args,indent=2)+'\n')
created=subprocess.run(args,capture_output=True,text=True)
(root/'create.stdout').write_text(created.stdout);(root/'create.stderr').write_text(created.stderr)
if created.returncode:raise SystemExit(created.returncode)
cid=created.stdout.strip()
r=subprocess.run(['docker','start','-a',cid],capture_output=True,text=True)
(root/'container.stdout.json').write_text(r.stdout);(root/'container.stderr.log').write_text(r.stderr)
inspection=subprocess.check_output(['docker','inspect',cid])
(root/'container-inspect.json').write_bytes(inspection)
(root/'exit.json').write_text(json.dumps({'docker_start_exit':r.returncode,'container_exit':json.loads(inspection)[0]['State']['ExitCode']})+'\n')
print('container',cid,'exit',r.returncode)
raise SystemExit(r.returncode)

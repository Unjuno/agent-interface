"""Read-only independent raw reconstruction. Imports no policy/actor/runner."""
import json,sys,hashlib,copy,struct
from pathlib import Path
SC=['IN_ORDER','DELAYED_BEFORE_CUT','DELAYED_AFTER_FUTURE','STALE_SNAPSHOT','FOREIGN_SNAPSHOT','MISSING_SNAPSHOT','POST_CUT_GAP']
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def lines(p):return [json.loads(s) for s in p.read_text().splitlines()]
def audit_case(p,scenario,session):
    errors=[];checks=0
    def ck(test,name):
        nonlocal checks
        checks+=1
        if not test:errors.append(name)
    try:
        r=json.loads((p/'CASE.json').read_text());ck(r['scenario']==scenario and r['session']==session,'IDENTITY')
        ck(r['complete'] is True and r['error'] is None,'COMPLETE');ck(r['cleanup'] is True,'CLEANUP')
        ck(r['server_alive_before_shutdown'] is True,'SERVER_LIVE')
        ck(set(r['processes'])=={'server','producer','observer'},'PROCESS_SET')
        ck(len({v['pid'] for v in r['processes'].values()})==3,'DISTINCT_PROCESSES')
        for n,v in r['processes'].items():
            ck(type(v['pid']) is int and v['pid']>0 and v['exit']==0,'EXIT:'+n)
            ck((p/(n+'.stderr')).exists(),'STDERR:'+n)
        ck('-nolisten' in r['processes']['server']['argv'] and 'tcp' in r['processes']['server']['argv'],'TCP_DISABLED')
        recv={n:[] for n in ('producer','observer')};commands={n:[] for n in recv}; exchanges={}
        previous=0
        for w in r['wire']:
            ck(w['ns']>=previous,'WIRE_TIME');previous=w['ns'];q=json.loads(w['raw']);peer=w['peer']
            if w['direction']=='SEND':
                commands[peer].append(q);exchanges[(peer,q['rid'])]=[w['ns'],None]
            else:
                recv[peer].append(q);ck(q['pid']==r['processes'][peer]['pid'],'REPLY_PID');ck(q['ns']<=w['ns'],'REPLY_TIME')
                if 'rid' in q:
                    a=exchanges[(peer,q['rid'])];a[1]=w['ns'];ck(a[0]<=q['ns'],'REQUEST_REPLY_ORDER')
        for n in recv:
            j=lines(p/(n+'.jsonl'));ck([x['reply'] for x in j if 'reply'in x]==recv[n],'JOURNAL_REPLY:'+n)
            ck([x['request'] for x in j if 'request'in x]==commands[n],'JOURNAL_REQUEST:'+n)
            ck(recv[n][0]['kind']=='READY' and recv[n][-1]['kind']=='CLOSED','LIFECYCLE:'+n)
            for x in j:
                if 'request'in x:
                    pair=exchanges[(n,x['request']['rid'])];ck(pair[0]<=x['ns']<=pair[1],'JOURNAL_ORDER')
        nmax=6 if scenario=='POST_CUT_GAP' else 5 if scenario in ('IN_ORDER','DELAYED_AFTER_FUTURE') else 4
        writes=[x for x in recv['producer'] if x['kind']=='WRITTEN'];native=[x for x in recv['observer'] if x['kind']=='NATIVE'];snaps=[x for x in recv['observer'] if x['kind']=='SNAPSHOT']
        ck(len(writes)==len(native)==nmax,'NATIVE_COUNT');ck(len(snaps)==3,'SNAPSHOT_COUNT')
        def record(n):return {'session':session,'source_epoch':1,'seq':n,'value':'value-'+str(n)}
        xid=r['producer_ready']['xid'];atom=r['producer_ready']['atom']
        arm=[x for x in recv['observer'] if x['kind']=='ARMED'];ck(len(arm)==1 and arm[0]['mask']==4194304,'SUBSCRIPTION')
        for i,(w,o) in enumerate(zip(writes,native),1):
            ck(w['record']==o['record']==record(i),'NATIVE_RECORD')
            ck(w['raw_hex']==o['raw_hex'],'NATIVE_BYTES')
            ck(json.loads(bytes.fromhex(o['raw_hex']))==record(i),'DECODED_PROPERTY')
            b=bytes.fromhex(o['event_hex']);ck(len(b)==32,'NATIVE_LENGTH')
            if len(b)==32:
                order='<' if r['byteorder']=='little' else '>'
                ck(b[0]==28 and o['type']==28 and o['send_event'] is False,'NATIVE_TYPE')
                ck(struct.unpack_from(order+'II',b,4)==(xid,atom) and o['window']==xid and o['atom']==atom,'NATIVE_WINDOW_ATOM')
            ck(o['format']==8 and o['property_type']==31 and o['bytes_after']==0,'PROPERTY_FORMAT')
            ck(w['ns']<=o['ns'],'WRITE_READ_ORDER')
        for o,n in zip(snaps,(2,4,nmax)):
            ck(o['record']==record(n) and json.loads(bytes.fromhex(o['raw_hex']))==record(n),'SNAPSHOT_BYTES')
        ck(r['final_capture']==snaps[-1],'FINAL_CAPTURE')
        gap={'id':session+':gap3','missing':[3]}
        chosen=record(2 if scenario=='STALE_SNAPSHOT' else 4)
        if scenario=='FOREIGN_SNAPSHOT':chosen['session']='foreign:'+session
        if scenario=='MISSING_SNAPSHOT':chosen=None
        qs=[{'op':'EVENT','record':record(1)},{'op':'GAP','gap':gap,'frontier':4},{'op':'SNAPSHOT','gap_id':gap['id'],'record':chosen}]
        follow={'IN_ORDER':[5],'DELAYED_BEFORE_CUT':[2],'DELAYED_AFTER_FUTURE':[5,2],'POST_CUT_GAP':[6]}.get(scenario,[])
        qs.extend({'op':'EVENT','record':record(n)} for n in follow)
        ck(r['inputs']==qs,'DELIVERY_BINDING')
        dt=r['delivery_times'];ck(len(dt)==len(qs),'DELIVERY_TIMES')
        ck(all(x['start_ns']<=x['end_ns'] for x in dt) and all(x['end_ns']<=y['start_ns'] for x,y in zip(dt,dt[1:])),'DELIVERY_ORDER')
        ck(snaps[1]['ns']<=dt[0]['start_ns']<=dt[2]['end_ns']<=snaps[-1]['ns'],'SNAPSHOT_DELIVERY_ORDER')
        if nmax>4:ck(dt[2]['end_ns']<=writes[4]['ns']<=native[-1]['ns']<=dt[-1]['start_ns'],'FUTURE_AFTER_SNAPSHOT')
        ck(set(r['decisions'])=={'BLIND_APPLY','CUT_CONTIGUOUS'},'POLICY_SET')
        metrics={'cases':1,'native_events':nmax,'actor_exits':3,'candidate_rollbacks':0,'weak_rollbacks':0,'candidate_unresolved_future':0,'weak_false_future_complete':0,'invalid_snapshot_refusals':0,'positive_current':0}
        for mode in ('BLIND_APPLY','CUT_CONTIGUOUS'):
            states=[]
            s={'current':record(1),'seq':1,'cut':None,'epoch':1,'coverage':'COMPLETE_FROM_START','active_gap':None,'historical_gaps':[],'frontier':0,'authority':False}
            def add(reason):states.append({'reason':reason,'state':copy.deepcopy(s)})
            add('EVENT_APPLIED');s.update(active_gap=gap,frontier=4,coverage='GAPPED');add('GAP_RECORDED')
            negative={'STALE_SNAPSHOT':'STALE_SNAPSHOT','FOREIGN_SNAPSHOT':'SCOPE_MISMATCH','MISSING_SNAPSHOT':'SNAPSHOT_UNAVAILABLE'}
            if scenario in negative:add(negative[scenario]);metrics['invalid_snapshot_refusals']+=1
            else:
                s.update(current=record(4),seq=4,cut=4,epoch=2,coverage='COMPLETE_SINCE_CUT',active_gap=None,historical_gaps=[gap]);add('SNAPSHOT_INSTALLED')
                for n in follow:
                    if mode=='CUT_CONTIGUOUS' and n==2:add('OLD_OR_DUPLICATE')
                    elif mode=='CUT_CONTIGUOUS' and n==6:
                        s.update(active_gap={'id':session+':future','missing':[5]},frontier=6,coverage='GAPPED');add('FUTURE_GAP')
                    else:s.update(current=record(n),seq=n);add('EVENT_APPLIED')
            actual=r['decisions'][mode];ck(actual==states,'POLICY_TRANSITIONS:'+mode)
            for a in actual:ck(a['state']['authority'] is False,'NO_AUTHORITY')
            last=actual[-1]['state']
            if scenario in ('DELAYED_BEFORE_CUT','DELAYED_AFTER_FUTURE'):
                rollback=int(last['current']!=record(nmax))
                metrics['candidate_rollbacks' if mode=='CUT_CONTIGUOUS' else 'weak_rollbacks']+=rollback
            if scenario=='POST_CUT_GAP':
                if mode=='CUT_CONTIGUOUS':metrics['candidate_unresolved_future']+=int(last['coverage']=='GAPPED')
                else:metrics['weak_false_future_complete']+=int(last['coverage']=='COMPLETE_SINCE_CUT')
            if scenario=='IN_ORDER':metrics['positive_current']+=int(last['current']==record(5))
        return {'checks':checks,'errors':errors,'metrics':metrics}
    except (KeyError,TypeError,ValueError,IndexError,FileNotFoundError) as e:
        return {'checks':checks,'errors':errors+['STRUCTURE:'+type(e).__name__],'metrics':{}}

def audit(root):
    errors=[];checks=0;metrics={}
    freeze=json.loads((root/'FREEZE.json').read_text())
    for n,h in freeze['sha256'].items():
        checks+=1
        if digest(root/n)!=h:errors.append('SOURCE:'+n)
    for b,scenario in enumerate(SC):
        p=root/'formal'/('batch%d'%b);launch=json.loads((root/'formal'/('launch%d.json'%b)).read_text());begin=json.loads((p/'BEGIN.json').read_text());end=json.loads((p/'END.json').read_text())
        checks+=4
        if launch['exit']!=0 or launch['timeout']:errors.append('LAUNCH:'+str(b))
        if begin['pid']!=end['pid'] or begin['pid']!=launch['pid']:errors.append('BATCH_PID')
        if not launch['start_ns']<=begin['ns']<=end['ns']<=launch['end_ns'] or end['cases']!=2:errors.append('BATCH_ORDER')
        if begin['freeze_sha256']!=digest(root/'FREEZE.json'):errors.append('BATCH_FREEZE')
        for rep in range(2):
            a=audit_case(p/('r%d'%rep),scenario,f'rsq2-formal-b{b}-r{rep}');checks+=a['checks'];errors.extend(f'b{b}r{rep}:'+x for x in a['errors'])
            for k,v in a['metrics'].items():metrics[k]=metrics.get(k,0)+v
    expected={'cases':14,'native_events':64,'actor_exits':42,'candidate_rollbacks':0,'weak_rollbacks':4,'candidate_unresolved_future':2,'weak_false_future_complete':2,'invalid_snapshot_refusals':12,'positive_current':4}
    checks+=1
    if metrics!=expected:errors.append('GLOBAL_ENDPOINTS')
    return {'decision':'PASS_X11_RESYNC_CUT_SCOPED' if not errors else 'HOLD_OR_FAIL_AUDIT','checks':checks,'errors':errors,'metrics':metrics}
if __name__=='__main__':
    if sys.argv[1]=='case':
        p=Path(sys.argv[2]);r=json.loads((p/'CASE.json').read_text());a=audit_case(p,r['scenario'],r['session'])
    else:a=audit(Path(sys.argv[1]))
    print(json.dumps(a,sort_keys=True,indent=2));raise SystemExit(bool(a['errors']))

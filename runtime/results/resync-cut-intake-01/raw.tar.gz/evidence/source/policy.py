"""Research-only observation reducer; no X11, task inputs or source oracle access."""
from copy import deepcopy

class Reducer:
    def __init__(self, mode, session):
        if mode not in ('BLIND_APPLY','CUT_CONTIGUOUS'): raise ValueError('mode')
        self.mode=mode; self.session=session
        self.s={'current':None,'seq':0,'cut':None,'epoch':1,'coverage':'NO_BASE',
                'active_gap':None,'historical_gaps':[],'frontier':0,'authority':False}
    def apply(self, q):
        s=self.s; op=q['op']; r=q.get('record'); reason=''
        if op=='GAP':
            s['frontier']=q['frontier'];s['active_gap']=deepcopy(q['gap']);s['coverage']='GAPPED';reason='GAP_RECORDED'
        elif op=='SNAPSHOT':
            if r is None: reason='SNAPSHOT_UNAVAILABLE'
            elif r['session']!=self.session or r['source_epoch']!=1: reason='SCOPE_MISMATCH'
            elif s['active_gap'] is None or q['gap_id']!=s['active_gap']['id']: reason='GAP_MISMATCH'
            elif r['seq']<s['frontier']: reason='STALE_SNAPSHOT'
            else:
                s['historical_gaps'].append(deepcopy(s['active_gap']));s['active_gap']=None
                s['current']=deepcopy(r);s['seq']=r['seq'];s['cut']=r['seq'];s['epoch']+=1
                s['coverage']='COMPLETE_SINCE_CUT';reason='SNAPSHOT_INSTALLED'
        elif op=='EVENT':
            if r['session']!=self.session or r['source_epoch']!=1: reason='SCOPE_MISMATCH'
            elif s['coverage']=='GAPPED':reason='RESYNC_REQUIRED'
            elif self.mode=='CUT_CONTIGUOUS' and r['seq']<=s['seq']:reason='OLD_OR_DUPLICATE'
            elif self.mode=='CUT_CONTIGUOUS' and r['seq']!=s['seq']+1:
                s['active_gap']={'id':self.session+':future','missing':list(range(s['seq']+1,r['seq']))}
                s['frontier']=r['seq'];s['coverage']='GAPPED';reason='FUTURE_GAP'
            else:
                s['current']=deepcopy(r);s['seq']=r['seq'];reason='EVENT_APPLIED'
                if s['coverage']=='NO_BASE':s['coverage']='COMPLETE_FROM_START'
        else:raise ValueError('unknown operation')
        return {'reason':reason,'state':deepcopy(s)}

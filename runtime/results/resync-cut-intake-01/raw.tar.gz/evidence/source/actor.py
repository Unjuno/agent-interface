"""Private cooperative native producer/observer. All replies are journaled independently."""
import json,os,sys,time
from pathlib import Path
from Xlib import X,Xatom,display
role=sys.argv[1]; journal=Path(sys.argv[2]).open('x'); d=display.Display()
def log(x):
    journal.write(json.dumps(x,sort_keys=True)+'\n');journal.flush()
def answer(x):
    x={'pid':os.getpid(),'ns':time.monotonic_ns(),**x};log({'reply':x});print(json.dumps(x,sort_keys=True),flush=True)
def payload():
    p=w.get_full_property(atom,X.AnyPropertyType)
    if p is None:raise RuntimeError('property unavailable')
    v=p.value;raw=v.encode('latin1') if isinstance(v,str) else bytes(v)
    return {'raw_hex':raw.hex(),'record':json.loads(raw),'format':p.format,'property_type':p.property_type,'bytes_after':p.bytes_after}
if role=='producer':
    w=d.screen().root.create_window(0,0,64,64,0,X.CopyFromParent,X.InputOutput,X.CopyFromParent)
    atom=d.intern_atom('RSQ2_COMPLETE_STATE');w.map();d.sync();answer({'kind':'READY','xid':w.id,'atom':atom})
else:answer({'kind':'READY'})
for line in sys.stdin:
    q=json.loads(line);log({'request':q,'ns':time.monotonic_ns()});op=q['op'];rid=q['rid']
    if op=='CLOSE':
        if role=='producer':w.destroy();d.sync()
        answer({'kind':'CLOSED','rid':rid});break
    if role=='producer':
        if op!='PUT':raise ValueError(op)
        raw=json.dumps(q['record'],sort_keys=True,separators=(',',':')).encode('utf-8')
        w.change_property(atom,Xatom.STRING,8,raw,X.PropModeReplace);d.sync()
        answer({'kind':'WRITTEN','rid':rid,'raw_hex':raw.hex(),'record':q['record']})
    elif op=='ARM':
        w=d.create_resource_object('window',q['xid']);atom=q['atom'];w.change_attributes(event_mask=X.PropertyChangeMask);d.sync()
        answer({'kind':'ARMED','rid':rid,'mask':w.get_attributes().your_event_mask,'xid':w.id,'atom':atom})
    elif op=='SNAPSHOT':answer({'kind':'SNAPSHOT','rid':rid,**payload()})
    elif op=='NEXT':
        end=time.monotonic()+3
        while not d.pending_events():
            if time.monotonic()>end:raise TimeoutError('native event')
            time.sleep(.001)
        e=d.next_event();b=e._binary
        if isinstance(b,str):b=b.encode('latin1')
        answer({'kind':'NATIVE','rid':rid,'type':e.type,'window':e.window.id,'atom':e.atom,
                'event_hex':bytes(b).hex(),'send_event':bool(e.send_event),**payload()})
    else:raise ValueError(op)
d.close();journal.close()

"""Exclusive, bounded first-outcome batches. No native keyboard or mouse input."""
import os,sys,json,time,select,socket,struct,subprocess,signal,hashlib,copy
from pathlib import Path
from policy import Reducer
SRC=Path(__file__).resolve().parent;ROOT=SRC.parent
SCENARIOS=['IN_ORDER','DELAYED_BEFORE_CUT','DELAYED_AFTER_FUTURE','STALE_SNAPSHOT','FOREIGN_SNAPSHOT','MISSING_SNAPSHOT','POST_CUT_GAP']
def dump(p,x):p.write_text(json.dumps(x,sort_keys=True,indent=2)+'\n')
def stop(signum,frame):raise TimeoutError('supervisor signal')
signal.signal(signal.SIGTERM,stop)
def case(p,scenario,session):
    p.mkdir(); ps={};hs=[];disp=24000+os.getpid()%12000;auth=p/'private.auth'
    r={'session':session,'scenario':scenario,'complete':False,'wire':[],'processes':{},'decisions':{},'inputs':[],'error':None,'byteorder':sys.byteorder}
    def get(name):
        proc=ps[name]
        if not select.select([proc.stdout],[],[],3)[0]:raise TimeoutError(name)
        line=proc.stdout.readline()
        if not line:raise RuntimeError(name+' EOF')
        r['wire'].append({'peer':name,'direction':'RECV','raw':line,'ns':time.monotonic_ns()});return json.loads(line)
    def call(name,q):
        q={'rid':len(r['wire']),**q};line=json.dumps(q,sort_keys=True)+'\n'
        r['wire'].append({'peer':name,'direction':'SEND','raw':line,'ns':time.monotonic_ns()})
        ps[name].stdin.write(line);ps[name].stdin.flush();a=get(name)
        if a.get('rid')!=q['rid']:raise RuntimeError('request mismatch')
        return a
    try:
        while Path('/tmp/.X11-unix/X'+str(disp)).exists() or Path('/tmp/.X'+str(disp)+'-lock').exists():disp+=1
        fields=[socket.gethostname().encode(),str(disp).encode(),b'MIT-MAGIC-COOKIE-1',os.urandom(16)]
        auth.write_bytes(struct.pack('>H',256)+b''.join(struct.pack('>H',len(x))+x for x in fields));auth.chmod(0o600)
        env=dict(os.environ,DISPLAY=':'+str(disp),XAUTHORITY=str(auth),PYTHONDONTWRITEBYTECODE='1')
        for name in ('server','producer','observer'):
            err=(p/(name+'.stderr')).open('x');hs.append(err)
            cmd=['Xvfb',env['DISPLAY'],'-screen','0','100x80x24','-auth',str(auth),'-nolisten','tcp','-noreset'] if name=='server' else [sys.executable,'-B',str(SRC/'actor.py'),name,str(p/(name+'.jsonl'))]
            if name=='server':
                out=(p/'server.stdout').open('x');hs.append(out);proc=subprocess.Popen(cmd,stdout=out,stderr=err,env=env)
            else:proc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,bufsize=1,env=env)
            ps[name]=proc;r['processes'][name]={'pid':proc.pid,'argv':cmd,'exit':None}
            if name=='server':
                deadline=time.monotonic()+3
                while not Path('/tmp/.X11-unix/X'+str(disp)).exists():
                    if proc.poll() is not None or time.monotonic()>deadline:raise RuntimeError('Xvfb startup')
                    time.sleep(.002)
            else:r[name+'_ready']=get(name)
        call('observer',{'op':'ARM','xid':r['producer_ready']['xid'],'atom':r['producer_ready']['atom']})
        native={};snap={}; reducers={m:Reducer(m,session) for m in ('BLIND_APPLY','CUT_CONTIGUOUS')}
        r['delivery_times']=[];r['decisions']={m:[] for m in reducers}
        def offer(q):
            start=time.monotonic_ns();r['inputs'].append(copy.deepcopy(q))
            for m,policy in reducers.items():r['decisions'][m].append(policy.apply(copy.deepcopy(q)))
            r['delivery_times'].append({'start_ns':start,'end_ns':time.monotonic_ns()})
        def emit(seq):
            rec={'session':session,'source_epoch':1,'seq':seq,'value':'value-'+str(seq)}
            call('producer',{'op':'PUT','record':rec});a=call('observer',{'op':'NEXT'});native[seq]=a['record']
            if a['record']!=rec:raise RuntimeError('capture binding')
        for n in range(1,5):
            emit(n)
            if n in (2,4):snap[n]=call('observer',{'op':'SNAPSHOT'})['record']
        gap={'id':session+':gap3','missing':[3]}
        offer({'op':'EVENT','record':native[1]});offer({'op':'GAP','gap':gap,'frontier':4})
        s=copy.deepcopy(snap[2 if scenario=='STALE_SNAPSHOT' else 4])
        if scenario=='FOREIGN_SNAPSHOT':s['session']='foreign:'+session
        if scenario=='MISSING_SNAPSHOT':s=None
        offer({'op':'SNAPSHOT','gap_id':gap['id'],'record':s})
        if scenario in ('IN_ORDER','DELAYED_AFTER_FUTURE'):emit(5);offer({'op':'EVENT','record':native[5]})
        if scenario in ('DELAYED_BEFORE_CUT','DELAYED_AFTER_FUTURE'):offer({'op':'EVENT','record':native[2]})
        if scenario=='POST_CUT_GAP':
            emit(5);emit(6);offer({'op':'EVENT','record':native[6]})
        r['final_capture']=call('observer',{'op':'SNAPSHOT'})
        for name in ('observer','producer'):
            call(name,{'op':'CLOSE'});r['processes'][name]['exit']=ps[name].wait(timeout=3)
        r['server_alive_before_shutdown']=ps['server'].poll() is None;r['complete']=True
    except Exception as e:r['error']=type(e).__name__+':'+str(e)
    finally:
        for name,proc in ps.items():
            if proc.poll() is None:proc.terminate()
            try:code=proc.wait(timeout=3)
            except subprocess.TimeoutExpired:proc.kill();code=proc.wait();r['error']='forced kill';r['complete']=False
            r['processes'][name]['exit']=code
        for h in hs:h.close()
        if auth.exists():auth.unlink()
        r['display']=disp;r['cleanup']=not Path('/tmp/.X11-unix/X'+str(disp)).exists() and not Path('/tmp/.X'+str(disp)+'-lock').exists()
        dump(p/'CASE.json',r)
    if not r['complete'] or any(v['exit']!=0 for v in r['processes'].values()):raise RuntimeError(r['error'] or 'child exit')
    return r
if __name__=='__main__':
    phase=sys.argv[1];batch=int(sys.argv[2]);p=ROOT/phase/('batch%d'%batch);p.mkdir(parents=True,exist_ok=False)
    frozen=hashlib.sha256((ROOT/'FREEZE.json').read_bytes()).hexdigest() if phase=='formal' else None
    dump(p/'BEGIN.json',{'pid':os.getpid(),'ns':time.monotonic_ns(),'freeze_sha256':frozen})
    # Two new session identities per batch. Formal has one scenario per batch.
    for rep in range(2):case(p/('r%d'%rep),SCENARIOS[batch],f'rsq2-{phase}-b{batch}-r{rep}')
    dump(p/'END.json',{'pid':os.getpid(),'ns':time.monotonic_ns(),'cases':2})

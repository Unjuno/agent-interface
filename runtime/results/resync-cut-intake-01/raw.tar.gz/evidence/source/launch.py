import subprocess,sys,time,json,os,signal
from pathlib import Path
root=Path(__file__).resolve().parent.parent;phase=sys.argv[1]
for b in map(int,sys.argv[2:]):
    dst=root/phase;dst.mkdir(exist_ok=True)
    receipt=dst/f'launch{b}.json'
    if receipt.exists() or (dst/f'batch{b}').exists():raise RuntimeError('allocation already consumed')
    cmd=[sys.executable,'-B',str(root/'source/runner.py'),phase,str(b)]
    with (dst/f'launch{b}.stdout').open('x') as out,(dst/f'launch{b}.stderr').open('x') as err:
        t=time.monotonic_ns();p=subprocess.Popen(cmd,stdout=out,stderr=err,start_new_session=True);timed=False
        try:code=p.wait(timeout=12)
        except subprocess.TimeoutExpired:
            timed=True;os.killpg(p.pid,signal.SIGTERM)
            try:code=p.wait(timeout=4)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
        receipt.write_text(json.dumps({'argv':cmd,'pid':p.pid,'start_ns':t,'end_ns':time.monotonic_ns(),'exit':code,'timeout':timed},sort_keys=True,indent=2)+'\n')
        print(phase,b,code,flush=True)
        if code or timed:raise SystemExit(1)

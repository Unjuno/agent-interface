import unittest
from policy import Reducer

def rec(n):return {'session':'unit','source_epoch':1,'seq':n,'value':'value-'+str(n)}
class Tests(unittest.TestCase):
    def base(self,mode='CUT_CONTIGUOUS'):
        r=Reducer(mode,'unit');r.apply({'op':'EVENT','record':rec(1)})
        r.apply({'op':'GAP','frontier':4,'gap':{'id':'unit:g','missing':[3]}});return r
    def snap(self,r):return r.apply({'op':'SNAPSHOT','record':rec(4),'gap_id':'unit:g'})
    def test_old_after_cut(self):
        r=self.base();self.snap(r);x=r.apply({'op':'EVENT','record':rec(2)})
        self.assertEqual(x['reason'],'OLD_OR_DUPLICATE');self.assertEqual(x['state']['seq'],4)
    def test_old_after_future(self):
        r=self.base();self.snap(r);r.apply({'op':'EVENT','record':rec(5)});x=r.apply({'op':'EVENT','record':rec(2)})
        self.assertEqual(x['state']['seq'],5)
    def test_new_gap(self):
        r=self.base();self.snap(r);x=r.apply({'op':'EVENT','record':rec(6)})
        self.assertEqual(x['state']['coverage'],'GAPPED');self.assertEqual(x['state']['seq'],4)
    def test_stale(self):
        r=self.base();x=r.apply({'op':'SNAPSHOT','record':rec(2),'gap_id':'unit:g'})
        self.assertEqual(x['reason'],'STALE_SNAPSHOT');self.assertEqual(x['state']['epoch'],1)
    def test_missing(self):
        r=self.base();x=r.apply({'op':'SNAPSHOT','record':None,'gap_id':'unit:g'})
        self.assertEqual(x['reason'],'SNAPSHOT_UNAVAILABLE')
    def test_history_retained(self):
        r=self.base();self.snap(r);x=r.apply({'op':'EVENT','record':rec(5)})
        self.assertEqual(x['state']['historical_gaps'],[{'id':'unit:g','missing':[3]}]);self.assertFalse(x['state']['authority'])
    def test_weak_counterexample(self):
        r=self.base('BLIND_APPLY');self.snap(r);x=r.apply({'op':'EVENT','record':rec(2)})
        self.assertEqual(x['state']['seq'],2)
if __name__=='__main__':unittest.main(verbosity=2)

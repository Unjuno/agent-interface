"""Effective copied-evidence controls; no original data is modified."""
import sys,json,copy,shutil,hashlib
from pathlib import Path
from audit import audit_case

def execute(root,phase,out):
    out.mkdir(parents=True,exist_ok=False);results=[]
    specs=[('missing_input',2),('duplicate_input',2),('snapshot_cut',2),('authority',2),
           ('rollback',2),('history',2),('epoch',2),('old_reason',2),('future_coverage',6),
           ('native_type',2),('property_bytes',2),('actor_exit',2)]
    for name,b in specs:
        original=root/phase/f'batch{b}/r0';p=out/name;shutil.copytree(original,p)
        qpath=p/'CASE.json';before=qpath.read_bytes();r=json.loads(before)
        a=r['decisions']['CUT_CONTIGUOUS']
        if name=='missing_input':r['inputs'].pop()
        elif name=='duplicate_input':r['inputs'].append(copy.deepcopy(r['inputs'][-1]))
        elif name=='snapshot_cut':a[2]['state']['cut']=2
        elif name=='authority':a[-1]['state']['authority']=True
        elif name=='rollback':a[-1]['state']['current']=copy.deepcopy(r['inputs'][-1]['record']);a[-1]['state']['seq']=2
        elif name=='history':
            for x in a[2:]:x['state']['historical_gaps']=[]
        elif name=='epoch':
            for x in a[2:]:x['state']['epoch']=3
        elif name=='old_reason':a[-1]['reason']='EVENT_APPLIED'
        elif name=='future_coverage':a[-1]['state']['coverage']='COMPLETE_SINCE_CUT'
        elif name=='native_type':
            # Change both redundant transport and actor journal to avoid a simple-copy mismatch shortcut.
            for x in r['wire']:
                v=json.loads(x['raw'])
                if x['direction']=='RECV' and x['peer']=='observer' and v.get('kind')=='NATIVE':
                    v['event_hex']='00'+v['event_hex'][2:];x['raw']=json.dumps(v,sort_keys=True)+'\n';break
            jp=p/'observer.jsonl';js=[json.loads(s) for s in jp.read_text().splitlines()]
            for x in js:
                if x.get('reply',{}).get('kind')=='NATIVE':x['reply']['event_hex']='00'+x['reply']['event_hex'][2:];break
            jp.write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in js))
        elif name=='property_bytes':r['final_capture']['raw_hex']=r['final_capture']['raw_hex'][:-2]+'20'
        elif name=='actor_exit':r['processes']['producer']['exit']=23
        qpath.write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');after=qpath.read_bytes()
        changed=before!=after;v=audit_case(p,r['scenario'],r['session'])
        (p/'CONTROL_AUDIT.json').write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
        structural=any(e.startswith('STRUCTURE:') for e in v['errors'])
        results.append({'name':name,'changed':changed,'before_sha256':hashlib.sha256(before).hexdigest(),
                        'after_sha256':hashlib.sha256(after).hexdigest(),'errors':v['errors'],
                        'pass':changed and bool(v['errors']) and not structural})
    return {'pass':all(x['pass'] for x in results),'count':len(results),'results':results}
if __name__=='__main__':
    r=execute(Path(sys.argv[1]),sys.argv[2],Path(sys.argv[3]));print(json.dumps(r,sort_keys=True,indent=2));raise SystemExit(not r['pass'])

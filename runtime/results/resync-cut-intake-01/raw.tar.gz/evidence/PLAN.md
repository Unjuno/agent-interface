# X11 resync snapshot cut — #4318
Allocation: rsq2-4318-20260924-01. Branch research/x11-resync-cut-677-20260924-rsq2.
Owned additive path research/integration/x11_resync_cut_rsq2_v1/**.

## Objective and H/T/D/C/U
H: captured old notifications must not overwrite a fresher resync snapshot. Exact cut/contiguous-future admission preserves snapshot state and a new contiguous observation suffix without laundering historical loss.
T: 7 schedules, 2 independent sessions each; both pure reducers consume identical actual acquired/delivered records in each session. Fourteen Xvfb lifetimes,42 producer/observer/server exits,28 policy observations. Seven immutable two-session batches. No model, task input, XTEST or experiment network. Compare BLIND_APPLY to CUT_CONTIGUOUS. Both share snapshot admission/history handling; only later event acceptance differs.
D: all14 records/source/process/native/IPC/cleanup identities and independent auditor reconcile; both IN_ORDER final states current; BLIND rollback4 in delayed cases vs candidate0; candidate POST_CUT_GAP unresolved2 versus blind false future-complete2; both policies reject6 invalid snapshots each (12 policy refusals); historical missing event3 remains explicit; authority=false; all12 fixed, effective corruption controls reject without no-op or parser crash. Complete contradiction is FAIL; missing support or failed gates is HOLD/STOP. No rerun, replacement, pooling or post-result tuning.
C: complete single-property state, cooperative producer monotonic sequence, directed loss/delay and explicit gap notice. This is live composition of an elementary ordering rule, not an algorithmic discovery. Snapshot admission is identical in both arms, not a test of source authentication.
U: no natural failure rate, general GUI snapshot atomicity, automatic resync, model/task/token/latency/power benefit, queue throughput, crash durability or production claim. Same-author independent implementation is not external human review. Diagnostic monotonic nanoseconds are not a calibrated benchmark; combined uncertainty/coverage factor unavailable.

## Exact schedule and observation semantics
Every session writes and independently acquires states1..4 via XChangeProperty, PropertyNotify and XGetProperty. Full property records contain {session,source_epoch=1,seq,value}. This producer sequence is NOT the X11 event request serial. The producer is quiescent during each capture. Snapshots at2 and4 are actual separate XGetProperty reads.

Deliver1, then announce missing3/frontier4; keep captured2 delayed and do not deliver3 or4 as events. Snapshot4 represents current state at cut4, NOT event3's past payload. The delayed2 record is preserved from its original acquisition, never fabricated from the later property. Both reducers are invoked when each request is delivered. Valid snapshot is consumed before future5/6 are generated; intervals are retained and audited.

| Condition | Snapshot supplied | Follow-up delivered |
|---|---|---|
| IN_ORDER | actual4 | actual5 |
| DELAYED_BEFORE_CUT | actual4 | earlier captured2 |
| DELAYED_AFTER_FUTURE | actual4 | actual5, earlier captured2 |
| STALE_SNAPSHOT | earlier actual2 | none |
| FOREIGN_SNAPSHOT | actual4 with session field explicitly corrupted | none |
| MISSING_SNAPSHOT | unavailable | none |
| POST_CUT_GAP | actual4 | actual6; actual5 acquired but withheld |

After accepted resync, observation epoch increments1->2 once. Historical missing3 identity survives. Events at/below current accepted sequence are ignored; an event beyond the next sequence creates a new explicit missing predecessor gap and does not update current state. This is an observation contract only, not action admission. Snapshot point-in-time truth does not license subsequent actions.

## Analytical reduction (not an empirical novelty claim)
Assume a complete single-record snapshot at the declared cut and well-formed same-source monotonic records. Immediately after installing it, the reconstructed state equals the state at that cut. For the next delivered event there are three exhaustive cases: older/equal sequence leaves the state unchanged; exact successor installs its actual value and advances the prefix; a greater sequence with a missing predecessor leaves the state unchanged and marks the suffix unresolved. Induction over any finite delivered list preserves a monotone accepted prefix until a gap, never overwriting it with an older record. This proof assumes complete records and trustworthy sequence allocation; the native experiment tests their measured transport composition under the fixed barriers, not hidden GUI dependencies.

## Variable table / units
| Symbol or field | Meaning (日本語) | SI unit | Definition | Domain/assumption | Type |
|---|---|---|---|---|---|
| seq | 生成元の通番 | 1 | property内の生成順序 | positive integer, no wrap | scalar integer |
| cut | 復旧基準の通番 | 1 | accepted snapshot sequence | positive integer or unset | optional scalar |
| epoch | 観測再開区間の版 | 1 | starts1, accepted resync increments | positive integer | scalar integer |
| frontier | 観測済み末尾の通番 | 1 | explicit gap notice or later missing-prefix event | nonnegative integer | scalar integer |
| value | 現在状態の内容 | not physical | complete producer-authored state string | value-1..value-6 here | string |
| ns | 同一ホスト単調時刻 | s (stored ns) | time.monotonic_ns integer | order diagnostic only | scalar integer |
| missing | 未配信の通番集合 | 1 | declared absent predecessor IDs | finite integer list | vector |
| session | 実験セッション識別 | not physical | allocation/phase/batch/repetition | unique per lifetime | string |
Dimensional check: all sequence comparisons use unitless integer identities, never nanosecond clocks or X event serials. Time comparisons use only same-host monotonic nanoseconds. No time or probability is inferred from row counts.

## Roadmap / freeze
Predecessor read-only preservation -> excluded construction -> public source/auditor/gate/environment freeze/readback -> seven first-outcome batches (one batch per outer invocation) -> unchanged raw audit -> all12 saved effective mutations -> lossless evidence/PR -> applicable exact-head CI/review -> qualified merge/readback. Stop on any incomplete formal batch. Build corrections and first errors remain separate; do not make wrapper-only successor Issues.
Construction01 grouped calls exceeded outer20s after batch4 data completed; launch4 exit receipt missing. No formal ran. Follow-up construction02 validates snapshot-before-future delivery on new identities; original construction/source are retained. This is not a continuation of an interrupted formal allocation.

## References / limits
#677: prior analytical resync contract; #4308: actual native event fan-out; #4312 ACK wait work excluded.
X.Org XNextEvent manual: https://xorg.freedesktop.org/archive/X11R7.5/doc/man/man3/XNextEvent.3.html
Python subprocess documentation: https://docs.python.org/3.13/library/subprocess.html
No dependency on the old unpublished backpressure source. Its ZIP and original audit are separately preserved; only read-only identity/audit receipts are included here, not a claim that its full historical bundle is in this new capsule.

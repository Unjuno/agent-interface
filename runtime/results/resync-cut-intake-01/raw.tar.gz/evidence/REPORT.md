# X11 resync snapshot cut — Issue #4318

**PASS_X11_RESYNC_CUT_SCOPED**. Fourteen actual private-X11 sessions,28 paired policy observations. Public source/gate freeze preceded seven first-outcome two-session batches. Same-batch reruns, replacements, exclusions and post-result tuning:0.

## Result

| Endpoint | BLIND_APPLY | CUT_CONTIGUOUS |
|---|---:|---:|
| Current state rolled back by an old captured notification |4|0|
| Post-cut missing predecessor falsely reported complete |2|0|
| Post-cut missing predecessor explicitly unresolved |0|2|
| Invalid stale/foreign/unavailable snapshot refused |6|6|
| IN_ORDER current state preserved |2/2|2/2|

All accepted snapshots preserve the historical gap for withheld event3 and advance observation epoch1->2 once. Candidate ignored delayed event2 after cut4 (and after future5), never replacing newer reconstructed state with value-2. When5 was withheld and6 delivered after cut4, candidate kept its last confirmed state4 and reported GAPPED, not current state6 or complete future coverage. Neither mode reconstructed the historical missing payload or granted action authority.

Actual transport:64 PropertyNotify events with32-byte native-event identities and corresponding complete XGetProperty bytes,42 named producer/observer/server exits0,7 observed batch-runner exits0. Both reducers process the SAME acquired evidence within14 OS sessions, not28 independent OS sessions. Snapshot consumption precedes future event generation and delivery; raw intervals independently reconcile.

Frozen separate raw-only auditor:2478 checks,errors=[]. Frozen12 copied-evidence controls:12 actual changes and12 rejections, no no-op or structural-parser fallback. The native-type control changes redundant wire/journal copies together and is rejected by native type semantics, not a simple duplicate-copy mismatch. All9 frozen scientific files remain byte-identical.

## H/T/D/C/U

H: a fresh recovery snapshot cannot make previously acquired delayed observations current; a cut/contiguous-future check should prevent rollback while preserving gap history.
T: seven fixed schedules with2 fresh repetitions: IN_ORDER, DELAYED_BEFORE_CUT, DELAYED_AFTER_FUTURE, STALE_SNAPSHOT, FOREIGN_SNAPSHOT, MISSING_SNAPSHOT, POST_CUT_GAP. A cooperative producer writes one complete JSON state property; a separate observer acquires actual X11 records under explicit barriers. Both modes share snapshot admission and historical-gap handling; only subsequent event acceptance differs.
D: exact14-session coverage, expected positive/negative/rollback/future-gap outcomes, actual process cleanup, raw audit and all12 effective controls pass jointly. No gate waiver.
C: producer sequence is authored monotonic identity, NOT X event request serial. PropertyNotify alone does NOT contain a complete state payload; XGetProperty is captured while producer is quiescent. The complete single-property snapshot is not arbitrary multi-property/GUI atomicity. The deliberately weak comparator is not alleged production behavior.
U: no automatic resync triggering, queue throughput, authentication, hidden dependencies, concurrent multi-property snapshot, crash/durability, natural failure rate, model/task/token/latency/power benefit or production claim. Same-author separate audit implementation/process is not independent human review.

Environment: provided Linux x86_64 container, CPython3.13.5, Python-Xlib module0.15, authenticated TCP-disabled private Xvfb. No Docker image attestation, model/provider, keyboard/mouse/XTEST, user desktop/data, package installation or experiment network. Clocks are diagnostic same-host monotonic nanoseconds, not a calibrated latency benchmark.

## Retained construction incidents

An excluded grouped construction call exceeded the outer20s limit. Batch4 has complete raw cases and runner END but lacks its outer launch exit receipt; no missing exit is inferred. No consumed construction case was rerun. Remaining unstarted cases ran in separate bounded calls. Before freeze the runner was refined to consume snapshots BEFORE future observations are generated, rather than evaluating a previously collected table; original runner/auditor and all old construction data remain. Revised construction02 checks and12 mutation rehearsals pass,7 final unit tests pass. Formal runs were unaffected and have complete exits.

## Provenance / reproduction

Source-first commit:fb73aae46fde7e2175fcf77b07712f7e4440d029.
Source archive SHA256:0810e7e2b735f06a323a377fb8f7ce36c49fbe401a47a7ed45c21cead89e5774.
FREEZE SHA256:496e79218beb5d7d461773af3a03e07ec785631267e81cf7e9565cce5215c873.
All five source transport/manifest/restorer Git blobs were read back against exact local objects before formal authorization. RESULT.json binds every formal CASE.json. Complete evidence includes construction failures/partials, sources, actor/IPC/native records, launch receipts, first audit and12 mutation payloads.

The older unpublished backpressure pilot is preserved and read-only re-audited separately; only its hash/verification receipts are included here, not its full historical ZIP. It is not pooled or upgraded to public preregistration.

Read only after obtaining publication files:
```
python -B unpack.py EVIDENCE_MANIFEST.json /tmp/rsq2-review-new
python -B /tmp/rsq2-review-new/source/audit.py /tmp/rsq2-review-new > /tmp/rsq2-audit.json
cmp /tmp/rsq2-review-new/AUDIT.json /tmp/rsq2-audit.json
```
Do not rerun consumed native sessions. Restorer writes regular relative files to a new trusted directory, verifies bounded complete bytes, and does not execute source.

## Integration meaning

Separate current-state recovery, complete future coverage and historical gap retention. A later current snapshot cannot erase a lost historical interval, and old retained observations must not overwrite the new checkpoint. This is additive research evidence only; #677/#4308/#4312, shared runtime and repository-wide ROADMAP are unchanged.

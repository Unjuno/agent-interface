# Primary-operated Calc with capture stage timing

Source 3c057b79b87e9faac967c919adb92f0c4e542499; seed 991299. Freeze precedes startup. Primary viewed initial, action-1 and action-2 images and chose both actions. No helper model, additional observation, replay or recovery. SDK client and owner both exited 0. The immutable action replies record two completed programs with verified input release. Independent XLSX evaluation returned exactly [826,141]. Primary image review confirms visible values/dialog closure, not file persistence.

SDK round trips: 875.982 and 847.856 ms. Server exchange: 863.785 and 835.018 ms. These are not model-rendered useful-feedback or semantic-completion latency. Primary decision time and host delivery are not measured by these intervals.

Action 1 contains observations 2–5: bridge spans total 450.259 ms; nested PNG encoding total 219.131 ms. Action 2 contains observations 6–10: bridge spans total 462.075 ms; nested PNG encoding total 224.413 ms. Do not sum enclosing and nested durations. Across all ten observations, medians: GetImage 20.622 ms, PNG encoding 48.807 ms, PNG write/close 0.372 ms, bridge artifact decode 18.270 ms, bridge start-to-decoded 103.180 ms. Source/initial setup observation is included in overall medians. File write does not include fsync. Fixed 250 ms waits were retained, not optimized.

Decision: encoding is a candidate for a controlled comparison on this route; disk-write-only optimization is not supported as the main opportunity by this run. Existing research #4401 warns that smaller encode time may increase delivery time. Preserve full-resolution pixels and existing guard checks. Do not change defaults from one successful known-app construction. Actual model tokens/cost, paired speedup, human baseline and task generalization remain unmeasured.

Cleanup report confirms tracked processes terminal and connection/artifact cleanup returned; it does not verify all descendants. Later native_status confirms owner exit 0. No full-machine cleanup claim.

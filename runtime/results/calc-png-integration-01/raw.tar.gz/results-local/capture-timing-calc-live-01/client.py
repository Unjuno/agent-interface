import asyncio,base64,json,os,time,sys
from pathlib import Path
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
root=Path(__file__).resolve().parent
repo=root.parents[1]
def save(name,value):
    (root/name).write_text(json.dumps(value,indent=2)+'\n')
async def main():
    params=StdioServerParameters(command=sys.executable,args=[str(repo/'research/live_control/native_mcp_v1.py'),'--allocation-directory',str(root/'allocation'),'--app','calc','--seed','991299','--max-stages','12','--text-gap-ms','2','--harness-python','/usr/bin/python3'],env=dict(os.environ))
    with (root/'server.log').open('w') as log:
        async with stdio_client(params,errlog=log) as (reader,writer):
            async with ClientSession(reader,writer) as client:
                await client.initialize()
                save('tools.json',(await client.list_tools()).model_dump(mode='json'))
                async def call(label,name,args):
                    save(label+'-request.json',{'tool':name,'arguments':args})
                    started=time.monotonic_ns()
                    reply=await client.call_tool(name,args)
                    save(label+'-timing.json',{'start_ns':started,'end_ns':time.monotonic_ns()})
                    save(label+'-response.json',reply.model_dump(mode='json'))
                    image=None; metadata={}
                    for block in reply.content:
                        if block.type=='image':
                            image=str(root/(label+'.png')); Path(image).write_bytes(base64.b64decode(block.data))
                        elif block.type=='text':
                            metadata=json.loads(block.text);save(label+'-metadata.json',metadata)
                    view={k:v for k,v in metadata.items() if k not in ('receipt','receipt_references','image_reference')}
                    view['image_reference']=metadata.get('image_reference')
                    view['raw_metadata_file']=str(root/(label+'-metadata.json'))
                    print(json.dumps({'label':label,'isError':reply.isError,'image':image,'metadata':view}),flush=True)
                await call('initial','native_start',{'timeout':30})
                for n in range(1,32):
                    path=root/f'decision-{n}.json'; deadline=time.monotonic()+300
                    while not path.exists() and not (root/'finish').exists():
                        if time.monotonic()>deadline:raise TimeoutError('primary decision timeout')
                        await asyncio.sleep(.05)
                    if (root/'finish').exists():break
                    decision=json.loads(path.read_text())
                    await call(f'action-{n}',decision['tool'],decision['arguments'])
    print(json.dumps({'client':'finished'}),flush=True)
asyncio.run(main())

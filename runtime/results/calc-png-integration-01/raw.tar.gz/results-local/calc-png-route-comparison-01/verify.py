from pathlib import Path
import hashlib,json,statistics
from PIL import Image
root=Path(__file__).resolve().parent
freeze=json.loads((root/'freeze.json').read_text())
for name in ('baseline','candidate','run'):
 key='runner_sha256' if name=='run' else name+'_source_sha256'
 assert hashlib.sha256((root/(name+'.py')).read_bytes()).hexdigest()==freeze[key]
rows=[json.loads(s) for s in (root/'rows.jsonl').read_text().splitlines()]
assert len(rows)==60
seen=set();inputs={}
for frame in freeze['frames']:
 p=root/frame['file'];assert hashlib.sha256(p.read_bytes()).hexdigest()==frame['sha256']
 with Image.open(p) as im: inputs[frame['sequence']]=(im.size,im.convert('RGB').tobytes())
for row in rows:
 key=(row['sequence'],row['repetition'],row['variant']);assert key not in seen;seen.add(key)
 a=row['artifact'];p=root/'outputs'/f"{row['sequence']}-{row['repetition']}-{row['variant']}"/Path(a['path']).name
 data=p.read_bytes();assert len(data)==row['png_bytes'];assert hashlib.sha256(data).hexdigest()==a['sha256']
 with Image.open(p) as im: assert (im.size,im.convert('RGB').tobytes())==inputs[row['sequence']]
 assert row['end_ns']>=row['start_ns']
 assert row['total_ms']==(row['end_ns']-row['start_ns'])/1e6
expected={(f['sequence'],r,v) for f in freeze['frames'] for r in range(3) for v in ('baseline','candidate')}
assert seen==expected
print('PASS: source/input/output identities, all 60 unique rows and decoded pixels')

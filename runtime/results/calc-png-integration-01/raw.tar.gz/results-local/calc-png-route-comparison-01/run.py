from pathlib import Path
import json,hashlib,io,base64,time,statistics,types
from PIL import Image
root=Path(__file__).resolve().parent
freeze=json.loads((root/'freeze.json').read_text())
classes={}
for name in ('baseline','candidate'):
 source=(root/(name+'.py')).read_bytes()
 assert hashlib.sha256(source).hexdigest()==freeze[name+'_source_sha256']
 module=types.ModuleType(name);exec(compile(source,str(root/(name+'.py')),'exec'),module.__dict__)
 classes[name]=module.CaptureArtifacts
# Initialize Pillow plugins outside measurement for both variants.
Image.init()
rows=[]
try:
 for frame in freeze['frames']:
  data=(root/frame['file']).read_bytes();assert hashlib.sha256(data).hexdigest()==frame['sha256']
  with Image.open(io.BytesIO(data)) as opened: image=opened.convert('RGB')
  expected=image.tobytes();raw=image.tobytes('raw','BGRX')
  for rep in range(freeze['repetitions']):
   order=('baseline','candidate') if (frame['sequence']+rep)%2==0 else ('candidate','baseline')
   for name in order:
    sink=classes[name](root/'outputs'/f"{frame['sequence']}-{rep}-{name}")
    start=time.monotonic_ns()
    artifact=sink.write(raw,*image.size,depth=24,bits_per_pixel=32,scanline_pad=32,byte_order=0,masks=(0xff0000,0xff00,0xff),true_color=True)
    wire=json.dumps({'type':'image','mimeType':'image/png','data':base64.b64encode(Path(artifact['path']).read_bytes()).decode('ascii')}).encode()
    received=base64.b64decode(json.loads(wire)['data'])
    with Image.open(io.BytesIO(received)) as opened: decoded=opened.convert('RGB')
    end=time.monotonic_ns()
    exact=decoded.size==image.size and decoded.tobytes()==expected
    t=artifact['timing_ns']
    row={'sequence':frame['sequence'],'repetition':rep,'variant':name,'start_ns':start,'end_ns':end,'total_ms':(end-start)/1e6,'encode_ms':(t['encoded']-t['converted'])/1e6,'png_bytes':artifact['bytes'],'wire_bytes':len(wire),'exact_pixels':exact,'artifact':artifact}
    rows.append(row)
    with (root/'rows.jsonl').open('a') as f: f.write(json.dumps(row)+'\n')
    assert exact,'pixel mismatch'
 pairs=[]
 for frame in freeze['frames']:
  for rep in range(freeze['repetitions']):
   pair={r['variant']:r for r in rows if r['sequence']==frame['sequence'] and r['repetition']==rep}
   b,c=pair['baseline'],pair['candidate']
   pairs.append({'sequence':frame['sequence'],'repetition':rep,'encode_ratio':c['encode_ms']/b['encode_ms'],'total_ratio':c['total_ms']/b['total_ms'],'byte_ratio':c['png_bytes']/b['png_bytes']})
 result={'row_count':len(rows),'pair_count':len(pairs),'exact_pixels':all(r['exact_pixels'] for r in rows),'paired_medians':{k:statistics.median(p[k] for p in pairs) for k in ('encode_ratio','total_ratio','byte_ratio')},'pairs':pairs}
 result['decision']='ELIGIBLE_FOR_LIVE_COMPARISON' if len(rows)==60 and result['exact_pixels'] and result['paired_medians']['encode_ratio']<=.90 and result['paired_medians']['total_ratio']<=.95 else 'HOLD'
 (root/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k!='pairs'}))
except Exception as e:
 (root/'failure.json').write_text(json.dumps({'error':repr(e),'completed_rows':len(rows)})+'\n');raise

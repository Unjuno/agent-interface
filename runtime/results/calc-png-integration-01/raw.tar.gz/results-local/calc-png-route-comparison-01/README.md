# Calc retained-frame PNG candidate comparison

This comparison applies the existing #4401 compression-level idea to the ten screenshots from the primary-operated Calc run capture-timing-calc-live-01. It does not replace that research's frozen outcomes. Runtime source 3c057b79b87e9faac967c919adb92f0c4e542499 remains unchanged.

Before execution, freeze.json bound all ten input hashes, the exact shared CaptureArtifacts baseline, the one-line level1 candidate, runner, order and gate. Three alternating technical pairs per frame produced 60 complete rows without retry/exclusion. Every output was decoded and compared byte-for-byte in RGB with its input. The later verify.py independently reopens all outputs and verifies identities/pixels; it shares Pillow and is not an independent decoder implementation.

Pooled paired median candidate/baseline ratios: PNG encoding 0.740538; sink write/hash plus local base64 JSON round trip and image decode 0.806320; PNG bytes 1.151468. Result: ELIGIBLE_FOR_LIVE_COMPARISON, using the prospective <=0.90 encode and <=0.95 local-total gates plus exact pixels. This is not a production adoption gate.

Measurement starts before shared sink.write and ends after image decode. Sink construction, input PNG load, RGB-to-BGRX reconstruction and Pillow plugin initialization occur outside timing; pixel equality audit is after timing. Reconstructed BGRX is not the original X11 raw reply. No actual MCP pipe, network, primary model rendering, tokens or human baseline were measured. Serial known Calc frames and three technical repetitions do not establish generalization or robust tail latency.

Decision: do not change defaults. Carry level1 forward as an explicit experimental variant in a live paired operation, preserving guard captures/full pixels and accounting for larger response bytes. The original #4401 result remains HOLD and its constrained-transport reversal remains relevant. Retain the full input/save live run and this comparison together when publishing the next integration decision.

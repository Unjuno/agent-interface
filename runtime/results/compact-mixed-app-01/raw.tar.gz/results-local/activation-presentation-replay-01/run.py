import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

repo = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(repo))
from runtime.cli_v1.review import present_result
from runtime.cli_v1.receipt_references import expand_receipt

out = Path(__file__).resolve().parent
source = repo / 'results-local/explicit-window-activation-primary-02'
encode = lambda x: json.dumps(x, ensure_ascii=False, separators=(',', ':')).encode()
rows = []
for label in ['initial'] + [f'action-{n}' for n in range(1, 15)]:
    path = source / (label + '-metadata.json')
    metadata = json.loads(path.read_text())
    if 'receipt' not in metadata:
        rows.append({'label': label, 'status': 'not_a_review_receipt',
                     'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
        continue
    raw = metadata['receipt']['source']['raw_report']
    full = present_result(raw, source)
    row = {'label': label, 'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'variants': {}}
    for mode, options in [('full', {}), ('compact', {'compact': True}),
                          ('report_refs', {'compact': True, 'report_refs': True})]:
        value = present_result(copy.deepcopy(raw), source, **options)
        restored = expand_receipt(value['receipt']) if mode != 'full' else value['receipt']
        assert restored == full['receipt'], (label, mode, 'receipt changed')
        assert value['outcome_summary'] == full['outcome_summary']
        assert value['image'] == full['image']
        assert value['image_status'] == full['image_status']
        image = value.pop('image')
        row['variants'][mode] = {'text_bytes': len(encode(value)),
            'image_base64_bytes': len(image['data']) if image else 0,
            'image_status': value['image_status']}
    rows.append(row)
totals = {mode: sum(row['variants'][mode]['text_bytes'] for row in rows if 'variants' in row)
          for mode in ('full', 'compact', 'report_refs')}
result = {'source_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
          'rows': rows, 'text_byte_totals': totals,
          'review_receipts': sum('variants' in row for row in rows),
          'scope': 'offline replay of retained real GUI reports; no new GUI actions or model calls',
          'model_tokens': None, 'model_cost': None, 'model_latency': None,
          'decision': 'PRESENTATION_PARITY_ONLY; model usability and token benefit unmeasured'}
(out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'rows'}))

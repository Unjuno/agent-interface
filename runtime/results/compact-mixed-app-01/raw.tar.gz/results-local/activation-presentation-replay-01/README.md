# Retained real-GUI presentation replay

Source main871e3c784dc4e59c639b89f63258b2289073fbdf. Replay uses the 15 public
calls in explicit-window-activation-primary-02. Ten observe/dispatch reports
use the shared review presentation; five management calls are outside this
comparison. All ten return identical image blocks in all variants. Expanding
compact receipts exactly recovers the full receipt, and outcome summaries match.

Serialized presentation text excluding the image block totals 53,599 UTF-8 bytes
for full and compact-only, and 37,470 for compact plus report_refs (30.09% less).
This excludes MCP/host framing and the five management responses; it is not a
whole-session byte or model-token result. Image bytes are unchanged. No new GUI
action or model call was made. No model token, cost or latency measurement exists.

Decision: try existing explicit compact=true/report_refs=true options in the
next primary live trial; do not change server defaults or add an unmeasured
summary format. Read original report at receipt.source.raw_report when needed.
Readiness and task completion still require image review/independent file scoring.

Issue intake: #4066 remains STOP_WORKER_TIMEOUT with 24/36 workers and no formal
controls; its incomplete pagination result is not adopted. #3311 formal06 is a
synthetic focus-ID mechanics result, not completion of integrated efficiency
acceptance. Prior evidence and other agents' experiments remain unchanged.

import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const directory=resolve(process.argv[2]);
const {createPrimaryCaller}=await import(pathToFileURL(join(directory,'primary_caller.mjs')));
const {createInstrumentedRelayClient}=await import(pathToFileURL(join(directory,'relay_host.mjs')));
const fixture="require('node:readline').createInterface({input:process.stdin}).on('line',line=>{const r=JSON.parse(line);console.log(JSON.stringify({id:r.id,tool:r.tool,status:'returned',next_id:r.id+1,result:{isError:false,content:[{type:'text',text:JSON.stringify({status:r.tool==='interface_close'?'closed':'returned',input_dispatched:false})}]}}));});";
const evidence=resolve(process.argv[3]);
const host=await createInstrumentedRelayClient({command:process.execPath,args:['-e',fixture],evidenceDirectory:evidence});
const presented=[];const caller=createPrimaryCaller(host,'guarded-local',{text:value=>presented.push(value),image:()=>assert.fail('inert fixture has no images')});
try {
  const first=await caller.observe();
  await caller.acknowledgeText(first.attempt,{task:'construction',phase:'initial',reason:'Read original inert observation reply; no GUI capture claimed'});
  const fresh=await caller.observe();
  await caller.acknowledgeText(fresh.attempt,{task:'construction',phase:'fresh',reason:'Read second original inert observation reply; no fresh GUI grounding claimed'});
  assert.equal(caller.state().stopped,null);
  const close=await caller.call('interface_close',{});
  await caller.acknowledgeText(close.attempt,{task:'construction',phase:'close',reason:'Read original inert close status; no physical release claimed'});
  const requests=await Promise.all([1,2,3].map(async n=>JSON.parse(await readFile(join(evidence,`request-${n}.json`),'utf8'))));
  assert.deepEqual(requests.map(r=>({tool:r.tool,args:r.arguments})),[
    {tool:'interface_guarded_observe',args:{}},{tool:'interface_guarded_observe',args:{}},{tool:'interface_close',args:{}}
  ]);
  assert.ok(presented.length>=6);
  await writeFile(join(evidence,'consumer-result.json'),JSON.stringify({scope:'packaged caller/real host with inert child; no GUI or physical input',calls:3,observations:2,original_text_acks:3,stopped:caller.state().stopped},null,2));
} finally {await host.close();}
console.log('Packaged primary caller and real host: two no-target observes, three original text acknowledgments, no input tool');

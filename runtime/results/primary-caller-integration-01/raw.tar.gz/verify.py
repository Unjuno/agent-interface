import hashlib,json,re
from pathlib import Path

def require(value,message):
    if not value:raise ValueError(message)

def read(path):return json.loads(Path(path).read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def verify(root):
    root=Path(root); provenance=read(root/'source.json')
    require(provenance['source']=='9e8bcd01ba61058ddac7f4a7c7b76b60e1626f26','committed implementation source')
    for name,digest in provenance['files'].items():require(sha(root/name)==digest,'implementation snapshot '+name)
    host=root/'bundle/host'; manifest=read(host/'HOST_MANIFEST.json')
    require(manifest['source_revision']==provenance['source'],'source-pinned host build')
    require({r['path'] for r in manifest['files']}=={'primary_caller.mjs','relay_client.mjs','relay_host.mjs','README.md'},'complete distributed host')
    for record in manifest['files']:
        require(sha(host/record['path'])==record['sha256'],'bundle file identity')
        require((host/record['path']).read_bytes()==(root/'source/runtime/host_v1'/record['path']).read_bytes(),'committed bundled bytes')
    for line in (host/'SHA256SUMS').read_text().splitlines():
        digest,name=line.split('  ',1);require(sha(host/name)==digest,'host checksum '+name)
    for name,count in [('node-ci-final.stdout.log',72),('caller-regression-final.stdout.log',19)]:
        text=(root/name).read_text();require(re.search(r'tests '+str(count)+r'\b',text) and re.search(r'pass '+str(count)+r'\b',text) and re.search(r'fail 0\b',text),'full final suite '+name)
    require('STOP must be visible' in (root/'red.stdout.log').read_text(),'actual original red failure')
    require('fail 1' in (root/'caller-regression.stdout.log').read_text() and 'Unknown tool' in (root/'caller-regression.stdout.log').read_text(),'intermediate compatibility failure retained')
    native=read(root/'native-final/result.json');require(native['status']=='PASS','final shared runner')
    for suite,count in zip(native['suites'],[337,149]):
        require(suite['returncode']==0,'shared suite exit')
        for record in suite['logs'].values():require(sha(root/'native-final'/record['file'])==record['sha256'],'shared full log identity')
        text=(root/'native-final'/suite['logs']['stderr']['file']).read_text()
        require(re.search(r'Ran '+str(count)+r' tests',text) and text.rstrip().endswith('OK'),'shared suite count')
    evidence=root/'bundle/consumer-host';result=read(evidence/'consumer-result.json')
    require(result['calls']==3 and result['observations']==2 and result['original_text_acks']==3 and result['stopped'] is None,'inert consumer outcome')
    require(read(evidence/'exit.json')=={'code':0,'signal':None},'original packaged transport exit')
    events=[json.loads(line) for line in (evidence/'host-events.jsonl').read_text().splitlines()]
    require([e['sequence'] for e in events]==list(range(1,len(events)+1)),'consumer host event order')
    require(len(list(evidence.glob('request-*.json')))==3 and len(list(evidence.glob('reply-*.json')))==3,'consumer all launched denominator')
    for attempt,tool in [(1,'interface_guarded_observe'),(2,'interface_guarded_observe'),(3,'interface_close')]:
        request=read(evidence/f'request-{attempt}.json');reply=read(evidence/f'reply-{attempt}.json');digest=sha(evidence/f'reply-{attempt}.json')
        require(request['tool']==tool and request['arguments']=={},'no-target observation and no input tool')
        require(reply['id']==attempt and reply['tool']==tool and reply['result']['isError'] is False,'original consumer response')
        require(all(c['type']=='text' for c in reply['result']['content']),'no fabricated image')
        ack=read(evidence/f'text-acknowledgment-{attempt}.json');require(ack['reply_sha256']==digest and ack['isError'] is False,'consumer original text identity')
        selected=[e for e in events if e.get('attempt')==attempt]
        require([e['kind'] for e in selected]==['send_requested','reply_available','presentation_started','presentation_callbacks_completed','text_acknowledgment_recorded'],'consumer exact presentation/ack order')
        require(all(e.get('reply_sha256',digest)==digest for e in selected),'consumer reply digests')
    return {'source':provenance['source'],'node_tests':72,'caller_tests':19,'protocol_tests':337,'harness_tests':149,'packaged_consumer_calls':3,'scope':'maintenance integration; inert transport, no GUI/model/input performance evidence'}

if __name__=='__main__':print(json.dumps(verify(Path(__file__).parent),indent=2))

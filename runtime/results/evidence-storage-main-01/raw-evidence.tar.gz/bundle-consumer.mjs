import assert from 'node:assert/strict';
import { readFile,writeFile } from 'node:fs/promises';
import { resolve,join } from 'node:path';
import { pathToFileURL } from 'node:url';
const bundle=resolve(process.argv[2]), evidenceDirectory=resolve(process.argv[3]);
const {createInstrumentedRelayClient}=await import(pathToFileURL(join(bundle,'relay_host.mjs')));
const fixture="require('node:readline').createInterface({input:process.stdin}).on('line',line=>{const r=JSON.parse(line);console.log(JSON.stringify({id:r.id,tool:r.tool,status:'returned',next_id:r.id+1,result:{isError:false,content:[{type:'text',text:JSON.stringify({status:r.tool==='interface_close'?'closed':'returned',input_dispatched:false})}]}}));});";
const host=await createInstrumentedRelayClient({command:process.execPath,args:['-e',fixture],evidenceDirectory});
const presented=[];
try {
  const preflight=JSON.parse(await readFile(join(evidenceDirectory,'storage-preflight.json'),'utf8'));
  assert.equal(preflight.minimum_free_bytes,33554432);
  assert.equal(preflight.child_started,false);
  assert.equal(preflight.future_writes_guaranteed,false);
  assert.equal(host.state().attempts,0);
  for(const tool of ['interface_clock','interface_close']) {
    const r=await host.send(tool,{});
    await host.present(r.attempt,{text:v=>presented.push(v),image:()=>assert.fail('inert fixture has no image')});
    assert.equal(JSON.parse(r.result.content[0].text).input_dispatched,false);
  }
  await writeFile(join(evidenceDirectory,'consumer-result.json'),JSON.stringify({
    scope:'Real main-derived public host with inert child; no actual MCP clock, GUI, physical input/release or perception proof',
    calls:2,presentation_values:presented.length,storage_floor:preflight.minimum_free_bytes,
  },null,2));
} finally { await host.close(); }
console.log('Main-derived public bundle: startup receipt, two inert transport exchanges, original text delivery, no input tool');

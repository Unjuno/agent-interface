from pathlib import Path
import subprocess,json
r=Path(__file__).parents[2]; d=Path(__file__).parent
source='265649efd946337659ef1459073c7e2acad4a61d'
def gitbytes(ref,path): return subprocess.check_output(['git','show',ref+':'+path],cwd=r)
old=gitbytes('f1463f65e6a9142e03344292e66a825ea3bf636c','runtime/host_v1/relay_client.mjs')
assert (r/'runtime/host_v1/relay_client.mjs').read_bytes()==old
(r/'runtime/host_v1/relay_client.mjs').write_bytes(gitbytes(source,'runtime/host_v1/relay_client.mjs'))
candidate=gitbytes(source,'runtime/host_v1/README.md').decode()
capacity='Both `createRelayClient`'+candidate.split('Both `createRelayClient`',1)[1].split('\n\nFor a returned response',1)[0]
path=r/'runtime/host_v1/README.md'; original=path.read_text()
start=original.index('The host creates'); end=original.index('\n\n',start)
updated=original[:end]+'\n\n'+capacity+original[end:]
updated=updated.replace("  evidenceDirectory: '/absolute/new-host-records',","  evidenceDirectory: '/absolute/new-host-records',\n  minimumEvidenceFreeBytes: 32 * 1024 * 1024,",1)
path.write_text(updated)
(d/'intake.json').write_text(json.dumps({'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'candidate_source':source,'main_client_matches_pre_fix_source':True,'runtime_scope':'relay_client capacity check only; main relay_host unchanged; no primary caller or guarded behavior intake','setup_command_failure':'An earlier inline Python command had shell quoting SyntaxError before any Python statement executed. This file replaces that authoring command; main baseline was still exact before intake.'},indent=2))
print('capacity change applied to exact main client')

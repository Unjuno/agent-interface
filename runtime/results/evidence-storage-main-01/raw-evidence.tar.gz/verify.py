import hashlib,json,sys
from pathlib import Path
r=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent
def require(ok,why):
    if not ok: raise ValueError(why)
def read(p): return json.loads((r/p).read_text())
def digest(p): return hashlib.sha256((r/p).read_bytes()).hexdigest()
for p,h in read('RAW_MANIFEST.json')['files'].items(): require(digest(p)==h,'raw digest '+p)
source=read('source.json')['source']; require(source=='75e57e50199597669f96f4b6b60b1b45206fb317','source identity')
require(read('source.json')['base']=='a7648fb47f16b15ac2fdb63075186aad1189859c','main base')
for label,code in [('baseline-node',1),('baseline-node-populated',0),('main-red',1),('main-green',0),('native',0),('consumer',0)]:
    require((r/(label+'.exit')).read_text().strip()==str(code),'exit '+label)
for label,count in [('baseline-node-populated',47),('main-green',52)]:
    text=(r/(label+'.stdout')).read_text(); require(f'pass {count}' in text and 'fail 0' in text,'Node denominator')
require('fail 5' in (r/'main-red.stdout').read_text() and 'pass 0' in (r/'main-red.stdout').read_text(),'main RED')
native=read('native/result.json'); require(native['status']=='PASS','native status')
for suite,count in zip(native['suites'],[327,141]):
    require(suite['returncode']==0,'native return')
    for stream in suite['logs'].values(): require(digest('native/'+stream['file'])==stream['sha256'],'native raw log')
    require(f'Ran {count} tests' in (r/'native'/suite['logs']['stderr']['file']).read_text(),'native count')
manifest=read('build-manifest.json'); require(manifest['source_revision']==source and digest('runtime.pyz')==manifest['sha256'],'runtime artifact')
bundle=read('host-bundle/HOST_MANIFEST.json'); require(bundle['source_revision']==source,'bundle revision')
for row in bundle['files']:
    require(digest('host-bundle/'+row['path'])==row['sha256'] and digest('candidate-source/'+row['path'])==row['sha256'],'bundle/source bytes')
for i in [0,1]:
    receipt=read(f'windows-accepted-original-{i}/storage-preflight.json')
    require(receipt['minimum_free_bytes']==33554432 and int(receipt['available_bytes'])>=33554432,'accepted actual capacity')
    require(receipt['capacity_reserved'] is False and receipt['future_writes_guaranteed'] is False,'accepted bounded scope')
    require(read(f'windows-accepted-original-{i}/exit.json')['code']==-4058,'nonexistent-command original exit')
    require(not list((r/f'windows-accepted-original-{i}').glob('request-*.json')),'accepted constructor no tool send')
require(read('windows-zero-capacity.json')==[{'unexpected':'child accepted'},{'unexpected':'child accepted'}],'preserved changed-environment expectation failure')
refused=read('windows-insufficient-capacity.json')
require(len(refused)==2 and all(x['code']=='EVIDENCE_CAPACITY' and x['minimumEvidenceFreeBytes']==9007199254740991 and 0<=int(x['availableBytes'])<9007199254740991 for x in refused),'explicit Windows floor refusal')
prefix='bundle-consumer-evidence/'
receipt=read(prefix+'storage-preflight.json')
require(receipt['minimum_free_bytes']==33554432 and int(receipt['available_bytes'])>=33554432 and receipt['capacity_reserved'] is False and receipt['future_writes_guaranteed'] is False,'consumer bounded capacity')
for i,tool in [(1,'interface_clock'),(2,'interface_close')]:
    request=read(prefix+f'request-{i}.json'); require(request['tool']==tool and request['arguments']=={},'inert request')
    reply=read(prefix+f'reply-{i}.json'); require(reply['status']=='returned' and all(x['type']=='text' for x in reply['result']['content']),'inert original reply')
    require(json.loads(reply['result']['content'][0]['text'])['input_dispatched'] is False,'inert no input')
require(read(prefix+'exit.json')['code']==0 and read(prefix+'consumer-result.json')['calls']==2,'consumer cleanup')
print(json.dumps({'audit':'PASS_SCOPED_MAIN_INTEGRATION_RETENTION','baseline_node':47,'main_node':52,'protocol':327,'harness':141,'windows_changed_capacity_expectation_retained':True,'new_windows_floor_refusals':2,'live_gui_comparison':False}))

import sys,json,subprocess,importlib.util
from pathlib import Path
r=Path(__file__).resolve().parents[1];sys.path[:0]=[str(r),str(r/'research/live_control'),str(r/'research/observation_gating')]
from run_native_six_task_self_use_v1 import PrivateSession
from runtime.backends.x11_v1.backend import X11Backend
from runtime.cli_v1.x11_target_review import inspect_focused_target
import gui_suite
out=r/'results-local/public-title-calc-01';out.mkdir(exist_ok=False)
save=lambda n,v:(out/n).write_text(json.dumps(v,indent=2)+'\n')
old=out/'baseline.py';old.write_bytes(subprocess.check_output(['git','show','HEAD:runtime/cli_v1/x11_target_review.py'],cwd=r))
spec=importlib.util.spec_from_file_location('baseline_target_review',old);baseline=importlib.util.module_from_spec(spec);spec.loader.exec_module(baseline)
s=PrivateSession();backend=None
try:
 _,output,_=gui_suite.prepare(s,'calc',991352,'')
 target=int(next(line.split()[0] for line in s.windows().splitlines() if output.name in line),16)
 backend=X11Backend({'app':target},display_name=s.name)
 before=baseline.inspect_focused_target(backend,target);after=inspect_focused_target(backend,target)
 save('comparison.json',{'before':before,'after':after,'backend_emissions':backend.emissions})
 result=subprocess.run(['xprop','-display',s.name,'-id',str(target),'WM_NAME','_NET_WM_NAME','_NET_WM_VISIBLE_NAME'],capture_output=True,text=True)
 (out/'xprop.stdout').write_text(result.stdout);(out/'xprop.stderr').write_text(result.stderr)
 save('xprop-exit.json',{'returncode':result.returncode})
 if before['title'] or not after['title'] or backend.emissions:raise ValueError('expected empty legacy title, recovered UTF-8 title and no task input')
 if {k:v for k,v in before.items() if k!='title'}!={k:v for k,v in after.items() if k!='title'}:raise ValueError('non-title evidence changed')
 print(json.dumps({'before_title':before['title'],'after_title':after['title'],'input_emissions':backend.emissions}))
finally:
 if backend:backend.close()
 s.close();save('cleanup.json',[{'pid':p.pid,'returncode':p.poll()} for p in s.procs])

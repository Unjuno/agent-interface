import json,hashlib,tarfile,subprocess
from pathlib import Path
r=Path(__file__).resolve().parents[1];out=r/'runtime/results/public-utf8-title-01';out.mkdir(exist_ok=False)
paths=[]
for name in ('public-title-native-01','public-title-calc-01','public-title-calc-02'):paths+=list((r/'results-local'/name).rglob('*'))
paths += [r/'results-local'/n for n in ('check-public-title-calc.py','check-public-title-calc-02.py','public-title-native-01.log')]
paths += [r/'runtime/cli_v1/x11_target_review.py',r/'runtime/cli_v1/test_x11_target_review.py',Path(__file__)]
manifest={}
with tarfile.open(out/'raw.tar.gz','w:gz') as archive:
 for p in sorted(paths):
  if not p.is_file() or '__pycache__' in p.parts:continue
  data=p.read_bytes();name=p.relative_to(r).as_posix();manifest[name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)};archive.add(p,arcname=name)
(out/'manifest.json').write_text(json.dumps({'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'files':manifest},indent=2)+'\n')
print(len(manifest))

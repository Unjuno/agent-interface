"""Recompute original trial evidence without granting integration acceptance."""
import base64,hashlib,json
from pathlib import Path

def require(ok,why):
    if not ok:raise ValueError(why)

def analyze(root):
    root=Path(root);load=lambda p:json.loads((root/p).read_text())
    plan=load('PLAN.json')
    for name,digest in plan['hashes'].items():
        require(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,'frozen source '+name)
    result={'status':'HOLD_TEXT_ONLY_CONTROL_REVIEW','source':plan['source'],'seed':plan['seed'],'routes':{}}
    for route,total,counts in [('guarded-local',40,[1,1,1,0,0,0]),('direct-post',29,[1]*6)]:
        directory=root/route/'host'
        paths=sorted(directory.glob('request-*.json'),key=lambda p:int(p.stem.split('-')[-1]))
        require(len(paths)==total,'request inventory')
        events=[json.loads(line) for line in (directory/'host-events.jsonl').read_text().splitlines()]
        require([e['sequence'] for e in events]==list(range(1,len(events)+1)),'event sequence')
        inputs=[];errors=[];pictures=0;emissions=0;parsed={};latencies=[]
        for index,path in enumerate(paths,1):
            q=json.loads(path.read_text());require(q['id']==index,'request sequence')
            rp=directory/f'reply-{index}.json';reply=json.loads(rp.read_text())
            m=json.loads(next(c['text'] for c in reply['result']['content'] if c['type']=='text'));parsed[index]=m
            delivered=[e for e in events if e['kind']=='presentation_callbacks_completed' and e.get('attempt')==index]
            started=[e for e in events if e['kind']=='send_requested' and e.get('attempt')==index]
            require(len(delivered)==len(started)==1,'original feedback delivered')
            require(delivered[0]['reply_sha256']==hashlib.sha256(rp.read_bytes()).hexdigest(),'delivery reply hash')
            latencies.append({'attempt':index,'tool':q['tool'],'send_to_callbacks_ms':delivered[0]['host_monotonic_ms']-started[0]['host_monotonic_ms']})
            images=[c for c in reply['result']['content'] if c['type']=='image'];pictures+=len(images)
            for c in images:require(base64.b64decode(c['data']).startswith(b'\x89PNG\r\n\x1a\n'),'original PNG')
            if reply['result'].get('isError'):errors.append(index)
            if q['tool'] in ('interface_guarded_input','interface_dispatch') and not reply['result'].get('isError'):
                if route=='guarded-local':
                    require(m['status']=='completed','guarded outcome');ex=m['result']['execution']
                else:
                    require(m['outcome_summary']['execution_status']=='completed' and m['outcome_summary']['input_release_verified'] is True,'direct outcome')
                    ex=m['receipt']['execution_summary']
                require(ex['releases'] and all(r['verified'] and not r['keys_down'] and not r['buttons_down'] for r in ex['releases']),'neutral input')
                require(m['image_status']=='image' and len(images)==1,'input feedback image')
                inputs.append(index);emissions+=ex['program_emissions']
            if images:
                receipt=json.loads((directory/f'review-{index}.json').read_text())
                require(receipt['reply_sha256']==hashlib.sha256(rp.read_bytes()).hexdigest(),'primary review reply hash')
                require([i['sha256'] for i in receipt['images']]==[hashlib.sha256(base64.b64decode(c['data'])).hexdigest() for c in images],'primary image attribution')
        score=load(route+'/session/evaluation-at-close.json')
        require([score['exact_counts'][f'task-{i}'] for i in range(1,7)]==counts,'independent score')
        require(score['success']==(route=='direct-post') and not score['duplicates'] and not score['unexpected'],'score acceptance scope')
        require(load(route+'/original-terminal.json')['exit_code']==0,'original terminal')
        require(load(route+'/host/exit.json')=={'code':0,'signal':None},'relay transport terminal')
        row={'calls':total,'completed_input_attempts':inputs,'error_attempts':errors,'reply_images':pictures,'program_emissions':emissions,'score':score,'call_feedback':latencies,'cleanup':load(route+'/session/cleanup.json')}
        if route=='guarded-local':
            controls=load('controls.json')
            for attempt,control in [(38,controls[0]),(40,controls[1])]:
                request=load(route+f'/host/request-{attempt}.json')
                require(request['tool']==control['tool'] and request['arguments']==control['args'],'declared control request')
            require(inputs==[4,8,10,13,16,18,20,23,26,28,31,34,37] and errors==[38,40],'guarded attempt outcome inventory')
            require(parsed[38]['result']['input_dispatched'] is False and parsed[38]['result']['guard_checks'][0]['reason']=='region_pixels_missing','planned layout refusal')
            require(parsed[39]['review']['previous_binding_revision']==0 and parsed[39]['review']['binding_revision']==1,'explicit window review')
            require(parsed[40]['error']=='KeyError(4)' and parsed[40]['input_dispatched'] is False,'planned revoked source')
            require(not (directory/'review-40.json').exists(),'text-only review failed without receipt')
            finish=load(route+'/session/finish.json');require(finish['policyState']['stopped']=='review recording failure' and finish['publicCloseReturned'] is False,'immediate failure stop')
            require(not finish['expiryEvents'],'no expiry remint claim')
            close_files=list((root/route/'session/server').glob('session-*-close.json'));require(len(close_files)==1,'server close inventory')
            close=json.loads(close_files[0].read_text());require(close['status']=='closed' and close['release']['verified'] and not close['release']['keys_down'] and not close['release']['buttons_down'],'server cleanup release')
            row.update({'public_close_returned':False,'server_cleanup_neutral':True,'unexecuted_control':'revoked-alias','remaining_tasks':[4,5,6]})
        else:
            require(inputs==list(range(6,29,2)) and not errors and emissions==588,'direct complete input inventory')
            close=parsed[29];require(close['status']=='closed' and close['release']['verified'] and not close['release']['keys_down'] and not close['release']['buttons_down'],'direct public close')
            row['public_close_returned']=True
        result['routes'][route]=row
    result.update({'matched_comparison':False,'speedup':None,'model_tokens':None,'dollars':None,'human_tempo_proven':False,'timing_scope':'Host send_requested to presentation_callbacks_completed; includes fixed waits and transport. Not independent semantic recognition or model cognitive latency.'})
    return result

if __name__=='__main__':
    import sys
    print(json.dumps(analyze(sys.argv[1] if len(sys.argv)>1 else Path(__file__).parent),indent=2))

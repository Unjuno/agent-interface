import hashlib, importlib.util, json, tarfile
from pathlib import Path
root=Path(__file__).parent
spec=importlib.util.spec_from_file_location('analysis06',root/'analyze.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
(root/'analysis.json').write_text(json.dumps(module.analyze(root),indent=2)+'\n')
out=root.parents[1]/'runtime/results/post-release-spine-06'
out.mkdir(parents=True,exist_ok=True)
members={}
with tarfile.open(out/'raw.tar.gz','w:gz') as archive:
    for path in sorted(root.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:continue
        name=path.relative_to(root).as_posix()
        members[name]=hashlib.sha256(path.read_bytes()).hexdigest()
        archive.add(path,arcname=name,recursive=False)
(out/'manifest.json').write_text(json.dumps({'source':module.analyze(root)['source'],'archive_sha256':hashlib.sha256((out/'raw.tar.gz').read_bytes()).hexdigest(),'members':members},indent=2)+'\n')
print(json.dumps({'members':len(members),'archive_bytes':(out/'raw.tar.gz').stat().st_size}))

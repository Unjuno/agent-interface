import sys,asyncio,json,time,os
from pathlib import Path
from Xlib import XK
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
r=Path('/var/tmp/agent-interface-integrated-main');sys.path[:0]=[str(r),str(r/'research/live_control')]
sys.path.append('/usr/lib/python3/dist-packages')
from run_native_six_task_self_use_v1 import PrivateSession
out=r/'results-local/x11-explicit-recovery-after-01';out.mkdir(exist_ok=False)
s=PrivateSession()
def save(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n')
async def main():
 targets={'fixture':s.d.screen().root.id};save('targets.json',targets)
 args=[str(r/'results-local/x11-explicit-recovery-mcp-host.py'),str(r/'results-local/explicit-input-recovery-build-01/runtime.pyz'),'--targets',str(out/'targets.json'),'--output-directory',str(out/'server'),'--display',s.name,'--session-mode','persistent-x11']
 save('launch.json',{'command':sys.executable,'args':args,'scope':'private X11 construction; one injected post-press acknowledgement error; no model or task benchmark'})
 params=StdioServerParameters(command=sys.executable,args=args,env=dict(os.environ))
 with (out/'server.stderr').open('w') as err:
  async with stdio_client(params,errlog=err) as (reader,writer):
   async with ClientSession(reader,writer) as client:
    await client.initialize()
    for attempt in (1,2):
     p={'schema':'agent-interface/program-v1','program_id':f'uncertain-press-{attempt}','source':{'observation_seq':0,'binding_revision':1},'authority':{'lease_id':'construction','expires_at_ns':time.monotonic_ns()+5_000_000_000},'terminal':{'release_all_required':True},'ops':[{'op':'key_state','key':'w','down':True},{'op':'wait_update','timeout_ms':20},{'op':'key_state','key':'w','down':False},{'op':'release_all'}]}
     if attempt==2:p['ops']=[{'op':'release_all'}]
     args={'program':p,'current_observation_seq':0,'current_binding_revision':1,'compact':True,'report_refs':True};save(f'request-{attempt}.json',args)
     reply=await client.call_tool('interface_dispatch',args);save(f'reply-{attempt}.json',reply.model_dump(mode='json'))
     code=s.d.keysym_to_keycode(XK.string_to_keysym('w'));keymap=s.d.query_keymap();save(f'witness-{attempt}.json',{'w_down':bool(keymap[code//8]&(1<<(code%8))),'monotonic_ns':time.monotonic_ns(),'phase':'after dispatch reply, before any next input or close'})
    reply=await client.call_tool('interface_recover_input',{'current_binding_revision':1});save('recovery.json',reply.model_dump(mode='json'))
    recovered=json.loads(reply.content[0].text);save('recovery-request.json',{'current_binding_revision':1})
    keymap=s.d.query_keymap();save('witness-after-recovery.json',{'w_down':bool(keymap[code//8]&(1<<(code%8))),'phase':'before any later dispatch or close'})
    reply=await client.call_tool('interface_recover_input',{'current_binding_revision':1});save('stale-recovery.json',reply.model_dump(mode='json'))
    # Rebuild the prior full pulse explicitly; the old binding must refuse it.
    p['ops']=[{'op':'key_state','key':'w','down':True},{'op':'wait_update','timeout_ms':20},{'op':'key_state','key':'w','down':False},{'op':'release_all'}]
    p['program_id']='old-binding-pulse';args={'program':p,'current_observation_seq':0,'current_binding_revision':1,'compact':True,'report_refs':True}
    save('stale-program-request.json',args);reply=await client.call_tool('interface_dispatch',args);save('stale-program.json',reply.model_dump(mode='json'))
    reply=await client.call_tool('interface_observe',{'target':'fixture','frame':'window_client','region':[0,0,32,32]});save('post-recovery-observation.json',reply.model_dump(mode='json'))
    revision=recovered['binding_revision'];p['source']['binding_revision']=revision;p['program_id']='new-explicit-pulse';p['authority']['expires_at_ns']=time.monotonic_ns()+5_000_000_000
    args={'program':p,'current_observation_seq':0,'current_binding_revision':revision,'compact':True,'report_refs':True};save('new-program-request.json',args)
    reply=await client.call_tool('interface_dispatch',args);save('new-program.json',reply.model_dump(mode='json'))
    keymap=s.d.query_keymap();save('witness-after-new-program.json',{'w_down':bool(keymap[code//8]&(1<<(code%8)))})
    reply=await client.call_tool('interface_results',{'call_id':recovered['call_id']});save('retained-recovery.json',reply.model_dump(mode='json'))
    reply=await client.call_tool('interface_close',{});save('close.json',reply.model_dump(mode='json'))
 keymap=s.d.query_keymap();save('witness-after-close.json',{'w_down':bool(keymap[code//8]&(1<<(code%8)))})
 save('client-completed.json',{'normal_context_exit':True})
try:asyncio.run(main())
finally:
 s.close();save('cleanup.json',[{'pid':p.pid,'code':p.poll()} for p in s.procs])
print(json.dumps({'output':str(out),'completed':True}))
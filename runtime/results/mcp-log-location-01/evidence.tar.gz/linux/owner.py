import json, os, socket, subprocess, sys, time
from pathlib import Path
root = Path(__file__).resolve().parent
display = ':248'
for address in ('/tmp/.X11-unix/X248', '\0/tmp/.X11-unix/X248'):
    with socket.socket(socket.AF_UNIX) as probe:
        try:
            probe.connect(address)
        except OSError:
            pass
        else:
            raise RuntimeError('display already in use')
if Path('/tmp/.X248-lock').exists():
    raise RuntimeError('display lock exists')
env = dict(os.environ, DISPLAY=display, PYTHONDONTWRITEBYTECODE='1')
import tempfile, shutil
log_temp = tempfile.TemporaryDirectory(prefix='ai-fixture-log-')
events_path = Path(log_temp.name)/'events.jsonl'
children = []
try:
    log = (root/'owner-stderr.txt').open('xb')
    xvfb = subprocess.Popen(['Xvfb', display, '-screen', '0', '640x360x24', '-nolisten', 'tcp', '-nolisten', 'unix'], stdout=log, stderr=log)
    children.append(xvfb)
    from Xlib.display import Display
    deadline = time.monotonic()+5
    while True:
        if xvfb.poll() is not None:
            raise RuntimeError('Xvfb exited')
        try:
            conn = Display(display)
            assert (conn.screen().width_in_pixels,conn.screen().height_in_pixels)==(640,360)
            conn.close()
            break
        except Exception:
            if time.monotonic()>deadline: raise
            time.sleep(.05)
    fixture = subprocess.Popen([sys.executable, '-m', 'runtime.backends.x11_v1.fixture_app', '--meta', str(root/'meta.json'), '--effect', str(root/'effect.json'), '--events', str(events_path)], env=env, stdout=log, stderr=log)
    children.append(fixture)
    deadline=time.monotonic()+5
    while not (root/'meta.json').exists():
        if fixture.poll() is not None or time.monotonic()>deadline:
            raise RuntimeError('fixture unavailable')
        time.sleep(.05)
    meta=json.loads((root/'meta.json').read_bytes())
    (root/'targets.json').write_text(json.dumps({'fixture':meta['window_id']}))
    print(json.dumps({'status':'ready','display':display,'pids':[p.pid for p in children],'window':meta['window_id']}),flush=True)
    deadline=time.monotonic()+300
    while not (root/'stop').exists():
        if time.monotonic()>deadline: raise RuntimeError('owner deadline')
        if any(p.poll() is not None for p in children): raise RuntimeError('child exited')
        time.sleep(.1)
finally:
    rows=[]
    for child in reversed(children):
        if child.poll() is None: child.terminate()
        try: child.wait(timeout=3)
        except subprocess.TimeoutExpired:
            child.kill(); child.wait(timeout=3)
        rows.append({'pid':child.pid,'returncode':child.returncode})
    (root/'cleanup.json').write_text(json.dumps({'tracked_processes':rows,'descendants_verified':False}))

    if events_path.exists(): shutil.copyfile(events_path, root/'events.jsonl')
    log_temp.cleanup()

import base64,hashlib,json,pathlib

def require(ok,why):
    if not ok:raise ValueError(why)

def analyze(root):
    root=pathlib.Path(root);read=lambda p:json.loads((root/p).read_text())
    plan=read('PLAN.json')
    for path,digest in plan['hashes'].items():
        require(hashlib.sha256((root/path).read_bytes()).hexdigest()==digest,'frozen source hash')
    host=root/'guarded-local/host'
    req=[read('guarded-local/host/request-'+str(i)+'.json') for i in range(1,8)]
    require([x['tool'] for x in req]==['interface_guarded_observe','interface_guarded_mint','interface_guarded_input','interface_guarded_mint_many','interface_clock','interface_results','interface_close'],'no replay request schedule')
    require(len(list(host.glob('request-*.json')))==len(list(host.glob('reply-*.json')))==7,'call inventory')
    replies=[read('guarded-local/host/reply-'+str(i)+'.json') for i in range(1,8)]
    meta=[json.loads(r['result']['content'][0]['text']) for r in replies]
    require(all(not r['result'].get('isError',False) for r in replies),'tool failure')
    single=meta[1];many=meta[3];clock=meta[4];lookup=meta[5]
    require(single['status']==many['status']=='minted','mint outcome')
    require(not single['input_dispatched'] and not many['input_dispatched'],'mint input')
    require(lookup['minted']==many['minted'] and lookup['operation_invoked'] is False,'retained deadline renewed')
    require(clock['authority_granted'] is False and clock['lease_issued'] is False,'clock authority')
    for item in [single,*many['minted']]:
        lifetime=item['lifetime']
        require(lifetime['clock']=='time.monotonic_ns' and lifetime['authority_granted'] is False,'lifetime authority/clock')
        require(lifetime['expires_ns']-lifetime['minted_ns']==300_000_000_000,'actual finite duration')
        require(lifetime['minted_ns']<=clock['monotonic_ns']<lifetime['expires_ns'],'same-host clock before deadline')
        require(lifetime['capture_freshness_ms']==1500,'capture freshness contract')
    execution=meta[2]['result']['execution']
    require(meta[2]['status']=='completed' and not meta[2]['result']['recovery_required'],'navigation outcome')
    require(execution['program_emissions']==68,'navigation only emissions')
    require(all(x['verified'] is True and not x['keys_down'] and not x['buttons_down'] for x in execution['releases']),'navigation release')
    close=meta[6]
    require(close['status']=='closed' and close['release']['verified'] is True and not close['release']['keys_down'] and not close['release']['buttons_down'],'neutral public close')
    for i in [1,3]:
        review=read('guarded-local/host/review-'+str(i)+'.json')
        require(review['reply_sha256']==hashlib.sha256((host/f'reply-{i}.json').read_bytes()).hexdigest(),'review reply hash')
        blocks=[b for b in replies[i-1]['result']['content'] if b['type']=='image']
        require(len(blocks)==1 and review['images']==[{'mime_type':b['mimeType'],'sha256':hashlib.sha256(base64.b64decode(b['data'],validate=True)).hexdigest()} for b in blocks],'review image')
    score=read('guarded-local/session/evaluation-at-close.json')
    require(score['record_count']==0 and score['exact_counts']=={f'task-{i}':0 for i in range(1,7)} and not score['success'],'independent zero submissions')
    require(not score['unexpected'] and not score['duplicates'],'unexpected submissions')
    terminal=read('process-terminal.json');require(terminal=={'original_session_id':82696,'exit_code':0,'transport':{'code':0,'signal':None}},'original terminal')
    return {'status':'SCOPED_LIFETIME_METADATA_PASS','calls':7,'primary_images':2,'navigation_programs':1,'save_tasks_attempted':0,'tokens':None,'dollars':None,'speed_benefit':None,'source':plan['source'],'seed':plan['seed'],'remaining_at_clock_seconds':[(x['lifetime']['expires_ns']-clock['monotonic_ns'])/1e9 for x in many['minted']],'cleanup':read('guarded-local/session/cleanup.json'),'product_acceptance':'HOLD'}

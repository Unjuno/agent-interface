import json,hashlib,tarfile,base64
from pathlib import Path
r=Path('/var/tmp/agent-interface-integrated-main')
p=r/'runtime/results/primary-layout-feedback-01';p.mkdir()
files={}
for n in ['01','02','03']:
 root=r/f'results-local/primary-layout-feedback-{n}'
 for f in root.rglob('*'):
  if f.is_file():files[f'{n}/{f.relative_to(root).as_posix()}']=f.read_bytes()
h=r/'results-local/primary-layout-feedback-03/primary-layout-feedback-03-host'
events=[json.loads(x) for x in (h/'host-events.jsonl').read_text().splitlines()]
metrics={'scope':'Known task family, fresh task4 seed1001032, unpaired primary use; not held-out generalization or speed/token comparison','allocations':{'01':'STOP_PRESENTATION_CALLBACK after prior setup mistakes','02':'STOP_ALLOCATION_EXPIRED','03':'One requested task independently exact once; all-six aggregate false'},'calls':[]}
for i in range(1,6):
 q=json.loads((h/f'request-{i}.json').read_text());reply=json.loads((h/f'reply-{i}.json').read_text());es={x['kind']:x for x in events if x.get('attempt')==i}; row={'attempt':i,'tool':q['tool'],'send_to_callbacks_ms':es['presentation_callbacks_completed']['host_monotonic_ms']-es['send_requested']['host_monotonic_ms'],'images':[]}
 for c in reply['result']['content']:
  if c['type']=='image':row['images'].append({'png_bytes':len(base64.b64decode(c['data'])),'sha256':hashlib.sha256(base64.b64decode(c['data'])).hexdigest()})
 if q['tool']=='interface_dispatch':
  row['region']=next(x['region'] for x in q['arguments']['program']['ops'] if x['op']=='observe')
  row['fixed_wait_ms']=sum(x.get('timeout_ms',0) for x in q['arguments']['program']['ops'] if x['op']=='wait_update')
 metrics['calls'].append(row)
metrics['author_clock_ms']=[json.loads(files[f'03/author-clock-{i}.json'])['duration_ms'] for i in range(1,4)]
metrics['dispatch_pixels']=sum(x['region'][2]*x['region'][3] for x in metrics['calls'] if 'region' in x)
metrics['dispatch_png_bytes']=sum(y['png_bytes'] for x in metrics['calls'] if 'region' in x for y in x['images'])
files['metrics.json']=(json.dumps(metrics,indent=2)+'\n').encode()
(p/'metrics.json').write_bytes(files['metrics.json'])
with tarfile.open(p/'raw.tar.gz','w:gz') as t:
 import io
 for name,b in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(b);info.mtime=0;t.addfile(info,io.BytesIO(b))
a=(p/'raw.tar.gz').read_bytes();manifest={'archive':{'bytes':len(a),'sha256':hashlib.sha256(a).hexdigest()},'files':[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(files.items())]};(p/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n'); print(json.dumps(metrics,indent=2));print('retained files',len(files),'archive bytes',len(a))
import json,statistics
from pathlib import Path
root=Path('results-local/guarded-mcp-primary-02')
requests={}; replies={};reports={}
for p in (root/'transport').glob('request-*.json'):
 r=json.loads(p.read_text());requests[r['id']]=r
for p in (root/'transport').glob('reply-*.json'):
 r=json.loads(p.read_text());replies[r['id']]=r
 reports[r['id']]=json.loads(r['result']['content'][0]['text'])
timing=[json.loads(x) for x in (root/'host-timing.jsonl').read_text().splitlines()]
inputs=[i for i in requests if requests[i]['tool']=='interface_guarded_input']
completed=[i for i in inputs if reports[i]['status']=='completed']
summary={'status':'PASS_SCOPED_PRIMARY_USE','seed':991329,
 'runtime_source_revision':json.loads(Path('results-local/guarded-mcp-build-02/manifest.json').read_text())['source_revision'],
 'model':'primary assistant; no helper model','model_tokens':None,'model_cost':None,
 'task_result':json.loads((root/'evaluation.json').read_text()),
 'calls':len(replies),'input_calls':len(inputs),'completed_input_calls':len(completed),
 'refused_input_calls':[i for i in inputs if reports[i]['status']!='completed'],
 'mint_calls':sum(r['tool']=='interface_guarded_mint' for r in requests.values()),
 'image_responses':sum(any(b['type']=='image' for b in r['result']['content']) for r in replies.values()),
 'primary_review_receipts':len(list(root.glob('review-*.json'))),
 'host_call_return_ms':{'sum':sum(r['returned_ms']-r['started_ms'] for r in timing),
 'median':statistics.median(r['returned_ms']-r['started_ms'] for r in timing),
 'scope':'Node send through returned relay receipt, including persistence; not model-visible feedback latency'},
 'elapsed_first_send_to_final_save_return_ms':next(r['returned_ms'] for r in timing if r['id']==29)-timing[0]['started_ms'],
 'timing_limits':'Host and Linux monotonic clocks are separate. Includes primary reasoning/tool orchestration. No matched baseline or human comparison; no speed claim.',
 'retention':json.loads((root/'retention-check.json').read_text()),
 'close':reports[31],
 'transport_exit':json.loads((root/'transport/exit.json').read_text()),
 'fixture_process_exit':0,
 'tracked_child_cleanup':json.loads((root/'cleanup.json').read_text()),
 'cleanup_limits':'All tracked children terminal; one child exited 1. No claim that every helper exited zero.',
 'decision':'Integrate as explicit opt-in shared public MCP mode. Preserve existing modes and waits. General efficiency and token benefits remain unproven.'}
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['calls','input_calls','completed_input_calls','refused_input_calls','mint_calls','image_responses','primary_review_receipts','host_call_return_ms','elapsed_first_send_to_final_save_return_ms']},indent=2))
export const meta=r=>JSON.parse(r.result.content.find(x=>x.type==='text').text);
export const nav=url=>[{op:'key_chord',keys:['CTRL','l']},{op:'wait_update',timeout_ms:100},{op:'text',text:url},{op:'wait_update',timeout_ms:100},{op:'key_chord',keys:['ENTER']},{op:'wait_update',timeout_ms:200}];
export const field=token=>[{op:'key_chord',keys:['CTRL','a']},{op:'wait_update',timeout_ms:100},{op:'text',text:token},{op:'wait_update',timeout_ms:100}];
const move=p=>({op:'pointer_move',frame:'screen_physical_px',x:p[0],y:p[1]});
const press=[{op:'pointer_button',button:'left',down:true},{op:'pointer_button',button:'left',down:false}];
export const batch=(token,a,b)=>[move(a),...press,...field(token),move(b),{op:'wait_update',timeout_ms:100},...press,{op:'wait_update',timeout_ms:100}];
const program=(seq,id,expiry,ops)=>({schema:'agent-interface/program-v1',program_id:id,source:{observation_seq:seq,binding_revision:1},authority:{lease_id:'paired-batch-efficiency01-direct',expires_at_ns:expiry},terminal:{release_all_required:true},ops:[{op:'focus',target:'browser'},...ops,{op:'release_all'}]});
import {createPrimaryCaller} from './host-bundle/primary_caller.mjs';
import {createInstrumentedRelayClient} from './host-bundle/relay_host.mjs';
export async function open(ctx,route,sinks){
 const root=ctx.root+'/'+route+'/session';
 const allocation=JSON.parse(await ctx.fs.readFile(root+'/allocation.json','utf8'));
 const goal=JSON.parse(await ctx.fs.readFile(root+'/goal.json','utf8'));
 const targets=JSON.parse(await ctx.fs.readFile(root+'/targets.json','utf8'));
 if(Object.keys(targets).length!==1||!Number.isSafeInteger(targets.browser)||targets.browser<1)throw Error('invalid explicit browser target registry');
 if(allocation.source!==ctx.source||allocation.seed!==ctx.seed)throw Error('allocation drift');
 const directory=ctx.parent+'/paired-batch-efficiency-01-'+route+'-host';
 const host=await createInstrumentedRelayClient({command:'wsl.exe',args:['-d','Ubuntu','-u','taka','--exec','/tmp/agent-interface-mcp-venv/bin/python',ctx.linux+'/runtime.pyz','relay','--','--targets',ctx.linux+'/'+route+'/session/targets.json','--output-directory',ctx.linux+'/'+route+'/session/server','--session-mode',route==='guarded-local'?'guarded-x11':'persistent-x11','--display',allocation.display],evidenceDirectory:directory,minimumEvidenceFreeBytes:128*1024*1024,reuseReviewedImages:false});
 const policy=createPrimaryCaller(host,route,sinks,route==='guarded-local'?ctx.controls:[],{reviewWindowId:targets.browser,observationArguments:{target:'browser',frame:'screen_physical_px',region:[0,0,1280,800],compact:true,report_refs:true}});
 const call=policy.call,refs=new Map(),expiryChecks=[];let seq=1,n=0,clockHost=null;
 return {route,allocation,goal,directory,host,call,refs,expiryChecks,
 reviewWindow:policy.reviewWindow,observe:policy.observe,review:(reply,reason)=>policy.review(reply.attempt,{task:'all-six',phase:'primary',reason}),acknowledgeText:(reply,reason)=>policy.acknowledgeText(reply.attempt,{task:'all-six',phase:'primary',reason}),state:policy.state,
 mintMany:async(sourceSequence,references)=>{const r=await policy.mintMany(sourceSequence,references);const m=meta(r);if(m.status==='minted')for(const ref of m.minted)refs.set(ref.alias,{lifetime:ref.lifetime});return r;},
 mint:async(alias,sourceSequence,point,regionSize)=>{const r=await policy.mint(alias,sourceSequence,point,regionSize);const m=meta(r);if(m.status==='minted')refs.set(alias,{lifetime:m.lifetime});return r;},
 input:async(alias,offset,interaction,tail)=>{
  const sampled=await call('interface_clock',{}),clock=meta(sampled);
  await policy.acknowledgeText(sampled.attempt,{task:'all-six',phase:'clock',reason:'Same-host clock sample for explicitly chosen guarded input; no input authority issued.'});
  if(clock.authority_granted!==false||clock.lease_issued!==false||!Number.isSafeInteger(clock.monotonic_ns))throw Error('clock contract');
  clockHost??=clock.server_instance_id;if(clockHost!==clock.server_instance_id)throw Error('clock host drift');
  const ref=refs.get(alias);if(!ref)throw Error('unknown reference');
  const remaining=ref.lifetime.expires_ns-clock.monotonic_ns;
  if(remaining<=5000000000){expiryChecks.push({alias,clockAttempt:sampled.attempt,remaining_ns:remaining});sinks.text({needs_primary_fresh_grounding:true,alias});return null;}
  return policy.input(alias,offset,interaction,tail);
 },
 direct:async(phase,ops)=>{const sample=await call('interface_clock',{}),c=meta(sample);await policy.acknowledgeText(sample.attempt,{task:'all-six',phase:'clock',reason:'Same-host clock sample for explicitly chosen direct program; no input authority issued.'});if(c.authority_granted!==false||c.lease_issued!==false||!Number.isSafeInteger(c.monotonic_ns))throw Error('clock');const r=await call('interface_dispatch',{program:program(seq,'paired-batch-efficiency01-'+phase+'-'+(++n),c.monotonic_ns+5000000000,ops),current_observation_seq:seq,current_binding_revision:1,compact:true,report_refs:true,detail:'summary',inspect_after:'browser',inspect_after_region:[0,0,1280,800]});seq++;return r;},
 preflight:async()=>{const replies=[];for(const [i,ops] of [nav(goal.tasks[0].url),batch(goal.tasks[0].token,[230,401],[376,401]),batch(goal.tasks[3].token,[630,558],[689,634])].entries()){const r=await call('interface_validate',{program:program(1,'paired-batch-efficiency01-preflight-'+i,5000000000,ops)});if(meta(r).status!=='valid')throw Error('preflight');replies.push(r);}return replies;},
 close:()=>call('interface_close',{})};
}

import argparse,json,sys,time,subprocess,shutil,traceback
from pathlib import Path
repo=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(repo),str(repo/'research/live_control'),str(repo/'research/observation_gating')]
from run_native_six_task_self_use_v1 import PrivateSession
import integrated_efficiency_runtime_v1 as integrated
p=argparse.ArgumentParser();p.add_argument('--route',required=True);p.add_argument('--seed',type=int,required=True);a=p.parse_args()
out=Path(__file__).parent/a.route/'session';out.mkdir(parents=True,exist_ok=False)
def save(n,v):(out/n).write_text(json.dumps(v,indent=2)+'\n')
s=fixture=None
try:
 setup_started_ns=time.monotonic_ns();s=PrivateSession();save('readiness.json',s.window_manager_readiness)
 goal,history,server=integrated.prepare(s,'chromium',a.seed,'/home/taka/.cache/ms-playwright/chromium-1208/chrome-linux64/chrome')
 fixture=integrated._ACTIVE[str(history)]
 line=next(x for x in s.windows().splitlines() if 'about:blank' in x)
 target=int(line.split()[0],16)
 save('goal.json',goal);save('targets.json',{'browser':target})
 save('allocation.json',{'display':s.name,'seed':a.seed,'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'task':'all six tasks','route':a.route,'width':s.d.screen().width_in_pixels,'height':s.d.screen().height_in_pixels})
 save('setup-timing.json',{'started_ns':setup_started_ns,'ready_ns':time.monotonic_ns(),'monotonic':vars(time.get_clock_info('monotonic')),'perf_counter':vars(time.get_clock_info('perf_counter'))});
 print(json.dumps({'ready':True,'route':a.route,'display':s.name,'target':target}),flush=True)
 end=time.monotonic()+1800
 while not (out/'finish.json').exists():
  if time.monotonic()>end:raise TimeoutError('original allocation lifetime expired')
  time.sleep(.05)
 save('evaluation-at-close.json',fixture.evaluate())
 if history.exists():shutil.copyfile(history,out/'submission-history.jsonl')
except BaseException as e:
 save('failure.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
finally:
 if fixture is not None:fixture.close()
 if s is not None:
  s.close();save('cleanup.json',[{'pid':q.pid,'returncode':q.poll()} for q in s.procs])

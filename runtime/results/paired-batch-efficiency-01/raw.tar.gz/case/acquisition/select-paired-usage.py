import json,pathlib
src='/mnt/c/Users/junny/.codex/sessions/2026/09/12/rollout-2026-09-12T23-46-37-01a09615-a96c-7b70-8284-e6391b885be5.jsonl'
r=pathlib.Path('/var/tmp/agent-interface-evidence-storage-main/results-local/paired-batch-efficiency-01')
need={'begin':'call_S56N15sPxBS7m1YagBYfFwvH','cold_end':'call_uWVrYy8OvHLbnJAlG5dnFKq2','direct_begin':'call_OcUthi6xDQfb7rA7FxOpUjc6'};found={};context=None
with open(src,encoding='utf-8') as f:
 for line in f:
  x=json.loads(line);p=x.get('payload',{})
  if x['type']=='turn_context':context={k:p.get(k) for k in ['model','effort','turn_id']}
  if x['type']!='response_item' or p.get('type')!='custom_tool_call':continue
  cid=p['call_id'];code=p.get('input','')
  for k,v in need.items():
   if cid==v:found[k]=cid
  if 'var peDirectExit=await peDirect.host.close();' in code:found['direct_end']=cid
  if 'fixture.py --route guarded-local --seed 1001065' in code and 'guarded-storage-preflight.json' in code:found['guarded_setup']=cid
  if 'var peGuarded=await peModule.open(peCtx' in code:found['guarded_begin']=cid
  if 'var peGExit=await peGuarded.host.close();' in code:found['guarded_end']=cid;break
if set(found)!=set(need)|{'direct_end','guarded_setup','guarded_begin','guarded_end'}:raise ValueError(found)
parts=[('common-cold-and-baseline-allocation','begin','cold_end'),('direct-execution-including-user-interruption','direct_begin','direct_end'),('between-arm-scoring-and-guarded-allocation','guarded_setup','guarded_setup'),('guarded-execution','guarded_begin','guarded_end')]
selection=[dict(name=n,begin_call_id=found[a],end_call_id=found[b]) for n,a,b in parts]
(r/'usage-selection.json').write_text(json.dumps(selection,indent=2)+'\n')
(r/'usage-whole-selection.json').write_text(json.dumps([dict(name='all-acquisition-through-both-close',begin_call_id=found['begin'],end_call_id=found['guarded_end'])],indent=2)+'\n')
print(json.dumps(found));print('ENDCONTEXT',json.dumps(context))

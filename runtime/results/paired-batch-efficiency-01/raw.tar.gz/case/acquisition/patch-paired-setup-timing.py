from pathlib import Path
p=Path('/var/tmp/agent-interface-evidence-storage-main/results-local/paired-batch-efficiency-01/fixture.py')
s=p.read_text().replace(' s=PrivateSession();', " setup_started_ns=time.monotonic_ns();s=PrivateSession();")
s=s.replace(" print(json.dumps({'ready':True", " save('setup-timing.json',{'started_ns':setup_started_ns,'ready_ns':time.monotonic_ns(),'monotonic':vars(time.get_clock_info('monotonic')),'perf_counter':vars(time.get_clock_info('perf_counter'))});\n print(json.dumps({'ready':True")
p.write_text(s)

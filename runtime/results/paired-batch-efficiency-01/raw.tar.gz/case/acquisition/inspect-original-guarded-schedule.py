import json
from pathlib import Path
root=Path('/mnt/c/Users/junny/Documents/Codex/2026-09-27/files-mentioned-by-the-user-codex/production-spine-02-guarded-local-host')
for n in range(1,17):
    r=json.loads((root/f'request-{n}.json').read_text());a=r['arguments'];print(n,r['tool'],{k:v for k,v in a.items() if k!='program'})

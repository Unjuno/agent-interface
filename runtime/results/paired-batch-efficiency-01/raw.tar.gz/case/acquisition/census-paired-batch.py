import json,hashlib,collections,pathlib,shutil
R=pathlib.Path('/var/tmp/agent-interface-evidence-storage-main/results-local/paired-batch-efficiency-01')
P=pathlib.Path('/mnt/c/Users/junny/Documents/Codex/2026-09-27/files-mentioned-by-the-user-codex')
def load(p):return json.loads(p.read_text())
def require(ok,msg):
 if not ok:raise ValueError(msg)
plan=load(R/'PLAN.json')
for n,h in plan['hashes'].items(): require(hashlib.sha256((R/n).read_bytes()).hexdigest()==h,'frozen file drift '+n)
result={'source':plan['source'],'seed':plan['seed'],'frozen_hashes_checked':len(plan['hashes']),'arms':{},'decision':'HOLD_EFFICIENCY','limits':['fixed baseline-first shared context','capability difference between guarded and direct','no independent first useful feedback or exact semantic-perception timestamp','actual usage phase attribution pending; never zero','no human comparator']}
for arm in plan['order']:
 h=P/('paired-batch-efficiency-01-'+arm+'-host'); s=R/arm/'session'
 requests=sorted(h.glob('request-*.json'),key=lambda p:int(p.stem.split('-')[1]))
 toolcounts=collections.Counter(); programs=[];controls=[]; image_count=0
 for q in requests:
  req=load(q);rid=req['id'];reply=load(h/('reply-'+str(rid)+'.json'));toolcounts[req['tool']]+=1
  m=json.loads(next(x['text'] for x in reply['result']['content'] if x['type']=='text'))
  imgs=[x for x in reply['result']['content'] if x['type']=='image'];image_count+=len(imgs)
  require((h/(('review-' if imgs else 'text-acknowledgment-')+str(rid)+'.json')).is_file(),'missing primary evidence acknowledgement '+arm+str(rid))
  e=m.get('result',{}).get('execution') or m.get('receipt',{}).get('execution_summary')
  if e:
   releases=e['releases'];require(releases and all(x['verified'] is True and not x['keys_down'] and not x['buttons_down'] for x in releases),'nonneutral program')
   waits=e.get('wait_summary')
   delay=waits['requested_ms_total'] if waits else sum(x['requested_ms'] for x in e.get('waits',[]))
   programs.append({'attempt':rid,'requested_wait_ms':delay,'program_emissions':e['program_emissions'],'execution_ns':e['ended_ns']-e['started_ns']})
  if m.get('status')=='refused': controls.append({'attempt':rid,'tool':req['tool'],'metadata':m})
  if req['tool']=='interface_close': require(m['status']=='closed' and m['release']['verified'] and not m['release']['keys_down'] and not m['release']['buttons_down'],'close not neutral')
 score=load(s/'evaluation-at-close.json');hist=[json.loads(x) for x in (s/'submission-history.jsonl').read_text().splitlines()]
 require(score['success'] and score['record_count']==6 and len(hist)==6 and all(v==1 for v in score['exact_counts'].values()),'independent score failure')
 require(load(h/'exit.json')['code']==0,'host exit failure')
 finish=load(s/'finish.json');require(finish['host_exit']['code']==0,'recorded host exit failure')
 result['arms'][arm]={'public_calls':len(requests),'tool_counts':dict(toolcounts),'programs':programs,'program_count':len(programs),'program_emissions':sum(x['program_emissions'] for x in programs),'requested_wait_ms':sum(x['requested_wait_ms'] for x in programs),'original_image_deliveries':image_count,'extra_same_file_previews':1 if arm=='direct-post' else 0,'independent_score':score,'controls':controls,'alias_expiry_checks':finish['expiry_checks'],'child_cleanup':load(s/'cleanup.json'),'host_exit':load(h/'exit.json')}
 require(len(controls)==(3 if arm=='guarded-local' else 0),'unexpected refusal inventory')
 dest=R/arm/'host';require(not dest.exists(),'host copy already exists');shutil.copytree(h,dest)
(R/'preliminary-census.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({a:{k:v for k,v in data.items() if k in ['public_calls','program_count','program_emissions','requested_wait_ms','original_image_deliveries','extra_same_file_previews']} for a,data in result['arms'].items()},indent=2))

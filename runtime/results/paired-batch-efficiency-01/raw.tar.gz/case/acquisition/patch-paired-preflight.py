from pathlib import Path
p=Path('/var/tmp/agent-interface-evidence-storage-main/results-local/paired-batch-efficiency-01/caller.mjs')
s=p.read_text();a="preflight:async()=>{for(const [i,ops]";b="preflight:async()=>{const replies=[];for(const [i,ops]"
if s.count(a)!=1:raise RuntimeError('preflight anchor')
s=s.replace(a,b)
a="if(meta(r).status!=='valid')throw Error('preflight');}},";b="if(meta(r).status!=='valid')throw Error('preflight');replies.push(r);}return replies;},"
if s.count(a)!=1:raise RuntimeError('preflight return anchor')
s=s.replace(a,b);p.write_text(s)

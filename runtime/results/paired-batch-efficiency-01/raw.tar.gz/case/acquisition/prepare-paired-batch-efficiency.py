import json,shutil,subprocess
from pathlib import Path
repo=Path('/var/tmp/agent-interface-evidence-storage-main');root=repo/'results-local/paired-batch-efficiency-01';old=repo/'results-local/production-spine-02'
for name in ('fixture.py','caller.mjs','controls.json'):
    text=(old/name).read_text().replace('production-spine-02','paired-batch-efficiency-01').replace('production-spine02','paired-batch-efficiency01').replace('1001062','1001065')
    if name=='caller.mjs':
        anchor=" mint:async(alias,sourceSequence,point,regionSize)=>"
        addition=" mintMany:async(sourceSequence,references)=>{const r=await policy.mintMany(sourceSequence,references);const m=meta(r);if(m.status==='minted')for(const ref of m.minted)refs.set(ref.alias,{lifetime:ref.lifetime});return r;},\n"
        if text.count(anchor)!=1:raise RuntimeError('caller anchor mismatch')
        text=text.replace(anchor,addition+anchor)
    (root/name).write_text(text)
command=['python3',str(repo/'runtime/distribution_v2/build.py'),'--root',str(repo),'--out',str(root/'runtime.pyz'),'--manifest',str(root/'build-manifest.json'),'--sums',str(root/'SHA256SUMS'),'--host-directory',str(root/'host-bundle')]
r=subprocess.run(command,capture_output=True);(root/'build.stdout').write_bytes(r.stdout);(root/'build.stderr').write_bytes(r.stderr)
if r.returncode:raise RuntimeError('build failed')
r=subprocess.run(['/home/taka/.volta/bin/node','--check',str(root/'caller.mjs')],capture_output=True);(root/'caller-check.stdout').write_bytes(r.stdout);(root/'caller-check.stderr').write_bytes(r.stderr)
if r.returncode:raise RuntimeError('caller syntax failed')
for name in ['research/live_control/run_native_six_task_self_use_v1.py','research/live_control/integrated_efficiency_fixture_v1.py','research/live_control/integrated_efficiency_runtime_v1.py','research/live_control/x11_window_manager_ready_v1.py','research/observation_gating/gui_suite.py','research/observation_gating/exact_gate.py','research/real_apps_v1/real_app_suite_v1.py']:
    target=root/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/name,target)
print(json.dumps({'root':str(root),'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'candidate':'guarded batch registration plus fresh guarded input; public direct baseline keeps full program batching'}))

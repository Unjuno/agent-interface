# Frozen composition for one six-task paired report

Issue #57 / #2789. New seed 1001065; no prior allocation is replayed.

Included: committed public portable runtime; persistent-X11 direct program
batching and opt-in post-release capture/summary; guarded-X11 same-source batch
registration, fresh per-input visual guards and finite alias lifetime; sequential
primary caller STOP policy; explicit window review/revocation; same-host clock
sampling; original text/image delivery and attribution; independent six-task
append-only submission/effect scorer. All operations use this primary model,
requested gpt-6.1-sol / medium. No model delegates are launched.

Excluded: optional local model, asynchronous model boundary, sensor/watcher,
automatic repair, compiled GUI graph not exposed by this public entry path,
exact-PNG presentation reuse and new form-method API. These exclusions do not
mean those historical research results are invalid or irrelevant. The selection
is the existing exercised public bundle; the comparison tests its actual costs.

Baseline retains real direct batching: one navigation program and one complete
field/Save program per task, same 800ms requested fixed delays per task, same
scope/focus/lease/release invariants and post-release image. The candidate retains
guarded navigation, field entry, Save motion, explicit hovered-source click mint,
Save click; initial field/Save references and changed-layout field/Save references
use the newly integrated batch helper. Every image is reviewed before input.

Both arms: fresh Chromium/Xvfb profiles, same six A/A/A/B/B/B tasks and tokens,
baseline then candidate order, no context reset. Task1 acquisition, tasks2/3
warm reuse, task4 invalidation/repair, tasks5/6 post-repair reuse. Baseline uses
fresh visual coordinates at task4. Candidate additionally exercises old-layout
zero-input refusal, explicit window review, old-source and old-alias refusal.
These additional control capabilities/costs are disclosed, not normalized away.

One fresh observation per navigation or Save is permitted only if its intended
cue is incomplete; no repeated input. Candidate task5 also has one prospective
fresh-grounding observation. An alias with <=5s remaining yields no input and
permits one explicit fresh observe/unique registration before a new decision;
expiry after dispatch is STOP. Original image presentation failures permit only
same-file preview with separately recorded cost. No unbounded observation loop.

Freeze six rows per arm, order, budget (one allocation per arm, 30min fixture
lifetime), schema preflight, controls and stopping rule before either arm starts.
First unexpected refusal/partial/transport uncertainty/invalid attribution stops
that arm; cleanup never retries its input. Arm2 may start only after Arm1's host
and private fixture are authoritatively terminal. All failed/missing rows remain.

All-attempt accounting: retain cold shared preparation separately, per-arm fixture
setup, schema/preflight, each task's navigation/grounding/input/observation/control,
repair and close. Usage comes from actual per-response session records, including
non-input/failed responses within the selected windows; deduplicate response IDs,
do not add diagnostic cumulative counters or cache/reasoning subsets twice.
No arbitrary split of shared acquisition or missing-cost-as-zero. Historical
research/development is outside this allocation; actual dollars stay unavailable.

Decision: correctness failure is REJECT for that scoped task path. Incomplete
accounting, unavailable independent useful/semantic timing, non-comparable safety
capabilities or uncontrolled context/order is HOLD for efficiency adoption.
For an otherwise comparable complete finite report, meaningful token benefit
requires >=10% lower cumulative actual input over all six tasks with cold costs
charged and correctness/release preserved; output, uncached usage, latency and
dollars remain separate outcomes. No result is rerun to cross this threshold.
Fixed order/shared context already preclude causal/general speed or token claims;
report the observed finite costs and HOLD rather than relabel that limitation.

Host send/reply/callback/review timings are observable bookkeeping endpoints.
They are not independently timed first useful feedback or exact model perception.
Raw fixture effect times, capture brackets and original cue declarations remain
separate. No human comparator is present. Full Agent Interface goal remains open.

import json,shutil,tempfile,hashlib
from pathlib import Path
from audit import audit

root=Path(__file__).parent
audit(root)
for kind in ['receipt-status','missing-presentation','rehashed-error-status']:
    with tempfile.TemporaryDirectory() as directory:
        changed=Path(directory);shutil.copytree(root/'primary-host',changed/'primary-host')
        host=changed/'primary-host'
        if kind=='receipt-status':
            path=host/'text-acknowledgment-2.json';row=json.loads(path.read_text());row['isError']=False;path.write_text(json.dumps(row))
        elif kind=='missing-presentation':
            path=host/'host-events.jsonl';rows=[json.loads(x) for x in path.read_text().splitlines()];rows[3]['kind']='reply_available';path.write_text(''.join(json.dumps(x)+'\n' for x in rows))
        else:
            path=host/'reply-2.json';row=json.loads(path.read_text());row['result']['isError']=False;path.write_text(json.dumps(row));digest=hashlib.sha256(path.read_bytes()).hexdigest()
            receipt=host/'text-acknowledgment-2.json';row=json.loads(receipt.read_text());row['reply_sha256']=digest;row['isError']=False;receipt.write_text(json.dumps(row))
            path=host/'host-events.jsonl';rows=[json.loads(x) for x in path.read_text().splitlines()]
            for row in rows:
                if row.get('attempt')==2 and 'reply_sha256' in row:row['reply_sha256']=digest
            path.write_text(''.join(json.dumps(x)+'\n' for x in rows))
        try: audit(changed)
        except ValueError as error: print(kind+': rejected '+str(error))
        else: raise RuntimeError('negative control accepted: '+kind)
print('Original evidence and three negative controls passed')

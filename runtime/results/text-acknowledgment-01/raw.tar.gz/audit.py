import hashlib,json,sys,copy
from pathlib import Path

def require(value, message):
    if not value: raise ValueError(message)

def audit(root):
    root=Path(root); host=root/'primary-host'
    events=[json.loads(line) for line in (host/'host-events.jsonl').read_text().splitlines()]
    require([r['sequence'] for r in events]==list(range(1,17)), 'event sequence')
    require([r['kind'] for r in events]==['send_requested','reply_available','presentation_started','presentation_callbacks_completed','text_acknowledgment_recorded']*3+['transport_closed'],'original presentation and acknowledgment order')
    require(json.loads((host/'exit.json').read_text())=={'code':0,'signal':None},'original transport exit')
    require(len(list(host.glob('request-*.json')))==3,'request denominator')
    require(not list(host.glob('review-*.json')),'no image review')
    for attempt,tool,error in [(1,'interface_validate',True),(2,'interface_guarded_mint',True),(3,'interface_clock',False)]:
        reply_bytes=(host/f'reply-{attempt}.json').read_bytes()
        reply=json.loads(reply_bytes); request=json.loads((host/f'request-{attempt}.json').read_bytes())
        receipt=json.loads((host/f'text-acknowledgment-{attempt}.json').read_bytes())
        digest=hashlib.sha256(reply_bytes).hexdigest(); rows=events[(attempt-1)*5:attempt*5]
        require(request['tool']==tool and reply['tool']==tool,'tool identity')
        require(reply['status']=='returned' and reply['result']['isError'] is error,'unchanged typed status')
        require(all(b['type']=='text' and isinstance(b['text'],str) for b in reply['result']['content']),'text only')
        require(receipt['schema']=='agent-interface/text-acknowledgment-v1' and receipt['attempt']==attempt,'receipt identity')
        require(receipt['tool']==tool and receipt['relay_id']==reply['id'] and receipt['isError'] is error,'receipt original status')
        require(receipt['reply_sha256']==digest and all(r['reply_sha256']==digest for r in rows[1:]),'reply digest correspondence')
        require(all(r['attempt']==attempt for r in rows),'host attempt correspondence')
    require(json.loads((host/'reply-1.json').read_text())['result']['content'][0]['text'].find('INVALID_PROGRAM')>=0,'invalid program control')
    require(json.loads((host/'reply-2.json').read_text())['result']['content'][0]['text']=='Unknown tool: interface_guarded_mint','unavailable tool control')
    clock=json.loads(json.loads((host/'reply-3.json').read_text())['result']['content'][0]['text'])
    require(clock['input_dispatched'] is False and clock['authority_granted'] is False and clock['lease_issued'] is False,'clock has no authority')
    return {'status':'PASS_TEXT_ACKNOWLEDGMENT_ONLY','calls':3,'text_acknowledgments':3,'image_reviews':0,'gui_task_success':None,'speedup':None,'tokens_cost':None,'transport_exit':0}

if __name__=='__main__': print(json.dumps(audit(sys.argv[1] if len(sys.argv)>1 else Path(__file__).parent),indent=2))

import sys,json
from pathlib import Path
from native_exchange_v1 import run
root=Path(__file__).resolve().parent
stage=int(sys.argv[1])
result=run(root/'run',stage,json.loads((root/f'decision-{stage}.json').read_bytes()),timeout=5,compact=True)
with (root/f'response-{stage}.json').open('x') as f: json.dump(result,f)
print(json.dumps({k:v for k,v in result.items() if k not in ('image','receipt')}))

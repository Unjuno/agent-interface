import asyncio,base64,json,os,socket,subprocess,sys,time
from pathlib import Path
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
root=Path(__file__).resolve().parent;repo=root.parents[1]
def save(n,o):(root/n).write_text(json.dumps(o,indent=2),encoding='utf-8')
async def main():
 children=[];display=':248';env=dict(os.environ,DISPLAY=display,PYTHONPATH=str(repo))
 if Path('/tmp/.X248-lock').exists():raise RuntimeError('display occupied')
 for address in ('/tmp/.X11-unix/X248','\0/tmp/.X11-unix/X248'):
  with socket.socket(socket.AF_UNIX) as p:
   try:p.connect(address)
   except OSError:pass
   else:raise RuntimeError('display occupied')
 svg=root/'shape.svg';svg.write_text('<svg xmlns="http://www.w3.org/2000/svg" width="200" height="160" viewBox="0 0 200 160"><rect x="50" y="50" width="40" height="30" fill="red"/></svg>')
 log=(root/'process.log').open('w');conn=None
 try:
  children.append(subprocess.Popen(['Xvfb',display,'-screen','0','1024x768x24','-nolisten','tcp','-nolisten','unix'],env=env,stdout=log,stderr=log))
  from Xlib.display import Display
  for _ in range(100):
   try:conn=Display(display);break
   except Exception:await asyncio.sleep(.05)
  assert conn
  children.append(subprocess.Popen(['openbox'],env=env,stdout=log,stderr=log))
  children.append(subprocess.Popen(['inkscape','--new-window',str(svg)],env=env,stdout=log,stderr=log))
  def find(w):
   try:
    title=w.get_wm_name() or ''
    if 'shape.svg' in title and 'Inkscape' in title and w.get_attributes().map_state==2:return w
    for c in w.query_tree().children:
     found=find(c)
     if found:return found
   except Exception:pass
  target=None
  for _ in range(200):
   target=find(conn.screen().root)
   if target:break
   if children[-1].poll() is not None:raise RuntimeError('application exited')
   await asyncio.sleep(.05)
  assert target,'no target'
  geo=target.get_geometry();save('targets.json',{'inkscape':target.id});save('allocation.json',{'pids':[c.pid for c in children],'target':target.id,'width':geo.width,'height':geo.height,'display':display})
  params=StdioServerParameters(command=sys.executable,cwd=str(repo),env=env,args=['-m','runtime.cli_v1.mcp_server','--targets',str(root/'targets.json'),'--output-directory',str(root/'calls'),'--display',display])
  with (root/'server.log').open('w') as err:
   async with stdio_client(params,errlog=err) as (reader,writer):
    async with ClientSession(reader,writer) as client:
     await client.initialize()
     async def call(name,args,label):
      save(label+'-request.json',args);result=await client.call_tool(name,args);save(label+'-reply.json',result.model_dump(mode='json'))
      for b in result.content:
       if b.type=='image':(root/(label+'.png')).write_bytes(base64.b64decode(b.data))
      print(label+' ready',flush=True)
     observe={'target':'inkscape','frame':'window_client','region':[0,0,geo.width,geo.height]}
     await call('interface_observe',observe,'initial')
     for stage in (1,2):
      path=root/f'decision-{stage}.json'
      for _ in range(1800):
       if path.exists():break
       await asyncio.sleep(.1)
      assert path.exists(),'no primary decision'
      program=json.loads(path.read_text());program['authority']['expires_at_ns']=time.monotonic_ns()+10_000_000_000
      await call('interface_dispatch',{'program':program,'current_observation_seq':stage,'current_binding_revision':0},f'action-{stage}')
     for _ in range(1200):
      if (root/'observe-final').exists():break
      await asyncio.sleep(.1)
     assert (root/'observe-final').exists()
     await call('interface_observe',observe,'final')
     for _ in range(600):
      if (root/'review-complete').exists():break
      await asyncio.sleep(.1)
     assert (root/'review-complete').exists()
 finally:
  if conn:conn.close()
  for child in reversed(children):
   if child.poll() is None:child.terminate()
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:child.kill();child.wait(timeout=3)
  save('cleanup.json',{'tracked_processes':[{'pid':c.pid,'returncode':c.returncode} for c in children],'descendants_verified':False});log.close()
asyncio.run(main())

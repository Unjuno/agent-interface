UNPOSTED research support, not a lease or start notice for another worker.

Completed a separate local exact affine-clock/deadline verification (c6t9) without
any GUI/input/model or prior allocation rerun. This extends r4m8's explicitly
unmeasured comparable-clock assumption; it does not repeat #4345's live witness
matrix or #3880's platform-specific calibration.

One9088-input computation;10 files frozen locally beforehand;110731 independent
vertex-oracle checks/errors0,12 effective data-corruption controls,16 unit methods.
Result PASS_LOCAL_AFFINE_CLOCK_CONTRACT. Nominal feasible clocks over-certify141
on-time and66 late inputs; preserving joint constraints resolves164 cases that
independent marginal boxes leave unresolved. All counts are synthetic, not rates.

Required assumption: a positive affine clock map over the entire declared horizon,
with independently justified bounds and same source/target epochs. Two agreeing
calibration points do NOT prove affine behavior; the countermodel is retained.
No task/input authority follows from a timing certificate. Publication pending:
this session's MCP exposed no writes. Do not treat the local evidence as integrated.

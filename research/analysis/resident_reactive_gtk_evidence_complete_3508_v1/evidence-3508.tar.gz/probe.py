import os, subprocess, time, hashlib
from Xlib import X, display
from Xlib.ext import xtest

os.environ['DISPLAY'] = ':200'
xv = subprocess.Popen(['/usr/bin/Xvfb', ':200', '-screen', '0', '640x480x24', '-nolisten', 'tcp'], stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
try:
    time.sleep(.3)
    state='/tmp/probe-title'
    app=subprocess.Popen(['python3','/src/fixture.py',state], stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    d=display.Display(); root=d.screen().root
    w=None
    for _ in range(100):
        time.sleep(.05)
        for c in root.query_tree().children:
            try:
                n=c.get_wm_name()
                if n and n.startswith('resident-fixture:'): w=c; break
            except Exception: pass
        if w: break
    assert w, 'GTK window not found'
    before=root.get_image(0,0,640,480,X.ZPixmap,0xffffffff).data
    w.set_input_focus(X.RevertToParent,X.CurrentTime); d.sync()
    k=d.keysym_to_keycode(32)
    xtest.fake_input(d,X.KeyPress,k); d.sync(); xtest.fake_input(d,X.KeyRelease,k); d.sync()
    for _ in range(50):
        time.sleep(.02)
        if w.get_wm_name()=='resident-fixture:1': break
    polls=0
    for polls in range(1,51):
        after=root.get_image(0,0,640,480,X.ZPixmap,0xffffffff).data
        if hashlib.sha256(before).digest()!=hashlib.sha256(after).digest(): break
        time.sleep(.01)
    assert w.get_wm_name()=='resident-fixture:1', f'title={w.get_wm_name()!r}'
    d.sync(); time.sleep(.05)
    assert hashlib.sha256(before).digest()!=hashlib.sha256(after).digest(), 'screenshot bytes did not change'
    print('CONSTRUCTION_PASS',polls,hashlib.sha256(before).hexdigest(),hashlib.sha256(after).hexdigest(),len(before),len(after))
finally:
    if 'app' in locals(): app.terminate(); app.wait(timeout=3)
    xv.terminate(); xv.wait(timeout=3)

# Resident GTK evidence bundle — allocation 03

Decision: `PASS_SYNTHETIC_RESIDENT_GTK_EVIDENCE_COMPLETE`, narrowly scoped to this synthetic policy harness and local GTK/X11 fixture.

`raw.jsonl` contains all 36 formal rows. Each row names its before/after X11 capture and SHA-256. To keep the bundle small without losing image bytes, `captures/` stores one gzip-compressed copy per distinct SHA-256. `reconstruct.py` verifies each decompressed hash/size and reconstructs all 72 named screenshots in `out/`, alongside the raw JSONL and cleanup receipt. The three unique captures are all exactly 1,228,800 bytes.

The original local run output contained 72 separate capture files. The raw JSONL hash and cleanup receipt hash are unchanged from the original output. Source hashes are recorded in `FREEZE.json`; `probe.py` is construction-only and was not used to generate formal rows.

Reproduce the independent audit from an extracted bundle with:

```sh
python3 reconstruct.py .
python3 audit.py out
```

Formal container: OrbStack, linux/arm64, pinned image `sha256:69bc215db0514ee1bc4f730cceb296ecef89e4418cea8d4b2fc2ca3101101e27`, network disabled. No production runtime or user task was tested.

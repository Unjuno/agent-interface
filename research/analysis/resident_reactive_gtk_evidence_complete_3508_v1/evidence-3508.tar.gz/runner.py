import os, sys, json, time, hashlib, subprocess, signal
from pathlib import Path
from Xlib import X, display
from Xlib.ext import xtest

OUT=Path(sys.argv[1])
if not OUT.is_dir() or any(OUT.iterdir()): raise RuntimeError('OUTPUT_PATH_MUST_EXIST_AND_BE_EMPTY')
ALLOCATION='issue3201-resident-gtk-evidence-complete-03'
SOURCE_COMMIT='7cda063936b89c3f0cd58c0ebd1b78497e0ad2b8'
IMAGE='sha256:69bc215db0514ee1bc4f730cceb296ecef89e4418cea8d4b2fc2ca3101101e27'
SRC=Path('/src'); FIX=SRC/'fixture.py';
CASES=[
 ('valid_rising_edge',[{'kind':'obs','id':'v0','seq':1,'gen':1,'target':1,'value':False},{'kind':'obs','id':'v1','seq':2,'gen':1,'target':1,'value':True}],1,'on'),
 ('revoked_stale',[{'kind':'obs','id':'r1','seq':1,'gen':1,'target':1,'value':True},{'kind':'revoke','seq':2,'gen':1}],0,'on'),
 ('delayed_old_after_new_false',[{'kind':'obs','id':'d0','seq':1,'gen':1,'target':1,'value':False},{'kind':'replace','seq':3,'gen':2,'target':2,'current_value':False},{'kind':'obs','id':'d1','seq':2,'gen':1,'target':1,'value':True}],0,'on'),
 ('duplicate_trigger_release',[{'kind':'obs','id':'u0','seq':1,'gen':1,'target':1,'value':False},{'kind':'obs','id':'u1','seq':2,'gen':1,'target':1,'value':True},{'kind':'trigger_duplicate','id':'u1','seq':3,'gen':1,'target':1,'value':True}],1,'on'),
 ('reordered_observation_control',[{'kind':'obs','id':'o0','seq':1,'gen':1,'target':1,'value':False},{'kind':'obs','id':'o2','seq':3,'gen':1,'target':1,'value':True},{'kind':'obs','id':'o1','seq':2,'gen':1,'target':1,'value':False,'delayed':True}],1,'on'),
 ('target_replacement',[{'kind':'replace','seq':1,'gen':2,'target':2,'current_value':False},{'kind':'obs','id':'t1','seq':2,'gen':1,'target':1,'value':True}],0,'on'),
 ('restart_replay',[{'kind':'persist','id':'p1','seq':2,'gen':1,'target':1,'value':True},{'kind':'restart','seq':3,'gen':2,'target':1},{'kind':'replay','id':'p1','seq':2,'gen':1,'target':1,'value':True}],0,'on'),
 ('planner_unavailable',[{'kind':'obs','id':'a0','seq':1,'gen':1,'target':1,'value':False},{'kind':'obs','id':'a1','seq':2,'gen':1,'target':1,'value':True},{'kind':'planner_unavailable','seq':3}],1,'on'),
 ('effect_unavailable',[{'kind':'obs','id':'e0','seq':1,'gen':1,'target':1,'value':False},{'kind':'obs','id':'e1','seq':2,'gen':1,'target':1,'value':True}],0,'off'),
]
POLICIES=['GENERATION_BOUND_RESIDENT_REACTOR','LAST_MESSAGE','MESSAGE_COUNT','RESTART_REPLAY_UNGUARDED']

def decide(policy, events):
 obs=[e for e in events if e.get('kind') in ('obs','trigger_duplicate') and e.get('value')]
 valid=[]; prev={}
 for e in events:
  if e.get('kind') in ('obs','trigger_duplicate'):
   k=(e.get('gen'),e.get('target'))
   rising=e.get('value') and not prev.get(k,False)
   if rising: valid.append(e)
   prev[k]=e.get('value',False)
 if policy=='GENERATION_BOUND_RESIDENT_REACTOR':
  generation=max((e.get('gen',0) for e in events),default=1)
  target=max((e.get('target',0) for e in events),default=1)
  revoked=any(e.get('kind')=='revoke' for e in events)
  return [e['id'] for e in valid if e.get('gen')==generation and e.get('target')==target and not revoked and e.get('kind')=='obs'][:1]
 if policy=='LAST_MESSAGE': return [e['id'] for e in obs]
 if policy=='MESSAGE_COUNT': return [e['id'] for e in obs]
 if policy=='RESTART_REPLAY_UNGUARDED':
  out=[e['id'] for e in obs]
  if any(e.get('kind')=='replay' for e in events): out += [e['id'] for e in events if e.get('kind')=='replay']
  return out

def digest(b): return hashlib.sha256(b).hexdigest()
os.environ['DISPLAY']=':200'
xv=subprocess.Popen(['/usr/bin/Xvfb',':200','-screen','0','640x480x24','-nolisten','tcp'],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
rows=[]
try:
 time.sleep(.25); d=display.Display(); root=d.screen().root; run=0
 for cname,events,expected,mode in CASES:
  for policy in POLICIES:
   run+=1; rid=f'{run:02d}'; titlefile=f'/tmp/title-{rid}'
   app=subprocess.Popen(['python3',str(FIX),titlefile],env={**os.environ,'EFFECT_MODE':mode},stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
   win=None
   for _ in range(100):
    time.sleep(.02)
    for c in root.query_tree().children:
     try:
      n=c.get_wm_name()
      if n and n.startswith('resident-fixture:'): win=c; break
     except Exception: pass
    if win: break
   if not win: raise RuntimeError('GTK_WINDOW_NOT_FOUND:'+rid)
   d.sync(); time.sleep(.05)
   pid=app.pid; start=int(Path(f'/proc/{pid}/stat').read_text().split()[21]); xid=win.id
   initial=win.get_wm_name(); before=root.get_image(0,0,640,480,X.ZPixmap,0xffffffff).data
   emissions=decide(policy,events)
   actions=[]
   win.set_input_focus(X.RevertToParent,X.CurrentTime); d.sync(); key=d.keysym_to_keycode(32)
   for eid in emissions:
    xtest.fake_input(d,X.KeyPress,key); d.sync(); xtest.fake_input(d,X.KeyRelease,key); d.sync()
    keymap=d.query_keymap(); released=not bool(keymap[key//8] & (1 << (key%8)))
    want=f'resident-fixture:{len(actions)+1}'
    for _ in range(50):
     time.sleep(.01)
     if win.get_wm_name()==want: break
    title=win.get_wm_name(); actions.append({'event_id':eid,'keycode':key,'keysym':'space','observed_title':title,'release_verified':released})
    d.sync(); time.sleep(.05)
   d.sync(); time.sleep(.05)
   after=root.get_image(0,0,640,480,X.ZPixmap,0xffffffff).data
   Path(OUT/f'{rid}-before.x11raw').write_bytes(before); Path(OUT/f'{rid}-after.x11raw').write_bytes(after)
   final=win.get_wm_name(); effect=int(final.split(':')[-1]); app.terminate(); app.wait(timeout=3)
   row={'allocation_id':ALLOCATION,'source_commit':SOURCE_COMMIT,'image_digest':IMAGE,'redraw_settle_ms':50,'run_id':run,'case':cname,'policy':policy,'events':events,'expected_task_effect':expected,'effect_mode':mode,'emissions':emissions,'actions':actions,'effect_count_observed':effect,'initial_title':initial,'final_title':final,'x11_window_id':xid,'gtk_pid':pid,'gtk_start_ticks':start,'gtk_exit':app.returncode,'release_verified_all':all(a['release_verified'] for a in actions),'before_file':f'{rid}-before.x11raw','after_file':f'{rid}-after.x11raw','before_sha256':digest(before),'after_sha256':digest(after),'before_bytes':len(before),'after_bytes':len(after)}
   if mode=='off': cls='TRANSPORT_WITHOUT_EFFECT' if emissions and effect==0 else 'HOLD'
   elif expected==0 and effect==0: cls='SAFE_REFUSAL' if not emissions else 'CONTROL_UNSAFE_WITNESS'
   elif expected==0: cls='CONTROL_UNSAFE_WITNESS'
   elif effect==expected: cls='VERIFIED_TASK_EFFECT'
   else: cls='NO_EFFECT_EXPECTED_POSITIVE'
   row['outcome_class']=cls; row['task_effect_satisfied']=cls=='VERIFIED_TASK_EFFECT'; rows.append(row)
 with open(OUT/'raw.jsonl','w') as f:
  for r in rows: f.write(json.dumps(r,sort_keys=True,separators=(',',':'))+'\n')
 print(json.dumps({'allocation':ALLOCATION,'rows':len(rows),'run_id_range':[1,len(rows)],'xvfb_pid':xv.pid,'image_digest':IMAGE,'raw_sha256':digest((OUT/'raw.jsonl').read_bytes())},sort_keys=True))
finally:
 xv.terminate(); xv.wait(timeout=3)
 (OUT/'cleanup.json').write_text(json.dumps({'xvfb_pid':xv.pid,'xvfb_exit':xv.returncode,'xvfb_waited':xv.poll() is not None,'gtk_children_all_exit_zero':all(r.get('gtk_exit')==0 for r in rows),'key_releases_all_verified':all(r.get('release_verified_all') for r in rows),'rows_written':len(rows)},sort_keys=True)+'\n')

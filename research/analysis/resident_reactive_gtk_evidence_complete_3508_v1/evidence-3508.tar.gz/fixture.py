import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib
import os, sys, signal

title_file = sys.argv[1]
win = Gtk.Window(title="resident-fixture:0")
win.set_default_size(440, 180)
label = Gtk.Label(label="resident-fixture:0")
win.add(label)
count = 0
def key(_w, ev):
    global count
    if ev.keyval == 32:
        if os.environ.get("EFFECT_MODE", "on") == "off": return True
        count += 1
        s = f"resident-fixture:{count}"
        label.set_text(s)
        win.set_title(s)
        with open(title_file, "w") as f: f.write(s)
        return True
    return False
win.connect("key-press-event", key)
win.connect("destroy", Gtk.main_quit)
signal.signal(signal.SIGTERM, lambda *_: GLib.idle_add(Gtk.main_quit))
win.show_all()
GLib.timeout_add(100, lambda: (open(title_file,"w").write(win.get_title()) if not os.path.exists(title_file) else None) or False)
Gtk.main()

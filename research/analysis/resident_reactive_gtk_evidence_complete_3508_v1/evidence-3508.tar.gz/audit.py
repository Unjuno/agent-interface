import sys,json,hashlib
from pathlib import Path

root=Path(sys.argv[1]); errors=[]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
rows=[json.loads(x) for x in (root/'raw.jsonl').read_text().splitlines()]
allocation='issue3201-resident-gtk-evidence-complete-03'
source_commit='7cda063936b89c3f0cd58c0ebd1b78497e0ad2b8'
image_digest='sha256:69bc215db0514ee1bc4f730cceb296ecef89e4418cea8d4b2fc2ca3101101e27'
expected_cases={'valid_rising_edge':1,'revoked_stale':0,'delayed_old_after_new_false':0,'duplicate_trigger_release':1,'reordered_observation_control':1,'target_replacement':0,'restart_replay':0,'planner_unavailable':1,'effect_unavailable':0}
policies={'GENERATION_BOUND_RESIDENT_REACTOR','LAST_MESSAGE','MESSAGE_COUNT','RESTART_REPLAY_UNGUARDED'}
def independent(policy,events):
 truth=[e for e in events if e.get('value') is True and e.get('kind') in ('obs','trigger_duplicate')]
 if policy=='GENERATION_BOUND_RESIDENT_REACTOR':
  generations=[e.get('gen',0) for e in events]; targets=[e.get('target',0) for e in events]
  curgen=max(generations,default=1); curtarget=max(targets,default=1)
  if any(e.get('kind')=='revoke' for e in events): return []
  prev={}; fires=[]
  for e in events:
   key=(e.get('gen'),e.get('target'))
   if e.get('kind')=='obs' and e.get('value') and not prev.get(key,False) and key==(curgen,curtarget): fires.append(e['id'])
   prev[key]=e.get('value',False)
  return fires[:1]
 if policy in ('LAST_MESSAGE','MESSAGE_COUNT'): return [e['id'] for e in truth]
 fires=[e['id'] for e in truth]
 fires.extend(e['id'] for e in events if e.get('kind')=='replay')
 return fires
if len(rows)!=36: errors.append(f'row_count={len(rows)}')
if [r.get('run_id') for r in rows]!=list(range(1,37)): errors.append('run_id_order')
seen=set()
for r in rows:
 key=(r.get('case'),r.get('policy'))
 if key in seen: errors.append(f'duplicate:{key}')
 seen.add(key)
 if r.get('case') not in expected_cases or r.get('policy') not in policies: errors.append(f'unknown:{key}'); continue
 if (r.get('allocation_id'),r.get('source_commit'),r.get('image_digest'))!=(allocation,source_commit,image_digest): errors.append(f'provenance:{key}')
 if r.get('redraw_settle_ms')!=50: errors.append(f'redraw_settle:{key}')
 exp=expected_cases[r['case']]
 if r.get('expected_task_effect')!=exp: errors.append(f'expected_effect:{key}')
 emissions=independent(r['policy'],r['events'])
 if r.get('emissions')!=emissions: errors.append(f'emissions:{key}:{r.get("emissions")}!={emissions}')
 if r.get('initial_title')!='resident-fixture:0': errors.append(f'initial_title:{key}')
 observed=r.get('effect_count_observed')
 if r.get('final_title')!=f'resident-fixture:{observed}': errors.append(f'final_title:{key}')
 if r.get('gtk_exit')!=0: errors.append(f'gtk_exit:{key}:{r.get("gtk_exit")}')
 if not r.get('release_verified_all') or any(not a.get('release_verified') for a in r.get('actions',[])): errors.append(f'release:{key}')
 if len(r.get('actions',[]))!=len(emissions): errors.append(f'action_count:{key}')
 mode=r.get('effect_mode')
 if mode=='off': cls='TRANSPORT_WITHOUT_EFFECT' if emissions and observed==0 else 'HOLD'
 elif exp==0 and observed==0: cls='SAFE_REFUSAL' if not emissions else 'CONTROL_UNSAFE_WITNESS'
 elif exp==0: cls='CONTROL_UNSAFE_WITNESS'
 elif observed==exp: cls='VERIFIED_TASK_EFFECT'
 else: cls='NO_EFFECT_EXPECTED_POSITIVE'
 if r.get('outcome_class')!=cls: errors.append(f'class:{key}')
 if r.get('task_effect_satisfied') != (cls=='VERIFIED_TASK_EFFECT'): errors.append(f'task_success:{key}')
 for side in ('before','after'):
  p=root/r[f'{side}_file']
  if not p.is_file() or sha(p)!=r[f'{side}_sha256']: errors.append(f'{side}_hash:{key}')
  elif len(p.read_bytes())!=r[f'{side}_bytes']: errors.append(f'{side}_size:{key}')
 b=(root/r['before_file']).read_bytes(); a=(root/r['after_file']).read_bytes()
 if ((observed>0) != (b!=a)): errors.append(f'screenshot_delta:{key}')
 cleanup=json.loads((root/'cleanup.json').read_text()) if (root/'cleanup.json').is_file() else {}
 if cleanup.get('rows_written')!=36 or not cleanup.get('xvfb_waited') or cleanup.get('xvfb_exit') is None or not cleanup.get('gtk_children_all_exit_zero') or not cleanup.get('key_releases_all_verified'): errors.append('cleanup_receipt')
 report={'rows':len(rows),'unique_pairs':len(seen),'cleanup':cleanup,'errors':errors,'decision':'PASS_SYNTHETIC_RESIDENT_GTK_EVIDENCE_COMPLETE' if not errors and len(rows)==36 and len(seen)==36 else 'HOLD_RESIDENT_EVIDENCE_AUDIT'}
print(json.dumps(report,sort_keys=True))
if errors: sys.exit(1)

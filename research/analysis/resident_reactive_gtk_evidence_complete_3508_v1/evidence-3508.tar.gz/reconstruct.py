import gzip, hashlib, json, sys
from pathlib import Path

root = Path(sys.argv[1])
raw = root / "raw.jsonl"
out = root / "out"
out.mkdir(exist_ok=True)
rows = [json.loads(line) for line in raw.read_text().splitlines()]
for row in rows:
    for side in ("before", "after"):
        digest = row[f"{side}_sha256"]
        packed = root / "captures" / f"{digest}.x11raw.gz"
        data = gzip.decompress(packed.read_bytes())
        if hashlib.sha256(data).hexdigest() != digest:
            raise SystemExit(f"capture hash mismatch: {digest}")
        if len(data) != row[f"{side}_bytes"]:
            raise SystemExit(f"capture size mismatch: {digest}")
        (out / row[f"{side}_file"]).write_bytes(data)
(out / "raw.jsonl").write_bytes(raw.read_bytes())
(out / "cleanup.json").write_bytes((root / "cleanup.json").read_bytes())
print(json.dumps({"rows": len(rows), "captures_reconstructed": len(rows) * 2, "unique_capture_hashes": len({r[k+"_sha256"] for r in rows for k in ("before", "after")}), "result": "PASS_RECONSTRUCTION"}, sort_keys=True))

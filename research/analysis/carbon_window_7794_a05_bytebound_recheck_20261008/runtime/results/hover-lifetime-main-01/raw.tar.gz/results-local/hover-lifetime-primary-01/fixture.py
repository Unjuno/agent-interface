import json,sys,time,tkinter as tk
from pathlib import Path
out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
root=tk.Tk();root.title('Hover Save — intended target');root.geometry('400x180+80+90')
count=0
def event(kind,**fields):
 with (out/'events.jsonl').open('a') as f:f.write(json.dumps({'kind':kind,'monotonic_ns':time.monotonic_ns(),**fields})+'\n')
def enter(e):
 button.configure(text='SAVE (hover)',bg='#5bc0eb',activebackground='#5bc0eb');event('hover')
def leave(e):button.configure(text='SAVE',bg='#dddddd');event('leave')
def clicked():
 global count
 count+=1;label.configure(text='SAVED '+str(count));event('save',count=count)
tk.Label(root,text='Hover, review, then Save exactly once').place(x=15,y=5)
button=tk.Button(root,text='SAVE',command=clicked,bg='#dddddd',font=('DejaVu Sans',14));button.place(x=95,y=40,width=210,height=55)
button.bind('<Enter>',enter);button.bind('<Leave>',leave)
label=tk.Label(root,text='UNSAVED',font=('DejaVu Sans',14));label.place(x=95,y=115)
root.update();(out/'ready.json').write_text(json.dumps({'content_window_id':root.winfo_id()}));root.mainloop()

import json,os,subprocess,time
from pathlib import Path
from Xlib import display as xdisplay
root=Path(__file__).resolve().parent;session=root/'session';session.mkdir(exist_ok=False)
processes=[]
def connects(name):
 try:d=xdisplay.Display(name);d.close();return True
 except Exception:return False
def wait(test):
 end=time.monotonic()+8
 while not test():
  if time.monotonic()>end:raise TimeoutError('readiness')
  time.sleep(.01)
display=next(':'+str(n) for n in range(153,190) if not connects(':'+str(n)) and not Path(f'/tmp/.X{n}-lock').exists())
env=dict(os.environ,DISPLAY=display)
try:
 for name,command in [('xvfb',['Xvfb',display,'-screen','0','1280x800x24','-ac','-nolisten','tcp']),('wm',['openbox','--config-file','/etc/xdg/openbox/rc.xml'])]:
  if name=='wm':wait(lambda:connects(display))
  p=subprocess.Popen(command,env=env,stdout=(session/(name+'.stdout')).open('wb'),stderr=(session/(name+'.stderr')).open('wb'));processes.append(p)
 time.sleep(.3)
 p=subprocess.Popen(['/usr/bin/python3',str(root/'fixture.py'),str(session/'fixture')],env=env,stdout=(session/'fixture.stdout').open('wb'),stderr=(session/'fixture.stderr').open('wb'));processes.append(p)
 wait(lambda:(session/'fixture/ready.json').exists())
 ready=json.loads((session/'fixture/ready.json').read_text())
 d=xdisplay.Display(display);target=d.create_resource_object('window',ready['content_window_id']).query_tree().parent.id
 clients=d.screen().root.get_full_property(d.intern_atom('_NET_CLIENT_LIST'),0)
 if clients is None or target not in list(clients.value):raise ValueError('target not managed')
 d.close();(session/'targets.json').write_text(json.dumps({'app':target}))
 (session/'allocation.json').write_text(json.dumps({'source':'659177b7fab93fe00248516beabaa53c2836d8f2','display':display,'target':target,'deadline_ns':time.monotonic_ns()+900_000_000_000}))
 print(json.dumps({'ready':True,'display':display,'target':target}),flush=True)
 end=time.monotonic()+900
 while not (session/'finish.json').exists():
  if time.monotonic()>end:raise TimeoutError('primary deadline')
  time.sleep(.1)
 events=[json.loads(l) for l in (session/'fixture/events.jsonl').read_text().splitlines()] if (session/'fixture/events.jsonl').exists() else []
 (session/'independent-effect.json').write_text(json.dumps({'events':events,'save_count':sum(e.get('kind')=='save' for e in events)},indent=2)+'\n')
finally:
 for p in reversed(processes):
  if p.poll() is None:p.terminate()
  try:p.wait(timeout=3)
  except subprocess.TimeoutExpired:p.kill();p.wait()
 (session/'cleanup.json').write_text(json.dumps([{'pid':p.pid,'returncode':p.returncode} for p in processes]))

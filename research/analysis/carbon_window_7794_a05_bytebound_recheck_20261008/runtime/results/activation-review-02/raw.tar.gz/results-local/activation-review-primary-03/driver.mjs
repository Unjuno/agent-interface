export function deliveredAttempt(reply){
 if(reply?.status!=='returned'||!Number.isSafeInteger(reply.attempt)||reply.attempt<1)throw Error('explicit returned response required before recording review');
 return reply.attempt;
}
import {createInstrumentedRelayClient} from './host-bundle/relay_host.mjs';
export async function open(fs,root,evidenceDirectory,sinks){
 const allocation=JSON.parse(await fs.readFile(root+'/session/allocation.json','utf8'));
 if(allocation.source!=='256614b9a81c7727dab64a76edd37daad5836732')throw Error('source mismatch');
 const linux='/var/tmp/agent-interface-integrated-main/results-local/activation-review-primary-03';
 const host=await createInstrumentedRelayClient({command:'wsl.exe',args:['-d','Ubuntu','-u','taka','--exec','/tmp/agent-interface-mcp-venv/bin/python',linux+'/runtime.pyz','relay','--','--targets',linux+'/session/targets.json','--output-directory',linux+'/session/server','--session-mode','guarded-x11','--display',allocation.display],evidenceDirectory,minimumEvidenceFreeBytes:128*1024*1024,reuseReviewedImages:false});
 return {host,allocation,call:(tool,args)=>host.sendPresented(tool,args,sinks),review:(reply,reason)=>host.review(deliveredAttempt(reply),{task:'focus-recovery',phase:'primary',reason}),ack:(reply,reason)=>host.acknowledgeText(deliveredAttempt(reply),{task:'focus-recovery',phase:'primary',reason})};
}

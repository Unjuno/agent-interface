import assert from 'node:assert/strict';
import {deliveredAttempt} from './driver.mjs';
assert.equal(deliveredAttempt({status:'returned',attempt:7}),7);
for(const value of [7,{},null,{status:'returned',attempt:true},{status:'returned',attempt:0},{status:'unknown',attempt:1}])assert.throws(()=>deliveredAttempt(value));
console.log('PASS explicit reply attempt, malformed/uncertain replies refused before host operation');

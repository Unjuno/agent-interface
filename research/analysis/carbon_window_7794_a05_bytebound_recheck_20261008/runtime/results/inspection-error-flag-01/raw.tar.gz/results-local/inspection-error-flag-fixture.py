import sys,json,time,shutil,subprocess
from pathlib import Path
r=Path(__file__).resolve().parents[1];sys.path[:0]=[str(r),str(r/'research/live_control'),str(r/'research/observation_gating')]
from run_native_six_task_self_use_v1 import PrivateSession
import gui_suite as suite
from openpyxl import load_workbook
out=r/'results-local/inspection-error-flag-primary-01';out.mkdir(exist_ok=False)
save=lambda n,v:(out/n).write_text(json.dumps(v,indent=2)+'\n')
s=PrivateSession()
try:
 goal,output,_=suite.prepare(s,'calc',991358,'')
 target=int(next(line.split()[0] for line in s.windows().splitlines() if output.name in line),16)
 save('targets.json',{'app':target});save('goal.json',{'A1':goal['a'],'A2':goal['b']})
 save('allocation.json',{'display':s.name,'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'seed':991358,'scope':'read-only primary inspection probe; no input or task-performance claim','output':str(output)})
 print(json.dumps({'ready':True,'display':s.name,'goal':{'A1':goal['a'],'A2':goal['b']}}),flush=True)
 deadline=time.monotonic()+900
 while not (out/'finish.json').exists():
  if time.monotonic()>deadline:raise TimeoutError('primary allocation expired')
  time.sleep(.1)

finally:
 s.close();save('cleanup.json',[{'pid':p.pid,'returncode':p.poll()} for p in s.procs])

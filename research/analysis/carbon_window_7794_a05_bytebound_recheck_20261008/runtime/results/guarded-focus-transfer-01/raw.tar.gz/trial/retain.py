import hashlib,json,shutil,tarfile
from pathlib import Path
root=Path(__file__).resolve().parent;repo=root.parents[1]
out=repo/'runtime/results/guarded-focus-transfer-01';out.mkdir()
files={p.relative_to(root).as_posix():{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(root.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
with tarfile.open(out/'raw.tar.gz','w:gz') as tar:
 for name in files:tar.add(root/name,arcname='trial/'+name,recursive=False)
with tarfile.open(out/'raw.tar.gz') as tar:
 for name,record in files.items():
  data=tar.extractfile('trial/'+name).read()
  if hashlib.sha256(data).hexdigest()!=record['sha256']:raise ValueError('archive hash')
(out/'raw-manifest.json').write_text(json.dumps(files,indent=2)+'\n')
(out/'result.json').write_text(json.dumps({'base':'64ba776be9ebed5a8902cfa89331b90230b11e34','kind':'exploratory live GUI regression; not frozen matched performance','cases':['baseline','baseline-02','baseline-03','baseline-04','baseline-05','corrected-01','stable-control-01'],'archive_sha256':hashlib.sha256((out/'raw.tar.gz').read_bytes()).hexdigest(),'files':len(files)},indent=2)+'\n')
print(json.dumps({'files':len(files),'path':str(out)}))

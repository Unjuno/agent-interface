import hashlib,json,os,subprocess,sys,time
from pathlib import Path
repo=Path('/var/tmp/agent-interface-integrated-main');sys.path.insert(0,str(repo))
from runtime.guarded_x11_v1.bridge import NativeHandleBridge
from Xlib import display as xdisplay
root=repo/'results-local/focus-transfer-01';out=root/sys.argv[1];out.mkdir()
display=None
for number in range(153,190):
 if not Path(f'/tmp/.X11-unix/X{number}').exists() and not Path(f'/tmp/.X{number}-lock').exists():display=f':{number}';break
if display is None:raise RuntimeError('no private display')
env=dict(os.environ,DISPLAY=display)
processes=[];bridge=None
def wait(test):
 end=time.monotonic()+5
 while not test():
  if time.monotonic()>end:raise TimeoutError('fixture readiness')
  time.sleep(.01)
def connected():
 try:
  d=xdisplay.Display(display);d.close();return True
 except Exception:return False
try:
 xf=subprocess.Popen(['Xvfb',display,'-screen','0','1280x800x24','-ac','-nolisten','tcp'],env=env,stdout=(out/'xvfb.stdout').open('wb'),stderr=(out/'xvfb.stderr').open('wb'));processes.append(xf)
 wait(connected)
 child=subprocess.Popen([sys.executable,str(root/'fixture.py'),str(out/'fixture')],env=env,stdout=(out/'fixture.stdout').open('wb'),stderr=(out/'fixture.stderr').open('wb'));processes.append(child)
 wait(lambda:(out/'fixture/ready.json').exists())
 target=json.loads((out/'fixture/ready.json').read_text())['window_id']
 connection=xdisplay.Display(display)
 parent=connection.create_resource_object('window',target).query_tree().parent.id
 if parent!=connection.screen().root.id:target=parent
 (out/'native-target.json').write_text(json.dumps({'target':target,'reported_parent':parent}))
 connection.close()
 bridge=NativeHandleBridge(display,{'app':target},'app',out/'bridge')
 observation=bridge.observe()
 bridge.mint('entry',observation['sequence'],[200,145],region_size=(24,38))
 result=bridge.click('entry',[12,19],tail=[{'op':'wait_update','timeout_ms':250},{'op':'text','text':'z'}])
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 time.sleep(.1)
 events=[json.loads(line) for line in (out/'fixture/events.jsonl').read_text().splitlines()] if (out/'fixture/events.jsonl').exists() else []
 (out/'independent-effect.json').write_text(json.dumps({'events':events,'A_text':''.join(e.get('char','') for e in events if e.get('role')=='A'),'B_text':''.join(e.get('char','') for e in events if e.get('role')=='B')},indent=2)+'\n')
 print(json.dumps({'result_status':result['status'],'events':events}))
finally:
 if bridge:
  (out/'release.json').write_text(json.dumps(bridge.backend.release_all()));bridge.close()
 for p in reversed(processes):
  p.terminate()
  try:p.wait(timeout=3)
  except subprocess.TimeoutExpired:p.kill();p.wait()
 (out/'cleanup.json').write_text(json.dumps([{'pid':p.pid,'returncode':p.returncode} for p in processes]))

"""Build the portable unified Agent Interface runtime zipapp deterministically."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import zipfile
from pathlib import Path

FIXED_TIME = (1980, 1, 1, 0, 0, 0)
SCHEMA = "agent-interface/portable-runtime-build-v1"

SOURCE_FILES = (
    "runtime/host_v1/__init__.py",
    "runtime/host_v1/file_publication.py",
    "runtime/guarded_x11_v1/__init__.py",
    "runtime/guarded_x11_v1/frames.py",
    "runtime/guarded_x11_v1/handles_base.py",
    "runtime/guarded_x11_v1/handles_texture.py",
    "runtime/guarded_x11_v1/handles.py",
    "runtime/guarded_x11_v1/bridge.py",
    "runtime/guarded_x11_v1/history.py",
    "runtime/guarded_x11_v1/form.py",
    "runtime/core_v1/__init__.py",
    "runtime/core_v1/backend.py",
    "runtime/core_v1/contract.py",
    "runtime/core_v1/sequence.py",
    "runtime/core_v1/doctor.py",
    "runtime/core_v1/platform_probe.py",
    "runtime/selector_v1/__init__.py",
    "runtime/selector_v1/selector.py",
    "runtime/cli_v1/__init__.py",
    "runtime/cli_v1/__main__.py",
    "runtime/cli_v1/validate_program.py",
    "runtime/cli_v1/api.py",
    "runtime/cli_v1/attempt.py",
    "runtime/cli_v1/mcp_server.py",
    "runtime/cli_v1/mcp_relay.py",
    "runtime/cli_v1/mcp_session.py",
    "runtime/cli_v1/mcp_guarded.py",
    "runtime/cli_v1/guarded_presentation.py",
    "runtime/cli_v1/public_presentation.py",
    "runtime/cli_v1/public_summary.py",
    "runtime/cli_v1/x11_target_review.py",
    "runtime/cli_v1/receipt.py",
    "runtime/cli_v1/review.py",
    "runtime/cli_v1/receipt_references.py",
    "runtime/cli_v1/receipt_image.py",
    "runtime/cli_v1/observe.py",
    "runtime/cli_v1/golden_v3.py",
    "runtime/motor_state_v1/__init__.py",
    "runtime/motor_state_v1/adapter.py",
    "runtime/backends/x11_v1/__init__.py",
    "runtime/backends/x11_v1/backend.py",
    "runtime/backends/x11_v1/capture_artifacts.py",
    "runtime/backends/x11_v1/session.py",
    "runtime/backends/win32_v1/__init__.py",
    "runtime/backends/win32_v1/backend.py",
    "runtime/backends/win32_v1/session.py",
    "runtime/backends/quartz_v1/__init__.py",
    "runtime/backends/quartz_v1/backend.py",
    "runtime/backends/quartz_v1/session.py",
)

GENERATED = {
    "runtime/__init__.py": b"\n",
    "runtime/backends/__init__.py": b"\n",
    "__main__.py": b'''import sys
if len(sys.argv) > 1 and sys.argv[1] in ("mcp", "relay"):
    mode = sys.argv.pop(1)
    try:
        if mode == "relay":
            from runtime.cli_v1.mcp_relay import main
        else:
            from runtime.cli_v1.mcp_server import main
    except ModuleNotFoundError as error:
        if error.name != "mcp" and not error.name.startswith("mcp."):
            raise
        print("MCP mode requires optional dependency mcp==1.30.0 in this Python environment.", file=sys.stderr)
        raise SystemExit(2)
else:
    from runtime.cli_v1.__main__ import main
raise SystemExit(main())
''',
}

SUPPORT = {
    "schema": "agent-interface/portable-runtime-support-v1",
    "python_minimum": "3.12",
    "promoted_backends": {
        "linux_x11": {"backend_id": "x11-v1", "extra_dependency": "python-xlib", "target_kind": "x11_window_id"},
        "windows": {"backend_id": "win32-v1", "extra_dependency": None, "target_kind": "hwnd"},
        "macos": {"backend_id": "quartz-v1", "extra_dependency": None, "target_kind": "pid", "permissions": ["Accessibility", "Screen Recording"]},
    },
    "wayland": {"promoted": False, "reason": "WAYLAND_BACKEND_NOT_PROMOTED"},
    "automatic_target_discovery": False,
    "automatic_permission_escalation": False,
    "optional_dependencies": {"x11_png_artifacts": ["Pillow"], "guarded_x11_python_api": ["Pillow", "python-xlib"], "mcp_stdio": ["mcp==1.30.0"]},
}


def _source_revision(root: Path) -> str | None:
    if not (root / ".git").exists():
        return None
    try:
        value = subprocess.check_output(
            ["git", "-C", str(root), "rev-parse", "--verify", "HEAD^{commit}"],
            stderr=subprocess.STDOUT).decode('ascii').strip()
        if not re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}', value):
            raise ValueError('full commit object ID required')
        return value
    except (OSError, subprocess.CalledProcessError, ValueError) as error:
        raise RuntimeError('cannot pin committed build source') from error


def _source_bytes(root: Path, rel: str, revision: str | None) -> bytes:
    if revision is not None:
        try:
            return subprocess.check_output(["git", "-C", str(root), "show", f"{revision}:{rel}"], stderr=subprocess.STDOUT)
        except (OSError, subprocess.CalledProcessError) as error:
            detail = getattr(error, "output", b"")
            if isinstance(detail, bytes):
                detail = detail.decode("utf-8", "replace")
            raise RuntimeError(f"cannot read committed source {rel}: {detail}") from error
    return (root / rel).read_bytes()


def _info(name: str) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name, FIXED_TIME)
    info.compress_type = zipfile.ZIP_STORED
    info.create_system = 3
    info.external_attr = 0o100644 << 16
    info.flag_bits = 0
    return info


HOST_SOURCE_FILES = ("runtime/host_v1/relay_client.mjs", "runtime/host_v1/relay_host.mjs", "runtime/host_v1/primary_caller.mjs", "runtime/host_v1/README.md")


def build(root: Path, out: Path, manifest_out: Path, sums_out: Path, *, host_directory: Path | None = None) -> dict:
    revision = _source_revision(root)
    entries: dict[str, bytes] = dict(GENERATED)
    source_manifest = []
    for rel in SOURCE_FILES:
        data = _source_bytes(root, rel, revision)
        entries[rel] = data
        source_manifest.append({"path": rel, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    support_bytes = (json.dumps(SUPPORT, indent=2, sort_keys=True) + "\n").encode()
    entries["SUPPORT.json"] = support_bytes
    build_meta = {
        "schema": SCHEMA,
        "source_revision": revision,
        "source_files": source_manifest,
        "generated_entries": sorted(GENERATED),
        "support_sha256": hashlib.sha256(support_bytes).hexdigest(),
        "research_tree_included": False,
        "tests_included": False,
        "fixtures_included": False,
    }
    entries["BUILD.json"] = (json.dumps(build_meta, sort_keys=True, separators=(",", ":")) + "\n").encode()

    # Read both distributions from the single source revision pinned above.
    # A conflicting host destination must refuse before changing runtime outputs.
    host_manifest = None
    if host_directory is not None:
        host_entries = {Path(rel).name: _source_bytes(root, rel, revision) for rel in HOST_SOURCE_FILES}
        host_manifest = {
            "schema": "agent-interface/portable-host-manifest-v1",
            "source_revision": revision,
            "node_minimum": "22",
            "files": [{"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
                      for name, data in sorted(host_entries.items())],
            "research_tree_included": False,
            "tests_included": False,
        }
        host_directory.mkdir(parents=True, exist_ok=False)
        for name, data in host_entries.items():
            with (host_directory / name).open('xb') as stream:
                stream.write(data)
        metadata = (json.dumps(host_manifest, indent=2, sort_keys=True) + "\n").encode('utf-8')
        with (host_directory / 'HOST_MANIFEST.json').open('xb') as stream:
            stream.write(metadata)
        checksums = ''.join(f"{row['sha256']}  {row['path']}\n" for row in host_manifest['files'])
        checksums += f"{hashlib.sha256(metadata).hexdigest()}  HOST_MANIFEST.json\n"
        with (host_directory / 'SHA256SUMS').open('x', encoding='utf-8', newline='\n') as stream:
            stream.write(checksums)

    out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_STORED, strict_timestamps=True) as archive:
        for name in sorted(entries):
            archive.writestr(_info(name), entries[name])

    raw = out.read_bytes()
    result = {
        "schema": "agent-interface/portable-runtime-manifest-v1",
        "source_revision": revision,
        "artifact": out.name,
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "entries": sorted(entries),
        "source_files": source_manifest,
        "support": SUPPORT,
    }
    if host_manifest is not None:
        result['host_bundle'] = {'directory': host_directory.name, 'manifest': host_manifest}
    manifest_out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    sums_out.write_text(f"{result['sha256']}  {out.name}\n", encoding="utf-8")
    return result


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--root", type=Path, default=Path("."))
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--manifest", type=Path, required=True)
    p.add_argument("--sums", type=Path, required=True)
    p.add_argument("--host-directory", type=Path, help="export committed Node host files into a fresh directory")
    a = p.parse_args()
    print(json.dumps(build(a.root.resolve(), a.out, a.manifest, a.sums, host_directory=a.host_directory), sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""Private six-task fixture allocation for primary use of public guarded MCP.

Only setup navigation uses direct dispatch. All task actions belong to the
separately retained primary-host MCP connection. No model or action selection.
"""
import json,shutil,sys,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'research/live_control'))
from run_native_six_task_self_use_v1 import PrivateSession
import integrated_efficiency_runtime_v1 as integrated
from runtime.cli_v1.api import dispatch
from runtime.core_v1.contract import SCHEMA_PROGRAM
out=ROOT/'results-local/guarded-deadline-primary-01';out.mkdir(exist_ok=False)
session=fixture=None
save=lambda name,value:(out/name).write_text(json.dumps(value,indent=2)+'\n')
try:
    session=PrivateSession()
    goal,history,_=integrated.prepare(session,'chromium',991339,
        '/home/taka/.cache/ms-playwright/chromium-1208/chrome-linux64/chrome')
    fixture=integrated._ACTIVE[str(history)]
    fixture.history=out/'independent-submissions.jsonl'
    window=next(line.split()[0] for line in session.windows().splitlines() if 'about:blank' in line)
    targets={'browser':int(window,16)}
    program={'schema':SCHEMA_PROGRAM,'program_id':'fixture-initial-navigation',
        'source':{'observation_seq':0,'binding_revision':0},
        'authority':{'lease_id':'fixture-setup','expires_at_ns':time.monotonic_ns()+5000000000},
        'terminal':{'release_all_required':True},'ops':[{'op':'focus','target':'browser'},
        {'op':'key_chord','keys':['CTRL','l']},{'op':'text','text':goal['tasks'][0]['url']},
        {'op':'key_chord','keys':['ENTER']},{'op':'release_all'}]}
    save('setup-program.json',program)
    setup=dispatch(program,targets,current_observation_seq=0,current_binding_revision=0,display_name=session.name)
    save('setup-result.json',setup)
    if setup.get('result',{}).get('status')!='completed':raise RuntimeError('setup navigation failed; no replay')
    session.wait_window('AI INTEGRATED task-1 READY',10)
    save('goal.json',goal);save('targets.json',targets)
    save('presentation-plan.json',{'scope':'task1 only; expected partial input expiry','actions':'enter exact token, wait6000ms, forbidden suffix X; observe prefix then choose separate Save','success':'expiry prevents suffix, verified release, post-release image, independent task1 exact-once save; six-task oracle stays false'})
    save('allocation.json',{'display':session.name,'seed':991339,'targets':targets,
        'scope':'primary public guarded MCP usability; not matched efficiency comparison',
        'timeout_seconds':900})
    print(json.dumps({'ready':True,'display':session.name,'targets':targets,'goal_file':str(out/'goal.json')}),flush=True)
    deadline=time.monotonic()+900
    while not (out/'finish.json').exists():
        if time.monotonic()>deadline:raise TimeoutError('fixture allocation expired')
        time.sleep(.1)
    save('evaluation.json',fixture.evaluate())
    print(json.dumps({'evaluation':fixture.evaluate()}),flush=True)
except Exception:
    (out/'error.txt').write_text(traceback.format_exc());raise
finally:
    if fixture:
        save('evaluation-at-close.json',fixture.evaluate())
        if fixture.history.exists():shutil.copyfile(fixture.history,out/'submission-history.jsonl')
        fixture.close()
    if session:
        session.close();save('cleanup.json',[{'pid':p.pid,'returncode':p.poll()} for p in session.procs])

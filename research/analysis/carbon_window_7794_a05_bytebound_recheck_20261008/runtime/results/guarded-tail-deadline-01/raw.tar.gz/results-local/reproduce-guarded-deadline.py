import sys,json,subprocess
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock,patch
r=Path('/var/tmp/agent-interface-integrated-main');sys.path.insert(0,str(r))
from runtime.guarded_x11_v1.bridge import _GuardedBackend
out=r/'results-local/guarded-deadline-before-01';out.mkdir(exist_ok=False)
clock=[1000000]
b=object.__new__(_GuardedBackend);b.emissions=0
b.owner=SimpleNamespace(active=('context',[0,0]),deadline=11000000)
b.preflight=Mock();b.text=Mock();b.release_all=Mock(return_value={'verified':True,'keys_down':[],'buttons_down':[]})
def sleep(seconds): clock[0]+=round(seconds*1000000000)
with patch('time.monotonic_ns',side_effect=lambda:clock[0]),patch('time.sleep',side_effect=sleep):
 result=b.execute({'ops':[{'op':'wait_update','timeout_ms':25},{'op':'text','text':'must-not-run'},{'op':'release_all'}]})
row={'scope':'deterministic fake clock/backend; no real input','source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'deadline_ns':b.owner.deadline,'ended_ns':clock[0],'late_text_called':b.text.called,'execution':result}
(out/'before.json').write_text(json.dumps(row,indent=2)+'\n')
for name in ('runtime/guarded_x11_v1/bridge.py','runtime/backends/x11_v1/backend.py'):
 (out/Path(name).name).write_bytes((r/name).read_bytes())
print(json.dumps(row))

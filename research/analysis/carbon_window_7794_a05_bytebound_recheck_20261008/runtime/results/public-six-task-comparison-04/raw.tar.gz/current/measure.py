import pathlib,json,hashlib,subprocess
r=pathlib.Path('/var/tmp/agent-interface-integrated-main');p=r/'results-local/public-six-task-comparison-04'
def save(n,v):(p/n).write_text(json.dumps(v,indent=2)+'\n')
rows=[];summary={}
for route in ['direct','guarded']:
 d=p/route; replies={int(q.stem.split('-')[1]):json.loads(q.read_text()) for q in (d/'host').glob('reply-*.json')};requests={int(q.stem.split('-')[1]):json.loads(q.read_text()) for q in (d/'host').glob('request-*.json')}; events=[json.loads(l) for l in (d/'host/host-events.jsonl').read_text().splitlines()];payloads={i:json.loads(rep['result']['content'][0]['text']) for i,rep in replies.items()}; releases=[]
 for i,rep in replies.items():
  m=payloads[i]; ex=m.get('receipt',{}).get('source',{}).get('raw_report',{}).get('result',{}).get('execution',{}) if route=='direct' else m.get('result',{}).get('execution',{})
  if rep['tool'] in ['interface_dispatch','interface_guarded_input']:releases+=ex.get('releases',[])
 valid=all(x['verified'] and not x['keys_down'] and not x['buttons_down'] for x in releases)
 assert len(releases)==18 and valid
 history=[json.loads(l) for l in (d/'submission-history.jsonl').read_text().splitlines()];ev=json.loads((d/'evaluation-at-close.json').read_text());assert ev['success'] and len(history)==6 and not ev['unexpected'] and not ev['duplicates']
 presented={e['attempt'] for e in events if e['kind']=='presentation_callbacks_completed'}
 for task in range(1,7):
  ent=(3+3*(task-1)) if route=='direct' else [5,8,11,16,19,22][task-1];sav=ent+1;start=14 if route=='guarded' and task==4 else ent
  selected=list(range(start,sav+1)); rep=replies[start]; entry=next(e for e in events if e['kind']=='send_requested' and e['attempt']==start);feedback=next(e for e in events if e['kind']=='presentation_callbacks_completed' and e['attempt']==start);review=next(e for e in events if e['kind']=='review_recorded' and e.get('task')==f'task-{task}' and e.get('phase')=='result'); presave=next(e for e in events if e['kind']=='review_recorded' and e.get('task')==f'task-{task}' and e.get('phase')=='pre-save')
  rec=history[task-1];assert rec['exact'] and rec['submitted_values']==[f't992004-{task}'] and rec['task_id']==f'task-{task}'
  rows.append({'route':route,'task':task,'entry_attempt':start,'successful_entry_attempt':ent,'save_attempt':sav,'exact_once':True,'sdk_selected_calls_ms':sum((replies[i]['sdk_return_ns']-replies[i]['sdk_entry_ns'])/1e6 for i in selected),'first_reply_presentation_ms':feedback['host_monotonic_ms']-entry['host_monotonic_ms'],'input_to_presave_annotation_ms':presave['host_monotonic_ms']-entry['host_monotonic_ms'],'input_to_result_annotation_ms':review['host_monotonic_ms']-entry['host_monotonic_ms'],'sdk_input_to_independent_submission_ms':(rec['received_ns']-rep['sdk_entry_ns'])/1e6,'visual_completion_cue_in_save_image':not(route=='direct' and task==6)})
 close=payloads[max(replies)];assert close['status']=='closed' and close['release']['verified'];lookup=payloads[max(replies)-1];assert lookup['operation_invoked'] is False
 captures=list((d/'server').rglob('observation-*.json')) if route=='guarded' else list((d/'server').rglob('*.png'))
 summary[route]={'public_calls':len(replies),'returned_image_blocks':sum(sum(c['type']=='image' for c in x['result']['content']) for x in replies.values()),'presented_image_blocks':sum(sum(c['type']=='image' for c in replies[i]['result']['content']) for i in presented),'native_captures':len(captures),'verified_input_releases':len(releases),'relay_exit':json.loads((d/'host/exit.json').read_text()),'child_cleanup_codes':[x['returncode'] for x in json.loads((d/'cleanup.json').read_text())]}
 assert summary[route]['relay_exit']['code']==0
assert payloads[14]['result']['input_dispatched'] is False and payloads[14]['result']['guard_checks'][0]['status']=='MISSING'
save('metrics.json',{'status':'PASS_PUBLIC_SIX_TASK_CORRECTNESS_SCOPED','integration_acceptance':'HOLD_INTEGRATION_INCOMPLETE','routes':summary,'tasks':rows,'limits':['One serial pair with growing conversation context; no causal ranking.','Host callback completion and review annotations are not exact perception/inference boundaries.','Independent scoring is cooperative fixture authority, not generic desktop completion.','Direct capture precedes final release; guarded feedback follows release.','Direct lookup omitted include_image:false: one historical image returned but not presented; guarded lookup explicit false.','Direct task6 Save image still shows submitted form; scorer succeeds.','No human-speed, isolated image-token or provider dollar-cost measurement.']})
save('terminal.json',{'direct':{'session_id':92169,'exit_code':0},'guarded':{'session_id':60409,'exit_code':0}})
source=p/'source';source.mkdir(exist_ok=True)
for n in ['research/live_control/run_native_six_task_self_use_v1.py','research/live_control/integrated_efficiency_runtime_v1.py','research/live_control/integrated_efficiency_fixture_v1.py','runtime/host_v1/relay_client.mjs','runtime/host_v1/relay_host.mjs']:
 q=source/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(subprocess.check_output(['git','show',json.loads((p/'PLAN.json').read_text())['source_revision']+':'+n],cwd=r))
print(json.dumps({'routes':summary,'tasks':rows},indent=2))

import pathlib,subprocess,json
p=pathlib.Path('/var/tmp/agent-interface-integrated-main/results-local/public-six-task-comparison-04')
rows=[]
for i in range(3):
 r=subprocess.run(['python3','-I',str(p/'runtime.pyz'),'validate','--program',str(p/f'preflight-{i}.json')],capture_output=True,text=True)
 (p/f'preflight-{i}-result.json').write_text(r.stdout)
 rows.append({'pattern':i,'exit':r.returncode,'result':json.loads(r.stdout)})
print(json.dumps(rows))
assert all(x['exit']==0 and x['result']['static_valid'] for x in rows)

import tkinter as tk,json
from pathlib import Path
out=Path(__file__).parent
root=tk.Tk();root.title('Public guarded integration');root.geometry('600x360+120+120')
tk.Label(root,text='Enter the exact value and click Save',font=('Sans',18)).pack(pady=30)
entry=tk.Entry(root,font=('Sans',20),width=26);entry.pack(pady=15)
label=tk.Label(root,text='No value saved',font=('Sans',14))
def save():
 value=entry.get();p=out/'payload.json'
 count=json.loads(p.read_text())['saves']+1 if p.exists() else 1
 p.write_text(json.dumps({'value':value,'saves':count}))
 label.config(text='Saved: '+value)
tk.Button(root,text='Save',font=('Sans',18),command=save).pack(pady=18)
label.pack();root.mainloop()

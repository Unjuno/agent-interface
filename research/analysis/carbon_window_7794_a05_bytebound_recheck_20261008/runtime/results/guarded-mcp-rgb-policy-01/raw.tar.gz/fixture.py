import json,sys,time,subprocess,traceback
from pathlib import Path
r=Path('/var/tmp/agent-interface-integrated-main')
sys.path[:0]=[str(r),str(r/'research/live_control'),str(r/'research/observation_gating')]
from run_native_six_task_self_use_v1 import PrivateSession
out=r/'results-local/guarded-mcp-rgb-policy-01'/sys.argv[1];out.mkdir()
def save(n,v):(out/n).write_text(json.dumps(v,indent=2)+'\n')
s=None
try:
 s=PrivateSession();save('readiness.json',s.window_manager_readiness)
 app=out/'app.py'
 app.write_text("""import tkinter as tk,json
from pathlib import Path
out=Path(__file__).parent
root=tk.Tk();root.title('Public guarded integration');root.geometry('600x360+120+120')
tk.Label(root,text='Enter the exact value and click Save',font=('Sans',18)).pack(pady=30)
entry=tk.Entry(root,font=('Sans',20),width=26);entry.pack(pady=15)
label=tk.Label(root,text='No value saved',font=('Sans',14))
def save():
 value=entry.get();p=out/'payload.json'
 count=json.loads(p.read_text())['saves']+1 if p.exists() else 1
 p.write_text(json.dumps({'value':value,'saves':count}))
 label.config(text='Saved: '+value)
tk.Button(root,text='Save',font=('Sans',18),command=save).pack(pady=18)
label.pack();root.mainloop()
""")
 p=s._popen(['/usr/bin/python3',str(app)],cwd=r)
 end=time.monotonic()+30;wid=None
 while time.monotonic()<end:
  for line in s.windows().splitlines():
   if 'Public guarded integration' in line:wid=int(line.split()[0],16);break
  if wid:break
  time.sleep(.1)
 if not wid:raise RuntimeError('target missing')
 save('targets.json',{'app':wid});save('allocation.json',{'display':s.name,'window':wid,'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'task':'Enter rgb_public_01 and save exactly once; independent payload.json must match.'})
 print(json.dumps({'ready':True,'display':s.name,'window':wid}),flush=True)
 end=time.monotonic()+900
 while not (out/'finish.json').exists():
  if time.monotonic()>end:raise TimeoutError('allocation expired')
  time.sleep(.1)
 save('finished.json',{'payload':json.loads((out/'payload.json').read_text()) if (out/'payload.json').exists() else None})
except BaseException as e:save('failure.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
finally:
 if s is not None:s.close();save('cleanup.json',[{'pid':p.pid,'returncode':p.poll()} for p in s.procs])

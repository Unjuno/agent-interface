import sys,json,hashlib,io,resource,subprocess,copy
from pathlib import Path
r=Path('/var/tmp/agent-interface-integrated-main');sys.path.insert(0,str(r))
from PIL import Image
from runtime.guarded_x11_v1.history import ObservationHistory
out=r/'results-local/decoded-history-memory-01'
source=r/'results-local/guarded-navigation-delay250-primary-01/server/d2dc68392cbe497082a0495ccf70768d/images/54260c4d19494b0c87f381b97d9277a8.png'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 rows=[]
 for pair in range(3):
  for mode in (('dict','bounded') if pair%2==0 else ('bounded','dict')):
   p=subprocess.run([sys.executable,__file__,mode],capture_output=True,text=True)
   (out/f'{pair}-{mode}.stdout.json').write_text(p.stdout)
   (out/f'{pair}-{mode}.stderr.txt').write_text(p.stderr)
   if p.returncode: raise RuntimeError(p.stderr)
   rows.append(dict(pair=pair,**json.loads(p.stdout)))
 (out/'summary.json').write_text(json.dumps({'scope':'isolated retained-image storage; no GUI timing or model tokens','rows':rows},indent=2)+'\n')
 print(json.dumps(rows))
else:
 mode=sys.argv[1];history={} if mode=='dict' else ObservationHistory()
 data=source.read_bytes();digest=hashlib.sha256(data).hexdigest();samples=[]
 for n in range(1,129):
  with Image.open(io.BytesIO(data)) as opened: image=opened.convert('RGB')
  observation={'sequence':n,'native':{'width':image.width,'height':image.height,'sha256':'recorded-source',
    'artifact':{'path':str(source),'sha256':digest,'source_raw_sha256':'recorded-source'}}}
  history[n]=observation,image
  if n in (1,16,32,64,128):
   rss=next(line for line in Path('/proc/self/status').read_text().splitlines() if line.startswith('VmRSS:'))
   samples.append({'frames':n,'rss_kib':int(rss.split()[1])})
 expected=hashlib.sha256(image.tobytes()).hexdigest()
 parity=[hashlib.sha256(history[n][1].tobytes()).hexdigest()==expected for n in (1,64,128)]
 print(json.dumps({'mode':mode,'source_sha256':digest,'dimensions':image.size,'samples':samples,'old_pixel_parity':parity,'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()}))

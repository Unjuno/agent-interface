import sys,json,time,shutil,subprocess,traceback
from pathlib import Path
import xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1];sys.path[:0]=[str(r),str(r/'research/live_control'),str(r/'research/observation_gating')]
from run_native_six_task_self_use_v1 import PrivateSession
import gui_suite as suite
out=r/'results-local/inkscape-current-primary-01';out.mkdir(exist_ok=False)
save=lambda n,v:(out/n).write_text(json.dumps(v,indent=2)+'\n')
s=None
try:
 s=PrivateSession()
 goal,output,_=suite.prepare(s,'inkscape',991359,'')
 target=int(next(line.split()[0] for line in s.windows().splitlines() if output.name in line),16)
 save('targets.json',{'app':target});save('goal.json',{'drag_right_screen_px':goal['dx'],'task':'Move red rectangle right, preserve y/size/fill/count, save SVG.'})
 save('allocation.json',{'display':s.name,'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'seed':991359,'output':str(output)})
 print(json.dumps({'ready':True,'display':s.name,'drag_right_screen_px':goal['dx']}),flush=True)
 deadline=time.monotonic()+900
 while not (out/'finish.json').exists():
  if time.monotonic()>deadline:raise TimeoutError('primary allocation expired')
  time.sleep(.1)
 shutil.copy2(output,out/'saved.svg')
 root=ET.parse(out/'saved.svg').getroot();rects=root.findall('{http://www.w3.org/2000/svg}rect')
 actual=[dict(x.attrib) for x in rects];ok=False
 if len(rects)==1:
  a=actual[0];fill=a.get('fill')
  if fill is None:
   style=dict(item.split(':',1) for item in a.get('style','').split(';') if ':' in item);fill=style.get('fill')
  ok=(a.get('transform') is None and float(a['x'])>50.5 and abs(float(a['y'])-50)<.1 and abs(float(a['width'])-40)<.1 and abs(float(a['height'])-30)<.1 and fill in ('red','#ff0000'))
 save('evaluation.json',{'success':ok,'rectangles':actual,'scope':'post-control SVG structural/value oracle'})
except BaseException as e:
 save('failure.json',{'error':str(e),'traceback':traceback.format_exc()});raise
finally:
 if s is not None:
  s.close();save('cleanup.json',[{'pid':p.pid,'returncode':p.poll()} for p in s.procs])

import hashlib,json
from pathlib import Path
repo=Path(__file__).resolve().parent.parent
text=(repo/'results-local/prepare_production_spine.py').read_text().replace('production-spine-01','production-spine-02').replace('production-spine01','production-spine02').replace('1001061','1001062')
exec(compile(text,str(repo/'results-local/prepare_production_spine.py'),'exec'))
root=repo/'results-local/production-spine-02';caller=root/'caller.mjs'
text=caller.read_text().replace('review:policy.review,acknowledgeText:policy.acknowledgeText',"review:(reply,reason)=>policy.review(reply.attempt,{task:'all-six',phase:'primary',reason}),acknowledgeText:(reply,reason)=>policy.acknowledgeText(reply.attempt,{task:'all-six',phase:'primary',reason})")
text=text.replace("const sampled=await call('interface_clock',{}),clock=meta(sampled);","const sampled=await call('interface_clock',{}),clock=meta(sampled);\n  await policy.acknowledgeText(sampled.attempt,{task:'all-six',phase:'clock',reason:'Same-host clock sample for explicitly chosen guarded input; no input authority issued.'});")
text=text.replace("const c=meta(await call('interface_clock',{}));","const sample=await call('interface_clock',{}),c=meta(sample);await policy.acknowledgeText(sample.attempt,{task:'all-six',phase:'clock',reason:'Same-host clock sample for explicitly chosen direct program; no input authority issued.'});")
caller.write_text(text)
plan=json.loads((root/'PLAN.json').read_text());plan['construction_delta']='Previous allocation stopped before input on wrong review attribution arguments. Pre-authored adapters now extract explicit integer reply.attempt and construct nonempty task/phase/reason. Clock sample acknowledgement added before input; no additional MCP calls, no replay and no altered controls.'
plan['hashes']={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in plan['hashes']};(root/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')

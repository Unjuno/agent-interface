import hashlib,json,shutil,subprocess,sys,tarfile
from pathlib import Path

repo=Path(__file__).resolve().parent.parent
stage=repo/'results-local/production-spine-retained-01'
stage.mkdir(exist_ok=False)
out=repo/'runtime/results/production-spine-main-01'
out.mkdir(parents=True,exist_ok=False)
for name in ['production-spine-01','production-spine-02']:
 shutil.copytree(repo/'results-local'/name,stage/name,ignore=shutil.ignore_patterns('__pycache__'))
for name in ['prepare_production_spine.py','prepare_production_spine_02.py','retain_production_spine.py']:
 shutil.copyfile(repo/'results-local'/name,stage/name)
source='3a8936cf20df11ec884244e76c791434fbf5d5fe'
(out/'timing_reader.py').write_bytes(subprocess.check_output(['git','show',source+':runtime/integration_checks/host_timing.py'],cwd=repo))
old=Path('/var/tmp/agent-interface-integrated-main/results-local/post-release-spine-13/audit_pair.py')
audit=old.read_text().replace("'adoption':'HOLD'","'adoption':'scoped_correctness_pass_performance_unproven'")
audit=audit.replace("('guarded-local',74,24,29,594)","('guarded-local',77,24,30,594)")
audit=audit.replace("read(session/'primary-terminal.json')['policy']['stopped']","read(session/'finish.json')['primary_state']['stopped']")
audit=audit.replace("  calls=timing['calls']",'''  require(wait_ms==4800,'equal requested fixed wait schedule')
  calls=timing['calls']
  for i in range(1,n+1):
   if i not in images:
    require((host/f'text-acknowledgment-{i}.json').exists(),'text acknowledgement '+str(i))
  if route=='direct-post':
   for i in programs:
    m=metas[i];q=requests[i];args=q['arguments'];raw=read(session/'server'/m['call_id']/'report.json')
    original=(session/'server'/m['call_id']/'report.json').read_bytes()
    require(hashlib.sha256(original).hexdigest()==m['receipt']['source']['sha256'] and len(original)==m['receipt']['source']['bytes'],'full report provenance')
    require(args['inspect_after']=='browser' and args['inspect_after_region']==[0,0,1280,800] and 'inspect_after_wait_ms' not in args,'optional post capture request')
    require(not any(op['op']=='observe' for op in args['program']['ops']),'no inline observe')
    e=raw['result']['execution'];post=raw['post_dispatch_inspection'];cap=post['observation_report']['observation']
    require(e['observations']==[] and cap['capture_started_ns']>=max([e['ended_ns']]+[r['monotonic_ns'] for r in e['releases']]),'post release capture order')
    require(m['image_reference']['capture_phase']=='after_dispatch_release' and m['image_reference']['post_dispatch_observation_id']==post['observation_report']['observation_id'],'post image selected')
    require(m['post_dispatch_inspection']==post and m['presentation']['returned']=='summary','post capture and summary preserved')
  else:
   require(requests[46]['tool']=='interface_clock' and requests[47]['tool']=='interface_guarded_observe' and requests[48]['tool']=='interface_guarded_mint','explicit expiry recovery, no input replay')
   require(requests[48]['arguments']['alias']=='save_off_b_renew4','unique explicit refreshed alias')
   terminal=read(session/'finish.json')
   require([terminal[k] for k in ['extra_observation_due_conversation_expiry','extra_mint_due_conversation_expiry','extra_clock_no_input']]==[1,1,1],'all extra expiry cost retained')
   fallbacks=[json.loads(l) for l in (root/'presentation-fallbacks.jsonl').read_text().splitlines()]
   require(sum(f['extra_disk_previews'] for f in fallbacks)==4 and terminal['extra_disk_previews_total']==4,'fallback cost')
''')
(out/'audit_pair.py').write_text(audit)
(out/'verify.py').write_text('''import hashlib,json,tarfile,tempfile
from pathlib import Path
from audit_pair import audit,require,read
def verify():
 here=Path(__file__).resolve().parent
 manifest=read(here/'raw-manifest.json')
 with tempfile.TemporaryDirectory(prefix='production-spine-audit-') as tmp:
  root=Path(tmp)
  with tarfile.open(here/'raw.tar.gz','r:gz') as archive:
   members=archive.getmembers()
   require(len(members)==len(manifest) and len({m.name for m in members})==len(members),'exact archive members')
   for m in members:
    p=Path(m.name)
    require(m.isfile() and not p.is_absolute() and '..' not in p.parts and m.name in manifest,'safe retained member')
    raw=archive.extractfile(m).read();entry=manifest[m.name]
    require(len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256'],'retained bytes '+m.name)
    dest=root/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
  pair=audit(root/'production-spine-02')
  failed=root/'production-spine-01';session=failed/'guarded-local/session';host=failed/'guarded-local/host'
  plan=read(failed/'PLAN.json')
  for name,sha in plan['hashes'].items():require(hashlib.sha256((failed/name).read_bytes()).hexdigest()==sha,'failed frozen bytes')
  score=read(session/'evaluation-at-close.json');terminal=read(session/'finish.json')
  require(score['success'] is False and score['record_count']==0 and len(score['missing'])==6,'failed original denominator')
  require(terminal['primary_state']['stopped']=='invalid primary review arguments' and terminal['host_exit']['code']==0,'failed original terminal')
  requests=[read(p) for p in host.glob('request-*.json')]
  require(not any(q['tool'] in ['interface_dispatch','interface_guarded_input'] for q in requests),'failed before input')
  pair['prior_failed_allocation']={'seed':plan['seed'],'tasks_successful':0,'tasks_allocated':6,'calls':len(requests),'stop':terminal['primary_state']['stopped']}
  pair['raw_files']=len(manifest)
  pair['archive_sha256']=hashlib.sha256((here/'raw.tar.gz').read_bytes()).hexdigest()
  return pair
if __name__=='__main__':print(json.dumps(verify(),indent=2))
''')
files=sorted(p for p in stage.rglob('*') if p.is_file())
manifest={p.relative_to(stage).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
with tarfile.open(out/'raw.tar.gz','w:gz') as archive:
 for p in files:archive.add(p,arcname=p.relative_to(stage).as_posix(),recursive=False)
(out/'raw-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for optimized in [False,True]:
 mode='optimized' if optimized else 'normal'
 r=subprocess.run([sys.executable]+(['-O'] if optimized else [])+[str(out/'verify.py')],capture_output=True)
 (out/(mode+'.stdout')).write_bytes(r.stdout);(out/(mode+'.stderr')).write_bytes(r.stderr)
 if r.returncode:raise RuntimeError(r.stderr.decode())
(out/'result.json').write_bytes((out/'normal.stdout').read_bytes())
print((out/'result.json').read_text())

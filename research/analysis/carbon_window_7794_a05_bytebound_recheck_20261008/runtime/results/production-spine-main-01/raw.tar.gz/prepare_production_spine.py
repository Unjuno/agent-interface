import hashlib,json,subprocess
from pathlib import Path
repo=Path(__file__).resolve().parent.parent;old=Path('/var/tmp/agent-interface-integrated-main/results-local/post-release-spine-13')
root=repo/'results-local/production-spine-01';root.mkdir(exist_ok=False)
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
for name in ['fixture.py','caller.mjs','controls.json']:
 text=(old/name).read_text().replace('post-release-spine-13','production-spine-01').replace('spine13','production-spine01')
 (root/name).write_text(text)
r=subprocess.run(['/usr/bin/python3',str(repo/'runtime/distribution_v2/build.py'),'--root',str(repo),'--out',str(root/'runtime.pyz'),'--manifest',str(root/'build-manifest.json'),'--sums',str(root/'SHA256SUMS'),'--host-directory',str(root/'host-bundle')],capture_output=True)
(root/'build.stdout').write_bytes(r.stdout);(root/'build.stderr').write_bytes(r.stderr)
if r.returncode:raise RuntimeError('portable build')
r=subprocess.run(['/home/taka/.volta/bin/node','--check',str(root/'caller.mjs')],capture_output=True)
(root/'caller-check.stdout').write_bytes(r.stdout);(root/'caller-check.stderr').write_bytes(r.stderr)
if r.returncode:raise RuntimeError('caller syntax')
dependencies=['research/live_control/run_native_six_task_self_use_v1.py','research/live_control/integrated_efficiency_fixture_v1.py','research/live_control/integrated_efficiency_runtime_v1.py','research/live_control/x11_window_manager_ready_v1.py','research/observation_gating/gui_suite.py','research/observation_gating/exact_gate.py','research/real_apps_v1/real_app_suite_v1.py']
for name in dependencies:
 target=root/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((repo/name).read_bytes())
plan=json.loads((old/'PLAN.json').read_text());plan.update(source=source,seed=1001061,H='Full primary guarded/direct comparison exercises the composed production entry path, including optional public post-release feedback, explicit changed-state refusal/review and independently scored six-task accounting.',T='Same current primary thread, same six-task fixture and seed per arm, same WSL Linux/X11/Chromium executable and committed portable source. Original guarded/direct schedules from retained successful known-family trial; original image/text presentation, explicit mint/move/remint/click choices.',U='Known fixture and fixed guarded-then-direct order; model context is not reset. Exact provider model/settings/cost are not independently established by this harness. No causal speed/token or human-tempo claim. A scoped correctness pass cannot imply full product success.',setup='Use exact installed Chromium and committed production fixture dependencies; imports checked without starting allocation. Configure browser target from actual targets.json. Existing helper requires positional alias/offset/interaction/tail. All six task rows remain in denominator. Expected controls preserve layout mismatch, old source4 and revoked alias refusal; any unexpected refusal STOP, no retry.',hashes={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()})
(root/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'root':str(root),'source':source,'seed':plan['seed'],'frozen_files':len(plan['hashes'])}))

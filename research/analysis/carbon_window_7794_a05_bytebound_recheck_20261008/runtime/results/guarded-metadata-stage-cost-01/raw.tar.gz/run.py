"""One frozen local presentation allocation; no GUI/model/SDK transport calls."""
import ast, base64, hashlib, importlib.util, json, platform, statistics, subprocess, sys, time
from pathlib import Path
from unittest.mock import patch
ROOT=Path('/var/tmp/agent-interface-integrated-main')
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from runtime.cli_v1 import mcp_server as candidate

def sha(data): return hashlib.sha256(data).hexdigest()
def check(ok,message):
    if not ok: raise RuntimeError(message)
def git(ref,path): return subprocess.check_output(['git','-C',str(ROOT),'show',ref+':'+path])
def main():
    plan=json.loads((OUT/'PLAN.json').read_text())
    check(sha(Path(__file__).read_bytes())==plan['runner_sha256'],'runner changed')
    spec=importlib.util.spec_from_file_location('runtime.cli_v1.benchmark_baseline',OUT/'baseline_mcp_server.py')
    baseline=importlib.util.module_from_spec(spec);spec.loader.exec_module(baseline)
    check(ast.dump(ast.parse(git(plan['baseline_ref'],'runtime/cli_v1/review.py'))) == ast.dump(ast.parse(git(plan['candidate_ref'],'runtime/cli_v1/review.py'))),'review source changed')
    for name,ref in [('baseline_mcp_server.py',plan['baseline_ref']),('candidate_mcp_server.py',plan['candidate_ref'])]:
        data=(OUT/name).read_bytes();check(data==git(ref,'runtime/cli_v1/mcp_server.py'),'source mismatch')
    check(Path(candidate.__file__).read_bytes()==(OUT/'candidate_mcp_server.py').read_bytes(),'imported candidate mismatch')
    original=Path(plan['report_path']);raw=original.read_bytes()
    check(sha(raw)==plan['report_sha256'],'report changed')
    report=json.loads(raw);image=Path(report['source']['native']['artifact']['path']);pixels=image.read_bytes()
    check(sha(pixels)==plan['png_sha256'],'PNG changed')
    methods={'baseline':lambda:baseline.content(baseline.present_management_report(report,original.parent),include_image=False),
             'candidate':lambda:candidate.content(candidate.present_management_report(report,original.parent,include_image=False),include_image=False)}
    # Semantic/encoding conformance outside timing; exact returned content expected.
    checks={}; expected=None
    for arm,method in methods.items():
        with patch('runtime.cli_v1.review.base64.b64encode',wraps=base64.b64encode) as encoder:
            reply=method();calls=encoder.call_count
        check(len(reply.content)==1 and reply.content[0].type=='text','unexpected image/content')
        dumped=reply.model_dump()
        if expected is None: expected=dumped
        else: check(dumped==expected,'metadata changed')
        check(calls==({'baseline':1,'candidate':0}[arm]),'encoding count')
        checks[arm]={'encoder_calls':calls,'reply_sha256':sha(json.dumps(dumped,sort_keys=True).encode())}
    # All ordered timing pairs retained; no warmup rows dropped, GC unchanged.
    with (OUT/'samples.jsonl').open('x') as stream:
        for pair in range(plan['pairs']):
            order=['baseline','candidate'] if pair%2==0 else ['candidate','baseline']
            for position,arm in enumerate(order):
                wall=time.perf_counter_ns();cpu=time.process_time_ns();reply=methods[arm]()
                cpu_ns=time.process_time_ns()-cpu;wall_ns=time.perf_counter_ns()-wall
                check(reply.model_dump()==expected,'timed output changed')
                stream.write(json.dumps({'pair':pair,'position':position,'arm':arm,'wall_ns':wall_ns,'cpu_ns':cpu_ns})+'\n')
    check(original.read_bytes()==raw and image.read_bytes()==pixels,'source mutated')
    result={'status':'COMPLETED_PRESENTATION_STAGE_ONLY','pairs':plan['pairs'],'checks':checks,
            'original_report_unchanged':True,'png_unchanged':True,'png_bytes':len(pixels),
            'environment':{'python':sys.version,'platform':platform.platform(),'perf_counter':vars(time.get_clock_info('perf_counter')),'process_time':vars(time.get_clock_info('process_time'))},
            'scope':'Shared synchronous presentation + MCP content construction only. No receipt read/async thread scheduling/SDK/relay/image acquisition/model inference/task latency or tokens measured.'}
    (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()

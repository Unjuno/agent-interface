"""Read-only stage timing audit; does not import/run the measured code."""
import hashlib,json,statistics,sys
from pathlib import Path

def need(ok,message):
    if not ok:raise ValueError(message)
def sha(b):return hashlib.sha256(b).hexdigest()
def audit(files):
    plan=json.loads(files['PLAN.json']);result=json.loads(files['result.json'])
    need(sha(files['run.py'])==plan['runner_sha256'],'runner freeze')
    need(sha(files['input_report.json'])==plan['report_sha256'],'report input')
    need(sha(files['input.png'])==plan['png_sha256'],'PNG input')
    report=json.loads(files['input_report.json'])
    need(report['source']['native']['artifact']['sha256']==plan['png_sha256'],'capture lineage')
    need(int(files['exit.txt'].decode().strip())==0,'outer exit')
    need(files['stderr.txt']==b'','stderr')
    need(result['status']=='COMPLETED_PRESENTATION_STAGE_ONLY','status')
    need(result['checks']['baseline']['encoder_calls']==1 and result['checks']['candidate']['encoder_calls']==0,'encoding counts')
    need(result['checks']['baseline']['reply_sha256']==result['checks']['candidate']['reply_sha256'],'reply parity record')
    need(result['original_report_unchanged'] is True and result['png_unchanged'] is True,'source unchanged record')
    need(result['png_bytes']==len(files['input.png']),'input size')
    rows=[json.loads(line) for line in files['samples.jsonl'].splitlines()]
    need(plan['pairs']==1000 and result['pairs']==1000 and len(rows)==2000,'denominator')
    pairs=[]
    for i in range(1000):
        pair=rows[i*2:i*2+2];order=['baseline','candidate'] if i%2==0 else ['candidate','baseline']
        for j,row in enumerate(pair):
            need(row['pair']==i and row['position']==j and row['arm']==order[j],'order/identity')
            need(all(type(row[k]) is int and row[k]>0 for k in ['wall_ns','cpu_ns']),'clock readings')
        pairs.append({row['arm']:row for row in pair})
    stats={}
    for clock in ['wall_ns','cpu_ns']:
        old=[p['baseline'][clock] for p in pairs];new=[p['candidate'][clock] for p in pairs]
        delta=[a-b for a,b in zip(old,new)]
        stats[clock]={'baseline_median':statistics.median(old),'candidate_median':statistics.median(new),'paired_delta_median':statistics.median(delta),'candidate_lower_pairs':sum(b<a for a,b in zip(old,new)),
          'candidate_first_delta_median':statistics.median(delta[1::2]),'baseline_first_delta_median':statistics.median(delta[::2])}
    return {'status':'PASS_LOCAL_PRESENTATION_STAGE_ACCOUNTING','pairs':1000,'rows':2000,'png_bytes':len(files['input.png']),'stats':stats,'scope':'One previously captured browser PNG, warm repeated local file reads, synchronous presenter+content only. Does not independently prove runner-reported semantic comparison or live SDK/model/task benefit. No variance calibration/population claim.'}
if __name__=='__main__':
    root=Path(sys.argv[1]);files={p.name:p.read_bytes() for p in root.iterdir() if p.is_file()}
    print(json.dumps(audit(files),indent=2))

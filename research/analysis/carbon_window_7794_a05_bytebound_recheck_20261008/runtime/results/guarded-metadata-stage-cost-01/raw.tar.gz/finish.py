import copy,importlib.util,json
from pathlib import Path
r=Path('/var/tmp/agent-interface-integrated-main/results-local/guarded-metadata-stage-cost-01')
spec=importlib.util.spec_from_file_location('stage_audit',r/'audit.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
f={p.name:p.read_bytes() for p in r.iterdir() if p.is_file()};pristine=m.audit(f)
(r/'audit.json').write_text(json.dumps(pristine,indent=2)+'\n')
controls=[]
for name in ['missing_row','wrong_order','forged_encoder_count','changed_png','missing_exit']:
    g=dict(f)
    if name=='missing_row':g['samples.jsonl']=b'\n'.join(g['samples.jsonl'].splitlines()[:-1])+b'\n'
    if name=='wrong_order':
        rows=g['samples.jsonl'].splitlines();rows[0],rows[1]=rows[1],rows[0];g['samples.jsonl']=b'\n'.join(rows)+b'\n'
    if name=='forged_encoder_count':
        x=json.loads(g['result.json']);x['checks']['candidate']['encoder_calls']=1;g['result.json']=json.dumps(x).encode()
    if name=='changed_png':g['input.png']+=b'changed'
    if name=='missing_exit':g['exit.txt']=b'1\n'
    try:m.audit(g)
    except ValueError as e:controls.append({'control':name,'rejected':True,'reason':str(e)})
    else:raise RuntimeError('accepted control '+name)
(r/'controls.json').write_text(json.dumps(controls,indent=2)+'\n')
intake={'current_main':'5527495b4e981d183478bec1acfd80eaeb02511a','candidates':[
{'issue':4362,'evidence_path':'research/measurement/o2_stream_real_capture_dot_v1/REPORT.md','disposition':'HOLD_PRODUCTION_ADOPTION','reason':'Retained-capture allocation benefit/parity reported, no live-path speed benefit. Targeted production public-entry/core/backend searches returned no tile_transport/observation_tiles consumer. Adding a new tile transport solely to adopt an offline encoder is not yet justified.'},
{'issue':4321,'branch':'research/online-effect-completion-2869-20260924-t5e7','observed_directory_names':['README.md','SOURCE_MANIFEST.json','source','unpack.py','vendor','verify_publication.py'],'disposition':'HOLD_RESULT_DELIVERY','reason':'Formal success reported but branch directory currently lacks RESULT_MANIFEST/formal raw capsule/AUDIT/CONTROLS. No formal rerun or inferred result rows.'},
{'issue':5518,'disposition':'HOLD_TOY_CONTRACT_TRANSFER','reason':'Recent Issue comments describe authored finite conformance probes; no real adapter/quiescence semantics proven.'},
{'issue':5508,'disposition':'HOLD_EXTERNAL_EFFECT_TRANSFER','reason':'Recent receipt/concurrent-sink/process-crash evidence is local SQLite authored state, not external GUI receipt semantics.'}],
'next_priority':'Fresh useful feedback and primary semantic completion boundaries, preserving original dispatch/release and no input replay. No longer fixed-wait default, sensors or implicit polling adopted.'}
(r/'integration-intake.json').write_text(json.dumps(intake,indent=2)+'\n')
print(json.dumps({'audit':pristine,'controls_rejected':len(controls),'intake_cases':len(intake['candidates'])},indent=2))

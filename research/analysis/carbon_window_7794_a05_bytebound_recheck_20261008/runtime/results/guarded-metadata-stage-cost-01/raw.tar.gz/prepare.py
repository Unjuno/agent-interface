import hashlib,json,subprocess
from pathlib import Path
r=Path('/var/tmp/agent-interface-integrated-main');o=r/'results-local/guarded-metadata-stage-cost-01'
refs={'baseline':'402e19ae6d2637af46577d67dfa45d4c6a6f2c70','candidate':subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD']).decode().strip()}
for arm,ref in refs.items():
    (o/(arm+'_mcp_server.py')).write_bytes(subprocess.check_output(['git','-C',str(r),'show',ref+':runtime/cli_v1/mcp_server.py']))
p=r/'results-local/guarded-metadata-no-encode-01/allocation/server/c84e3da3837f494a991640f86ad1ef1c/report.json'
raw=p.read_bytes();report=json.loads(raw);img=Path(report['source']['native']['artifact']['path'])
sha=lambda b:hashlib.sha256(b).hexdigest()
plan={'baseline_ref':refs['baseline'],'candidate_ref':refs['candidate'],'runner_sha256':sha((o/'run.py').read_bytes()),'report_path':str(p),'report_sha256':sha(raw),'png_sha256':sha(img.read_bytes()),'pairs':1000,'allocation':'one local paired presentation loop; all 2000 rows retained; alternating arm order; first execution only; no GUI/model/tool dispatch','policy':'Exact final metadata and image omission equality; encoder counts outside timing baseline1/candidate0. No preselected speed gate or inference/general performance claim. No warmup exclusion. Retain errors, do not replace failed allocation.'}
(o/'PLAN.json').write_text(json.dumps(plan,indent=2)+'\n')
(o/'input_report.json').write_bytes(raw);(o/'input.png').write_bytes(img.read_bytes())
print(json.dumps(plan,indent=2))

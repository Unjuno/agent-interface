import json,subprocess,sys,time,traceback
from pathlib import Path
r=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(r),str(r/'research/live_control'),str(r/'research/observation_gating')]
from run_native_six_task_self_use_v1 import PrivateSession
out=r/'results-local/public-inkscape-batch-01';out.mkdir(exist_ok=False)
def save(n,v):(out/n).write_text(json.dumps(v,indent=2)+'\n')
s=None
try:
 s=PrivateSession();save('readiness.json',s.window_manager_readiness)
 doc=out/'drawing.svg';doc.write_text('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="240" viewBox="0 0 400 240"></svg>')
 p=s._popen(['inkscape',str(doc)],cwd=r)
 end=time.monotonic()+30;wid=None
 while time.monotonic()<end:
  for line in s.windows().splitlines():
   if 'Inkscape' in line or 'drawing.svg' in line:wid=int(line.split()[0],16);break
  if wid:break
  time.sleep(.1)
 if not wid:raise RuntimeError('Inkscape target missing')
 subprocess.run(['wmctrl','-ir',hex(wid),'-b','add,maximized_vert,maximized_horz'],env=s.env,check=True)
 save('targets.json',{'inkscape':wid});save('allocation.json',{'display':s.name,'window':wid,'screen':[s.d.screen().width_in_pixels,s.d.screen().height_in_pixels],'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'task':'Create two distinct rectangles on the page using visually selected coordinates, then save drawing.svg. Do not accept toolbar or off-page shapes as success.'})
 print(json.dumps({'ready':True,'display':s.name,'window':wid}),flush=True)
 end=time.monotonic()+900
 while not (out/'finish.json').exists():
  if time.monotonic()>end:raise TimeoutError('primary allocation expired')
  time.sleep(.1)
 save('finished.json',{'inkscape_exit_before_cleanup':p.poll(),'svg_sha256':__import__('hashlib').sha256(doc.read_bytes()).hexdigest()})
except BaseException as e:save('failure.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
finally:
 if s is not None:s.close();save('cleanup.json',[{'pid':p.pid,'returncode':p.poll()} for p in s.procs])

/** Use directly with createInstrumentedRelayClient.present(attempt, callbacks).
 * Text is not assumed to be JSON. No metadata projection, replay, or task policy.
 */
export function passthroughCallbacks(host) {
  return {
    text: async value => host.write(value),
    image: async value => host.emitImage(value),
  };
}
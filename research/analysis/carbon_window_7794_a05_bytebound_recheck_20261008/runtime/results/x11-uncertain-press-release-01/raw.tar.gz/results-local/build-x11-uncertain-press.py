from pathlib import Path
import sys,json,hashlib,subprocess
r=Path('/var/tmp/agent-interface-integrated-main');sys.path.insert(0,str(r))
from runtime.distribution_v2.build import build
out=r/'results-local/x11-uncertain-press-build-01';out.mkdir(exist_ok=False)
build(r,out/'runtime.pyz',out/'manifest.json',out/'SHA256SUMS')
(out/'build.json').write_text(json.dumps({'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'sha256':hashlib.sha256((out/'runtime.pyz').read_bytes()).hexdigest()},indent=2))
print((out/'build.json').read_text())
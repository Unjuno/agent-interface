import sys,json,hashlib,subprocess
from pathlib import Path
from unittest import mock
from Xlib import X,XK
from Xlib.ext import xtest
r=Path('/var/tmp/agent-interface-integrated-main');sys.path[:0]=[str(r),str(r/'research/live_control')]
from run_native_six_task_self_use_v1 import PrivateSession
from runtime.backends.x11_v1.backend import X11Backend,X11ExecutionError
out=r/'results-local/x11-uncertain-press-before-02';out.mkdir(exist_ok=False)
s=PrivateSession();b=None
try:
 b=X11Backend(s.name,{})
 code=s.d.keysym_to_keycode(XK.string_to_keysym('w'))
 original_sync=b.d.sync;calls=0
 def fail_after_sync():
  global calls
  calls+=1;original_sync()
  if calls==1:raise OSError('injected lost sync acknowledgement after server processed press')
 try:
  with mock.patch.object(b.d,'sync',side_effect=fail_after_sync):
   b.execute({'ops':[{'op':'key_state','key':'w','down':True},{'op':'wait_update','timeout_ms':10},{'op':'key_state','key':'w','down':False},{'op':'release_all'}]})
 except X11ExecutionError as e:execution=e.execution
 else:raise RuntimeError('expected fault was not raised')
 keys=s.d.query_keymap();down=bool(keys[code//8]&(1<<(code%8)))
 report={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'display':s.name,'fault':'after actual XSync completion for first key press; construction only','execution':execution,'tracked_keys_after_failure':dict(b.held_keycodes),'independent_w_down':down}
 (out/'result.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
 (out/'backend-before.py').write_bytes((r/'runtime/backends/x11_v1/backend.py').read_bytes())
finally:
 if 'code' in globals():
  xtest.fake_input(s.d,X.KeyRelease,code);s.d.sync()
  keys=s.d.query_keymap();(out/'cleanup-key.json').write_text(json.dumps({'independent_w_down':bool(keys[code//8]&(1<<(code%8)))}))
 if b:b.close()
 s.close();(out/'cleanup-processes.json').write_text(json.dumps([{'pid':p.pid,'code':p.poll()} for p in s.procs]))
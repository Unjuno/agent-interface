import sys,runpy
from unittest import mock
archive=sys.argv.pop(1);sys.path.insert(0,archive)
from runtime.backends.x11_v1.backend import X11Backend
original=X11Backend.key_state
injected=False
def key_state(self,key,down):
 global injected
 if down and not injected:
  injected=True
  sync=self.d.sync
  def lost_reply():
   sync();raise OSError('construction: lost acknowledgement after processed key press')
  with mock.patch.object(self.d,'sync',side_effect=lost_reply):return original(self,key,down)
 return original(self,key,down)
X11Backend.key_state=key_state
runpy.run_module('runtime.cli_v1.mcp_server',run_name='__main__')
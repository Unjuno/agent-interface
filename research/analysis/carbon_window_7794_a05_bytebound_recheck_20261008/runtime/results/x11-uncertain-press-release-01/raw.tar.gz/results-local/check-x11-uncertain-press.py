import sys,json,subprocess
from pathlib import Path
from unittest import mock
from Xlib import X,XK
from Xlib.ext import xtest
r=Path('/var/tmp/agent-interface-integrated-main');sys.path[:0]=[str(r),str(r/'research/live_control')]
from run_native_six_task_self_use_v1 import PrivateSession
from runtime.backends.x11_v1.backend import X11Backend,X11ExecutionError
out=r/'results-local/x11-uncertain-press-after-01';out.mkdir(exist_ok=False)
rows=[]
for pointer in (False,True):
 for boundary in ('send','sync'):
  s=PrivateSession();b=X11Backend(s.name,{});row={'pointer':pointer,'boundary':boundary}
  code=s.d.keysym_to_keycode(XK.string_to_keysym('w'));original_sync=b.d.sync;original_emit=xtest.fake_input;calls=[0]
  press=X.ButtonPress if pointer else X.KeyPress
  def emit(display,event,detail):
   original_emit(display,event,detail)
   if event==press and boundary=='send':
    original_sync();raise OSError('injected send-call failure after server processed press')
  def sync():
   calls[0]+=1;original_sync()
   if calls[0]==1:raise OSError('injected lost sync acknowledgement after server processed press')
  try:
   op={'op':'pointer_button','button':'left','down':True} if pointer else {'op':'key_state','key':'w','down':True}
   patch=mock.patch.object(b.d,'sync',side_effect=sync) if boundary=='sync' else mock.patch.object(xtest,'fake_input',side_effect=emit)
   try:
    with patch:b.execute({'ops':[op,{'op':'wait_update','timeout_ms':10},{'op':'release_all'}]})
   except X11ExecutionError as e:row['execution']=e.execution
   else:raise RuntimeError('fault not raised')
   keys=s.d.query_keymap();row['independent_w_down']=bool(keys[code//8]&(1<<(code%8)));row['independent_left_down']=bool(s.d.screen().root.query_pointer().mask&X.Button1Mask)
   row['tracked_keys']=dict(b.held_keycodes);row['tracked_buttons']=sorted(b.held_buttons)
  finally:
   original_emit(s.d,X.KeyRelease,code);original_emit(s.d,X.ButtonRelease,1);s.d.sync();b.close();s.close()
   row['cleanup']=[{'pid':p.pid,'code':p.poll()} for p in s.procs];rows.append(row)
   (out/'results.json').write_text(json.dumps(rows,indent=2))
(out/'source.json').write_text(json.dumps({'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()}))
print(json.dumps(rows))
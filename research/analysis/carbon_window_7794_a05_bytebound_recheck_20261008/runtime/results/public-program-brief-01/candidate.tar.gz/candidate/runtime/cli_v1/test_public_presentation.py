import copy
import json
import unittest
from runtime.cli_v1.public_presentation import brief_public_report
from runtime.cli_v1.receipt_references import expand_receipt

def fixture():
    program = {'schema':'agent-interface/program-v1','ops':[{'op':'text','text':'x'*3000}]}
    execution={'observations':[], 'waits':[], 'releases':[{'verified':True,'keys_down':[],'buttons_down':[]}],
               'completed_ops':[0], 'program_emissions':10}
    raw={'schema':'agent-interface/runtime-dispatch-result-v1','status':'returned',
         'result':{'status':'completed','admission':'accepted','recovery_required':False,'execution':execution},
         'normalization':{'kind':'explicit_observation_region','source_program':program,'source_operation_indices':[0]},
         'extension':{'unknown':'preserve'}}
    return {'receipt':{'schema':'agent-interface/receipt-view-v3-report-ref','source':{'raw_report':raw,'sha256':'old'},
                       'report':{'report_ref':'/source/raw_report'},'report_reference':'/source/raw_report'},
            'outcome_summary':{'execution_status':'completed','input_release_verified':True},
            'image_status':'image','image_reference':{'sha256':'image'},'call_id':'exact'}

class PublicBriefTests(unittest.TestCase):
    def test_only_source_program_is_omitted_and_full_retrieval_is_explicit(self):
        before=fixture();view=copy.deepcopy(before);new=brief_public_report(view)
        self.assertEqual(view,before)
        self.assertEqual(new['presentation']['returned'],'brief')
        raw=new['receipt']['source']['report_projection']
        original=before['receipt']['source']['raw_report']
        self.assertEqual(raw['result'],original['result'])
        self.assertEqual(raw['extension'],original['extension'])
        self.assertEqual(new['image_reference'],before['image_reference'])
        self.assertNotIn('source_program',raw['normalization'])
        self.assertEqual(new['presentation']['retrieve']['arguments']['call_id'],'exact')
        self.assertEqual(new['presentation']['retrieve']['arguments']['detail'],'full')
        self.assertLess(len(json.dumps(new)),len(json.dumps(before)))
        with self.assertRaises(ValueError):expand_receipt(new['receipt'])

    def test_failures_and_unavailable_images_keep_original_evidence(self):
        mutations=[
            lambda v:v.update(persistence_error='disk'),
            lambda v:v.update(image_status='missing'),
            lambda v:v['outcome_summary'].update(execution_error='partial'),
            lambda v:v['receipt']['source']['raw_report']['result'].update(status='failed'),
            lambda v:v['receipt']['source']['raw_report']['result'].update(recovery_required=True),
            lambda v:v['receipt']['source']['raw_report']['result']['execution']['releases'][0].update(verified=False),
            lambda v:v['receipt']['source']['raw_report']['result']['execution']['observations'].append({'artifact_error':'failed'}),
            lambda v:v['receipt']['source']['raw_report']['result']['execution']['waits'].append({'completed':False}),
        ]
        for mutate in mutations:
            with self.subTest(mutate=mutate):
                view=fixture();mutate(view);new=brief_public_report(view)
                self.assertEqual(new.pop('presentation')['returned'],'full')
                self.assertEqual(new,view)

    def test_unknown_compilers_and_existing_markers_are_not_overwritten(self):
        for mutate in [
            lambda s:s.update(kind='future'),
            lambda s:s.update(source_program_omitted={'extension':'keep'}),
            lambda s:s['source_program'].update(schema='future')]:
            view=fixture();mutate(view['receipt']['source']['raw_report']['normalization'])
            new=brief_public_report(view)
            self.assertEqual(new.pop('presentation')['returned'],'full')
            self.assertEqual(new,view)

    def test_small_program_is_not_expanded_by_summary_metadata(self):
        view=fixture();view['receipt']['source']['raw_report']['normalization']['source_program']['ops']=[]
        new=brief_public_report(view)
        self.assertEqual(new.pop('presentation')['returned'],'full')
        self.assertEqual(new,view)

if __name__=='__main__':unittest.main()

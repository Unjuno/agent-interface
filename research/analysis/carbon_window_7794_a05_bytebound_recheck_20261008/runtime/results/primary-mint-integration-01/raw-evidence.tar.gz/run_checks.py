import json, subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
repo=root.parents[1]
node='/home/taka/.volta/bin/node'
checks={
 'node':[node,'--test',*map(str,[repo/'research/live_control/test_native_relay_client_v1.mjs',repo/'research/live_control/test_relay_host_timeline_v1.mjs',*sorted((repo/'runtime/host_v1').glob('test_*.mjs'))])],
 'native':['/tmp/agent-interface-mcp-venv/bin/python',str(repo/'runtime/integration_checks/native.py'),'--output',str(root/'native')]
}
results={}
for name,command in checks.items():
 with (root/(name+'.stdout')).open('w') as out,(root/(name+'.stderr')).open('w') as err:
  code=subprocess.run(command,cwd=repo,stdout=out,stderr=err).returncode
 results[name]={'command':command,'exit_code':code}
 (root/'checks.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name,code,flush=True)
 if code: raise SystemExit(code)

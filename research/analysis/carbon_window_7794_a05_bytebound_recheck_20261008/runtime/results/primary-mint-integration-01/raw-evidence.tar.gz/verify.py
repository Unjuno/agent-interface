import hashlib,json,base64
from pathlib import Path
r=Path(__file__).parent
def load(p):return json.loads((r/p).read_text())
def need(ok,why):
 if not ok:raise ValueError(why)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in load('RAW_MANIFEST.json')['files'].items():need(digest(r/p)==h,'raw digest '+p)
old=load('spine10/PLAN.json')
for p,h in old['hashes'].items():need(digest(r/'spine10'/p)==h,'frozen spine10 '+p)
need(load('PLAN.json')['source']=='b6a6b1b155a13d20f37bb191da3d1c13907ce7f6','helper source')
need(load('build-manifest.json')['source_revision']==load('PLAN.json')['source'],'bundle source')
for prefix,count in [('guarded-local',10),('spine10/guarded-local',22)]:
 host=r/prefix/'host'
 need(len(list(host.glob('request-*.json')))==count,'request count')
 need(len(list(host.glob('reply-*.json')))==count,'reply count')
 images=0
 for i in range(1,count+1):
  req=json.loads((host/f'request-{i}.json').read_text());reply=json.loads((host/f'reply-{i}.json').read_text())
  need(req['id']==i and reply['id']==i and req['tool']==reply['tool'],'original exchange sequence')
  text=next(c['text'] for c in reply['result']['content'] if c['type']=='text');m=json.loads(text)
  imageblocks=[c for c in reply['result']['content'] if c['type']=='image']
  if imageblocks:
   images+=1; review=json.loads((host/f'review-{i}.json').read_text())
   need(review['reply_sha256']==digest(host/f'reply-{i}.json'),'review reply digest')
   need([hashlib.sha256(base64.b64decode(c['data'])).hexdigest() for c in imageblocks]==[c['sha256'] for c in review['images']],'original image digest')
  if req['tool']=='interface_guarded_input':
   need(not reply['result']['isError'] and m['status']=='completed','ordinary input outcome')
   need(all(x['verified'] and not x['keys_down'] and not x['buttons_down'] for x in m['result']['execution']['releases']),'neutral input')
  if i==count:
   need(req['tool']=='interface_close' and m['status']=='closed','public close')
   need(m['release']['verified'] and not m['release']['keys_down'] and not m['release']['buttons_down'],'close neutral')
   need((host/f'text-acknowledgment-{i}.json').is_file(),'close acknowledgment')
 need(images==(5 if count==10 else 8),'image count')
 terminal=load(prefix+'/caller-terminal.json')
 need(terminal['transport']=={'code':0,'signal':None},'original transport terminal')
 need(terminal['state']['stopped']==(None if count==10 else 'unexpected MCP refusal'),'caller stop')
 score=load(prefix+'/session/evaluation-at-close.json')
 need(score['exact_counts']=={'task-'+str(i):int(i==1) for i in range(1,7)},'exact counts')
 need(score['record_count']==1 and not score['success'] and not score['duplicates'] and not score['unexpected'],'score scope')
 need(all(x['returncode'] is not None for x in load(prefix+'/session/cleanup.json')),'fixture children terminal')
error=load('spine10/guarded-local/host/reply-21.json')
m=json.loads(error['result']['content'][0]['text'])
need(error['result']['isError'] and m['unknown_arguments']==['region'] and not m['input_dispatched'] and not m['operation_invoked'],'retained invalid mint')
for i,alias,seq,point in [(2,'nav_smoke',1,[350,73]),(4,'field_smoke',4,[230,401]),(6,'save_off_smoke',9,[376,401]),(8,'save_hover_smoke',13,[376,401])]:
 need(load(f'guarded-local/host/request-{i}.json')['arguments']=={'alias':alias,'source_sequence':seq,'point':point,'region_size':[24,38]},'helper public request')
need(load('native/result.json')['status']=='PASS','native checks')
need(all(v['exit_code']==0 for v in load('checks.json').values()),'local checks')
print('PASS_RETENTION_AND_ONE_TASK_HELPER_ONLY; six-task adoption remains HOLD')

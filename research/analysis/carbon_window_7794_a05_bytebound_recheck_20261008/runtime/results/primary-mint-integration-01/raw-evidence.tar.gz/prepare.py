import json,subprocess,shutil
from pathlib import Path
r=Path(__file__).parent; repo=r.parents[1]
shutil.copyfile(repo/'results-local/post-release-spine-10/fixture.py',r/'fixture.py')
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
(r/'PLAN.json').write_text(json.dumps({'source':source,'seed':1001057,'scope':'one task personal public-helper usability smoke, not six-task adoption or matched comparison','route':'guarded-local','procedure':'build committed bundle; private fixture; observe original image and review; explicit mint/navigation; view/review; explicit mint/field; view/review; explicit mint/Save; view/review; public close and text acknowledgment; original transport and fixture cleanup; independent evaluation after close','stop':'unexpected refusal, uncertain input or image failure stops; only close and attribution/transport cleanup; no input retry'},indent=2)+'\n')
cmd=['/usr/bin/python3','runtime/distribution_v2/build.py','--root',str(repo),'--out',str(r/'runtime.pyz'),'--manifest',str(r/'build-manifest.json'),'--sums',str(r/'SHA256SUMS'),'--host-directory',str(r/'host-bundle')]
with (r/'build.stdout').open('w') as out,(r/'build.stderr').open('w') as err:
 code=subprocess.run(cmd,cwd=repo,stdout=out,stderr=err).returncode
if code:raise SystemExit(code)
print(source)

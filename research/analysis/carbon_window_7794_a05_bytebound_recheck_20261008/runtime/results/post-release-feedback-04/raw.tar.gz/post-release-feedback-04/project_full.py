import copy,json,sys
from pathlib import Path
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root.parents[1]))
from runtime.cli_v1.review import present_result
from runtime.cli_v1.public_summary import summarize_public_dispatch
from analyze import load,meta,need,sha
rows={}
for route in ['candidate-post','baseline-inline']:
 p=root/route;h=p/'host';s=p/'session';out=p/'same-report-full';out.mkdir(exist_ok=True);records=[]
 for task in load(s/'finish.json')['taskRows']:
  for phase,key in [('navigation','navigationAttempt'),('save','saveAttempt')]:
   i=task[key];reply=load(h/f'reply-{i}.json');actual=meta(reply);q=load(h/f'request-{i}.json');callroot=s/'server'/actual['call_id'];raw=load(callroot/'report.json')
   full=present_result(raw,callroot,compact=True,report_refs=True,include_image=True)
   full['session']=copy.deepcopy(raw['session'])
   if 'post_dispatch_inspection' in raw:full['post_dispatch_inspection']=copy.deepcopy(raw['post_dispatch_inspection'])
   full.update(call_id=actual['call_id'],call_directory=str(callroot))
   projected=summarize_public_dispatch(full,source_program=q['arguments']['program']);projected.pop('image',None)
   need(projected==actual,'offline summary reproduces original wire metadata')
   full.pop('image',None);fullbytes=json.dumps(full,allow_nan=False).encode();(out/f'full-{i}.json').write_bytes(fullbytes)
   text=next(x['text'] for x in reply['result']['content'] if x['type']=='text').encode();records.append({'attempt':i,'task':task['task'],'phase':phase,'actual_summary_text_bytes':len(text),'same_report_full_text_bytes':len(fullbytes),'same_report_full_sha256':sha(fullbytes),'image_reference_identical':full['image_reference']==actual['image_reference'],'outcome_identical':full['outcome_summary']==actual['outcome_summary']})
 rows[route]={'calls':records,'summary_bytes':sum(x['actual_summary_text_bytes'] for x in records),'full_bytes':sum(x['same_report_full_text_bytes'] for x in records)}
record={'schema':'agent-interface/same-report-full-projection-v1','source':load(root/'PLAN.json')['source'],'arms':rows,'scope':'Read-only offline reconstruction with pinned current full presenter and actual pre-invocation request copy. Reproduces each original summary metadata exactly; no tool operation, new capture, input, model presentation or isolated token/billing measurement.'};(root/'same-report-full-projection.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:{x:v[x] for x in ['summary_bytes','full_bytes']} for k,v in rows.items()}))

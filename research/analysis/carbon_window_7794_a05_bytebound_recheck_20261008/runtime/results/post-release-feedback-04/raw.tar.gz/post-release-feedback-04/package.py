import hashlib,json,tarfile
from pathlib import Path
repo=Path(__file__).resolve().parents[2];dest=repo/'runtime/results/post-release-feedback-04';files=[]
with tarfile.open(dest/'raw.tar.gz','x:gz') as t:
 for name in ['post-release-feedback-03','post-release-feedback-04']:
  root=repo/'results-local'/name
  for path in sorted(root.rglob('*')):
   if not path.is_file() or '__pycache__' in path.parts:continue
   arc=name+'/'+path.relative_to(root).as_posix();b=path.read_bytes();files.append({'path':arc,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()});t.add(path,arcname=arc,recursive=False)
b=(dest/'raw.tar.gz').read_bytes();manifest={'schema':'agent-interface/retained-six-task-feedback-manifest-v1','source':json.loads((repo/'results-local/post-release-feedback-04/PLAN.json').read_text())['source'],'archive':{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},'files':files,'scope':'Local byte consistency; not authenticated source, runtime, model or image provenance.'};(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'files':len(files),'bytes':len(b)}))

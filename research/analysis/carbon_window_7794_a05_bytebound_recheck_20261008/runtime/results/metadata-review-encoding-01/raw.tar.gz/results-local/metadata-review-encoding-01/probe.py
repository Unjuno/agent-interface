import asyncio,json,sys,hashlib,copy
from pathlib import Path
from unittest.mock import patch
archive,fixture,output=sys.argv[1:]
sys.path.insert(0,archive)
from runtime.cli_v1.mcp_server import create_server
from runtime.cli_v1 import review
async def probe():
 root=Path(output);root.mkdir()
 original=json.loads(Path(fixture).read_text());native=original['result']['execution']['observations'][-1]
 png=Path(native['artifact']['path']).read_bytes()
 server=create_server({'inkscape':native['native_window_id']},root/'server')
 def observation(_targets,**kwargs):
  selected=copy.deepcopy(native);path=Path(kwargs['capture_directory'])/'retained.png';path.parent.mkdir(parents=True);path.write_bytes(png)
  selected['artifact']['path']=str(path)
  return {'schema':'agent-interface/runtime-observation-v1','status':'returned','observation':selected}
 calls=[];encoder=review.base64.b64encode
 def counted(data):calls.append(len(data));return encoder(data)
 with patch('runtime.cli_v1.mcp_server.observe',side_effect=observation) as acquire,patch('runtime.cli_v1.review.base64.b64encode',side_effect=counted):
  initial=await server.call_tool('interface_observe',{'target':'inkscape','frame':'screen_physical_px','region':native['region']})
  meta=json.loads(initial.content[0].text);call_id=meta['call_id'];report=root/'server'/call_id/'report.json';before=report.read_bytes()
  rows=[]
  for label,include in [('omitted',False),('included',True)]:
   calls.clear();reply=await server.call_tool('interface_results',{'call_id':call_id,'include_image':include,'compact':True,'report_refs':True})
   (root/(label+'.json')).write_text(reply.model_dump_json())
   row=json.loads(reply.content[0].text)
   if row['image_status']!='image' or row['operation_invoked'] is not False:raise RuntimeError(label)
   if len(reply.content)!=(2 if include else 1):raise RuntimeError('content count')
   rows.append({'case':label,'encoding_calls':len(calls),'encoding_input_bytes':sum(calls),'content_blocks':len(reply.content)})
  if report.read_bytes()!=before:raise RuntimeError('raw changed')
  (root/'lookup-original-report.json').write_bytes(before)
  image=Path(meta['image_reference']['path']);image.write_bytes(png+b' ');calls.clear()
  broken=await server.call_tool('interface_results',{'call_id':call_id,'include_image':False})
  (root/'altered-image.json').write_text(broken.model_dump_json());bad=json.loads(broken.content[0].text)
  if bad['image_status']!='needs_review' or calls:raise RuntimeError('corrupt image bypass')
  if acquire.call_count!=1:raise RuntimeError('reacquired')
  included=json.loads((root/'included.json').read_text())['content'][0]['text'];omitted=json.loads((root/'omitted.json').read_text())['content'][0]['text'];a=json.loads(included);b=json.loads(omitted);b.pop('image_delivery')
  if a!=b:raise RuntimeError('metadata changed')
  (root/'probe.json').write_text(json.dumps({'archive':archive,'rows':rows,'image_sha256':hashlib.sha256(png).hexdigest(),'report_unchanged':True,'metadata_parity':True,'altered_image_refused':True,'input_dispatched':False,'scope':'retained actual PNG injected into server observation acquisition; no live GUI/model/MCP stdio task'},indent=2)+'\n')
 print(json.dumps(rows))
asyncio.run(probe())

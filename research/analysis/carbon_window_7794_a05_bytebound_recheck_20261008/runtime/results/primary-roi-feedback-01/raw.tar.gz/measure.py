import json,base64,hashlib,platform
from pathlib import Path
p=Path(__file__).resolve().parent
load=lambda n:json.loads(n.read_text());results={};programs={}
for route in ('full','roi'):
 d=p/route;h=d/'host';events=[json.loads(x) for x in (h/'host-events.jsonl').read_text().splitlines()];rows=[];programs[route]=[]
 for request in sorted(h.glob('request-*.json'),key=lambda x:int(x.stem.split('-')[-1])):
  i=int(request.stem.split('-')[-1]);q=load(request);r=load(h/f'reply-{i}.json');ev={e['kind']:e for e in events if e.get('attempt')==i};m=json.loads(next(x['text'] for x in r['result']['content'] if x['type']=='text'));imgs=[x for x in r['result']['content'] if x['type']=='image']
  row={'attempt':i,'tool':q['tool'],'call_id':m.get('call_id'),'image_count':len(imgs),'image_png_bytes':sum(len(base64.b64decode(x['data'])) for x in imgs),'host_send_to_callbacks_ms':ev['presentation_callbacks_completed']['host_monotonic_ms']-ev['send_requested']['host_monotonic_ms'],'reply_to_callbacks_ms':ev['presentation_callbacks_completed']['host_monotonic_ms']-ev['reply_available']['host_monotonic_ms']}
  if 'review_recorded' in ev:row['callbacks_to_review_annotation_ms']=ev['review_recorded']['host_monotonic_ms']-ev['presentation_callbacks_completed']['host_monotonic_ms']
  raw=load(d/'server'/m['call_id']/'report.json')
  if q['tool']=='interface_dispatch':
   ex=raw['result']['execution'];row.update(execution_ms=(ex['ended_ns']-ex['started_ns'])/1e6,fixed_wait_ms=sum(w['requested_ms'] for w in ex['waits']),release_verified=bool(ex['releases']) and all(x['verified'] and not x['keys_down'] and not x['buttons_down'] for x in ex['releases']),captures=[{'width':x['width'],'height':x['height'],'region':x['region'],'capture_ms':(x['capture_ended_ns']-x['capture_started_ns'])/1e6,'artifact_png_bytes':x['artifact']['bytes']} for x in ex['observations']])
   program=json.loads(json.dumps(q['arguments']['program']))
   for op in program['ops']:
    if op['op']=='observe':op['region']='<treatment-region>'
    if op.get('text')==load(d/'goal.json')['tasks'][0]['url']:op['text']='<task-url>'
   programs[route].append(program['ops'])
  rows.append(row)
 submissions=[json.loads(x) for x in (d/'submission-history.jsonl').read_text().splitlines()];finish=load(d/'finish.json')
 exact=len(submissions)==1 and submissions[0]['task_id']=='task-1' and submissions[0]['exact'] is True and submissions[0]['submitted_values']==['t1001027-1']
 results[route]={'rows':rows,'correct_task1_once':exact,'extra_observations':finish['extra_observation'],'input_replay':finish['input_replay'],'dispatch_count':sum(r['tool']=='interface_dispatch' for r in rows),'total_calls':len(rows),'total_images':sum(r['image_count'] for r in rows),'total_png_bytes':sum(r['image_png_bytes'] for r in rows),'dispatch_png_bytes':sum(r['image_png_bytes'] for r in rows if r['tool']=='interface_dispatch'),'transport_exit':load(h/'exit.json'),'cleanup':load(d/'cleanup.json'),'six_task_aggregate':load(d/'evaluation-at-close.json')}
checks={'normalized_program_ops_equal':programs['full']==programs['roi'],'both_one_correct_save':all(r['correct_task1_once'] for r in results.values()),'three_dispatches_each':all(r['dispatch_count']==3 for r in results.values()),'all_dispatches_released':all(x['release_verified'] for r in results.values() for x in r['rows'] if x['tool']=='interface_dispatch'),'neutral_transport_exits':all(r['transport_exit']['code']==0 for r in results.values()),'actual_recovery_kept':results['full']['extra_observations']==1 and results['roi']['extra_observations']==0,'both_fixture_process_exits_zero':True}
receipt=load(p/'execution-receipt.json');checks['both_fixture_process_exits_zero']=receipt['full']['exit']==0 and receipt['roi']['exit']==0
metrics={'status':'PASS_PRIMARY_ROI_TASK_USE_SCOPED' if all(checks.values()) else 'HOLD_ACCOUNTING','checks':checks,'source_revision':'a2469a821f4d27d2ec9a1d5d63ed8b81e57f81c3','environment':{'kernel':platform.release(),'python':platform.python_version()},'routes':results,'dispatch_pixels':{'full':3*1280*800,'roi':3*1050*400,'fraction_removed':1-(1050*400)/(1280*800)},'limits':'Single fixed-order pair. Full navigation image was still blank and required explicit requery; ROI navigation image was ready. Different render timing makes latency/byte differences causally confounded. No actual isolated image/model tokens, cost, general readiness, semantic oracle, speedup or human-tempo claim.'}
(p/'metrics.json').write_text(json.dumps(metrics,indent=2)+'\n');print(json.dumps(metrics,indent=2));raise SystemExit(0 if all(checks.values()) else 1)

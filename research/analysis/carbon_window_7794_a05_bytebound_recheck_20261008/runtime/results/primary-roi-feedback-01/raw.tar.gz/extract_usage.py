import pathlib,json,hashlib
log=pathlib.Path('/mnt/c/Users/junny/.codex/sessions/2026/09/12/rollout-2026-09-12T23-46-37-01a09615-a96c-7b70-8284-e6391b885be5.jsonl')
rows=[]
with log.open('rb') as f:
 f.seek(max(0,log.stat().st_size-16*1024*1024));f.readline()
 for line in f:
  try:rows.append(json.loads(line))
  except (ValueError,UnicodeError):pass
context=None;calls={};selected=[]
for r in rows:
 p=r.get('payload',{})
 if r.get('type')=='turn_context':context={k:p.get(k) for k in ['model','effort','turn_id']}
 if r.get('type')=='response_item' and p.get('type')=='custom_tool_call' and 'tools.mcp__node_repl__js' in p.get('input','') and 'roi' in p.get('input',''):
  row={'call_id':p['call_id'],'timestamp':r.get('timestamp'),'input_sha256':hashlib.sha256(p['input'].encode()).hexdigest(),'local_context':context,'route':'guarded' if 'live4G' in p['input'] else 'direct_or_setup','usage_records_before_output':[]};calls[p['call_id']]=row;selected.append(row)
 if r.get('type')=='token_usage_record':
  for row in calls.values():row['usage_records_before_output'].append({'ordinal':r.get('ordinal'),'timestamp':r.get('timestamp'),'response_id':p.get('response_id'),'usage':p.get('usage')})
 if r.get('type')=='response_item' and p.get('type')=='custom_tool_call_output' and p.get('call_id') in calls:
  row=calls.pop(p['call_id']);row['output_timestamp']=r.get('timestamp')
p=pathlib.Path('/var/tmp/agent-interface-integrated-main/results-local/primary-roi-feedback-01')
record={'source':'local Codex usage records, bounded16MiB tail; private conversation excluded','association':'Usage record occurs after tool request and before matching tool output by call_id; ordinal association, not provider-attested foreign key. Whole response context, not SDK call or image cost.','dollars':None,'calls':selected}
(p/'model-usage-projection.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'selected':len(selected),'unique_contexts':list({json.dumps(x['local_context'],sort_keys=True) for x in selected}),'usage_records_per_call':sorted(set(len(x['usage_records_before_output']) for x in selected))}))


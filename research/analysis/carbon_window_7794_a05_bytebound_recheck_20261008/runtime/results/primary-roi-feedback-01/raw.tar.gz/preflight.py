import pathlib,subprocess,json
p=pathlib.Path(__file__).resolve().parent;rows=[]
for route in ('full','roi'):
 for i in range(3):
  r=subprocess.run(['/usr/bin/python3','-I',str(p/'runtime.pyz'),'validate','--program',str(p/f'preflight-{route}-{i}.json')],capture_output=True,text=True)
  row={'route':route,'pattern':i,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr};rows.append(row)
(p/'preflight-results.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'patterns':len(rows),'all_static_valid':all(x['exit']==0 and json.loads(x['stdout'])['static_valid'] for x in rows)}))
raise SystemExit(0 if all(x['exit']==0 and json.loads(x['stdout'])['static_valid'] for x in rows) else 1)

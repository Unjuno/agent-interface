import json,sys,time,tkinter as tk
from pathlib import Path
out=Path(sys.argv[1]);out.mkdir()
a=tk.Tk();a.title('Intended target A');a.geometry('400x180+80+90')
b=tk.Toplevel(a);b.title('Unrelated target B');b.geometry('400x180+550+90')
entries=[]
def log(value):
 with (out/'events.jsonl').open('a') as f:f.write(json.dumps(dict(value,monotonic_ns=time.monotonic_ns()))+'\n')
for window,role in [(a,'A'),(b,'B')]:
 tk.Label(window,text='Target '+role).place(x=20,y=10)
 entry=tk.Entry(window);entry.place(x=20,y=40,width=220,height=30);entries.append(entry)
 entry.bind('<KeyPress>',lambda event,r=role:log({'role':r,'kind':'key','char':event.char,'keysym':event.keysym}))
def transfer():
 entries[1].focus_force();a.update();log({'kind':'focus_transfer','focus':str(a.focus_get())})
transferred=False
def arm(event):
 global transferred
 log({'kind':'arm'});entries[0].focus_force()
 if not transferred:
  transferred=True;a.after(40,transfer)
entries[0].bind('<ButtonPress-1>',arm)
a.update();entries[0].focus_force();a.update()
def ready():
 a.update()
 (out/'ready.json').write_text(json.dumps({'window_id':int(a.wm_frame(),0),'content_window_id':a.winfo_id(),'entry_point':[entries[0].winfo_rootx()+100,entries[0].winfo_rooty()+15]}))
a.after(100,ready)
a.mainloop()

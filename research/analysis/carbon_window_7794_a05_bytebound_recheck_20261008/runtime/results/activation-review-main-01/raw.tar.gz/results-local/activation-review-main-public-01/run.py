import asyncio,base64,hashlib,json,os,subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parent;repo=root.parent.parent;sys.path.insert(0,str(repo))
from Xlib import display as xdisplay
from runtime.cli_v1.mcp_server import create_server
out=root/'case';out.mkdir(exist_ok=False)
processes=[];server=None;calls=[]
def require(condition,message):
 if not condition:raise ValueError(message)
def connected(name):
 try:d=xdisplay.Display(name);d.close();return True
 except Exception:return False
def wait(test):
 end=time.monotonic()+8
 while not test():
  if time.monotonic()>end:raise TimeoutError('readiness')
  time.sleep(.01)
display=next(':'+str(n) for n in range(153,190) if not connected(':'+str(n)) and not Path(f'/tmp/.X{n}-lock').exists())
env=dict(os.environ,DISPLAY=display)
async def call(tool,args):
 index=len(calls)+1;row={'index':index,'tool':tool,'arguments':args,'started_ns':time.monotonic_ns()}
 (out/f'request-{index}.json').write_text(json.dumps(row,indent=2)+'\n')
 reply=await server.call_tool(tool,args);row['ended_ns']=time.monotonic_ns();row['reply']=reply.model_dump(mode='json')
 (out/f'exchange-{index}.json').write_text(json.dumps(row,indent=2)+'\n');calls.append(row)
 meta=json.loads(next(c.text for c in reply.content if c.type=='text'))
 for image in (c for c in reply.content if c.type=='image'):
  data=base64.b64decode(image.data,validate=True);artifact=meta['source']['native']['artifact']
  require(hashlib.sha256(data).hexdigest()==artifact['sha256'] and Path(artifact['path']).read_bytes()==data,'exact returned PNG')
 return meta
async def run():
 global server
 try:
  for name,argv in [('xvfb',['Xvfb',display,'-screen','0','1280x800x24','-ac','-nolisten','tcp']),('wm',['openbox','--config-file','/etc/xdg/openbox/rc.xml'])]:
   if name=='wm':wait(lambda:connected(display))
   processes.append(subprocess.Popen(argv,env=env,stdout=(out/(name+'.stdout')).open('wb'),stderr=(out/(name+'.stderr')).open('wb')))
  time.sleep(.3)
  processes.append(subprocess.Popen(['/usr/bin/python3',str(root/'fixture.py'),str(out/'fixture')],env=env,stdout=(out/'fixture.stdout').open('wb'),stderr=(out/'fixture.stderr').open('wb')))
  wait(lambda:(out/'fixture/ready.json').exists());ready=json.loads((out/'fixture/ready.json').read_text())
  d=xdisplay.Display(display);target=d.create_resource_object('window',ready['content_window_id']).query_tree().parent.id;d.close()
  server=create_server({'app':target},str(out/'server'),display_name=display,session_mode='guarded-x11')
  observe=await call('interface_guarded_observe',{})
  await call('interface_guarded_mint',{'alias':'entry_a','source_sequence':observe['source']['sequence'],'point':ready['entry_point'],'region_size':[24,38]})
  failure=await call('interface_guarded_input',{'alias':'entry_a','offset':[12,19],'tail':[{'op':'wait_update','timeout_ms':250},{'op':'text','text':'z'}],'detail':'brief','observation_refs':True})
  require(failure['status']=='execution_failed' and failure['result']['execution']['failed_op']==5,'expected transfer stop')
  require(all(r['verified'] is True and r['keys_down']==[] and r['buttons_down']==[] for r in failure['result']['execution']['releases']),'neutral failure')
  clock=await call('interface_clock',{})
  combined=await call('interface_guarded_activate_window',{'window_id':target,'source_sequence':failure['source']['sequence'],'current_binding_revision':0,'expires_at_ns':clock['monotonic_ns']+5_000_000_000,'timeout_ms':500,'review_after_activation':True})
  require(combined['status']=='reviewed' and combined['result']['status']=='completed' and combined['session']['binding_revision']==1 and combined['session']['review_required'] is False,'combined review')
  require(combined['result']['execution']['program_emissions']==0,'activation sends no edit')
  await call('interface_guarded_mint',{'alias':'fresh_a','source_sequence':combined['source']['sequence'],'point':ready['entry_point'],'region_size':[24,38]})
  resumed=await call('interface_guarded_input',{'alias':'fresh_a','offset':[12,19],'tail':[{'op':'text','text':'z'}],'detail':'brief','observation_refs':True})
  require(resumed['status']=='completed','new input completes')
  closed=await call('interface_close',{});require(closed['status']=='closed','closed')
  time.sleep(.1)
  events=[json.loads(line) for line in (out/'fixture/events.jsonl').read_text().splitlines()]
  require([(e['role'],e['char']) for e in events if e['kind']=='key']==[('A','z')],'independent exact task effect')
  (out/'independent-effect.json').write_text(json.dumps({'events':events,'A_text':'z','B_text':''},indent=2)+'\n')
  (out/'result.json').write_text(json.dumps({'status':'PASS_PUBLIC_CONTRACT_SCOPED','calls':len(calls),'images':sum(sum(c['type']=='image' for c in r['reply']['content']) for r in calls),'source':'f358e9cd1ff93396cba62db248bb4f10acda4024','model_trial':False},indent=2)+'\n')
 finally:
  if server and (not calls or calls[-1]['tool']!='interface_close'):
   try:await call('interface_close',{})
   except Exception as error:(out/'close-error.txt').write_text(repr(error))
  for p in reversed(processes):
   if p.poll() is None:p.terminate()
   try:p.wait(timeout=3)
   except subprocess.TimeoutExpired:p.kill();p.wait()
  (out/'cleanup.json').write_text(json.dumps([{'pid':p.pid,'returncode':p.returncode} for p in processes])+'\n')
asyncio.run(run())
print((out/'result.json').read_text())

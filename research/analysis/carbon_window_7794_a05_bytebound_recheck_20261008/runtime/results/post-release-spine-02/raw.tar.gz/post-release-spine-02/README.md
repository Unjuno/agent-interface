# Guarded integration self-use, trial 02

Pinned source f2924d1ea74c17deb5b0f93da40769f574a854ba; seed 1001042; WSL 3.0.1.0 Ubuntu WSL2.

Independent scorer confirms six exact tokens once each, no duplicate/unexpected records. Primary viewed all six SAVED frames. Natural task4 old-layout refusal and post-review old-source/alias refusals dispatched no input. One read-only scope review, fresh B mint, task5/6 reuse. 28 calls, 21 presentations, source sequence78, 588 total emissions, zero additional confirmation captures, zero input replay.

HOLD: caller probe throws for expected MCP isError; primary manually presented retained reply and completed planned repair. This is not an autonomous recovery pass. Corrected future helper presents errors before throwing and preserves reply; offline retained-refusal check passes. Frozen live caller stays unchanged. Wrapper construction needed correction before live input; original spine01 STOP with all six missing is retained. Finish used documented host.close rather than nonexistent host.transport.close.

Direct-post matched arm remains pending; no efficiency, model-token/cost, human-tempo, or production-complete claim. Cleanup process exit codes [0,1,1] retained, not labeled clean.

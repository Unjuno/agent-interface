import hashlib,json,tarfile,shutil,subprocess
from pathlib import Path
repo=Path(__file__).resolve().parents[2];dest=repo/'runtime/results/post-release-spine-02';dest.mkdir(exist_ok=False)
files=[]
with tarfile.open(dest/'raw.tar.gz','x:gz') as t:
 for name in ['post-release-spine-01','post-release-spine-02']:
  root=repo/'results-local'/name
  for p in sorted(root.rglob('*')):
   if not p.is_file() or '__pycache__' in p.parts:continue
   arc=name+'/'+p.relative_to(root).as_posix();b=p.read_bytes();files.append({'path':arc,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()});t.add(p,arcname=arc,recursive=False)
b=(dest/'raw.tar.gz').read_bytes();manifest={'schema':'agent-interface/manual-spine-pair-manifest-v1','source':json.loads((repo/'results-local/post-release-spine-02/PLAN.json').read_text())['source'],'archive':{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},'files':files,'scope':'Retained local byte consistency, not authenticated semantic/model perception proof'}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2))
for src,out in [('analyze-v3.py','analyze.py'),('analysis-v3.json','analysis.json'),('model-usage-projection.json','model-usage-projection.json')]:shutil.copyfile(repo/'results-local/post-release-spine-02'/src,dest/out)
print(json.dumps({'files':len(files),'archiveBytes':len(b),'path':str(dest)}))

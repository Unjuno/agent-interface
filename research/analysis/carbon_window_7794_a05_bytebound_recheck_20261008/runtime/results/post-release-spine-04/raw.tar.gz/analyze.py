"""Audit retained primary self-use; timings are host instrumentation, not cognition."""
import base64,hashlib,json,pathlib

def require(ok,why):
    if not ok: raise ValueError(why)

def analyze(root):
    root=pathlib.Path(root)
    read=lambda p:json.loads((root/p).read_text())
    plan=read('PLAN.json')
    for path,digest in plan['hashes'].items():
        require(hashlib.sha256((root/path).read_bytes()).hexdigest()==digest,'frozen source '+path)
    result={'status':'HOLD_INTERRUPTED_GUARDED_STALE','seed':plan['seed'],'source':plan['source'],'routes':{},'model_tokens':None,'dollars':None,'human_speed_comparison':None}
    for route in plan['order']:
        directory=root/route/'host'
        requests={int(p.stem.split('-')[1]):json.loads(p.read_text()) for p in directory.glob('request-*.json')}
        replies={int(p.stem.split('-')[1]):json.loads(p.read_text()) for p in directory.glob('reply-*.json')}
        require(set(requests)==set(replies)==set(range(1,len(requests)+1)),'request/reply inventory')
        finish=read(route+'/session/finish.json')
        score=read(route+'/session/evaluation-at-close.json')
        allocation=read(route+'/session/allocation.json')
        require(allocation['source']==plan['source'] and allocation['seed']==plan['seed'],'allocation freeze')
        require(finish['inputReplay']==0 and finish['transport']=={'code':0,'signal':None},'transport terminal')
        events=[json.loads(x) for x in (directory/'host-events.jsonl').read_text().splitlines()]
        require(events[-1]['kind']=='transport_closed' and events[-1]['code']==0,'retained transport exit')
        require(not score['duplicates'] and not score['unexpected'],'independent unexpected/duplicate saves')
        require(score['exact_counts']=={f'task-{i}':int(route=='direct-post' or i<6) for i in range(1,7)},'independent exact counts')
        require(score['success']==(route=='direct-post'),'independent full success')
        images=0;inputs=0;emissions=0;refusals=[]
        feedback=[]
        for attempt in sorted(replies):
            reply=replies[attempt];req=requests[attempt]
            require(reply['tool']==req['tool'],'tool correspondence')
            texts=[x['text'] for x in reply['result']['content'] if x['type']=='text']
            meta=json.loads(texts[0])
            blocks=[x for x in reply['result']['content'] if x['type']=='image']
            if blocks:
                images+=1
                review=json.loads((directory/f'review-{attempt}.json').read_text())
                require(review['relay_id']==attempt,'primary review attempt')
                require(review['reply_sha256']==hashlib.sha256((directory/f'reply-{attempt}.json').read_bytes()).hexdigest(),'review original reply hash')
                require(review['images']==[{'mime_type':x['mimeType'],'sha256':hashlib.sha256(base64.b64decode(x['data'],validate=True)).hexdigest()} for x in blocks],'review original images')
            if req['tool']=='interface_guarded_input':
                if meta['status']=='refused':
                    require(meta['result']['input_dispatched'] is False,'refusal dispatched input')
                    refusals.append({'attempt':attempt,'guard_status':meta['result'].get('guard_checks',[{}])[0].get('status'),'error':meta['result'].get('error')})
                    continue
                require(meta['status']=='completed' and not meta['result']['recovery_required'],'guarded execution')
                execution=meta['result']['execution'];inputs+=1;emissions+=execution['program_emissions']
                if req['arguments'].get('interaction','click')=='move':
                    require(execution['program_emissions']==1,'pointer-only emission')
                    require(all(x['op']=='wait_update' for x in req['arguments']['tail']),'move input tail')
            elif req['tool']=='interface_dispatch':
                require(meta['outcome_summary']['execution_status']=='completed' and not meta['outcome_summary']['recovery_required'],'direct execution')
                execution=meta['receipt']['execution_summary'];inputs+=1;emissions+=execution['program_emissions']
            else: continue
            require(execution['releases'] and all(x['verified'] is True and not x['keys_down'] and not x['buttons_down'] for x in execution['releases']),'verified neutral release')
            feedback.append({'attempt':attempt,'sdk_feedback_ms':(reply['sdk_return_ns']-reply['sdk_entry_ns'])/1e6})
        require(requests[len(requests)]['tool']=='interface_close','public close last')
        close=json.loads(replies[len(replies)]['result']['content'][0]['text'])
        require(close['status']=='closed' and close['release']['verified'] is True and not close['release']['keys_down'] and not close['release']['buttons_down'],'neutral public close')
        if route=='guarded-local':
            require(len(requests)==43 and inputs==21 and images==26,'guarded schedule counts')
            require(finish['status']=='STOP_UNEXPECTED_STALE_TASK6' and finish['refusalAttempt']==42,'frozen stop')
            require(requests[42]['arguments']['alias']=='field_b' and refusals[-1]['guard_status']=='STALE','stale refusal')
            elapsed=(replies[42]['sdk_entry_ns']-replies[28]['sdk_entry_ns'])/1e9
            require(elapsed>300,'expired alias interval')
            result['alias_mint_to_refusal_seconds']=elapsed
        else:
            require([requests[i]['tool'] for i in sorted(requests)]==['interface_validate']*3+['interface_observe']+['interface_clock','interface_dispatch']*12+['interface_close'],'direct schedule')
            require(inputs==12 and images==13 and emissions==588,'direct execution counts')
            require(finish['status']=='VISUALLY_SAVED_SIX' and len(finish['rows'])==6,'direct primary finish')
        result['routes'][route]={'score':score,'calls':len(requests),'inputs':inputs,'model_images':images,'emissions':emissions,'refusals':refusals,'feedback':feedback,'cleanup':read(route+'/session/cleanup.json')}
    return result

if __name__=='__main__':
    import sys
    print(json.dumps(analyze(sys.argv[1] if len(sys.argv)>1 else pathlib.Path(__file__).parent),indent=2))

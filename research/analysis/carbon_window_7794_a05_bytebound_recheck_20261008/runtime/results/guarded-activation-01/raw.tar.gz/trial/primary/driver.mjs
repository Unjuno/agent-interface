import {createInstrumentedRelayClient} from './host-bundle/relay_host.mjs';
export async function open(fs,root,evidenceDirectory,sinks){
 const allocation=JSON.parse(await fs.readFile(root+'/session/allocation.json','utf8'));
 if(allocation.source!=='8be49d281101a430ec728412fe526201ff919b0f')throw Error('source mismatch');
 const linux='/var/tmp/agent-interface-integrated-main/results-local/guarded-activation-primary-01';
 const host=await createInstrumentedRelayClient({command:'wsl.exe',args:['-d','Ubuntu','-u','taka','--exec','/tmp/agent-interface-mcp-venv/bin/python',linux+'/runtime.pyz','relay','--','--targets',linux+'/session/targets.json','--output-directory',linux+'/session/server','--session-mode','guarded-x11','--display',allocation.display],evidenceDirectory,minimumEvidenceFreeBytes:128*1024*1024,reuseReviewedImages:false});
 return {host,allocation,call:(tool,args)=>host.sendPresented(tool,args,sinks),review:(attempt,reason)=>host.review(attempt,{task:'focus-recovery',phase:'primary',reason}),ack:(attempt,reason)=>host.acknowledgeText(attempt,{task:'focus-recovery',phase:'primary',reason})};
}

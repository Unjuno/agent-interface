import hashlib,json
from pathlib import Path
repo=Path('/var/tmp/agent-interface-integrated-main');out=repo/'results-local/guarded-activation-01'
original=repo/'results-local/focus-transfer-01'
fixture=(original/'fixture.py').read_text()
fixture=fixture.replace("def arm(event):\n", "transferred=False\ndef arm(event):\n global transferred\n")
fixture=fixture.replace("if len(sys.argv)<3 or sys.argv[2]!='stable':a.after(40,transfer)","if not transferred:\n  transferred=True;a.after(40,transfer)")
(out/'fixture.py').write_text(fixture)
run=(original/'run.py').read_text().replace("root=repo/'results-local/focus-transfer-01'", "root=repo/'results-local/guarded-activation-01'")
run=run.replace("wait(connected)","wait(connected)\n wm=subprocess.Popen(['openbox','--config-file','/etc/xdg/openbox/rc.xml'],env=env,stdout=(out/'wm.stdout').open('wb'),stderr=(out/'wm.stderr').open('wb'));processes.append(wm)\n time.sleep(.25)")
run=run.replace("time.sleep(.1)\n events=", """time.sleep(.1)
 source=bridge.observe()
 activation=bridge.activate_window(window_id=target,source_sequence=source['sequence'],current_binding_revision=bridge.binding_revision,expires_at_ns=time.monotonic_ns()+5_000_000_000,timeout_ms=500)
 (out/'activation.json').write_text(json.dumps(activation,indent=2)+'\\n')
 blocked=bridge.click('entry',[12,19],tail=[])
 (out/'before-review-control.json').write_text(json.dumps(blocked,indent=2)+'\\n')
 review=bridge.review_window(target)
 (out/'review.json').write_text(json.dumps(review,indent=2)+'\\n')
 stale=bridge.click('entry',[12,19],tail=[])
 (out/'after-review-control.json').write_text(json.dumps(stale,indent=2)+'\\n')
 if review['status']!='reviewed':raise ValueError('window review failed; no retry')
 bridge.mint('fresh_entry',review['observation']['sequence'],[200,145],region_size=(24,38))
 resumed=bridge.click('fresh_entry',[12,19],tail=[{'op':'text','text':'z'}])
 (out/'resumed.json').write_text(json.dumps(resumed,indent=2)+'\\n')
 time.sleep(.1)
 events=""")
(out/'run.py').write_text(run)
freeze={'base':'49ee351dff969e0cbe3911bf430f47634360228b','label':'program-driven live activation construction; not model recovery timing','case':'live-01','expectation':'initial guard stop; old alias blocked; explicit activation then review and fresh alias; A gets z only','files':{}}
for name in ['results-local/guarded-activation-01/run.py','results-local/guarded-activation-01/fixture.py','runtime/guarded_x11_v1/bridge.py','runtime/cli_v1/mcp_guarded.py']:
 freeze['files'][name]=hashlib.sha256((repo/name).read_bytes()).hexdigest()
(out/'FREEZE.json').write_text(json.dumps(freeze,indent=2)+'\n')

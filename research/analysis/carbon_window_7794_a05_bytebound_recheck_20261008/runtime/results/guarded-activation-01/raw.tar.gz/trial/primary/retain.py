import hashlib,json,shutil,subprocess,sys,tarfile,tempfile
from pathlib import Path
repo=Path('/var/tmp/agent-interface-integrated-main');primary=repo/'results-local/guarded-activation-primary-01';construction=repo/'results-local/guarded-activation-01'
out=repo/'runtime/results/guarded-activation-01';out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['audit.py','timing_reader.py']:shutil.copy2(primary/name,out/name)
checks=[]
with tempfile.TemporaryDirectory(prefix='activation-retain-') as temp:
 stage=Path(temp)/'trial';stage.mkdir()
 for name,source in [('primary',primary),('construction',construction)]:shutil.copytree(source,stage/name,ignore=shutil.ignore_patterns('__pycache__'))
 sources=stage/'sources';sources.mkdir()
 for name in ['bridge.py','mcp_guarded.py']:
  path=repo/('runtime/guarded_x11_v1' if name=='bridge.py' else 'runtime/cli_v1')/name
  shutil.copy2(path,sources/name)
 for mode in [[],['-O']]:
  label='optimized' if mode else 'normal'
  result=subprocess.run([sys.executable,*mode,str(out/'audit.py'),str(stage/'primary')],capture_output=True)
  (out/f'audit-{label}.stdout').write_bytes(result.stdout);(out/f'audit-{label}.stderr').write_bytes(result.stderr)
  if result.returncode:raise ValueError('primary audit')
  checks.append({'mode':label,'original':0})
  path=stage/'primary/session/fixture/events.jsonl';original=path.read_bytes()
  rows=[json.loads(line) for line in original.splitlines()]
  for row in rows:
   if row.get('kind')=='key':row['role']='B'
  path.write_text(''.join(json.dumps(row)+'\n' for row in rows))
  result=subprocess.run([sys.executable,*mode,str(out/'audit.py'),str(stage/'primary')],capture_output=True)
  (out/f'negative-{label}.stderr').write_bytes(result.stderr);path.write_bytes(original)
  if result.returncode==0 or b'independent effects' not in result.stderr:raise ValueError('semantic negative did not reject wrong-target event')
  checks.append({'mode':label,'wrong_target_negative':result.returncode,'reason':'independent effects'})
 manifest={p.relative_to(stage).as_posix():{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(stage.rglob('*')) if p.is_file()}
 (out/'raw-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 with tarfile.open(out/'raw.tar.gz','w:gz') as tar:tar.add(stage,arcname='trial')
 with tarfile.open(out/'raw.tar.gz') as tar:
  for name,record in manifest.items():
   data=tar.extractfile('trial/'+name).read()
   if hashlib.sha256(data).hexdigest()!=record['sha256']:raise ValueError('archive identity')
 result=json.loads((out/'audit-normal.stdout').read_text())
 result.update(verification=checks,archive_sha256=sha(out/'raw.tar.gz'),files=len(manifest),auditor_sha256=sha(out/'audit.py'),reader_sha256=sha(out/'timing_reader.py'))
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'files':len(manifest),'checks':checks}))

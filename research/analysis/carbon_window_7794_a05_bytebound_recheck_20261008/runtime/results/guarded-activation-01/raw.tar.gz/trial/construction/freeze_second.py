import hashlib,json
from pathlib import Path
repo=Path('/var/tmp/agent-interface-integrated-main');root=repo/'results-local/guarded-activation-01'
freeze=json.loads((root/'FREEZE-live-01.json').read_text());freeze['case']='live-02'
freeze['changes']='WM-managed Tk client from content parent; entry coordinates from fixture readiness; same activation implementation'
for name in freeze['files']:freeze['files'][name]=hashlib.sha256((repo/name).read_bytes()).hexdigest()
(root/'FREEZE-live-02.json').write_text(json.dumps(freeze,indent=2)+'\n')

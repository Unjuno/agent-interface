import json,subprocess,sys,time
from pathlib import Path
r=Path.cwd();sys.path[:0]=[str(r),str(r/'research/live_control'),str(r/'research/observation_gating')]
from run_native_six_task_self_use_v1 import PrivateSession
from runtime.cli_v1.x11_target_review import inspect_focused_target
from types import SimpleNamespace
from Xlib import X
out=r/'results-local/target-root-diagnosis-01';out.mkdir(exist_ok=False)
s=PrivateSession()
try:
 s._popen(['/usr/bin/python3','runtime/backends/x11_v1/fixture_app.py','--meta',str(out/'meta.json'),'--effect',str(out/'effect.json')],cwd=r)
 deadline=time.monotonic()+10
 while not (out/'meta.json').exists():
  if time.monotonic()>deadline:raise TimeoutError('fixture ready')
  time.sleep(.05)
 d=s.d;root=d.screen().root
 wid=json.loads((out/'meta.json').read_text())['window_id']
 win=d.create_resource_object('window',wid);path=[]
 for _ in range(16):
  path.append({'window_id':win.id,'title':win.get_wm_name(),'wm_class':win.get_wm_class()})
  if win.id==root.id:break
  win=win.query_tree().parent
 managed=list(map(int,root.get_full_property(d.intern_atom('_NET_CLIENT_LIST'),X.AnyPropertyType).value))
 rows=[]
 for candidate in [wid]+managed:
  try:rows.append({'configured_root':candidate,'inspection':inspect_focused_target(SimpleNamespace(d=d,root=root),candidate)})
  except Exception as e:rows.append({'configured_root':candidate,'error':repr(e)})
 (out/'result.json').write_text(json.dumps({'configured_window':wid,'ancestry':path,'managed_clients':managed,'inspections':rows,'scope':'Fresh read-only metadata diagnosis; no primary input or task trial'},indent=2)+'\n')
 print((out/'result.json').read_text())
finally:
 s.close();(out/'cleanup.json').write_text(json.dumps([{'pid':p.pid,'returncode':p.poll()} for p in s.procs],indent=2))

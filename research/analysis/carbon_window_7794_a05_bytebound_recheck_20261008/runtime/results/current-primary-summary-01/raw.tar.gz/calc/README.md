# Calc primary use: summaries and returned attempts

On main 0a69b1e27, primary controlled fresh LibreOffice Calc on private WSL/Xvfb/Openbox, seed 991389, goal A1=413 A2=382 saved as XLSX. Public persistent MCP used the archive built from the same revision. Every presentation/review used reply.attempt. Three input programs returned summary representations; target-management results retained their full contract. No full receipt lookup was needed.

Eight calls: observe, enter values, Save, inspect modal, review/select modal with capture, accept XLSX, inspect main with capture, close. Six images were reviewed. After Return plus a 100ms wait the captured image still showed the format dialog despite completed input. The primary explicitly inspected fresh state without repeating input; the dialog had closed and both values remained. Only after close did the fixture read the XLSX, independently confirming 413/382.

The final screen capture's configured target was still the old dialog; inspection evidence identified the original main window. No further input was attempted. Further input would require explicit main-window target review, rather than treating screen capture as rebinding. This mirrors the known public target contract, not a newly fixed condition.

The task used one connection, no input replay, no repair program and no presentation failure. Process cleanup is fixture shutdown, with actual child codes retained, not normal application exit. Fixed waits and completed input do not establish UI redraw or saved effect. This trial demonstrates integrated use, not natural reliability, matched latency, token/cost savings or human-tempo operation. Host timings measure callbacks and caller declarations, not model consumption or semantic understanding.

"""Audit the retained incomplete allocation, not a performance acceptance gate."""
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent
def require(ok,why):
    if not ok: raise ValueError(why)
def read(p): return json.loads((root/p).read_text())
def digest(p): return hashlib.sha256((root/p).read_bytes()).hexdigest()
manifest=read('RAW_MANIFEST.json')
for p,h in manifest['files'].items(): require(digest(p)==h,'raw digest '+p)
plan=read('PLAN.json')
for p,h in plan['hashes'].items(): require(digest(p)==h,'frozen source '+p)
require(plan['source']=='bd5b6b53d5c2f5b5d05f84efeae9290ae4fa7eba','source')
require(plan['seed']==1001055,'seed')
g='guarded-local/host-evidence/'
replies={i:read(g+f'reply-{i}.json') for i in range(1,40)}
def meta(i): return json.loads(replies[i]['result']['content'][0]['text'])
events=[json.loads(s) for s in (root/g/'host-events.jsonl').read_text().splitlines()]
send={e['attempt']:e['sequence'] for e in events if e['kind']=='send_requested'}
review={e['attempt']:e['sequence'] for e in events if e['kind']=='review_recorded'}
images=[];ordinary=[]
for i,r in replies.items():
    require(r['id']==i and r['status']=='returned','reply identity')
    require(read(g+f'request-{i}.json')['tool']==r['tool'],'request identity')
    if any(c['type']=='image' for c in r['result']['content']):
        images.append(i)
        receipt=read(g+f'review-{i}.json')
        require(receipt['reply_sha256']==digest(g+f'reply-{i}.json'),'review digest')
        require(i in review,'review event')
        # Each following input is preceded by attribution of every earlier image.
        for j in range(i+1,40):
            if replies[j]['tool']=='interface_guarded_input': require(review[i]<send[j],'review before input')
        artifact=meta(i)['source']['native']['artifact']
        p='guarded-local/session/server/'+artifact['path'].split('/server/',1)[1]
        require(digest(p)==artifact['sha256'],'original image')
    if r['tool']=='interface_guarded_input' and i!=38:
        m=meta(i); require(m['status']=='completed' and r['result']['isError'] is False,'ordinary outcome')
        releases=m['result']['execution']['releases']
        require(bool(releases) and all(x['verified'] and x['keys_down']==[] and x['buttons_down']==[] for x in releases),'neutral ordinary release')
        ordinary.append(m['result']['execution']['program_emissions'])
require(len(images)==15 and len(ordinary)==13 and sum(ordinary)==365,'retained denominator')
require(read(g+'request-38.json')['arguments']==read('controls.json')[0]['args'],'unchanged control')
m=meta(38); check=m['result']['guard_checks'][0]
require(m['status']=='refused' and m['result']['input_dispatched'] is False,'control no input')
require(check['status']=='STALE' and check['reason']=='expired_or_nonfresh_observation','actual control failure')
expiry=meta(29)['lifetime']['expires_ns']; capture=m['source']['capture_ns']
require(capture>expiry,'expiry precedes returned capture')
close=meta(39)
require(close['status']=='closed' and close['release_attempted'] and close['release']['verified'] and close['release']['keys_down']==[] and close['release']['buttons_down']==[],'public close')
require(read(g+'text-acknowledgment-39.json')['reply_sha256']==digest(g+'reply-39.json'),'close acknowledgment')
require(events[-1]['kind']=='transport_closed' and events[-1]['code']==0,'guard transport')
require(read('guarded-local/terminal.json')['state']['stopped']=='control outcome mismatch','caller STOP')
for route,count in [('guarded-local',3),('direct-post',0)]:
    a=read(route+'/session/allocation.json'); require(a['source']==plan['source'] and a['seed']==plan['seed'],'allocation pin')
    oracle=read(route+'/session/evaluation-at-close.json')
    require(oracle['record_count']==count and oracle['success'] is False and not oracle['unexpected'] and not oracle['duplicates'],'independent score')
    require(oracle['exact_counts']=={f'task-{i}':int(route=='guarded-local' and i<=3) for i in range(1,7)},'exact counts')
    require(all(p['returncode'] is not None for p in read(route+'/session/cleanup.json')),'original children terminal')
d='direct-post/host-evidence/'
require((root/d/'request-3.json').read_bytes()==b'','retained incomplete third request')
require(not (root/d/'reply-3.json').exists(),'missing third reply remains missing')
for i in [1,2]:
    require(read(d+f'request-{i}.json')['tool']=='interface_validate','static request')
    r=read(d+f'reply-{i}.json'); require(json.loads(r['result']['content'][0]['text'])['status']=='valid','static result')
t=read('direct-post/terminal.json')
require(t['caller']['stopped']=='transport or presentation failure' and 'ENOSPC' in t['host']['host_blocked'],'direct STOP')
require(t['host']['host_closed'] and t['host']['terminal']['code']==0,'direct transport terminal')
print(json.dumps({'audit':'PASS_RETAINED_FAILURE_ONLY','guarded_exact':3,'direct_exact':0,'guarded_calls':39,'guarded_programs':13,'guarded_emissions':365,'images_reviewed':15,'control_capture_after_expiry_ns':capture-expiry,'comparison_valid':False}))

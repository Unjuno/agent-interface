from pathlib import Path
import subprocess,json,os,platform
r=Path('/var/tmp/agent-interface-integrated-main');p=r/'results-local/native-ci-sparse-01';plan=json.loads((p/'PLAN.json').read_text())
workflow=(r/'.github/workflows/native-mcp-v1.yml').read_text();chunk=workflow.split('          sparse-checkout: |\n',1)[1].split('          sparse-checkout-cone-mode:',1)[0];patterns=[line.strip() for line in chunk.splitlines() if line.strip()]
if patterns!=plan['candidate_patterns'] or 'sparse-checkout-cone-mode: false' not in workflow:raise RuntimeError('workflow does not match tested patterns')
(r/'results-local/native-ci-sparse-01/final-workflow.yml').write_text(workflow)
results=[]
for label in ('baseline-v2','candidate-v2'):
 d=(p/(label+'-checkout')).resolve()
 if d.parent!=p.resolve():raise RuntimeError('worktree outside owned experiment directory')
 tracked_changed=subprocess.check_output(['git','diff','--name-only'],cwd=d,text=True).splitlines()
 untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=d).split(b'\0')
 ignored=subprocess.check_output(['git','ls-files','--others','--ignored','--exclude-standard','-z'],cwd=d).split(b'\0')
 generated=[os.fsdecode(n) for n in untracked+ignored if n]
 if tracked_changed or any('__pycache__' not in Path(n).parts or not n.endswith('.pyc') for n in generated):raise RuntimeError('preserve unexpected worktree modifications before removal')
 source=json.loads((p/(label+'-files.json')).read_text());same=all((d/f['path']).is_file() for f in source)
 record={'path':str(d),'tracked_changed':tracked_changed,'generated_cache_files':generated,'tracked_files_exist_after_tests':same}
 result=subprocess.run(['git','worktree','remove','--force',str(d)],cwd=r,capture_output=True,text=True);record.update(exit=result.returncode,stdout=result.stdout,stderr=result.stderr,exists_after=d.exists());results.append(record)
 if result.returncode:raise RuntimeError('owned worktree removal failed')
(p/'cleanup.json').write_text(json.dumps(results,indent=2)+'\n')
env={'inspection_phase':'after matched pair','kernel':platform.release(),'git':subprocess.check_output(['git','--version'],text=True).strip(),'node':subprocess.check_output(['/home/taka/.volta/bin/node','--version'],text=True).strip(),'python':subprocess.check_output(['/tmp/agent-interface-mcp-venv/bin/python','--version'],text=True).strip()}
(p/'environment.json').write_text(json.dumps(env,indent=2)+'\n');print(json.dumps({'workflow_patterns_match':True,'removed_owned_worktrees':len(results),'environment':env}))
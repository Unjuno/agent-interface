from pathlib import Path
import subprocess,json,time,hashlib,os
r=Path('/var/tmp/agent-interface-integrated-main');p=r/'results-local/native-ci-sparse-01';plan=json.loads((p/'PLAN.json').read_text());base=plan['base'];records=[]
def run(label,args,cwd,input=None):
 start=time.monotonic_ns();result=subprocess.run(args,cwd=cwd,input=input,text=True,capture_output=True)
 (p/(label+'.stdout.txt')).write_text(result.stdout);(p/(label+'.stderr.txt')).write_text(result.stderr)
 record={'args':args,'cwd':str(cwd),'exit':result.returncode,'started_ns':start,'ended_ns':time.monotonic_ns()};(p/(label+'.receipt.json')).write_text(json.dumps(record,indent=2)+'\n')
 if result.returncode:raise RuntimeError(f'{label} original child exit {result.returncode}')
 return record
for label in ('baseline-v2','candidate-v2'):
 d=p/(label+'-checkout');run(label+'-worktree',['git','-c','maintenance.auto=false','worktree','add','--no-checkout','--detach',str(d),base],r)
 mode='--cone' if label.startswith('baseline') else '--no-cone';run(label+'-init',['git','sparse-checkout','init',mode],d)
 patterns=plan['old_cone_paths'] if label.startswith('baseline') else plan['candidate_patterns'];run(label+'-set',['git','sparse-checkout','set',mode,'--stdin'],d,'\n'.join(patterns)+'\n')
 receipt=run(label+'-checkout',['git','-c','maintenance.auto=false','checkout','--detach',base],d)
 tracked=subprocess.check_output(['git','ls-files','-z'],cwd=d).split(b'\0');members=[]
 for name in tracked:
  if not name:continue
  rel=os.fsdecode(name);f=d/rel
  if f.is_file():members.append({'path':rel,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
 (p/(label+'-files.json')).write_text(json.dumps(members,indent=2)+'\n');records.append({'label':label,'files':len(members),'bytes':sum(f['bytes'] for f in members),'checkout_receipt':receipt})
 print(json.dumps(records[-1]),flush=True)
 nodecmd=['/home/taka/.volta/bin/node','--test','research/live_control/test_native_relay_client_v1.mjs','research/live_control/test_relay_host_timeline_v1.mjs','runtime/host_v1/test_relay_client.mjs','runtime/host_v1/test_relay_host.mjs']
 env=dict(os.environ);env['PATH']='/tmp/agent-interface-mcp-venv/bin:'+env['PATH']
 start=time.monotonic_ns()
 with (p/(label+'-node.stdout.log')).open('w') as so,(p/(label+'-node.stderr.log')).open('w') as se:res=subprocess.run(nodecmd,cwd=d,env=env,stdout=so,stderr=se)
 (p/(label+'-node.receipt.json')).write_text(json.dumps({'args':nodecmd,'cwd':str(d),'exit':res.returncode,'started_ns':start,'ended_ns':time.monotonic_ns()},indent=2)+'\n')
 if res.returncode:raise RuntimeError(f'{label} node tests exit {res.returncode}')
 checks=p/(label+'-native-checks');command=['python3','runtime/integration_checks/native.py','--protocol-python','/tmp/agent-interface-mcp-venv/bin/python','--output',str(checks)];start=time.monotonic_ns()
 with (p/(label+'-native.console.log')).open('w') as so:res=subprocess.run(command,cwd=d,env=env,stdout=so,stderr=subprocess.STDOUT)
 (p/(label+'-native.receipt.json')).write_text(json.dumps({'args':command,'cwd':str(d),'exit':res.returncode,'started_ns':start,'ended_ns':time.monotonic_ns()},indent=2)+'\n')
 if res.returncode:raise RuntimeError(f'{label} native tests exit {res.returncode}')
 print(label+' tests passed',flush=True)
(p/'checkout-summary.json').write_text(json.dumps(records,indent=2)+'\n')
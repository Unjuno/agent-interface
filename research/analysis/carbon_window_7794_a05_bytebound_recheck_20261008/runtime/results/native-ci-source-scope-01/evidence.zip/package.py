from pathlib import Path
import json,zipfile,hashlib,subprocess
r=Path('/var/tmp/agent-interface-integrated-main');p=r/'results-local/native-ci-sparse-01';out=r/'runtime/results/native-ci-source-scope-01';out.mkdir()
load=lambda n:json.loads((p/n).read_text())
old=load('baseline-v2-files.json');new=load('candidate-v2-files.json');before=sum(x['bytes'] for x in old);after=sum(x['bytes'] for x in new)
(p/'baseline-workflow.yml').write_bytes(subprocess.check_output(['git','show',load('PLAN.json')['base']+':.github/workflows/native-mcp-v1.yml'],cwd=r))
(p/'tested-native-runner.py').write_bytes((r/'runtime/integration_checks/native.py').read_bytes())
(p/'final-integration-guide.md').write_bytes((r/'runtime/integration_checks/README.md').read_bytes())
metrics={'schema':'agent-interface/native-ci-source-scope-v1','base':load('PLAN.json')['base'],'old_files':len(old),'new_files':len(new),'old_bytes':before,'new_bytes':after,'byte_fraction_removed':1-after/before,'candidate_subset_same_bytes':all({f['path']:f for f in old}.get(f['path'])==f for f in new),'local_environment':load('environment.json'),'node_tests_each':47,'protocol_tests_each':324,'harness_tests_each':141,'scope':'Same-commit local source/test closure; shared Git objects, no network transfer measurement or remote stability/GUI speed claim'}
(out/'metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
files=sorted(f for f in p.rglob('*') if f.is_file() and '__pycache__' not in f.parts)
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(f,f.relative_to(p).as_posix())
manifest={'archive':'evidence.zip','sha256':hashlib.sha256((out/'evidence.zip').read_bytes()).hexdigest(),'files':[{'path':f.relative_to(p).as_posix(),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files]}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'files':len(files),'archive_bytes':(out/'evidence.zip').stat().st_size,'metrics':metrics}))
import asyncio,ctypes,json,os,signal,time,hashlib,subprocess
from pathlib import Path
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
root=Path('/var/tmp/agent-interface-integrated-main')
out=root/'results-local/native-owner-lifetime-construction-01';out.mkdir(exist_ok=False)
# Reap only descendants of this isolated probe, including the adopted fixture.
if ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)!=0: raise OSError('subreaper unavailable')
helper=out/'fixture-python'
helper.write_text('''#!/usr/bin/python3
import json,os,sys,time
from pathlib import Path
from native_exchange_v1 import current_owner_identity
out=Path(sys.argv[sys.argv.index('--out')+1]);out.mkdir()
(out/'identity.json').write_text(json.dumps({'pid':os.getpid(),'parent':os.getppid(),'owner':current_owner_identity()}))
while not (out/'arm').exists(): time.sleep(.01)
(out/'owner.json').write_text(json.dumps(current_owner_identity()))
(out/'source-1.json').write_text(json.dumps({'sequence':1}))
while not (out/'stop').exists(): time.sleep(.01)
(out/'fixture-exit.json').write_text(json.dumps({'explicit_fixture_stop':True}))
''');helper.chmod(0o700)
source={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in ['research/live_control/native_mcp_v1.py','research/live_control/native_allocation_v1.py','research/live_control/native_exchange_v1.py']}
(out/'plan.json').write_text(json.dumps({'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_sha256':source,'hypothesis':'normal stdio server exit leaves managed fixture alive under current contract','scope':'construction, actual MCP/allocation classes; substitute inert harness; no GUI/input/model','formal_4124_rerun':False,'cleanup':'explicit fixture stop, adopted child waitpid; bounded exact-child rescue only'}))
fixture=out/'allocation/run';pid=None
async def wait_file(p):
 for _ in range(500):
  if p.exists():return
  await asyncio.sleep(.01)
 raise TimeoutError(str(p))
def proc(pid):
 try:
  raw=Path(f'/proc/{pid}/stat').read_text();f=raw[raw.rfind(')')+2:].split()
  return {'pid':pid,'state':f[0],'ppid':int(f[1]),'starttime':f[19]}
 except FileNotFoundError:return None
async def main():
 global pid
 params=StdioServerParameters(command='/tmp/agent-interface-mcp-venv/bin/python',args=['research/live_control/native_mcp_v1.py','--allocation-directory',str(out/'allocation'),'--app','calc','--harness-python',str(helper)],cwd=str(root),env=dict(os.environ,PYTHONPATH='.:research/live_control'))
 async with stdio_client(params) as (rd,wr):
  async with ClientSession(rd,wr) as client:
   await client.initialize()
   first=await client.call_tool('native_start',{'timeout':0});(out/'start.json').write_text(first.model_dump_json())
   await wait_file(fixture/'identity.json');identity=json.loads((fixture/'identity.json').read_text());pid=identity['pid']
   before=proc(pid);(fixture/'arm').touch()
   await wait_file(fixture/'source-1.json')
   state=await client.call_tool('native_status',{});(out/'ready.json').write_text(state.model_dump_json())
   assert json.loads(state.content[0].text)['allocation']['status']=='ready'
 after=proc(pid);server=proc(identity['parent'])
 (out/'observation.json').write_text(json.dumps({'before':before,'after':after,'server_after':server,'survived_server_exit':after is not None and after['state'] not in ['Z','X'] and after['starttime']==before['starttime']}))
 assert server is None and after and after['starttime']==before['starttime'] and after['state'] not in ['Z','X']
 print('Observed: actual MCP server exited; same managed fixture process remains live.',flush=True)
try:
 asyncio.run(main())
finally:
 if pid is None and (fixture/'identity.json').exists():pid=json.loads((fixture/'identity.json').read_text())['pid']
 if pid:
  (fixture/'stop').touch();deadline=time.monotonic()+5;reaped=None;rescue=False
  while time.monotonic()<deadline:
   try:done,status=os.waitpid(pid,os.WNOHANG)
   except ChildProcessError:done=0
   if done:reaped=os.waitstatus_to_exitcode(status);break
   time.sleep(.02)
  if reaped is None:
   identity=json.loads((fixture/'identity.json').read_text());current=proc(pid)
   if current and current['starttime']==identity['owner']['starttime']:
    rescue=True;os.kill(pid,signal.SIGKILL);_,status=os.waitpid(pid,0);reaped=os.waitstatus_to_exitcode(status)
  (out/'cleanup.json').write_text(json.dumps({'pid':pid,'reaped_exit':reaped,'rescue_used':rescue,'process_after':proc(pid)}))
  assert reaped==0 and proc(pid) is None and not rescue
  print('Cleanup: explicit fixture stop, reaped exit 0, no rescue signal.',flush=True)

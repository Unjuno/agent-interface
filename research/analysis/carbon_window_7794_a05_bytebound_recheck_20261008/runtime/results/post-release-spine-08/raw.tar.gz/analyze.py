import base64, hashlib, json, statistics
from pathlib import Path

def require(value, message):
    if not value:
        raise ValueError(message)

def read(path):
    return json.loads(Path(path).read_text())

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def metadata(reply):
    return json.loads(next(c['text'] for c in reply['result']['content'] if c['type']=='text'))

def analyze(root):
    root=Path(root); plan=read(root/'PLAN.json')
    for name, expected in plan['hashes'].items():
        require(digest(root/name)==expected, 'frozen file '+name)
    result={'source':plan['source'], 'seed':plan['seed'], 'status':'HOLD_GUARDED_INVALID_OBSERVE', 'arms':{}}
    for route,count,saved in [('guarded-local',56,4),('direct-post',29,6)]:
        arm=root/route; host=arm/'host'; session=arm/'session'
        allocation=read(session/'allocation.json')
        require(allocation['source']==plan['source'] and allocation['seed']==plan['seed'], 'allocation identity')
        goal=read(session/'goal.json')
        entries=[json.loads(line) for line in (session/'submission-history.jsonl').read_text().splitlines()]
        exact={t['task_id']:sum(r['task_id']==t['task_id'] and r['submitted_values']==[t['token']] for r in entries) for t in goal['tasks']}
        require(list(exact.values())==[int(i<saved) for i in range(6)] and len(entries)==saved, 'independent exact-once saves')
        score=read(session/'evaluation-at-close.json')
        require(score['exact_counts']==exact and score['record_count']==saved and score['success'] is (saved==6), 'independent scorer correspondence')
        require(not score['unexpected'] and not score['duplicates'], 'unexpected or duplicate saves')
        require(score['missing']==[t['task_id'] for t in goal['tasks'] if not exact[t['task_id']]], 'missing task denominator')
        events=[json.loads(line) for line in (host/'host-events.jsonl').read_text().splitlines()]
        require([e['sequence'] for e in events]==list(range(1,len(events)+1)), 'host event order')
        require(read(host/'exit.json')=={'code':0,'signal':None}, 'original transport terminal')
        require(len(list(host.glob('request-*.json')))==count and len(list(host.glob('reply-*.json')))==count, 'all launched calls retained')
        images=reviews=acks=programs=emissions=0; save_ms=[]; previous_review_sequence=0
        all_meta={}; requests={}
        for attempt in range(1,count+1):
            reply=read(host/f'reply-{attempt}.json'); request=read(host/f'request-{attempt}.json'); requests[attempt]=request
            require(reply['id']==request['id']==attempt and reply['tool']==request['tool'], 'relay identity')
            meta=metadata(reply); all_meta[attempt]=meta; sha=digest(host/f'reply-{attempt}.json')
            selected=[e for e in events if e.get('attempt')==attempt]
            require([e['kind'] for e in selected[:4]]==['send_requested','reply_available','presentation_started','presentation_callbacks_completed'], 'original presentation boundary')
            require(all(e.get('reply_sha256',sha)==sha for e in selected), 'original reply digest')
            require(selected[0]['sequence']>previous_review_sequence, 'review before following call')
            pictures=[c for c in reply['result']['content'] if c['type']=='image']; images+=len(pictures)
            if pictures:
                receipt=read(host/f'review-{attempt}.json'); reviews+=1
                require(receipt['reply_sha256']==sha, 'image review identity')
                require([r['sha256'] for r in receipt['images']]==[hashlib.sha256(base64.b64decode(p['data'])).hexdigest() for p in pictures], 'original image bytes')
                review_event=next(e for e in selected if e['kind']=='review_recorded')
                require(review_event['sequence']>selected[3]['sequence'], 'review after presentation')
                previous_review_sequence=review_event['sequence']
            ack=host/f'text-acknowledgment-{attempt}.json'
            if ack.exists():
                receipt=read(ack); acks+=1
                require(not pictures and receipt['reply_sha256']==sha and receipt.get('isError')==reply['result'].get('isError'), 'original text status attribution')
                require(selected[-1]['kind']=='text_acknowledgment_recorded', 'text acknowledgment event')
                previous_review_sequence=selected[-1]['sequence']
            execution=None
            if reply['tool']=='interface_dispatch':
                require(meta['outcome_summary']['execution_status']=='completed' and not meta['outcome_summary']['recovery_required'], 'completed direct input')
                execution=meta['receipt']['execution_summary']
            elif reply['tool']=='interface_guarded_input' and meta['status']=='completed':
                require(meta['result']['status']=='completed' and not meta['result']['recovery_required'], 'completed guarded input')
                execution=meta['result']['execution']
            if execution:
                require(execution['releases'] and all(r['verified'] is True and not r['keys_down'] and not r['buttons_down'] for r in execution['releases']), 'neutral input releases')
                programs+=1; emissions+=execution['program_emissions']
                if route=='direct-post' and attempt in [8,12,16,20,24,28]:
                    save_ms.append(selected[3]['host_monotonic_ms']-selected[0]['host_monotonic_ms'])
        close=all_meta[count]
        require(requests[count]['tool']=='interface_close' and close['status']=='closed', 'returned public close')
        require(close['release_attempted'] is True and close['release']['verified'] is True and not close['release']['keys_down'] and not close['release']['buttons_down'], 'neutral public close')
        if route=='guarded-local':
            controls=read(root/'controls.json')
            for attempt,control in zip([38,40,41],controls):
                req=requests[attempt]; reply=read(host/f'reply-{attempt}.json'); meta=all_meta[attempt]
                require(req['tool']==control['tool'] and req['arguments']==control['args'], 'exact declared control')
                require(reply['result']['isError'] is True and meta['status']=='refused' and meta['session']['binding_revision']==control['revision'], 'control refusal status')
                if control['kind']=='source':
                    require(meta['error']==control['error'] and meta['input_dispatched'] is False, 'no input on revoked source')
                else:
                    require(meta['result']['input_dispatched'] is False and 'execution' not in meta['result'], 'no hidden control input')
                    checks=meta['result']['guard_checks']
                    require(len(checks)==1 and checks[0]['stage']=='before_admission' and checks[0]['reason']==control['reason'], 'control guard reason')
            require(all_meta[55]['status']=='invalid_request' and all_meta[55]['operation_invoked'] is False and all_meta[55]['input_dispatched'] is False, 'actual failed fresh observe')
            require(requests[55]['tool']=='interface_guarded_observe' and requests[55]['arguments']=={'target':'browser'}, 'actual erroneous arguments')
            require(read(arm/'primary-terminal.json')['stop_attempt']==55, 'STOP attribution')
            expired=read(arm/'primary-expiry-checks.json')
            require(len(expired)==1 and expired[0]['clockAttempt']==54 and expired[0]['remaining_ns']<=5000000000, 'no input near expiry')
            require(requests[54]['tool']=='interface_clock' and requests[56]['tool']=='interface_close', 'no corrected retry after STOP')
            require(images==21 and reviews==21 and acks==3 and programs==17 and emissions==464, 'guarded denominator')
        else:
            require(images==13 and reviews==13 and acks==1 and programs==12 and emissions==588, 'direct denominator')
        result['arms'][route]={'calls':count,'saved':saved,'exact_counts':exact,'images':images,'image_reviews':reviews,'text_acknowledgments':acks,'programs':programs,'emissions':emissions,'save_send_to_presentation_ms':save_ms,'save_median_ms':statistics.median(save_ms) if save_ms else None,'cleanup':read(session/'cleanup.json')}
    terminals=read(root/'original-terminals.json')
    require(terminals['guarded_fixture']=={'session_id':2630,'exit_code':0} and terminals['direct_fixture']=={'session_id':43788,'exit_code':0}, 'original fixture terminals')
    return result

if __name__=='__main__':
    print(json.dumps(analyze(Path(__file__).parent),indent=2))

import hashlib,json,shutil,tempfile
from pathlib import Path
from analyze import analyze

root=Path(__file__).parent
analyze(root)
for kind in ['wrong-score','held-key','rehashed-text-error','hidden-control-input']:
    with tempfile.TemporaryDirectory() as directory:
        changed=Path(directory)/'raw';shutil.copytree(root,changed,ignore=shutil.ignore_patterns('__pycache__'))
        if kind=='wrong-score':
            path=changed/'guarded-local/session/evaluation-at-close.json';row=json.loads(path.read_text());row['success']=True;path.write_text(json.dumps(row))
        else:
            route='direct-post' if kind=='held-key' else 'guarded-local'
            attempt=29 if kind=='held-key' else (40 if kind=='rehashed-text-error' else 38)
            host=changed/route/'host';path=host/f'reply-{attempt}.json';row=json.loads(path.read_text())
            if kind=='rehashed-text-error':row['result']['isError']=False
            else:
                meta=json.loads(row['result']['content'][0]['text'])
                if kind=='held-key':meta['release']['keys_down']=['CTRL']
                else:meta['result']['input_dispatched']=True
                row['result']['content'][0]['text']=json.dumps(meta)
            path.write_text(json.dumps(row));sha=hashlib.sha256(path.read_bytes()).hexdigest()
            receipt=host/(f'review-{attempt}.json' if kind=='hidden-control-input' else f'text-acknowledgment-{attempt}.json')
            row=json.loads(receipt.read_text());row['reply_sha256']=sha
            if kind=='rehashed-text-error':row['isError']=False
            receipt.write_text(json.dumps(row));path=host/'host-events.jsonl';rows=[json.loads(x) for x in path.read_text().splitlines()]
            for row in rows:
                if row.get('attempt')==attempt and 'reply_sha256' in row:row['reply_sha256']=sha
            path.write_text(''.join(json.dumps(row)+'\n' for row in rows))
        try:analyze(changed)
        except ValueError as error:print(kind+': rejected '+str(error))
        else:raise RuntimeError('semantic negative control accepted: '+kind)
print('Original partial pair and four semantic negative controls passed')

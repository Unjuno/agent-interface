"""Research clock-only process. No input, lease, model, or clock translation."""
import json,sys,time,os
from pathlib import Path
boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
last=0
for line in sys.stdin:
 q=json.loads(line)
 if set(q)!={'id'} or type(q['id']) is not int or q['id']!=last+1:
  print(json.dumps({'status':'refused','authority':False}),flush=True);break
 last=q['id']; now=time.monotonic_ns();perf=time.perf_counter_ns()
 print(json.dumps({'id':last,'monotonic_ns':now,'perf_counter_ns':perf,'boot_id':boot,'pid':os.getpid(),'authority':False}),flush=True)
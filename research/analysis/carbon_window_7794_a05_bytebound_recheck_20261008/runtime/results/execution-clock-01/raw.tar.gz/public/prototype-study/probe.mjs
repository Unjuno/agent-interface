import {spawn,spawnSync} from 'node:child_process';
import {createInterface} from 'node:readline';
import {writeFile,appendFile} from 'node:fs/promises';
export function startClock(directory,tag) {
 const started=performance.now();
 const child=spawn('wsl.exe',['-d','Ubuntu','-u','taka','--exec','python3','/var/tmp/agent-interface-integrated-main/results-local/clock-acquisition-server-01.py'],{windowsHide:true,stdio:['pipe','pipe','pipe']});
 let next=1,pending=null,blocked=null,journal=Promise.resolve();
 const exited=new Promise(resolve=>child.once('close',(code,signal)=>{journal=journal.then(()=>writeFile(directory+'/'+tag+'-exit.json',JSON.stringify({code,signal})+'\n',{flag:'wx'}));journal.then(()=>resolve({code,signal}),e=>resolve({code,signal,journal_error:String(e)}));}));
 child.stderr.on('data',b=>{journal=journal.then(()=>appendFile(directory+'/'+tag+'-stderr.log',b));});
 const fail=e=>{blocked=String(e);if(pending)pending.reject(e);};child.on('error',fail);child.stdin.on('error',fail);
 createInterface({input:child.stdout}).on('line',line=>{ const current=pending;journal=journal.then(async()=>{await appendFile(directory+'/'+tag+'-wire.jsonl',JSON.stringify({line,received_ms:performance.now()})+'\n');if(!current)throw Error('unsolicited');const value=JSON.parse(line);if(value.id!==current.id && value.status!=='refused')throw Error('identity mismatch');current.settled=true;current.resolve({value,duration_ms:performance.now()-current.started});});journal.catch(fail);});
 return {started,child,exited,request(payload){if(blocked||child.exitCode!==null||pending&&!pending.settled)throw Error(blocked||'not available');let id=next++;payload??={id};pending={id:payload.id,started:performance.now(),settled:false};pending.promise=new Promise((resolve,reject)=>Object.assign(pending,{resolve,reject}));pending.promise.catch(()=>{});journal=journal.then(async()=>{await appendFile(directory+'/'+tag+'-requests.jsonl',JSON.stringify({payload,started_ms:pending.started})+'\n');child.stdin.write(JSON.stringify(payload)+'\n');});journal.catch(fail);return pending.promise;},wait(){return pending?.promise;},async close(){if(pending&&!pending.settled)throw Error('pending');child.stdin.end();return exited;}};
}
export async function benchmark(clock,directory) {
 const first=await clock.request();const startup_ms=performance.now()-clock.started;const rows=[];
 for(let i=0;i<20;i++) {
  let candidate;if(i%2===0)candidate=await clock.request();
  const left=await clock.request();const before=performance.now();const baseline=spawnSync('wsl.exe',['-d','Ubuntu','-u','taka','--exec','python3','-c','import time;print(time.monotonic_ns())'],{windowsHide:true,encoding:'utf8'});const baseline_ms=performance.now()-before;const right=await clock.request();
  if(i%2===1)candidate=await clock.request();
  const row={index:i,order:i%2===0?'candidate_first':'baseline_first',left,right,candidate,baseline:{stdout:baseline.stdout,stderr:baseline.stderr,status:baseline.status,duration_ms:baseline_ms},bracket:left.value.monotonic_ns<=Number(baseline.stdout.trim())&&Number(baseline.stdout.trim())<=right.value.monotonic_ns};rows.push(row);await appendFile(directory+'/rows.jsonl',JSON.stringify(row)+'\n');
  if(baseline.status!==0||!row.bracket)throw Error('first allocation stopped: baseline/bracket');
  for(const x of [left,right,candidate])if(x.value.boot_id!==first.value.boot_id||x.value.pid!==first.value.pid||x.value.authority!==false||Math.abs(x.value.perf_counter_ns-x.value.monotonic_ns)>1000000)throw Error('domain mismatch');
 }
 const median=a=>{a.sort((x,y)=>x-y);return(a[9]+a[10])/2;};const bm=median(rows.map(x=>x.baseline.duration_ms)),cm=median(rows.map(x=>x.candidate.duration_ms));const result={startup_ms,rows:rows.length,baseline_median_ms:bm,candidate_median_ms:cm,all_bracketed:rows.every(x=>x.bracket),candidate_lower:cm<bm,boot_id:first.value.boot_id,pid:first.value.pid,first};await writeFile(directory+'/summary.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});return result;
}
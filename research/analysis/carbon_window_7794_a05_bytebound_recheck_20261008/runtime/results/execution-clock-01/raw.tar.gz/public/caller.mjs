import {spawnSync} from 'node:child_process';
import {writeFile} from 'node:fs/promises';
export function createCaller(host, goal, directory, show, clockService, clockId) {
 let sequence=1,dispatchCount=0;
 const click=(x,y)=>[{op:'pointer_move',frame:'screen_physical_px',x,y},{op:'pointer_button',button:'left',down:true},{op:'pointer_button',button:'left',down:false}];
 const dispatch=async(phase,ops,region)=>{
  const started=performance.now();
  const clock=await clockService.request();
  const ended=performance.now();if(clock.value.authority_granted!==false || clock.value.lease_issued!==false || clock.value.server_instance_id!==clockId || !Number.isSafeInteger(clock.value.monotonic_ns))throw Error('clock domain/receipt mismatch');
  const program={schema:'agent-interface/program-v1',program_id:'layout-feedback-'+phase+'-'+Date.now(),source:{observation_seq:sequence,binding_revision:1},authority:{lease_id:'layout-feedback-01',expires_at_ns:clock.value.monotonic_ns+5000000000},terminal:{release_all_required:true},ops:[{op:'focus',target:'browser'},...ops,{op:'observe',target:'browser',frame:'screen_physical_px',region},{op:'release_all'}]};
  dispatchCount++;await writeFile(directory+'/author-clock-'+dispatchCount+'.json',JSON.stringify({phase,started_ms:started,ended_ms:ended,duration_ms:ended-started,clock_receipt:clock,region})+'\n',{flag:'wx'});
  const reply=await host.send('interface_dispatch',{program,current_observation_seq:sequence,current_binding_revision:1});sequence++;await show(reply);return reply;
 };
 return {navigate:()=>dispatch('navigate',[{op:'key_chord',keys:['CTRL','l']},{op:'wait_update',timeout_ms:100},{op:'text',text:goal.tasks[3].url},{op:'wait_update',timeout_ms:100},{op:'key_chord',keys:['ENTER']},{op:'wait_update',timeout_ms:200}],[0,0,1280,800]),enter:(x,y,region)=>dispatch('enter',[...click(x,y),{op:'key_chord',keys:['CTRL','a']},{op:'wait_update',timeout_ms:100},{op:'text',text:goal.tasks[3].token},{op:'wait_update',timeout_ms:100}],region),save:(x,y,region)=>dispatch('save',[...click(x,y),{op:'wait_update',timeout_ms:100}],region)};
}
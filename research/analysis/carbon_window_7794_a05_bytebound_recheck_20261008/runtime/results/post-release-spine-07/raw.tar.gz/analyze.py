import json,hashlib,statistics
from pathlib import Path

def require(value, message):
    if not value: raise ValueError(message)

def analyze(root):
    root=Path(root); plan=json.loads((root/'PLAN.json').read_text())
    for name,digest in plan['hashes'].items():
        require(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,'frozen file '+name)
    result={'source':plan['source'],'seed':plan['seed'],'status':'HOLD_GUARDED_INVALID_INTERACTION','arms':{}}
    for route,count,saved in [('guarded-local',5,0),('direct-post',29,6)]:
        arm=root/route;host=arm/'host';session=arm/'session'
        require(json.loads((session/'allocation.json').read_text())['source']==plan['source'],'allocation source')
        goal=json.loads((session/'goal.json').read_text());history=session/'submission-history.jsonl'
        entries=[json.loads(x) for x in history.read_text().splitlines()] if history.exists() else []
        exact={task['task_id']:sum(r['task_id']==task['task_id'] and r['submitted_values']==[task['token']] for r in entries) for task in goal['tasks']}
        require(sum(exact.values())==saved and len(entries)==saved,'independent exact saved values')
        require(all(v==(1 if saved else 0) for v in exact.values()),'exact-once denominator')
        score=json.loads((session/'evaluation-at-close.json').read_text())
        require(score['exact_counts']==exact and score['record_count']==saved and score['success'] is (saved==6),'independent scorer correspondence')
        require(not score['unexpected'] and not score['duplicates'],'extra or duplicate saves')
        events=[json.loads(x) for x in (host/'host-events.jsonl').read_text().splitlines()]
        require([x['sequence'] for x in events]==list(range(1,len(events)+1)),'ordered host events')
        require(json.loads((host/'exit.json').read_text())=={'code':0,'signal':None},'original relay terminal')
        require(len(list(host.glob('request-*.json')))==count and len(list(host.glob('reply-*.json')))==count,'all launched requests retained')
        images=reviews=acks=programs=emissions=0; save_ms=[]
        for attempt in range(1,count+1):
            raw=(host/f'reply-{attempt}.json').read_bytes();reply=json.loads(raw);digest=hashlib.sha256(raw).hexdigest()
            selected=[x for x in events if x.get('attempt')==attempt]
            require([x['kind'] for x in selected[:4]]==['send_requested','reply_available','presentation_started','presentation_callbacks_completed'],'presentation boundary')
            require(all(x.get('reply_sha256',digest)==digest for x in selected),'original delivery digest')
            content=reply['result']['content'];pictures=[x for x in content if x['type']=='image'];images+=len(pictures)
            receipt_path=host/f'review-{attempt}.json'
            if pictures:
                require(receipt_path.exists(),'primary image attribution')
                receipt=json.loads(receipt_path.read_text());reviews+=1
                require(receipt['reply_sha256']==digest,'image review digest')
                require(any(x['kind']=='review_recorded' for x in selected),'image review event')
            text_path=host/f'text-acknowledgment-{attempt}.json'
            if text_path.exists():
                receipt=json.loads(text_path.read_text());acks+=1
                require(not pictures and receipt['reply_sha256']==digest,'text attribution must match unchanged text-only reply')
                require(receipt.get('isError')==reply['result'].get('isError'),'text error preservation')
                require(selected[-1]['kind']=='text_acknowledgment_recorded','text ack event')
            if reply['tool']=='interface_dispatch':
                meta=json.loads(content[0]['text']);execution=meta['receipt']['execution_summary']
                require(meta['outcome_summary']['execution_status']=='completed','completed input')
                require(all(r['verified'] is True and r['keys_down']==[] and r['buttons_down']==[] for r in execution['releases']),'neutral releases')
                programs+=1;emissions+=execution['program_emissions']
                if attempt in [8,12,16,20,24,28]:save_ms.append(selected[3]['host_monotonic_ms']-selected[0]['host_monotonic_ms'])
        close=json.loads(json.loads((host/f'reply-{count}.json').read_text())['result']['content'][0]['text'])
        require(close['status']=='closed','returned public close')
        if route=='guarded-local':
            require(images==1 and reviews==1 and acks==2,'guarded review denominator')
            failed=json.loads((host/'reply-4.json').read_text())
            require(failed['result']['isError'] is True and 'input_value=\'focus\'' in failed['result']['content'][0]['text'],'actual invalid interaction refusal')
            request=json.loads((host/'request-4.json').read_text());require(request['arguments']['interaction']=='focus','actual erroneous request')
            require(json.loads((host/'request-5.json').read_text())['tool']=='interface_close','STOP permits only close after refusal')
            require(close['release_attempted'] is False,'no fabricated neutral-close proof')
        else:
            require(images==13 and reviews==13 and acks==1 and programs==12 and emissions==588,'direct execution denominator')
            require(close['release']['verified'] is True and close['release']['keys_down']==[] and close['release']['buttons_down']==[],'direct neutral close')
        result['arms'][route]={'calls':count,'exact_counts':exact,'saved':saved,'images':images,'image_reviews':reviews,'text_acknowledgments':acks,'programs':programs,'emissions':emissions,'save_send_to_presentation_ms':save_ms,'save_median_ms':statistics.median(save_ms) if save_ms else None,'cleanup':json.loads((session/'cleanup.json').read_text())}
    terminals=json.loads((root/'original-terminals.json').read_text())
    require(terminals['guarded_fixture']['exit_code']==0 and terminals['direct_fixture']['exit_code']==0,'original fixture terminals')
    return result

if __name__=='__main__':print(json.dumps(analyze(Path(__file__).parent),indent=2))

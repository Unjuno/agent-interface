import json,tempfile,shutil,hashlib
from pathlib import Path
from analyze import analyze

root=Path(__file__).parent
analyze(root)
for kind in ['wrong-score','held-key','rehashed-refusal-status']:
    with tempfile.TemporaryDirectory() as directory:
        changed=Path(directory)/'raw';shutil.copytree(root,changed,ignore=shutil.ignore_patterns('__pycache__'))
        if kind=='wrong-score':
            path=changed/'guarded-local/session/evaluation-at-close.json';row=json.loads(path.read_text());row['success']=True;path.write_text(json.dumps(row))
        elif kind=='held-key':
            path=changed/'direct-post/host/reply-29.json';row=json.loads(path.read_text());meta=json.loads(row['result']['content'][0]['text']);meta['release']['keys_down']=['CTRL'];row['result']['content'][0]['text']=json.dumps(meta);path.write_text(json.dumps(row))
        else:
            path=changed/'guarded-local/host/reply-4.json';row=json.loads(path.read_text());row['result']['isError']=False;path.write_text(json.dumps(row))
        if kind!='wrong-score':
            digest=hashlib.sha256(path.read_bytes()).hexdigest();host=path.parent;attempt=29 if kind=='held-key' else 4
            receipt=host/f'text-acknowledgment-{attempt}.json';row=json.loads(receipt.read_text());row['reply_sha256']=digest
            if kind=='rehashed-refusal-status':row['isError']=False
            receipt.write_text(json.dumps(row));events=host/'host-events.jsonl';rows=[json.loads(x) for x in events.read_text().splitlines()]
            for row in rows:
                if row.get('attempt')==attempt and 'reply_sha256' in row:row['reply_sha256']=digest
            events.write_text(''.join(json.dumps(x)+'\n' for x in rows))
        try:analyze(changed)
        except ValueError as error:print(kind+': rejected '+str(error))
        else:raise RuntimeError('negative control accepted: '+kind)
print('Original failure evidence and three semantic controls passed')

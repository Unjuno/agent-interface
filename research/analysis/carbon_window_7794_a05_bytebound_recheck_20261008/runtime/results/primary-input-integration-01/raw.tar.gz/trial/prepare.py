from pathlib import Path
import subprocess,json,hashlib,shutil
d=Path(__file__).parent;r=d.parents[1];old=r/'results-local/post-release-spine-11'
for p in ['fixture.py','controls.json']:shutil.copyfile(old/p,d/p)
caller=(old/'caller.mjs').read_text().replace('spine11','spine12').replace('post-release-spine-11','post-release-spine-12')
needle=" const goal=JSON.parse(await ctx.fs.readFile(root+'/goal.json','utf8'));"
replacement=needle+"\n const targets=JSON.parse(await ctx.fs.readFile(root+'/targets.json','utf8'));\n if(Object.keys(targets).length!==1||!Number.isSafeInteger(targets.browser)||targets.browser<1)throw Error('invalid explicit browser target registry');"
if caller.count(needle)!=1:raise ValueError('unexpected driver shape')
caller=caller.replace(needle,replacement)
caller=caller.replace("{observationArguments:{target:'browser'","{reviewWindowId:targets.browser,observationArguments:{target:'browser'")
caller=caller.replace('observe:policy.observe,review:policy.review','reviewWindow:policy.reviewWindow,observe:policy.observe,review:policy.review')
if caller.count('reviewWindowId:targets.browser')!=1 or caller.count('reviewWindow:policy.reviewWindow')!=1:raise ValueError('missing configured public helper')
(d/'caller.mjs').write_text(caller)
with (d/'build.stdout').open('w') as out,(d/'build.stderr').open('w') as err:
 code=subprocess.run(['/usr/bin/python3','runtime/distribution_v2/build.py','--root',str(r),'--out',str(d/'runtime.pyz'),'--manifest',str(d/'build-manifest.json'),'--sums',str(d/'SHA256SUMS'),'--host-directory',str(d/'host-bundle')],cwd=r,stdout=out,stderr=err).returncode
if code:raise SystemExit(code)
p=subprocess.run(['/home/taka/.volta/bin/node','--check',str(d/'caller.mjs')],capture_output=True,text=True)
(d/'driver-check.json').write_text(json.dumps({'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})+'\n')
if p.returncode:raise SystemExit(p.returncode)
plan=json.loads((old/'PLAN.json').read_text());plan['source']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();plan['seed']=1001059
plan['H']='Public positional mint and configured reviewWindow helpers support full guarded primary use, exact no-input controls and explicit fresh grounding; compare direct-post without replay.'
plan['setup']='Before host construction read actual session/targets.json: exactly one positive safe integer browser ID. Configure public reviewWindowId once. Explicit reviewWindow() at planned39 uses no arguments; source IDs and alias points remain primary choices from reviewed original images. allocation.json is not a target registry.'
plan['U']='Candidate648b9aeae; broader adoption still HOLD. Prior failures immutable. Useful-feedback recognition, semantic latency, provider tokens/cost, human tempo and WSL/Docker comparisons unmeasured.'
files=['fixture.py','caller.mjs','controls.json','runtime.pyz','build-manifest.json','SHA256SUMS']+[str(p.relative_to(d)) for p in sorted((d/'host-bundle').iterdir()) if p.is_file()]
plan['hashes']={p:hashlib.sha256((d/p).read_bytes()).hexdigest() for p in files}
with (d/'PLAN.json').open('x') as f:json.dump(plan,f,indent=2);f.write('\n')
print(json.dumps({'source':plan['source'],'seed':plan['seed'],'hashes':len(files)}))

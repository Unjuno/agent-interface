import hashlib,json,tarfile
from pathlib import Path
root=Path(__file__).resolve().parents[2]
out=root/'runtime/results/primary-input-integration-01'
out.mkdir(exist_ok=False)
trial=root/'results-local/post-release-spine-12'
def read(p):return json.loads(p.read_text())
def require(v,msg):
 if not v:raise ValueError(msg)
plan=read(trial/'PLAN.json')
for name,digest in plan['hashes'].items():
 require(hashlib.sha256((trial/name).read_bytes()).hexdigest()==digest,'frozen hash '+name)
host=trial/'guarded-local/host'
replies=[read(host/f'reply-{i}.json') for i in range(1,49)]
requests=[read(host/f'request-{i}.json') for i in range(1,49)]
def meta(i):return json.loads(next(x['text'] for x in replies[i-1]['result']['content'] if x['type']=='text'))
for i,control in zip([39,41,42],read(trial/'controls.json')):
 require(requests[i-1]['tool']==control['tool'] and requests[i-1]['arguments']==control['args'],'control request')
 m=meta(i)
 require(replies[i-1]['result']['isError'] and m['status']=='refused','control refusal')
 require(m['session']['binding_revision']==control['revision'],'control revision')
 if control['kind']=='source':require(m['error']==control['error'] and m['input_dispatched'] is False,'source control')
 else:
  g=m['result']['guard_checks'];require(len(g)==1 and g[0]['stage']=='before_admission' and g[0]['reason']==control['reason'] and m['result']['input_dispatched'] is False and 'execution' not in m['result'],'guard control')
require(meta(40)['review']['binding_revision']==1,'window helper')
require('offset' not in requests[46]['arguments'] and replies[46]['result']['isError'] is True,'failed request')
require(requests[47]['tool']=='interface_close','only close after STOP')
c=meta(48);require(c['status']=='closed' and c['release']['verified'] and c['release']['keys_down']==[] and c['release']['buttons_down']==[],'neutral close')
score=read(trial/'guarded-local/session/evaluation-at-close.json')
require(score['exact_counts']=={f'task-{i}':int(i<=3) for i in range(1,7)} and score['success'] is False,'independent score')
require(read(host/'exit.json')['code']==0,'transport terminal')
programs=[]
for i,r in enumerate(replies,1):
 try:m=meta(i)
 except (ValueError,KeyError):continue
 if r['tool']=='interface_guarded_input' and m.get('status')=='completed':
  e=m['result']['execution'];require(all(x['verified'] and not x['keys_down'] and not x['buttons_down'] for x in e['releases']),'release')
  programs.append(i)
summary={'classification':'FAILED_PRIMARY_TRIAL; not adoption evidence','source':plan['source'],'seed':plan['seed'],'returned_calls':48,'completed_program_calls':programs,'independent_score':score,'controls':[39,41,42],'window_review_call':40,'unexpected_refusal_call':47,'public_close_call':48,'direct_arm':'not launched after guarded STOP','frozen_hashes_verified':len(plan['hashes']),'transport_exit':read(host/'exit.json'),'new_helper_gui_self_use':'not yet measured'}
(out/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[]
for base,prefix in [(trial,'trial'),(Path(__file__).parent,'checks')]:
 for p in sorted(base.rglob('*')):
  if p.is_file():files.append((p,prefix+'/'+p.relative_to(base).as_posix()))
with tarfile.open(out/'raw.tar.gz','w:gz') as tar:
 for p,name in files:tar.add(p,arcname=name,recursive=False)
manifest={name:hashlib.sha256(p.read_bytes()).hexdigest() for p,name in files}
(out/'raw-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'raw.tar.gz') as tar:
 for name,digest in manifest.items():require(hashlib.sha256(tar.extractfile(name).read()).hexdigest()==digest,'archive '+name)
print(json.dumps({'retained_files':len(files),'programs':len(programs),'archive_bytes':(out/'raw.tar.gz').stat().st_size,'archive_members_verified':len(manifest)}))

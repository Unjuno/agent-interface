import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import {spawn} from 'node:child_process';
export const base='/var/tmp/agent-interface-integrated-main/results-local/capture-rgb-handoff-01';
const win=path=>'\\\\wsl.localhost\\Ubuntu'+path.replaceAll('/','\\');
export async function publish(notice, value){
  if(!notice.request_file.startsWith(base+'/')) throw Error('Foreign request');
  if(value.source_sequence!==notice.source_sequence) throw Error('Wrong source');
  const output=await new Promise((resolve,reject)=>{
    const cp=spawn('wsl.exe',['-d','Ubuntu','--exec','/usr/bin/python3','-I',base+'/runtime.pyz','publish-json','--path',notice.request_file,'--value','-'],{windowsHide:true});
    let stdout='',stderr='';
    cp.stdout.on('data',v=>stdout+=v);cp.stderr.on('data',v=>stderr+=v);
    cp.on('error',reject);cp.on('close',code=>resolve({code,stdout,stderr}));
    cp.stdin.on('error',reject);cp.stdin.end(JSON.stringify(value));
  });
  // A nonzero/ambiguous result never authorizes a second publication or action.
  if(output.code!==0) throw Error(JSON.stringify(output));
  return JSON.parse(output.stdout);
}
export async function poll(route){
 const deadline=Date.now()+10000;
 while(Date.now()<deadline){
  const lines=(await fs.readFile(win(base+'/'+route+'.console.txt'),'utf8')).split('\n');
  const line=lines.filter(x=>x.startsWith('{')).at(-1);
  if(line){
   const notice=JSON.parse(line);
   if(notice.request_file){
    let occupied=true;try{await fs.access(win(notice.request_file));}catch(e){if(e.code!=='ENOENT')throw e;occupied=false;}
    if(!occupied){
      const name=notice.needs_grounding??notice.needs_primary_review;
      const request=JSON.parse(await fs.readFile(win(base+'/'+route+'/'+name+(notice.needs_grounding?'-source.json':'-primary-review-request.json')),'utf8'));
      const source=notice.needs_grounding?request:request.source;
      const bytes=await fs.readFile(win(source.native.artifact.path));
      if(crypto.createHash('sha256').update(bytes).digest('hex')!==source.native.artifact.sha256)throw Error('Image digest mismatch');
      return {notice,bytes,summary:{route,kind:notice.needs_grounding?'grounding':'review',name,sequence:notice.source_sequence,receipt:notice.receipt_summary??null}};
    }
   }
  }
  await new Promise(resolve=>setTimeout(resolve,100));
 }
 throw Error('No new request observed: inspect the same process handle, never restart from a polling timeout');
}

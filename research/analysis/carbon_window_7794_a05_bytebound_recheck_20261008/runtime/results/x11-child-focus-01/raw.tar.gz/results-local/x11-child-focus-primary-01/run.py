import sys,asyncio,json,base64,subprocess,time,shutil
from pathlib import Path
sys.path.insert(0,'/tmp/agent-interface-mcp-venv/lib/python3.12/site-packages')
sys.path[:0]=['research/live_control','research/observation_gating']
from run_native_six_task_self_use_v1 import PrivateSession
import gui_suite as suite
from openpyxl import load_workbook
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
root=Path(__file__).resolve().parent;repo=root.parents[1]
def save(name,data): (root/name).write_text(json.dumps(data,indent=2)+'\n')
save('freeze.json',{'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'seed':991307,'app':'inkscape','session_mode':'persistent-x11','task':'move rectangle right preserving y and size; Save As saved-copy.svg; explicit close then independent SVG evaluation','limits':'construction caller supplies lease/source assertions; no automatic visual guard or model latency claim'})
async def main():
 session=PrivateSession();output=None
 try:
  goal,output,_=suite.prepare(session,'inkscape',991307,'')
  save('goal.json',goal)
  target=int(next(line.split()[0] for line in session.windows().splitlines() if output.name in line),16)
  save('targets.json',{'app':target})
  saved_copy=output.with_name('saved-copy.svg')
  context={'goal':{'move':'right, preserving y/size','save_as':str(saved_copy)},'expires_at_ns':time.monotonic_ns()+600_000_000_000,'lease_id':'private-primary-991307','source_scope':'caller-owned test assertions, not server-issued freshness'};save('context.json',context)
  params=StdioServerParameters(command='/tmp/agent-interface-mcp-venv/bin/python',args=['-m','runtime.cli_v1.mcp_server','--targets',str(root/'targets.json'),'--output-directory',str(root/'calls'),'--display',session.name,'--session-mode','persistent-x11'],cwd=str(repo))
  with (root/'server.stderr').open('w') as log:
   async with stdio_client(params,errlog=log) as (reader,writer):
    async with ClientSession(reader,writer) as client:
     await client.initialize();save('tools.json',(await client.list_tools()).model_dump(mode='json'))
     async def call(label,name,args):
      save(label+'-request.json',{'tool':name,'arguments':args});start=time.monotonic_ns()
      reply=await client.call_tool(name,args);save(label+'-timing.json',{'start_ns':start,'end_ns':time.monotonic_ns()});save(label+'-response.json',reply.model_dump(mode='json'))
      row=json.loads(reply.content[0].text);save(label+'-metadata.json',row);image=None
      for block in reply.content:
       if block.type=='image':
        image=str(root/(label+'.png'));Path(image).write_bytes(base64.b64decode(block.data))
      print(json.dumps({'label':label,'image':image,'isError':reply.isError,'session':row.get('session'),'outcome':row.get('outcome_summary'),'status':row.get('status'),'call_id':row.get('call_id'),'metadata_file':str(root/(label+'-metadata.json'))}),flush=True)
     print(json.dumps({'context':context}),flush=True)
     await call('initial','interface_observe',{'target':'app','frame':'screen_physical_px','region':[0,0,1280,800]})
     for n in range(1,21):
      decision=root/f'decision-{n}.json';deadline=time.monotonic()+300
      while not decision.exists() and not (root/'finish').exists():
       if time.monotonic()>deadline: raise RuntimeError('primary decision timeout')
       await asyncio.sleep(.05)
      if (root/'finish').exists():break
      d=json.loads(decision.read_text());await call(f'action-{n}',d['tool'],d['arguments'])
  shutil.copy2(output,root/'original.svg')
  if saved_copy.exists(): shutil.copy2(saved_copy,root/'saved-copy.svg')
  evaluation=suite.evaluate('inkscape',saved_copy,goal);save('evaluation.json',evaluation);print(json.dumps({'evaluation':evaluation}),flush=True)
 finally:
  session.close();save('fixture-cleanup.json',{'session_close_returned':True})
asyncio.run(main())

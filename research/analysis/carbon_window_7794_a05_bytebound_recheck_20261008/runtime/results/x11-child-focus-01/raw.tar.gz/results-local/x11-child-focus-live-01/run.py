import sys,json,time,hashlib,subprocess,importlib.util
from pathlib import Path
sys.path[:0]=['research/live_control','research/observation_gating']
from run_native_six_task_self_use_v1 import PrivateSession
import gui_suite as suite
from PIL import ImageGrab
from runtime.backends.x11_v1.backend import X11Backend
from runtime.cli_v1.x11_target_review import inspect_focused_target
root=Path(__file__).resolve().parent
baseline_source=subprocess.check_output(['git','show','4ed8196218327d0da9dd433df0dc726da7660b4a:runtime/backends/x11_v1/backend.py'])
(root/'baseline_backend.py').write_bytes(baseline_source)
spec=importlib.util.spec_from_file_location('runtime.backends.x11_v1.focus_baseline',root/'baseline_backend.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
freeze={'candidate':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'baseline':'4ed8196218327d0da9dd433df0dc726da7660b4a','baseline_backend_sha256':hashlib.sha256(baseline_source).hexdigest(),'seed':991306,'order':['inkscape/baseline','inkscape/candidate','calc/baseline','calc/candidate'],'scope':'ordinary private app focus construction; no task correctness, model or timing-ranking experiment','checks':['record focused native ID before/after focus on already selected modal','main client remains distinct from modal; focus verification must refuse if modal retains focus'],'fixture':'fresh Xvfb/Openbox/app per case; same core imports; baseline backend exact source module, candidate normal import'}
(root/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
rows=[]
for app in ('inkscape','calc'):
 for route,klass in [('baseline',module.X11Backend),('candidate',X11Backend)]:
  out=root/(app+'-'+route);out.mkdir();s=PrivateSession();b=None;row={'app':app,'route':route}
  try:
   goal,output,_=suite.prepare(s,app,991306,'')
   main=int(next(line.split()[0] for line in s.windows().splitlines() if output.name in line),16)
   b=klass(s.name,{'main':main})
   b.focus('main')
   if app=='calc':b.text('11');b.key_chord(['Return'])
   b.key_chord(['CTRL','SHIFT','s'] if app=='inkscape' else ['CTRL','s']);b.release_all()
   title='Select file to save to' if app=='inkscape' else 'Confirm File Format'
   s.wait_window(title,10)
   evidence=inspect_focused_target(b,main)
   b.targets['modal']=b.d.create_resource_object('window',evidence['window_id'])
   row['inspection']=evidence
   row['before_focus']=getattr(b.d.get_input_focus().focus,'id',None)
   ImageGrab.grab(xdisplay=s.name).save(out/'before.png')
   start=time.monotonic_ns()
   try:b.focus('modal');row['modal_focus']='returned'
   except Exception as error:row['modal_focus']=repr(error)
   row['focus_call_ns']=time.monotonic_ns()-start
   row['after_focus']=getattr(b.d.get_input_focus().focus,'id',None)
   ImageGrab.grab(xdisplay=s.name).save(out/'after.png')
   try:b.focus('main');row['main_focus']='returned'
   except Exception as error:row['main_focus']=repr(error)
   row['after_main_attempt']=getattr(b.d.get_input_focus().focus,'id',None)
  except Exception as error:row['error']=repr(error)
  finally:
   if b is not None:row['release']=b.release_all();b.close()
   s.close();row['fixture_close_returned']=True
   (out/'result.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row)
   print(json.dumps(row),flush=True)
(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
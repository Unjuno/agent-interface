import asyncio,json,os,subprocess,base64
from pathlib import Path
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
root=Path('/var/tmp/agent-interface-integrated-main');out=root/'results-local/native-explicit-stop-calc-01';out.mkdir(exist_ok=False)
(out/'PLAN.json').write_text(json.dumps({'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'seed':991320,'case':'one real idle Calc allocation, native_stop on same MCP connection','input_calls':0,'gates':['stopping distinguished from terminal','same server stays callable','no repeated launch','tracked cleanup and exit1'],'limits':['no in-flight input','no full descendant closure','not a task success or latency trial']}))
async def main():
 params=StdioServerParameters(command='/tmp/agent-interface-mcp-venv/bin/python',args=['research/live_control/native_mcp_v1.py','--allocation-directory',str(out/'allocation'),'--app','calc','--seed','991320','--owner-lifetime','--harness-python','/usr/bin/python3'],cwd=str(root),env=dict(os.environ,PYTHONPATH='.:research/live_control'))
 async with stdio_client(params) as (rd,wr):
  async with ClientSession(rd,wr) as client:
   await client.initialize()
   async def call(label,tool,args):
    result=await client.call_tool(tool,args);(out/(label+'.json')).write_text(result.model_dump_json())
    for i,b in enumerate(result.content):
     if b.type=='image':(out/f'{label}-{i}.png').write_bytes(base64.b64decode(b.data))
    assert not result.isError,(label,result)
    return json.loads(result.content[0].text)
   ready=await call('start','native_start',{'timeout':10});assert ready['allocation']['status']=='ready'
   pid=ready['allocation']['pid']
   stopped=await call('stop','native_stop',{});assert stopped['allocation']['stop_requested'] is True
   assert stopped['allocation']['status'] in ['stopping','terminal']
   for i in range(100):
    state=await call(f'status-{i}','native_status',{})
    if state['allocation']['status']=='terminal':break
    await asyncio.sleep(.05)
   assert state['allocation']['status']=='terminal' and state['allocation']['returncode']==1
   repeated=await call('stop-again','native_stop',{});assert repeated['allocation']['pid']==pid and repeated['allocation']['status']=='terminal'
   again=await call('start-again','native_start',{'timeout':0});assert again['allocation']['pid']==pid and again['allocation']['status']=='terminal'
   listing=await client.list_tools();(out/'tools-after.json').write_text(listing.model_dump_json())
 run=out/'allocation/run';cleanup=json.loads((run/'cleanup-report.json').read_text())
 result={'owner_pid':pid,'owner_absent':not Path(f'/proc/{pid}').exists(),'tracked_absent':{str(p['pid']):not Path(f"/proc/{p['pid']}").exists() for p in cleanup['processes']},'cleanup':cleanup,'requests':list(p.name for p in run.glob('request-*.json')),'same_connection_after_stop':True,'evaluation_present':(run/'evaluation.json').exists()}
 (out/'RESULT.json').write_text(json.dumps(result,indent=2))
 assert result['owner_absent'] and all(result['tracked_absent'].values()) and not result['requests'] and not result['evaluation_present']
 print('PASS explicit stop, terminal exit1, same connection usable, repeated stop/start did not relaunch, tracked processes absent.')
asyncio.run(main())

import asyncio,ctypes,json,os,time,hashlib,subprocess,base64,signal
from pathlib import Path
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
root=Path('/var/tmp/agent-interface-integrated-main');out=root/'results-local/native-owner-lifetime-calc-kill-01';out.mkdir(exist_ok=False)
if ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)!=0:raise OSError('subreaper unavailable')
files=['native_mcp_v1.py','native_allocation_v1.py','native_exchange_v1.py','run_native_calc_self_use_v1.py','native_cleanup_v1.py']
(out/'PLAN.json').write_text(json.dumps({'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_hashes':{n:hashlib.sha256((root/'research/live_control'/n).read_bytes()).hexdigest() for n in files},'case':'one actual managed Calc idle boundary; SIGKILL of exact owned MCP server while Calc waits, opt-in owner lifetime','seed':991319,'input_calls':0,'gui':True,'limits':['no task score','no held input','no arbitrary descendant containment'],'expected':'owner EOF error, existing cleanup, child exit1 reaped; no external rescue before scoring'}))
def proc(pid):
 try:
  raw=Path(f'/proc/{pid}/stat').read_text();f=raw[raw.rfind(')')+2:].split();return {'pid':pid,'state':f[0],'ppid':int(f[1]),'starttime':f[19]}
 except FileNotFoundError:return None
async def main():
 params=StdioServerParameters(command='/tmp/agent-interface-mcp-venv/bin/python',args=['research/live_control/native_mcp_v1.py','--allocation-directory',str(out/'allocation'),'--app','calc','--seed','991319','--max-stages','8','--text-gap-ms','2','--owner-lifetime','--harness-python','/usr/bin/python3'],cwd=str(root),env=dict(os.environ,PYTHONPATH='.:research/live_control'))
 async with stdio_client(params) as (rd,wr):
  async with ClientSession(rd,wr) as client:
   await client.initialize()
   response=await client.call_tool('native_start',{'timeout':10})
   (out/'start.json').write_text(response.model_dump_json())
   data=json.loads(response.content[0].text);state=data['allocation']
   if state['status']=='starting':
    response=await client.call_tool('native_start',{'timeout':10});(out/'start-wait.json').write_text(response.model_dump_json());data=json.loads(response.content[0].text);state=data['allocation']
   assert state['status']=='ready',state
   pid=state['pid'];before=proc(pid)
   (out/'before.json').write_text(json.dumps(before))
   for idx,block in enumerate(response.content):
    if block.type=='image':(out/f'initial-{idx}.png').write_bytes(base64.b64decode(block.data))
   server_before=proc(before['ppid'])
   server_fd=os.pidfd_open(before['ppid'])
   try:
    assert proc(before['ppid'])==server_before
    (out/'server-kill.json').write_text(json.dumps({'target':server_before,'signal':'SIGKILL','mechanism':'pidfd_send_signal','input_calls':0}))
    signal.pidfd_send_signal(server_fd,signal.SIGKILL,None,0)
   finally:os.close(server_fd)
   print('Calc ready; exact owning MCP server killed via pidfd, no input submitted.',flush=True)
 ended=time.monotonic_ns();deadline=time.monotonic()+15;code=None
 while time.monotonic()<deadline:
  done,status=os.waitpid(pid,os.WNOHANG)
  if done:code=os.waitstatus_to_exitcode(status);break
  await asyncio.sleep(.02)
 after=proc(pid);run=out/'allocation/run'
 cleanup=json.loads((run/'cleanup-report.json').read_text()) if (run/'cleanup-report.json').exists() else None
 error=(run/'error.txt').read_text() if (run/'error.txt').exists() else None
 result={'owner_pid':pid,'server_after':proc(before['ppid']),'owner_after':after,'owner_exit':code,'observed_after_server_close_ms':(time.monotonic_ns()-ended)/1e6,'cleanup':cleanup,'error':error,'requests':sorted(p.name for p in run.glob('request-*.json')),'tracked_process_after':{str(p['pid']):proc(p['pid']) for p in cleanup['processes']} if cleanup else None,'external_rescue':False}
 (out/'RESULT.json').write_text(json.dumps(result,indent=2))
 assert code==1 and after is None,result
 assert cleanup['tracked_processes_terminal'] is True and 'owning server ended' in error
 assert not result['requests']
 assert all(v is None for v in result['tracked_process_after'].values())
 print('PASS actual Calc idle owner EOF; owner reaped exit1, tracked processes absent, no input/rescue.',flush=True)
asyncio.run(main())

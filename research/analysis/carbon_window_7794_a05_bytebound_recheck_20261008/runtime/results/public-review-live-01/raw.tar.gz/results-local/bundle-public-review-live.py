import json,hashlib,tarfile,subprocess
from pathlib import Path
r=Path(__file__).resolve().parents[1];out=r/'runtime/results/public-review-live-01'
paths=[]
for rel in ['results-local/calc-review-live-01','results-local/calc-review-live-02','results-local/private-x11-startup-diagnostic-01','results-local/calc-review-live-build-01','results-local/review-live-host-module-01','results-local/public-review-timing-native-01']:
 paths += list((r/rel).rglob('*'))
paths += [r/'results-local/calc-review-live-fixture.py',r/'results-local/calc-review-live-fixture-02.py',r/'results-local/public-review-timing-native-01.log',Path(__file__),r/'runtime/integration_checks/host_timing.py',r/'runtime/integration_checks/test_host_timing.py']
m={}
with tarfile.open(out/'raw.tar.gz','w:gz') as t:
 for p in sorted(paths):
  if not p.is_file():continue
  raw=p.read_bytes();name=p.relative_to(r).as_posix();m[name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};t.add(p,arcname=name)
(out/'manifest.json').write_text(json.dumps({'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'scope':'working-tree timing fix explicitly retained in archive; portable runtime source pinned separately','files':m},indent=2)+'\n')
print(len(m),(out/'raw.tar.gz').stat().st_size)

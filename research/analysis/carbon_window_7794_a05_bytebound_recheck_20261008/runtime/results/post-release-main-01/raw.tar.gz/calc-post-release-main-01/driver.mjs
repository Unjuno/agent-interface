export function deliveredAttempt(reply){
 if(reply?.status!=='returned'||!Number.isSafeInteger(reply.attempt)||reply.attempt<1)throw Error('explicit returned response required before recording review');
 return reply.attempt;
}
import {createInstrumentedRelayClient} from './host-bundle/relay_host.mjs';
export async function open(fs,root,evidenceDirectory,sinks){
 const allocation=JSON.parse(await fs.readFile(root+'/session/allocation.json','utf8'));
 if(allocation.source!=='dab6d75233c441e4d2f404b8353e34f2a6d5bfc9')throw Error('source mismatch');
 const linux='/var/tmp/agent-interface-evidence-storage-main/results-local/calc-post-release-main-01';
 const host=await createInstrumentedRelayClient({command:'wsl.exe',args:['-d','Ubuntu','-u','taka','--exec','/tmp/agent-interface-mcp-venv/bin/python',linux+'/runtime.pyz','relay','--','--targets',linux+'/session/targets.json','--output-directory',linux+'/session/server','--session-mode','persistent-x11','--display',allocation.display],evidenceDirectory,minimumEvidenceFreeBytes:128*1024*1024,reuseReviewedImages:false});
 return {host,allocation,call:(tool,args)=>host.sendPresented(tool,args,sinks),review:(reply,reason)=>host.review(deliveredAttempt(reply),{task:'calc-main-entry',phase:'primary',reason}),ack:(reply,reason)=>host.acknowledgeText(deliveredAttempt(reply),{task:'calc-main-entry',phase:'primary',reason})};
}

// Explicit caller-authorized program only. No image choice, retry, binding review,
// target selection or automatic source freshness is hidden in this helper.
export async function dispatchProgram(client,id,seq,revision,ops){
 if(!Number.isSafeInteger(seq)||!Number.isSafeInteger(revision)||!Array.isArray(ops))throw Error('explicit source and ops required');
 const frozen=JSON.parse(JSON.stringify(ops));
 const clock=await client.call('interface_clock',{});
 if(clock.status!=='returned'||clock.result.isError)throw Error('clock failure; stop');
 const sample=JSON.parse(clock.result.content.find(c=>c.type==='text').text);
 await client.ack(clock,'Same execution-host clock sample for explicitly authorized private Calc program; no clock-granted authority.');
 return client.call('interface_dispatch',{
  program:{schema:'agent-interface/program-v1',program_id:id,
   source:{observation_seq:seq,binding_revision:revision},
   authority:{lease_id:'calc-post-release-main-01',expires_at_ns:sample.monotonic_ns+30_000_000_000},
   terminal:{release_all_required:true},ops:frozen},
  current_observation_seq:seq,current_binding_revision:revision,
  inspect_after:'app',inspect_after_region:[0,0,1280,800],inspect_after_wait_ms:250,
  compact:true,report_refs:true,detail:'summary'});
}

# Post-release feedback integration candidate

This candidate addresses the result boundary in #2789 / #57: an inline observation can precede the terminal release that commits a held-input action. The public persistent X11 route now optionally captures once after verified release using the existing inspect_after inspection, an explicit screen region, and an optional caller-requested 0–1000ms settling sleep. Default behavior adds no capture or wait. No automatic retry, target selection, source refresh, binding advance, redraw detection or task-success inference is added.

**Decision: SCOPED_CANDIDATE. Mainline promotion is pending the full current-path integration comparison.** The six-task integration spine remains HOLD_INTEGRATION_INCOMPLETE; human-comparable tempo and general token/cost benefit are unmeasured. These are six arms of task-4 experiments, not a six-task benchmark PASS.

| Frozen comparison | Seed / order | Extra observation, baseline → candidate | Independent task-4 submissions | Result |
|---|---|---|---|---|
| Ordinary pointer release, no post wait | 1001036 / inline → post | 0 → 0 | exactly one in each | Correct later image; no roundtrip benefit demonstrated |
| Held Save, no post wait | 1001037 / inline → post | 1 → 1 | exactly one in each | HOLD: candidate capture suppressed by target-change check; retrospectively viewed pixels lack SAVED |
| Held Save, matched 200ms total requested sleep | 1001038 / post → inline | 1 → 0 | exactly one in each | Candidate delivered SAVED in original dispatch reply; baseline needed fresh observation |

Source revisions are d13e2fe3b99e922de8173b81dfaaebf3dafb459e for the first two comparisons and 52ac21f4ecf9360a6c8a7e253cb04069196c253a for the explicit-wait comparison. All use the primary model locally labelled gpt-6.1-sol / medium, the same fixed task family and Linux/X11 Chromium fixture. Current main through 818ebd32a changed research artifacts only, with no changes in the affected runtime/host/check paths. Archive builds read committed source and are pinned by source-file and artifact hashes.

In the last comparison both Save calls request 200ms total sleep. Baseline waits 100+100ms while holding the button, captures, then releases. Candidate holds 100ms, releases, waits 100ms, then inspects/captures. This changes both capture/wait placement and button-held duration. It is a known-family, fixed-order comparison, not an isolated causal latency result or evidence of universal 100ms suitability. Application response may require a different bound or another observation. A successful dispatch or metadata title is not interpreted as task success: the primary reviewed the actual SAVED pixels, and the independent fixture separately recorded exactly one accepted token.

The final pair has 13 baseline versus 12 candidate public calls including clocks, retained-result lookup, expired-admission control and explicit close. The candidate adds no extra observation; baseline adds one. Navigation/input/Save send-to-reply times were 483.62/251.26/278.92ms baseline and 512.12/252.35/273.95ms candidate. These are host exchange intervals, not measured semantic perception or human comparison. Full reply text for the three input dispatches was 16,694 versus 25,836 bytes (54.8% more for candidate); receipt size is a real tradeoff, not token savings. Model usage projections retain whole-context counters/cache and chronology, including later context growth; before-output records cannot include the result just returned. Actual dollar billing is unavailable. No isolated input-token saving is established.

Preserved failures include the initial caller result-envelope parsing error and disabled eval construction attempt, unobserved no-wait candidate Save pixels at original delivery, and cleanup outcomes. Ordinary baseline cleanup has -9/1/-9; ordinary candidate 0/1/0; no-wait held arms 0/1/1; final candidate 0/1/0 and baseline 0/1/1. Transport and original fixture handles all exited 0, but this does not turn nonzero child cleanup into clean success. Lookup in held and final arms was programmatically checked and not presented to the model. Earlier ordinary lookups were presented. The original six-task scorer remains false in every arm because five tasks were not requested; its missing rows are retained unchanged.

Capture/inspection failure retains the executed-input receipt and any inline image. A target recheck now retains its second metadata sample when it fails, without relaxing any review or admission rule. Expired admission, recovery-required state and unverified neutral release skip capture and settling sleep. Retained interface_results returns the same image reference and does not observe, wait or renew a review ID. Capture timestamps must follow execution end and all verified releases before a later image may be selected.

Validation: local shared protocol 334 tests and Linux harness 141 tests pass. Seven post-capture tests cover actual distinct PNG selection, no-inline programs, retained lookup, release/refusal/recovery skips, capture/target failures, explicit wait ordering and invalid pre-input requests. The portable runtime was used by the primary through the ordinary public relay for each live arm. These checks do not satisfy the full #2789 integration-spine gate.

raw.tar.gz and manifest.json retain 405 files at initial packaging, including requests/replies, raw reports, PNGs, caller code, fixture code, timing/review/close records, failed results, local check logs and actual model usage projections. Run python3 runtime/results/post-release-feedback-01/verify.py to verify byte integrity and recorded ordering/scoring. The standalone verifier never connects to an application or replays inputs. It uses explicit checks that remain active under python -O; archive corruption and missing manifest-member controls must reject. Manifest consistency is not authenticated provenance, and caller-declared image review is not an independent semantic evaluator.

The additive timing-boundaries.json projects the original final-pair host events.
From Save send to useful image presentation callback: candidate 276.21ms, baseline
11,000.27ms (the baseline includes the decision to request a fresh observation).
From Save send to recorded completion review: candidate 31,658.34ms, baseline
21,808.98ms. Thus fewer observations and earlier useful delivery did **not**
establish a faster completion-review endpoint in this run. Callback completion
is delivery, and review receipt is caller-declared attribution; neither is an
independent perception clock. The candidate close helper was authored between
delivery and review; tool scheduling, model context and code authoring confound
that gap. Preserve these full intervals rather than reporting only the smaller
transport interval. Pre-authored callers and matched presentation are needed
for the next full-path comparison.

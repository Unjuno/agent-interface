from pathlib import Path
import subprocess,json,sys
r=Path(__file__).parent;repo=r.parents[1]
mode=sys.argv[1]
node='/home/taka/.volta/bin/node'
if mode=='red':checks={'red':[node,'--test',str(repo/'runtime/host_v1/test_primary_window_review.mjs')]}
else:checks={'node':[node,'--test',str(repo/'research/live_control/test_native_relay_client_v1.mjs'),str(repo/'research/live_control/test_relay_host_timeline_v1.mjs'),*map(str,sorted((repo/'runtime/host_v1').glob('test_*.mjs')))],'native':['/tmp/agent-interface-mcp-venv/bin/python',str(repo/'runtime/integration_checks/native.py'),'--output',str(r/'native')]}
rows={}
for name,cmd in checks.items():
 with (r/(name+'.stdout')).open('w') as out,(r/(name+'.stderr')).open('w') as err:code=subprocess.run(cmd,cwd=repo,stdout=out,stderr=err).returncode
 rows[name]={'command':cmd,'exit_code':code};(r/(mode+'-checks.json')).write_text(json.dumps(rows,indent=2)+'\n');print(name,code,flush=True)
 if code and mode!='red':raise SystemExit(code)

from pathlib import Path
import subprocess,json,hashlib,shutil
d=Path(__file__).parent;r=d.parents[1];old=r/'results-local/post-release-spine-10'
for p in ['fixture.py','controls.json']:shutil.copyfile(old/p,d/p)
caller=(old/'caller.mjs').read_text().replace('spine10','spine11').replace('post-release-spine-10','post-release-spine-11')
caller=caller.replace("mint:async args=>{const r=await call('interface_guarded_mint',args);const m=meta(r);if(m.status==='minted')refs.set(args.alias,{args:structuredClone(args),lifetime:m.lifetime});return r;},", "mint:async(alias,sourceSequence,point,regionSize)=>{const r=await policy.mint(alias,sourceSequence,point,regionSize);const m=meta(r);if(m.status==='minted')refs.set(alias,{lifetime:m.lifetime});return r;},")
(d/'caller.mjs').write_text(caller)
with (d/'build.stdout').open('w') as out,(d/'build.stderr').open('w') as err:
 code=subprocess.run(['/usr/bin/python3','runtime/distribution_v2/build.py','--root',str(r),'--out',str(d/'runtime.pyz'),'--manifest',str(d/'build-manifest.json'),'--sums',str(d/'SHA256SUMS'),'--host-directory',str(d/'host-bundle')],cwd=r,stdout=out,stderr=err).returncode
if code:raise SystemExit(code)
p=subprocess.run(['/home/taka/.volta/bin/node','--check',str(d/'caller.mjs')],capture_output=True,text=True)
(d/'driver-check.json').write_text(json.dumps({'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})+'\n')
if p.returncode:raise SystemExit(p.returncode)
plan=json.loads((old/'PLAN.json').read_text());plan['source']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();plan['seed']=1001058
plan['H']='Public primary positional mint helper supports complete guarded use with exact no-input controls, explicit original-image review and fresh grounding; compare direct-post without replay.'
plan['U']='Candidate290a88b00; full adoption still HOLD. Prior failed pairs remain immutable. Useful-feedback recognition, semantic-completion latency, actual provider tokens/cost and human or WSL/Docker comparisons unmeasured.'
files=['fixture.py','caller.mjs','controls.json','runtime.pyz','build-manifest.json','SHA256SUMS']+[str(p.relative_to(d)) for p in sorted((d/'host-bundle').iterdir()) if p.is_file()]
plan['hashes']={p:hashlib.sha256((d/p).read_bytes()).hexdigest() for p in files}
with (d/'PLAN.json').open('x') as f:json.dump(plan,f,indent=2);f.write('\n')
print(json.dumps({'source':plan['source'],'seed':plan['seed'],'hashes':len(files)}))

import hashlib,json,base64
from pathlib import Path
r=Path(__file__).parent
def load(p):return json.loads((r/p).read_text())
def need(v,msg):
 if not v:raise ValueError(msg)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in load('RAW_MANIFEST.json')['files'].items():need(digest(r/p)==h,'raw hash '+p)
for p,h in load('spine11/PLAN.json')['hashes'].items():need(digest(r/'spine11'/p)==h,'frozen source '+p)
host=r/'spine11/guarded-local/host'
need(len(list(host.glob('request-*.json')))==39 and len(list(host.glob('reply-*.json')))==39,'exchange count')
images=inputs=emissions=0
for i in range(1,40):
 req=json.loads((host/f'request-{i}.json').read_text());rep=json.loads((host/f'reply-{i}.json').read_text());need(req['id']==i and rep['id']==i and req['tool']==rep['tool'],'sequence')
 m=json.loads(next(c['text'] for c in rep['result']['content'] if c['type']=='text'))
 blocks=[c for c in rep['result']['content'] if c['type']=='image']
 if blocks:
  images+=1;review=json.loads((host/f'review-{i}.json').read_text())
  need(review['reply_sha256']==digest(host/f'reply-{i}.json'),'review reply')
  need([hashlib.sha256(base64.b64decode(c['data'])).hexdigest() for c in blocks]==[c['sha256'] for c in review['images']],'review image')
 if req['tool']=='interface_guarded_input' and i!=38:
  inputs+=1;need(m['status']=='completed' and not rep['result']['isError'],'input')
  emissions+=m['result']['execution']['program_emissions']
  need(all(x['verified'] and not x['keys_down'] and not x['buttons_down'] for x in m['result']['execution']['releases']),'neutral input')
 if i==38:
  need(rep['result']['isError'] and m['status']=='refused' and not m['result']['input_dispatched'] and 'execution' not in m['result'],'control no input')
  need(m['result']['guard_checks'][0]['reason']=='region_pixels_missing' and m['session']['binding_revision']==0,'control reason')
 if i==39:need(req['tool']=='interface_close' and m['release']['verified'] and not m['release']['keys_down'] and not m['release']['buttons_down'],'close')
need((images,inputs,emissions)==(15,13,365),'actual counts')
score=load('spine11/guarded-local/session/evaluation-at-close.json')
need(score['exact_counts']=={'task-'+str(i):int(i<=3) for i in range(1,7)},'exact counts')
need(score['record_count']==3 and not score['success'] and not score['duplicates'] and not score['unexpected'],'score scope')
terminal=load('spine11/guarded-local/caller-terminal.json')
need(terminal['state']['stopped']=='transport or presentation failure' and terminal['transport']=={'code':0,'signal':None},'terminal')
need((host/'text-acknowledgment-39.json').is_file(),'ack close')
need(all(c['returncode'] is not None for c in load('spine11/guarded-local/session/cleanup.json')),'fixture terminal')
need(load('red-checks.json')['red']['exit_code']==1,'red')
need(all(v['exit_code']==0 for v in load('green-checks.json').values()),'green')
print('PASS_RETAINED_FAILURE_AND_HELPER_CONTRACT_ONLY')

import hashlib,json,tarfile
from pathlib import Path
r=Path(__file__).resolve().parents[1];out=r/'runtime/results/calc-compact-primary-01';out.mkdir(exist_ok=False)
paths=list((r/'results-local/calc-compact-primary-01').rglob('*'))
paths+=list((r/'results-local/recovery-capture-build-01').iterdir())
paths += [r/'results-local/calc-compact-primary-fixture.py',Path(__file__)]
paths += [r/'research/live_control'/n for n in ('native_mcp_relay_v1.py','native_relay_client_v1.mjs','relay_host_timeline_v1.mjs','run_native_six_task_self_use_v1.py','x11_window_manager_ready_v1.py')]
paths += [r/'research/observation_gating/gui_suite.py']
manifest={}
with tarfile.open(out/'raw.tar.gz','w:gz') as archive:
 for p in sorted(paths):
  if not p.is_file():continue
  name=p.relative_to(r).as_posix();data=p.read_bytes();manifest[name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)};archive.add(p,arcname=name)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(manifest),'archive_bytes':(out/'raw.tar.gz').stat().st_size}))

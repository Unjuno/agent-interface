import json, os, subprocess, time, traceback
from pathlib import Path
from run_native_six_task_self_use_v1 import PrivateSession, suite
out=Path('results-local/native-startup-diagnostic-02');out.mkdir(exist_ok=False)
class Diagnostic(PrivateSession):
    def _popen(self,args,**kw):
        name=Path(args[0]).name
        if name in ('Xvfb','openbox'):
            log=(out/(name+'.log')).open('w')
            kw.update(stdout=log,stderr=log)
        return super()._popen(args,**kw)
s=None
try:
    s=Diagnostic()
    (out/'session.json').write_text(json.dumps({'display':s.name,'tmp':str(s.tmp),'processes':[{'pid':p.pid,'args':p.args,'returncode':p.poll()} for p in s.procs]},indent=2))
    try: suite.prepare(s,'calc',991321,'')
    except Exception: (out/'error.txt').write_text(traceback.format_exc())
    from PIL import ImageGrab
    ImageGrab.grab(xdisplay=s.name).save(out/'timeout.png')
    started=time.monotonic()
    samples=[]
    while time.monotonic()-started<60:
        windows=s.windows(); samples.append({'elapsed_s':time.monotonic()-started,'windows':windows})
        if 'sheet.xlsx' in windows: break
        time.sleep(1)
    (out/'late-windows.json').write_text(json.dumps(samples,indent=2))
    ImageGrab.grab(xdisplay=s.name).save(out/'late.png')
    (out/'windows.txt').write_text(s.windows())
    (out/'processes.json').write_text(json.dumps([{'pid':p.pid,'args':p.args,'returncode':p.poll()} for p in s.procs],indent=2))
    for name,args in [('root',['xprop','-root']),('tree',['xwininfo','-root','-tree'])]:
        r=subprocess.run(args,env=s.env,text=True,capture_output=True,timeout=5)
        (out/(name+'.txt')).write_text(r.stdout+r.stderr)
    (out/'application.log').write_bytes((s.tmp/'application.log').read_bytes())
finally:
    if s:s.close()
print(out)
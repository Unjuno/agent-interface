# Native relay integration checkpoint

Base: 0c42e341baaf7c7954e25b903142554a9f4271f4, with local native_stop relay allowlist fix and regression test.

- All 7 relay tests pass (24.339 seconds); git diff --check passes.
- Primary assistant used persistent Node child_process -> WSL JSON-lines relay -> native MCP.
- list_tools returned six native tools, including native_stop.
- One allocation: results-local/native-node-relay-01. Native start used defaults (Calc, seed 991116, four stages, gap 0) and owner-lifetime mode.
- Initial start/status reported starting; a subsequent start waited on the SAME PID 246, then returned terminal exit 1: TimeoutError window sheet.xlsx.
- No input decisions or image review occurred. Same-response image delivery remains unverified. No task success, latency, token, or cleanup-completeness claim.
- Tracked process cleanup report says terminal for three tracked processes, but owner_exit_verified and descendants_verified remain false.
- native_stop reached the server and returned the same terminal allocation; relay stdin then closed normally.
- Registered Codex native_status still returned Transport closed after WSL reboot.
- /tmp/realapp-x-vlgr5275/application.log only reported failed javaldx launch. This does not establish the GUI timeout cause.
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

from PIL import Image
from native_handle_bridge_v1 import NativeHandleBridge, _GuardedBackend, read_window_title
from scoped_target_handle_v3 import TargetHandleStore
from runtime.backends.x11_v1.backend import X11Backend, X11BackendError


class WindowTitleTests(unittest.TestCase):
    def test_visible_utf8_fallback_when_client_name_missing(self):
        d = mock.Mock()
        d.intern_atom.side_effect = lambda name: name
        window = mock.Mock()
        window.get_full_property.side_effect = [None, SimpleNamespace(value='sheet.xlsx — Calc'.encode())]
        self.assertEqual(read_window_title(d, window), 'sheet.xlsx — Calc')
        window.get_wm_name.assert_not_called()

    def test_client_title_precedes_visible_decoration(self):
        d = mock.Mock()
        window = mock.Mock()
        window.get_full_property.return_value = SimpleNamespace(value=b'client')
        self.assertEqual(read_window_title(d, window), 'client')
        self.assertEqual(window.get_full_property.call_count, 1)

    def test_legacy_fallback_and_invalid_utf8(self):
        d = mock.Mock()
        window = mock.Mock()
        window.get_full_property.return_value = None
        window.get_wm_name.return_value = 'legacy'
        self.assertEqual(read_window_title(d, window), 'legacy')
        window.get_full_property.return_value = SimpleNamespace(value=b'\xff')
        with self.assertRaises(UnicodeDecodeError):
            read_window_title(d, window)

class NativeHandleBridgeTests(unittest.TestCase):
    def review_bridge(self, focus=20, captured_focus=20):
        bridge = object.__new__(NativeHandleBridge)
        bridge.active = None
        bridge.target = 'app'
        bridge.scope = 'previous'
        bridge.store = TargetHandleStore(bridge.scope)
        bridge.history = {7: ('old-observation', 'old-image')}
        bridge.used_aliases = {'old_target'}
        bridge.sequence = 7
        connection = mock.Mock()
        connection.get_input_focus.return_value = SimpleNamespace(focus=SimpleNamespace(id=focus))
        connection.create_resource_object.side_effect = lambda kind, wid: SimpleNamespace(id=wid)
        bridge.backend = SimpleNamespace(d=connection, targets={'app': SimpleNamespace(id=10)})
        bridge.session = SimpleNamespace(dispatch=mock.Mock())
        bridge._save = mock.Mock()
        def observe():
            bridge.sequence += 1
            observation = {'sequence': bridge.sequence, 'pointer_binding': {'focus': captured_focus}}
            bridge.history[bridge.sequence] = (observation, 'new-image')
            return observation
        bridge.observe = mock.Mock(side_effect=observe)
        return bridge

    def test_public_observation_failure_retains_error_without_advancing_source(self):
        bridge = self.review_bridge()
        bridge._binding = mock.Mock(return_value={"focus": 20})
        bridge.backend = mock.Mock()
        bridge.backend.d.screen.return_value = SimpleNamespace(
            width_in_pixels=1280, height_in_pixels=800)
        bridge.backend.observe_read_only.side_effect = OSError("capture unavailable")
        bridge.session.backend = bridge.backend
        bridge.session.recovery_required = True
        with self.assertRaisesRegex(X11BackendError, "public observation failed"):
            NativeHandleBridge.observe(bridge)
        self.assertEqual(bridge.sequence, 7)
        self.assertEqual(set(bridge.history), {7})
        self.assertTrue(bridge.session.recovery_required)
        bridge.backend.observe_read_only.assert_called_once_with(
            "app", "screen_physical_px", [0, 0, 1280, 800])
        bridge.backend.close.assert_not_called()
        bridge.session.dispatch.assert_not_called()
        report = bridge._save.call_args.args[1]
        self.assertEqual(report["status"], "observation_failed")
        self.assertFalse(report["input_dispatched"])

    def test_public_observation_keeps_binding_change_refusal(self):
        bridge = self.review_bridge()
        bridge._binding = mock.Mock(side_effect=[{"focus": 20}, {"focus": 21}])
        bridge.backend = mock.Mock()
        bridge.backend.d.screen.return_value = SimpleNamespace(
            width_in_pixels=1280, height_in_pixels=800)
        bridge.backend.observe_read_only.return_value = {"sha256": "captured"}
        bridge.session.backend = bridge.backend
        with self.assertRaisesRegex(X11BackendError, "binding changed"):
            NativeHandleBridge.observe(bridge)
        self.assertEqual(bridge.sequence, 7)
        self.assertEqual(set(bridge.history), {7})
        bridge.backend.close.assert_not_called()
        bridge.session.dispatch.assert_not_called()
        self.assertEqual(bridge._save.call_args.args[1]["status"], "returned")

    def test_public_dispatch_retains_report_and_caller_owned_session(self):
        bridge = self.review_bridge()
        bridge.binding_revision = 0
        bridge.check = mock.Mock(return_value={'point': [10, 20]})
        bridge.session.backend = mock.Mock()
        bridge.session.dispatch.return_value = {'status': 'completed'}
        row = bridge.keyboard('field', [0, 0], tail=[{'op': 'text', 'text': 'x'}])
        self.assertEqual(row['status'], 'completed')
        bridge.session.dispatch.assert_called_once()
        bridge.session.backend.close.assert_not_called()
        reports = [call.args[1] for call in bridge._save.call_args_list
                   if call.args[0].startswith('public-dispatch-')]
        self.assertEqual(len(reports), 1)
        self.assertEqual(reports[0]['schema'], 'agent-interface/runtime-dispatch-result-v1')
        self.assertIsNone(bridge.active)

    def test_public_dispatch_exception_is_retained_without_retry_or_close(self):
        bridge = self.review_bridge()
        bridge.binding_revision = 0
        bridge.check = mock.Mock(return_value={'point': [10, 20]})
        bridge.session.backend = mock.Mock()
        bridge.session.dispatch.side_effect = RuntimeError('controlled execution error')
        with self.assertRaisesRegex(RuntimeError, 'public dispatch failed'):
            bridge.keyboard('field', [0, 0], tail=[{'op': 'text', 'text': 'x'}])
        bridge.session.dispatch.assert_called_once()
        bridge.session.backend.close.assert_not_called()
        reports = [call.args[1] for call in bridge._save.call_args_list
                   if call.args[0].startswith('public-dispatch-')]
        self.assertEqual(reports[0]['status'], 'runtime_failed')
        self.assertIn('controlled execution error', reports[0]['error'])
        self.assertIsNone(bridge.active)
        self.assertIsNone(bridge.deadline)

    def test_child_focus_ancestry_is_bounded_and_does_not_grant_other_surface(self):
        bridge = self.review_bridge(focus=21, captured_focus=21)
        parent = SimpleNamespace(id=20)
        child = SimpleNamespace(id=21, query_tree=lambda: SimpleNamespace(parent=parent))
        bridge.backend.d.get_input_focus.return_value.focus = child
        self.assertTrue(bridge._focus_within_target(20))
        self.assertFalse(bridge._focus_within_target(99))
        row = bridge.review_window(20)
        self.assertEqual(row['status'], 'reviewed')
        self.assertEqual(row['observation']['pointer_binding']['focus'], 21)
        self.assertFalse(row['authority_granted'])
        child.query_tree = lambda: SimpleNamespace(parent=child)
        self.assertFalse(bridge._focus_within_target(20))

    def test_guarded_focus_preserves_validated_child_and_refuses_outsider(self):
        backend = object.__new__(_GuardedBackend)
        backend.owner = SimpleNamespace(active=('field', [1,1]), check=mock.Mock(),
                                        _focus_within_target=mock.Mock(return_value=True))
        with mock.patch.object(X11Backend, 'focus') as native_focus:
            backend.focus('app')
            native_focus.assert_not_called()
            backend.owner.check.assert_called_once_with('before_focus')
            backend.owner._focus_within_target.return_value = False
            with self.assertRaises(X11BackendError):
                backend.focus('app')
            native_focus.assert_not_called()

    def test_focused_client_uses_managed_ancestor_without_mutation_or_input(self):
        bridge = self.review_bridge()
        top = SimpleNamespace(id=30)
        child = SimpleNamespace(id=31, query_tree=lambda: SimpleNamespace(parent=top))
        bridge.backend.d.get_input_focus.return_value.focus = child
        bridge.backend.root = mock.Mock()
        bridge.backend.root.get_full_property.return_value = SimpleNamespace(format=32,value=[20,30])
        before = (bridge.scope, bridge.backend.targets['app'].id, dict(bridge.history))
        self.assertEqual(bridge.focused_client_window(),30)
        self.assertEqual((bridge.scope,bridge.backend.targets['app'].id,bridge.history),before)
        bridge.session.dispatch.assert_not_called()
        bridge.observe.assert_not_called()
        bridge._save.assert_not_called()

    def test_focused_client_missing_list_cycle_unknown_and_read_failure_stop(self):
        bridge = self.review_bridge()
        bridge.backend.root = mock.Mock()
        for value in (None, SimpleNamespace(format=8,value=[20])):
            bridge.backend.root.get_full_property.return_value = value
            self.assertIsNone(bridge.focused_client_window())
        bridge.backend.root.get_full_property.return_value = SimpleNamespace(format=32,value=[99])
        child = SimpleNamespace(id=21)
        child.query_tree=lambda: SimpleNamespace(parent=child)
        bridge.backend.d.get_input_focus.return_value.focus=child
        self.assertIsNone(bridge.focused_client_window())
        bridge.backend.d.get_input_focus.return_value.focus=0
        self.assertIsNone(bridge.focused_client_window())
        bridge.backend.root.get_full_property.side_effect=RuntimeError('unavailable')
        self.assertIsNone(bridge.focused_client_window())

    def test_window_review_does_not_clear_unverified_input_release(self):
        bridge = self.review_bridge()
        bridge.session.recovery_required = True
        self.assertEqual(bridge.review_window(20)['status'], 'reviewed')
        self.assertTrue(bridge.session.recovery_required)
        with self.assertRaisesRegex(X11BackendError, 'input recovery'):
            bridge.mint('new_target', 8, [1, 1])
        row = bridge.click('old_target', [1, 1])
        self.assertEqual(row['error'], 'INPUT_RECOVERY_REQUIRED')
        self.assertFalse(row['input_dispatched'])
        bridge.session.dispatch.assert_not_called()

    def test_window_review_revokes_old_sources_and_prevents_alias_rebinding(self):
        bridge = self.review_bridge()
        connection = bridge.backend.d
        result = bridge.review_window(20)
        self.assertEqual(result['status'], 'reviewed')
        self.assertFalse(result['authority_granted'])
        self.assertFalse(result['input_dispatched'])
        self.assertIs(bridge.backend.d, connection)
        self.assertNotEqual(bridge.scope, 'previous')
        self.assertEqual(result['previous_binding_revision'], 0)
        self.assertEqual(result['binding_revision'], 1)
        self.assertNotIn(7, bridge.history)
        with self.assertRaises(KeyError):
            bridge.mint('new_target', 7, [1, 1])
        with self.assertRaises(ValueError):
            bridge.mint('old_target', 8, [1, 1])
        self.assertEqual(bridge.store.resolve_point('old_target', [], None, None, 0)['status'], 'MISSING')
        bridge.session.dispatch.assert_not_called()

    def test_failed_window_review_blocks_input_and_mint_until_success(self):
        for focus, captured_focus in [(21, 20), (20, 21)]:
            bridge = self.review_bridge(focus, captured_focus)
            result = bridge.review_window(20)
            self.assertEqual(result['status'], 'needs_review')
            self.assertEqual(bridge.history, {})
            self.assertTrue(bridge.review_required)
            with self.assertRaises(X11BackendError):
                bridge.mint('new_target', 8, [1, 1])
            self.assertEqual(bridge.click('old_target', [1, 1])['error'], 'WINDOW_REVIEW_REQUIRED')
            bridge.session.dispatch.assert_not_called()

    def test_window_review_cannot_mutate_scope_during_input(self):
        bridge = self.review_bridge()
        bridge.active = ('old_target', [1, 1])
        with self.assertRaises(RuntimeError):
            bridge.review_window(20)
        self.assertEqual(bridge.scope, 'previous')
        self.assertIn(7, bridge.history)
        bridge.observe.assert_not_called()

    def test_window_review_capture_failure_requires_fresh_successful_review(self):
        bridge = self.review_bridge()
        normal_observe = bridge.observe.side_effect
        def fail_after_partial_observation():
            normal_observe()
            raise RuntimeError('capture delivery failed')
        bridge.observe.side_effect = fail_after_partial_observation
        failed = bridge.review_window(20)
        self.assertEqual(failed['status'], 'needs_review')
        self.assertIn('capture delivery failed', failed['error'])
        self.assertEqual(bridge.history, {})
        self.assertTrue(bridge.review_required)
        bridge.observe.side_effect = normal_observe
        recovered = bridge.review_window(20)
        self.assertEqual(recovered['status'], 'reviewed')
        self.assertFalse(bridge.review_required)
        self.assertNotEqual(failed['scope'], recovered['scope'])
        self.assertEqual(list(bridge.history), [recovered['observation']['sequence']])
        bridge.session.dispatch.assert_not_called()

    def test_feedback_title_prefers_utf8_net_name_and_falls_back_only_if_absent(self):
        bridge = object.__new__(NativeHandleBridge)
        bridge.target = 'app'
        window = mock.Mock()
        window.get_full_property.return_value = SimpleNamespace(value='菫晏ｭ俶ｸ医∩'.encode('utf-8'))
        window.get_wm_name.return_value = 'legacy'
        bridge.backend = SimpleNamespace(targets={'app': window}, d=mock.Mock())
        self.assertEqual(bridge._window_title(), '菫晏ｭ俶ｸ医∩')
        window.get_wm_name.assert_not_called()
        window.get_full_property.return_value = None
        self.assertEqual(bridge._window_title(), 'legacy')

    def feedback_bridge(self, titles, *, focus=20):
        bridge = object.__new__(NativeHandleBridge)
        bridge.active = None
        bridge.target = 'app'
        bridge._window_title = mock.Mock(side_effect=titles)
        binding = {'focus': focus, 'surface': 20, 'geometry': [0, 0, 40, 40]}
        bridge._binding = mock.Mock(return_value=binding)
        bridge._focus_within_target = mock.Mock(return_value=focus == 20)
        bridge.observe = mock.Mock(return_value={'sequence': 4, 'pointer_binding': binding})
        bridge._save = mock.Mock()
        return bridge

    def test_feedback_match_is_observed_cue_not_task_success(self):
        bridge = self.feedback_bridge(['SAVED', 'SAVED'])
        row = bridge.feedback('SAVED')
        self.assertEqual(row['status'], 'matched')
        self.assertIsNone(row['task_success'])
        self.assertFalse(row['authority_granted'])
        self.assertFalse(row['input_dispatched'])
        self.assertEqual(row['observation']['sequence'], 4)

    def test_feedback_rejection_and_timeout_are_distinct(self):
        for titles, expected in [(['REJECTED', 'REJECTED'], 'rejected'),
                                 (['READY', 'READY'], 'pending')]:
            bridge = self.feedback_bridge(titles)
            row = bridge.feedback('SAVED', rejected_titles=['REJECTED'], timeout_ms=0)
            self.assertEqual(row['status'], expected)
            self.assertIsNone(row['task_success'])

    def test_feedback_changed_title_or_focus_requires_review(self):
        for titles, focus in [(['SAVED', 'READY'], 20), (['SAVED', 'SAVED'], 21)]:
            bridge = self.feedback_bridge(titles, focus=focus)
            self.assertEqual(bridge.feedback('SAVED')['status'], 'needs_review')

    def test_feedback_capture_failure_is_retained_without_retry(self):
        bridge = self.feedback_bridge(['SAVED'])
        bridge.observe.side_effect = RuntimeError('capture failed')
        row = bridge.feedback('SAVED')
        self.assertEqual(row['status'], 'needs_review')
        self.assertIn('capture failed', row['error'])
        bridge.observe.assert_called_once()
        bridge._save.assert_called_once()

    def test_existing_store_refuses_changed_pixels_at_native_check(self):
        bridge = object.__new__(NativeHandleBridge)
        bridge.scope = "test-session"
        bridge.store = TargetHandleStore(bridge.scope)
        bridge.sequence = 2
        bridge.active = ("field", [4, 4])
        bridge.deadline = None
        bridge.checks = []
        image = Image.new("RGB", (40, 40), "white")
        for y in range(8, 16):
            for x in range(8, 16):
                image.putpixel((x, y), (0, 0, 0) if (x+y)%2 else (255, 255, 255))
        now = time.monotonic_ns()
        obs = {"sequence": 1, "capture_ns": now,
               "pointer_binding": {"focus": 20, "surface": 20, "geometry": [0, 0, 40, 40]}}
        bridge.store.mint("field", "window_content", [8, 8, 8, 8], obs, image, now)
        current = dict(obs, sequence=2)
        bridge.history = {2: (current, image)}
        bridge.observe = lambda: current
        self.assertEqual(bridge.check("before_press")["point"], [12, 12])
        changed = image.copy()
        changed.putpixel((8, 8), (100, 100, 100))
        bridge.history[2] = (current, changed)
        with self.assertRaises(X11BackendError):
            bridge.check("before_press")
        self.assertEqual(bridge.checks[-1]["status"], "MISSING")

    def test_point_change_after_move_prevents_native_press(self):
        backend = object.__new__(_GuardedBackend)
        backend.owner = SimpleNamespace(check=mock.Mock(return_value={"point": [50, 50]}), moved_point=[40, 40])
        backend.root = SimpleNamespace(query_pointer=lambda: SimpleNamespace(root_x=40, root_y=40))
        with mock.patch.object(X11Backend, "pointer_button") as press:
            with self.assertRaises(X11BackendError):
                backend.pointer_button("left", True)
            press.assert_not_called()

    def test_release_is_not_blocked_by_guard_refusal(self):
        backend = object.__new__(_GuardedBackend)
        backend.owner = SimpleNamespace(check=mock.Mock(side_effect=X11BackendError("stale")))
        with mock.patch.object(X11Backend, "pointer_button") as release:
            backend.pointer_button("left", False)
            release.assert_called_once_with("left", False)
            backend.owner.check.assert_not_called()

    def test_expired_guard_does_not_capture_or_resolve(self):
        bridge = object.__new__(NativeHandleBridge)
        bridge.active = ("field", [1, 1])
        bridge.deadline = 1
        bridge.observe = mock.Mock()
        with self.assertRaises(X11BackendError):
            bridge.check("before_press")
        bridge.observe.assert_not_called()

    def test_refusal_before_admission_never_dispatches(self):
        with tempfile.TemporaryDirectory() as tmp:
            bridge = object.__new__(NativeHandleBridge)
            bridge.out = Path(tmp)
            bridge.active = None
            bridge.check = mock.Mock(side_effect=X11BackendError("changed target"))
            bridge.session = SimpleNamespace(dispatch=mock.Mock())
            row = bridge.click("field", [1, 1])
            self.assertEqual(row["status"], "refused")
            self.assertFalse(row["input_dispatched"])
            bridge.session.dispatch.assert_not_called()
            self.assertIsNone(bridge.active)

    def test_mint_requires_explicit_retained_source(self):
        bridge = object.__new__(NativeHandleBridge)
        bridge.history = {}
        with self.assertRaises(KeyError):
            bridge.mint("field", 123, [10, 10])

    def test_keyboard_continuation_has_no_pointer_ops_and_requires_release(self):
        bridge = object.__new__(NativeHandleBridge)
        bridge.active = None
        bridge.check = mock.Mock(return_value={'point': [10, 20]})
        bridge._save = mock.Mock()
        bridge.sequence, bridge.binding_revision = 7, 2
        bridge.scope, bridge.target = 'native-x11:test', 'app'
        bridge.session = SimpleNamespace(dispatch=mock.Mock(return_value={'status': 'completed'}))
        row = bridge.keyboard('anchor', [1, 1], tail=[{'op': 'key_chord', 'keys': ['Right']}])
        program = bridge.session.dispatch.call_args.args[0]
        self.assertEqual([op['op'] for op in program['ops']], ['focus', 'key_chord', 'release_all'])
        self.assertTrue(program['terminal']['release_all_required'])
        self.assertEqual(program['source'], {'observation_seq': 7, 'binding_revision': 2})
        self.assertEqual(row['status'], 'completed')
        self.assertIsNone(bridge.active)

    def test_keyboard_refusal_does_not_fall_back_to_click(self):
        for recovery in (False, True):
            with self.subTest(recovery=recovery):
                bridge = object.__new__(NativeHandleBridge)
                bridge.active = None
                bridge.check = mock.Mock(side_effect=X11BackendError('stale anchor'))
                bridge._save = mock.Mock()
                bridge.session = SimpleNamespace(recovery_required=recovery, dispatch=mock.Mock())
                row = bridge.keyboard('old', [1, 1], tail=[{'op': 'key_chord', 'keys': ['Right']}])
                self.assertEqual(row['status'], 'refused')
                self.assertFalse(row['input_dispatched'])
                bridge.session.dispatch.assert_not_called()

    def test_keyboard_rejects_empty_or_pointer_tail_before_admission(self):
        bridge = object.__new__(NativeHandleBridge)
        bridge.active = None
        bridge.check = mock.Mock()
        for tail in ([], [{'op': 'wait_update', 'timeout_ms': 10}],
                     [{'op': 'pointer_button', 'button': 'left', 'down': True}]):
            with self.subTest(tail=tail), self.assertRaises(ValueError):
                bridge.keyboard('anchor', [1, 1], tail=tail)
        bridge.check.assert_not_called()


    def test_stale_drawable_recovery_uses_read_only_discovery_then_explicit_review(self):
        bridge = self.review_bridge(focus=31, captured_focus=31)
        def geometry(target):
            if bridge.backend.targets[target].id == 10:
                raise X11BackendError("BadDrawable: stale original drawable")
            return {"x": 4, "y": 5, "width": 80, "height": 60}

        bridge.backend.geometry = mock.Mock(side_effect=geometry)

        def observe_replacement():
            binding = bridge._binding()
            bridge.sequence += 1
            observation = {"sequence": bridge.sequence, "pointer_binding": binding}
            bridge.history[bridge.sequence] = (observation, "replacement-image")
            return observation

        bridge.observe.side_effect = observe_replacement
        bridge.backend.root = mock.Mock()
        bridge.backend.root.get_full_property.return_value = SimpleNamespace(
            format=32, value=[30])

        # The old anchor is genuinely unreadable. Recovery must not keep asking
        # its geometry while discovering the currently focused managed client.
        with self.assertRaisesRegex(X11BackendError, "BadDrawable"):
            bridge._binding()
        parent = SimpleNamespace(id=30)
        child = SimpleNamespace(
            id=31, query_tree=lambda: SimpleNamespace(parent=parent))
        bridge.backend.d.get_input_focus.return_value.focus = child
        self.assertEqual(bridge.focused_client_window(), 30)
        bridge.backend.geometry.assert_called_once()
        self.assertEqual(bridge.backend.targets["app"].id, 10)
        self.assertEqual(bridge.session.dispatch.call_count, 0)
        bridge.observe.assert_not_called()

        # Rebinding is a separate explicit caller choice. It rotates the
        # binding scope and clears the old observation/handle source.
        previous_scope = bridge.scope
        row = bridge.review_window(30)
        self.assertEqual(row["status"], "reviewed")
        self.assertFalse(row["authority_granted"])
        self.assertFalse(row["input_dispatched"])
        self.assertEqual(bridge.backend.targets["app"].id, 30)
        self.assertEqual(row["observation"]["pointer_binding"], {
            "focus": 31, "surface": 30, "geometry": [4, 5, 80, 60]})
        self.assertEqual(bridge.backend.geometry.call_count, 2)
        self.assertEqual(bridge.binding_revision, 1)
        self.assertNotEqual(bridge.scope, previous_scope)
        self.assertEqual(list(bridge.history), [8])
        with self.assertRaises(KeyError):
            bridge.mint("new_target", 7, [1, 1])
        with self.assertRaises(ValueError):
            bridge.mint("old_target", 8, [1, 1])
        self.assertEqual(
            bridge.store.resolve_point("old_target", [], None, None, 0)["status"],
            "MISSING")
        bridge.session.dispatch.assert_not_called()
        bridge.backend.geometry.assert_has_calls([mock.call("app"), mock.call("app")])


if __name__ == "__main__":
    unittest.main()

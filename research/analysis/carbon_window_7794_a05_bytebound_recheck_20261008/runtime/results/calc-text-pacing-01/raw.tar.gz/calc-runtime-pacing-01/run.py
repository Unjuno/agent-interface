import sys,json,time,random,subprocess,shutil,hashlib,statistics
from pathlib import Path
ROOT=Path('/var/tmp/agent-interface-integrated-main')
sys.path[:0]=[str(ROOT),str(ROOT/'research/real_apps_v1')]
from real_app_suite_v1 import XSession
from runtime.backends.x11_v1.backend import X11Backend
from runtime.core_v1.sequence import expand_text_gaps
from openpyxl import Workbook,load_workbook
OUT=Path(__file__).parent
def save(name,value): (OUT/name).write_text(json.dumps(value,indent=2))
seed=991313
tokens=['477','300','112233','8112200','548','478','123456','909090']
cases=[{'gap_ms':gap,'text':token} for token in tokens for gap in [0,1,2,10]]
random.Random(seed).shuffle(cases)
save('plan.json',{'seed':seed,'cases':cases,'post_return_ms':100,'scope':'backend execute + public gap compiler; no MCP/model timing','source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()})
s=XSession(); b=None
try:
 p=s.tmp/'sheet.xlsx';Workbook().save(p)
 s.spawn(['libreoffice','--norestore','--nodefault','--nolockcheck',f'-env:UserInstallation=file://{s.tmp}/lo','--calc',str(p)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 s.wait_window('sheet.xlsx',15);s.focus('sheet.xlsx');time.sleep(1)
 wid=int(next(line.split()[0] for line in s.windows().splitlines() if 'sheet.xlsx' in line),16)
 b=X11Backend(s.name,{'calc':wid})
 rows=[]
 for i,case in enumerate(cases,1):
  ops,source=expand_text_gaps([{'op':'focus','target':'calc'},{'op':'text',**case},{'op':'key_chord','keys':['Return']},{'op':'release_all'}])
  result=b.execute({'ops':ops})
  row={**case,'row':i,'execution':result,'source_map':source,'elapsed_ms':(result['ended_ns']-result['started_ns'])/1e6}
  rows.append(row);save('rows.json',rows)
  time.sleep(.1)
 b.key_chord(['CTRL','s'])
 deadline=time.monotonic()+3
 while time.monotonic()<deadline:
  if 'Confirm File Format' in s.windows(): b.key_chord(['Return']);break
  time.sleep(.05)
 time.sleep(1)
 shutil.copy2(p,OUT/'sheet.xlsx')
 book=load_workbook(OUT/'sheet.xlsx',data_only=False)
 for row in rows:
  row['actual']=str(book.active.cell(row['row'],1).value)
  row['correct']=row['actual']==row['text']
 book.close();save('rows.json',rows)
 summary=[]
 for gap in [0,1,2,10]:
  batch=[r for r in rows if r['gap_ms']==gap]
  summary.append({'gap_ms':gap,'correct':sum(r['correct'] for r in batch),'n':len(batch),'median_execution_ms':statistics.median(r['elapsed_ms'] for r in batch),'errors':[{'expected':r['text'],'actual':r['actual']} for r in batch if not r['correct']]})
 save('result.json',{'summary':summary,'release':b.release_all(),'limits':'One warm application, eight shared strings per gap, shuffled order; fixed 100ms between rows. No first useful feedback/model/whole-task timing. No default policy conclusion.'})
 print(json.dumps(summary),flush=True)
except Exception as e:
 save('failure.json',{'error':repr(e)});raise
finally:
 if b: b.close()
 s.close()
 save('cleanup.json',{'processes_stopped':all(p.poll() is not None for p in s.procs)})

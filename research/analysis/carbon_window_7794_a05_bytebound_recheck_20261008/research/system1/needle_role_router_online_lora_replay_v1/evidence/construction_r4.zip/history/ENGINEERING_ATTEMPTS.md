# Preserved construction engineering attempts

These attempts are not formal results, were not used to change formal seeds, and are not pooled with final construction r4. Their original local outputs remain under the correspondingly named `outputs/needle_role_router_online_lora_replay_v1_construction*` directories.

1. **Initial zero-update test:** failed only its adapter-identity assertion because two temporary Python objects could reuse an `id` after immediate destruction. Corrected test retains both objects concurrently; final suite passed 6/6.
2. **Construction r1:** container exited 1 with `STOP_A_SKILL_MUTATED`. The implementation incorrectly asserted immutability for the deliberately shared-adapter comparison. No formal seeds were involved.
3. **Construction r2:** one-shot construction completed, raw 509,949 bytes, SHA-256 `17a0046fd357f91fd23c9ff8110cf3de137ecb8d6519534bc848a4b1cb5cc8ca`. The first independent audit had 131 errors due auditor expectations about shared adapter immutability, route receipts, and where YIELD controls were recorded. Repairs reduced but did not eliminate errors. The raw remains immutable and is not treated as valid evidence.
4. **Construction r3:** its auditor reported PASS under a faulty route expectation. A direct receipt inspection after that audit showed `ROUTED_SHARED_ADAPTER` was actually using the B-skill adapter ID instead of a role-shared adapter, so that run was invalidated and superseded; its PASS is not cited as a study result.
5. **Construction r4:** after changing route semantics to make the routed-shared arm use one `role-shared-online-v1` adapter for both roles, the separate arm use immutable A and online B IDs, retaining both role routes and all split digests, a fresh excluded-seed run independently replayed with `PASS_CONSTRUCTION_AUDIT`, 0 errors. This is the only construction run summarized as valid above.

No old raw/report was edited to turn a failure into a pass. The only result used for the final construction summary is r4.

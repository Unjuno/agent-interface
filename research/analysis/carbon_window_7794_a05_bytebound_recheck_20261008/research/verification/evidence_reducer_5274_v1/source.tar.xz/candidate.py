"""Research-only typed evidence reducer. No action, network, or authority API."""
from __future__ import annotations
import copy
import hashlib
import json
import sys

FIELDS = frozenset(('eid', 'check', 'source', 'session', 'epoch', 'role', 'status'))
RULES = {'A': ('CURRENT', ('a1', 'a2')), 'B': ('VERIFIED_EFFECT', ('b1',)),
         'C': ('CURRENT', ('c1',))}
STATUSES = ('PASS', 'FAIL', 'UNKNOWN', 'TIMEOUT')
ROLES = ('CURRENT', 'VERIFIED_EFFECT', 'HISTORICAL', 'PREDICTED')


def encode(value: object) -> str:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False)


def classify(e: object) -> str:
    if type(e) is not dict or set(e) != FIELDS:
        return 'MALFORMED'
    if any(type(e[k]) is not str or not e[k] for k in FIELDS - {'epoch'}):
        return 'MALFORMED'
    if type(e['epoch']) is not int or e['epoch'] < 0:
        return 'MALFORMED'
    if e['check'] not in RULES or e['status'] not in STATUSES or e['role'] not in ROLES:
        return 'MALFORMED'
    role, sources = RULES[e['check']]
    if e['source'] not in sources:
        return 'MALFORMED'
    if e['session'] != 's1' or e['epoch'] != 7:
        return 'SCOPE_MISMATCH'
    if e['role'] != role:
        return 'ROLE_MISMATCH'
    return 'ACCEPTED'


class Reducer:
    """A union-only evidence frontier; only an explicit seal freezes a decision.

    Malformed evidence prevents PASS, but cannot hide an independently unopposed
    mandatory FAIL. Same-check PASS+FAIL conflicts; optional results do not vote.
    """
    def __init__(self) -> None:
        self._seen: dict[str, object] = {}
        self._sealed: dict | None = None

    def add(self, event: object) -> str:
        if self._sealed is not None:
            return 'LATE_IGNORED'
        wire = encode(event)
        if wire in self._seen:
            return 'DUPLICATE'
        self._seen[wire] = json.loads(wire)
        return classify(event)

    def view(self) -> dict:
        if self._sealed is not None:
            return copy.deepcopy(self._sealed)
        groups = {k: set() for k in RULES}
        ids: dict[str, set[str]] = {}
        faults: set[str] = set()
        quarantine: set[str] = set()
        for wire, e in self._seen.items():
            disposition = classify(e)
            if disposition == 'MALFORMED':
                faults.add('MALFORMED')
                continue
            ids.setdefault(e['eid'], set()).add(wire)
            if disposition == 'ACCEPTED':
                groups[e['check']].add(e['status'])
            else:
                quarantine.add(disposition)
        if any(len(v) > 1 for v in ids.values()):
            faults.add('EVIDENCE_ID_REUSED')
        checks = {}
        for name, statuses in groups.items():
            if 'PASS' in statuses and 'FAIL' in statuses:
                checks[name] = 'CONFLICT'
            elif 'FAIL' in statuses:
                checks[name] = 'FAIL'
            elif statuses == {'PASS'}:
                checks[name] = 'PASS'
            else:
                checks[name] = 'UNCERTAIN'
        if any(checks[k] == 'FAIL' for k in ('A', 'B')):
            verdict = 'FAIL'
        elif not faults and all(checks[k] == 'PASS' for k in ('A', 'B')):
            verdict = 'PASS'
        else:
            verdict = 'UNCERTAIN'
        # The frontier digest includes quarantined/faulty bytes, not just successes.
        digest = hashlib.sha256(encode(sorted(self._seen)).encode()).hexdigest()
        return {'verdict': verdict, 'checks': checks, 'faults': sorted(faults),
                'quarantine': sorted(quarantine), 'version': len(self._seen),
                'frontier_sha256': digest, 'authority': 'none'}

    def seal(self) -> dict:
        if self._sealed is None:
            self._sealed = self.view()
        return self.view()


def evaluate(packet: dict) -> dict:
    if set(packet) != {'case', 'events', 'late'} or type(packet['case']) is not str:
        raise ValueError('invalid packet')
    if type(packet['events']) is not list or type(packet['late']) is not list:
        raise ValueError('invalid event sequence')
    r = Reducer()
    prefixes = []
    for e in packet['events']:
        receipt = r.add(e)
        prefixes.append({'receipt': receipt, 'view': r.view()})
    final = r.seal()
    late = [{'receipt': r.add(e), 'view': r.view()} for e in packet['late']]
    return {'case': packet['case'], 'prefixes': prefixes, 'final': final,
            'late': late, 'resealed': r.seal()}


def strict_pairs(pairs: list) -> dict:
    out = {}
    for k, v in pairs:
        if k in out:
            raise ValueError('duplicate JSON key')
        out[k] = v
    return out


if __name__ == '__main__':
    # Local stdio protocol only. Invalid framing aborts, never fabricates PASS.
    for raw in sys.stdin.buffer:
        if len(raw) > 65536 or not raw.endswith(b'\n'):
            raise ValueError('invalid frame')
        obj = json.loads(raw, object_pairs_hook=strict_pairs,
                         parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
        print(encode(evaluate(obj)), flush=True)

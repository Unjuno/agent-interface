"""Finite declared corpus. A case is an ordering, not an independent OS trial."""
import itertools
import json


def enc(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False)


def evidence(check, variant=1, **changes):
    if variant == 0:
        return None
    e = dict(eid=check+'0', check=check, source={'A':'a1','B':'b1','C':'c1'}[check],
             session='s1', epoch=7, role='VERIFIED_EFFECT' if check == 'B' else 'CURRENT',
             status={1:'PASS',2:'FAIL',3:'UNKNOWN',4:'TIMEOUT',5:'PASS',6:'PASS'}[variant])
    if variant in (5,6):
        e['role'] = 'HISTORICAL' if variant == 5 else 'PREDICTED'
    e.update(changes)
    return e


def directed():
    a,b,c = (evidence(k) for k in 'ABC')
    return [
      ('conflict', [a,b,evidence('A',2,eid='A1',source='a2')]),
      ('conflict_plus_fail', [a,evidence('B',2),evidence('A',2,eid='A1',source='a2')]),
      ('equivocation', [a,b,evidence('A',2)]),
      ('duplicate', [a,a,b]),
      ('unknown_plus_pass', [a,b,evidence('A',3,eid='A1',source='a2')]),
      ('timeout_plus_fail', [evidence('A',2),b,evidence('A',4,eid='A1',source='a2')]),
      ('boolean_epoch', [evidence('A',epoch=True),b]),
      ('float_epoch', [evidence('A',epoch=7.0),b]),
      ('foreign_session', [evidence('A',session='s2'),b]),
      ('stale_epoch', [evidence('A',epoch=6),b]),
      ('future_epoch', [evidence('A',epoch=8),b]),
      ('unknown_check', [dict(a,check='Z'),b]),
      ('unknown_source', [dict(a,source='b1'),b]),
      ('missing_field', [{k:v for k,v in a.items() if k != 'role'},b]),
      ('boolean_status', [dict(a,status=True),b]),
      ('wrong_effect_role', [a,dict(b,role='CURRENT')]),
      ('historical_failure', [a,b,evidence('A',2,eid='A1',source='a2',role='HISTORICAL')]),
      ('extra_confidence', [dict(a,confidence=1),b]),
      ('null_event', [None,b]),
      ('optional_votes', [evidence('A',2),b,c,evidence('C',eid='C1')]),
      ('optional_conflict', [a,b,c,evidence('C',2,eid='C1')]),
      ('fault_with_fail', [dict(a,epoch=True),evidence('B',2)]),
    ]


def cases():
    sets = [('grid-'+''.join(map(str, v)), [e for k,i in zip('ABC',v)
             if (e := evidence(k,i)) is not None]) for v in itertools.product(range(7), repeat=3)]
    sets += directed()
    late = [evidence('A',2,eid='late-A',source='a2'), evidence('B')]
    result=[]
    for name, evs in sets:
        perms=sorted({enc(list(p)) for p in itertools.permutations(evs)})
        for i, wire in enumerate(perms):
            result.append(dict(case=f'{name}/p{i}', events=json.loads(wire), late=late))
    return result


if __name__ == '__main__':
    rows=cases()
    print(enc({'sets':343+len(directed()),'orderings':len(rows),
               'prefixes':sum(len(r['events']) for r in rows),
               'late_events':sum(len(r['late']) for r in rows)}))

"""Well-formed copied-evidence controls, with transport hashes refreshed."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import audit


def run(root,construction=False):
    original=[json.loads(x) for x in (root/'RESPONSES.jsonl').read_text().splitlines()]
    requests=[json.loads(x) for x in (root/'REQUESTS.jsonl').read_text().splitlines()]
    index={x['case'].split('/')[0]:i for i,x in enumerate(requests)}
    positive=index['grid-111'];conflict=index['conflict'];failed=index['optional_votes'];bad=index['boolean_epoch']
    variants=['drop_row','duplicate_row','false_final','boolean_version','late_rewrite',
              'failure_outvoted','conflict_collapsed','malformed_fault_hidden','authority_added',
              'prefix_changed','missing_final_lf','boolean_exit']
    results=[]
    for name in variants:
        with tempfile.TemporaryDirectory(prefix='reducer-audit-') as tmp:
            study=Path(tmp); dest=study/'data';dest.mkdir()
            for f in root.parent.iterdir():
                if f.is_file() and (f.suffix=='.py' or f.name=='FREEZE.json'):
                    shutil.copyfile(f,study/f.name)
            for f in root.iterdir():
                if f.is_file(): shutil.copyfile(f,dest/f.name)
            rows=copy.deepcopy(original);execution=json.loads((dest/'EXECUTION.json').read_text())
            if name=='drop_row':rows.pop()
            elif name=='duplicate_row':rows[1]=copy.deepcopy(rows[0])
            elif name=='false_final':rows[positive]['final']['verdict']='FAIL'
            elif name=='boolean_version':rows[positive]['final']['version']=True
            elif name=='late_rewrite':rows[positive]['late'][0]['view']['verdict']='FAIL'
            elif name=='failure_outvoted':rows[failed]['final']['verdict']='PASS'
            elif name=='conflict_collapsed':rows[conflict]['final']['verdict']='PASS'
            elif name=='malformed_fault_hidden':rows[bad]['final']['faults']=[]
            elif name=='authority_added':rows[positive]['final']['authority']='execute'
            elif name=='prefix_changed':rows[positive]['prefixes'][0]['view']['verdict']='PASS'
            elif name=='boolean_exit':execution['returncode']=False
            raw=(''.join(audit.canonical(x)+'\n' for x in rows)).encode()
            if name=='missing_final_lf':raw=raw[:-1]
            original_exec=(root/'EXECUTION.json').read_bytes()
            changed=raw!=(root/'RESPONSES.jsonl').read_bytes() or audit.canonical(execution)!=audit.canonical(json.loads(original_exec))
            (dest/'RESPONSES.jsonl').write_bytes(raw)
            execution['response_sha256']=hashlib.sha256(raw).hexdigest()
            (dest/'EXECUTION.json').write_text(json.dumps(execution,sort_keys=True,indent=2)+'\n')
            result=audit.audit(dest,construction)
            results.append(dict(name=name,effective=changed,rejected=bool(result['errors']),
                                first_error=result['errors'][0] if result['errors'] else None))
    return dict(status='PASS_CONTROLS' if all(r['effective'] and r['rejected'] for r in results)
                else 'FAIL_CONTROLS',controls=results,count=len(results),formal_reruns=0)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('out',type=Path)
    p.add_argument('--construction',action='store_true');a=p.parse_args();result=run(a.root,a.construction)
    with a.out.open('x') as f:f.write(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps(result,sort_keys=True));raise SystemExit(result['status']!='PASS_CONTROLS')

"""Excluded construction assertions; no old or formal allocation is executed."""
import json
import unittest
from candidate import Reducer, encode, evaluate, strict_pairs
from corpus import evidence

class Tests(unittest.TestCase):
    def evaluate_events(self,events):
        return evaluate(dict(case='unit',events=events,late=[]))['final']
    def test_missing(self):
        self.assertEqual(self.evaluate_events([])['verdict'],'UNCERTAIN')
    def test_positive(self):
        self.assertEqual(self.evaluate_events([evidence('A'),evidence('B')])['verdict'],'PASS')
    def test_optional_votes(self):
        events=[evidence('A',2),evidence('B')]+[evidence('C',eid=str(i)) for i in range(20)]
        self.assertEqual(self.evaluate_events(events)['verdict'],'FAIL')
    def test_historical(self):
        self.assertEqual(self.evaluate_events([evidence('A',5),evidence('B')])['verdict'],'UNCERTAIN')
    def test_predicted(self):
        self.assertEqual(self.evaluate_events([evidence('A'),evidence('B',6)])['verdict'],'UNCERTAIN')
    def test_conflict(self):
        self.assertEqual(self.evaluate_events([evidence('A'),evidence('B'),
            evidence('A',2,eid='A1',source='a2')])['checks']['A'],'CONFLICT')
    def test_partial_order_not_monotone_label(self):
        r=Reducer();r.add(evidence('A'));r.add(evidence('B'));self.assertEqual(r.view()['verdict'],'PASS')
        r.add(evidence('A',2,eid='A1',source='a2'));self.assertEqual(r.view()['verdict'],'UNCERTAIN')
    def test_dedup(self):
        r=Reducer();e=evidence('A');r.add(e);before=r.view();self.assertEqual(r.add(e),'DUPLICATE')
        self.assertEqual(before,r.view())
    def test_equivocation(self):
        result=self.evaluate_events([evidence('A'),evidence('A',2),evidence('B')])
        self.assertIn('EVIDENCE_ID_REUSED',result['faults'])
    def test_boolean_epoch(self):
        self.assertEqual(self.evaluate_events([evidence('A',epoch=True),evidence('B')])['verdict'],'UNCERTAIN')
    def test_no_external_mutation(self):
        r=Reducer();e=evidence('A');r.add(e);before=r.view();e['status']='FAIL'
        self.assertEqual(before,r.view());v=r.seal();v['verdict']='PASS';self.assertEqual(r.seal(),before)
    def test_late(self):
        r=Reducer();r.add(evidence('A'));r.add(evidence('B'));before=r.seal()
        self.assertEqual(r.add(evidence('A',2)),'LATE_IGNORED');self.assertEqual(r.seal(),before)
    def test_duplicate_json(self):
        with self.assertRaises(ValueError): json.loads('{"epoch":7,"epoch":8}',object_pairs_hook=strict_pairs)
    def test_foreign_epoch(self):
        self.assertEqual(self.evaluate_events([evidence('A',epoch=8),evidence('B')])['verdict'],'UNCERTAIN')

if __name__=='__main__': unittest.main()

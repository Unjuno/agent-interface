"""One-shot bounded local driver; construction and formal destinations differ."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import corpus

HERE=Path(__file__).resolve().parent

def main():
    p=argparse.ArgumentParser();p.add_argument('out',type=Path);p.add_argument('--construction',action='store_true')
    args=p.parse_args(); out=args.out.resolve();out.mkdir(parents=False,exist_ok=False)
    rows=corpus.cases()
    if args.construction:
        rows=[rows[0]]+[r for r in rows if r['case'].endswith('/p0') and
            r['case'].split('/')[0] in ['grid-111','conflict','duplicate','optional_votes','boolean_epoch']]
    else:
        freeze=json.loads((HERE/'FREEZE.json').read_bytes())
        for name,want in freeze['sources'].items():
            if hashlib.sha256((HERE/name).read_bytes()).hexdigest()!=want:
                raise RuntimeError('source drift:'+name)
        if len(rows)!=freeze['orderings']:
            raise RuntimeError('denominator drift')
    wire=(''.join(corpus.enc(row)+'\n' for row in rows)).encode()
    (out/'REQUESTS.jsonl').write_bytes(wire)
    command=[sys.executable,'-I','-B',str(HERE/'candidate.py')]
    start=time.monotonic_ns()
    child=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
        env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8'},cwd=out)
    status='COMPLETE'
    try:
        stdout,stderr=child.communicate(wire,timeout=20)
    except subprocess.TimeoutExpired:
        status='STOP_TIMEOUT';child.kill();stdout,stderr=child.communicate()
    end=time.monotonic_ns()
    (out/'RESPONSES.jsonl').write_bytes(stdout);(out/'stderr.txt').write_bytes(stderr)
    record=dict(kind='CONSTRUCTION' if args.construction else 'FORMAL',status=status,
        argv=command,pid=child.pid,returncode=child.returncode,start_ns=start,end_ns=end,
        cases=len(rows),request_sha256=hashlib.sha256(wire).hexdigest(),
        response_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest())
    (out/'EXECUTION.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
    print(json.dumps(record,sort_keys=True))
    return 0 if status=='COMPLETE' and child.returncode==0 and not stderr else 1

if __name__=='__main__':
    sys.exit(main())

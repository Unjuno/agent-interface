"""Raw-only independent oracle. Does not import candidate, corpus, or runner."""
import argparse
from collections import Counter, defaultdict
import hashlib
import itertools
import json
from pathlib import Path
import sys


def canonical(x):
    return json.dumps(x,sort_keys=True,separators=(',', ':'),ensure_ascii=True,allow_nan=False)


def sha(x):
    return hashlib.sha256(x).hexdigest()


def decode(raw):
    def pairs(xs):
        d={}
        for k,v in xs:
            if k in d: raise ValueError('duplicate-key')
            d[k]=v
        return d
    return json.loads(raw,object_pairs_hook=pairs,
        parse_constant=lambda x: (_ for _ in ()).throw(ValueError('nonfinite')))


def eligibility(e):
    columns={'eid','check','source','session','epoch','role','status'}
    allowed_sources={'A':{'a1','a2'},'B':{'b1'},'C':{'c1'}}
    if type(e)!=dict or set(e)!=columns: return 'MALFORMED'
    if not all(type(e[k])==str and bool(e[k]) for k in columns-{'epoch'}): return 'MALFORMED'
    if type(e['epoch'])!=int or e['epoch']<0: return 'MALFORMED'
    if e['check'] not in allowed_sources: return 'MALFORMED'
    if e['source'] not in allowed_sources[e['check']]: return 'MALFORMED'
    if e['role'] not in {'CURRENT','VERIFIED_EFFECT','HISTORICAL','PREDICTED'}: return 'MALFORMED'
    if e['status'] not in {'PASS','FAIL','UNKNOWN','TIMEOUT'}: return 'MALFORMED'
    if (e['session'],e['epoch'])!=('s1',7): return 'SCOPE_MISMATCH'
    expected_role={'A':'CURRENT','B':'VERIFIED_EFFECT','C':'CURRENT'}[e['check']]
    return 'ACCEPTED' if e['role']==expected_role else 'ROLE_MISMATCH'


def oracle(history):
    unique=sorted(set(map(canonical,history)))
    records=[decode(x) for x in unique]
    typed=[(x,eligibility(x)) for x in records]
    faults=[]
    if any(tag=='MALFORMED' for _,tag in typed): faults.append('MALFORMED')
    usable_schema=[x for x,t in typed if t!='MALFORMED']
    if len([x['eid'] for x in usable_schema])!=len({x['eid'] for x in usable_schema}):
        faults.append('EVIDENCE_ID_REUSED')
    checks={}
    for check in 'ABC':
        votes=[x['status'] for x,t in typed if t=='ACCEPTED' and x['check']==check]
        bits=(bool(votes), 'PASS' in votes, 'FAIL' in votes,
              any(s in {'UNKNOWN','TIMEOUT'} for s in votes))
        if bits[1] and bits[2]: checks[check]='CONFLICT'
        elif bits[2]: checks[check]='FAIL'
        elif bits[0] and bits[1] and not bits[3]: checks[check]='PASS'
        else: checks[check]='UNCERTAIN'
    required=[checks['A'],checks['B']]
    verdict=('FAIL' if 'FAIL' in required else
             'PASS' if required==['PASS','PASS'] and not faults else 'UNCERTAIN')
    return dict(verdict=verdict,checks=checks,faults=sorted(faults),
        quarantine=sorted({t for _,t in typed if t not in {'MALFORMED','ACCEPTED'}}),
        version=len(unique),frontier_sha256=sha(canonical(unique).encode()),authority='none')


def audit(root,construction=False):
    errors=[]; counts=Counter(); prefixes=late_count=0; equivalence={}; groups=defaultdict(list)
    def require(ok,message):
        if not ok: raise ValueError(message)
    try:
        study=root.parent
        execution=decode((root/'EXECUTION.json').read_bytes())
        req=(root/'REQUESTS.jsonl').read_bytes();resp=(root/'RESPONSES.jsonl').read_bytes()
        require(type(execution['returncode'])==int and execution['returncode']==0,'child exit')
        require(type(execution['pid'])==int and execution['pid']>0,'child identity')
        require(all(type(execution[k])==int for k in ('start_ns','end_ns')) and
                execution['start_ns']<execution['end_ns'],'execution clock ordering')
        require(execution['status']=='COMPLETE','terminal status')
        require(execution['kind']==('CONSTRUCTION' if construction else 'FORMAL'),'allocation kind')
        require((root/'stderr.txt').read_bytes()==b'','stderr')
        require(execution['stderr_sha256']==sha(b''),'stderr identity')
        require(execution['request_sha256']==sha(req) and execution['response_sha256']==sha(resp),'wire identity')
        require(req.endswith(b'\n') and resp.endswith(b'\n'),'JSONL final LF')
        requests=[decode(x) for x in req.splitlines()];responses=[decode(x) for x in resp.splitlines()]
        require(type(execution['cases'])==int and len(requests)==len(responses)==execution['cases'],'denominator')
        require(len({r['case'] for r in requests})==len(requests),'unique case IDs')
        if not construction:
            freeze=decode((study/'FREEZE.json').read_bytes())
            require(len(requests)==freeze['orderings'],'frozen denominator')
            require(sha(req)==freeze['request_sha256'],'frozen corpus')
            for name,want in freeze['sources'].items():
                require(sha((study/name).read_bytes())==want,'source:'+name)
        for request,response in zip(requests,responses):
            ident=request['case']
            try:
                require(set(response)=={'case','prefixes','final','late','resealed'},'response schema')
                require(response['case']==ident,'response/case join')
                require(len(response['prefixes'])==len(request['events']),'prefix denominator')
                history=[]
                for event,item in zip(request['events'],response['prefixes']):
                    tag='DUPLICATE' if canonical(event) in set(map(canonical,history)) else eligibility(event)
                    history.append(event)
                    expected={'receipt':tag,'view':oracle(history)}
                    require(canonical(item)==canonical(expected),'prefix semantics')
                    prefixes+=1
                final=oracle(history)
                require(canonical(response['final'])==canonical(final),'final semantics')
                require(canonical(response['resealed'])==canonical(final),'reseal immutability')
                require(len(response['late'])==len(request['late']),'late denominator')
                for item in response['late']:
                    require(canonical(item)==canonical({'receipt':'LATE_IGNORED','view':final}),'late rewrite')
                    late_count+=1
                key=canonical(sorted(map(canonical,request['events'])))
                if key in equivalence: require(equivalence[key]==canonical(final),'permutation disagreement')
                equivalence[key]=canonical(final)
                groups[ident.split('/')[0]].append(request['events'])
                counts[final['verdict']]+=1
            except Exception as exc: errors.append(ident+': '+str(exc))
        if not construction:
            require(len(groups)==freeze['sets'],'set denominator')
            for name, orders in groups.items():
                expected={canonical(list(p)) for p in itertools.permutations(orders[0])}
                require({canonical(x) for x in orders}==expected and len(orders)==len(expected),'permutations:'+name)
            expected_grid={'grid-'+''.join(map(str,x)) for x in itertools.product(range(7),repeat=3)}
            require({g for g in groups if g.startswith('grid-')}==expected_grid,'grid coverage')
            for name in expected_grid:
                events=groups[name][0]
                require(len(events)==sum(c!='0' for c in name[-3:]),'grid missing mapping')
                indexed={e['check']:e for e in events}
                for check,n in zip('ABC',map(int,name[-3:])):
                    if not n: require(check not in indexed,'grid absent');continue
                    e=indexed[check]
                    expected_status=('PASS','FAIL','UNKNOWN','TIMEOUT','PASS','PASS')[n-1]
                    expected_role=('HISTORICAL' if n==5 else 'PREDICTED' if n==6 else
                                   'VERIFIED_EFFECT' if check=='B' else 'CURRENT')
                    require(e['status']==expected_status and e['role']==expected_role,'grid variant')
            require(prefixes==freeze['prefixes'] and late_count==freeze['late_events'],'boundary denominator')
    except Exception as exc: errors.append('envelope: '+str(exc))
    return dict(status='PASS_CONSTRUCTION' if construction and not errors else
                'PASS_TYPED_REDUCER_FINITE_SCOPED' if not errors else 'HOLD_AUDIT_ERRORS',
                errors=errors,cases=sum(counts.values()),sets=len(groups),prefixes=prefixes,
                late_events=late_count,verdict_counts=dict(sorted(counts.items())))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('out',type=Path)
    p.add_argument('--construction',action='store_true');args=p.parse_args()
    result=audit(args.root,args.construction)
    with args.out.open('x') as f: f.write(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps(result,sort_keys=True));sys.exit(bool(result['errors']))

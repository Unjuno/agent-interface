from pathlib import Path
import argparse,json

def main():
    p=argparse.ArgumentParser();p.add_argument('--evidence',required=True);p.add_argument('--out',required=True);a=p.parse_args();root=Path(a.evidence);s=json.loads((root/'score.json').read_text());owners=json.loads((root/'setup-owner-records.json').read_text());events=json.loads((root/'setup-events.json').read_text());errors=[]
    if s.get('seed')!=2447009:errors.append('case_identity')
    if s.get('error')!="RuntimeError('SETUP_DID_NOT_REACH_SECTOR165')":errors.append('unexpected_stop_reason')
    releases=[x for x in owners if x.get('event')=='owner_release'];clean=bool(releases) and all(x.get('verified') and not x.get('keys_down') and not x.get('buttons_down') for x in releases)
    if not clean:errors.append('release_not_verified_empty')
    if any(x.get('kind')=='input' and not x.get('release',{}).get('verified') for x in events):errors.append('event_release_mismatch')
    out={'schema':'issue2447-setup-stop-audit-v1','case':'issue2447-positive-handoff-construction-2447009','decision':'STOP_SETUP_FIXTURE_NOT_REACHED' if not errors else 'HOLD_AUDIT','errors':errors,'stop_reason':s.get('error'),'setup_owner_release_count':len(releases),'all_setup_releases_verified_empty':clean,'setup_input_event_count':sum(x.get('kind')=='input' for x in events),'phase_gate_reached':False,'next_subgoal_emitted':False,'formal_rows':0,'retries':0,'scope':'Construction allocation stopped during fixture navigation before phase gate; no phase/handoff conclusion.'}
    Path(a.out).write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps(out,sort_keys=True))
if __name__=='__main__':main()

# Issue #2447 — fresh completion handoff construction

Status: fresh construction-only allocation 2447009; no formal rows and no retries.

## H/T/D/C/U

- **H:** A next subgoal is admitted only on fresh `DROP_COMPLETED` evidence; after continuation, recheck from input-free frames. `NO_DROP` and `UNKNOWN` must stop/fail closed.
- **T:** One fresh MAP01 drop episode, seed 2447009, temporal gate, heading 110°. If continuation is requested, issue at most one bounded extra-forward, then collect 450ms of input-free frames and recompute. If admitted, execute one bounded Right turn and then test stale-observation refusal. No retry.
- **D:** PASS_CONSTRUCTION only if transitions match the gate, any admitted turn has fresh binding/image, measurable effect and empty verified release, and stale evidence is refused before input. `NO_DROP`/`UNKNOWN` must stop; any mismatch is HOLD/STOP. One run only.
- **C:** Same Docker Desktop Linux/amd64 image and source fixture; observer reads X11 pixels and binding only. Heading 110° was used in distinct seed 2447006 whose initial phase passed; 2447009 is a new allocation.
- **U:** Single construction episode; no endpoint comparison, formal rates, full fault matrix, held-out transfer, or episode-completion claim.

## Frozen parameters

Seed 2447009; temporal gate; requested heading 110°; one extra-forward maximum; 450ms observation-only recheck; stale TTL250ms/delay350ms; adjacent-pair thresholds inherited from phase1 (<=100ms, >=80 tracks, median dy <= -20px).

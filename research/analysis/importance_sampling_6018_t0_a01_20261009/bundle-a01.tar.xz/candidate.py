#!/usr/bin/env python3
"""#6018 A01 finite Bernoulli sampling candidate. Synthetic method only."""
import argparse
import hashlib
import json
import random
import statistics
from fractions import Fraction as F
from pathlib import Path


def fstr(v):
    return str(v)


def failing(mask):
    # Bit order: stale, duplicate, verifier late, correlated source.
    stale, duplicate, late, correlated = [bool(mask & (1 << k)) for k in range(4)]
    return (stale and duplicate and (late or correlated)) or (duplicate and late and correlated)


def mass(mask, rates):
    out = F(1)
    for i, p in enumerate(rates):
        out *= p if (mask & (1 << i)) else (1 - p)
    return out


def sample(q, seed, n):
    rng = random.Random(seed)
    hist = [0] * 16
    sha = hashlib.sha256()
    first = None
    examples = []
    for t in range(1, n + 1):
        mask = sum((1 << j) for j in range(4) if rng.random() < q[j])
        hist[mask] += 1
        sha.update(bytes((mask,)))
        if failing(mask):
            if first is None:
                first = t
            if len(examples) < 3:
                examples.append([t, mask])
    return {"seed": seed, "n": n, "hist": hist, "trace_sha256": sha.hexdigest(),
            "first_failure": first, "first_three_counterexamples": examples}


def run(spec, source_file, spec_file):
    p = [F(v) for v in spec["P"]]
    all_paths = [{"mask": m, "P": fstr(mass(m, p)), "failure": failing(m)} for m in range(16)]
    exact = sum((mass(m, p) for m in range(16) if failing(m)), F(0))
    n, reps = spec["sample_count_per_batch"], spec["batch_count"]
    arms = []
    for arm_index, entry in enumerate(spec["proposals"]):
        q = [F(v) for v in entry["q"]]
        weights = [mass(m, p) / mass(m, q) for m in range(16)]
        q_rate = sum((mass(m, q) for m in range(16) if failing(m)), F(0))
        e2 = sum((mass(m, p)**2 / mass(m, q) for m in range(16) if failing(m)), F(0))
        variance = e2 - exact**2
        se2 = variance / (n * exact**2)
        rows = []
        weighted_sum = F(0)
        total_bad, total_bit = 0, 0
        med = []
        for rep in range(reps):
            seed = spec["master_seed"] + rep * spec["seed_stride"] + arm_index * spec["arm_seed_stride"]
            row = sample(q, seed, n)
            rows.append(row)
            total_bad += sum(row["hist"][m] for m in range(16) if failing(m))
            total_bit += sum(row["hist"][m] * m.bit_count() for m in range(16))
            weighted_sum += sum((row["hist"][m] * weights[m] for m in range(16) if failing(m)), F(0))
            med.append(row["first_failure"] if row["first_failure"] is not None else n + 1)
        arms.append({"id": entry["id"], "version": entry["version"], "q": entry["q"],
                     "Q_exact_failure": fstr(q_rate), "Q_to_P_exact_rate_ratio": fstr(q_rate / exact),
                     "relative_se_squared_per_batch": fstr(se2),
                     "estimation_quality": "UNCERTAIN_HIGH_VARIANCE" if se2 > F(spec["variance_relative_se2_ceiling"]) else "WITHIN_THEORETICAL_SE_GATE",
                     "rows": rows, "sampled_event_count": total_bad,
                     "raw_Q_frequency": fstr(F(total_bad, n * reps)),
                     "weighted_P_estimate": fstr(weighted_sum / (n * reps)),
                     "median_first_failure_or_censor": fstr(F(statistics.median(med))),
                     "detected_batches": sum(x["first_failure"] is not None for x in rows),
                     "mean_injected_faults": fstr(F(total_bit, n * reps))})
    return {"schema": "rare_fault_IS_t0_a01_v1", "allocation": spec["allocation"],
            "source_sha256": hashlib.sha256(Path(source_file).read_bytes()).hexdigest(),
            "spec_sha256": hashlib.sha256(Path(spec_file).read_bytes()).hexdigest(),
            "endpoint": spec["endpoint"], "path_oracle": all_paths,
            "P_exact_failure": fstr(exact), "arms": arms,
            "invalid_controls": [{"id": x["id"], "classification": "HOLD_UNIDENTIFIED", "reason": x["reason"], "sampled": False, "P_estimate": None} for x in spec["invalid_controls"]]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--spec", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    spec = json.loads(Path(args.spec).read_text())
    raw = run(spec, __file__, args.spec)
    Path(args.out).write_text(json.dumps(raw, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"allocation": raw["allocation"], "P_exact_failure": raw["P_exact_failure"],
                      "arms": [{"id": x["id"], "estimate": x["weighted_P_estimate"],
                                "median_discovery": x["median_first_failure_or_censor"]} for x in raw["arms"]],
                      "candidate_rows": sum(len(x["rows"]) for x in raw["arms"])}))


if __name__ == "__main__":
    main()

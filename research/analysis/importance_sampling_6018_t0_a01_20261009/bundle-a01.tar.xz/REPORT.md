# Issue #6018 — T0 A01 likelihood-ratio audit of biased rare-fault exploration

**Formal outcome: PASS_METHOD_SCOPED (synthetic, authored IID fault model; not deployed safety evidence).**

Issue: https://github.com/Unjuno/agent-interface/issues/6018 · Allocation: `RARE-FAULT-6018-T0-A01-20261009` · Original main intake: `57337e95ecbecf7e762c8ec8091472b79e8ad49f`. Scientific source/spec and decision gates were frozen *prospectively* in Issue comment https://github.com/Unjuno/agent-interface/issues/6018#issuecomment-6070911843 . The previous related #5380 results are preserved unchanged. This result answers a new *change-of-measure identification* question; it does **not** claim a live #59 DOOM threat-control run or real incidence rate.

## H / T / D / C / U

- **H (falsifiable):** Relative to direct P sampling, preregistered Q-useful finds the authored rare authorization violation earlier (first-failure median at least 4× smaller and detected in ≥12/16 batches), while raw Q frequency is ≥10× the exact P failure probability; the likelihood-ratio-corrected aggregate estimates P within 15% relative. The concentrated proposal must disclose theoretical high variance. Missing-support, reused adaptive selection and unknown operational P must not produce risk estimates.
- **T:** Enumerate 16 binary fault combinations, sample 4 named fixed proposal arms with 16 predeclared disjoint seeds each and 4096 generated four-bit masks per batch (262,144 total). Candidate/independent raw-only auditor each executed exactly once after freeze. Audit checks full candidate histogram, path mass, recorded first failure, first three counterexample indices, full-sample stream hashes, Q versions, exact correction fractions, seed provenance and seven mutations. The separate construction used unrelated input (2×64 per arm) and is not pooled.
- **D:** `PASS_METHOD_SCOPED` only if all structural/audit controls, every planned H threshold and all invalid-case holds pass. Otherwise retain original `FAIL_METHOD` or `HOLD`; no changed threshold, seed, source or official retry.
- **C:** Exact enumeration may be cheaper than any stochastic scheme for 16 states; Q-uniform can provide even earlier discovery and lower variance, but at higher injected-fault intensity; poorly concentrated Q can destroy estimator precision. An operational distribution P may be unknowable, so discovery utility may be separable from incidence claims.
- **U:** Bernoulli independence, synthetic fault/event predicate, known invented P, independent CPython RNG samples, fixed 4-bit space, and no model/application backpressure or correlated actual scheduling. This does **not** estimate real-world model/GUI failure rates, establish safety, calibrate DOOM behavior, claim actual timing speedups or change permission to act.

## Exact model / variable dictionary

| Symbol | Meaning (Japanese) | SI unit | Definition | Domain / assumptions | Type |
|---|---|---|---|---|---|
| `S,D,V,C` | stale-source / duplicate ACK / late verifier / shared-source fault flags（故障指標） | 1 | independent Bernoulli factors in the listed bit order | {0,1}; only inside the authored finite P,Q model | discrete scalar |
| `m` | binary fault mask（故障状態） | 1 | sum of 2^j times each flag | integer 0..15 | integer scalar |
| `H(m)` | unsafe-admission predicate（危険結果指標） | 1 | D and ((S and (V or C)) or (V and C)) | {0,1}; synthetic only | Boolean scalar |
| `P_m` | declared operational reference *in the toy model*（参照質量） | 1 | product of the four Bernoulli PMFs at mask m | [0,1], sum=1; P fully known only in fixture | rational probability |
| `Q_m` | proposal sampling mass（提案分布の質量） | 1 | product Bernoulli PMFs of the frozen proposal | (0,1] for every mask with P_m>0 for valid arms | rational probability |
| `w_m` | likelihood ratio（尤度比） | 1 | P_m/Q_m | Q_m>0 when P_m>0 | rational scalar |
| `p` | exact model hazard rate（真の故障確率） | 1 | sum(P_m H(m)) across 16 masks | [0,1]; model-conditional | rational probability |
| `n,R` | samples/batch and batches（標本数、反復数） | 1 | 4096, 16 | positive integers, IID batches | integer scalars |
| `X_i` | sampled masked event（抽出された状態） | 1 | generated under Q | {0,..,15} | discrete random variable |
| `p_hat` | LR corrected estimator（補正確率推定量） | 1 | (1/(nR)) sum(w_(X_i) H(X_i)) | independent samples, full support and known P,Q | rational random scalar |
| `u_c` | model-conditional analytical standard error（合成標準不確かさ） | 1 | sqrt(Var_Q(w H)/(nR)) | finite variance; exact in authored model | nonnegative scalar |
| `k` | expanded-uncertainty coefficient（包含係数） | 1 | k=2 in descriptive ±2u_c figures | not a guarantee of frequentist coverage under skew/rare events | positive scalar |

### Analytical derivation (no hidden simulation assumption)

Let s=P(S)=1/32, d=P(D)=1/16, v=P(V)=1/24, c=P(C)=1/16. By independence and inclusion–exclusion:

1. P(V or C)=v+c-vc; P(S and (V or C))=s(v+c-vc).
2. The intersection with (V and C) has probability svc. Thus conditional on D, the event probability is `s(v+c-vc)+vc-svc = s(v+c-2vc)+vc`.
3. `v+c-2vc = 19/192`; `s(19/192)+vc = 19/6144+16/6144 = 35/6144`.
4. Multiplying d gives the exact **p=35/98304=0.000356038411**, matched by both independent 16-mask enumerations.
5. If Q_m>0 wherever P_m>0, E_Q[w_X H(X)] = sum_m Q_m(P_m/Q_m)H(m) = sum_m P_m H(m) = p. Independent sample means therefore retain p in expectation; **raw Q event rate has expectation Q(H), not p**. Without proposal identity, P, or support this equality is not licensed.
6. Variance under the specified model is `Var_Q(wH) = sum_{H(m)=1} P_m^2/Q_m - p^2`, so `u_c^2 = Var_Q(wH)/(nR)` for independent draws. Every term is unitless, hence the estimator and u_c have SI unit **1**, matching the definition of probability. Counts n and R are dimensionless. This derivation concerns the toy model only.

## Frozen official first outcomes (no pooling with construction)

| Method | first fail median (samples; censored 4097) | batches found | Q observed fail frequency | LR corrected P estimate | relative error | analytic u_c, 16 batches |
|---|---:|---:|---:|---:|---:|---:|
| direct_P | 3857/2 | 12/16 | 0.0003356934 | 0.0003356934 | -5.71% | 7.3694e-05 |
| useful_Q | 18 | 16/16 | 0.03895569 | 0.0003551046 | -0.26% | 7.4791e-06 |
| uniform_Q | 3 | 16/16 | 0.2511597 | 0.0003581022 | +0.58% | 2.9839e-06 |
| concentrated_Q | 1 | 16/16 | 0.9100189 | 0.0003271714 | -8.11% | 0.00010194 |


- Q-useful first failure median 18 vs P median 1928.5, a 107.14× reduction in sampled-trace index **only**; 16/16 useful batches found the event. Q-uniform is an informative alternative (median 3 and 2.005 faults/sample vs Q-useful 1.004 faults/sample), so Q-useful is **not** claimed optimal. All four arms used the same per-batch sample count, but independent predeclared seeds; time-to-discovery is sample count, not observed wall time.
- Authored Q-useful exact event frequency is 5/128=0.0390625, approx 109.7× the authored P probability. Empirical raw Q frequency is 0.03895569 (>10× P) and is **not** interpreted as real risk. Likelihood correction gives 0.000355104605, an error of -0.26% versus exact p (frozen ≤15% tolerance).
- Concentrated Q is full-support but theoretical per-batch relative standard error is 1.145, above the frozen 0.25 threshold; its point estimate's apparent closeness is accidental and not sufficient for a confidence claim. Even direct P has high per-batch relative SE 0.828. Q-uniform is more efficient on this crafted 4-bit fixture, so a universal “best Q” or efficiency benefit is **not** supported.
- For Q-useful, the model-conditional independent-batch standard error is `u_c=7.4790745e-06` (unit 1); the descriptive k=2 scale is ±1.4958149e-05 around the observed estimate. This is **not** a validated 95% coverage interval for arbitrary real failures, and exact p here is already known analytically.
- Missing-support proposal, adaptive Q selected using the same evaluation stream without a separately protected estimation sample, and unknown operational P all return `HOLD_UNIDENTIFIED` with zero point estimates. No UNKNOWN was silently scored as success or failure.
- Auditor reconstructed all 64 actual batch records / 262144 sampled fault-mask draws, and rejected 7/7 intentionally altered copies: missing count, inverted weight, Q-version substitution, missing-support false estimate, unknown P mislabel, changed endpoint and removed counterexample. Every fault mask is logged via seed/stream SHA-256 and 16-bin histogram, with first three violating indices per batch; the exact full stream can be recomputed deterministically from the retained CPython RNG recipe.

## Provenance, file hashes, execution and reproducibility

- Python backend: CPython 3.13.5 x86_64, Debian 13, Linux kernel 6.18.44 and glibc 2.41, Python standard library only. Tool-container cgroup reported `cpu.max=400000 100000` and `memory.max=4294967296` bytes; no proof those reflect isolated physical CPU/swap enforcement. No GPU, GUI, LLM, Docker, OrbStack, WSLc, native macOS or source/network backend used during experiment.
- Pre-frozen SHA256: spec `35c54e5877a6e73bc09a4db5811c3fcb69ef15a470cad03951448d546cb305df`; candidate `aa5ea9c868f658713b5908ce2d0c4db53cde2a1639b5bf0dbc0c06ab12623792`; independent auditor `30e08f7f3cb2b6fcae187ed9c9382b66cd8f2c7e8c1673ea0de7b5c2d72bdd9a`.
- First official candidate raw `a0dd810be29acb27c96c5167076d059f71b22ed4da45386c028ae0f372040706` (49,721 bytes); independent auditor raw `f6076dd19c725745f7ff86d7095c8cee11b46a59c5d84f7f9d34d4c1fb2c84f2` (1,363 bytes); process `RECEIPTS.json` hash `dbbe2647e808028f4f4ffb820b75f60e55d882b3fb264d5a4f2c43d4e84455fa`.
- Candidate first exact command uses frozen local package `python candidate.py --spec spec.json --out formal/raw_candidate.json`, exit 0, measured single-run process elapsed 2.508 seconds; auditor `python audit.py --spec spec.json --candidate-source candidate.py --input formal/raw_candidate.json --out formal/raw_audit.json`, exit 0, 7.050 seconds. UTC timestamps and stdout/stderr receipts are inside the immutable archive; stdout/stderr are not the scientific raw. These times are **not benchmarks** (one container/clock/load; no repeated runs), and no throughput superiority is claimed.
- Original first raw/output/exit receipts, exact frozen source/spec, construction-only records and manifest are in `bundle-a01.tar.xz`. The archive is retained unchanged after SHA freeze. Do not rerun A01 as an allocation. New reproduction executions need a new identity and must not overwrite the first raw. To read/independently audit existing evidence after extraction:


a) Verify `sha256sum` of the archive against the exact archive hash recorded in the owning Issue and PR, extract, and check every file against internal `SHA256SUMS.txt`.

b) Reconstruct first official raw **read-only** by invoking the frozen auditor on the extracted paths with a separate new output path, never replacing `formal/raw_audit.json`.

c) To attempt an independent replication of the sampler, explicitly allocate a *new* construction/reproduction identity and separate output path; recorded runs are already consumed.

## ERROR CHECK and promotion boundary

- Analytical event/probability derivation: PASS (16/16 masks; exact Fraction arithmetic, mass sum 1).
- Candidate–independent-audit identity/provenance: PASS (64/64 batches, 262144/262144 full RNG streams).
- Seven mutation rejection tests: PASS (7/7), no retry.
- Hypothesis gates: PASS on sampled discovery contrast, rate distortion, weighted calibration and explicit invalid-case holds **for the frozen synthetic family only**.
- Live-agent behavioral effect, probability-model calibration, full application fault coverage, real-time deadline/liveness or physical input release: **NOT TESTED**.

**Next research gate:** A separate independently sourced #59/V39 disturbance trace and observationally identified P/Q selection model would be required before even attempting operational fault-incidence estimation. Regardless of risk estimation, deterministic authority/lease/release checks retain priority over sampling confidence.

## Cross-disciplinary transfer

Statistical model checking (conditional error control), importance sampling/Monte Carlo (likelihood ratios and effective sample size), robust software verification (hard authority invariants and replay oracle) and control engineering (deadline/observation disturbances) inform this finite evaluation; no discipline's theorem supplies the missing real-world data-generating distribution.

# #6018 A01 — likelihood-ratio validation of biased rare-fault exploration

**Scoped finite-method result: PASS_METHOD_SCOPED, not runtime safety.** See [REPORT.md](REPORT.md), [Issue #6018](https://github.com/Unjuno/agent-interface/issues/6018), and the prospective [formal freeze](https://github.com/Unjuno/agent-interface/issues/6018#issuecomment-6070911843).

This directory stores one immutable formal candidate result and a separate raw-only independent audit over 262,144 sampled four-bit fault traces. It distinguishes (a) faster *counterexample discovery* under Q from (b) estimating the reference P probability correctly. Q-event frequency itself is not an unbiased risk estimator.

`bundle-a01.tar.xz` contains exact source/spec, original first formal raw and two exit receipts, construction records, and the SHA256 manifest. Read `REPORT.md` for the complete H/T/D/C/U contract, units/variables, exact derivation and transfer boundaries. Do not rerun or overwrite the consumed formal A01 result. Reviewers may re-verify retained artifacts using a new independent audit output file.

The original first raw experiment used CPython 3.13.5 on an isolated Debian/Linux tool container, not a qualified WSLc/OrbStack or a live desktop.

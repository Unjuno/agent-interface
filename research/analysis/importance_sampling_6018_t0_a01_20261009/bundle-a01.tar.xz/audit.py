#!/usr/bin/env python3
"""Independent raw-only T0 reference/audit for #6018; does not import candidate."""
import argparse
import copy
import hashlib
import json
import random
import statistics
from fractions import Fraction as F
from pathlib import Path


def prob(code, rates):
    term = F(1)
    for index in range(4):
        term *= rates[index] if ((code >> index) % 2) else (1 - rates[index])
    return term


def violation(code):
    s = ((code >> 0) & 1) == 1
    d = ((code >> 1) & 1) == 1
    v = ((code >> 2) & 1) == 1
    c = ((code >> 3) & 1) == 1
    return (d and v and c) or (s and d and (v or c))


def require(cond, why):
    if not cond:
        raise AssertionError(why)


def replay(seed, n, probs):
    g = random.Random(seed)
    counts = [0 for _ in range(16)]
    digest = hashlib.sha256()
    first = None
    examples = []
    for i in range(1, n + 1):
        tosses = [g.random() for _ in range(4)]
        code = 0
        for j in range(4):
            if tosses[j] < probs[j]:
                code |= (1 << j)
        counts[code] += 1
        digest.update(bytes([code]))
        if violation(code):
            if first is None:
                first = i
            if len(examples) < 3:
                examples.append([i, code])
    return counts, digest.hexdigest(), first, examples


def verify(spec, raw, source_digest):
    require(raw["schema"] == "rare_fault_IS_t0_a01_v1", "schema")
    require(raw["allocation"] == spec["allocation"], "allocation")
    require(raw["endpoint"] == spec["endpoint"], "endpoint")
    require(raw["source_sha256"] == source_digest, "candidate source identity")
    P = [F(z) for z in spec["P"]]
    require(len(P) == 4 and all(0 < p < 1 for p in P), "P positive")
    ref = [{"mask": code, "P": str(prob(code, P)), "failure": violation(code)} for code in range(16)]
    require(ref == raw["path_oracle"], "reference exhaustive path oracle")
    truth = sum((prob(code, P) for code in range(16) if violation(code)), F())
    require(str(truth) == raw["P_exact_failure"], "true P incident risk")
    require(len(raw["arms"]) == len(spec["proposals"]), "proposal arms")
    n, reps = spec["sample_count_per_batch"], spec["batch_count"]
    reference_arms = []
    for aidx, (qcfg, arm) in enumerate(zip(spec["proposals"], raw["arms"])):
        require(arm["id"] == qcfg["id"] and arm["version"] == qcfg["version"], "Q identity/version")
        require(arm["q"] == qcfg["q"], "Q parameter identity")
        q = [F(v) for v in qcfg["q"]]
        require(all(0 < r < 1 for r in q), "Q full support")
        query = sum((prob(code, q) for code in range(16) if violation(code)), F())
        second = sum((prob(code, P)**2/prob(code, q) for code in range(16) if violation(code)), F())
        relative_var = (second - truth**2) / (truth**2 * n)
        require(arm["Q_exact_failure"] == str(query), "Q exact failure")
        require(arm["Q_to_P_exact_rate_ratio"] == str(query / truth), "Q/P ratio")
        require(arm["relative_se_squared_per_batch"] == str(relative_var), "variance")
        quality = "UNCERTAIN_HIGH_VARIANCE" if relative_var > F(spec["variance_relative_se2_ceiling"]) else "WITHIN_THEORETICAL_SE_GATE"
        require(arm["estimation_quality"] == quality, "variance classification")
        require(len(arm["rows"]) == reps, "batch count")
        numerator = F(0)
        failures = 0
        bit_sum = 0
        firsts = []
        seen_seeds = set()
        for rix, row in enumerate(arm["rows"]):
            seed = spec["master_seed"] + rix*spec["seed_stride"] + aidx*spec["arm_seed_stride"]
            require(row["seed"] == seed and seed not in seen_seeds, "independent allocation seed")
            seen_seeds.add(seed)
            require(row["n"] == n, "sample size")
            counts, sha, first, examples = replay(seed, n, q)
            require(row["hist"] == counts and sum(counts) == n, "path count")
            require(row["trace_sha256"] == sha, "sample trace digest")
            require(row["first_failure"] == first, "first adversarial example")
            require(row["first_three_counterexamples"] == examples, "retained counterexample instances")
            numerator += sum((counts[code]*prob(code, P)/prob(code,q) for code in range(16) if violation(code)), F())
            failures += sum(counts[code] for code in range(16) if violation(code))
            bit_sum += sum(counts[code] * code.bit_count() for code in range(16))
            firsts.append(first if first is not None else n+1)
        require(arm["weighted_P_estimate"] == str(numerator/(reps*n)), "likelihood ratio correction")
        require(arm["raw_Q_frequency"] == str(F(failures, reps*n)), "raw Q frequency")
        require(arm["sampled_event_count"] == failures, "total events")
        require(arm["mean_injected_faults"] == str(F(bit_sum, reps*n)), "fault intensity")
        require(arm["detected_batches"] == sum(x <= n for x in firsts), "detection count")
        require(arm["median_first_failure_or_censor"] == str(F(statistics.median(firsts))), "first failure median")
        reference_arms.append({"id": arm["id"], "events": failures, "P_estimate": str(numerator/(reps*n)), "median":str(F(statistics.median(firsts))), "quality": quality})
    require(len(raw["invalid_controls"]) == len(spec["invalid_controls"]), "invalid controls list")
    for frozen, actual in zip(spec["invalid_controls"],raw["invalid_controls"]):
        require(frozen["id"] == actual["id"] and frozen["reason"] == actual["reason"], "invalid control identity")
        require(actual["classification"] == "HOLD_UNIDENTIFIED" and actual["sampled"] is False and actual["P_estimate"] is None, "no invented probability from invalid proposal")
    return {"truth":truth,"arms":reference_arms,"row_count":reps*len(reference_arms),"samples":reps*n*len(reference_arms)}


def mutations(spec, raw, digest):
    changed = []
    edits = [
        ("missing_path", lambda v: v["arms"][1]["rows"][0]["hist"].__setitem__(0,0)),
        ("inverted_weight", lambda v: v["arms"][1].__setitem__("weighted_P_estimate", "1")),
        ("wrong_q_version", lambda v: v["arms"][1].__setitem__("version", "Q-unknown")),
        ("missing_support_accepted", lambda v: v["invalid_controls"][0].__setitem__("P_estimate", "1/3")),
        ("unknown_P_accepted", lambda v: v["invalid_controls"][2].__setitem__("classification", "PASS")),
        ("wrong_endpoint", lambda v: v.__setitem__("endpoint", "different_hazard")),
        ("missing_counterexample", lambda v: v["arms"][1]["rows"][0].__setitem__("first_three_counterexamples", [])),
    ]
    for name, mutate in edits:
        item = copy.deepcopy(raw)
        mutate(item)
        try:
            verify(spec,item,digest)
            changed.append({"id":name,"rejected":False})
        except (AssertionError,ValueError,KeyError,TypeError):
            changed.append({"id":name,"rejected":True})
    return changed


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--spec",required=True)
    parser.add_argument("--candidate-source",required=True)
    parser.add_argument("--input",required=True)
    parser.add_argument("--out",required=True)
    parser.add_argument("--audit-only",action="store_true", help="construction consistency/mutation audit, no H decision")
    a=parser.parse_args()
    sp=Path(a.spec)
    spec=json.loads(sp.read_text())
    raw=json.loads(Path(a.input).read_text())
    digest=hashlib.sha256(Path(a.candidate_source).read_bytes()).hexdigest()
    status="PASS_AUDIT"
    errors=[]
    try:
        require(raw["spec_sha256"] == hashlib.sha256(sp.read_bytes()).hexdigest(), "spec content digest")
        res=verify(spec,raw,digest)
        muts=mutations(spec,raw,digest)
        require(len(muts) == spec["required_mutation_rejections"] and all(m["rejected"] for m in muts), "mutations")
        p=res["truth"]
        arms={x["id"]:x for x in raw["arms"]}
        useful=arms["useful_Q"]
        direct=arms["direct_P"]
        if not a.audit_only:
            require(F(useful["median_first_failure_or_censor"])*spec["min_discovery_speed_factor"] <= F(direct["median_first_failure_or_censor"]),"discovery contrast")
            require(useful["detected_batches"] >= spec["min_useful_batches_detected"],"useful detection support")
            require(F(useful["raw_Q_frequency"]) >= spec["min_raw_Q_rate_multiple"]*p,"raw Q event-rate distortion")
            require(abs(F(useful["weighted_P_estimate"])-p) <= F(spec["good_relative_bias_tolerance"])*p,"held-out Q calibration")
            require(arms["concentrated_Q"]["estimation_quality"] == "UNCERTAIN_HIGH_VARIANCE", "bad Q uncertainty")
        result={"status":"PASS_AUDIT_ONLY" if a.audit_only else "PASS_METHOD_SCOPED", "condition":"authored finite P,Q model only", "P_truth":str(p),
                "audited_batches":res["row_count"],"audited_samples":res["samples"],
                "arms":res["arms"],"mutations":muts,"errors":[]}
    except (AssertionError,ValueError,KeyError,TypeError) as ex:
        status="FAIL_METHOD"
        errors.append(str(ex))
        result={"status":status,"errors":errors}
    Path(a.out).write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
    print(json.dumps({"status":result["status"],"errors":errors,"mutations_passed":sum(z["rejected"] for z in result.get("mutations",[]))}))
    raise SystemExit(0 if result["status"] in {"PASS_METHOD_SCOPED","PASS_AUDIT_ONLY"} else 1)

if __name__=="__main__":
    main()

"""One-use focus+key acquisition study. Only fixture-owned Shift input is generated."""
from __future__ import annotations
from pathlib import Path
import json,os,sys,time,traceback
from infra import Actor,save,sha,now
from server import Server
from native import load,Reader
HERE=Path(__file__).resolve().parent
CONTEXTS=('UP','DOWN','EDGE_BURST','FOCUS_RETURN')
ARMS=('FOCUS_QUERY','FOCUS_SYNC','FOCUS_PIGGYBACK')
def rpc(actor,op,ident,**extra):
    actor.send(json.dumps(dict(op=op,id=ident,**extra),sort_keys=True))
    return actor.until(lambda r:r.get('id')==ident,timeout=3)
def freeze_check():
    f=json.loads((HERE/'FREEZE.json').read_bytes())
    for k,h in f['files'].items():
        if sha((HERE/k).read_bytes())!=h:raise ValueError('frozen file drift '+k)
    return sha((HERE/'FREEZE.json').read_bytes())
def run(mode,index,out):
    if mode not in ('construct','allocation') or index not in range(4):raise ValueError('bad allocation')
    freeze=freeze_check() if mode=='allocation' else None
    context=CONTEXTS[index];blocks=8 if mode=='allocation' else 2;cycles=27 if mode=='allocation' else 7
    if mode=='allocation' and index:
        prev=json.loads((out.parent/f'batch-{index-1}'/'EXTERNAL.json').read_bytes())
        if prev['returncode']!=0:raise ValueError('preceding batch not complete')
    out.mkdir(parents=True,exist_ok=False)
    cpu=json.loads((HERE/'ENVIRONMENT.json').read_bytes())['pinned_cpu'];os.sched_setaffinity(0,{cpu})
    save(out/'START.json',dict(mode=mode,index=index,pid=os.getpid(),before_ns=now(),context=context,blocks=blocks,
         cycles=cycles,freeze_sha256=freeze,affinity=sorted(os.sched_getaffinity(0))))
    server=writer=witness=None;readers=[];rc=1;complete=0
    old={k:os.environ.get(k) for k in ('DISPLAY','XAUTHORITY')}
    try:
        server=Server(out);os.environ.update(DISPLAY=server.display,XAUTHORITY=str(server.auth))
        writer=Actor('writer',[sys.executable,'-B',str(HERE/'actor.py'),'writer'],server.env,out)
        witness=Actor('witness',[sys.executable,'-B',str(HERE/'actor.py'),'witness'],server.env,out)
        wr=writer.until(lambda r:r.get('kind')=='ready',timeout=3);wi=witness.until(lambda r:r.get('kind')=='ready',timeout=3)
        lib=load();save(out/'ACTORS.json',dict(writer=wr,witness=wi,native_sample_size=lib.fp_sample_size(),native_event_size=lib.fp_event_size(),ulong_size=lib.fp_ulong_size()))
        for block in range(blocks):
            row=dict(index=block,context=context,start_ns=now(),samples=[],status='STARTED');readers=[]
            try:
                row['new']=new=rpc(writer,'new',f'new-{block}')
                row['seed']=seed=rpc(witness,'snapshot',f'seed-{block}')
                if any(bytes.fromhex(seed['result']['keymap'])) or seed['result']['focus']!=new['result']['target']:raise ValueError('seed not neutral/focused')
                code=wr['keycode'];window=new['result']['target'];row.update(keycode=code,window=window)
                rr={};row['bootstrap']={};row['first_ordinals']={}
                for arm in (*ARMS,'OTHER_CONNECTION_FOCUS'):
                    r=Reader(lib,window,code,seed['result']['keymap'],arm!='FOCUS_QUERY',f'{arm}-{index}-{block}',arm=='OTHER_CONNECTION_FOCUS')
                    rr[arm]=r;readers.append(r)
                    if arm!='FOCUS_QUERY':row['bootstrap'][arm]=r.bootstrap();row['first_ordinals'][arm]=r.first
                row['mutation']=rpc(writer,'mutate',f'mutate-{block}',context=context)
                row['before']=rpc(witness,'snapshot',f'before-{block}')
                row['foreign_control']=rr['OTHER_CONNECTION_FOCUS'].observe('OTHER_CONNECTION_FOCUS')
                for pair in range(cycles):
                    phase='first' if pair==0 else ('warmup' if pair<3 else 'measured')
                    # Cycle all six permutations to balance first/second/third positions.
                    orders=(ARMS,(ARMS[1],ARMS[2],ARMS[0]),(ARMS[2],ARMS[0],ARMS[1]),
                            tuple(reversed(ARMS)),(ARMS[0],ARMS[2],ARMS[1]),(ARMS[1],ARMS[0],ARMS[2]))
                    order=orders[(pair+block+index)%6]
                    for pos,arm in enumerate(order):
                        r=rr[arm].observe(arm);r.update(pair=pair,phase=phase,position=pos);row['samples'].append(r)
                row['after']=rpc(witness,'snapshot',f'after-{block}')
                row['release']=rpc(writer,'release',f'release-{block}')
                row['neutral']=rpc(witness,'snapshot',f'neutral-{block}')
                for r in readers:r.close()
                readers=[];row['status']='COMPLETE';complete+=1
            except BaseException:
                row['status']='STOP';row['error']=traceback.format_exc();raise
            finally:
                for r in readers:
                    try:r.close()
                    except BaseException:row.setdefault('cleanup_errors',[]).append(traceback.format_exc())
                readers=[];row['end_ns']=now();save(out/f'block-{block:02}.json',row)
        rc=0
    except BaseException:
        (out/'STOP.txt').write_text(traceback.format_exc());raise
    finally:
        for a in (writer,witness):
            if a is not None:a.stop(json.dumps(dict(op='close',id='close')))
        if server is not None:server.close()
        for k,v in old.items():
            if v is None:os.environ.pop(k,None)
            else:os.environ[k]=v
        save(out/'END.json',dict(complete=complete,returncode=rc,after_ns=now(),freeze_sha256=freeze))
if __name__=='__main__':run(sys.argv[1],int(sys.argv[2]),Path(sys.argv[3]).resolve())

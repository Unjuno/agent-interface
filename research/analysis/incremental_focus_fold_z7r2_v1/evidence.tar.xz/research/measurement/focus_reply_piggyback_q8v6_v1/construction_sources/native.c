/* Read-only same-connection focus/key-state acquisition. Private test display only.
 * New measurement helper derived from n6k4 native.c, not a production backend.
 * All task input is performed by the separate unchanged fixture actor.
 */
#define _POSIX_C_SOURCE 200809L
#include <X11/Xlib.h>
#include <X11/XKBlib.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define CAP 96
/* modes: 0=FOCUS_QUERY, 1=FOCUS_SYNC, 2=FOCUS_PIGGYBACK,
 * 3=OTHER_CONNECTION_FOCUS (diagnostic only). */
typedef struct { uint64_t ordinal,window,server_ms,dequeued_ns;
 int type,send_event,keycode,mode,detail; unsigned char keymap[32]; } Event;
typedef struct { uint64_t t0,t1,r0,r1,p0,p1,focus_r0,focus_r1,focus_t0,focus_t1,
 drain_r0,drain_r1,other_r0,other_r1,focus_window;
 int count,queries,syncs,focus_calls,errors; unsigned char keymap[32]; Event events[CAP]; } Sample;
typedef struct { Display *d,*other; Window window; uint64_t ordinal; int subscribed; } Ctx;
static int error_count=0;
static int on_error(Display*d,XErrorEvent*e){(void)d;(void)e;error_count++;return 0;}
static uint64_t ns(void){struct timespec t; if(clock_gettime(CLOCK_MONOTONIC,&t))abort();return (uint64_t)t.tv_sec*1000000000ULL+t.tv_nsec;}
size_t fp_sample_size(void){return sizeof(Sample);}
size_t fp_event_size(void){return sizeof(Event);}
size_t fp_ulong_size(void){return sizeof(unsigned long);}
void *fp_open(unsigned long w,int subscribed,int foreign){
 Ctx *c=calloc(1,sizeof *c); if(!c)return NULL;
 XSetErrorHandler(on_error); c->d=XOpenDisplay(NULL); if(!c->d){free(c);return NULL;}
 c->window=w;c->subscribed=subscribed; Bool supported=False,active=False;
 if(!XkbSetDetectableAutoRepeat(c->d,True,&supported)||!XkbGetDetectableAutoRepeat(c->d,&active)||!supported||!active){XCloseDisplay(c->d);free(c);return NULL;}
 long mask=subscribed?(KeyPressMask|KeyReleaseMask|FocusChangeMask|KeymapStateMask):0;
 XSelectInput(c->d,w,mask);XSync(c->d,False);
 XWindowAttributes a;if(!XGetWindowAttributes(c->d,w,&a)||a.your_event_mask!=mask||error_count){XCloseDisplay(c->d);free(c);return NULL;}
 if(foreign){c->other=XOpenDisplay(NULL);if(!c->other){XCloseDisplay(c->d);free(c);return NULL;}}
 return c;
}
static int drain(Ctx*c,Sample*s,int synced){
 while(synced?XPending(c->d):XEventsQueued(c->d,QueuedAlready)){
  XEvent e;memset(&e,0,sizeof e);XNextEvent(c->d,&e);
  if(e.type!=KeyPress&&e.type!=KeyRelease&&e.type!=FocusIn&&e.type!=FocusOut&&e.type!=KeymapNotify)continue;
  if(s->count>=CAP)return -4;
  Event*v=&s->events[s->count++];v->ordinal=c->ordinal++;v->type=e.type;v->send_event=e.xany.send_event;v->dequeued_ns=ns();
  if(e.type==KeymapNotify)memcpy(v->keymap,e.xkeymap.key_vector,32);
  else if(e.type==FocusIn||e.type==FocusOut){v->window=e.xfocus.window;v->mode=e.xfocus.mode;v->detail=e.xfocus.detail;}
  else{v->window=e.xkey.window;v->keycode=e.xkey.keycode;v->server_ms=e.xkey.time;}
 }
 return 0;
}
int fp_observe(void *opaque,int mode,Sample*s){
 Ctx*c=opaque;if(!c||!s||mode<0||mode>3)return -1;
 if(mode!=0&&!c->subscribed)return -2;
 if(mode==3&&!c->other)return -6;
 memset(s,0,sizeof *s);s->r0=XNextRequest(c->d);s->p0=XLastKnownRequestProcessed(c->d);
 s->other_r0=c->other?XNextRequest(c->other):0;s->t0=ns();
 Display *fd=mode==3?c->other:c->d;Window focus=0;int revert=0;
 s->focus_t0=ns();s->focus_r0=XNextRequest(fd);s->focus_calls=1;
 if(!XGetInputFocus(fd,&focus,&revert))return -7;
 s->focus_r1=XNextRequest(fd);s->focus_t1=ns();s->focus_window=focus;
 if(mode==0){s->queries=1;if(!XQueryKeymap(c->d,(char*)s->keymap))return -3;}
 else{
  if(mode==1){s->syncs=1;XSync(c->d,False);}
  s->drain_r0=XNextRequest(c->d);int rc=drain(c,s,mode==1);s->drain_r1=XNextRequest(c->d);
  if(rc)return rc;
 }
 s->t1=ns();s->r1=XNextRequest(c->d);s->p1=XLastKnownRequestProcessed(c->d);
 s->other_r1=c->other?XNextRequest(c->other):0;s->errors=error_count;return error_count?-5:0;
}
int fp_close(void*opaque){Ctx*c=opaque;if(!c)return -1;if(c->other)XCloseDisplay(c->other);XCloseDisplay(c->d);free(c);return error_count?-1:0;}

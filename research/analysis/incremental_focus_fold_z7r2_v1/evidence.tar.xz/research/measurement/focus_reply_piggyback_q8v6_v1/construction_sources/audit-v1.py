"""Independent raw-only reconstruction. Imports no actor, native adapter or policy."""
from pathlib import Path
import hashlib,json,statistics,sys
ARMS=('FOCUS_QUERY','FOCUS_SYNC','FOCUS_PIGGYBACK')
CONTEXTS=('UP','DOWN','EDGE_BURST','FOCUS_RETURN')
class AuditError(ValueError):pass
class Checks:
    def __init__(self):self.n=0
    def yes(self,condition,message):
        self.n+=1
        if not condition:raise AuditError(message)
def digest(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes())
def integer(v):return type(v) is int and v>=0
def bitmap(s,c):
    if type(s) is not str or len(s)!=64 or any(x not in '0123456789abcdef' for x in s):raise AuditError('bitmap encoding')
    return bool(bytes.fromhex(s)[c//8] & (1<<(c%8)))
def summarize(values):return {'minimum':min(values),'median':statistics.median(values),'maximum':max(values)}
def reduce_events(events,first,window,code,seed,ck):
    # A separately written one-pass state machine, not imported classify().
    down=bitmap(seed,code);known=True;focus=True;awaiting=False
    for index,ev in enumerate(events):
        ck.yes(type(ev['ordinal']) is int and ev['ordinal']==first+index,'event ordinal')
        ck.yes(ev['send_event'] is False and type(ev['type']) is int,'event type/synthetic marker')
        kind=ev['type']
        if kind in (2,3):
            ck.yes(type(ev['keycode']) is int and 8<=ev['keycode']<=255 and type(ev['window']) is int and ev['window']==window,'key event binding')
            if awaiting:known=False;awaiting=False
            if ev['keycode']==code:down=(kind==2)
        elif kind in (9,10):
            ck.yes(type(ev['window']) is int and ev['window']==window and type(ev['mode']) is int and 0<=ev['mode']<=3 and type(ev['detail']) is int and 0<=ev['detail']<=7,'focus event binding')
            known=False;focus=kind==9 and ev['mode']==0;awaiting=focus
        elif kind==11:
            ck.yes(focus and awaiting,'keymap focus relation')
            down=bitmap(ev['keymap'],code);known=True;awaiting=False
        else:raise AuditError('unknown event type')
    ck.yes(known and focus and not awaiting,'resolved focus/key state')
    return down

def audit_block(row,context,index,block,cycles,mode,ck):
    ck.yes(row['context']==context and row['index']==block and row['status']=='COMPLETE','block identity/status')
    ck.yes(not row.get('cleanup_errors') and row['start_ns']<row['end_ns'],'block lifecycle')
    code=row['keycode'];win=row['window'];away=row['new']['result']['away']
    ck.yes(type(code) is int and 8<=code<=255 and type(win) is int and win>0 and win==row['new']['result']['target'],'target/key identity')
    seed=row['seed']['result'];before=row['before']['result'];after=row['after']['result'];neutral=row['neutral']['result']
    ck.yes(not any(bytes.fromhex(seed['keymap'])) and seed['focus']==win,'neutral focused seed')
    ck.yes(before['keymap']==after['keymap'] and before['focus']==after['focus']==win,'unchanged measurement state/focus')
    expected=context!='UP';ck.yes(bitmap(before['keymap'],code)==expected,'actual witness state')
    ck.yes(not any(bytes.fromhex(neutral['keymap'])) and neutral['pointer_mask']&0x1f00==0,'neutral cleanup')
    ops=row['mutation']['result']['operations']
    exp={'UP':[], 'DOWN':['edge'], 'EDGE_BURST':['edge']*17,'FOCUS_RETURN':['focus','edge','focus']}[context]
    ck.yes([x['kind'] for x in ops]==exp,'actual mutation operation count')
    edges=[x for x in ops if x['kind']=='edge']
    for k,e in enumerate(edges):ck.yes(e['keycode']==code and e['down'] is (k%2==0) and e['before_ns']<=e['after_ns'],'actual writer edge')
    if context=='FOCUS_RETURN':ck.yes(ops[0]['window']==away and ops[-1]['window']==win,'focus excursion')
    ck.yes(row['mutation']['after_ns']<=row['before']['before_ns'],'writer-before-witness order')
    histories={a:[] for a in (*ARMS,'OTHER_CONNECTION_FOCUS')}
    first=row['first_ordinals']
    for arm,boot in row['bootstrap'].items():
        ck.yes(first[arm]==len(boot['events']) and boot['history_count']==len(boot['events']),'bootstrap ordinal count')
        ck.yes(boot['mode']=='FOCUS_SYNC' and boot['native_errors']==0,'bootstrap mode')
    foreign=row['foreign_control'];fn=foreign['native']
    ck.yes(foreign['mode']=='OTHER_CONNECTION_FOCUS' and foreign['events']==[],'separate connection did not drain observer')
    ck.yes(fn['r1']==fn['r0'] and fn['other_r1']-fn['other_r0']==1 and fn['focus_r1']-fn['focus_r0']==1,'separate connection request identity')
    ck.yes(fn['focus_window']==win and foreign['decision']['shift_down'] is False,'separate connection stale seed')
    ck.yes(foreign['decision']['authority']=='none' and foreign['decision']['input_dispatched'] is False,'separate control neutral flags')
    ck.yes(len(row['samples'])==cycles*3,'acquisition denominator')
    lastend=foreign['wall_after_ns'];per_arm={a:[] for a in ARMS};req={a:0 for a in ARMS}
    orders=[ARMS,(ARMS[1],ARMS[2],ARMS[0]),(ARMS[2],ARMS[0],ARMS[1]),tuple(reversed(ARMS)),(ARMS[0],ARMS[2],ARMS[1]),(ARMS[1],ARMS[0],ARMS[2])]
    if mode=='construct':orders[4]=(ARMS[2],ARMS[1],ARMS[0]) # explicitly retained old construction list
    for i,s in enumerate(row['samples']):
        pair,pos=divmod(i,3);arm=orders[(pair+block+index)%6][pos];n=s['native']
        ck.yes(s['pair']==pair and type(s['pair']) is int and s['position']==pos and s['mode']==arm,'sample identity/order')
        ck.yes(s['phase']==('first' if pair==0 else 'warmup' if pair<3 else 'measured'),'sample phase')
        for v in (s['wall_before_ns'],s['wall_after_ns'],s['cpu_before_ns'],s['cpu_after_ns'],*n.values()):ck.yes(integer(v),'timestamp/counter type')
        ck.yes(lastend<=s['wall_before_ns']<=n['t0']<=n['focus_t0']<=n['focus_t1']<=n['t1']<=s['wall_after_ns'],'clock/order brackets')
        ck.yes(row['before']['after_ns']<=s['wall_before_ns'] and s['wall_after_ns']<=row['after']['before_ns'],'witness acquisition bracketing')
        ck.yes(s['cpu_before_ns']<=s['cpu_after_ns'] and s['native_errors']==0,'CPU/error state');lastend=s['wall_after_ns']
        ck.yes(n['focus_window']==win and s['focus_calls']==1 and n['focus_r1']-n['focus_r0']==1,'actual focus reply/request')
        count=1 if arm=='FOCUS_PIGGYBACK' else 2
        ck.yes(n['r1']-n['r0']==count and n['other_r0']==n['other_r1']==0,'same connection request count')
        ck.yes(n['focus_r0']==n['r0'] and n['p1']>=n['r1']-1 and n['p1']>=n['p0'],'processed reply fence')
        ck.yes(n['drain_r1']==n['drain_r0'],'drain is request-free')
        ck.yes(s['query_calls']==int(arm=='FOCUS_QUERY') and s['sync_calls']==int(arm=='FOCUS_SYNC'),'API call accounting')
        if arm=='FOCUS_QUERY':
            ck.yes(s['events']==[] and s['history_count']==0 and s['keymap']==before['keymap'],'query raw bitmap')
            down=bitmap(s['keymap'],code)
        else:
            ck.yes(s['keymap'] is None,'event path has no query bitmap')
            for e in s['events']:ck.yes(n['t0']<=e['dequeued_ns']<=n['t1'],'event dequeue timestamp')
            histories[arm].extend(s['events']);ck.yes(s['history_count']==len(histories[arm]),'history accounting')
            down=reduce_events(histories[arm],first[arm],win,code,seed['keymap'],ck)
        ck.yes(down==expected and s['decision']['shift_down'] is down,'state reconstructed from primitive bytes')
        ck.yes(s['decision']['status']==('WAIT' if down else 'TYPE') and s['disposition']==s['decision']['status'],'disposition')
        ck.yes(s['decision']['authority']=='none' and s['decision']['input_dispatched'] is False,'no authority')
        if pair>=3:
            per_arm[arm].append(s['wall_after_ns']-s['wall_before_ns']);req[arm]+=count
    for arm in ('FOCUS_SYNC','FOCUS_PIGGYBACK'):
        types=[e['type'] for e in histories[arm]]
        expected_types={'UP':[],'DOWN':[2],'EDGE_BURST':[t for _ in range(8) for t in (2,3)]+[2],'FOCUS_RETURN':[10,9,11]}[context]
        ck.yes(types==expected_types,'full delivered event trace')
    def canonical(events):return [{k:v for k,v in e.items() if k not in ('ordinal','dequeued_ns','server_time_ms')} for e in events]
    ck.yes(canonical(histories['FOCUS_SYNC'])==canonical(histories['FOCUS_PIGGYBACK']),'paired event content equality')
    med={a:statistics.median(v) for a,v in per_arm.items()}
    return {'context':context,'index':index,'block':block,'medians_ns':med,'request_counts':req,
            'piggyback_query_ratio':med['FOCUS_PIGGYBACK']/med['FOCUS_QUERY'],
            'piggyback_sync_ratio':med['FOCUS_PIGGYBACK']/med['FOCUS_SYNC'],'foreign_mismatch':int(expected)}

def audit(study,data,mode='allocation'):
    study=Path(study);data=Path(data);ck=Checks();contract=load(study/'EXECUTION_CONTRACT.json');records=[]
    if mode=='allocation':
        f=load(study/'FREEZE.json')
        for n,h in f['files'].items():ck.yes(digest((study/n).read_bytes())==h,'frozen source '+n)
        frozen=digest((study/'FREEZE.json').read_bytes())
    else:frozen=None
    blocks=8 if mode=='allocation' else 2;cycles=27 if mode=='allocation' else 7
    ck.yes({p.name for p in data.glob('batch-*')}=={f'batch-{i}' for i in range(4)},'batch denominator')
    for idx,context in enumerate(CONTEXTS):
        root=data/f'batch-{idx}';start=load(root/'START.json');end=load(root/'END.json');external=load(root/'EXTERNAL.json')
        ck.yes(start['mode']==mode and start['index']==idx and start['context']==context and start['blocks']==blocks and start['cycles']==cycles,'batch identity')
        ck.yes(start['freeze_sha256']==end['freeze_sha256']==frozen,'batch source freeze')
        ck.yes(type(external['returncode']) is int and external['returncode']==0 and external['timeout'] is False and end['returncode']==0 and end['complete']==blocks,'actual outer/batch exits')
        ck.yes(external['pid']==start['pid'] and external['before_ns']<=start['before_ns']<end['after_ns']<=external['after_ns'],'outer process/clock identity')
        ck.yes(external['argv'][:3]==[contract['python'],'-B',contract['source_root']+'/run.py'] and external['argv'][3:5]==[mode,str(idx)],'frozen actual runner argv')
        ck.yes((root/'EXTERNAL.stderr').read_bytes()==b'','no runner stderr')
        ck.yes({p.name for p in root.glob('block-*.json')}=={f'block-{i:02}.json' for i in range(blocks)},'block file inventory')
        # Actual raw pipe strings and subprocess receipts; row copies must match replies.
        pipes={}
        for role in ('writer','witness'):
            p=load(root/f'{role}.process.json');raw=(root/f'{role}.stdout').read_bytes();err=(root/f'{role}.stderr').read_bytes()
            ck.yes(type(p['returncode']) is int and p['returncode']==0 and not p['forced_cleanup'] and p['unterminated_bytes_hex']=='','actor exit/framing')
            ck.yes(p['stdout_sha256']==digest(raw) and p['stderr_sha256']==digest(err) and err==b'','actual actor bytes')
            ck.yes(p['argv']==[contract['python'],'-B',contract['source_root']+'/actor.py',role],'actual actor source command')
            lines=raw.splitlines();parsed=[json.loads(x) for x in lines];ck.yes(parsed[0]['pid']==p['pid'] and parsed[0]['role']==role,'actor ready identity')
            req=[json.loads(bytes.fromhex(x['bytes_hex'])) for x in p['requests']]
            ck.yes(len(parsed)==len(req)+1,'request/reply denominator')
            replies={}
            for q,r in zip(req,parsed[1:]):ck.yes(q['id']==r['id'] and q['op']==r['op'],'pipe request/reply identity');replies[q['id']]=r
            pipes[role]=replies
        server=load(root/'server.json')
        ck.yes(type(server['returncode']) is int and server['returncode']==0 and server['socket_absent'] and server['auth_removed'],'server exit/cleanup')
        ck.yes('-auth' in server['argv'] and server['argv'][server['argv'].index('-nolisten')+1]=='tcp','private authenticated server')
        for block in range(blocks):
            row=load(root/f'block-{block:02}.json')
            for name,role,op in [('new','writer','new'),('seed','witness','seed'),('mutation','writer','mutate'),('before','witness','before'),('after','witness','after'),('release','writer','release'),('neutral','witness','neutral')]:
                ck.yes(row[name]==pipes[role][f'{op}-{block}'],'row binds original pipe '+name)
            records.append(audit_block(row,context,idx,block,cycles,mode,ck))
    cells={}
    for c in CONTEXTS:
        rs=[r for r in records if r['context']==c]
        cells[c]={'wall_ns':{a:summarize([r['medians_ns'][a] for r in rs]) for a in ARMS},
                  'piggyback_query_ratio':summarize([r['piggyback_query_ratio'] for r in rs]),
                  'piggyback_sync_ratio':summarize([r['piggyback_sync_ratio'] for r in rs])}
    ratio=statistics.median([r['piggyback_query_ratio'] for r in records])
    speed=ratio<=.80 and all(cells[c]['piggyback_query_ratio']['median']<=1.00 for c in CONTEXTS)
    return {'status':'PASS_FOCUS_REPLY_PIGGYBACK_ACCOUNTING','speed_status':('PASS_SCOPED_20_PERCENT_ACQUISITION_GAIN' if speed else 'HOLD_PIGGYBACK_ACQUISITION_TRADEOFF') if mode=='allocation' else 'CONSTRUCTION_NOT_BENCHMARK',
            'checks':ck.n,'errors':[],'blocks':len(records),'samples':len(records)*cycles*3,'measured_samples':len(records)*(cycles-3)*3,
            'foreign_controls':len(records),'foreign_mismatches':sum(r['foreign_mismatch'] for r in records),
            'request_counts':{a:sum(r['request_counts'][a] for r in records) for a in ARMS},
            'paired_ratio_median':ratio,'cells':cells,'records':records,'mode':mode}
if __name__=='__main__':
    try:result=audit(Path(__file__).resolve().parent,Path(sys.argv[1]),sys.argv[2] if len(sys.argv)>2 else 'allocation');code=0
    except (AuditError,KeyError,ValueError,OSError,TypeError,IndexError) as e:result={'status':'FAIL_RAW_AUDIT','errors':[str(e)]};code=1
    print(json.dumps(result,sort_keys=True,indent=2));raise SystemExit(code)

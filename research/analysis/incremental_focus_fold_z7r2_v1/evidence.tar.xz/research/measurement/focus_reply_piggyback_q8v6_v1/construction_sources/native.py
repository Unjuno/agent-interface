"""New measured focus+key acquisition; unchanged predecessor policy for both event arms."""
from __future__ import annotations
import ctypes as C
from pathlib import Path
import time
from predecessor_policy import classify
MODES=('FOCUS_QUERY','FOCUS_SYNC','FOCUS_PIGGYBACK','OTHER_CONNECTION_FOCUS')
U64=('t0','t1','r0','r1','p0','p1','focus_r0','focus_r1','focus_t0','focus_t1','drain_r0','drain_r1','other_r0','other_r1','focus_window')
class Event(C.Structure):
    _fields_=[(k,C.c_uint64) for k in ('ordinal','window','server_ms','dequeued_ns')]+[(k,C.c_int) for k in ('type','send_event','keycode','mode','detail')]+[('keymap',C.c_ubyte*32)]
class Sample(C.Structure):
    _fields_=[(k,C.c_uint64) for k in U64]+[(k,C.c_int) for k in ('count','queries','syncs','focus_calls','errors')]+[('keymap',C.c_ubyte*32),('events',Event*96)]
def load():
    l=C.CDLL(str(Path(__file__).with_name('focus_reply.so')))
    l.fp_open.argtypes=[C.c_ulong,C.c_int,C.c_int];l.fp_open.restype=C.c_void_p
    l.fp_observe.argtypes=[C.c_void_p,C.c_int,C.POINTER(Sample)];l.fp_observe.restype=C.c_int
    l.fp_close.argtypes=[C.c_void_p];l.fp_close.restype=C.c_int
    for n in ('fp_sample_size','fp_event_size','fp_ulong_size'):getattr(l,n).restype=C.c_size_t
    if (l.fp_sample_size(),l.fp_event_size(),l.fp_ulong_size())!=(C.sizeof(Sample),C.sizeof(Event),C.sizeof(C.c_ulong)):
        raise RuntimeError('native ABI mismatch')
    return l
class Reader:
    def __init__(self,lib,window,code,seed,subscribed,epoch,foreign=False):
        self.lib=lib;self.window=window;self.code=code;self.seed=seed;self.epoch=epoch
        self.ptr=lib.fp_open(window,int(subscribed),int(foreign))
        if not self.ptr:raise RuntimeError('observer setup')
        self.history=[];self.first=0;self.s=Sample()
    def bootstrap(self):
        r=self.observe('FOCUS_SYNC');self.first+=len(self.history);self.history=[];return r
    def observe(self,mode):
        op=MODES.index(mode);a=time.perf_counter_ns();cpu0=time.process_time_ns()
        rc=self.lib.fp_observe(self.ptr,op,C.byref(self.s))
        if rc:raise RuntimeError('native acquisition error '+str(rc))
        s=self.s;events=[]
        for v in s.events[:s.count]:
            e=dict(ordinal=v.ordinal,type=v.type,send_event=bool(v.send_event),dequeued_ns=v.dequeued_ns)
            if v.type==11:e['keymap']=bytes(v.keymap).hex()
            elif v.type in (9,10):e.update(window=v.window,mode=v.mode,detail=v.detail)
            else:e.update(window=v.window,keycode=v.keycode,server_time_ms=v.server_ms)
            events.append(e)
        if op==0:
            m=bytes(s.keymap);down=bool(m[self.code//8]&(1<<(self.code%8)))
            decision=dict(status='WAIT' if down else 'TYPE',shift_down=down,authority='none',input_dispatched=False)
        else:
            self.history.extend(events)
            p=dict(epoch=self.epoch,expected_epoch=self.epoch,window=self.window,keycode=self.code,seed_keymap=self.seed,
                   seed_focused=True,first_ordinal=self.first,events=self.history,coverage_complete=True)
            decision=classify(p,'FOCUS_KEYMAP')
        # Focus result is a required output and eligibility input in every arm.
        # This is an observation disposition; it cannot emit task input.
        if s.focus_window!=self.window:
            disposition='FOCUS_UNKNOWN'
        else:disposition=decision['status']
        cpu1=time.process_time_ns();b=time.perf_counter_ns()
        return dict(mode=mode,wall_before_ns=a,wall_after_ns=b,cpu_before_ns=cpu0,cpu_after_ns=cpu1,
                    native={k:int(getattr(s,k)) for k in U64},query_calls=s.queries,sync_calls=s.syncs,
                    focus_calls=s.focus_calls,native_errors=s.errors,keymap=bytes(s.keymap).hex() if op==0 else None,
                    events=events,history_count=len(self.history),decision=decision,disposition=disposition)
    def close(self):
        if self.ptr:
            rc=self.lib.fp_close(self.ptr);self.ptr=None
            if rc:raise RuntimeError('observer close')

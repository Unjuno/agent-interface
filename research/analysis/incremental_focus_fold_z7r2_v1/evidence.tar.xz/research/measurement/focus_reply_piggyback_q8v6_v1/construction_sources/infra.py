"""Research IPC helpers, mechanically extracted unchanged from prior infrastructure."""
import hashlib,json,os,select,subprocess,time
def now(): return time.monotonic_ns()

def sha(b): return hashlib.sha256(b).hexdigest()

def save(p, o): p.write_text(json.dumps(o, sort_keys=True, indent=2)+'\n')

class Actor:
    def __init__(self, name, argv, env, out):
        self.name=name;self.argv=argv;self.out=out;self.buf=bytearray();self.records=[];self.requests=[]
        self.started=now();self.err=open(out/f'{name}.stderr','wb');self.raw=open(out/f'{name}.stdout','wb')
        self.p=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.err,env=env,bufsize=0)
        self.closed=False
    def drain(self, timeout=0):
        if self.closed: return
        r,_,_=select.select([self.p.stdout],[],[],timeout)
        if r:
            b=os.read(self.p.stdout.fileno(),65536)
            if b:
                self.raw.write(b);self.raw.flush();self.buf.extend(b)
                while b'\n' in self.buf:
                    line,_,rest=self.buf.partition(b'\n');self.buf[:]=rest
                    self.records.append(json.loads(line))
    def until(self, pred, timeout=2.0):
        end=time.monotonic()+timeout
        while True:
            matches=[r for r in self.records if pred(r)]
            if matches:return matches[-1]
            if time.monotonic()>end:raise TimeoutError(self.name+' reply deadline')
            self.drain(min(0.02,max(0,end-time.monotonic())))
            if self.p.poll() is not None:
                self.drain();matches=[r for r in self.records if pred(r)]
                if matches:return matches[-1]
                raise RuntimeError(f'{self.name} exited {self.p.returncode} before reply')
    def send(self, text):
        b=text.encode()+b'\n';self.requests.append(dict(ns=now(),bytes_hex=b.hex()))
        self.p.stdin.write(b);self.p.stdin.flush()
    def stop(self, command):
        if self.closed:return
        if self.p.poll() is None:self.send(command)
        end=time.monotonic()+2
        while self.p.poll() is None and time.monotonic()<end:self.drain(.01)
        forced=False
        if self.p.poll() is None:forced=True;self.p.kill()
        rc=self.p.wait(timeout=1)
        # Reap and retain any last pipe bytes without changing their contents.
        while True:
            b=os.read(self.p.stdout.fileno(),65536)
            if not b:break
            self.raw.write(b);self.buf.extend(b)
        while b'\n' in self.buf:
            line,_,rest=self.buf.partition(b'\n');self.buf[:]=rest
            self.records.append(json.loads(line))
        self.raw.close();self.err.close();self.p.stdin.close();self.p.stdout.close();self.closed=True
        save(self.out/f'{self.name}.process.json',dict(argv=self.argv,pid=self.p.pid,start_ns=self.started,end_ns=now(),
                returncode=rc,forced_cleanup=forced,requests=self.requests,unterminated_bytes_hex=self.buf.hex(),
                stdout_sha256=sha((self.out/f'{self.name}.stdout').read_bytes()),
                stderr_sha256=sha((self.out/f'{self.name}.stderr').read_bytes())))
        return rc


from pathlib import Path
import subprocess,sys,time,json,os,signal
root=Path(__file__).resolve().parent
mode,idx,namespace=sys.argv[1:];idx=int(idx);out=root/namespace/f'batch-{idx}'
out.parent.mkdir(exist_ok=True)
marker=out.parent/f'CONSUMED-{idx}.json'
with marker.open('x') as f:json.dump({'mode':mode,'index':idx,'time_ns':time.monotonic_ns()},f)
args=[sys.executable,'-B',str(root/'run.py'),mode,str(idx),str(out)]
a=time.monotonic_ns();p=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
timeout=False
try:so,se=p.communicate(timeout=20)
except subprocess.TimeoutExpired:
 timeout=True;os.killpg(p.pid,signal.SIGTERM)
 try:so,se=p.communicate(timeout=3)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);so,se=p.communicate(timeout=3)
b=time.monotonic_ns();out.mkdir(exist_ok=True)
(out/'EXTERNAL.stdout').write_bytes(so);(out/'EXTERNAL.stderr').write_bytes(se)
record={'argv':args,'pid':p.pid,'supervisor_pid':os.getpid(),'returncode':p.returncode,'before_ns':a,'after_ns':b,'timeout':timeout}
(out/'EXTERNAL.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
print(json.dumps(record));print(se.decode()[-4000:])
raise SystemExit(0 if p.returncode==0 and not timeout else 1)

# Stopped duplicate synchronization study — construction only

**STOP_PARALLEL_SCOPE_BEFORE_FORMAL**. Just-in-time GitHub branch/Issue inspection located #4389, which owns the same focus-reply piggyback acquisition question. This q8v6 proposal is retired without a formal allocation. Do not run run.py allocation, do not score its construction as formal science and do not create a replacement piggyback experiment.

All8 excluded construction blocks/168 acquisition records, source, actual exits and audit/control evidence are preserved. The preliminary repeated arm-order defect was fixed before any freeze; KeymapNotify byte0 was excluded only from the paired semantic comparison because valid keys start at8. Original source versions and failed audit remain. The onset/byte0 cause is not isolated. The corrected construction audit's PASS label is construction-only, not a qualified performance result.

Formal calls0, formal rows0, public/local formal freeze0, remote writes0. This bundle has no shared-runtime or foreign-branch changes. Candidate source/native binary is retained for inspection, not invoked by the new incremental study's verifier. The parent experiment n6k4 remains unchanged and its publication belongs to #4405.

A separate pure-computation study under research/analysis/incremental_focus_fold_z7r2_v1 changes ONLY prefix-reduction storage/computation, not acquisition or synchronization. Do not combine its result with this unfinished study or with the other owner's future data.

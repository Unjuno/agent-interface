# Preserved construction

Eight excluded blocks ran in four one-use construction batches. All returned zero. State outputs and source-request counts agreed with the intended boundary. Construction used seven cycles; none enters the 27-cycle allocation.

A code review found the six-element rotation list repeated PSQ and omitted QPS. The original run.py and all original construction outputs are retained under construction_sources/ and construction-01/. Before formal freeze, only that permutation was corrected. Pure schedule tests check all six permutations and position balance. This changes sample ordering, not the state reducer, source, method or scientific threshold. Construction audit uses the retained original schedule explicitly; no construction timing is a benchmark.

The initial archive-inspection command also attempted nonexistent measure.py and exited2 after extracting correctly; no experiment was invoked by that read.

The first construction auditor rejected paired complete keymap byte equality in the focus-return condition. Retained raw vectors differed only at byte0 (keycodes0..7), outside the frozen predecessor classifier domain8..255; all tested Shift bits matched. The v1 auditor and FAIL stdout are retained. Before formal freeze, the paired-content check was scoped to bytes1..31 while preserving every original raw byte. The cause of byte0 variability is not isolated or claimed. State-bit and full query-map checks remain unchanged.

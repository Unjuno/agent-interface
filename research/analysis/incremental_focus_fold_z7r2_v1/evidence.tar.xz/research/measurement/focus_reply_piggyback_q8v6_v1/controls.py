"""Effective, well-formed copied-evidence mutations; never executes live actors."""
from pathlib import Path
import json,shutil,sys,tempfile,hashlib
from audit import audit,AuditError
HERE=Path(__file__).resolve().parent

def check(data,mode):
    cases=[('decision','batch-1/block-00.json'),('requests','batch-0/block-00.json'),
           ('calls_boolean','batch-0/block-00.json'),('focus','batch-0/block-00.json'),
           ('missing_sample','batch-0/block-00.json'),('duplicate_sample','batch-0/block-00.json'),
           ('ordinal','batch-1/block-00.json'),('map_bit','batch-3/block-00.json'),
           ('clock','batch-0/block-00.json'),('foreign_connection','batch-1/block-00.json'),
           ('exit_boolean','batch-0/EXTERNAL.json'),('disposition','batch-0/block-00.json')]
    result=[]
    for name,rel in cases:
        with tempfile.TemporaryDirectory(prefix='focus-piggyback-audit-') as tmp:
            target=Path(tmp)/'data';shutil.copytree(data,target)
            baseline=audit(HERE,target,mode)
            path=target/rel;before=path.read_bytes();r=json.loads(before)
            if name=='decision':r['samples'][0]['decision']['shift_down']=False
            elif name=='requests':r['samples'][0]['native']['r1']+=1
            elif name=='calls_boolean':r['samples'][0]['focus_calls']=True
            elif name=='focus':r['samples'][0]['native']['focus_window']+=1
            elif name=='missing_sample':r['samples'].pop()
            elif name=='duplicate_sample':r['samples'][1]=r['samples'][0]
            elif name=='ordinal':
                next(s for s in r['samples'] if s['events'])['events'][0]['ordinal']+=1
            elif name=='map_bit':
                e=next(e for s in r['samples'] for e in s['events'] if e['type']==11)
                b=bytearray.fromhex(e['keymap']);b[r['keycode']//8]^=1<<(r['keycode']%8);e['keymap']=b.hex()
            elif name=='clock':r['samples'][0]['wall_after_ns']=r['samples'][0]['wall_before_ns']-1
            elif name=='foreign_connection':r['foreign_control']['native']['r1']+=1
            elif name=='exit_boolean':r['returncode']=False
            elif name=='disposition':r['samples'][0]['disposition']='WAIT'
            after=(json.dumps(r,sort_keys=True,indent=2)+'\n').encode()
            if before==after:raise RuntimeError('no-op control '+name)
            path.write_bytes(after)
            try:audit(HERE,target,mode)
            except AuditError as e:
                result.append({'name':name,'normal_copy_passed':baseline['errors']==[],'changed':True,'rejected':True,
                               'reason':str(e),'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest()})
            else:raise RuntimeError('mutation accepted '+name)
    return {'status':'PASS_EFFECTIVE_EVIDENCE_CONTROLS','count':len(result),'controls':result,'live_runs':0}
if __name__=='__main__':print(json.dumps(check(Path(sys.argv[1]),sys.argv[2] if len(sys.argv)>2 else 'allocation'),sort_keys=True,indent=2))

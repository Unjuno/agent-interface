import unittest,ast,copy,hashlib,json
from pathlib import Path
from predecessor_policy import classify
HERE=Path(__file__).resolve().parent
class Contract(unittest.TestCase):
    def base(self):return dict(epoch='e',expected_epoch='e',window=101,keycode=50,seed_keymap='00'*32,seed_focused=True,first_ordinal=0,events=[],coverage_complete=True)
    def edge(self,n,kind):return dict(ordinal=n,type=kind,send_event=False,window=101,keycode=50)
    def focus(self,n,kind):return dict(ordinal=n,type=kind,send_event=False,window=101,mode=0,detail=3)
    def km(self,n,down):
        b=bytearray(32);b[6]=4 if down else 0
        return dict(ordinal=n,type=11,send_event=False,keymap=b.hex())
    def result(self,p):return classify(p,'FOCUS_KEYMAP')['status']
    def test_seed(self):self.assertEqual(self.result(self.base()),'TYPE')
    def test_down(self):
        p=self.base();p['events']=[self.edge(0,2)];self.assertEqual(self.result(p),'WAIT')
    def test_down_up_down(self):
        p=self.base();p['events']=[self.edge(0,2),self.edge(1,3),self.edge(2,2)];self.assertEqual(self.result(p),'WAIT')
    def test_focus_loss(self):
        p=self.base();p['events']=[self.focus(0,10)];self.assertEqual(self.result(p),'UNKNOWN')
    def test_rebase(self):
        p=self.base();p['events']=[self.focus(0,10),self.focus(1,9),self.km(2,True)];self.assertEqual(self.result(p),'WAIT')
    def test_postrebase_edge(self):
        p=self.base();p['events']=[self.focus(0,10),self.focus(1,9),self.km(2,True),self.edge(3,3)];self.assertEqual(self.result(p),'TYPE')
    def test_missing_map(self):
        p=self.base();p['events']=[self.focus(0,10),self.focus(1,9)];self.assertEqual(self.result(p),'UNKNOWN')
    def test_synthetic(self):
        p=self.base();e=self.edge(0,2);e['send_event']=True;p['events']=[e];self.assertEqual(self.result(p),'UNKNOWN')
    def test_gap(self):
        p=self.base();p['events']=[self.edge(2,2)];self.assertEqual(self.result(p),'UNKNOWN')
    def test_boolean_code(self):
        p=self.base();p['keycode']=True;self.assertEqual(self.result(p),'UNKNOWN')
    def test_epoch(self):
        p=self.base();p['epoch']='old';self.assertEqual(self.result(p),'UNKNOWN')
    def test_incomplete(self):
        p=self.base();p['coverage_complete']=False;self.assertEqual(self.result(p),'UNKNOWN')
    def test_unused_bitmap_byte(self):
        p=self.base();e=self.km(1,True);e['keymap']='ff'+e['keymap'][2:];p['events']=[self.focus(0,9),e];self.assertEqual(self.result(p),'WAIT')
    def test_retained_policy(self):
        wanted=json.loads((HERE/'LINEAGE.json').read_text())['unchanged']['predecessor_policy.py']
        self.assertEqual(hashlib.sha256((HERE/'predecessor_policy.py').read_bytes()).hexdigest(),wanted)
    def test_actual_schedule(self):
        tree=ast.parse((HERE/'run.py').read_text());expr=next(n.value for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='orders' for t in n.targets))
        arms=('FOCUS_QUERY','FOCUS_SYNC','FOCUS_PIGGYBACK')
        orders=eval(compile(ast.Expression(expr),'<pure-schedule>','eval'),{'__builtins__':{},'ARMS':arms,'tuple':tuple,'reversed':reversed})
        self.assertEqual(len(set(orders)),6)
        for off in range(6):
            seq=[orders[(k+off)%6] for k in range(3,27)]
            for pos in range(3):
                for arm in arms:self.assertEqual(sum(o[pos]==arm for o in seq),8)
    def test_neutrality(self):
        r=classify(self.base(),'FOCUS_KEYMAP');self.assertEqual(r['authority'],'none');self.assertIs(r['input_dispatched'],False)
if __name__=='__main__':unittest.main()

"""Serial one-use stage supervisor with retained actual process outcomes."""
import os,sys,json,subprocess,time,signal,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def main():
    stage=int(sys.argv[1]);base=ROOT/'formal';base.mkdir(exist_ok=True)
    if not 0<=stage<=6:raise ValueError('stage outside plan')
    if stage:
        previous=json.loads((base/f'stage-{stage-1}'/'END.json').read_text())
        if previous['status']!='COMPLETE':raise RuntimeError('previous stage incomplete')
    out=base/f'stage-{stage}';out.mkdir(exist_ok=False)
    (out/'START.json').write_text(json.dumps(dict(pid=os.getpid(),stage=stage,start_ns=time.monotonic_ns()),sort_keys=True)+'\n')
    jobs=[('correctness',0)] if not stage else [('bench',i) for i in range((stage-1)*5,stage*5)]
    env={k:v for k,v in os.environ.items() if k not in ('DISPLAY','XAUTHORITY','WAYLAND_DISPLAY')}
    env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONHASHSEED']='0'
    end=dict(status='COMPLETE',stage=stage,processes=[])
    for kind,index in jobs:
        argv=[sys.executable,'-S','-B',str(ROOT/'evaluate.py'),kind,str(index)]
        t0=time.monotonic_ns()
        p=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        timeout=False
        try:stdout,stderr=p.communicate(timeout=15)
        except subprocess.TimeoutExpired:
            timeout=True;os.killpg(p.pid,signal.SIGTERM)
            try:stdout,stderr=p.communicate(timeout=2)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);stdout,stderr=p.communicate()
        t1=time.monotonic_ns();name=f'{kind}-{index}'
        (out/(name+'.jsonl')).write_bytes(stdout);(out/(name+'.stderr')).write_bytes(stderr)
        receipt=dict(kind=kind,index=index,pid=p.pid,argv=argv,returncode=p.returncode,timeout=timeout,
                     start_ns=t0,end_ns=t1,stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest())
        (out/(name+'.process.json')).write_text(json.dumps(receipt,indent=2)+'\n');end['processes'].append(name)
        if timeout or p.returncode!=0:
            end['status']='STOP_PROCESS';break
    end['end_ns']=time.monotonic_ns()
    (out/'END.json').write_text(json.dumps(end,indent=2)+'\n')
    print(json.dumps(end))
    return 0 if end['status']=='COMPLETE' else 2
if __name__=='__main__':raise SystemExit(main())

import unittest,copy
from fold import Fold
from reference import classify
from corpus import context,event,partitions,generated
class Tests(unittest.TestCase):
    def check(self,word,mode='FOCUS_KEYMAP'):
        ctx=context();es=[event(x,i) for i,x in enumerate(word)];f=Fold(ctx,mode)
        out=[]
        for i in range(len(es)+1):
            got=f.result() if not i else f.extend(es[i-1:i]);self.assertEqual(got,classify(dict(ctx,events=es[:i]),mode));out.append(got['status'])
        return out
    def test_recoverable_unknown(self):self.assertEqual(self.check(['O','I','K1','U']),['TYPE','UNKNOWN','UNKNOWN','WAIT','TYPE'])
    def test_poison_does_not_heal(self):self.assertEqual(self.check(['X','I','K1'])[-1],'UNKNOWN')
    def test_pending_edge_then_recovery(self):self.assertEqual(self.check(['I','D','I','K0'])[-1],'TYPE')
    def test_unrequested_bitmap_poison(self):self.assertEqual(self.check(['K0','I','K1'])[-1],'UNKNOWN')
    def test_edges_mode(self):self.check(['O','I','K1','U'],'KEY_EDGES')
    def test_empty_batches(self):
        f=Fold(context());x=f.result();self.assertEqual(f.extend([]),x);self.assertEqual(f.visited,0)
    def test_split_independence(self):
        e=[event(x,i) for i,x in enumerate(['D','O','I','K0','D','U'])]
        for cut in range(len(e)+1):
            f=Fold(context());f.extend(e[:cut]);self.assertEqual(f.extend(e[cut:]),classify(dict(context(),events=e),'FOCUS_KEYMAP'))
    def test_mutable_input_not_retained(self):
        c=context();e=event('D',0);f=Fold(c);f.extend([e]);c['window']=7;e['type']=3;self.assertEqual(f.result()['status'],'WAIT')
    def test_illegal_batch(self):self.assertEqual(Fold(context()).extend(None)['status'],'UNKNOWN')
    def test_context_mismatch(self):self.assertEqual(Fold(dict(context(),expected_epoch='b')).result()['status'],'UNKNOWN')
    def test_ordinal_bool(self):self.assertEqual(Fold(context()).extend([dict(event('D',0),ordinal=True)])['status'],'UNKNOWN')
    def test_uint_boundary(self):
        c=dict(context(),first_ordinal=2**63-1);f=Fold(c);e=event('D',2**63-1);self.assertEqual(f.extend([e])['status'],'WAIT');self.assertEqual(f.extend([event('U',2**63)])['status'],'UNKNOWN')
    def test_no_authority(self):self.assertEqual(Fold(context()).result()['authority'],'none')
    def test_small_excluded_corpus(self):
        for c in generated(1):
            f=Fold(c['context'],c['mode']);self.assertEqual(f.extend(c['events']),classify(dict(c['context'],events=c['events']),c['mode']))
    def test_storage_shape(self):
        f=Fold(context());f.extend([event('D',0)]);self.assertFalse(hasattr(f,'__dict__'));self.assertEqual(len(f.__slots__),10)
    def test_non_target(self):self.assertEqual(self.check(['P'])[-1],'TYPE')
if __name__=='__main__':unittest.main()

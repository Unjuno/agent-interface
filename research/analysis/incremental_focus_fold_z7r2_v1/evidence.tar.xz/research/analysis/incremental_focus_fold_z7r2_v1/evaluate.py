"""One-use pure-code evaluation; never opens a display or loads native code."""
from pathlib import Path
import sys,json,time,os,hashlib
from fold import Fold
from reference import classify
ROOT=Path(__file__).resolve().parent

def sha(data):return hashlib.sha256(data).hexdigest()
def dump(obj):return json.dumps(obj,sort_keys=True,separators=(',',':'))
def check_sources():
    freeze=json.loads((ROOT/'FREEZE.json').read_text())
    for name,h in freeze['files'].items():
        if sha((ROOT/name).read_bytes())!=h:raise RuntimeError('source mismatch '+name)

def differential(case):
    es=case['events'];mode=case['mode'];ctx=case['context'];outputs={}
    before=dump(case)
    for key,ends in case['partitions'].items():
        f=Fold(ctx,mode);last=0;steps=[]
        for end in ends:
            a=f.extend(es[last:end]);b=classify(dict(ctx,events=es[:end]),mode)
            steps.append(dict(end=end,candidate=a,reference=b,visited=f.visited))
            last=end
        outputs[key]=steps
    return dict(id=case['id'],input_sha256=sha(before.encode()),input_unchanged=before==dump(case),outputs=outputs)

def benchmark(spec):
    # Input acquisition, imports, batch construction and serialization are excluded.
    inp=json.loads((ROOT/'BENCH_INPUTS.json').read_text())[str(spec['length'])]
    es=inp['events'];ctx=inp['context'];mode='FOCUS_KEYMAP'
    batches=[es[i:i+spec['batch']] for i in range(0,len(es),spec['batch'])]
    before=dump(inp);results={}
    for arm in spec['order']:
        w0=time.perf_counter_ns();c0=time.process_time_ns()
        outputs=[]
        if arm=='FULL_PREFIX':
            history=[]
            for batch in batches:
                history.extend(batch);outputs.append(classify(dict(ctx,events=history),mode))
            visited=None
        else:
            f=Fold(ctx,mode)
            for batch in batches:outputs.append(f.extend(batch))
            visited=f.visited
        c1=time.process_time_ns();w1=time.perf_counter_ns()
        results[arm]=dict(wall_before_ns=w0,wall_after_ns=w1,cpu_before_ns=c0,cpu_after_ns=c1,
                          outputs=outputs,visited=visited)
    return dict(spec=spec,pid=os.getpid(),affinity=sorted(os.sched_getaffinity(0)),
                input_sha256=sha(before.encode()),input_unchanged=dump(inp)==before,arms=results)

def main():
    check_sources();os.sched_setaffinity(0,{json.loads((ROOT/'ENVIRONMENT.json').read_text())['cpu']})
    kind,index=sys.argv[1:];index=int(index)
    if kind=='correctness':
        cases=json.loads((ROOT/'CASES.json').read_text())
        for case in cases:print(dump(differential(case)),flush=True)
    elif kind=='bench':
        specs=json.loads((ROOT/'BENCH_PLAN.json').read_text())
        print(dump(benchmark(specs[index])),flush=True)
    else:raise ValueError('unknown evaluation')
if __name__=='__main__':main()

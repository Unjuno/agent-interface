"""Finite protocol corpus, not new X11 observations or natural event sampling."""
import itertools,copy,json
from pathlib import Path
ALPHABET=('D','U','P','I','O','K0','K1','X')

def context(down=False):
    keymap=bytearray(32)
    if down:keymap[6]=4
    return dict(epoch='study-epoch',expected_epoch='study-epoch',window=101,keycode=50,
                seed_keymap=keymap.hex(),seed_focused=True,first_ordinal=0,coverage_complete=True)

def event(symbol,index):
    base=dict(ordinal=index,send_event=False)
    if symbol in ('D','U','P'):return dict(base,type=3 if symbol=='U' else 2,window=101,keycode=51 if symbol=='P' else 50)
    if symbol in ('I','O'):return dict(base,type=9 if symbol=='I' else 10,window=101,mode=0,detail=0)
    if symbol in ('K0','K1'):return dict(base,type=11,keymap=context(symbol=='K1')['seed_keymap'])
    return dict(base,type=99)

def partitions(n):
    return {'each':[0]+list(range(1,n+1))+[n], 'split':[0,n//2,n], 'whole':[0,n]}

def generated(max_length=3):
    rows=[]
    for size in range(max_length+1):
        for word in itertools.product(ALPHABET,repeat=size):
            for down in (False,True):
                for mode in ('KEY_EDGES','FOCUS_KEYMAP'):
                    rows.append(dict(id=f'g{len(rows):05}',kind='generated',mode=mode,context=context(down),
                                     events=[event(x,i) for i,x in enumerate(word)]))
    # Typed malformed events followed by a genuine focus+map. Poison must not heal.
    bad=[]
    for field,value in [('ordinal',True),('ordinal',1),('ordinal',-1),('send_event',True),('send_event',0),
                        ('type',True),('type',None),('window',102),('window',True),('keycode',True),('keycode',7),('keycode',256)]:
        e=event('D',0);e[field]=value;bad.append(e)
    bad += [dict(event('I',0),mode=4),dict(event('I',0),detail=True),dict(event('K0',0),keymap='00'),[]]
    for j,e in enumerate(bad):
        for mode in ('KEY_EDGES','FOCUS_KEYMAP'):
            rows.append(dict(id=f'e{j:02}-{mode}',kind='invalid_event',mode=mode,context=context(),events=[e,event('I',1),event('K1',2)]))
    edits=[('epoch',''),('expected_epoch','foreign'),('window',True),('keycode',256),('first_ordinal',True),
           ('seed_focused',1),('coverage_complete',False),('seed_keymap','ff')]
    for j,(k,v) in enumerate(edits):
        for mode in ('KEY_EDGES','FOCUS_KEYMAP'):
            ctx=context();ctx[k]=v
            rows.append(dict(id=f'c{j:02}-{mode}',kind='invalid_context',mode=mode,context=ctx,events=[event('I',0),event('K1',1)]))
    return rows

def all_cases(root,max_length=3,retained=True):
    cases=generated(max_length)
    if retained:
        for p in sorted((Path(root)/'retained').glob('batch-*/block-*.json')):
            d=json.loads(p.read_text());index=int(p.parent.name.split('-')[-1]);block=d['index']
            batches=[s['events'] for s in d['samples'] if s['mode']=='EVENT_SYNC']
            ctx=context();ctx.update(epoch=f'e-{index}-{block}',expected_epoch=f'e-{index}-{block}',
                window=d['window'],keycode=d['keycode'],seed_keymap=d['seed']['result']['keymap'],first_ordinal=d['first_ordinal'])
            ends=[0];n=0
            for b in batches:n+=len(b);ends.append(n)
            cases.append(dict(id=f'r{index}-{block}',kind='retained',mode='FOCUS_KEYMAP',context=ctx,
                events=[e for b in batches for e in b],partitions={'original_batches':ends},
                source=str(p.relative_to(root)),old_decisions=[s['decision'] for s in d['samples'] if s['mode']=='EVENT_SYNC']))
    for c in cases:c.setdefault('partitions',partitions(len(c['events'])))
    return cases

def benchmark_events(length):
    # Valid repeatedly observed focus intervals, target edges and other-key events.
    word=('D','U','O','I','K0','D','P','U')
    return [event(word[i%8],i) for i in range(length)]

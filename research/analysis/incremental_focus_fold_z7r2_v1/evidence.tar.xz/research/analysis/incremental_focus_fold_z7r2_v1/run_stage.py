"""Outer synchronous supervisor; it records actual return, not inferred success."""
from pathlib import Path
import sys,subprocess,json,time,signal,os
ROOT=Path(__file__).resolve().parent

def main():
    stage=int(sys.argv[1]);path=ROOT/'formal'/f'stage-{stage}'
    if path.exists():raise RuntimeError('stage already consumed')
    argv=[sys.executable,'-S','-B',str(ROOT/'execute.py'),str(stage)]
    start=time.monotonic_ns()
    p=subprocess.Popen(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    timed=False
    try:out,err=p.communicate(timeout=30)
    except subprocess.TimeoutExpired:
        timed=True;os.killpg(p.pid,signal.SIGTERM)
        try:out,err=p.communicate(timeout=2)
        except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);out,err=p.communicate()
    finish=time.monotonic_ns()
    path.mkdir(parents=True,exist_ok=True)
    (path/'OUTER.stdout').write_bytes(out);(path/'OUTER.stderr').write_bytes(err)
    (path/'OUTER.json').write_text(json.dumps(dict(argv=argv,pid=p.pid,returncode=p.returncode,timeout=timed,start_ns=start,end_ns=finish),indent=2)+'\n')
    print(json.dumps(dict(stage=stage,returncode=p.returncode,timeout=timed)))
    return 0 if p.returncode==0 and not timed else 2
if __name__=='__main__':raise SystemExit(main())

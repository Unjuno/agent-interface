# Agent Interface retained research delivery

Primary completed study: research/analysis/incremental_focus_fold_z7r2_v1 — offline contract and local CPU evaluation. Run its verify.py with Python -S -B to verify retained data without repeating measurements.

Stopped construction: research/measurement/focus_reply_piggyback_q8v6_v1 — STOP_PARALLEL_SCOPE_BEFORE_FORMAL on finding owner #4389. No formal result or freeze. All excluded construction/source/failure records preserved; do not run it.

GitHub writes/PR/main changes were unavailable in this session. No remote branch was created. The patch contains additions only, generated from a temporary local staging tree, not a commit with current remote main as its parent. Recheck scope, paths and exact head before a permitted publication. #2107 and the global ROADMAP remain open. Prior n6k4 publication belongs to #4405.

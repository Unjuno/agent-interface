candidate fixture: research/doom/session_map01_v12.py

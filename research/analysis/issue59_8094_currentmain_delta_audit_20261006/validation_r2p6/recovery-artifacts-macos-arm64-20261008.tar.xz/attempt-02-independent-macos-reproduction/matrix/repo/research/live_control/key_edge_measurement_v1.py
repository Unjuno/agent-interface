candidate fixture: research/live_control/key_edge_measurement_v1.py

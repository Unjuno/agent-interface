candidate fixture: research/doom/map01_overlap_controller_v39.py

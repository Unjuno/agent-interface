candidate fixture: research/live_control/input_owner_v12.py

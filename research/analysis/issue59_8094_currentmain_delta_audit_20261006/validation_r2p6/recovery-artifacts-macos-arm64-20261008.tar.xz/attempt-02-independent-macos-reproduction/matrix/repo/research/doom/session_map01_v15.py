candidate fixture: research/doom/session_map01_v15.py

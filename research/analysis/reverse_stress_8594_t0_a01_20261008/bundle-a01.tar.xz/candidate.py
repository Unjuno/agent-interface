#!/usr/bin/env python3
"""Finite reverse-stress candidate. No import from independently written audit."""
import argparse
import hashlib
import itertools
import json
import platform
import random
import time
from pathlib import Path


def canonical(x):
    return json.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def code_sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def legal(bits, names):
    p = dict(zip(names, bits))
    return (not p['audit_gap'] or p['receipt_late']) and (not p['renewal_overlap'] or p['lease_renewed'])


def replay(bits, case, s, unknown=False):
    f = dict(zip(s['flags'], bits))
    if not legal(bits, s['flags']):
        return {'status': 'ILLEGAL', 'events': []}
    if unknown:
        return {'status': 'UNKNOWN', 'events': [{'t_ms': 21, 'event': s['unknown_event']}]}
    cancel = s['default_cancel_ms']
    if f['queue_backlog'] and f['cancel_late']:
        cancel = max(cancel, s['sparse_branches']['queue_and_late_cancel_ms'])
    if f['observation_stale'] and f['focus_mutation'] and f['verification_deferred']:
        cancel = max(cancel, s['sparse_branches']['stale_focus_deferred_ms'])
    if f['renewal_overlap'] and f['scheduler_spike']:
        cancel = max(cancel, s['sparse_branches']['renewal_overlap_spike_ms'])
    if case == 'dense' and sum(bits) >= s['dense_threshold']:
        cancel = max(cancel, s['dense_trigger_cancel_ms'])
    service = s['slow_release_service_ms'] if f['release_slow'] else s['normal_release_service_ms']
    effect = cancel + service
    receipt = effect + (s['sparse_branches']['audit_receipt_lag_ms'] if f['receipt_late'] and f['audit_gap'] else 0)
    raw = [(0, 'LEASE_START'), (3 + 60 * f['observation_stale'], 'OBSERVATION'),
           (cancel, 'CANCEL_REQUEST'), (effect, 'RELEASE_EFFECT'),
           (receipt, 'RELEASE_RECEIPT'), (s['deadline_ms'], 'DEADLINE')]
    if f['focus_mutation']:
        raw.append((26, 'FOCUS_MUTATION'))
    rank = {e: i for i, e in enumerate(s['event_tie_order'])}
    raw.sort(key=lambda x: (x[0], rank[x[1]]))
    events = [{'t_ms': t, 'event': e} for t, e in raw]
    return {'status': 'FAIL' if receipt > s['deadline_ms'] else 'SAFE',
            'cancel_ms': cancel, 'effect_ms': effect, 'receipt_ms': receipt, 'events': events}


def mask(bits):
    return sum((1 << i) for i, b in enumerate(bits) if b)


def bits_from_mask(m, n):
    return tuple((m >> i) & 1 for i in range(n))


def upper_legal(prefix, s):
    """A legal componentwise upper envelope for every legal completion."""
    values = list(prefix) + [1] * (len(s['flags']) - len(prefix))
    fixed = len(prefix)
    ix = {x: i for i, x in enumerate(s['flags'])}
    changed = True
    while changed:
        changed = False
        for child, parent in s['dependencies']:
            c, p = ix[child], ix[parent]
            if values[p] == 0 and values[c] == 1:
                if c < fixed:
                    return None
                values[c] = 0
                changed = True
    if not legal(values, s['flags']):
        return None
    return tuple(values)


def reverse(case, s):
    cache = {}
    stats = {'visited_nodes': 0, 'pruned_infeasible': 0, 'pruned_safe_upper': 0,
             'pruned_dominated': 0, 'oracle_hits': 0}
    minima = []

    def ask(bits):
        m = mask(bits)
        if m not in cache:
            cache[m] = replay(bits, case, s)
        else:
            stats['oracle_hits'] += 1
        return cache[m]

    def dfs(prefix):
        stats['visited_nodes'] += 1
        lower_mask = mask(prefix)
        if any(lower_mask & m == m for m in minima):
            stats['pruned_dominated'] += 1
            return
        upper = upper_legal(prefix, s)
        if upper is None:
            stats['pruned_infeasible'] += 1
            return
        if ask(upper)['status'] != 'FAIL':
            stats['pruned_safe_upper'] += 1
            return
        if len(prefix) == len(s['flags']):
            minima.append(mask(upper))
            return
        dfs(prefix + (0,))
        dfs(prefix + (1,))

    dfs(())
    minima.sort()
    evidence = []
    for m in minima:
        base_bits = bits_from_mask(m, len(s['flags']))
        neighbors = []
        for i in range(len(s['flags'])):
            if base_bits[i]:
                b = tuple(0 if i == j else v for j, v in enumerate(base_bits))
                if legal(b, s['flags']):
                    neighbors.append({'mask': mask(b), 'trace': ask(b)})
        evidence.append({'mask': m, 'trace': ask(base_bits), 'safe_neighbors': neighbors})
    return {'minimal_evidence': evidence, 'minimal_masks': minima, 'stats': {
        **stats, 'unique_oracle_calls': len(cache), 'oracle_mask_sha256': hashlib.sha256(canonical(sorted(cache))).hexdigest(), 'oracle_masks': sorted(cache)}}


def baselines(case, s, budget):
    n = len(s['flags'])
    legal_masks = [i for i in range(1 << n) if legal(bits_from_mask(i, n), s['flags'])]
    w = lambda m: m.bit_count()
    portfolio = sorted((i for i in legal_masks if w(i) <= 2), key=lambda z: (w(z), z))
    if (1 << n) - 1 not in portfolio:
        portfolio.append((1 << n) - 1)
    rng = random.Random(s['random_seed'])
    shuffled = list(legal_masks)
    rng.shuffle(shuffled)
    gray = [i ^ (i >> 1) for i in range(1 << n)]
    gray_legal = [i for i in gray if i in set(legal_masks)]
    out = {}
    for name, seq in [('weight_lte2_portfolio', portfolio), ('random_equal_budget', shuffled[:budget]),
                      ('gray_equal_budget', gray_legal[:budget])]:
        out[name] = {'masks': seq, 'unique_oracle_calls': len(seq),
                     'failure_observations': sum(replay(bits_from_mask(x, n), case, s)['status'] == 'FAIL' for x in seq)}
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--spec', required=True)
    ap.add_argument('--out', required=True)
    args = ap.parse_args()
    s = json.loads(Path(args.spec).read_text())
    start = time.perf_counter_ns()
    results = {}
    for case in s['case_names']:
        t = time.perf_counter_ns()
        r = reverse(case, s)
        r['elapsed_ns'] = time.perf_counter_ns() - t
        r['baselines'] = baselines(case, s, r['stats']['unique_oracle_calls'])
        results[case] = r
    n = len(s['flags'])
    impossible = [(1 << s['flags'].index('audit_gap')), (1 << s['flags'].index('renewal_overlap'))]
    unknown = replay(tuple([0] * n), 'sparse', s, unknown=True)
    out = {'schema': s['schema'], 'allocation': s['allocation'], 'spec_sha256': code_sha(args.spec),
           'candidate_sha256': code_sha(__file__), 'endpoint': s['adverse_endpoint'], 'python': platform.python_version(),
           'case_results': results, 'illegal_checks': [{'mask': x, 'trace': replay(bits_from_mask(x, n), 'sparse', s)} for x in impossible],
           'unknown_check': unknown, 'total_elapsed_ns': time.perf_counter_ns() - start}
    Path(args.out).write_bytes(canonical(out) + b'\n')
    print(json.dumps({'allocation': out['allocation'], 'status': 'CANDIDATE_RETAINED',
                      'results': {k: {'minimal_count': len(v['minimal_masks']), 'unique_oracle_calls': v['stats']['unique_oracle_calls'], 'elapsed_ns': v['elapsed_ns']} for k, v in results.items()},
                      'raw_sha256': code_sha(args.out)}, sort_keys=True))


if __name__ == '__main__':
    main()

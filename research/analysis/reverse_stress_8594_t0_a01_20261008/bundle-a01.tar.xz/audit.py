#!/usr/bin/env python3
"""Independent finite event/table enumerator and raw-only audit; never imports candidate."""
import argparse
import copy
import hashlib
import json
import random
import sys
import time
from pathlib import Path


def bytes_json(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def test(ok, message):
    if not ok:
        raise ValueError(message)


def oracle(mask, mode, cfg, unknowable=False):
    names = cfg['flags']
    v = {name: bool(mask & (1 << i)) for i, name in enumerate(names)}
    for child, requisite in cfg['dependencies']:
        if v[child] and not v[requisite]:
            return {'status': 'ILLEGAL', 'events': []}
    if unknowable:
        return {'status': 'UNKNOWN', 'events': [{'t_ms': 21, 'event': cfg['unknown_event']}]}

    late_reasons = [cfg['default_cancel_ms']]
    if all(v[k] for k in ('queue_backlog', 'cancel_late')):
        late_reasons.append(cfg['sparse_branches']['queue_and_late_cancel_ms'])
    if all(v[k] for k in ('observation_stale', 'focus_mutation', 'verification_deferred')):
        late_reasons.append(cfg['sparse_branches']['stale_focus_deferred_ms'])
    if all(v[k] for k in ('lease_renewed', 'renewal_overlap', 'scheduler_spike')):
        late_reasons.append(cfg['sparse_branches']['renewal_overlap_spike_ms'])
    if mode == 'dense' and mask.bit_count() >= cfg['dense_threshold']:
        late_reasons.append(cfg['dense_trigger_cancel_ms'])
    cancel_time = max(late_reasons)
    effect_time = cancel_time + (cfg['slow_release_service_ms'] if v['release_slow'] else cfg['normal_release_service_ms'])
    lag = cfg['sparse_branches']['audit_receipt_lag_ms'] if (v['receipt_late'] and v['audit_gap']) else 0
    ack_time = effect_time + lag
    event_times = {
        'LEASE_START': 0,
        'OBSERVATION': 63 if v['observation_stale'] else 3,
        'CANCEL_REQUEST': cancel_time,
        'RELEASE_EFFECT': effect_time,
        'RELEASE_RECEIPT': ack_time,
        'DEADLINE': cfg['deadline_ms']
    }
    if v['focus_mutation']:
        event_times['FOCUS_MUTATION'] = 26
    order = {name: j for j, name in enumerate(cfg['event_tie_order'])}
    ordered = sorted(event_times, key=lambda name: (event_times[name], order[name]))
    return {'status': 'FAIL' if ack_time > cfg['deadline_ms'] else 'SAFE',
            'cancel_ms': cancel_time, 'effect_ms': effect_time, 'receipt_ms': ack_time,
            'events': [{'t_ms': event_times[name], 'event': name} for name in ordered]}


def exhaustive(cfg, mode):
    n = len(cfg['flags'])
    reference = {m: oracle(m, mode, cfg) for m in range(1 << n)}
    legal_masks = [m for m in reference if reference[m]['status'] != 'ILLEGAL']
    failures = [m for m in legal_masks if reference[m]['status'] == 'FAIL']
    minimum = []
    for mask in failures:
        subset = (mask - 1) & mask
        non_minimal = False
        while subset:
            if subset in reference and reference[subset]['status'] == 'FAIL':
                non_minimal = True
                break
            subset = (subset - 1) & mask
        # separately check empty mask, so zero can itself be a minimal failing case
        if not non_minimal and (mask == 0 or reference[0]['status'] != 'FAIL'):
            minimum.append(mask)
    for mask in legal_masks:
        for bit in range(n):
            if not (mask & (1 << bit)):
                larger = mask | (1 << bit)
                if larger in reference and reference[larger]['status'] == 'SAFE' and reference[mask]['status'] == 'FAIL':
                    raise ValueError('NONMONOTONE_ORACLE')
    return reference, legal_masks, sorted(minimum)



def independently_reconstruct_queries(reference, cfg):
    """Replay candidate search schedule against *independently enumerated* oracle."""
    n = len(cfg['flags'])
    index = {name: i for i, name in enumerate(cfg['flags'])}
    observed = set()
    already_found = []

    def descend(partial):
        lower = sum(1 << bit for bit, value in enumerate(partial) if value)
        if any((lower & known) == known for known in already_found):
            return
        upper = list(partial) + [1] * (n - len(partial))
        for child, parent in cfg['dependencies']:
            c = index[child]
            p = index[parent]
            if upper[p] == 0 and upper[c] == 1:
                if c < len(partial):
                    return
                upper[c] = 0
        optimistic = sum(1 << bit for bit, value in enumerate(upper) if value)
        if reference[optimistic]['status'] == 'ILLEGAL':
            raise ValueError('INVALID_UPPER_ENVELOPE')
        observed.add(optimistic)
        if reference[optimistic]['status'] != 'FAIL':
            return
        if len(partial) == n:
            already_found.append(optimistic)
            return
        descend(partial + (0,))
        descend(partial + (1,))

    descend(())
    for minimum in already_found:
        for j in range(n):
            neighbor = minimum & ~(1 << j)
            if neighbor != minimum and reference[neighbor]['status'] != 'ILLEGAL':
                observed.add(neighbor)
    return sorted(observed), sorted(already_found)


def validate(payload, cfg):
    test(payload['schema'] == cfg['schema'], 'SCHEMA_MISMATCH')
    test(payload['allocation'] == cfg['allocation'], 'ALLOCATION_MISMATCH')
    test(payload['endpoint'] == cfg['adverse_endpoint'], 'ENDPOINT_MUTATION')
    test(payload['spec_sha256'] == sha(CFG_PATH), 'SPEC_HASH_MISMATCH')
    test(payload['candidate_sha256'] == sha(CANDIDATE_PATH), 'CANDIDATE_HASH_MISMATCH')
    checked = {}
    for mode in cfg['case_names']:
        raw = payload['case_results'][mode]
        ref, eligible, expected = exhaustive(cfg, mode)
        minima = raw['minimal_masks']
        test(all(m in eligible for m in minima), 'ILLEGAL_MINIMAL')
        test(len(set(minima)) == len(minima), 'DUPLICATE_MINIMUM')
        test(sorted(minima) == expected, 'INCOMPLETE_OR_SPURIOUS_MINIMUM')
        entries = raw['minimal_evidence']
        test([z['mask'] for z in entries] == minima, 'MISALIGNED_EVIDENCE')
        for entry in entries:
            mask = entry['mask']
            test(entry['trace'] == ref[mask], 'TRACE_OR_BOUNDARY_MUTATION')
            test(ref[mask]['status'] == 'FAIL', 'NONFAIL_MINIMAL')
            expected_neighbors = []
            for bit in range(len(cfg['flags'])):
                neighbor = mask & ~(1 << bit)
                if neighbor != mask and ref[neighbor]['status'] != 'ILLEGAL':
                    test(ref[neighbor]['status'] == 'SAFE', 'UNSAFE_NEIGHBOR')
                    expected_neighbors.append({'mask': neighbor, 'trace': ref[neighbor]})
            test(entry['safe_neighbors'] == expected_neighbors, 'NEIGHBOR_MISMATCH')
        stats = raw['stats']
        observed_masks = stats['oracle_masks']
        test(observed_masks == sorted(set(observed_masks)), 'DUPLICATED_ORACLE_LOG')
        test(all(z in eligible for z in observed_masks), 'ILLEGAL_ORACLE_CALL')
        test(stats['unique_oracle_calls'] == len(observed_masks), 'ORACLE_COUNT_MISMATCH')
        test(stats['oracle_mask_sha256'] == hashlib.sha256(bytes_json(observed_masks)).hexdigest(), 'ORACLE_LOG_HASH')
        reconstructed_queries, found_by_schedule = independently_reconstruct_queries(ref, cfg)
        test(found_by_schedule == expected, 'SCHEDULE_MINIMUM_MISMATCH')
        test(observed_masks == reconstructed_queries, 'ORACLE_QUERY_SCHEDULE_MISMATCH')
        # Baseline masks are frozen deterministic choices: fully reconstitute without candidate code.
        cards = sorted((m for m in eligible if m.bit_count() <= 2), key=lambda m: (m.bit_count(), m))
        maximum = (1 << len(cfg['flags'])) - 1
        if maximum not in cards:
            cards.append(maximum)
        rng = random.Random(cfg['random_seed'])
        shuffled = list(eligible)
        rng.shuffle(shuffled)
        gray_legal = [x ^ (x >> 1) for x in range(1 << len(cfg['flags'])) if (x ^ (x >> 1)) in set(eligible)]
        plans = {'weight_lte2_portfolio': cards,
                 'random_equal_budget': shuffled[:len(observed_masks)],
                 'gray_equal_budget': gray_legal[:len(observed_masks)]}
        for label, expected_masks in plans.items():
            actual = raw['baselines'][label]
            test(actual['masks'] == expected_masks, 'BASELINE_ORDER_MISMATCH')
            test(actual['unique_oracle_calls'] == len(expected_masks), 'BASELINE_COUNT_MISMATCH')
            test(actual['failure_observations'] == sum(ref[m]['status'] == 'FAIL' for m in expected_masks), 'BASELINE_FAILURE_MISMATCH')
        frac = 1 - len(observed_masks) / len(eligible)
        checked[mode] = {'legal_scenarios': len(eligible), 'fail_scenarios': len([m for m in eligible if ref[m]['status'] == 'FAIL']),
                         'minimal_bundles': len(expected), 'candidate_oracle_calls': len(observed_masks),
                         'exhaustive_oracle_calls': len(eligible), 'call_reduction': frac,
                         'portfolio_minimum_coverage': len(set(cards) & set(expected)),
                         'random_minimum_coverage': len(set(plans['random_equal_budget']) & set(expected)),
                         'gray_minimum_coverage': len(set(plans['gray_equal_budget']) & set(expected)),
                         'candidate_elapsed_ns': raw['elapsed_ns']}
    invalid = [(1 << cfg['flags'].index('audit_gap')), (1 << cfg['flags'].index('renewal_overlap'))]
    test(payload['illegal_checks'] == [{'mask': m, 'trace': oracle(m, 'sparse', cfg)} for m in invalid], 'ILLEGAL_RECONSTRUCTION')
    test(payload['unknown_check'] == oracle(0, 'sparse', cfg, unknowable=True), 'UNKNOWN_WAS_COLLAPSED')
    return checked


def mutation_audit(payload, cfg):
    cases = {}
    # Intentional corruptions of copies only. Never modify retained candidate output.
    for label in ('endpoint', 'event_order', 'legality', 'boundary'):
        changed = copy.deepcopy(payload)
        if label == 'endpoint':
            changed['endpoint'] = 'DIFFERENT_ENDPOINT'
        elif label == 'event_order':
            e = changed['case_results']['sparse']['minimal_evidence'][0]['trace']['events']
            e[0], e[1] = e[1], e[0]
        elif label == 'legality':
            changed['case_results']['sparse']['minimal_masks'].append(1 << cfg['flags'].index('audit_gap'))
        elif label == 'boundary':
            changed['case_results']['sparse']['minimal_evidence'][0]['trace']['receipt_ms'] += 1
        try:
            validate(changed, cfg)
            cases[label] = {'rejected': False, 'error': None}
        except (ValueError, KeyError, TypeError) as exc:
            cases[label] = {'rejected': True, 'error': str(exc)}
    return cases


def main():
    global CFG_PATH, CANDIDATE_PATH
    p = argparse.ArgumentParser()
    p.add_argument('--spec', required=True)
    p.add_argument('--candidate-source', required=True)
    p.add_argument('--input', required=True)
    p.add_argument('--out', required=True)
    arg = p.parse_args()
    CFG_PATH = arg.spec
    CANDIDATE_PATH = arg.candidate_source
    cfg = json.loads(Path(CFG_PATH).read_text())
    payload = json.loads(Path(arg.input).read_text())
    start = time.perf_counter_ns()
    try:
        summary = validate(payload, cfg)
        mutations = mutation_audit(payload, cfg)
        test(all(v['rejected'] for v in mutations.values()), 'MUTATION_NOT_DETECTED')
        test(summary['sparse']['call_reduction'] >= cfg['required_sparse_reduction_fraction'], 'NO_20PCT_ADVANTAGE')
        verdict = 'PASS_METHOD_SCOPED'
        failures = []
    except (ValueError, KeyError, TypeError) as exc:
        summary = locals().get('summary', {})
        mutations = locals().get('mutations', {})
        verdict = 'FAIL_METHOD_OR_AUDIT'
        failures = [str(exc)]
    result = {'schema': cfg['schema'], 'allocation': cfg['allocation'], 'verdict': verdict,
              'errors': failures, 'candidate_output_sha256': sha(arg.input), 'auditor_source_sha256': sha(__file__),
              'spec_sha256': sha(CFG_PATH), 'summary': summary, 'mutations': mutations,
              'auditor_elapsed_ns': time.perf_counter_ns() - start}
    Path(arg.out).write_bytes(bytes_json(result) + b'\n')
    print(json.dumps(result, sort_keys=True))
    return 0 if verdict == 'PASS_METHOD_SCOPED' else 1


if __name__ == '__main__':
    sys.exit(main())

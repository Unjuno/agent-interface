import unittest
from model import fallback,monitor_valid,run,Scenario,FORMAL_SCENARIOS
class T(unittest.TestCase):
 def test_fallback_moves_inward(self):
  for x in range(-5,6):
   if x:self.assertLess(abs(x+fallback(x)),abs(x))
 def test_monitor_margin(self):self.assertFalse(monitor_valid(4,1,1));self.assertTrue(monitor_valid(2,1,0))
 def test_late_no_retake(self):self.assertEqual(run('RUNTIME_ASSURANCE_FALLBACK',Scenario('x',4,(1,1,1),(1,1,1),True,2))['stale_retake'],0)
 def test_formal_shape_only(self):
  self.assertEqual(len(FORMAL_SCENARIOS),16);self.assertEqual(len({s.name for s in FORMAL_SCENARIOS}),16)
  self.assertTrue(all(s.name.startswith('held_') for s in FORMAL_SCENARIOS))
if __name__=='__main__':unittest.main()

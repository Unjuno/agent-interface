from dataclasses import dataclass
SAFE=5; MARGIN=4
@dataclass(frozen=True)
class Scenario:
    name:str; x0:int; drift:tuple[int,...]; proposals:tuple[int,...]; fallback_available:bool=True; late_at:int|None=None

def make_drift(onset,duration,n=8): return tuple(1 if onset<=t<onset+duration else 0 for t in range(n))
CONSTRUCTION_SCENARIOS=(
 Scenario('nominal',0,(0,)*8,(1,1,1,0,0,0,0,0)),
 Scenario('benign',2,(0,)*8,(1,0,0,0,0,0,0,0)),
 Scenario('drift_early',3,(1,1,1,1,0,0,0,0),(1,1,1,1,0,0,0,0)),
 Scenario('drift_late',2,(0,1,1,1,1,0,0,0),(1,1,1,1,1,0,0,0)),
 Scenario('drift_long',4,(1,1,1,1,1,1,0,0),(1,1,1,1,1,1,0,0)),
 Scenario('late_result',3,(1,1,1,1,0,0,0,0),(1,1,1,1,0,0,0,0),True,4),
 Scenario('late_result_long',4,(1,1,1,1,1,0,0,0),(1,1,1,1,1,0,0,0),True,5),
 Scenario('fallback_unavailable',4,(1,1,1,0,0,0,0,0),(1,1,1,0,0,0,0,0),False,3),
)
FORMAL_SCENARIOS=[]
for x0 in (2,3,4):
 for onset in (0,2):
  for duration in (2,5):
   FORMAL_SCENARIOS.append(Scenario(f'held_x{x0}_o{onset}_d{duration}',x0,make_drift(onset,duration),(1,1,1,1,1,1,0,0)))
FORMAL_SCENARIOS += [
 Scenario('held_late_x3',3,make_drift(0,5),(1,1,1,1,1,1,0,0),True,4),
 Scenario('held_late_x4',4,make_drift(2,5),(1,1,1,1,1,1,0,0),True,6),
 Scenario('held_nominal',1,(0,)*8,(1,1,0,0,0,0,0,0)),
 Scenario('held_fallback_unavailable',3,make_drift(0,5),(1,1,1,1,1,0,0,0),False,4),
]
FORMAL_SCENARIOS=tuple(FORMAL_SCENARIOS)
def clamp(u): return max(-1,min(1,int(u)))
def fallback(x): return -1 if x>0 else (1 if x<0 else 0)
def monitor_valid(x,u,d): return abs(x+clamp(u)+d) <= MARGIN

def run(policy,s):
 x=s.x0; switched=False; yielded=False; authority=True; stale_retake=0; rows=[]
 for t,(d,proposal) in enumerate(zip(s.drift,s.proposals)):
  late=(s.late_at is not None and t==s.late_at); valid=monitor_valid(x,proposal,d); action='ADVANCED'; u=clamp(proposal)
  if switched:
   if policy=='RUNTIME_ASSURANCE_FALLBACK' and s.fallback_available: action='FALLBACK'; u=fallback(x)
   else: action='YIELD'; u=0; authority=False; yielded=True
  elif not valid:
   switched=True
   if policy=='RUNTIME_ASSURANCE_FALLBACK' and s.fallback_available: action='FALLBACK'; u=fallback(x)
   else: action='YIELD'; u=0; authority=False; yielded=True
  before=x; x=x+u+d; safe=abs(x)<=SAFE; progress=safe and x>=2
  rows.append({'t':t,'x_before':before,'drift':d,'proposal':proposal,'monitor_valid':valid,'action':action,'u':u,'x_after':x,'safe':safe,'safe_progress':progress,'late_advanced_arrival':late,'authority_after':authority})
 return {'policy':policy,'scenario':s.name,'rows':rows,'switched':switched,'yielded':yielded,'fallback_available':s.fallback_available,'violating_ticks':sum(not r['safe'] for r in rows),'safe_progress_ticks':sum(r['safe_progress'] for r in rows),'stale_retake':stale_retake,'final_x':x,'terminal_released':True}

import argparse,json,pathlib
from model import CONSTRUCTION_SCENARIOS,FORMAL_SCENARIOS,run
p=argparse.ArgumentParser();p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--formal',action='store_true');a=p.parse_args()
a.out.mkdir(parents=True,exist_ok=False); sc=FORMAL_SCENARIOS if a.formal else CONSTRUCTION_SCENARIOS
out=[run(pol,s) for s in sc for pol in ('ADVANCED_OR_STOP','RUNTIME_ASSURANCE_FALLBACK')]
(a.out/'RAW.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps({'rows':len(out),'formal':a.formal}))

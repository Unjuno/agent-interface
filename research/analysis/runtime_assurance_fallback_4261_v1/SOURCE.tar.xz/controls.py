import copy,json,sys
from audit import audit
raw=json.load(open(sys.argv[1])); controls=[]
def t(name,fn):
 d=copy.deepcopy(raw);fn(d); controls.append({'name':name,'rejected':bool(audit(d)['errors'])})
def find(d,sc,pol): return next(x for x in d if x['scenario']==sc and x['policy']==pol)
names={x['scenario'] for x in raw}; formal=all(n.startswith('held_') for n in names); sc=sorted(n for n in names if n not in ({'held_nominal','held_fallback_unavailable'} if formal else {'nominal','benign','fallback_unavailable'}))[0]; un='held_fallback_unavailable' if formal else 'fallback_unavailable'
t('candidate_violation',lambda d: find(d,sc,'RUNTIME_ASSURANCE_FALLBACK').__setitem__('violating_ticks',1))
t('stale_retake',lambda d: find(d,sc,'RUNTIME_ASSURANCE_FALLBACK').__setitem__('stale_retake',1))
t('release_false',lambda d: d[0].__setitem__('terminal_released',False))
t('unavailable_fallback',lambda d: find(d,un,'RUNTIME_ASSURANCE_FALLBACK')['rows'][0].__setitem__('action','FALLBACK'))
t('remove_row',lambda d:d.pop())
t('erase_baseline_violations',lambda d:[x.__setitem__('violating_ticks',0) for x in d if x['policy']=='ADVANCED_OR_STOP'])
print(json.dumps({'controls':controls,'rejected':sum(x['rejected'] for x in controls),'total':len(controls)},indent=2))

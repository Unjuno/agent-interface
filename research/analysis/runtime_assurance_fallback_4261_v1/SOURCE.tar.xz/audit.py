import argparse,json,pathlib

def audit(data):
 errs=[]; by={(x['scenario'],x['policy']):x for x in data}; names={x['scenario'] for x in data}
 if len(data)%2 or len(by)!=len(data): errs.append('shape')
 for n in names:
  for p in ('ADVANCED_OR_STOP','RUNTIME_ASSURANCE_FALLBACK'):
   if (n,p) not in by: errs.append('missing:'+n+':'+p)
 if errs: return {'decision':'HOLD_OR_FAIL','errors':errs,'rows':len(data)}
 for k,x in by.items():
  if not x.get('terminal_released'): errs.append('release:'+str(k))
  if x.get('stale_retake')!=0: errs.append('stale_retake:'+str(k))
 formal=all(n.startswith('held_') for n in names)
 if formal:
  efficacy={n for n in names if n not in {'held_nominal','held_fallback_unavailable'}}
  nominal='held_nominal'; unavailable='held_fallback_unavailable'
 else:
  efficacy={'drift_early','drift_late','drift_long','late_result','late_result_long'}
  nominal='nominal'; unavailable='fallback_unavailable'
 for sc in ([nominal] if formal else ['nominal','benign']):
  a=by[(sc,'ADVANCED_OR_STOP')]; b=by[(sc,'RUNTIME_ASSURANCE_FALLBACK')]
  if a['violating_ticks'] or b['violating_ticks'] or a['final_x']!=b['final_x']: errs.append('nominal:'+sc)
 fu=by[(unavailable,'RUNTIME_ASSURANCE_FALLBACK')]
 if not fu['yielded'] or any(r['action']=='FALLBACK' for r in fu['rows']): errs.append('unavailable_not_yield')
 bviol=sum(by[(s,'ADVANCED_OR_STOP')]['violating_ticks'] for s in efficacy); cviol=sum(by[(s,'RUNTIME_ASSURANCE_FALLBACK')]['violating_ticks'] for s in efficacy)
 bprog=sum(by[(s,'ADVANCED_OR_STOP')]['safe_progress_ticks'] for s in efficacy); cprog=sum(by[(s,'RUNTIME_ASSURANCE_FALLBACK')]['safe_progress_ticks'] for s in efficacy)
 if not cviol < bviol: errs.append('no_violation_improvement')
 if not cprog > bprog: errs.append('no_progress_improvement')
 for s in efficacy:
  if by[(s,'RUNTIME_ASSURANCE_FALLBACK')]['violating_ticks']!=0: errs.append('candidate_violation:'+s)
 decision='PASS_RUNTIME_ASSURANCE_FALLBACK_SCOPED' if not errs else 'HOLD_OR_FAIL'
 return {'decision':decision,'errors':errs,'rows':len(data),'formal':formal,'eligible_scenarios':len(efficacy),'baseline_violating_ticks':bviol,'candidate_violating_ticks':cviol,'baseline_safe_progress_ticks':bprog,'candidate_safe_progress_ticks':cprog,'stale_retakes':sum(x['stale_retake'] for x in data)}
def main():
 p=argparse.ArgumentParser();p.add_argument('raw',type=pathlib.Path);p.add_argument('--out',type=pathlib.Path,required=True);a=p.parse_args();o=audit(json.loads(a.raw.read_text()));a.out.write_text(json.dumps(o,indent=2,sort_keys=True)+'\n');print(json.dumps(o,sort_keys=True))
if __name__=='__main__':main()

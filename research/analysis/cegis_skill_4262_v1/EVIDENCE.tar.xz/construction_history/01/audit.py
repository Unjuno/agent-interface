#!/usr/bin/env python3
import argparse,json
from pathlib import Path
FEATURES=['target_ok','evidence','alt_ok','forbidden','current','ambiguous']
HELDOUT=[i for i in range(64) if ((3*i+59)%64)<16]; DEMOS={18,19,22}
RULES={
 'FORBIDDEN_YIELD':('forbidden',True,'YIELD'),'STALE_YIELD':('current',False,'YIELD'),'AMBIGUOUS_YIELD':('ambiguous',True,'YIELD'),
 'MISSING_EVIDENCE_YIELD':('evidence',False,'YIELD'),'PRIMARY_ACT':('target_ok',True,'ACT_PRIMARY'),'ALT_ACT':('alt_ok',True,'ACT_ALT')}
def oracle(s):
    if s['forbidden'] or not s['current'] or s['ambiguous'] or not s['evidence']: return 'YIELD'
    if s['target_ok']: return 'ACT_PRIMARY'
    if s['alt_ok']: return 'ACT_ALT'
    return 'YIELD'
def apply(names,s):
    for n in names:
        f,v,o=RULES[n]
        if s[f] is v:return o
    return 'YIELD'
def check(root):
    res=json.loads((root/'RESULT.json').read_text()); rows=[json.loads(x) for x in (root/'RAW.jsonl').read_text().splitlines() if x]
    e=[]
    if len(rows)!=128:e.append('row_count')
    by={(r['arm'],r['state_id']):r for r in rows}
    if len(by)!=128:e.append('row_identity')
    for arm,names in [('ONE_SHOT',res.get('one_shot_rules',[])),('CEGIS',res.get('cegis_rules',[]))]:
        for i in range(64):
            r=by.get((arm,i));
            if not r: continue
            exp_state={f:bool((i>>j)&1) for j,f in enumerate(FEATURES)}
            exp_split='HELDOUT' if i in HELDOUT else ('DEMO' if i in DEMOS else 'VERIFY')
            if r.get('state')!=exp_state or r.get('split')!=exp_split:e.append(f'{arm}:{i}:identity')
            if r.get('oracle')!=oracle(exp_state):e.append(f'{arm}:{i}:oracle')
            if r.get('prediction')!=apply(names,exp_state):e.append(f'{arm}:{i}:prediction')
            if r.get('authority')!='none':e.append(f'{arm}:{i}:authority')
    one=sum(by[('ONE_SHOT',i)]['prediction']==by[('ONE_SHOT',i)]['oracle'] for i in HELDOUT)
    ceg=sum(by[('CEGIS',i)]['prediction']==by[('CEGIS',i)]['oracle'] for i in HELDOUT)
    if res.get('heldout_correct')!={'CEGIS':ceg,'ONE_SHOT':one}:e.append('heldout_summary')
    if not (ceg==16 and one<ceg):e.append('heldout_gate')
    unsafe=sum(by[('CEGIS',i)]['prediction']!='YIELD' and by[('CEGIS',i)]['oracle']=='YIELD' for i in range(64))
    if unsafe:e.append('unsafe_cegis')
    hist=res.get('history',[]); cex=res.get('counterexamples',[])
    if len(cex)>6 or not hist or hist[-1].get('remaining_verifier_mismatches')!=0:e.append('cegis_convergence')
    # Every recorded counterexample must remain correct in final candidate.
    for i in cex:
        if by[('CEGIS',i)]['prediction']!=by[('CEGIS',i)]['oracle']:e.append('counterexample_regression')
    if len(res.get('cegis_rules',[]))>6:e.append('rule_budget')
    if res.get('authority')!='none':e.append('result_authority')
    return e,{'rows':len(rows),'one_shot_heldout':one,'cegis_heldout':ceg,'cex_count':len(cex),'cegis_rule_count':len(res.get('cegis_rules',[]))}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('root');ap.add_argument('--out',required=True);a=ap.parse_args(); e,s=check(Path(a.root));o={'schema':'agent-interface/cegis-skill-audit-v1','errors':e,'audit_pass':not e,**s};Path(a.out).write_text(json.dumps(o,indent=2,sort_keys=True)+'\n');print(json.dumps(o,sort_keys=True));return 0 if not e else 1
if __name__=='__main__':raise SystemExit(main())

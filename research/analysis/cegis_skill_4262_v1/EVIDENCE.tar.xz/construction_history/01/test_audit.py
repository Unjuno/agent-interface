#!/usr/bin/env python3
import copy,json,sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent));import audit
root=Path(sys.argv[1]); base_res=json.loads((root/'RESULT.json').read_text()); base_rows=[json.loads(x) for x in (root/'RAW.jsonl').read_text().splitlines() if x]
controls=[]
def run(name,mut):
    with tempfile.TemporaryDirectory() as td:
        p=Path(td);res=copy.deepcopy(base_res);rows=copy.deepcopy(base_rows);mut(res,rows);(p/'RESULT.json').write_text(json.dumps(res));(p/'RAW.jsonl').write_text('\n'.join(json.dumps(x) for x in rows)+'\n');errs,_=audit.check(p);controls.append({'name':name,'rejected':bool(errs)})
run('drop_row',lambda r,x:x.pop())
run('dup_row',lambda r,x:x.append(copy.deepcopy(x[0])))
run('oracle',lambda r,x:x[0].__setitem__('oracle','ACT_PRIMARY'))
run('prediction',lambda r,x:x[-1].__setitem__('prediction','ACT_ALT'))
run('state',lambda r,x:x[10]['state'].__setitem__('forbidden',not x[10]['state']['forbidden']))
run('split',lambda r,x:x[23].__setitem__('split','VERIFY'))
run('authority',lambda r,x:x[0].__setitem__('authority','task'))
run('summary',lambda r,x:r['heldout_correct'].__setitem__('CEGIS',0))
run('rules',lambda r,x:r.__setitem__('cegis_rules',r['cegis_rules'][:-1]))
run('history',lambda r,x:r['history'][-1].__setitem__('remaining_verifier_mismatches',1))
run('cex',lambda r,x:r.__setitem__('counterexamples',r['counterexamples']+[63,62]))
run('result_authority',lambda r,x:r.__setitem__('authority','input'))
ok=all(c['rejected'] for c in controls);print(json.dumps({'controls':controls,'rejected':sum(c['rejected'] for c in controls),'total':len(controls)},sort_keys=True));raise SystemExit(0 if ok else 1)

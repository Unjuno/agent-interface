#!/usr/bin/env python3
import argparse, itertools, json
from pathlib import Path

FEATURES=['target_ok','evidence','alt_ok','forbidden','current','ambiguous']
TEMPLATES=[
 ('FORBIDDEN_YIELD','forbidden',True,'YIELD'),
 ('STALE_YIELD','current',False,'YIELD'),
 ('AMBIGUOUS_YIELD','ambiguous',True,'YIELD'),
 ('MISSING_EVIDENCE_YIELD','evidence',False,'YIELD'),
 ('PRIMARY_ACT','target_ok',True,'ACT_PRIMARY'),
 ('ALT_ACT','alt_ok',True,'ACT_ALT'),
]
DEMOS=[18,19,22]
HELDOUT=[i for i in range(64) if ((3*i+59)%64)<16]
VERIFY=[i for i in range(64) if i not in HELDOUT]
MAX_RULES=6; MAX_CEX=6

def state(i): return {f:bool((i>>j)&1) for j,f in enumerate(FEATURES)}
def oracle(s):
    if s['forbidden'] or not s['current'] or s['ambiguous'] or not s['evidence']: return 'YIELD'
    if s['target_ok']: return 'ACT_PRIMARY'
    if s['alt_ok']: return 'ACT_ALT'
    return 'YIELD'
def apply(rules,s):
    for ri in rules:
        _,f,v,out=TEMPLATES[ri]
        if s[f] is v: return out
    return 'YIELD'
def synth(examples):
    for k in range(MAX_RULES+1):
        for rules in itertools.permutations(range(len(TEMPLATES)),k):
            if all(apply(rules,state(i))==label for i,label in examples): return rules
    return None

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--mode',choices=['construction','formal'],required=True); ap.add_argument('--out',required=True); a=ap.parse_args()
    out=Path(a.out); out.mkdir(parents=False,exist_ok=False)
    demos=[(i,oracle(state(i))) for i in DEMOS]
    one=synth(demos)
    examples=list(demos); history=[]
    for rnd in range(MAX_CEX+1):
        rules=synth(examples)
        bad=[i for i in VERIFY if apply(rules,state(i))!=oracle(state(i))]
        history.append({'round':rnd,'rules':[TEMPLATES[x][0] for x in rules],'counterexample':bad[0] if bad else None,'remaining_verifier_mismatches':len(bad)})
        if not bad: break
        ce=bad[0]; examples.append((ce,oracle(state(ce))))
    cegis=rules
    rows=[]
    for arm,rules in [('ONE_SHOT',one),('CEGIS',cegis)]:
        for i in range(64):
            split='HELDOUT' if i in HELDOUT else ('DEMO' if i in DEMOS else 'VERIFY')
            rows.append({'arm':arm,'state_id':i,'state':state(i),'split':split,'oracle':oracle(state(i)),'prediction':apply(rules,state(i)),'authority':'none'})
    held={arm:sum(r['prediction']==r['oracle'] for r in rows if r['arm']==arm and r['split']=='HELDOUT') for arm in ['ONE_SHOT','CEGIS']}
    unsafe={arm:sum(r['prediction']!='YIELD' and r['oracle']=='YIELD' for r in rows if r['arm']==arm) for arm in ['ONE_SHOT','CEGIS']}
    accumulated=[h['counterexample'] for h in history if h['counterexample'] is not None]
    result={
      'schema':'agent-interface/cegis-skill-v1','allocation':'cegis-skill-4262-20260923-01','mode':a.mode,
      'features':FEATURES,'templates':[x[0] for x in TEMPLATES],'demos':DEMOS,'heldout':HELDOUT,'verifier_count':len(VERIFY),
      'one_shot_rules':[TEMPLATES[x][0] for x in one],'cegis_rules':[TEMPLATES[x][0] for x in cegis],
      'history':history,'counterexamples':accumulated,'heldout_correct':held,'heldout_total':len(HELDOUT),'unsafe_action_on_yield':unsafe,
      'formal_invocations':1 if a.mode=='formal' else 0,'authority':'none'
    }
    with (out/'RAW.jsonl').open('w') as f:
        for r in rows: f.write(json.dumps(r,sort_keys=True)+'\n')
    (out/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'heldout':held,'unsafe':unsafe,'cex':accumulated,'cegis_rules':result['cegis_rules']},sort_keys=True))
if __name__=='__main__': main()

import unittest
from model import evaluate

class PhantomTest(unittest.TestCase):
    def test_phantom_insert(self):
        r = evaluate('unique', ('insert_B','unrelated'))
        self.assertTrue(r['NODE_ONLY'])
        self.assertFalse(r['MEMBERSHIP_CERT'])
        self.assertFalse(r['ALWAYS_REQUERY'])
    def test_aba(self):
        r = evaluate('unique', ('insert_B','remove_B'))
        self.assertTrue(r['NODE_ONLY'])
        self.assertFalse(r['MEMBERSHIP_CERT'])
        self.assertTrue(r['ALWAYS_REQUERY'])
    def test_unrelated(self):
        r = evaluate('unique', ('unrelated','unrelated'))
        self.assertTrue(all(r.values()))
    def test_surface_reset(self):
        r = evaluate('unique', ('replace_surface','unrelated'))
        self.assertFalse(r['MEMBERSHIP_CERT'])
    def test_initial_incomplete(self):
        r = evaluate('incomplete', ('mark_complete','unrelated'))
        self.assertFalse(any(r.values()))

if __name__ == '__main__':
    unittest.main()

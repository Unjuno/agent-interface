"""One-shot exhaustive candidate on the frozen predicate history corpus."""
import argparse, json, os, sys, time
from pathlib import Path
from model import corpus, evaluate


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    p = Path(args.out)
    if p.exists():
        raise SystemExit('REFUSE_EXISTING_OUTPUT')
    p.parent.mkdir(parents=True, exist_ok=True)
    started = time.monotonic_ns()
    counts = {'total':0,'node_admit':0,'cert_admit':0,'requery_admit':0}
    with p.open('x', encoding='utf-8', newline='\n') as f:
        for ix, (template, events) in enumerate(corpus()):
            verdicts = evaluate(template, events)
            f.write(json.dumps({'index':ix, 'template':template, 'events':list(events),
                                'decisions':verdicts}, sort_keys=True, separators=(',',':'))+'\n')
            counts['total'] += 1
            for col,key in [('node_admit','NODE_ONLY'),('cert_admit','MEMBERSHIP_CERT'),
                            ('requery_admit','ALWAYS_REQUERY')]:
                counts[col] += int(verdicts[key])
    print(json.dumps({'status':'CANDIDATE_COMPLETED','counts':counts,
                      'elapsed_monotonic_ns':time.monotonic_ns()-started,
                      'pid':os.getpid(),'python':sys.version.split()[0]}, sort_keys=True))

if __name__ == '__main__':
    main()

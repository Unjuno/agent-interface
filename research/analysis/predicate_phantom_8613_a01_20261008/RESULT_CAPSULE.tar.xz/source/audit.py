"""Independent replay audit from input rows only. Does not import candidate/model."""
import argparse, hashlib, itertools, json
from pathlib import Path

INIT=('unique','distractor','multiple','none','disabled','other_scope','incomplete')
ACTIONS=('insert_B','insert_C','remove_A','remove_B','rename_B','enable_B',
         'replace_surface','unrelated','mark_incomplete','mark_complete')
KEYS=('NODE_ONLY','MEMBERSHIP_CERT','ALWAYS_REQUERY')


def fresh(name):
    nodes={k: [False,'Other',True,'dialog',0] for k in 'ABC'}  # alive,label,enabled,scope,rev
    nodes['A']=[True,'Save',True,'dialog',0]
    if name=='distractor': nodes['B'][0]=True
    elif name=='multiple': nodes['B']=[True,'Save',True,'dialog',0]
    elif name=='none': nodes['A'][1]='Other'
    elif name=='disabled': nodes['A'][2]=False
    elif name=='other_scope': nodes['A'][3]='other'
    return nodes, name!='incomplete'


def query(nodes):
    return tuple(k for k in sorted(nodes) if
                 nodes[k][0] and nodes[k][1]=='Save' and nodes[k][2] and nodes[k][3]=='dialog')


def reference(name, events):
    nodes,complete=fresh(name)
    first=query(nodes)
    selected=first[0] if complete and len(first)==1 else None
    saved_rev=nodes[selected][4] if selected is not None else None
    changed_members=False
    changed_complete=False
    scope_changed=False
    for action in events:
        prev=query(nodes)
        if action.startswith('insert_'):
            k=action[-1]; oldrev=nodes[k][4]
            nodes[k]=[True,'Save',True,'dialog',oldrev+1]
        elif action.startswith('remove_'):
            k=action[-1]
            if nodes[k][0]:
                nodes[k][0]=False; nodes[k][4]+=1
        elif action=='rename_B' and nodes['B'][0]:
            nodes['B'][1]='Other' if nodes['B'][1]=='Save' else 'Save'
            nodes['B'][4]+=1
        elif action=='enable_B' and nodes['B'][0]:
            nodes['B'][2]=not nodes['B'][2]; nodes['B'][4]+=1
        elif action=='replace_surface':
            scope_changed=True
        elif action=='mark_complete' and not complete:
            complete=True;changed_complete=True
        elif action=='mark_incomplete' and complete:
            complete=False;changed_complete=True
        # 'unrelated' is an observable but irrelevant state change
        if query(nodes)!=prev:
            changed_members=True
    node=selected is not None and nodes[selected][0] and nodes[selected][4]==saved_rev
    endpoint=bool(node and complete and query(nodes)==first and not scope_changed)
    cert=bool(endpoint and not changed_complete and not changed_members)
    return {'NODE_ONLY':bool(node),'MEMBERSHIP_CERT':cert,'ALWAYS_REQUERY':endpoint},cert,changed_members


def audit(path):
    errors=[]
    stats={'rows':0,'safe':0,'unsafe':0,'node_wrong_accept':0,
           'requery_wrong_accept':0,'cert_wrong_accept':0,'cert_false_refuse':0,
           'phantom_witness':0,'aba_witness':0,'unchanged_accept':0}
    seen_ids=set()
    p=Path(path)
    with p.open('r',encoding='utf-8') as f:
        index=0
        for t in INIT:
            for length in (2,3,4):
                for events in itertools.product(ACTIONS,repeat=length):
                    line=f.readline()
                    if not line:
                        errors.append('missing_row:'+str(index)); return {'errors':errors,'stats':stats}
                    try: row=json.loads(line,parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
                    except Exception as exc:
                        errors.append('bad_json:'+str(index)+':'+type(exc).__name__)
                        return {'errors':errors,'stats':stats}
                    if (type(row) is not dict or set(row)!={'index','template','events','decisions'} or
                            type(row.get('index')) is not int or row['index']!=index or
                            row['template']!=t or row['events']!=list(events)):
                        errors.append('identity_or_order:'+str(index));return {'errors':errors,'stats':stats}
                    value=row['decisions']
                    if type(value) is not dict or set(value)!=set(KEYS) or any(type(value[k]) is not bool for k in KEYS):
                        errors.append('invalid_decision_type:'+str(index));return {'errors':errors,'stats':stats}
                    expected,safe,churn=reference(t,events)
                    if expected!=value:
                        errors.append('decision_mismatch:'+str(index));return {'errors':errors,'stats':stats}
                    stats['rows']+=1
                    stats['safe' if safe else 'unsafe']+=1
                    stats['node_wrong_accept']+=int(value['NODE_ONLY'] and not safe)
                    stats['requery_wrong_accept']+=int(value['ALWAYS_REQUERY'] and not safe)
                    stats['cert_wrong_accept']+=int(value['MEMBERSHIP_CERT'] and not safe)
                    stats['cert_false_refuse']+=int(not value['MEMBERSHIP_CERT'] and safe)
                    stats['unchanged_accept']+=int(safe and value['MEMBERSHIP_CERT'])
                    stats['phantom_witness']+=int(t=='unique' and events[:1]==('insert_B',) and value['NODE_ONLY'] and not safe)
                    stats['aba_witness']+=int(t=='unique' and len(events)>=2 and events[:2]==('insert_B','remove_B') and value['ALWAYS_REQUERY'] and not safe)
                    index+=1
        if f.readline(): errors.append('extra_rows')
    if stats['rows']!=len(INIT)*sum(len(ACTIONS)**j for j in (2,3,4)):
        errors.append('total_count')
    if stats['node_wrong_accept']==0 or stats['phantom_witness']==0 or stats['aba_witness']==0:
        errors.append('missing_discriminator')
    if stats['cert_wrong_accept'] or stats['cert_false_refuse']:
        errors.append('certificate_unsound_or_overconservative')
    if stats['safe']==0: errors.append('no_positive_controls')
    return {'errors':errors, 'stats':stats,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}


def main():
    pa=argparse.ArgumentParser();pa.add_argument('raw');pa.add_argument('--out',required=True)
    args=pa.parse_args()
    path=Path(args.out)
    if path.exists(): raise SystemExit('REFUSE_EXISTING_AUDIT_OUTPUT')
    result=audit(args.raw)
    path.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps({'errors':result['errors'],'stats':result['stats']},sort_keys=True))
    if result['errors']: raise SystemExit(1)

if __name__=='__main__':main()

"""Disjoint hand witnesses; never runs the frozen full candidate corpus."""
import unittest
from audit import reference

class OracleConstruction(unittest.TestCase):
    def test_insert_phantom(self):
        outcomes,safe,churn=reference('unique',('insert_B','unrelated'))
        self.assertEqual(outcomes, {'NODE_ONLY':True,'MEMBERSHIP_CERT':False,'ALWAYS_REQUERY':False})
        self.assertFalse(safe)
        self.assertTrue(churn)
    def test_insert_remove_aba(self):
        outcomes,safe,churn=reference('unique',('insert_B','remove_B'))
        self.assertEqual(outcomes, {'NODE_ONLY':True,'MEMBERSHIP_CERT':False,'ALWAYS_REQUERY':True})
        self.assertFalse(safe)
        self.assertTrue(churn)
    def test_unrelated(self):
        outcomes,safe,churn=reference('unique',('unrelated','unrelated'))
        self.assertTrue(safe)
        self.assertEqual(set(outcomes.values()),{True})
        self.assertFalse(churn)
    def test_surface(self):
        outcomes,safe,churn=reference('unique',('replace_surface','unrelated'))
        self.assertFalse(safe)
        self.assertFalse(outcomes['MEMBERSHIP_CERT'])
    def test_recovered_incompleteness(self):
        outcomes,safe,_=reference('unique',('mark_incomplete','mark_complete'))
        self.assertFalse(safe)
        self.assertTrue(outcomes['ALWAYS_REQUERY'])
        self.assertFalse(outcomes['MEMBERSHIP_CERT'])
    def test_zero_multi(self):
        for k in ('none','multiple','disabled','other_scope','incomplete'):
            result,safe,_=reference(k,('unrelated','unrelated'))
            self.assertFalse(safe)
            self.assertEqual(set(result.values()),{False})
if __name__=='__main__':unittest.main()

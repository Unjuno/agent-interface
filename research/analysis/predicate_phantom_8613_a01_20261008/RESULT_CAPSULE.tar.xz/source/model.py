"""Deterministic UI predicate history model. No GUI, network, or actuation."""
from itertools import product

TEMPLATES = ('unique', 'distractor', 'multiple', 'none', 'disabled', 'other_scope', 'incomplete')
EVENTS = ('insert_B', 'insert_C', 'remove_A', 'remove_B', 'rename_B', 'enable_B',
          'replace_surface', 'unrelated', 'mark_incomplete', 'mark_complete')
ARMS = ('NODE_ONLY', 'MEMBERSHIP_CERT', 'ALWAYS_REQUERY')


def initial(kind):
    if kind not in TEMPLATES:
        raise ValueError(kind)
    nodes = {key: dict(live=False, label='Other', enabled=True, visible=True, scope='dialog', rev=0)
             for key in 'ABC'}
    nodes['A'].update(live=True, label='Save')
    if kind == 'distractor':
        nodes['B'].update(live=True, label='Other')
    if kind == 'multiple':
        nodes['B'].update(live=True, label='Save')
    if kind == 'none':
        nodes['A']['label'] = 'Other'
    if kind == 'disabled':
        nodes['A']['enabled'] = False
    if kind == 'other_scope':
        nodes['A']['scope'] = 'other'
    return dict(nodes=nodes, complete=kind != 'incomplete', membership_rev=0,
                scope_rev=0, completeness_rev=0, unrelated_rev=0)


def members(w):
    return tuple(k for k, v in w['nodes'].items() if
                 v['live'] and v['label'] == 'Save' and v['enabled']
                 and v['visible'] and v['scope'] == 'dialog')


def transition(w, event):
    if event not in EVENTS:
        raise ValueError(event)
    before = members(w)
    n = w['nodes']
    if event in ('insert_B', 'insert_C'):
        v = n[event[-1]]
        # Reinsertion reuses a UI locator name, but always creates a new generation.
        v.update(live=True, label='Save', enabled=True, visible=True, scope='dialog')
        v['rev'] += 1
    elif event in ('remove_A', 'remove_B'):
        v = n[event[-1]]
        if v['live']:
            v['live'] = False
            v['rev'] += 1
    elif event == 'rename_B':
        v = n['B']
        if v['live']:
            v['label'] = 'Other' if v['label'] == 'Save' else 'Save'
            v['rev'] += 1
    elif event == 'enable_B':
        v = n['B']
        if v['live']:
            v['enabled'] = not v['enabled']
            v['rev'] += 1
    elif event == 'replace_surface':
        w['scope_rev'] += 1
    elif event == 'unrelated':
        w['unrelated_rev'] += 1
    elif event in ('mark_incomplete', 'mark_complete'):
        new_value = event == 'mark_complete'
        if w['complete'] != new_value:
            w['complete'] = new_value
            w['completeness_rev'] += 1
    if members(w) != before:
        w['membership_rev'] += 1


def evaluate(kind, events):
    w = initial(kind)
    observed = members(w)
    selected = observed[0] if w['complete'] and len(observed) == 1 else None
    token = (w['nodes'][selected]['rev'] if selected else None)
    old_member_rev = w['membership_rev']
    old_scope_rev = w['scope_rev']
    old_complete_rev = w['completeness_rev']
    for event in events:
        transition(w, event)
    # Every arm still relies on initial uniqueness and the selected node identity.
    node_valid = (selected is not None and w['nodes'][selected]['live']
                  and w['nodes'][selected]['rev'] == token)
    node_only = bool(node_valid)
    requery = bool(node_valid and w['complete'] and members(w) == observed
                   and w['scope_rev'] == old_scope_rev)
    certificate = bool(requery and w['membership_rev'] == old_member_rev
                       and w['completeness_rev'] == old_complete_rev)
    return dict(NODE_ONLY=node_only, MEMBERSHIP_CERT=certificate,
                ALWAYS_REQUERY=requery)


def corpus():
    for kind in TEMPLATES:
        for length in (2, 3, 4):
            for events in product(EVENTS, repeat=length):
                yield kind, events

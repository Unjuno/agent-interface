"""Fixed copied-evidence corruptions; original formal row file is never modified."""
import argparse, hashlib, json, tempfile
from pathlib import Path
from audit import audit

MUTATIONS = ('wrong_verdict','bool_alias','wrong_template','wrong_events',
             'index_bool_alias','dropped_first','duplicated_first','extra_row','truncated_last')


def mutate(lines, name):
    copy=list(lines)
    if name in MUTATIONS[:5]:
        x=json.loads(copy[0]);
        if name=='wrong_verdict': x['decisions']['MEMBERSHIP_CERT']=not x['decisions']['MEMBERSHIP_CERT']
        elif name=='bool_alias': x['decisions']['NODE_ONLY']=int(x['decisions']['NODE_ONLY'])
        elif name=='wrong_template': x['template']='multiple'
        elif name=='wrong_events': x['events']=['unrelated','unrelated']
        else: x['index']=True
        copy[0]=json.dumps(x,sort_keys=True,separators=(',',':'))+'\n'
    elif name=='dropped_first': copy=copy[1:]
    elif name=='duplicated_first': copy.insert(0,copy[0])
    elif name=='extra_row': copy.append(copy[0])
    elif name=='truncated_last': copy.pop()
    else: raise ValueError(name)
    return copy


def main():
    p=argparse.ArgumentParser();p.add_argument('raw');p.add_argument('--out',required=True)
    a=p.parse_args()
    out=Path(a.out)
    if out.exists(): raise SystemExit('REFUSE_EXISTING_CONTROLS_OUTPUT')
    lines=Path(a.raw).read_text(encoding='utf-8').splitlines(keepends=True)
    baseline=audit(a.raw)
    if baseline['errors']: raise SystemExit('BASELINE_NOT_PASSING')
    record={'baseline_errors':baseline['errors'],'controls':[]}
    with tempfile.TemporaryDirectory(prefix='phantom-controls-') as tmp:
        for i,name in enumerate(MUTATIONS):
            mutated=mutate(lines,name)
            raw=''.join(mutated).encode()
            temp=Path(tmp)/f'{i:02}.jsonl'
            temp.write_bytes(raw)
            aout=audit(temp)
            record['controls'].append({'name':name,'changed_sha256':hashlib.sha256(raw).hexdigest(),
                                       'errors':aout['errors'],'rejected':bool(aout['errors'])})
    record['all_rejected']=all(x['rejected'] for x in record['controls'])
    out.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'controls':len(MUTATIONS),'all_rejected':record['all_rejected']}))
    if not record['all_rejected']:raise SystemExit(1)

if __name__=='__main__':main()

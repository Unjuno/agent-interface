"""Offline read-only verification; it NEVER invokes the consumed candidate run.py."""
import hashlib,json,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'source'
RAW=ROOT/'formal/rows.jsonl'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def verify():
    freeze=json.loads((ROOT/'FREEZE.json').read_text())
    for name,h in freeze['source_hashes'].items():
        assert sha(ROOT/name)==h, ('source_changed',name)
    assert sha(RAW)=='e6c4e05f105a8009abe3242da19f9d845bedbdc660cb334f30d4808441d218a7'
    assert sha(ROOT/'formal/AUDIT.json')=='9ae7072eb5d6ec007631ce01d76c249faaf6772634b03bb84725f0c9abc53ea5'
    with tempfile.TemporaryDirectory(prefix='audit-only-8613-') as t:
        a=Path(t)/'audit.json';b=Path(t)/'controls.json'
        for file,out in [('audit.py',a),('controls.py',b)]:
            p=subprocess.run([sys.executable,'-B',str(SRC/file),str(RAW),'--out',str(out)],capture_output=True,text=True,timeout=100)
            assert p.returncode==0,(file,p.stderr,p.stdout)
        assert a.read_bytes()==(ROOT/'formal/AUDIT.json').read_bytes()
        assert b.read_bytes()==(ROOT/'formal/CONTROLS.json').read_bytes()
    print(json.dumps({'status':'SAVED_EVIDENCE_VERIFIED','cases':freeze['cases'],'errors':0,
                      'audit_controls':9,'science_reruns':0},sort_keys=True))
if __name__=='__main__': verify()

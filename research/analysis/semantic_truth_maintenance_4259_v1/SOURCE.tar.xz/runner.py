#!/usr/bin/env python3
import argparse, json, os, sys, time
from pathlib import Path

T='TRUE'; F='FALSE'; U='UNKNOWN'
BASE_ORDER=['target_visible','target_identity_ok','focus_ok','submit_allowed','verified_handle','document_ready','policy_permits','unrelated_theme']
DERIVED_ORDER=['target_ready','primary_submit','handle_submit','can_submit','macro_ready','attention_ok']
DEPS={
 'target_ready':('AND',['target_visible','target_identity_ok']),
 'primary_submit':('AND',['target_ready','focus_ok','submit_allowed']),
 'handle_submit':('AND',['verified_handle','focus_ok','submit_allowed']),
 'can_submit':('OR',['primary_submit','handle_submit']),
 'macro_ready':('AND',['can_submit','document_ready','policy_permits']),
 'attention_ok':('OR',['target_visible','verified_handle']),
}
INITIAL={
 'target_visible':[T,'vision',1], 'target_identity_ok':[T,'vision',1],
 'focus_ok':[T,'os',1], 'submit_allowed':[T,'rule',1],
 'verified_handle':[F,'cache',1], 'document_ready':[T,'app',1],
 'policy_permits':[T,'rule',1], 'unrelated_theme':[T,'ui',1],
}
SCHEDULE=[
 ('INITIAL',{}),
 ('UNRELATED_THEME_FALSE',{'unrelated_theme':(F,None,None)}),
 ('VERIFY_HANDLE_TRUE',{'verified_handle':(T,None,None)}),
 ('TARGET_IDENTITY_FALSE',{'target_identity_ok':(F,None,None)}),
 ('TARGET_VISIBLE_UNKNOWN',{'target_visible':(U,None,None)}),
 ('VISION_GENERATION_RESET',{'target_visible':(U,'vision',2),'target_identity_ok':(U,'vision',2)}),
 ('RESTORE_VISION_TRUE',{'target_visible':(T,'vision',2),'target_identity_ok':(T,'vision',2)}),
 ('HANDLE_FALSE',{'verified_handle':(F,None,None)}),
 ('FOCUS_UNKNOWN',{'focus_ok':(U,None,None)}),
 ('FOCUS_TRUE',{'focus_ok':(T,None,None)}),
 ('SUBMIT_FALSE',{'submit_allowed':(F,None,None)}),
 ('SUBMIT_TRUE',{'submit_allowed':(T,None,None)}),
 ('DOC_FALSE',{'document_ready':(F,None,None)}),
 ('DOC_TRUE',{'document_ready':(T,None,None)}),
]

def tv_and(vals):
    if F in vals: return F
    if U in vals: return U
    return T

def tv_or(vals):
    if T in vals: return T
    if U in vals: return U
    return F

def eval_one(name, base, derived):
    op,deps=DEPS[name]
    vals=[]
    for d in deps:
        vals.append(base[d][0] if d in base else derived[d])
    return tv_and(vals) if op=='AND' else tv_or(vals)

def full_eval(base):
    d={}
    for name in DERIVED_ORDER: d[name]=eval_one(name,base,d)
    return d

def reverse_graph():
    rev={x:set() for x in BASE_ORDER+DERIVED_ORDER}
    for name,(_,deps) in DEPS.items():
        for dep in deps: rev.setdefault(dep,set()).add(name)
    return rev
REV=reverse_graph()

def affected(changed):
    seen=set(); stack=list(changed)
    while stack:
        cur=stack.pop()
        for nxt in REV.get(cur,()):
            if nxt not in seen:
                seen.add(nxt); stack.append(nxt)
    return [n for n in DERIVED_ORDER if n in seen]

def leaves(name):
    out=set()
    def walk(x):
        if x in INITIAL: out.add(x); return
        for y in DEPS[x][1]: walk(y)
    walk(name)
    return sorted(out)
LEAVES={n:leaves(n) for n in DERIVED_ORDER}

def snapshot_base(base):
    return {k:{'value':base[k][0],'producer':base[k][1],'generation':base[k][2]} for k in BASE_ORDER}

def provenance(base, derived):
    return {n:{'direct_dependencies':list(DEPS[n][1]),'base_support':LEAVES[n],
               'support_state':{b:{'value':base[b][0],'producer':base[b][1],'generation':base[b][2]} for b in LEAVES[n]},
               'value':derived[n]} for n in DERIVED_ORDER}

def run_policy(policy):
    base={k:list(v) for k,v in INITIAL.items()}; derived={}
    rows=[]; total=0
    for idx,(event,changes) in enumerate(SCHEDULE):
        changed=[]
        for k,(value,producer,generation) in changes.items():
            base[k][0]=value
            if producer is not None: base[k][1]=producer
            if generation is not None: base[k][2]=generation
            changed.append(k)
        if idx==0:
            recomputed=list(DERIVED_ORDER)
        elif policy=='GLOBAL_INVALIDATE':
            recomputed=list(DERIVED_ORDER)
        elif policy=='SUPPORT_SET_RETRACTION':
            recomputed=affected(changed)
        else: raise ValueError(policy)
        if idx==0 or policy=='GLOBAL_INVALIDATE':
            derived=full_eval(base)
        else:
            for n in recomputed: derived[n]=eval_one(n,base,derived)
        total += len(recomputed)
        rows.append({'schema':'agent-interface/semantic-truth-maintenance-row-v1','policy':policy,
                     'step':idx,'event':event,'changed_base':changed,'base':snapshot_base(base),
                     'derived':dict(derived),'recomputed':recomputed,'recompute_count':len(recomputed),
                     'cumulative_recomputes':total,'macro_ready':derived['macro_ready'],
                     'provenance':provenance(base,derived),'authority':'none'})
    return rows

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--mode',choices=['construction','formal'],required=True); ap.add_argument('--out',required=True)
    a=ap.parse_args(); out=Path(a.out)
    if out.exists(): raise SystemExit('output exists')
    out.mkdir(parents=True)
    started=time.time_ns()
    rows=[]
    for p in ['GLOBAL_INVALIDATE','SUPPORT_SET_RETRACTION']: rows += run_policy(p)
    raw=out/'RAW.jsonl'
    raw.write_text(''.join(json.dumps(r,sort_keys=True,separators=(',',':'))+'\n' for r in rows))
    meta={'schema':'agent-interface/semantic-truth-maintenance-run-v1','mode':a.mode,'row_count':len(rows),
          'policies':['GLOBAL_INVALIDATE','SUPPORT_SET_RETRACTION'],'schedule_steps':len(SCHEDULE),
          'started_ns':started,'ended_ns':time.time_ns(),'formal_reruns':0,'authority':'none'}
    (out/'RUN.json').write_text(json.dumps(meta,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'rows':len(rows),'global':rows[13]['cumulative_recomputes'],'support':rows[-1]['cumulative_recomputes']},sort_keys=True))
if __name__=='__main__': main()

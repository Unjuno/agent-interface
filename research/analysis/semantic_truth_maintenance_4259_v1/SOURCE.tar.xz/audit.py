#!/usr/bin/env python3
import argparse, copy, json, sys
from pathlib import Path
T='TRUE'; F='FALSE'; U='UNKNOWN'
BASE_ORDER=['target_visible','target_identity_ok','focus_ok','submit_allowed','verified_handle','document_ready','policy_permits','unrelated_theme']
DERIVED_ORDER=['target_ready','primary_submit','handle_submit','can_submit','macro_ready','attention_ok']
DEPS={
 'target_ready':('AND',['target_visible','target_identity_ok']),
 'primary_submit':('AND',['target_ready','focus_ok','submit_allowed']),
 'handle_submit':('AND',['verified_handle','focus_ok','submit_allowed']),
 'can_submit':('OR',['primary_submit','handle_submit']),
 'macro_ready':('AND',['can_submit','document_ready','policy_permits']),
 'attention_ok':('OR',['target_visible','verified_handle']),
}
EVENT_CHANGES={
 'INITIAL':[], 'UNRELATED_THEME_FALSE':['unrelated_theme'], 'VERIFY_HANDLE_TRUE':['verified_handle'],
 'TARGET_IDENTITY_FALSE':['target_identity_ok'], 'TARGET_VISIBLE_UNKNOWN':['target_visible'],
 'VISION_GENERATION_RESET':['target_visible','target_identity_ok'], 'RESTORE_VISION_TRUE':['target_visible','target_identity_ok'],
 'HANDLE_FALSE':['verified_handle'], 'FOCUS_UNKNOWN':['focus_ok'], 'FOCUS_TRUE':['focus_ok'],
 'SUBMIT_FALSE':['submit_allowed'], 'SUBMIT_TRUE':['submit_allowed'], 'DOC_FALSE':['document_ready'], 'DOC_TRUE':['document_ready'],
}

def tri(op,vals):
    if op=='AND':
        return F if F in vals else U if U in vals else T
    return T if T in vals else U if U in vals else F

def oracle(base):
    d={}
    for n in DERIVED_ORDER:
        op,deps=DEPS[n]; vals=[base[x]['value'] if x in base else d[x] for x in deps]; d[n]=tri(op,vals)
    return d

def rev():
    r={x:set() for x in BASE_ORDER+DERIVED_ORDER}
    for n,(_,ds) in DEPS.items():
        for d in ds:r.setdefault(d,set()).add(n)
    return r
REV=rev()

def closure(changed):
    seen=set(); q=list(changed)
    while q:
        x=q.pop()
        for n in REV.get(x,()):
            if n not in seen: seen.add(n); q.append(n)
    return [n for n in DERIVED_ORDER if n in seen]

def leafset(n):
    s=set()
    def w(x):
        if x in BASE_ORDER:s.add(x)
        else:
            for y in DEPS[x][1]:w(y)
    w(n);return sorted(s)
LEAF={n:leafset(n) for n in DERIVED_ORDER}

def audit_rows(rows):
    errs=[]
    if len(rows)!=28: errs.append('row_count')
    groups={p:[] for p in ['GLOBAL_INVALIDATE','SUPPORT_SET_RETRACTION']}
    for r in rows:
        if r.get('policy') not in groups: errs.append('policy'); continue
        groups[r['policy']].append(r)
    for p,rs in groups.items():
        rs.sort(key=lambda x:x.get('step',-1))
        if [r.get('step') for r in rs]!=list(range(14)): errs.append(f'{p}:steps'); continue
        cumulative=0
        for i,r in enumerate(rs):
            if r.get('event') not in EVENT_CHANGES: errs.append(f'{p}:{i}:event'); continue
            if r.get('changed_base')!=EVENT_CHANGES[r['event']]: errs.append(f'{p}:{i}:changed')
            base=r.get('base',{})
            if set(base)!=set(BASE_ORDER): errs.append(f'{p}:{i}:basekeys'); continue
            expected=oracle(base)
            if r.get('derived')!=expected: errs.append(f'{p}:{i}:lattice')
            exp_recomp=DERIVED_ORDER if i==0 or p=='GLOBAL_INVALIDATE' else closure(EVENT_CHANGES[r['event']])
            if r.get('recomputed')!=exp_recomp: errs.append(f'{p}:{i}:recomputed')
            if r.get('recompute_count')!=len(exp_recomp): errs.append(f'{p}:{i}:recount')
            cumulative += len(exp_recomp)
            if r.get('cumulative_recomputes')!=cumulative: errs.append(f'{p}:{i}:cumulative')
            if r.get('macro_ready')!=expected['macro_ready']: errs.append(f'{p}:{i}:macro')
            if r.get('authority')!='none': errs.append(f'{p}:{i}:authority')
            prov=r.get('provenance',{})
            if set(prov)!=set(DERIVED_ORDER): errs.append(f'{p}:{i}:provkeys'); continue
            for n in DERIVED_ORDER:
                x=prov[n]
                if x.get('direct_dependencies')!=DEPS[n][1] or x.get('base_support')!=LEAF[n] or x.get('value')!=expected[n]:
                    errs.append(f'{p}:{i}:prov:{n}'); break
                ss=x.get('support_state',{})
                if list(sorted(ss))!=LEAF[n]: errs.append(f'{p}:{i}:support:{n}'); break
                for b in LEAF[n]:
                    if ss[b]!=base[b]: errs.append(f'{p}:{i}:supportstate:{n}:{b}'); break
    if not errs:
        g=groups['GLOBAL_INVALIDATE'][-1]['cumulative_recomputes']; s=groups['SUPPORT_SET_RETRACTION'][-1]['cumulative_recomputes']
        if not s<g: errs.append('no_incremental_value')
        # critical semantic controls
        by={(r['policy'],r['event']):r for r in rows}
        if by[('SUPPORT_SET_RETRACTION','UNRELATED_THEME_FALSE')]['recompute_count']!=0: errs.append('unrelated_not_preserved')
        if by[('SUPPORT_SET_RETRACTION','VISION_GENERATION_RESET')]['derived']['target_ready']!=U: errs.append('generation_reset_not_unknown')
        if by[('SUPPORT_SET_RETRACTION','TARGET_IDENTITY_FALSE')]['derived']['can_submit']!=T: errs.append('alternate_support_failed')
        if by[('SUPPORT_SET_RETRACTION','FOCUS_UNKNOWN')]['derived']['macro_ready']!=U: errs.append('unknown_not_propagated')
    return errs

def read_rows(path):
    return [json.loads(x) for x in Path(path).read_text().splitlines() if x.strip()]

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('raw'); ap.add_argument('--out',required=True); a=ap.parse_args()
    rows=read_rows(a.raw); errs=audit_rows(rows)
    g=[r for r in rows if r.get('policy')=='GLOBAL_INVALIDATE']; s=[r for r in rows if r.get('policy')=='SUPPORT_SET_RETRACTION']
    result={'schema':'agent-interface/semantic-truth-maintenance-audit-v1','errors':errs,'audit_pass':not errs,
            'rows':len(rows),'global_recomputes':g[-1]['cumulative_recomputes'] if g else None,
            'support_recomputes':s[-1]['cumulative_recomputes'] if s else None,
            'decision':'PASS_SEMANTIC_TRUTH_MAINTENANCE_SCOPED' if not errs else 'FAIL_INTEGRITY'}
    Path(a.out).write_text(json.dumps(result,sort_keys=True,indent=2)+'\n'); print(json.dumps(result,sort_keys=True))
    return 0 if not errs else 1
if __name__=='__main__':raise SystemExit(main())

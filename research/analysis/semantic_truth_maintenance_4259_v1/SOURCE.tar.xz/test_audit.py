#!/usr/bin/env python3
import copy, json, sys
from pathlib import Path
import audit

def rows(path): return audit.read_rows(path)
def rejected(base, mut):
    z=copy.deepcopy(base); mut(z); return bool(audit.audit_rows(z))
def main():
    raw=Path(sys.argv[1]); base=rows(raw)
    muts=[
      ('drop_row',lambda z:z.pop()),
      ('dup_row',lambda z:z.append(copy.deepcopy(z[-1]))),
      ('wrong_lattice',lambda z:z[3]['derived'].__setitem__('can_submit','FALSE')),
      ('wrong_recomputed',lambda z:z[15].__setitem__('recomputed',['macro_ready'])),
      ('wrong_count',lambda z:z[15].__setitem__('recompute_count',99)),
      ('wrong_cumulative',lambda z:z[20].__setitem__('cumulative_recomputes',999)),
      ('authority',lambda z:z[0].__setitem__('authority','task')),
      ('generation',lambda z:z[5]['base']['target_visible'].__setitem__('generation',1)),
      ('provenance_leaf',lambda z:z[6]['provenance']['macro_ready'].__setitem__('base_support',[])),
      ('support_state',lambda z:z[6]['provenance']['macro_ready']['support_state']['focus_ok'].__setitem__('value','FALSE')),
      ('changed_base',lambda z:z[1].__setitem__('changed_base',[])),
      ('macro_ready',lambda z:z[8].__setitem__('macro_ready','TRUE')),
    ]
    out=[]
    for n,m in muts: out.append({'name':n,'rejected':rejected(base,m)})
    print(json.dumps(out,sort_keys=True))
    if not all(x['rejected'] for x in out): return 1
    return 0
if __name__=='__main__':raise SystemExit(main())

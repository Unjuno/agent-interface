import json, pathlib
from model import AuthenticatedLedger, UnauthenticatedLedger, Intent
F=json.loads(pathlib.Path('fixtures.json').read_text())
TRUST={'issuer-root-v1':bytes.fromhex(F['trusted_public_key_hex'])}
fresh=Intent('A',2,1,4,5,confirmation_revision=4)
old=Intent('A',1,1,4,5,confirmation_revision=4)

b=UnauthenticatedLedger(); bi=b.install(F['valid']['receipt']); ba=b.apply_intent(fresh)
valid=AuthenticatedLedger(TRUST); vi=valid.install_signed(F['valid']); va=valid.apply_intent(fresh)
restart=AuthenticatedLedger(TRUST,durable_signed_receipt=F['valid']); ro=restart.classify_intent(old); rf=restart.apply_intent(fresh)
tam=AuthenticatedLedger(TRUST); ti=tam.install_signed(F['tampered'])
wrong=AuthenticatedLedger(TRUST); wi=wrong.install_signed(F['wrong_signer'])
conf=AuthenticatedLedger(TRUST); ci1=conf.install_signed(F['valid']); ci2=conf.install_signed(F['same_id_changed_trusted'])
replay=AuthenticatedLedger(TRUST); ri1=replay.install_signed(F['valid']); ri2=replay.install_signed(F['valid'])

result={
 'task':'COORD-AUTH-INCARNATION-INSTALL-20260917-026',
 'cases':{
  'unauthenticated_forged_install_baseline':{'install':bi,'fresh_i2_apply':ba,'generation':b.generation,'install_writes':b.install_writes},
  'authenticated_valid_install':{'install':vi,'fresh_i2_apply':va,'snapshot':valid.snapshot()},
  'authenticated_restart_recovery':{'old_i1_classification':ro,'fresh_i2_apply':rf,'snapshot':restart.snapshot()},
  'authenticated_content_tamper':{'install':ti,'snapshot':tam.snapshot()},
  'authenticated_wrong_signer':{'install':wi,'snapshot':wrong.snapshot()},
  'signed_replay_and_conflict_controls':{'exact_first':ri1,'exact_replay':ri2,'changed_first':ci1,'same_id_changed_content':ci2},
 },
 'gates':{
  'baseline_forged_install_applies': bi=='INSTALLED' and ba=='APPLIED' and b.generation==5,
  'trusted_signed_install_applies_once': vi=='INSTALLED' and va=='APPLIED' and valid.transition_writes==1,
  'restart_recovers_i2': restart.current_incarnation==2 and ro=='STALE_ISSUER_INCARNATION' and rf=='APPLIED',
  'tamper_rejected_before_install_write': ti=='INSTALL_SIGNATURE_INVALID' and tam.install_writes==0 and tam.current_incarnation==1,
  'wrong_signer_rejected_before_install_write': wi=='UNTRUSTED_INSTALL_SIGNER' and wrong.install_writes==0 and wrong.current_incarnation==1,
  'exact_signed_replay_idempotent': ri2=='ALREADY_INSTALLED_SELF' and replay.install_writes==1,
  'same_id_changed_signed_content_conflicts': ci2=='INSTALL_RECEIPT_CONFLICT' and conf.current_incarnation==2,
  'retained_has_no_private_key_files': not any(('private' in p.name.lower() or p.name.lower().endswith('.key')) for p in pathlib.Path('.').iterdir()),
 },
 'formal_reruns':0,
}
result['decision']='PASS_AUTHENTICATED_INCARNATION_INSTALL_RECEIPT_SCOPED' if all(result['gates'].values()) else 'FAIL_AUTHENTICATED_INCARNATION_INSTALL_RECEIPT_SCOPED'
pathlib.Path('result.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,indent=2,sort_keys=True))

import json, pathlib, sys
r=json.loads(pathlib.Path('result.json').read_text())
expected='PASS_AUTHENTICATED_INCARNATION_INSTALL_RECEIPT_SCOPED'
if r['decision']!=expected or not all(r['gates'].values()) or r['formal_reruns']!=0:
    raise SystemExit('FAIL_VERIFY')
if any(('private' in p.name.lower() or p.name.lower().endswith('.key')) for p in pathlib.Path('.').iterdir()):
    raise SystemExit('FAIL_PRIVATE_KEY_RETAINED')
print('PASS_VERIFY')

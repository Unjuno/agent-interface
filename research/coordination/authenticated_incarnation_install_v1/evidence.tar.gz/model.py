from __future__ import annotations
from dataclasses import dataclass, asdict
import json
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.exceptions import InvalidSignature


def canonical_receipt_bytes(receipt: dict) -> bytes:
    return json.dumps(receipt, sort_keys=True, separators=(",", ":")).encode("utf-8")

@dataclass(frozen=True)
class Intent:
    intent_id: str
    issuer_incarnation: int
    intent_seq: int
    from_generation: int
    to_generation: int
    confirmation_content_id: str = "content-C"
    confirmation_revision: int = 1

class UnauthenticatedLedger:
    def __init__(self):
        self.current_incarnation = 1
        self.generation = 4
        self.install_writes = 0
        self.transition_writes = 0
        self.latest_install_receipt = None
    def install(self, receipt: dict) -> str:
        if receipt["previous_incarnation"] != self.current_incarnation:
            return "INSTALL_PREVIOUS_MISMATCH"
        self.current_incarnation = receipt["new_incarnation"]
        self.latest_install_receipt = dict(receipt)
        self.install_writes += 1
        return "INSTALLED"
    def classify_intent(self, intent: Intent) -> str:
        if intent.issuer_incarnation != self.current_incarnation:
            return "STALE_ISSUER_INCARNATION"
        if intent.from_generation != self.generation or intent.to_generation != self.generation + 1:
            return "GENERATION_MISMATCH"
        return "NEW_INTENT_ALLOWED"
    def apply_intent(self, intent: Intent) -> str:
        if self.classify_intent(intent) != "NEW_INTENT_ALLOWED":
            return "REJECTED"
        self.generation = intent.to_generation
        self.transition_writes += 1
        return "APPLIED"

class AuthenticatedLedger:
    def __init__(self, trusted_keys: dict[str, bytes], durable_signed_receipt: dict | None = None):
        self.trusted_keys = dict(trusted_keys)
        self.current_incarnation = 1
        self.generation = 4
        self.install_writes = 0
        self.transition_writes = 0
        self.latest_install_receipt = None
        self._installed_by_id: dict[str, dict] = {}
        if durable_signed_receipt is not None:
            outcome = self.install_signed(durable_signed_receipt)
            if outcome not in {"INSTALLED", "ALREADY_INSTALLED_SELF"}:
                raise ValueError(outcome)
    def _verify(self, signed: dict) -> str:
        receipt = signed["receipt"]
        signer_id = receipt["signer_id"]
        raw_key = self.trusted_keys.get(signer_id)
        if raw_key is None:
            return "UNTRUSTED_INSTALL_SIGNER"
        try:
            Ed25519PublicKey.from_public_bytes(raw_key).verify(bytes.fromhex(signed["signature_hex"]), canonical_receipt_bytes(receipt))
        except (InvalidSignature, ValueError):
            return "INSTALL_SIGNATURE_INVALID"
        return "VERIFIED"
    def install_signed(self, signed: dict) -> str:
        verified = self._verify(signed)
        if verified != "VERIFIED":
            return verified
        receipt = dict(signed["receipt"])
        install_id = receipt["install_id"]
        prior = self._installed_by_id.get(install_id)
        if prior is not None:
            if prior == receipt:
                return "ALREADY_INSTALLED_SELF"
            return "INSTALL_RECEIPT_CONFLICT"
        if receipt["previous_incarnation"] != self.current_incarnation:
            return "INSTALL_PREVIOUS_MISMATCH"
        if receipt["new_incarnation"] != self.current_incarnation + 1:
            return "INSTALL_NONCONSECUTIVE"
        self._installed_by_id[install_id] = receipt
        self.latest_install_receipt = receipt
        self.current_incarnation = receipt["new_incarnation"]
        self.install_writes += 1
        return "INSTALLED"
    def classify_intent(self, intent: Intent) -> str:
        if intent.issuer_incarnation != self.current_incarnation:
            return "STALE_ISSUER_INCARNATION"
        if intent.from_generation != self.generation or intent.to_generation != self.generation + 1:
            return "GENERATION_MISMATCH"
        return "NEW_INTENT_ALLOWED"
    def apply_intent(self, intent: Intent) -> str:
        if self.classify_intent(intent) != "NEW_INTENT_ALLOWED":
            return "REJECTED"
        self.generation = intent.to_generation
        self.transition_writes += 1
        return "APPLIED"
    def snapshot(self):
        return {
            "current_incarnation": self.current_incarnation,
            "generation": self.generation,
            "install_writes": self.install_writes,
            "transition_writes": self.transition_writes,
            "latest_install_receipt": self.latest_install_receipt,
            "trusted_signers": sorted(self.trusted_keys),
        }

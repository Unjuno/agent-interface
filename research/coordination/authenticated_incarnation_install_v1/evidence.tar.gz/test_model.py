import json, pathlib, unittest
from model import AuthenticatedLedger, UnauthenticatedLedger, Intent

F=json.loads(pathlib.Path('fixtures.json').read_text())
TRUST={'issuer-root-v1':bytes.fromhex(F['trusted_public_key_hex'])}
INTENT=Intent('A',2,1,4,5,confirmation_revision=4)

class Tests(unittest.TestCase):
    def test_unauthenticated_accepts_forged(self):
        l=UnauthenticatedLedger(); self.assertEqual(l.install(F['valid']['receipt']),'INSTALLED'); self.assertEqual(l.apply_intent(INTENT),'APPLIED')
    def test_valid_signed_install(self):
        l=AuthenticatedLedger(TRUST); self.assertEqual(l.install_signed(F['valid']),'INSTALLED'); self.assertEqual(l.apply_intent(INTENT),'APPLIED')
    def test_tamper_invalid(self):
        l=AuthenticatedLedger(TRUST); self.assertEqual(l.install_signed(F['tampered']),'INSTALL_SIGNATURE_INVALID'); self.assertEqual(l.install_writes,0)
    def test_wrong_signer(self):
        l=AuthenticatedLedger(TRUST); self.assertEqual(l.install_signed(F['wrong_signer']),'UNTRUSTED_INSTALL_SIGNER'); self.assertEqual(l.install_writes,0)
    def test_exact_replay_idempotent(self):
        l=AuthenticatedLedger(TRUST); self.assertEqual(l.install_signed(F['valid']),'INSTALLED'); self.assertEqual(l.install_signed(F['valid']),'ALREADY_INSTALLED_SELF'); self.assertEqual(l.install_writes,1)
    def test_same_id_changed_signed_content_conflicts(self):
        l=AuthenticatedLedger(TRUST); self.assertEqual(l.install_signed(F['valid']),'INSTALLED'); self.assertEqual(l.install_signed(F['same_id_changed_trusted']),'INSTALL_RECEIPT_CONFLICT')
    def test_restart_recovery(self):
        l=AuthenticatedLedger(TRUST,durable_signed_receipt=F['valid']); self.assertEqual(l.current_incarnation,2); self.assertEqual(l.apply_intent(INTENT),'APPLIED')
    def test_old_incarnation_stale_after_recovery(self):
        l=AuthenticatedLedger(TRUST,durable_signed_receipt=F['valid']); old=Intent('A',1,1,4,5); self.assertEqual(l.classify_intent(old),'STALE_ISSUER_INCARNATION')
    def test_no_private_key_files_in_retained(self):
        names=[p.name.lower() for p in pathlib.Path('.').iterdir()]; self.assertFalse(any('private' in n or n.endswith('.key') for n in names))

if __name__=='__main__': unittest.main()

import json, unittest
from model import Ledger
F=json.load(open('fixtures.json'))
def ledger():
    p=F['public_keys']; hs=F['public_key_hashes']
    kr={hs['k2']:p['k2'],hs['k3']:p['k3'],hs['attacker']:p['attacker']}
    return Ledger(2,'issuer-root-v2',p['k2'],p['root'],kr)
class T(unittest.TestCase):
    def test_baseline_compromised_current_signer(self):
        l=ledger(); x=F['rotation_attacker']; self.assertEqual(l.normal_rotate(x['receipt'],x['signature']),'ROTATED')
        x=F['install_attacker']; self.assertEqual(l.install(x['receipt'],x['signature']),'INSTALLED')
    def test_recovery_replaces_k2(self):
        l=ledger(); x=F['recovery']; self.assertEqual(l.recover(x['receipt'],x['signature']),'RECOVERED'); self.assertEqual(l.current_signer_id,'issuer-root-v3')
    def test_old_k2_stale(self):
        l=ledger(); x=F['recovery']; l.recover(x['receipt'],x['signature']); x=F['install_old_k2']; self.assertEqual(l.install(x['receipt'],x['signature']),'STALE_INSTALL_KEY_EPOCH')
    def test_k3_live(self):
        l=ledger(); x=F['recovery']; l.recover(x['receipt'],x['signature']); x=F['install_k3']; self.assertEqual(l.install(x['receipt'],x['signature']),'INSTALLED')
    def test_forged_recovery(self):
        l=ledger(); x=F['recovery_forged_by_k2']; self.assertEqual(l.recover(x['receipt'],x['signature']),'RECOVERY_SIGNATURE_INVALID'); self.assertEqual(l.recovery_writes,0)
    def test_replay(self):
        l=ledger(); x=F['recovery']; self.assertEqual(l.recover(x['receipt'],x['signature']),'RECOVERED'); self.assertEqual(l.recover(x['receipt'],x['signature']),'ALREADY_RECOVERED_SELF')
    def test_conflict(self):
        l=ledger(); x=F['recovery']; l.recover(x['receipt'],x['signature']); y=F['recovery_changed_valid_root']; self.assertEqual(l.recover(y['receipt'],y['signature']),'RECOVERY_RECEIPT_CONFLICT')
    def test_restart(self):
        l=ledger(); x=F['recovery']; l.recover(x['receipt'],x['signature']); r=Ledger.restart_from_recovery(l.latest_recovery,F['public_keys']['root'],l.keyring_by_hash); self.assertEqual(r.current_signer_id,'issuer-root-v3'); self.assertEqual(r.reconcile_recovery(),'RECOVERY_STATE_OK')
    def test_epoch_gap(self):
        l=ledger(); x=dict(F['recovery']['receipt']); x['recovery_epoch']=2; self.assertEqual(l.recover(x,F['recovery']['signature']),'RECOVERY_EPOCH_GAP')
if __name__=='__main__': unittest.main()

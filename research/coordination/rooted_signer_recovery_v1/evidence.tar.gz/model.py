from __future__ import annotations
import base64, hashlib, json
from dataclasses import dataclass
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.exceptions import InvalidSignature

def canon(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()

def pub_hash(pub_b64: str) -> str:
    return hashlib.sha256(base64.b64decode(pub_b64)).hexdigest()

def verify(pub_b64: str, obj: dict, sig_b64: str) -> bool:
    try:
        Ed25519PublicKey.from_public_bytes(base64.b64decode(pub_b64)).verify(base64.b64decode(sig_b64), canon(obj))
        return True
    except (InvalidSignature, ValueError):
        return False

@dataclass
class Ledger:
    current_key_epoch: int
    current_signer_id: str
    current_public_key_b64: str
    recovery_root_public_key_b64: str
    keyring_by_hash: dict
    current_incarnation: int = 2
    generation: int = 5
    recovery_epoch: int = 0
    latest_recovery: dict | None = None
    latest_install: dict | None = None
    rotation_writes: int = 0
    recovery_writes: int = 0
    install_writes: int = 0
    transition_writes: int = 0

    def normal_rotate(self, rec: dict, sig: str) -> str:
        if rec["previous_key_epoch"] != self.current_key_epoch or rec["previous_signer_id"] != self.current_signer_id:
            return "ROTATION_PREDECESSOR_MISMATCH"
        if rec["new_key_epoch"] != self.current_key_epoch + 1:
            return "ROTATION_EPOCH_GAP"
        if not verify(self.current_public_key_b64, rec, sig):
            return "ROTATION_SIGNATURE_INVALID"
        new_pub = self.keyring_by_hash.get(rec["new_public_key_sha256"])
        if not new_pub:
            return "ROTATION_UNKNOWN_NEW_KEY"
        self.current_key_epoch = rec["new_key_epoch"]
        self.current_signer_id = rec["new_signer_id"]
        self.current_public_key_b64 = new_pub
        self.rotation_writes += 1
        return "ROTATED"

    def recover(self, rec: dict, sig: str) -> str:
        if self.latest_recovery and rec["recovery_id"] == self.latest_recovery["recovery_id"]:
            if rec == self.latest_recovery:
                return "ALREADY_RECOVERED_SELF"
            return "RECOVERY_RECEIPT_CONFLICT"
        if rec["recovery_epoch"] != self.recovery_epoch + 1:
            return "RECOVERY_EPOCH_GAP"
        if rec["previous_key_epoch"] != self.current_key_epoch or rec["previous_signer_id"] != self.current_signer_id:
            return "RECOVERY_PREDECESSOR_MISMATCH"
        if rec["new_key_epoch"] != self.current_key_epoch + 1:
            return "RECOVERY_KEY_EPOCH_GAP"
        if not verify(self.recovery_root_public_key_b64, rec, sig):
            return "RECOVERY_SIGNATURE_INVALID"
        new_pub = self.keyring_by_hash.get(rec["new_public_key_sha256"])
        if not new_pub:
            return "RECOVERY_UNKNOWN_NEW_KEY"
        self.latest_recovery = dict(rec)
        self.recovery_epoch = rec["recovery_epoch"]
        self.current_key_epoch = rec["new_key_epoch"]
        self.current_signer_id = rec["new_signer_id"]
        self.current_public_key_b64 = new_pub
        self.recovery_writes += 1
        return "RECOVERED"

    def reconcile_recovery(self) -> str:
        if not self.latest_recovery:
            return "NO_RECOVERY_RECEIPT"
        r = self.latest_recovery
        if (self.current_key_epoch, self.current_signer_id, pub_hash(self.current_public_key_b64)) != (
            r["new_key_epoch"], r["new_signer_id"], r["new_public_key_sha256"]
        ):
            return "RECOVERY_STATE_ROLLBACK"
        return "RECOVERY_STATE_OK"

    @classmethod
    def restart_from_recovery(cls, durable_recovery: dict, root_pub: str, keyring: dict, *, generation=5, current_incarnation=2):
        new_pub = keyring[durable_recovery["new_public_key_sha256"]]
        return cls(
            current_key_epoch=durable_recovery["new_key_epoch"],
            current_signer_id=durable_recovery["new_signer_id"],
            current_public_key_b64=new_pub,
            recovery_root_public_key_b64=root_pub,
            keyring_by_hash=keyring,
            current_incarnation=current_incarnation,
            generation=generation,
            recovery_epoch=durable_recovery["recovery_epoch"],
            latest_recovery=dict(durable_recovery),
        )

    def install(self, rec: dict, sig: str) -> str:
        if rec["key_epoch"] < self.current_key_epoch:
            return "STALE_INSTALL_KEY_EPOCH"
        if rec["key_epoch"] > self.current_key_epoch:
            return "FUTURE_INSTALL_KEY_EPOCH"
        if rec["signer_id"] != self.current_signer_id:
            return "UNTRUSTED_INSTALL_SIGNER"
        if not verify(self.current_public_key_b64, rec, sig):
            return "INSTALL_SIGNATURE_INVALID"
        if self.latest_install and rec["install_id"] == self.latest_install["install_id"]:
            if rec == self.latest_install:
                return "ALREADY_INSTALLED_SELF"
            return "INSTALL_RECEIPT_CONFLICT"
        if rec["previous_incarnation"] != self.current_incarnation or rec["new_incarnation"] != self.current_incarnation + 1:
            return "INSTALL_INCARNATION_MISMATCH"
        self.current_incarnation = rec["new_incarnation"]
        self.latest_install = dict(rec)
        self.install_writes += 1
        return "INSTALLED"

    def apply_fresh_work(self) -> str:
        self.generation += 1
        self.transition_writes += 1
        return "APPLIED"

    def snap(self):
        return {
            "current_key_epoch": self.current_key_epoch,
            "current_signer_id": self.current_signer_id,
            "current_public_key_sha256": pub_hash(self.current_public_key_b64),
            "current_incarnation": self.current_incarnation,
            "generation": self.generation,
            "recovery_epoch": self.recovery_epoch,
            "latest_recovery": self.latest_recovery,
            "latest_install": self.latest_install,
            "rotation_writes": self.rotation_writes,
            "recovery_writes": self.recovery_writes,
            "install_writes": self.install_writes,
            "transition_writes": self.transition_writes,
            "state_shape": "current_key_scalars_plus_one_durable_recovery_receipt"
        }

import json, sys
r=json.load(open('result.json'))
assert r['task']=='COORD-ROOTED-SIGNER-RECOVERY-20260917-029'
assert r['decision']=='PASS_ROOTED_SIGNER_RECOVERY_SCOPED'
assert all(r['gates'].values())
assert r['formal_reruns']==0
print('PASS_VERIFY')

import json
from model import Ledger
F=json.load(open('fixtures.json'))
def ledger():
    p=F['public_keys']; hs=F['public_key_hashes']; kr={hs['k2']:p['k2'],hs['k3']:p['k3'],hs['attacker']:p['attacker']}
    return Ledger(2,'issuer-root-v2',p['k2'],p['root'],kr)
R={"task":"COORD-ROOTED-SIGNER-RECOVERY-20260917-029","formal_reruns":0,"cases":{},"gates":{}}
# baseline
l=ledger(); x=F['rotation_attacker']; rot=l.normal_rotate(x['receipt'],x['signature']); x=F['install_attacker']; ins=l.install(x['receipt'],x['signature']); app=l.apply_fresh_work() if ins=='INSTALLED' else 'NOT_APPLIED'
R['cases']['compromised_current_signer_baseline']={"rotation":rot,"attacker_install":ins,"fresh_i3_apply":app,"snapshot":l.snap()}
# rooted recovery
l=ledger(); x=F['recovery']; rec=l.recover(x['receipt'],x['signature']); old=F['install_old_k2']; oldr=l.install(old['receipt'],old['signature']); new=F['install_k3']; newr=l.install(new['receipt'],new['signature']); app=l.apply_fresh_work() if newr=='INSTALLED' else 'NOT_APPLIED'
R['cases']['root_recovery_replaces_compromised']={"recovery":rec,"old_k2_install":oldr,"k3_install":newr,"fresh_i3_apply":app,"snapshot":l.snap()}
# forged
l=ledger(); x=F['recovery_forged_by_k2']; fr=l.recover(x['receipt'],x['signature']); R['cases']['forged_recovery_rejected']={"recovery":fr,"recovery_writes_after_attempt":l.recovery_writes,"snapshot":l.snap()}
# restart
l=ledger(); x=F['recovery']; l.recover(x['receipt'],x['signature']); r=Ledger.restart_from_recovery(l.latest_recovery,F['public_keys']['root'],l.keyring_by_hash); old=F['install_old_k2']; oldr=r.install(old['receipt'],old['signature']); new=F['install_k3']; newr=r.install(new['receipt'],new['signature']); app=r.apply_fresh_work() if newr=='INSTALLED' else 'NOT_APPLIED'
R['cases']['recovery_restart_reconstruction']={"reconcile":r.reconcile_recovery(),"old_k2_install":oldr,"k3_install":newr,"fresh_i3_apply":app,"snapshot":r.snap()}
# controls
l=ledger(); x=F['recovery']; a=l.recover(x['receipt'],x['signature']); replay=l.recover(x['receipt'],x['signature']); y=F['recovery_changed_valid_root']; conflict=l.recover(y['receipt'],y['signature']); gap=dict(F['recovery']['receipt']); gap['recovery_id']='gap'; gap['recovery_epoch']=3
R['cases']['controls']={"first":a,"exact_replay":replay,"same_id_changed_content":conflict,"epoch_gap":l.recover(gap,F['recovery']['signature'])}
C=R['cases']
R['gates']={
 "baseline_compromised_k2_can_mint_attacker": C['compromised_current_signer_baseline']['rotation']=='ROTATED' and C['compromised_current_signer_baseline']['attacker_install']=='INSTALLED' and C['compromised_current_signer_baseline']['fresh_i3_apply']=='APPLIED',
 "root_recovery_without_k2_cooperation": C['root_recovery_replaces_compromised']['recovery']=='RECOVERED',
 "old_k2_stale_after_recovery": C['root_recovery_replaces_compromised']['old_k2_install']=='STALE_INSTALL_KEY_EPOCH',
 "k3_live_after_recovery": C['root_recovery_replaces_compromised']['k3_install']=='INSTALLED' and C['root_recovery_replaces_compromised']['fresh_i3_apply']=='APPLIED',
 "forged_recovery_zero_write": C['forged_recovery_rejected']['recovery']=='RECOVERY_SIGNATURE_INVALID' and C['forged_recovery_rejected']['recovery_writes_after_attempt']==0,
 "restart_reconstructs_k3": C['recovery_restart_reconstruction']['reconcile']=='RECOVERY_STATE_OK' and C['recovery_restart_reconstruction']['old_k2_install']=='STALE_INSTALL_KEY_EPOCH' and C['recovery_restart_reconstruction']['k3_install']=='INSTALLED' and C['recovery_restart_reconstruction']['fresh_i3_apply']=='APPLIED',
 "exact_replay_idempotent": C['controls']['exact_replay']=='ALREADY_RECOVERED_SELF',
 "same_id_changed_content_conflicts": C['controls']['same_id_changed_content']=='RECOVERY_RECEIPT_CONFLICT',
 "epoch_gap_rejected": C['controls']['epoch_gap']=='RECOVERY_EPOCH_GAP',
}
R['decision']='PASS_ROOTED_SIGNER_RECOVERY_SCOPED' if all(R['gates'].values()) else 'FAIL_ROOTED_SIGNER_RECOVERY_SCOPED'
open('result.json','w').write(json.dumps(R,indent=2,sort_keys=True)+"\n")
print(json.dumps(R,indent=2,sort_keys=True))

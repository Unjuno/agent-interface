from __future__ import annotations
import argparse,hashlib,json,random
from pathlib import Path
from validator import graph_for,validate_structural,validate_typed,execute,ValidationError

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
SAFE={"safe_current_admission","safe_hint_revalidated","safe_invalidator_to_planner","safe_effect_to_terminal","safe_hint_to_planner"}
UNSAFE={"unsafe_hint_direct","unsafe_planner_direct","unsafe_invalidator_direct","unsafe_effect_direct","unsafe_historical_admission"}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--plan',required=True); ap.add_argument('--out',required=True); a=ap.parse_args()
    out=Path(a.out)
    if out.exists(): raise SystemExit('refuse existing output')
    plan=json.loads(Path(a.plan).read_text())
    sched=[(r,s) for r in range(plan['repetitions']) for s in plan['scenarios']]
    random.Random(plan['seed']).shuffle(sched)
    rows=[]
    for idx,(rep,scenario) in enumerate(sched):
        g=graph_for(scenario)
        for policy in ('structural_only','typed_roles'):
            validator=validate_structural if policy=='structural_only' else validate_typed
            accepted=True; reason=None; runtime=None
            try: validator(g)
            except ValidationError as e: accepted=False; reason=str(e)
            if accepted: runtime=execute(g)
            rows.append({'row_id':f'm{idx:02d}-{policy}','schedule_index':idx,'rep':rep,'scenario':scenario,'class':'safe' if scenario in SAFE else 'unsafe','policy':policy,'accepted':accepted,'reject_reason':reason,'runtime':runtime})
    data={'schema':'agent-interface/sensorimotor-graph-evidence-role-formal-v1','task':plan['task'],'plan_sha256':sha(a.plan),'rows':rows}
    out.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'rows':len(rows),'typed_rejects':sum(1 for r in rows if r['policy']=='typed_roles' and not r['accepted']),'baseline_emissions':sum((r['runtime'] or {}).get('backend_emissions',0) for r in rows if r['policy']=='structural_only')},sort_keys=True))
if __name__=='__main__': main()

from __future__ import annotations
import argparse,json
from pathlib import Path
SAFE={"safe_current_admission","safe_hint_revalidated","safe_invalidator_to_planner","safe_effect_to_terminal","safe_hint_to_planner"}
UNSAFE={"unsafe_hint_direct","unsafe_planner_direct","unsafe_invalidator_direct","unsafe_effect_direct","unsafe_historical_admission"}
REASONS={
"unsafe_hint_direct":"ACTUATOR_REQUIRES_ADMISSION_DEPENDENCY",
"unsafe_planner_direct":"ACTUATOR_REQUIRES_ADMISSION_DEPENDENCY",
"unsafe_invalidator_direct":"ACTUATOR_REQUIRES_ADMISSION_DEPENDENCY",
"unsafe_effect_direct":"ACTUATOR_REQUIRES_ADMISSION_DEPENDENCY",
"unsafe_historical_admission":"ACTUATOR_REQUIRES_CURRENT",
}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--result',required=True); ap.add_argument('--out',required=True); a=ap.parse_args()
    d=json.loads(Path(a.result).read_text()); rows=d['rows']; errs=[]
    if len(rows)!=80: errs.append(f'rows:{len(rows)}')
    ids=[r['row_id'] for r in rows]
    if len(ids)!=len(set(ids)): errs.append('duplicate_ids')
    typed_safe=typed_unsafe=base_unsafe=0; safe_match=0
    by={(r['schedule_index'],r['policy']):r for r in rows}
    for r in rows:
        s=r['scenario']; p=r['policy']; rt=r['runtime']
        if s in SAFE:
            if not r['accepted']: errs.append(f"{r['row_id']}:safe_reject:{r['reject_reason']}")
            else:
                expected_emission=1 if s in {'safe_current_admission','safe_hint_revalidated'} else 0
                if rt['backend_emissions']!=expected_emission: errs.append(f"{r['row_id']}:safe_emission")
                if p=='typed_roles': typed_safe+=1
        else:
            if p=='structural_only':
                if not r['accepted'] or rt is None or rt['backend_emissions']!=1: errs.append(f"{r['row_id']}:baseline_boundary_not_exposed")
                else: base_unsafe+=1
            else:
                if r['accepted'] or rt is not None: errs.append(f"{r['row_id']}:unsafe_typed_admitted")
                elif r['reject_reason']!=REASONS[s]: errs.append(f"{r['row_id']}:reason:{r['reject_reason']}:{REASONS[s]}")
                else: typed_unsafe+=1
    for i in range(40):
        arow=by[(i,'structural_only')]; brow=by[(i,'typed_roles')]
        if arow['scenario'] in SAFE and arow['runtime']==brow['runtime']: safe_match+=1
    if typed_safe!=20: errs.append(f'typed_safe:{typed_safe}')
    if typed_unsafe!=20: errs.append(f'typed_unsafe:{typed_unsafe}')
    if base_unsafe!=20: errs.append(f'base_unsafe:{base_unsafe}')
    if safe_match!=20: errs.append(f'safe_match:{safe_match}')
    decision='PASS_TYPED_EVIDENCE_ROLE_GATE_SCOPED' if not errs else 'FAIL_ROLE_GATE'
    out={'schema':'agent-interface/sensorimotor-graph-evidence-role-audit-v1','decision':decision,'errors':errs,'counts':{'typed_safe_accept':typed_safe,'typed_unsafe_reject_preinput':typed_unsafe,'structural_unsafe_backend_emissions':base_unsafe,'safe_runtime_matches':safe_match}}
    Path(a.out).write_text(json.dumps(out,indent=2,sort_keys=True)+'\n'); print(json.dumps(out,sort_keys=True)); raise SystemExit(0 if not errs else 1)
if __name__=='__main__': main()

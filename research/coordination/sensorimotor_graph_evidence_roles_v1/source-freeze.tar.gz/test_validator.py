import unittest
from validator import *
SAFE=['safe_current_admission','safe_hint_revalidated','safe_invalidator_to_planner','safe_effect_to_terminal','safe_hint_to_planner']
UNSAFE=['unsafe_hint_direct','unsafe_planner_direct','unsafe_invalidator_direct','unsafe_effect_direct','unsafe_historical_admission']
class T(unittest.TestCase):
    def test_structural_accepts_all_authored(self):
        for s in SAFE+UNSAFE: self.assertTrue(validate_structural(graph_for(s))['ok'])
    def test_typed_accepts_safe(self):
        for s in SAFE: self.assertTrue(validate_typed(graph_for(s))['ok'])
    def test_typed_rejects_unsafe(self):
        for s in UNSAFE:
            with self.assertRaises(ValidationError): validate_typed(graph_for(s))
    def test_hint_requires_revalidation_for_actuation(self):
        with self.assertRaisesRegex(ValidationError,'ADMISSION_DEPENDENCY'): validate_typed(graph_for('unsafe_hint_direct'))
    def test_historical_admission_rejected(self):
        with self.assertRaisesRegex(ValidationError,'CURRENT'): validate_typed(graph_for('unsafe_historical_admission'))
    def test_safe_actuation_counts(self):
        for s in ['safe_current_admission','safe_hint_revalidated']: self.assertEqual(execute(graph_for(s))['backend_emissions'],1)
    def test_nonactuating_safe_counts(self):
        for s in ['safe_invalidator_to_planner','safe_effect_to_terminal','safe_hint_to_planner']: self.assertEqual(execute(graph_for(s))['backend_emissions'],0)
if __name__=='__main__': unittest.main()

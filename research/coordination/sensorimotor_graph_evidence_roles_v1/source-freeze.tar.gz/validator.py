from __future__ import annotations
from dataclasses import dataclass
from typing import Any

ALLOWED_OPS={"SOURCE","REVALIDATE_CURRENT","DISCARD_OLD_AUTHORITY","TO_PLANNER_CONTEXT","ACTUATOR","TERMINAL_SUCCESS","YIELD"}

@dataclass(frozen=True)
class Fact:
    role:str
    freshness:str

class ValidationError(ValueError):
    pass

def validate_structural(graph:dict[str,Any])->dict[str,Any]:
    steps=graph["steps"]
    if not isinstance(steps,list) or not steps or len(steps)>16: raise ValidationError("STRUCTURE_BOUNDS")
    ids=set(); seen=set(); terminals=0
    for s in steps:
        sid=s.get("id"); op=s.get("op")
        if not sid or sid in ids: raise ValidationError("STRUCTURE_ID")
        ids.add(sid)
        if op not in ALLOWED_OPS: raise ValidationError("STRUCTURE_OP")
        for ref in s.get("inputs",[]):
            if ref not in seen: raise ValidationError("STRUCTURE_ORDER")
        if op in {"TERMINAL_SUCCESS","YIELD"}: terminals += 1
        if op=="ACTUATOR" and s.get("resource") not in graph.get("allowed_resources",[]): raise ValidationError("RESOURCE_SUBSET")
        seen.add(sid)
    if terminals!=1: raise ValidationError("STRUCTURE_TERMINAL")
    if graph.get("finally_neutralize") is not True: raise ValidationError("MISSING_FINALLY")
    return {"ok":True,"policy":"structural_only"}

def validate_typed(graph:dict[str,Any])->dict[str,Any]:
    validate_structural(graph)
    facts:dict[str,Fact]={}
    by_id={}
    for s in graph["steps"]:
        sid=s["id"]; op=s["op"]; by_id[sid]=s
        ins=[facts[x] for x in s.get("inputs",[])]
        if op=="SOURCE":
            role=s.get("role"); fresh=s.get("freshness")
            if role not in {"HINT","INVALIDATOR","PLANNER_CONTEXT","ADMISSION_DEPENDENCY","EFFECT_EVIDENCE"}: raise ValidationError("ROLE_UNKNOWN")
            if fresh not in {"CURRENT","HISTORICAL"}: raise ValidationError("FRESHNESS_UNKNOWN")
            facts[sid]=Fact(role,fresh)
        elif op=="REVALIDATE_CURRENT":
            if len(ins)!=2: raise ValidationError("REVALIDATE_ARITY")
            roles={f.role for f in ins}
            if "HINT" not in roles or "ADMISSION_DEPENDENCY" not in roles: raise ValidationError("REVALIDATE_ROLE")
            cur=[f for f in ins if f.role=="ADMISSION_DEPENDENCY"]
            if len(cur)!=1 or cur[0].freshness!="CURRENT": raise ValidationError("REVALIDATE_CURRENT_REQUIRED")
            facts[sid]=Fact("ADMISSION_DEPENDENCY","CURRENT")
        elif op=="DISCARD_OLD_AUTHORITY":
            if len(ins)!=1 or ins[0].role!="INVALIDATOR" or ins[0].freshness!="CURRENT": raise ValidationError("INVALIDATOR_CURRENT_REQUIRED")
            facts[sid]=Fact("PLANNER_CONTEXT","CURRENT")
        elif op=="TO_PLANNER_CONTEXT":
            if len(ins)!=1 or ins[0].role not in {"HINT","INVALIDATOR","PLANNER_CONTEXT"}: raise ValidationError("PLANNER_CONTEXT_PROMOTION")
            facts[sid]=Fact("PLANNER_CONTEXT",ins[0].freshness)
        elif op=="ACTUATOR":
            if len(ins)!=1 or ins[0].role!="ADMISSION_DEPENDENCY": raise ValidationError("ACTUATOR_REQUIRES_ADMISSION_DEPENDENCY")
            if ins[0].freshness!="CURRENT": raise ValidationError("ACTUATOR_REQUIRES_CURRENT")
            facts[sid]=Fact("EFFECT_EVIDENCE","CURRENT")
        elif op=="TERMINAL_SUCCESS":
            if len(ins)!=1 or ins[0].role!="EFFECT_EVIDENCE" or ins[0].freshness!="CURRENT": raise ValidationError("TERMINAL_REQUIRES_CURRENT_EFFECT")
            facts[sid]=ins[0]
        elif op=="YIELD":
            if len(ins)!=1 or ins[0].role!="PLANNER_CONTEXT": raise ValidationError("YIELD_REQUIRES_PLANNER_CONTEXT")
            facts[sid]=ins[0]
    return {"ok":True,"policy":"typed_roles","facts":{k:{"role":v.role,"freshness":v.freshness} for k,v in facts.items()}}

def execute(graph:dict[str,Any])->dict[str,Any]:
    backend=0; terminal=None
    values={}
    for s in graph["steps"]:
        op=s["op"]; sid=s["id"]
        if op=="SOURCE": values[sid]=True
        elif op=="REVALIDATE_CURRENT": values[sid]=all(values[x] for x in s["inputs"])
        elif op in {"DISCARD_OLD_AUTHORITY","TO_PLANNER_CONTEXT"}: values[sid]=values[s["inputs"][0]]
        elif op=="ACTUATOR": backend+=1; values[sid]=True
        elif op=="TERMINAL_SUCCESS": terminal="SUCCESS"; values[sid]=True
        elif op=="YIELD": terminal="YIELD"; values[sid]=True
    return {"backend_emissions":backend,"terminal":terminal}

def graph_for(name:str)->dict[str,Any]:
    G={"graph_id":name,"allowed_resources":["scroll"],"finally_neutralize":True}
    S=[]
    def src(i,role,fresh): S.append({"id":i,"op":"SOURCE","role":role,"freshness":fresh})
    if name=="safe_current_admission":
        src("a","ADMISSION_DEPENDENCY","CURRENT"); S += [{"id":"x","op":"ACTUATOR","inputs":["a"],"resource":"scroll"},{"id":"t","op":"TERMINAL_SUCCESS","inputs":["x"]}]
    elif name=="safe_hint_revalidated":
        src("h","HINT","HISTORICAL"); src("c","ADMISSION_DEPENDENCY","CURRENT"); S += [{"id":"r","op":"REVALIDATE_CURRENT","inputs":["h","c"]},{"id":"x","op":"ACTUATOR","inputs":["r"],"resource":"scroll"},{"id":"t","op":"TERMINAL_SUCCESS","inputs":["x"]}]
    elif name=="safe_invalidator_to_planner":
        src("i","INVALIDATOR","CURRENT"); S += [{"id":"d","op":"DISCARD_OLD_AUTHORITY","inputs":["i"]},{"id":"y","op":"YIELD","inputs":["d"]}]
    elif name=="safe_effect_to_terminal":
        src("e","EFFECT_EVIDENCE","CURRENT"); S += [{"id":"t","op":"TERMINAL_SUCCESS","inputs":["e"]}]
    elif name=="safe_hint_to_planner":
        src("h","HINT","HISTORICAL"); S += [{"id":"p","op":"TO_PLANNER_CONTEXT","inputs":["h"]},{"id":"y","op":"YIELD","inputs":["p"]}]
    elif name=="unsafe_hint_direct":
        src("h","HINT","HISTORICAL"); S += [{"id":"x","op":"ACTUATOR","inputs":["h"],"resource":"scroll"},{"id":"t","op":"TERMINAL_SUCCESS","inputs":["x"]}]
    elif name=="unsafe_planner_direct":
        src("p","PLANNER_CONTEXT","CURRENT"); S += [{"id":"x","op":"ACTUATOR","inputs":["p"],"resource":"scroll"},{"id":"t","op":"TERMINAL_SUCCESS","inputs":["x"]}]
    elif name=="unsafe_invalidator_direct":
        src("i","INVALIDATOR","CURRENT"); S += [{"id":"x","op":"ACTUATOR","inputs":["i"],"resource":"scroll"},{"id":"t","op":"TERMINAL_SUCCESS","inputs":["x"]}]
    elif name=="unsafe_effect_direct":
        src("e","EFFECT_EVIDENCE","CURRENT"); S += [{"id":"x","op":"ACTUATOR","inputs":["e"],"resource":"scroll"},{"id":"t","op":"TERMINAL_SUCCESS","inputs":["x"]}]
    elif name=="unsafe_historical_admission":
        src("a","ADMISSION_DEPENDENCY","HISTORICAL"); S += [{"id":"x","op":"ACTUATOR","inputs":["a"],"resource":"scroll"},{"id":"t","op":"TERMINAL_SUCCESS","inputs":["x"]}]
    else: raise KeyError(name)
    G["steps"]=S; return G

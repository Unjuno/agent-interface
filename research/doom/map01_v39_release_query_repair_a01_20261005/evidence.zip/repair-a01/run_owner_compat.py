import importlib.util, sys, unittest
from pathlib import Path
ROOT=Path("/src")
DOOM=ROOT/"research/doom"
FIX=DOOM/"map01_v39_cancel_release_fix_a01_20261005"
REPAIR=ROOT/"repair-a01"
BRIDGE_TEST=DOOM/"map01_v39_perkey_bridge_a01"/"test_bridge.py"
V12=DOOM/"map01_attack_onset_phase_allocation_02_v1"/"dependencies/v12"
V10=ROOT/"research/live_control/input_owner_v10.py"
spec=importlib.util.spec_from_file_location("bridge_test_owner_compat",BRIDGE_TEST)
bt=importlib.util.module_from_spec(spec); sys.modules[spec.name]=bt; spec.loader.exec_module(bt)
tm=bt.load_v12_test_harness()
v10=tm.load("input_owner_v10_for_repair_compat",V10)
repair=tm.load("input_owner_v13_repair_for_compat",REPAIR/"input_owner_v13_repair_candidate.py")
def set_up(cls): cls.v10=v10; cls.v12=repair
tm.Tests.setUpClass=classmethod(set_up)
suite=unittest.defaultTestLoader.loadTestsFromTestCase(tm.Tests)
result=unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(0 if result.wasSuccessful() else 1)

import sys
from pathlib import Path
FIX_PATH = Path("/src/research/doom/map01_v39_cancel_release_fix_a01_20261005")
REPAIR_PATH = Path("/src/repair-a01")
sys.path.insert(0, str(FIX_PATH))
from test_cancel_release import load_candidate, run_program
import test_cancel_release

test_cancel_release.OWNER_V13_PATH = REPAIR_PATH / "input_owner_v13_repair_candidate.py"
_bt, _hm, harness, lease, _bm, backend = load_candidate({"query_fail_on": {5}})
def fail_after_release(self, identifier, step):
    self._input_event_context = (identifier, step)
    self.raw("F8", True)
    self.owner.call("release", self.lease)
try:
    caught = None
    try:
        run_program(_bt, backend, lease, fail_after_release,
                    identifier="aggregate-query-repair-a01", step=4)
    except Exception as exc:
        caught = repr(exc)
    owner_state = harness.owner.call("input_state", lease)
    up_rows = [row for row in backend.events if row.get("event") == "input_release_measurement"]
    state = {"exception": caught, "events": backend.events,
             "owner_records": harness.owner.records, "owner_state": owner_state,
             "physical": sorted(harness.d.physical), "bridge_held": sorted(backend.held),
             "query_i": harness.d.query_i, "injections": harness.d.injections}
    print({"outcome": "REPAIR_INVARIANTS", **state})
    assert caught and "sample failure" in caught, state
    assert len(up_rows) == 1, state
    assert up_rows[0]["physical_key_measurement"]["classification"] == "CONFIRMED_PHYSICAL_UP", state
    assert harness.d.physical == set(), state
    assert backend.held == set(), state
    assert owner_state["owned_keycodes"] == [], state
    assert owner_state["active_lease_deadline_ns"] is None, state
finally:
    harness.close()

import sys, unittest
from pathlib import Path
FIX = Path("/src/research/doom/map01_v39_cancel_release_fix_a01_20261005")
REPAIR = Path("/src/repair-a01")
sys.path.insert(0, str(FIX))
import test_cancel_release as suite
test_cancel_release = suite
test_cancel_release.OWNER_V13_PATH = REPAIR / "input_owner_v13_repair_candidate.py"
unittest.main(module=suite, verbosity=2)

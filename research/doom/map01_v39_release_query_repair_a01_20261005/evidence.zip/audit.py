import ast, hashlib, json
from pathlib import Path
root=Path(__file__).resolve().parent
lock=json.loads((root/'SOURCE_LOCK.json').read_text())
def git_blob(path):
    b=path.read_bytes()
    return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def raw(path, marker):
    for line in path.read_text(encoding='utf-8-sig').splitlines():
        if line.startswith(marker): return ast.literal_eval(line)
    raise AssertionError(f'missing raw record in {path.name}')
base_owner=root/'research/doom/map01_v39_cancel_release_fix_a01_20261005/input_owner_v13_candidate.py'
base_bridge=root/'research/doom/map01_v39_cancel_release_fix_a01_20261005/bridge_v2_candidate.py'
previous_bridge=root/'research/doom/map01_v39_perkey_bridge_a01/bridge.py'
v12_harness=root/'research/doom/map01_attack_onset_phase_allocation_02_v1/dependencies/v12/test_input_owner_v12.py'
assert git_blob(base_owner)==lock['candidate_owner_blob']
assert git_blob(base_bridge)==lock['candidate_bridge_blob']
assert git_blob(previous_bridge)==lock['previous_bridge_blob']
assert git_blob(v12_harness)==lock['v12_harness_blob']
base=raw(root/'raw/raw-repair-red.log', "{'outcome': 'ASSERTION'")
fixed=raw(root/'raw/raw-repair-green.log', "{'outcome': 'REPAIR_INVARIANTS'")
assert base['bridge_held']==['F8'] and base['owner_records']==[] and base['physical']==[]
assert fixed['exception']=="RuntimeError('sample failure')"
rows=[r for r in fixed['events'] if r.get('event')=='input_release_measurement']
assert len(rows)==1 and rows[0]['physical_key_measurement']['classification']=='CONFIRMED_PHYSICAL_UP'
partial=[r for r in fixed['owner_records'] if r.get('event')=='owner_release']
assert len(partial)==1 and partial[0]['verified'] is False and partial[0]['keys_down'] is None and partial[0]['buttons_down'] is None
assert fixed['physical']==[] and fixed['bridge_held']==[]
assert fixed['owner_state']['owned_keycodes']==[] and fixed['owner_state']['active_lease_deadline_ns'] is None
assert fixed['query_i']==5
for name in ('raw-focused-suite.log','raw-owner-compat.log'):
    assert 'Ran 8 tests' in (root/'raw'/name).read_text(encoding='utf-8-sig') or name=='raw-owner-compat.log'
assert 'Ran 10 tests' in (root/'raw/raw-owner-compat.log').read_text(encoding='utf-8-sig')
print(json.dumps({'audit':'PASS_REPAIR_RAW_AND_SOURCE','baseline_stale_ledgers':True,'confirmed_up_rows':1,'owner_and_bridge_neutral':True,'focused_tests':8,'compatibility_tests':10},sort_keys=True))

import difflib
from pathlib import Path
root=Path(__file__).resolve().parent
old=(root/'research/doom/map01_v39_cancel_release_fix_a01_20261005/input_owner_v13_candidate.py').read_text().splitlines(True)
new=(root/'repair/input_owner_v13_repair_candidate.py').read_text().splitlines(True)
patch=''.join(difflib.unified_diff(old,new,fromfile='a/research/doom/map01_v39_cancel_release_fix_a01_20261005/input_owner_v13_candidate.py',tofile='b/research/doom/map01_v39_cancel_release_fix_a01_20261005/input_owner_v13_candidate.py'))
(root/'repair.patch').write_text(patch,encoding='utf-8',newline='\n')

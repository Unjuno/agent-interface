import sys,unittest
from pathlib import Path
ROOT=Path('/src');FIX=ROOT/'research/doom/map01_v39_cancel_release_fix_a01_20261005';REPAIR=ROOT/'repair/input_owner_v13_repair_candidate.py'
sys.path.insert(0,str(FIX));import test_cancel_release as suite;suite.OWNER_V13_PATH=REPAIR;unittest.main(module=suite,verbosity=2)

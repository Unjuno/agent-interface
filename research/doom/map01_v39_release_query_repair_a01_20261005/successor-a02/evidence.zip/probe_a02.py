import sys
from pathlib import Path
ROOT = Path('/src')
FIX = ROOT / 'research/doom/map01_v39_cancel_release_fix_a01_20261005'
sys.path.insert(0, str(FIX))
from test_cancel_release import load_candidate, run_program

def release_then_raise(self, identifier, step):
    self._input_event_context = (identifier, step)
    self.raw('F8', True)
    self.owner.call('release', self.lease)

_bt, _hm, harness, lease, _bm, backend = load_candidate({'query_fail_on': {5}})
try:
    caught = None
    try:
        run_program(_bt, backend, lease, release_then_raise,
                    identifier='owner-ledger-after-query-failure-a02', step=6)
    except Exception as exc:
        caught = repr(exc)
    state = harness.owner.call('input_state', lease)
    ups = [row for row in backend.events if row.get('event') == 'input_release_measurement']
    report = {'exception': caught, 'owner_state': state,
              'bridge_held': sorted(backend.held), 'physical': sorted(harness.d.physical),
              'release_rows': ups, 'owner_records': harness.owner.records,
              'query_i': harness.d.query_i, 'injections': harness.d.injections}
    print({'outcome': 'REPAIR_GAP_PROBE', **report})
    assert caught and 'sample failure' in caught, report
    assert len(ups) == 1 and ups[0]['physical_key_measurement']['classification'] == 'CONFIRMED_PHYSICAL_UP', report
    assert backend.held == set() and harness.d.physical == set(), report
    assert state['owned_keycodes'] == [], report
    assert state['active_lease_deadline_ns'] is None, report
    try:
        harness.owner.call('down', lease, 'F8')
    except RuntimeError as exc:
        assert 'failed closed' in str(exc), report
    else:
        raise AssertionError('owner accepted new input after aggregate-verification failure')
finally:
    harness.close()

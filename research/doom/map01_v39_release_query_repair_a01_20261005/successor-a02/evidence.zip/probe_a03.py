import sys
from pathlib import Path
ROOT=Path('/src')
FIX=ROOT/'research/doom/map01_v39_cancel_release_fix_a01_20261005'
sys.path.insert(0,str(FIX))
import test_cancel_release as suite
candidate=Path(sys.argv[1]) if len(sys.argv)>1 else FIX/'input_owner_v13_candidate.py'
suite.OWNER_V13_PATH=candidate
from test_cancel_release import load_candidate,run_program

def down_then_fail_release(self,identifier,step):
    self._input_event_context=(identifier,step)
    self.raw('a',True)
    self.owner.call('release',self.lease)

_bt,hm,harness,lease,_bm,backend=load_candidate({'query_fail_on':{5}})
hm.owner_module.XK.string_to_keysym=lambda key: ord(key)
harness.d.keysym_to_keycode=lambda sym:sym
try:
    caught=None
    try:
        run_program(_bt,backend,lease,down_then_fail_release,
                    identifier='post-query-failure-control-a03',step=9)
    except Exception as exc:
        caught=repr(exc)
    post_down=None; post_error=None
    try:
        post_down=harness.owner.call('down',lease,'b',event_context=('after-query-failure',10))
    except Exception as exc:
        post_error=repr(exc)
    state=harness.owner.call('input_state',lease)
    report={'exception':caught,'post_failure_down':post_down,'post_failure_error':post_error,
            'owner_state':state,'physical':sorted(harness.d.physical),
            'bridge_held':sorted(backend.held),'records':harness.owner.records,
            'events':backend.events,'query_i':harness.d.query_i,
            'injections':harness.d.injections}
    print({'outcome':'FAIL_CLOSED_POST_FAILURE_TEST','report':report})
    assert caught and 'sample failure' in caught,report
    assert post_error and 'failed closed' in post_error,report
    assert post_down is None,report
    assert state['owned_keycodes']==[] and state['active_lease_deadline_ns'] is None,report
    assert harness.d.physical==set() and backend.held==set(),report
finally:
    harness.close()

import ast,hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
lock=json.loads((root/'SOURCE_LOCK.json').read_text())
def gitblob(p):
 b=p.read_bytes();return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def raw(file,marker):
 for line in (root/'raw'/file).read_text(encoding='utf-8-sig').splitlines():
  if line.startswith(marker):return ast.literal_eval(line)
 raise AssertionError(file)
files={
'candidate_owner_blob':'research/doom/map01_v39_cancel_release_fix_a01_20261005/input_owner_v13_candidate.py',
'candidate_test_blob':'research/doom/map01_v39_cancel_release_fix_a01_20261005/test_cancel_release.py',
'candidate_bridge_blob':'research/doom/map01_v39_cancel_release_fix_a01_20261005/bridge_v2_candidate.py',
'previous_bridge_blob':'research/doom/map01_v39_perkey_bridge_a01/bridge.py',
'previous_bridge_test_blob':'research/doom/map01_v39_perkey_bridge_a01/test_bridge.py',
'v12_owner_blob':'research/doom/map01_attack_onset_phase_allocation_02_v1/dependencies/v12/input_owner_v12.py',
'v12_harness_blob':'research/doom/map01_attack_onset_phase_allocation_02_v1/dependencies/v12/test_input_owner_v12.py',
'executor_blob':'research/live_control/executor_v3.py','v10_owner_blob':'research/live_control/input_owner_v10.py','lease_blob':'research/live_control/lease.py'}
for key,rel in files.items():assert gitblob(root/rel)==lock[key],key
r=raw('stale-ledger-red-a02.log',"{'outcome': 'REPAIR_GAP_PROBE'")
assert r['owner_state']['owned_keycodes']==[74] and r['owner_state']['active_lease_deadline_ns'] is not None
assert r['bridge_held']==[] and r['physical']==[] and len(r['release_rows'])==1
assert r['release_rows'][0]['physical_key_measurement']['classification']=='CONFIRMED_PHYSICAL_UP'
r3=raw('post-fault-admission-red-a03.log',"{'outcome': 'FAIL_CLOSED_POST_FAILURE_TEST'")['report']
assert r3['post_failure_down']['event']=='input_admission' and r3['physical']==[98]
assert r3['owner_state']['owned_keycodes']==[97,98] and r3['owner_state']['active_lease_deadline_ns'] is not None
g=raw('post-fault-closed-green-a03.log',"{'outcome': 'FAIL_CLOSED_POST_FAILURE_TEST'")['report']
assert g['post_failure_down'] is None and 'failed closed' in g['post_failure_error']
assert g['owner_state']['owned_keycodes']==[] and g['owner_state']['active_lease_deadline_ns'] is None
assert g['physical']==[] and g['bridge_held']==[]
assert 'Ran 11 tests' in (root/'raw/focused-suite.log').read_text(encoding='utf-8-sig')
assert 'Ran 10 tests' in (root/'raw/owner-compat.log').read_text(encoding='utf-8-sig')
print(json.dumps({'audit':'PASS_OWNER_LEDGER_FAIL_CLOSED','baseline_post_error_admission':True,'repair_post_error_admission_rejected':True,'focused':11,'compatibility':10},sort_keys=True))

"""Inert JSONL peer: no Codex, model, application, network, or input calls."""
import json
import sys

mode = sys.argv[1]


def emit(row):
    print(json.dumps(row), flush=True)


for line in sys.stdin:
    row = json.loads(line)
    method = row["method"]
    if "id" not in row:
        continue
    identifier = row["id"]
    if method == "initialize":
        result = {"synthetic": True}
    elif method == "thread/start":
        result = {"thread": {"id": "inert-thread"}}
    elif method == "turn/start":
        result = {"turn": {"id": "inert-turn"}}
    elif method == "turn/interrupt":
        if mode == "eof":
            break
        if mode == "rpc_error":
            emit({"id": identifier, "error": {"code": -32001,
                  "message": "inert peer rejects interrupt; turn remains unfinished"}})
            continue
        result = {}
    else:
        raise RuntimeError("unexpected request: " + method)
    emit({"id": identifier, "result": result})
    if method == "turn/interrupt" and mode == "ack_complete":
        emit({"method": "turn/completed", "params": {
            "threadId": "inert-thread", "turn": {"id": "inert-turn",
            "status": "completed", "items": [{"type": "agentMessage",
            "text": '{"state":"active"}'}]}}})

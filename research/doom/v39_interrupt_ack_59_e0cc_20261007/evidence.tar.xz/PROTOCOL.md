# Ordinary fatal-cover interruption repair matrix

This is a fresh ordinary engineering regression/composition run, not a replay
of a consumed formal allocation. Prior Turn28 evidence is unchanged. No model,
Codex service, GUI, game, native input, VM, or container is invoked. One inert
Python peer at a time uses the real default Popen app-server transport. The
application session, observations and cleanup-entry spy remain synthetic.

H: a successful interrupt RPC acknowledgement alone leaves the old fatal-cover
path's future pending. On fatal session exit, the existing transport abort
should unblock the pending future without the construction watchdog rescue.
Completion observed during interruption needs no abort. The original cover
failure remains primary and no later action/cover can be admitted.

T: six new host cells, baseline/candidate for ack_silent, ack_complete and
rpc_error. Baseline production files are exact #8280 head029064c; candidate
changes only the fatal-cover abort condition and adapter docstring. A new test
module is overlaid for unit tests but is not imported by the transport probe.
Run one cell at a time; same inert peer and probe bytes. Source, harness and
command identities are captured before starting. All raw stays in fresh paths.

D: baseline ack_silent should require the existing one-second external-close
watchdog; candidate ack_silent must call abort and reach the error/cleanup path
without that rescue. Both RPC-error arms should abort; completion control may
race actual completion versus close but must not admit an answer. Every cell
must preserve the fatal-cover RuntimeError, send exactly one synthetic session
submit, have no final action admission, and retire its owned child, reader,
future, journal and process group. Outer wrapper limit30s; unexpected wrapper
failure stops this matrix and retains its output. Ordinary engineering repair
may continue separately, with the first result preserved.

C: a fixture that completes await on interrupt would hide the defect. The
actual inert peer must acknowledge the RPC while withholding turn/completed
in ack_silent mode. A successful close alone is not physical input release.
Both arms use the same earlier client; #8290's distinct EOF/reap fix is not
overlaid. EOF-with-exited-leader is outside this matrix and retains its known
separate defect. No real provider/network timing is sampled.

U: this identifies a causal software path and observed owned-process cleanup;
it establishes no OS shutdown worst-case bound, model cancellation guarantee,
physical release, live threat response, useful feedback, or gameplay benefit.
Transport/OS close failure can still delay thread joining until the planner's
existing deadline. Successful abort does not repair an unknown input state.

Timing uses host perf_counter_ns for event order and descriptive intervals;
nanoseconds are SI duration units, not a cross-machine clock. Future state,
return codes and Boolean retirement fields are discrete observations. Initial
unit failures are retained; regression gates rely on event order and the
absence of waiter-timeout/rescue, not a newly tuned performance threshold.

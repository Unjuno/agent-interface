import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import signal
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
RUNS = ROOT/'runs'
RUNS.mkdir(exist_ok=False)
sources = {}
for arm in ('baseline', 'candidate'):
    sources[arm] = {str(p.relative_to(ROOT/arm/'source')): hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in sorted((ROOT/arm/'source').rglob('*')) if p.is_file()}
freeze = {'kind': 'ordinary regression source snapshot, not formal allocation',
          'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'python': sys.version, 'platform': platform.platform(), 'machine': platform.machine(),
          'load_average': os.getloadavg(), 'free_bytes': shutil.disk_usage(ROOT).free,
          'source_hashes': sources,
          'harness_hashes': {n: hashlib.sha256((ROOT/n).read_bytes()).hexdigest()
                             for n in ('controller_probe.py','inert_peer.py','PROTOCOL.md','run_matrix.py')}}
(ROOT/'MATRIX_SOURCE_SNAPSHOT.json').write_text(json.dumps(freeze,indent=2)+'\n')
for mode in ('ack_silent','ack_complete','rpc_error'):
    for arm in ('baseline','candidate'):
        name = arm+'-'+mode
        command = [sys.executable,'-B',str(ROOT/'controller_probe.py'),
                   '--source',str(ROOT/arm/'source'),'--out',str(RUNS/name),'--mode',mode]
        start = datetime.datetime.now(datetime.timezone.utc).isoformat()
        process = subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        timeout = False
        try:
            stdout,stderr = process.communicate(timeout=30)
        except subprocess.TimeoutExpired:
            timeout = True
            # Own wrapper only. The inert peer starts its own group; inspect its
            # saved identity and exact argv before any exceptional cleanup.
            identity = RUNS/name/'peer_identity.json'
            if identity.exists():
                pid = json.loads(identity.read_text())['pid']
                observed = subprocess.run(['ps','-p',str(pid),'-o','command='],capture_output=True,text=True)
                if str(ROOT/'inert_peer.py') in observed.stdout and mode in observed.stdout:
                    try: os.killpg(pid,signal.SIGTERM)
                    except ProcessLookupError: pass
            os.killpg(process.pid,signal.SIGTERM)
            try: stdout,stderr = process.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL)
                stdout,stderr = process.communicate(timeout=5)
        (RUNS/(name+'.stdout.txt')).write_bytes(stdout)
        (RUNS/(name+'.stderr.txt')).write_bytes(stderr)
        receipt = {'command': command, 'start_utc': start,
                   'end_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   'returncode': process.returncode, 'outer_timeout': timeout,
                   'stdout_sha256': hashlib.sha256(stdout).hexdigest(),
                   'stderr_sha256': hashlib.sha256(stderr).hexdigest()}
        (RUNS/(name+'.execution.json')).write_text(json.dumps(receipt,indent=2)+'\n')
        print(name,process.returncode,stdout.decode().strip(),flush=True)
        if timeout or process.returncode:
            raise SystemExit(1)

#!/usr/bin/env python3
"""Independent read-only audit for six real-Popen ordinary-terminal traces.

Consumes saved JSON/JSONL only; never imports candidate/controller/auditor code.
"""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent / "audit-result-v1.json"
BASELINE_SHA = "029064c797768183f63c79bbedbe3aca18f85dbb"
MODES = ("ack_silent", "ack_complete", "rpc_error")
BASE_MAP_SHA = "ebd753bb5d351a67668aea1b6227527ce6aeb126bb7d3f9d81c9fbb27da3313a"
HARNESS_PINS = {
    "controller_probe.py": "07f7bf9ffeed310397052b4693dc5170f39e3f64fba75b9d51f16f030f7462c8",
    "inert_peer.py": "35eb23407f4ccfd8de9a0ac760cf359e38914ad4e1466fcb3c7a3df233beeb8d",
    "BASELINE_SOURCE.json": BASE_MAP_SHA,
}
SOURCE_PINS = {
    "baseline": {
        "research/doom/map01_overlap_controller_v39.py": "39166131f628f4116ab9e65f26a66263984acbd404b73c4dafa9177d5441106c",
        "research/doom/test_map01_overlap_controller_v39_cover_terminal.py": "bbe4f9c1c134e8f5b61bf3c05be0be4d89d74ff5a623fc50443e69369e2632ec",
        "research/live_control/persistent_planner_adapter_v2.py": "017428f4a585dc6da4e6c77cba8be46d583004ea6f1b0df40b1f183e5ee9a204",
    },
    "candidate": {
        "research/doom/map01_overlap_controller_v39.py": "96ac88f4faffbf5d2ae77b3b7178ea6238e0bd0e9bc3c62a89da065b70617703",
        "research/doom/test_map01_overlap_controller_v39_cover_terminal.py": "2a9690553f77badb7a3852ded061701799ea048427246f0bf2189d328f340f8c",
        "research/live_control/persistent_planner_adapter_v2.py": "2bb391d4f897952b2c4137f91646b2ebb0c910c1c19a9d1e3feef8aa302647d1",
    },
}
checks = []
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def check(name, ok, detail=None): checks.append({"name": name, "pass": bool(ok), "detail": detail})
def readjson(path): return json.loads(Path(path).read_text())
def timeline_rows(trace, name): return [row for row in trace.get("timeline", []) if row.get("event") == name]
def one(rows): return rows[0] if len(rows) == 1 else None

# Input identities: check the frozen baseline inventory, the exact baseline
# export and the only three expected candidate overlays.
base_map_path = ROOT / "BASELINE_SOURCE.json"
if not base_map_path.is_file():
    print("missing BASELINE_SOURCE.json", file=sys.stderr); sys.exit(2)
base_map_bytes = base_map_path.read_bytes()
base_map = json.loads(base_map_bytes)
check("baseline_source_manifest_hash", hashlib.sha256(base_map_bytes).hexdigest() == BASE_MAP_SHA,
      {"actual": hashlib.sha256(base_map_bytes).hexdigest(), "expected": BASE_MAP_SHA})
source_inventory = {}
for arm in ("baseline", "candidate"):
    source_root = ROOT / arm / "source"
    expected_map = dict(base_map)
    if arm == "baseline":
        expected_map.update({p: h for p, h in SOURCE_PINS[arm].items()})
    else:
        expected_map.update({p: h for p, h in SOURCE_PINS[arm].items()})
    rows=[]; present=set()
    for rel, expected in expected_map.items():
        path=source_root/rel
        got=sha(path) if path.is_file() else None
        rows.append({"path":rel,"expected":expected,"actual":got,"pass":got==expected})
        if path.is_file(): present.add(rel)
    extras=sorted(str(p.relative_to(source_root)) for p in source_root.rglob("*") if p.is_file() and str(p.relative_to(source_root)) not in expected_map)
    source_inventory[arm]={"expected_count":len(expected_map),"pass_count":sum(x["pass"] for x in rows),"missing_or_mismatched":[x for x in rows if not x["pass"]],"extras":extras}
check("exact_68_source_files_each_arm_and_expected_overlays",
      all(v["expected_count"]==68 and v["pass_count"]==68 and not v["extras"] for v in source_inventory.values()),source_inventory)
for name, expected in HARNESS_PINS.items():
    path=ROOT/name
    actual=sha(path) if path.is_file() else None
    check("frozen_harness:"+name, actual==expected,{"actual":actual,"expected":expected})

# Read a freeze when present and enforce its declared hashes, without importing
# or executing any frozen program. A missing freeze is itself a failed gate.
freeze_path=ROOT/"freeze.json"
if freeze_path.is_file():
    freeze=readjson(freeze_path)
    files=freeze.get("files",{})
    freeze_rows=[]
    for rel,want in files.items():
        p=ROOT/rel; got=sha(p) if p.is_file() else None
        freeze_rows.append({"path":rel,"expected":want,"actual":got,"pass":got==want})
    check("freeze_declared_files_match",bool(freeze_rows) and all(r["pass"] for r in freeze_rows),freeze_rows)
else:
    freeze={}
    check("freeze_exists",False,"freeze.json not present at audit time")

cells={}
expected_keys={f"{arm}-{mode}" for arm in ("baseline","candidate") for mode in MODES}
runs_root=ROOT/"runs"
actual_keys={p.name for p in runs_root.iterdir() if p.is_dir()} if runs_root.is_dir() else set()
check("exact_six_cell_directories",actual_keys==expected_keys,{"expected":sorted(expected_keys),"actual":sorted(actual_keys)})

for arm in ("baseline","candidate"):
  for mode in MODES:
    key=f"{arm}-{mode}"; run=runs_root/key
    try:
        trace_bytes=(run/"trace.json").read_bytes(); trace=json.loads(trace_bytes)
        wire_bytes=(run/"wire.jsonl").read_bytes(); wire=[json.loads(line) for line in wire_bytes.decode().splitlines() if line]
        execution=readjson(runs_root/(key+".execution.json"))
    except Exception as exc:
        check(key+":inputs_read",False,repr(exc)); continue
    timeline=trace.get("timeline",[]); names=[r.get("event") for r in timeline]
    commands=trace.get("commands",[]); events=trace.get("events",[])
    terminals=[r for r in events if r.get("event")=="terminal"]
    sends=[r.get("message",{}) for r in wire if r.get("direction")=="sent"]
    recvs=[r.get("message",{}) for r in wire if r.get("direction")=="received"]
    request=one([r for r in sends if r.get("method")=="turn/interrupt"])
    response=one([r for r in recvs if request is not None and r.get("id")==request.get("id")])
    completed=[r for r in recvs if r.get("method")=="turn/completed" and
               r.get("params",{}).get("threadId")=="inert-thread" and
               r.get("params",{}).get("turn",{}).get("id")=="inert-turn"]
    interrupt_result=one(timeline_rows(trace,"interrupt_result"))
    abort_enter=one(timeline_rows(trace,"abort_enter")); abort_result=one(timeline_rows(trace,"abort_result"))
    rescue=one(timeline_rows(trace,"external_rescue_enter"))
    await_error=one(timeline_rows(trace,"await_error")); await_result=one(timeline_rows(trace,"await_result"))
    terminal_read=one(timeline_rows(trace,"terminal_read"))
    cleanup=one(timeline_rows(trace,"cleanup_entry"))
    error=trace.get("error",{})
    receipt_cmd=execution.get("command",[])
    def arg_value(flag):
        try: return receipt_cmd[receipt_cmd.index(flag)+1]
        except (ValueError,IndexError): return None
    receipt_ok=(execution.get("exit_code")==0 and
                Path(receipt_cmd[0]).name in ("python3","python") if receipt_cmd else False)
    # Require expected script/source/output/mode arguments in the captured
    # command receipt; avoid trusting trace metadata alone.
    receipt_ok=(receipt_ok and any(Path(x).name=="controller_probe.py" for x in receipt_cmd) and
                Path(arg_value("--source") or "/missing").resolve()==(ROOT/arm/"source").resolve() and
                Path(arg_value("--out") or "/missing").resolve()==run.resolve() and
                arg_value("--mode")==mode)
    common=(trace.get("mode")==mode and trace.get("no_model_or_native_input") is True and
            receipt_ok and len(commands)==1 and commands[0].get("op")=="submit" and
            commands[0].get("id")=="cover-0" and len(terminals)==1 and
            terminals[0].get("id")=="cover-0" and terminals[0].get("status")=="failed" and
            terminals[0].get("error")=="injected input error" and
            terminals[0].get("release")=={"verified":True,"keys_down":[],"buttons_down":[]} and
            error.get("type")=="RuntimeError" and "cover terminal lacks allowed status" in error.get("message","") and
            "final_admission" not in names and trace.get("all_futures_done") is True and
            trace.get("reader_alive") is False and trace.get("journal_closed") is True and
            trace.get("peer_returncode") is not None and trace.get("process_group_absent") is True and
            trace.get("watchdog_alive") is False and cleanup is not None and cleanup.get("error")=="RuntimeError")
    check(key+":common_fatal_terminal_and_owned_process_retired",common,{
        "mode":trace.get("mode"),"exit_code":execution.get("exit_code"),"command":receipt_cmd,
        "commands":commands,"terminal":terminals,"error":error,"timeline":names,
        "all_futures_done":trace.get("all_futures_done"),"reader_alive":trace.get("reader_alive"),
        "journal_closed":trace.get("journal_closed"),"peer_returncode":trace.get("peer_returncode"),
        "process_group_absent":trace.get("process_group_absent"),"watchdog_alive":trace.get("watchdog_alive")})
    wire_ok=(request is not None and request.get("params")=={"threadId":"inert-thread","turnId":"inert-turn"} and
             response is not None and response.get("id")==request.get("id"))
    if mode in ("ack_silent","ack_complete"):
        wire_ok=wire_ok and response.get("result")=={} and response.get("error") is None
    else:
        wire_ok=wire_ok and response.get("error",{}).get("message")=="inert peer rejects interrupt; turn remains unfinished"
    check(key+":wire_interrupt_request_ack_and_turn_identity",wire_ok,{
        "request":request,"response":response,"completion_count":len(completed),"wire_rows":len(wire)})
    if mode=="ack_silent":
        check(key+":no_completion_notification",len(completed)==0,{"completed":completed})
        if arm=="baseline":
            check(key+":baseline_ack_silent_stays_pending_until_watchdog",
                  interrupt_result is not None and interrupt_result.get("result",{}).get("outcome")=="requested" and
                  rescue is not None and rescue.get("unfinished_futures")==1 and abort_enter is None and
                  await_error is not None and timeline_rows(trace,"external_rescue_return"),
                  {"interrupt_result":interrupt_result,"rescue":rescue,"timeline":timeline})
        else:
            t={r.get("event"):r.get("ns") for r in timeline}
            check(key+":candidate_ack_silent_abort_unblocks_before_rescue",
                  interrupt_result is not None and interrupt_result.get("result",{}).get("outcome")=="requested" and
                  abort_enter is not None and abort_result is not None and rescue is None and await_error is not None and
                  t.get("interrupt_result",10**30)<t.get("abort_enter",-1)<t.get("abort_result",-1) and
                  t.get("abort_enter",10**30)<t.get("await_error",-1),
                  {"interrupt_result":interrupt_result,"abort_enter":abort_enter,"abort_result":abort_result,
                   "await_error":await_error,"timeline":timeline})
    elif mode=="ack_complete":
        result=(await_result or {}).get("result",{})
        check(key+":completion_control_is_cancelled_and_ineligible",
              len(completed)==1 and result.get("status")=="completed" and result.get("cancelled") is True and
              result.get("eligible") is False and abort_enter is None and rescue is None and await_error is None,
              {"completion_count":len(completed),"await_result":await_result,"timeline":timeline})
    elif mode=="rpc_error":
        check(key+":error_reply_fixture",response is not None and response.get("error",{}).get("code")==-32001 and len(completed)==0,
              {"response":response,"completion_count":len(completed)})
        if arm=="baseline":
            check(key+":baseline_error_waits_for_external_close",
                  rescue is not None and rescue.get("unfinished_futures")==1 and abort_enter is None and await_error is not None,
                  {"rescue":rescue,"timeline":timeline})
        else:
            t={r.get("event"):r.get("ns") for r in timeline}
            check(key+":candidate_error_aborts_without_rescue",
                  rescue is None and abort_enter is not None and abort_result is not None and await_error is not None and
                  t.get("abort_enter",10**30)<t.get("await_error",-1),
                  {"abort_enter":abort_enter,"abort_result":abort_result,"await_error":await_error,"timeline":timeline})
    cells[key]={"trace_sha256":hashlib.sha256(trace_bytes).hexdigest(),
                "wire_sha256":hashlib.sha256(wire_bytes).hexdigest(),
                "execution":execution,"timeline":timeline,"error":error,
                "wire_interrupt_request":request,"wire_interrupt_response":response,
                "completion_notifications":completed,"summary":{"commands":commands,"terminal":terminals,
                "futures_done":trace.get("all_futures_done"),"reader_alive":trace.get("reader_alive"),
                "journal_closed":trace.get("journal_closed"),"peer_returncode":trace.get("peer_returncode"),
                "group_absent":trace.get("process_group_absent"),"watchdog_alive":trace.get("watchdog_alive")}}

passed=sum(c["pass"] for c in checks)
result={"schema":"v39-ordinary-cover-interrupt-ack-independent-saved-audit-v1",
        "baseline_source_ref":BASELINE_SHA,"harness_pins":HARNESS_PINS,
        "source_inventory":source_inventory,"cells":cells,"checks":checks,
        "checks_passed":passed,"checks_total":len(checks),"failures":[c["name"] for c in checks if not c["pass"]],
        "overall_pass":passed==len(checks),
        "limits":["Saved JSON/JSONL and source inventory audit only; no candidate/controller/test code imported or executed by this auditor.",
          "Six one-shot inert real-Popen cells use a synthetic V39 session, observation reader, and cleanup-entry spy; no model, game, GUI, or input calls.",
          "Watchdog-censored waits measure only whether the arm remains pending at the watchdog boundary, not a 90-second latency distribution.",
          "This checks the ordinary fatal cover-terminal interrupt path only; no invalidation, real physical input/release, application effect, or production cleanup is demonstrated.",
          "If abort itself fails before closing the transport, ThreadPoolExecutor may still wait for the planner wait timeout; this audit does not claim that failure path is bounded."]}
OUT.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
print(json.dumps({"overall_pass":result["overall_pass"],"checks":f"{passed}/{len(checks)}","failures":result["failures"],"output":str(OUT)},indent=2))
sys.exit(bool(result["failures"]))

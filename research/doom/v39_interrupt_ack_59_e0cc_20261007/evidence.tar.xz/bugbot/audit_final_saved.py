#!/usr/bin/env python3
"""Read-only audit of the three final v2 real-Popen cells; no producer runs."""
import hashlib, json, re, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=Path(__file__).resolve().parent/'audit-final-result.json'
checks=[]
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p): return json.loads(Path(p).read_text())
def add(name, ok, detail=None): checks.append({'name':name,'pass':bool(ok),'detail':detail})
def rows(t,event): return [r for r in t.get('timeline',[]) if r.get('event')==event]
def one(xs): return xs[0] if len(xs)==1 else None

snap_path=ROOT/'FINAL_MATRIX_SOURCE_SNAPSHOT.json'; snap=load(snap_path)
source_path=ROOT/'FINAL_SOURCE.json'; final_source=load(source_path)
expected=snap.get('source_hashes',{}).get('candidate',{})
add('final_source_index_matches_matrix', final_source==expected, {'snapshot_count':len(expected),'final_source_count':len(final_source)})
export=ROOT/'candidate-v2/source'; inventory=[]
for rel,want in sorted(expected.items()):
 p=export/rel; got=sha(p) if p.is_file() else None
 inventory.append({'path':rel,'expected':want,'actual':got,'pass':got==want})
actual={str(p.relative_to(export)) for p in export.rglob('*') if p.is_file()}
add('candidate_v2_export_matches_all_82_snapshot_hashes',len(expected)==82 and all(r['pass'] for r in inventory) and actual==set(expected),{'count':len(inventory),'bad':[r for r in inventory if not r['pass']],'missing':sorted(set(expected)-actual),'extra':sorted(actual-set(expected))})
for rel,want in snap.get('harness_hashes',{}).items():
 p=ROOT/rel; got=sha(p) if p.is_file() else None
 add('final_harness:'+rel,got==want,{'actual':got,'expected':want})
# Confirm the three tracked edited files in the owned current checkout are the
# exact final source version exercised. Historical/base refs remain immutable.
repo=Path('<task-root>/work/perkey-owner-guard-repo-e0cc-20261005')
changed=['research/doom/map01_overlap_controller_v39.py','research/doom/test_map01_overlap_controller_v39_cover_terminal.py','research/live_control/persistent_planner_adapter_v2.py']
repo_rows=[]
for rel in changed:
 want=expected.get(rel); p=repo/rel; got=sha(p) if p.is_file() else None
 repo_rows.append({'path':rel,'expected':want,'actual':got,'pass':got==want})
add('working_checkout_final_changed_files_match_run_source',all(x['pass'] for x in repo_rows),repo_rows)

runs=ROOT/'runs-final'; cells={}
for mode in ('ack_silent','ack_complete','rpc_error'):
 key='candidate-'+mode; run=runs/key
 trace_b=(run/'trace.json').read_bytes(); trace=json.loads(trace_b)
 wire_b=(run/'wire.jsonl').read_bytes(); wire=[json.loads(line) for line in wire_b.decode().splitlines() if line.strip()]
 receipt=load(runs/(key+'.execution.json')); peer=load(run/'peer_identity.json')
 stdout=runs/(key+'.stdout.txt'); stderr=runs/(key+'.stderr.txt')
 cmd=receipt.get('command',[])
 def arg(flag):
  try:return cmd[cmd.index(flag)+1]
  except (ValueError,IndexError):return None
 cmdok=(bool(cmd) and Path(cmd[0]).name in ('python3','python') and
  any(Path(x).name=='controller_probe.py' for x in cmd) and
  Path(arg('--source') or '/none').resolve()==(ROOT/'candidate-v2/source').resolve() and
  Path(arg('--out') or '/none').resolve()==run.resolve() and arg('--mode')==mode)
 receiptok=(receipt.get('returncode')==0 and receipt.get('outer_timeout') is False and cmdok and
  stdout.is_file() and stderr.is_file() and sha(stdout)==receipt.get('stdout_sha256') and sha(stderr)==receipt.get('stderr_sha256'))
 add(key+':execution_receipt',receiptok,{'returncode':receipt.get('returncode'),'outer_timeout':receipt.get('outer_timeout'),'command_matches':cmdok,'stdout_hash_ok':stdout.is_file() and sha(stdout)==receipt.get('stdout_sha256'),'stderr_hash_ok':stderr.is_file() and sha(stderr)==receipt.get('stderr_sha256')})
 peer_cmd=peer.get('command',[])
 peerok=(len(peer_cmd)>=3 and Path(peer_cmd[0]).name in ('python3','python') and Path(peer_cmd[2]).resolve()==(ROOT/'inert_peer.py').resolve() and peer_cmd[-1]==mode and isinstance(peer.get('pid'),int))
 add(key+':peer_identity',peerok,peer)
 timeline=trace.get('timeline',[]); names=[x.get('event') for x in timeline]; events=trace.get('events',[])
 terminals=[x for x in events if x.get('event')=='terminal']; accepted=[x for x in events if x.get('event')=='accepted']; commands=trace.get('commands',[])
 fatal=(trace.get('mode')==mode and trace.get('no_model_or_native_input') is True and len(commands)==1 and commands[0].get('op')=='submit' and commands[0].get('id')=='cover-0' and len(accepted)==1 and accepted[0].get('id')=='cover-0' and len(terminals)==1 and terminals[0].get('id')=='cover-0' and terminals[0].get('status')=='failed' and terminals[0].get('error')=='injected input error' and terminals[0].get('release')=={'verified':True,'keys_down':[],'buttons_down':[]} and trace.get('error',{}).get('type')=='RuntimeError' and 'cover terminal lacks allowed status' in trace.get('error',{}).get('message','') and 'final_admission' not in names and rows(trace,'cleanup_entry') and rows(trace,'main_error'))
 retired=(trace.get('all_futures_done') is True and trace.get('reader_alive') is False and trace.get('journal_closed') is True and trace.get('peer_returncode') is not None and trace.get('process_group_absent') is True and trace.get('watchdog_alive') is False)
 add(key+':primary_fatal_error_no_admission_and_retirement',fatal and retired,{'fatal':fatal,'retired':retired,'events':events,'error':trace.get('error'),'cleanup':rows(trace,'cleanup_entry'),'retirement':{x:trace.get(x) for x in ('all_futures_done','reader_alive','journal_closed','peer_returncode','process_group_absent','watchdog_alive')}})
 sent=[x.get('message',{}) for x in wire if x.get('direction')=='sent']; recv=[x.get('message',{}) for x in wire if x.get('direction')=='received']
 req=one([x for x in sent if x.get('method')=='turn/interrupt'])
 resp=one([x for x in recv if req is not None and x.get('id')==req.get('id')])
 completed=[x for x in recv if x.get('method')=='turn/completed' and x.get('params',{}).get('threadId')=='inert-thread' and x.get('params',{}).get('turn',{}).get('id')=='inert-turn']
 wireok=req is not None and req.get('params')=={'threadId':'inert-thread','turnId':'inert-turn'} and resp is not None and resp.get('id')==req.get('id')
 if mode=='rpc_error': wireok=wireok and resp.get('error',{}).get('code')==-32001 and resp.get('error',{}).get('message')=='inert peer rejects interrupt; turn remains unfinished' and not completed
 else: wireok=wireok and resp.get('result')=={} and 'error' not in resp
 add(key+':interrupt_request_response_and_mode',wireok,{'request':req,'response':resp,'completion_count':len(completed)})
 abort_enter=one(rows(trace,'abort_enter')); abort_result=one(rows(trace,'abort_result')); interrupt_result=one(rows(trace,'interrupt_result')); await_error=one(rows(trace,'await_error')); rescue=rows(trace,'external_rescue_enter')
 if mode=='ack_silent':
  note='pending planner turn transport aborted' in trace.get('error',{}).get('notes',[])
  check=(len(completed)==0 and abort_enter is not None and abort_result is not None and await_error is not None and not rescue and interrupt_result is not None and interrupt_result.get('result',{}).get('outcome')=='requested' and interrupt_result['ns']<abort_enter['ns']<await_error['ns']<=abort_result['ns'] and note)
  add(key+':ack_only_aborts_pending_future_without_rescue',check,{'interrupt_result':interrupt_result,'abort_enter':abort_enter,'await_error':await_error,'abort_result':abort_result,'notes':trace.get('error',{}).get('notes'), 'timeline':timeline})
 elif mode=='ack_complete':
  ar=one(rows(trace,'await_result')) or {}
  check=(len(completed)==1 and ar.get('status')=='completed' and ar.get('cancelled') is True and ar.get('eligible') is False and abort_enter is None and abort_result is None and await_error is None and not rescue and 'pending planner turn transport aborted' not in trace.get('error',{}).get('notes',[]))
  add(key+':completed_race_skips_abort_and_stays_ineligible',check,{'await_result':ar,'interrupt_result':interrupt_result,'completion_count':len(completed),'timeline':timeline})
 else:
  note='planner interrupt transport failed' in trace.get('error',{}).get('notes',[]) and 'pending planner turn transport aborted' in trace.get('error',{}).get('notes',[])
  check=(not completed and abort_enter is not None and abort_result is not None and await_error is not None and not rescue and interrupt_result is not None and interrupt_result.get('result',{}).get('outcome')=='request_error' and interrupt_result['ns']<abort_enter['ns']<await_error['ns']<=abort_result['ns'] and abort_result.get('result',{}).get('outcome')=='aborted' and note)
  add(key+':rpc_error_aborts_and_preserves_primary_error',check,{'interrupt_result':interrupt_result,'abort_enter':abort_enter,'await_error':await_error,'abort_result':abort_result,'notes':trace.get('error',{}).get('notes'),'timeline':timeline})
 cells[key]={'trace_sha256':sha(run/'trace.json'),'wire_sha256':sha(run/'wire.jsonl'),'receipt':receipt,'peer':peer,'timeline':timeline,'terminal':terminals,'wire_interrupt_request':req,'wire_interrupt_response':resp,'completion_count':len(completed),'retirement':{x:trace.get(x) for x in ('all_futures_done','reader_alive','journal_closed','peer_returncode','process_group_absent','watchdog_alive')}}

# Preserve and report prior one-shot unit results without re-execution.
recheck=load(ROOT/'FINAL_RECHECK.json')
recheck_rows=[]
for index,row in enumerate(recheck):
 log=ROOT/row['log']; text=log.read_text() if log.is_file() else ''
 ok=row.get('returncode')==0 and 'Ran 101 tests' in text and '\nOK\n' in text
 recheck_rows.append({'index':index,'returncode':row.get('returncode'),'tests_101_and_OK_in_log':ok,'log_sha256':sha(log) if log.is_file() else None})
add('final_unit_runs_normal_and_optimized_101_each',len(recheck_rows)==2 and all(r['tests_101_and_OK_in_log'] for r in recheck_rows),recheck_rows)
prior=load(ROOT/'FINAL_FOCUSED.json')
add('first_loader_error_preserved_as_failure',len(prior)==1 and prior[0].get('returncode')==1,{'receipt':prior})
red=load(ROOT/'DIAGNOSTIC_RED.json')
add('pre_guard_false_note_regression_red_preserved',red.get('returncode')==1,red)

passed=sum(x['pass'] for x in checks)
result={'schema':'v39-fatal-cover-interrupt-final-saved-audit-v1','saved_data_only':True,'overall_pass':passed==len(checks),'checks_passed':passed,'checks_total':len(checks),'failures':[x['name'] for x in checks if not x['pass']],'matrix_snapshot_sha256':sha(snap_path),'final_source_index_sha256':sha(source_path),'cells':cells,'checks':checks,'limits':['Audited three final candidate real-Popen cells from saved traces, wire logs and receipts; no producer or candidate rerun.','Source lock covers the final 82-file candidate export; current checkout matches the three edited source/test files.','The JSON-RPC peer is a local inert Popen process; V39 session, observations and cleanup spy are synthetic. No model, Codex service, game, GUI, physical input, or task effect was tested.','The candidate aborts the transport after a fatal session error if its future remains pending. This does not bound the case where abort itself fails before unblocking the future; pool join can still wait for the configured planner timeout.','No live-control or release-safety claim follows from these construction cells.']}
OUT.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'overall_pass':result['overall_pass'],'checks':f'{passed}/{len(checks)}','failures':result['failures'],'output':str(OUT)},indent=2))
sys.exit(bool(result['failures']))

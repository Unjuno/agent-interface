#!/usr/bin/env python3
"""Read-only v2 oracle for the preserved six-cell ordinary fatal-terminal matrix.

Consumes saved source inventories, JSON/JSONL traces, and execution receipts only.
It does not import or execute controller, candidate, peer, or test code.
"""
import hashlib, json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent / "audit-result-v4.json"
MODES = ("ack_silent", "ack_complete", "rpc_error")
ARMS = ("baseline", "candidate")
checks=[]
def add(name, ok, detail=None): checks.append({"name":name,"pass":bool(ok),"detail":detail})
def load(p): return json.loads(Path(p).read_text())
def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ev(rows, name): return [r for r in rows if r.get("event")==name]
def one(rows): return rows[0] if len(rows)==1 else None

# Matrix snapshot is the run's frozen path->hash map; verify the snapshot and
# every exported byte rather than comparing against a moving worktree.
snapshot_path=ROOT/"MATRIX_SOURCE_SNAPSHOT.json"
snapshot_bytes=snapshot_path.read_bytes()
snapshot=load(snapshot_path)
add("matrix_snapshot_sha256", digest(snapshot_path)=="a29cccef2d288359be915b3bc98451ab9b15361763f7b9a5bd588f56babdb060", {"actual":digest(snapshot_path),"expected":"a29cccef2d288359be915b3bc98451ab9b15361763f7b9a5bd588f56babdb060"})
for rel, want in snapshot.get("harness_hashes",{}).items():
    p=ROOT/rel; got=digest(p) if p.is_file() else None
    add("harness:"+rel, got==want, {"actual":got,"expected":want})
source_audit={}
for arm in ARMS:
    expected=snapshot.get("source_hashes",{}).get(arm,{})
    source_root=ROOT/arm/"source"
    rows=[]
    for rel,want in sorted(expected.items()):
        p=source_root/rel
        got=digest(p) if p.is_file() else None
        rows.append({"path":rel,"expected":want,"actual":got,"pass":got==want})
    actual_paths={str(p.relative_to(source_root)) for p in source_root.rglob("*") if p.is_file()}
    expected_paths=set(expected)
    source_audit[arm]={"expected_count":len(expected),"verified_count":sum(r["pass"] for r in rows),"rows":rows,
                       "missing":sorted(expected_paths-actual_paths),"extra":sorted(actual_paths-expected_paths)}
    add(arm+":exact_source_export", bool(expected) and all(r["pass"] for r in rows) and actual_paths==expected_paths,
        {"count":len(rows),"mismatch":[r for r in rows if not r["pass"]],"missing":source_audit[arm]["missing"],"extra":source_audit[arm]["extra"]})

runs=ROOT/"runs"
expected_dirs={f"{a}-{m}" for a in ARMS for m in MODES}
actual_dirs={p.name for p in runs.iterdir() if p.is_dir()}
add("exact_six_run_directories",actual_dirs==expected_dirs,{"expected":sorted(expected_dirs),"actual":sorted(actual_dirs)})
cells={}
for arm in ARMS:
  for mode in MODES:
    key=f"{arm}-{mode}"; run=runs/key
    try:
      trace_bytes=(run/"trace.json").read_bytes(); trace=json.loads(trace_bytes)
      wire_bytes=(run/"wire.jsonl").read_bytes(); wire=[json.loads(x) for x in wire_bytes.decode().splitlines() if x.strip()]
      receipt=load(runs/(key+".execution.json"))
      peer=load(run/"peer_identity.json")
    except Exception as exc:
      add(key+":readback",False,repr(exc)); continue
    timeline=trace.get("timeline",[]); names=[r.get("event") for r in timeline]
    timed={name:one(ev(timeline,name)) for name in {r.get("event") for r in timeline}}
    events=trace.get("events",[])
    terminals=[r for r in events if r.get("event")=="terminal"]
    accepted=[r for r in events if r.get("event")=="accepted"]
    submitted=trace.get("commands",[])
    sent=[r.get("message",{}) for r in wire if r.get("direction")=="sent"]
    recvd=[r.get("message",{}) for r in wire if r.get("direction")=="received"]
    requests=[r for r in sent if r.get("method")=="turn/interrupt"]
    request=one(requests)
    response=one([r for r in recvd if request is not None and r.get("id")==request.get("id")])
    completed=[r for r in recvd if r.get("method")=="turn/completed" and r.get("params",{}).get("threadId")=="inert-thread" and r.get("params",{}).get("turn",{}).get("id")=="inert-turn"]
    abort_enters=ev(timeline,"abort_enter"); abort_results=ev(timeline,"abort_result")
    rescues=ev(timeline,"external_rescue_enter")
    await_errors=ev(timeline,"await_error"); await_results=ev(timeline,"await_result")
    cleanup=one(ev(timeline,"cleanup_entry")); main_error=one(ev(timeline,"main_error")); main_exit=one(ev(timeline,"main_exit"))
    err=trace.get("error",{})
    command=receipt.get("command",[])
    def arg(flag):
      try:return command[command.index(flag)+1]
      except (ValueError,IndexError):return None
    cmd_ok=(bool(command) and Path(command[0]).name in ("python3","python") and
      any(Path(x).name=="controller_probe.py" for x in command) and
      Path(arg("--source") or "/nope").resolve()==(ROOT/arm/"source").resolve() and
      Path(arg("--out") or "/nope").resolve()==run.resolve() and arg("--mode")==mode)
    stdout_path=runs/(key+".stdout.txt"); stderr_path=runs/(key+".stderr.txt")
    receipt_ok=(receipt.get("returncode")==0 and receipt.get("outer_timeout") is False and cmd_ok and
      stdout_path.is_file() and stderr_path.is_file() and digest(stdout_path)==receipt.get("stdout_sha256") and digest(stderr_path)==receipt.get("stderr_sha256"))
    add(key+":execution_receipt_and_output_hashes",receipt_ok,{"returncode":receipt.get("returncode"),"outer_timeout":receipt.get("outer_timeout"),"command_matches":cmd_ok,"stdout_hash_matches":stdout_path.is_file() and digest(stdout_path)==receipt.get("stdout_sha256"),"stderr_hash_matches":stderr_path.is_file() and digest(stderr_path)==receipt.get("stderr_sha256")})
    peer_cmd=peer.get("command",[])
    peer_ok=(len(peer_cmd)>=3 and Path(peer_cmd[0]).name in ("python3","python") and Path(peer_cmd[2]).resolve()==(ROOT/"inert_peer.py").resolve() and peer_cmd[-1]==mode and isinstance(peer.get("pid"),int))
    add(key+":recorded_inert_peer_identity",peer_ok,{"identity":peer})
    terminal=one(terminals); accepted_event=one(accepted)
    core=(trace.get("mode")==mode and trace.get("no_model_or_native_input") is True and
      len(submitted)==1 and submitted[0].get("op")=="submit" and submitted[0].get("id")=="cover-0" and
      accepted_event is not None and accepted_event.get("id")=="cover-0" and
      terminal is not None and terminal.get("id")=="cover-0" and terminal.get("status")=="failed" and terminal.get("error")=="injected input error" and
      terminal.get("release")=={"verified":True,"keys_down":[],"buttons_down":[]} and
      err.get("type")=="RuntimeError" and "cover terminal lacks allowed status" in err.get("message","") and
      "final_admission" not in names and trace.get("all_futures_done") is True and trace.get("reader_alive") is False and trace.get("journal_closed") is True and
      trace.get("peer_returncode") is not None and trace.get("process_group_absent") is True and trace.get("watchdog_alive") is False and
      cleanup is not None and cleanup.get("error")=="RuntimeError" and main_error is not None and main_error.get("kind")=="RuntimeError" and main_exit is not None)
    add(key+":fatal_cover_and_retirement",core,{"commands":submitted,"accepted":accepted,"terminal":terminals,"error":err,"cleanup":cleanup,"main_exit":main_exit,"retirement":{k:trace.get(k) for k in ("all_futures_done","reader_alive","journal_closed","peer_returncode","process_group_absent","watchdog_alive")}})
    wire_ok=(request is not None and request.get("params")=={"threadId":"inert-thread","turnId":"inert-turn"} and response is not None and response.get("id")==request.get("id"))
    if mode in ("ack_silent","ack_complete"):
      wire_ok=wire_ok and response.get("result")=={} and "error" not in response
    else:
      wire_ok=wire_ok and response.get("error",{}).get("code")==-32001 and response.get("error",{}).get("message")=="inert peer rejects interrupt; turn remains unfinished"
    add(key+":interrupt_wire_identity",wire_ok,{"request":request,"response":response,"completions":completed})
    interrupt_result=one(ev(timeline,"interrupt_result"))
    if mode=="ack_silent":
      add(key+":ack_is_not_completion",len(completed)==0 and not await_results,{"completion_count":len(completed),"await_results":await_results})
      if arm=="baseline":
        rescue=one(rescues)
        cond=(interrupt_result is not None and interrupt_result.get("result",{}).get("outcome")=="requested" and
              rescue is not None and rescue.get("unfinished_futures")==1 and not abort_enters and len(await_errors)==1)
      else:
        ae=one(abort_enters); ar=one(abort_results); we=one(await_errors)
        cond=(interrupt_result is not None and interrupt_result.get("result",{}).get("outcome")=="requested" and
              ae is not None and ar is not None and not rescues and we is not None and
              interrupt_result["ns"]<ae["ns"]<we["ns"]<=ar["ns"])
      add(key+":"+("baseline_requires_rescue" if arm=="baseline" else "candidate_aborts_without_rescue"),cond,
          {"interrupt_result":interrupt_result,"abort_enter":abort_enters,"abort_result":abort_results,"await_error":await_errors,"rescue":rescues,"timeline":timeline})
    elif mode=="ack_complete":
      result=one(await_results)
      result_obj=result or {}
      cond=(len(completed)==1 and result_obj.get("status")=="completed" and result_obj.get("cancelled") is True and result_obj.get("eligible") is False and not abort_enters and not rescues and not await_errors)
      add(key+":completion_race_does_not_abort_or_admit",cond,{"completion_count":len(completed),"await_result":result,"interrupt_result":interrupt_result,"timeline":timeline})
    else:
      add(key+":rpc_error_fixture",response is not None and response.get("error",{}).get("code")==-32001 and not completed,{"response":response,"completion_count":len(completed)})
      ae=one(abort_enters); ar=one(abort_results); we=one(await_errors)
      if arm=="baseline":
        cond=(ae is not None and ar is not None and not rescues and we is not None)
        label="baseline_rpc_error_aborts_without_rescue"
      else:
        cond=(ae is not None and ar is not None and not rescues and we is not None and ae["ns"]<we["ns"]<=ar["ns"])
        label="candidate_rpc_error_aborts_without_rescue"
      add(key+":"+label,cond,{"interrupt_result":interrupt_result,"abort_enter":ae,"abort_result":ar,"await_error":we,"rescue":rescues,"timeline":timeline})
    cells[key]={"trace_sha256":digest(run/"trace.json"),"wire_sha256":digest(run/"wire.jsonl"),"execution":receipt,"peer":peer,"timeline":timeline,"wire_request":request,"wire_response":response,"completion_notifications":completed,"terminal":terminal,"retirement":{k:trace.get(k) for k in ("all_futures_done","reader_alive","journal_closed","peer_returncode","process_group_absent","watchdog_alive")}}
passed=sum(c["pass"] for c in checks)
result={"schema":"v39-ordinary-cover-interrupt-ack-independent-saved-audit-v4","read_only_saved_data":True,"checks_passed":passed,"checks_total":len(checks),"overall_pass":passed==len(checks),"failures":[c["name"] for c in checks if not c["pass"]],"source_exports":source_audit,"matrix_snapshot_sha256":digest(snapshot_path),"cells":cells,"checks":checks,"prior_audits":[{"file":"bugbot/audit-result-v1.json","status":"FAIL 18/29 preserved","reasons":["v1 expected a freeze.json instead of using MATRIX_SOURCE_SNAPSHOT.json","v1 used exit_code although receipts store returncode","v1 read terminal/events from summary-style fields rather than top-level events","v1 expected no abort on baseline rpc_error although #8280 already aborts on interrupt RPC error","v1 assumed completion must arrive after interrupt response; completion can race before the RPC response"]},{"file":"bugbot/audit-result-v2.json","status":"FAIL 35/38 preserved","reasons":["v2's snapshot hash check used an empty placeholder rather than the computed pinned digest","v2 treated await_result as nested under result although its actual fields are top-level"]}],"limits":["Read-only audit of six retained real-Popen runs and their source exports; no candidate or test rerun.","The controller session, observations, and cleanup-entry spy are synthetic; peer uses actual Popen app-server transport, not a model or Codex service.","Acknowledgement-silent mode shows baseline remained pending until the watchdog external-close rescue; candidate abort returned without that rescue. It is a bounded construction comparison, not a 90-second production latency claim.","Completion may race ahead of the interrupt RPC response; eligibility/cancellation and no-abort behavior are the checked contract.","Does not establish real-game behavior, physical input release, or any live-control effect.","If abort itself fails before closing transport, the executor may still wait for its existing planner timeout; this matrix does not show that failure mode bounded."]}
OUT.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
print(json.dumps({"overall_pass":result["overall_pass"],"checks":f"{passed}/{len(checks)}","failures":result["failures"],"output":str(OUT)},indent=2))
sys.exit(bool(result["failures"]))

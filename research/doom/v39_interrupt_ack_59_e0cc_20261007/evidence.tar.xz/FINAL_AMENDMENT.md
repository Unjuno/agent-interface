# Ordinary repair revision after the first six cells

The first six cells and their source snapshots remain unchanged. Root noticed
that the adapter can observe an already-completed turn during a race and return
already_terminal, while the caller's success diagnostic unconditionally said
transport aborted. A new regression fails on v1 for that false statement.
The final controller emits the aborted note only for outcome=aborted. It makes
no additional cancellation request or policy change.

Final ordinary validation uses a new source snapshot and three fresh candidate
cells (ack_silent, ack_complete, rpc_error), saved separately in runs-final.
The baseline six-cell comparison is not rerun. Earlier source/outputs and unit
failures remain immutable. The full focused suite's first invocation had one
loader error because PYTHONPATH omitted research/doom for a top-level helper
import; repeat uses the declared doom/live_control module search path and
separate trace/log paths. No production fix is credited for this runner setup.

# Issue #2447 — stale handoff fail-closed construction case

Status: fresh construction-only allocation; new seed 2447007. No formal rows authorized or consumed.

## H/T/D/C/U

- **H:** A temporal completion signal and later visible phase effect must not authorize the next subgoal when its bound observation exceeds a frozen age limit. A stale handoff should return a typed refusal before any third-subgoal input, with the prior bounded subgoal already released.
- **T:** One fresh Docker Desktop Linux/amd64 MAP01 episode from seed 2447007, drop class, temporal gate, requested heading 120°. Execute the inherited drop phase, then one fresh-bound Right 190ms subgoal with paired screenshots. For the next subgoal, capture a new screenshot and matching X11 focus/surface/geometry, wait 350ms, then evaluate a pre-frozen 250ms monotonic freshness limit. Record the refusal and prove no input was admitted for that handoff. One invocation only.
- **D:** Construction PASS only if the phase temporal detector independently recomputes DROP_COMPLETED, the Right action has a valid paired visual effect and empty verified release, the attempted next observation hash/binding is exact, measured age is >250ms, typed decision is `REFUSE_STALE`, and third-subgoal input emissions are zero. Any run error, unclear age/binding, missing evidence or unexpected third input is retained as STOP/FAIL; no retries.
- **C:** One temporal-arm live GUI episode; no model; same inherited setup, detector, InputOwner and screen capture. Pinned Docker image, network none, read-only root/source, fresh evidence output. Scorer-only state is not available to the freshness guard.
- **U:** Tests only one stale-time fault. Does not cover missing/ambiguous evidence, delayed/dropped frame semantics, early/repeated false positives, wrong-direction, focus loss, timeout, restart, held-out transfer, episode completion, endpoint comparison or formal #2447 acceptance.

## Frozen case

ID `issue2447-stale-guard-construction-2447007`; seed `2447007`; class `drop`; gate `temporal_gate`; requested heading `120°`; stale TTL `250ms`; injected delay `350ms`. Exact runner/auditor/source hashes and image identity must be recorded before launch. This case is not pooled with 2447005/2447006.

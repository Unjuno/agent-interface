import json,tempfile
from pathlib import Path
import audit

def main():
    # Excluded construction validates per-case audit mechanics only; no formal aggregate gate is evaluated.
    root=Path('/tmp/ai_exp831/construction')
    rows=[('endpoint',{'id':'c-endpoint','class':'drop','heading':75,'seed':998190,'gate':'endpoint_gate'}),('temporal',{'id':'c-temporal','class':'drop','heading':75,'seed':998190,'gate':'temporal_gate'})]
    for name,row in rows:
        score,errs=audit.audit_case(root/name,row)
        assert not errs,(name,errs)
        assert score['hidden_phase1_drop']
        assert abs(score['next_subgoal_yaw_delta'])>=5
    assert json.loads((root/'endpoint'/'score.json').read_text())['extra_forward_issued'] is True
    assert json.loads((root/'temporal'/'score.json').read_text())['extra_forward_issued'] is False
    print('2/2 construction case audits PASS')
if __name__=='__main__':main()

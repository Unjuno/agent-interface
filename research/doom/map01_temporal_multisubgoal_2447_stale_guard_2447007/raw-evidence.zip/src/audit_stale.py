from pathlib import Path
import argparse, hashlib, json
import numpy as np
from PIL import Image
import audit_v8

def audit(root):
    root=Path(root);score=json.loads((root/'score.json').read_text());errors=[]
    if score.get('seed')!=2447007 or score.get('gate')!='temporal_gate' or score.get('class')!='drop':errors.append('case_identity')
    if score.get('error') is not None:errors.append('runner_error')
    prior=json.loads((root/'next_subgoal/result.json').read_text());pdir=root/'next_subgoal'
    before=Image.open(pdir/'before-action.png').convert('RGB');after=Image.open(pdir/'after-action.png').convert('RGB')
    f=audit_v8.flow(before,after);prior_ok=bool(prior.get('key')=='Right' and prior.get('release',{}).get('verified') and not prior['release'].get('keys_down') and not prior['release'].get('buttons_down') and f['status']=='MEASURED')
    if not prior_ok:errors.append('prior_subgoal_effect_or_release')
    attempt=json.loads((root/'third_subgoal/result.json').read_text());img=Image.open(root/'third_subgoal/handoff-observation.png').convert('RGB');digest=hashlib.sha256(np.asarray(img).tobytes()).hexdigest()
    binding={k:score.get('setup_binding',{}).get(k) for k in ('focus','surface','geometry')}
    age=attempt.get('observation_age_ms');valid=bool(attempt.get('observation_binding')==binding and digest==attempt.get('observation_sha256') and attempt.get('decision_ns',0)>attempt.get('observation_capture_ns',0) and age is not None and abs(age-(attempt['decision_ns']-attempt['observation_capture_ns'])/1e6)<1e-6)
    if not valid:errors.append('observation_receipt_or_binding')
    if not age or age<=250 or attempt.get('ttl_ms')!=250 or attempt.get('decision')!='REFUSE_STALE':errors.append('stale_decision')
    if attempt.get('next_subgoal_issued') is not False or attempt.get('input_emissions')!=0 or json.loads((root/'third_subgoal/events.json').read_text()) or json.loads((root/'third_subgoal/owner-records.json').read_text()):errors.append('refusal_not_input_free')
    phase={'independent':None}
    # Reuse the frozen raw-frame auditor's metric, but allow this successor allocation.
    pr=json.loads((root/'phase1/result.json').read_text());frames=[Image.open(root/'phase1'/n).convert('RGB') for n in pr['frame_files']]
    pairs=[]
    for i,(a,b) in enumerate(zip(frames,frames[1:])):
        m=audit_v8.flow(a,b);m.update(dt_ms=(pr['frame_capture_start_ns'][i+1]-pr['frame_capture_start_ns'][i])/1e6);pairs.append(m)
    eligible=[r for r in pairs if r['dt_ms']<=100 and r['valid_tracks']>=80 and r['median_dy_px'] is not None];detected=any(r['median_dy_px']<=-20 for r in eligible)
    if not detected or pr.get('temporal_status')!='DROP_COMPLETED' or score.get('extra_forward_issued') is not False:errors.append('temporal_gate_recompute')
    phase={'status':pr.get('temporal_status'),'eligible_pairs':len(eligible),'drop_pairs':sum(r['median_dy_px']<=-20 for r in eligible),'raw_recompute':detected,'runner_issued_extra_forward':score.get('extra_forward_issued')}
    return {'schema':'issue2447-stale-handoff-audit-v1','case':'issue2447-stale-guard-construction-2447007','decision':'PASS_CONSTRUCTION_FAIL_CLOSED' if not errors else 'HOLD_CONSTRUCTION','errors':errors,'phase':phase,'prior_subgoal':{'key':prior.get('key'),'release_verified_empty':prior_ok,'visual_flow':f},'stale_attempt':{'age_ms':age,'ttl_ms':attempt.get('ttl_ms'),'decision':attempt.get('decision'),'receipt_hash_matches_image':digest==attempt.get('observation_sha256'),'binding_matches_setup':attempt.get('observation_binding')==binding,'next_subgoal_issued':attempt.get('next_subgoal_issued'),'input_emissions':attempt.get('input_emissions')},'formal_rows':0,'retries':0,'scope':'Single construction-only stale-observation refusal probe; not Issue #2447 acceptance or safety-estimate.'}
def main():
    p=argparse.ArgumentParser();p.add_argument('--evidence',required=True);p.add_argument('--out',required=True);a=p.parse_args();r=audit(a.evidence);Path(a.out).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps(r,sort_keys=True))
if __name__=='__main__':main()

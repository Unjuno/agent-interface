from pathlib import Path
import argparse, hashlib, json, time
from Xlib import display
from common import screenshot, write

def main():
    p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--ctx',required=True);p.add_argument('--out',required=True);p.add_argument('--ttl-ms',type=int,required=True);p.add_argument('--delay-ms',type=int,required=True);a=p.parse_args()
    out=Path(a.out);out.mkdir(parents=True,exist_ok=False);ctx=json.loads(Path(a.ctx).read_text());d=display.Display(ctx['display'])
    focus=d.get_input_focus().focus.id;win=d.create_resource_object('window',ctx['surface']);geo=win.get_geometry();pos=d.screen().root.translate_coords(win,0,0);binding=[pos.x,pos.y,geo.width,geo.height]
    if focus!=ctx['focus'] or binding!=ctx['geometry']:raise RuntimeError('FRESH_OBSERVATION_BINDING_MISMATCH')
    capture_ns=time.perf_counter_ns();im=screenshot(ctx['display'],binding);digest=hashlib.sha256(im.tobytes()).hexdigest();im.save(out/'handoff-observation.png');d.close()
    time.sleep(a.delay_ms/1000);decision_ns=time.perf_counter_ns();age_ms=(decision_ns-capture_ns)/1e6;stale=age_ms>a.ttl_ms
    result={'schema':'agent-interface/stale-handoff-guard-v1','decision':'REFUSE_STALE' if stale else 'ALLOW_CURRENT','reason':'stale_observation' if stale else None,'observation_capture_ns':capture_ns,'decision_ns':decision_ns,'observation_age_ms':age_ms,'ttl_ms':a.ttl_ms,'injected_delay_ms':a.delay_ms,'observation_sha256':digest,'observation_binding':{'focus':focus,'surface':ctx['surface'],'geometry':binding},'next_subgoal_issued':False,'input_emissions':0}
    write(out/'result.json',result);write(out/'events.json',[]);write(out/'owner-records.json',[])
if __name__=='__main__':main()

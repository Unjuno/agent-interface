import json,os,sys,subprocess
sys.path.insert(0,'/src/research/doom');sys.path.insert(0,'/src/research/live_control')
from map01_overlap_controller_v39 import app_server_command
cmd=app_server_command();p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1)
def req(i,m,params=None):
 q={'method':m,'id':i}
 if params is not None:q['params']=params
 p.stdin.write(json.dumps(q,separators=(',',':'))+'\n');p.stdin.flush()
 while True:
  line=p.stdout.readline()
  if not line:raise RuntimeError('closed rc='+str(p.poll())+' stderr='+p.stderr.read()[-3000:])
  r=json.loads(line)
  if r.get('id')==i:
   if 'error'in r:raise RuntimeError(json.dumps(r['error']))
   return r['result']
info=req(1,'initialize',{'clientInfo':{'name':'V39 preflight','title':'V39 preflight','version':'1'},'capabilities':{'experimentalApi':False,'requestAttestation':False}})
p.stdin.write('{"method":"initialized"}\n');p.stdin.flush(); models=req(2,'model/list',{})
selected=[{'id':x['id'],'efforts':[e['reasoningEffort'] for e in x['supportedReasoningEfforts']]} for x in models.get('data',[]) if x['id']=='gpt-6.1-sol']
print(json.dumps({'command':cmd,'initialize':'PASS','selected_model':selected},sort_keys=True));p.stdin.close();p.terminate();p.wait(timeout=10)

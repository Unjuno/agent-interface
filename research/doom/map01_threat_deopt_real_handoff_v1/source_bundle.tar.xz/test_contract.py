import unittest
from policy import authority_guarded,handoff_fenced

class Contract(unittest.TestCase):
 def setUp(self):
  self.props=[{'proposal_id':'threat-g1','resource':'locomotion','source':'threat','authority_id':'threat-auth-g1','generation':1,'proposed_at':1,'ready':True},{'proposal_id':'deopt-g1','resource':'locomotion','source':'deopt','authority_id':None,'generation':1,'proposed_at':2,'ready':True}]
  self.lease=[{'resource':'locomotion','active':True,'valid_context':True,'start_tick':0,'end_tick':2,'generation':1,'authority_id':'threat-auth-g1'}]
 def test_active_both_protect_threat(self):
  for fn in (authority_guarded,handoff_fenced): self.assertEqual(fn(self.props,self.lease,{'locomotion':1},1)['selected']['locomotion']['proposal_id'],'threat-g1')
 def test_baseline_executes_stale_after_handoff(self):
  l=[dict(self.lease[0],active=False)];self.assertEqual(authority_guarded(self.props,l,{'locomotion':2},2)['selected']['locomotion']['proposal_id'],'deopt-g1')
 def test_candidate_rejects_stale_and_accepts_fresh(self):
  l=[dict(self.lease[0],active=False)];r=handoff_fenced(self.props,l,{'locomotion':2},2);self.assertNotIn('locomotion',r['selected']);self.assertTrue(any(d['proposal_id']=='deopt-g1' and d['reason']=='STALE_RESOURCE_GENERATION' for d in r['deferred']))
  fresh=dict(self.props[1],proposal_id='deopt-g2',generation=2,proposed_at=3);r=handoff_fenced(self.props+[fresh],l,{'locomotion':2},2);self.assertEqual(r['selected']['locomotion']['proposal_id'],'deopt-g2')
if __name__=='__main__':unittest.main()

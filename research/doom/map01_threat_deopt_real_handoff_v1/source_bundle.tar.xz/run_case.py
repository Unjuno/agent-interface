from __future__ import annotations
import argparse, hashlib, json, os, queue, subprocess, sys, threading, time
from pathlib import Path
from policy import authority_guarded, handoff_fenced

TASK='MAP01-THREAT-DEOPT-REAL-HANDOFF-20260917-001'
RUNTIME_BUNDLE_SHA256='522763418610ea10e57e55615fa71e76445200b9f86d208820ea97c77c234f0b'
THREAT_STEPS=[{'op':'hold','keys':['a'],'duration_ms':350},{'op':'hold','keys':['d'],'duration_ms':350},{'op':'observe'}]
DEOPT_STEPS=[{'op':'hold','keys':['e'],'duration_ms':40}] + ([{'op':'hold','keys':['Right'],'duration_ms':190}] * 6) + [{'op':'observe'}]

def wait_from(q,p,pred,timeout=45):
    end=time.monotonic()+timeout
    while time.monotonic()<end:
        try:r=q.get(timeout=.25)
        except queue.Empty:
            if p.poll() is not None: raise RuntimeError('session died: '+p.stderr.read())
            continue
        if pred(r): return r
    raise TimeoutError('expected event')

def run(arm:str, case_id:str, out:Path, runtime_root:Path, python:Path):
    out.mkdir(parents=True,exist_ok=False)
    doom=runtime_root/'research/doom'; live=runtime_root/'research/live_control'
    fixture=doom/'fixtures/map01-threat-contact-v2/fixture.json'; session=doom/'session_map01_v12.py'
    env=os.environ.copy(); env['PYTHONPATH']=f'{doom}:{live}'
    p=subprocess.Popen([str(python),str(session),'--out',str(out/'runtime'),'--seed','990619','--timeout-seconds','60','--skill','1','--load-fixture-manifest',str(fixture)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1,env=env)
    q=queue.Queue(); events=[]
    def reader():
        for line in p.stdout:
            try:r=json.loads(line)
            except Exception: continue
            events.append(r);q.put(r)
    threading.Thread(target=reader,daemon=True).start(); wait=lambda pred,t=45:wait_from(q,p,pred,t)
    ready=wait(lambda r:r.get('event')=='ready'); typed0=wait(lambda r:r.get('event')=='typed_observation'); obs0=wait(lambda r:r.get('event')=='observation' and r.get('sequence')==typed0.get('sequence'))
    proposals=[
      {'proposal_id':'threat-g1','resource':'locomotion','source':'threat','authority_id':'threat-auth-g1','generation':1,'proposed_at':1,'ready':True,'motor':'threat-cover-v31'},
      {'proposal_id':'deopt-g1','resource':'locomotion','source':'deopt','authority_id':None,'generation':1,'proposed_at':2,'ready':True,'motor':'repeated-no-progress-deopt-595'}]
    leases=[{'resource':'locomotion','active':True,'valid_context':True,'start_tick':0,'end_tick':2,'generation':1,'authority_id':'threat-auth-g1'}]
    generations={'locomotion':1}; fn=authority_guarded if arm=='baseline' else handoff_fenced
    active=fn(proposals,leases,generations,1)
    if active.get('selected',{}).get('locomotion',{}).get('proposal_id')!='threat-g1': raise RuntimeError(('active arbitration',active))
    seq=obs0['sequence']; submitted=[]
    def submit(pid,steps,semantic_proposal_id):
        nonlocal seq
        before=len(events)
        p.stdin.write(json.dumps({'op':'clock'})+'\n');p.stdin.flush();clock=wait(lambda r:r.get('event')=='clock')
        p.stdin.write(json.dumps({'op':'submit','id':pid,'expected_sequence':seq,'valid_until_ns':clock['runtime_ns']+5_000_000_000,'steps':steps})+'\n');p.stdin.flush()
        submitted.append({'program_id':pid,'semantic_proposal_id':semantic_proposal_id})
        accepted=wait(lambda r:r.get('event') in ('accepted','rejected') and (r.get('id')==pid or r.get('event')=='rejected'))
        if accepted.get('event')!='accepted': raise RuntimeError(('program rejected',pid,accepted))
        terminal=wait(lambda r:r.get('event')=='terminal' and r.get('id')==pid)
        new_obs=[r for r in events[before:] if r.get('event')=='observation' and r.get('sequence',0)>seq]
        if new_obs: seq=max(r['sequence'] for r in new_obs)
        return {'program_id':pid,'semantic_proposal_id':semantic_proposal_id,'accepted':accepted,'terminal':terminal,'post_sequence':seq}
    threat_exec=submit(case_id+'-threat',THREAT_STEPS,'threat-g1')
    lease_before=dict(leases[0]); leases[0]['active']=False; generations['locomotion']=2
    post=fn(proposals,leases,generations,2)
    stale_submit_count=0; stale_exec=None; fresh_exec=None; fresh_arbitration=None
    if arm=='baseline':
        chosen=post.get('selected',{}).get('locomotion',{})
        if chosen.get('proposal_id')!='deopt-g1': raise RuntimeError(('baseline stale not selected',post))
        stale_submit_count=1; stale_exec=submit(case_id+'-stale-deopt',DEOPT_STEPS,'deopt-g1')
    elif arm=='candidate':
        if 'locomotion' in post.get('selected',{}): raise RuntimeError(('candidate stale selected',post))
        if not any(d.get('proposal_id')=='deopt-g1' and d.get('reason')=='STALE_RESOURCE_GENERATION' for d in post.get('deferred',[])): raise RuntimeError(('candidate missing stale deferral',post))
        fresh=dict(proposals[1]); fresh.update(proposal_id='deopt-g2',generation=2,proposed_at=3)
        fresh_arbitration=fn(proposals+[fresh],leases,generations,2)
        if fresh_arbitration.get('selected',{}).get('locomotion',{}).get('proposal_id')!='deopt-g2': raise RuntimeError(('fresh deopt not selected',fresh_arbitration))
        fresh_exec=submit(case_id+'-fresh-deopt',DEOPT_STEPS,'deopt-g2')
    else: raise ValueError(arm)
    p.stdin.write(json.dumps({'op':'finish'})+'\n');p.stdin.flush();score=wait(lambda r:r.get('event')=='post_control_score');p.stdin.close();p.wait(timeout=15)
    stderr=p.stderr.read(); typed=[r for r in events if r.get('event')=='typed_observation']; obs=[r for r in events if r.get('event')=='observation']
    result={
      'schema':'map01-threat-deopt-real-handoff-case-v1','task':TASK,'id':case_id,'arm':arm,
      'runtime_bundle_sha256':RUNTIME_BUNDLE_SHA256,'fixture_seed':990619,
      'initial_sequence':obs0['sequence'],'active_arbitration':active,'post_handoff_arbitration':post,'fresh_arbitration':fresh_arbitration,
      'lease_before_handoff':lease_before,'generation_before_handoff':1,'generation_after_handoff':2,
      'threat_exec':threat_exec,'stale_exec':stale_exec,'fresh_exec':fresh_exec,'stale_submit_count':stale_submit_count,'submitted_programs':submitted,
      'final_sequence':max([r.get('sequence',0) for r in obs],default=obs0['sequence']),
      'final_frame_rgb_sha256':obs[-1].get('frame_rgb_sha256') if obs else None,
      'final_health':typed[-1].get('signals',{}).get('health',{}).get('value') if typed else None,
      'final_ammo':typed[-1].get('signals',{}).get('ammo',{}).get('value') if typed else None,
      'score':{k:score.get(k) for k in ('kill_count','death_count','map_exit','player_dead')},
      'stderr':stderr,
      'transport_ready':{'operations':ready.get('operations'),'bindings':ready.get('bindings')},
    }
    (out/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--arm',choices=['baseline','candidate'],required=True);ap.add_argument('--id',required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--runtime-root',type=Path,required=True);ap.add_argument('--python',type=Path,required=True);a=ap.parse_args()
    print(json.dumps(run(a.arm,a.id,a.out,a.runtime_root,a.python),indent=2,sort_keys=True))
if __name__=='__main__':main()

FORMAL_CASES = [
 {"id":"rigid_p140","family":"rigid","seed":76901,"shift":140,"task_shift":140},
 {"id":"rigid_p158","family":"rigid","seed":76902,"shift":158,"task_shift":158},
 {"id":"rigid_p165","family":"rigid","seed":76903,"shift":165,"task_shift":165},
 {"id":"rigid_p190","family":"rigid","seed":76904,"shift":190,"task_shift":190},
 {"id":"rigid_n175","family":"rigid","seed":76905,"shift":-175,"task_shift":-175},
 {"id":"parallax_a","family":"parallax","seed":76911,"bg_shift":80,"fg_shift":180,"task_shift":80},
 {"id":"parallax_b","family":"parallax","seed":76912,"bg_shift":-70,"fg_shift":-185,"task_shift":-70},
 {"id":"parallax_c","family":"parallax","seed":76913,"bg_shift":25,"fg_shift":170,"task_shift":25},
 {"id":"unrelated","family":"unrelated","seed_a":76921,"seed_b":76922,"task_shift":None},
 {"id":"low_texture","family":"low_texture","task_shift":None},
]

from __future__ import annotations
import numpy as np

STOP_GATE_PX = 34
OLD_LIMIT = 160
WIDE_LIMIT = 240
MIN_CORR = 0.20
MIN_MARGIN = 0.015


def gradient_x(img: np.ndarray) -> np.ndarray:
    a = img.astype(np.float64)
    if a.ndim == 3:
        a = 0.299*a[...,0] + 0.587*a[...,1] + 0.114*a[...,2]
    return np.diff(a, axis=1)


def _ncc(a: np.ndarray, b: np.ndarray) -> float | None:
    x = a.ravel().astype(np.float64)
    y = b.ravel().astype(np.float64)
    x = x - x.mean()
    y = y - y.mean()
    nx = np.linalg.norm(x)
    ny = np.linalg.norm(y)
    if nx < 1e-12 or ny < 1e-12:
        return None
    return float(np.dot(x, y) / (nx * ny))


def score_shift(ref: np.ndarray, cur: np.ndarray, shift: int) -> float | None:
    rg = gradient_x(ref)
    cg = gradient_x(cur)
    w = rg.shape[1]
    s = int(shift)
    if abs(s) >= w - 8:
        return None
    if s >= 0:
        a = rg[:, :w-s] if s else rg
        b = cg[:, s:] if s else cg
    else:
        k = -s
        a = rg[:, k:]
        b = cg[:, :w-k]
    if a.shape[1] < 16:
        return None
    return _ncc(a, b)


def estimate_shift(ref: np.ndarray, cur: np.ndarray, search_limit: int) -> dict:
    scores: list[tuple[float,int]] = []
    for s in range(-int(search_limit), int(search_limit)+1):
        c = score_shift(ref, cur, s)
        if c is not None and np.isfinite(c):
            scores.append((c, s))
    if not scores:
        return {"status":"UNKNOWN_FLAT", "shift_px":None, "corr":None, "margin":None, "goal":None}
    scores.sort(reverse=True)
    best_corr, best_shift = scores[0]
    second_corr = max((c for c,s in scores[1:] if abs(s-best_shift) > 2), default=-1.0)
    margin = float(best_corr-second_corr)
    if best_corr < MIN_CORR or margin < MIN_MARGIN:
        return {"status":"UNKNOWN_AMBIGUOUS", "shift_px":None, "corr":best_corr, "margin":margin, "goal":None,
                "raw_best_shift":best_shift}
    if abs(best_shift) == int(search_limit):
        return {"status":"UNKNOWN_BOUNDARY", "shift_px":best_shift, "corr":best_corr, "margin":margin, "goal":None}
    return {"status":"IDENTIFIED", "shift_px":best_shift, "corr":best_corr, "margin":margin,
            "goal":abs(best_shift) <= STOP_GATE_PX}


def texture(seed: int, h: int=140, w: int=320, smooth: int=1) -> np.ndarray:
    rng = np.random.default_rng(seed)
    x = rng.integers(0, 256, size=(h,w), dtype=np.uint8).astype(np.float64)
    # Add deterministic large structure so overlap NCC is stable.
    yy, xx = np.mgrid[0:h,0:w]
    x = 0.60*x + 45*np.sin(xx/11.0) + 35*np.cos(yy/9.0) + 25*np.sin((xx+yy)/17.0) + 80
    return np.clip(x,0,255).astype(np.uint8)


def shift_image(img: np.ndarray, dx: int, fill_seed: int) -> np.ndarray:
    h,w = img.shape
    rng = np.random.default_rng(fill_seed)
    out = rng.integers(0, 256, size=(h,w), dtype=np.uint8)
    if dx == 0:
        return img.copy()
    if dx > 0:
        if dx < w:
            out[:,dx:] = img[:,:w-dx]
    else:
        k = -dx
        if k < w:
            out[:,:w-k] = img[:,k:]
    return out


def rigid_pair(seed: int, dx: int) -> tuple[np.ndarray,np.ndarray]:
    ref = texture(seed)
    cur = shift_image(ref, dx, seed+10000)
    return ref,cur


def parallax_pair(seed: int, bg_shift: int, fg_shift: int) -> tuple[np.ndarray,np.ndarray]:
    h,w = 140,320
    bg = texture(seed, h, w)
    fg = texture(seed+1000, h, w)
    # Foreground deliberately dominates area and gradient energy.
    ref = bg.copy()
    ref[:108,:] = fg[:108,:]
    bg_cur = shift_image(bg, bg_shift, seed+20000)
    fg_cur = shift_image(fg, fg_shift, seed+30000)
    cur = bg_cur.copy()
    cur[:108,:] = fg_cur[:108,:]
    return ref,cur


def unrelated_pair(seed_a: int, seed_b: int) -> tuple[np.ndarray,np.ndarray]:
    return texture(seed_a), texture(seed_b)


def low_texture_pair() -> tuple[np.ndarray,np.ndarray]:
    return np.full((140,320), 127, dtype=np.uint8), np.full((140,320), 127, dtype=np.uint8)

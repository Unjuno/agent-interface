import unittest
from model import *

class Tests(unittest.TestCase):
 def test_excluded_rigid_sign(self):
  r,c=rigid_pair(88001,73); d=estimate_shift(r,c,160); self.assertEqual(d['status'],'IDENTIFIED'); self.assertEqual(d['shift_px'],73)
 def test_excluded_negative_sign(self):
  r,c=rigid_pair(88002,-61); d=estimate_shift(r,c,160); self.assertEqual(d['shift_px'],-61)
 def test_excluded_wide_recovers(self):
  r,c=rigid_pair(88003,181); d=estimate_shift(r,c,240); self.assertEqual(d['status'],'IDENTIFIED'); self.assertLessEqual(abs(d['shift_px']-181),1)
 def test_old_range_flags_beyond(self):
  r,c=rigid_pair(88004,181); d=estimate_shift(r,c,160); self.assertIn(d['status'],('UNKNOWN_BOUNDARY','UNKNOWN_AMBIGUOUS'))
 def test_parallax_dominant_foreground(self):
  r,c=parallax_pair(88005,70,184); d=estimate_shift(r,c,240); self.assertEqual(d['status'],'IDENTIFIED'); self.assertGreater(abs(d['shift_px']-70),20)
 def test_low_texture_unknown(self):
  r,c=low_texture_pair(); d=estimate_shift(r,c,240); self.assertTrue(d['status'].startswith('UNKNOWN'))
 def test_gate_constant(self):
  self.assertEqual(STOP_GATE_PX,34)

if __name__=='__main__': unittest.main()

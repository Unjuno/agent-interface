import json, pathlib
R=pathlib.Path(__file__).parent
result=json.loads((R/'result.json').read_text())
errors=[]
if result.get('decision')!='PASS_NCC_BOUNDARY_CAUSE_DISCRIMINATOR_SCOPED': errors.append('decision')
if result.get('formal_invocations')!=1: errors.append('formal_invocations')
if not all(result.get('gates',{}).values()): errors.append('gates')
if int((R/'formal_invocations.txt').read_text().strip())!=1: errors.append('counter')
if result['summary']['stop_gate_px']!=34: errors.append('stop_gate')
if errors:
 print('FAIL_VERIFY '+','.join(errors)); raise SystemExit(1)
print('PASS_VERIFY')

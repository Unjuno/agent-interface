from __future__ import annotations
import json, pathlib, hashlib
from model import estimate_shift, rigid_pair, parallax_pair, unrelated_pair, low_texture_pair, OLD_LIMIT, WIDE_LIMIT, STOP_GATE_PX
from cases import FORMAL_CASES

ROOT=pathlib.Path(__file__).parent
COUNT=ROOT/'formal_invocations.txt'
RESULT=ROOT/'result.json'
if RESULT.exists():
    raise SystemExit('formal result already exists')
count=int(COUNT.read_text().strip() or '0') if COUNT.exists() else 0
count += 1
COUNT.write_text(str(count)+'\n')

rows=[]
for case in FORMAL_CASES:
    fam=case['family']
    if fam=='rigid':
        ref,cur=rigid_pair(case['seed'],case['shift'])
    elif fam=='parallax':
        ref,cur=parallax_pair(case['seed'],case['bg_shift'],case['fg_shift'])
    elif fam=='unrelated':
        ref,cur=unrelated_pair(case['seed_a'],case['seed_b'])
    elif fam=='low_texture':
        ref,cur=low_texture_pair()
    else:
        raise ValueError(fam)
    bounded=estimate_shift(ref,cur,OLD_LIMIT)
    wide=estimate_shift(ref,cur,WIDE_LIMIT)
    row={**case,'bounded160':bounded,'diagnostic240':wide}
    rows.append(row)

rigids=[r for r in rows if r['family']=='rigid']
parallax=[r for r in rows if r['family']=='parallax']
controls=[r for r in rows if r['family'] in ('unrelated','low_texture')]
old_boundary=[r['id'] for r in rigids if abs(r['task_shift'])>OLD_LIMIT and r['bounded160']['status']=='UNKNOWN_BOUNDARY']
wide_rigid_bad=[]
for r in rigids:
    d=r['diagnostic240']
    if d['status']!='IDENTIFIED' or abs(d['shift_px']-r['task_shift'])>1:
        wide_rigid_bad.append(r['id'])
parallax_task_wrong=[]
for r in parallax:
    d=r['diagnostic240']
    if d['status']!='IDENTIFIED' or abs(d['shift_px']-r['task_shift'])>20:
        parallax_task_wrong.append(r['id'])
control_false=[]
for r in controls:
    d=r['diagnostic240']
    if d['status']=='IDENTIFIED' and d.get('goal') is True:
        control_false.append(r['id'])

gates={
 'bounded160_exposes_rigid_boundary': bool(old_boundary),
 'diagnostic240_recovers_all_rigid_within_1px': not wide_rigid_bad,
 'diagnostic240_not_general_under_parallax': bool(parallax_task_wrong),
 'controls_not_false_aligned': not control_false,
 'stop_gate_unchanged_34px': STOP_GATE_PX==34,
 'formal_invocations_one': count==1,
}
decision='PASS_NCC_BOUNDARY_CAUSE_DISCRIMINATOR_SCOPED' if all(gates.values()) else 'HOLD_OR_FAIL_NCC_BOUNDARY_CAUSE'
out={
 'task':'MAP01-NCC-BOUNDARY-CAUSE-20260917-005',
 'decision':decision,
 'formal_invocations':count,
 'gates':gates,
 'summary':{
   'old_boundary_rigid_cases':old_boundary,
   'wide_rigid_bad':wide_rigid_bad,
   'parallax_task_wrong_or_ambiguous':parallax_task_wrong,
   'control_false_accepts':control_false,
   'old_search_limit_px':OLD_LIMIT,
   'diagnostic_search_limit_px':WIDE_LIMIT,
   'stop_gate_px':STOP_GATE_PX,
 },
 'rows':rows,
}
RESULT.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
print(decision)
print(json.dumps(out['summary'],sort_keys=True))

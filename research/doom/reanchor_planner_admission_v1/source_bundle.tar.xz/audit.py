from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path


def canonical_bytes(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def digest(obj):
    return hashlib.sha256(canonical_bytes(obj)).hexdigest()

EXPECTED = {
    "matching_completed": ("FRESH_PLANNER_DECISION_ELIGIBLE", "matching_reanchor_receipt_completed", True),
    "capacity_deferred": ("TASK_DEFERRED", "deferred_upstream", False),
    "completed_stale_receipt": ("TASK_BLOCKED", "stale_reanchor_receipt", False),
    "receipt_grants_input_authority": ("TASK_BLOCKED", "reanchor_receipt_authority_violation", False),
    "deferred_with_output_usage": ("TASK_BLOCKED", "invalid_typed_outcome", False),
    "changed_receipt_old_digest": ("TASK_BLOCKED", "reanchor_receipt_content_mismatch", False),
}


def audit(data):
    errors = []
    if data.get("schema") != "reanchor-planner-admission-result-v1": errors.append("schema")
    if data.get("task") != "MAP01-REANCHOR-PLANNER-ADMISSION-20260917-001": errors.append("task")
    if data.get("dependency_semantic_grounding_sha256") != "337eed1ef5fc248ba121ad7c9769fda7e2f685bade1c82482542eab2b0674dcc": errors.append("dependency_sha")
    rows = data.get("cases")
    if type(rows) is not list or len(rows) != 6:
        errors.append("case_count")
        rows = []
    seen = set()
    for row in rows:
        name = row.get("case")
        if name in seen: errors.append(f"duplicate:{name}")
        seen.add(name)
        if name not in EXPECTED:
            errors.append(f"unexpected:{name}")
            continue
        actual_digest = digest(row.get("receipt"))
        if actual_digest != row.get("actual_receipt_sha256"):
            errors.append(f"receipt_digest:{name}")
        b = row.get("binding") or {}
        exp_status, exp_reason, exp_eligible = EXPECTED[name]
        if (b.get("status"), b.get("reason"), b.get("fresh_planner_decision_eligible")) != (exp_status, exp_reason, exp_eligible):
            errors.append(f"classification:{name}")
        if b.get("grants_input_authority") is not False or b.get("grants_semantic_authority") is not False:
            errors.append(f"authority:{name}")
        if b.get("ordinary_executor_admission_required") is not True:
            errors.append(f"executor_gate:{name}")
        if b.get("old_action_authority_reused") is not False:
            errors.append(f"old_authority:{name}")
        if name == "matching_completed":
            if b.get("planner_call_id") != "call-fixed-001": errors.append("matching_call")
            if b.get("grounding_reference") != {"action": "turn_right", "extent": "short"}: errors.append("matching_grounding")
        else:
            if "planner_call_id" in b or "grounding_reference" in b or "usage" in b:
                errors.append(f"blocked_leak:{name}")
    if seen != set(EXPECTED): errors.append("case_set")
    decision = "PASS_REANCHOR_PLANNER_ADMISSION_SCOPED" if not errors else "FAIL_INTEGRITY"
    return {"schema":"reanchor-planner-admission-audit-v1","decision":decision,"pass":not errors,"errors":errors}


def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--result",type=Path,required=True); ap.add_argument("--out",type=Path,required=True); a=ap.parse_args()
    data=json.loads(a.result.read_text()); out=audit(data); a.out.write_text(json.dumps(out,indent=2,sort_keys=True)+"\n"); print(json.dumps(out,indent=2,sort_keys=True))
if __name__=="__main__": main()

import copy, unittest
import audit, experiment

def result():
    return {
        'schema':'reanchor-planner-admission-result-v1',
        'task':'MAP01-REANCHOR-PLANNER-ADMISSION-20260917-001',
        'dependency_semantic_grounding_sha256':'337eed1ef5fc248ba121ad7c9769fda7e2f685bade1c82482542eab2b0674dcc',
        'canonical_reanchor_receipt_sha256':experiment.digest(experiment.canonical_receipt()),
        'cases':experiment.formal_matrix(),
    }

class AuditMutationTests(unittest.TestCase):
    def assertRejected(self, mutate):
        x=result(); mutate(x); self.assertFalse(audit.audit(x)['pass'])
    def test_matching_not_eligible(self):
        self.assertRejected(lambda x: x['cases'][0]['binding'].__setitem__('fresh_planner_decision_eligible',False))
    def test_authority_escalation(self):
        self.assertRejected(lambda x: x['cases'][0]['binding'].__setitem__('grants_input_authority',True))
    def test_executor_gate_removed(self):
        self.assertRejected(lambda x: x['cases'][0]['binding'].__setitem__('ordinary_executor_admission_required',False))
    def test_old_authority_reused(self):
        self.assertRejected(lambda x: x['cases'][0]['binding'].__setitem__('old_action_authority_reused',True))
    def test_receipt_digest_lie(self):
        self.assertRejected(lambda x: x['cases'][0].__setitem__('actual_receipt_sha256','0'*64))
    def test_blocked_output_leak(self):
        self.assertRejected(lambda x: x['cases'][2]['binding'].__setitem__('planner_call_id','leak'))
    def test_dependency_hash_changed(self):
        self.assertRejected(lambda x: x.__setitem__('dependency_semantic_grounding_sha256','0'*64))
    def test_case_removed(self):
        self.assertRejected(lambda x: x['cases'].pop())
    def test_stale_promoted(self):
        def m(x):
            b=x['cases'][2]['binding']; b['status']='FRESH_PLANNER_DECISION_ELIGIBLE'; b['reason']='matching_reanchor_receipt_completed'; b['fresh_planner_decision_eligible']=True
        self.assertRejected(m)

if __name__=='__main__': unittest.main()

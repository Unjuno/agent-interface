from __future__ import annotations
import argparse, copy, hashlib, json
from pathlib import Path

from semantic_grounding_admission_v1 import admit as base_admit

REANCHOR_SCHEMA = "recovery-reanchor-receipt-v1"
RESULT_SCHEMA = "reanchor-planner-admission-result-v1"
BINDING_SCHEMA = "reanchor-planner-admission-v1"


def canonical_bytes(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def digest(obj):
    return hashlib.sha256(canonical_bytes(obj)).hexdigest()


def validate_reanchor_receipt(receipt, expected_digest):
    if type(receipt) is not dict or receipt.get("schema") != REANCHOR_SCHEMA:
        return "INVALID_REANCHOR_RECEIPT"
    if type(receipt.get("sequence")) is not int or receipt["sequence"] <= 0:
        return "INVALID_REANCHOR_RECEIPT"
    frame = receipt.get("frame_rgb_sha256")
    if type(frame) is not str or len(frame) != 64 or any(c not in "0123456789abcdef" for c in frame):
        return "INVALID_REANCHOR_RECEIPT"
    pointer = receipt.get("pointer_binding")
    if type(pointer) is not dict or set(pointer) != {"surface_id", "binding_id"}:
        return "INVALID_REANCHOR_RECEIPT"
    if not all(type(pointer[k]) is str and pointer[k] for k in pointer):
        return "INVALID_REANCHOR_RECEIPT"
    if receipt.get("grants_input_authority") is not False:
        return "REANCHOR_RECEIPT_AUTHORITY_VIOLATION"
    if receipt.get("old_action_authority_discarded") is not True:
        return "REANCHOR_RECEIPT_OLD_AUTHORITY_NOT_DISCARDED"
    if digest(receipt) != expected_digest:
        return "REANCHOR_RECEIPT_CONTENT_MISMATCH"
    return None


def bind_planner_outcome(current_receipt, current_digest, outcome):
    receipt_error = validate_reanchor_receipt(current_receipt, current_digest)
    base = {
        "schema": BINDING_SCHEMA,
        "source_reanchor_receipt_sha256": current_digest,
        "grants_semantic_authority": False,
        "grants_input_authority": False,
        "ordinary_executor_admission_required": True,
        "fresh_planner_decision_eligible": False,
        "old_action_authority_reused": False,
    }
    if receipt_error:
        return {**base, "status": "TASK_BLOCKED", "reason": receipt_error.lower()}
    if type(outcome) is not dict:
        return {**base, "status": "TASK_BLOCKED", "reason": "invalid_typed_outcome"}
    if outcome.get("source_reanchor_receipt_sha256") != current_digest:
        return {**base, "status": "TASK_BLOCKED", "reason": "stale_reanchor_receipt"}
    try:
        admitted = base_admit(outcome)
    except (ValueError, TypeError):
        return {**base, "status": "TASK_BLOCKED", "reason": "invalid_typed_outcome"}
    if admitted["status"] == "TASK_MUTATION_ELIGIBLE":
        return {
            **base,
            "status": "FRESH_PLANNER_DECISION_ELIGIBLE",
            "reason": "matching_reanchor_receipt_completed",
            "fresh_planner_decision_eligible": True,
            "planner_call_id": admitted["model_call_id"],
            "grounding_reference": admitted["grounding_reference"],
            "usage": admitted["usage"],
        }
    if admitted["status"] == "TASK_DEFERRED":
        return {**base, "status": "TASK_DEFERRED", "reason": "deferred_upstream"}
    return {**base, "status": "TASK_BLOCKED", "reason": admitted["reason"]}


def canonical_receipt():
    return {
        "schema": REANCHOR_SCHEMA,
        "sequence": 21,
        "frame_rgb_sha256": "5c" * 32,
        "pointer_binding": {
            "surface_id": "map01-threat-contact-v2",
            "binding_id": "pointer-seq-21",
        },
        "grants_input_authority": False,
        "old_action_authority_discarded": True,
    }


def completed_outcome(source_digest):
    return {
        "schema": "semantic-grounding-invocation-outcome-v1",
        "status": "COMPLETED",
        "requested_model": "synthetic-fixed-planner",
        "requested_effort": "low",
        "grants_semantic_authority": False,
        "grants_input_authority": False,
        "source_reanchor_receipt_sha256": source_digest,
        "result": {
            "call_id": "call-fixed-001",
            "grounding": {"action": "turn_right", "extent": "short"},
        },
        "usage": {"input_tokens": 123, "output_tokens": 17},
    }


def deferred_outcome(source_digest):
    return {
        "schema": "semantic-grounding-invocation-outcome-v1",
        "status": "DEFERRED_UPSTREAM",
        "reason": "capacity_unavailable",
        "requested_model": "synthetic-fixed-planner",
        "requested_effort": "low",
        "grants_semantic_authority": False,
        "grants_input_authority": False,
        "source_reanchor_receipt_sha256": source_digest,
        "result": None,
        "usage": None,
    }


def run_case(name, receipt, expected_digest, outcome):
    result = bind_planner_outcome(receipt, expected_digest, outcome)
    return {
        "case": name,
        "receipt": receipt,
        "expected_receipt_sha256": expected_digest,
        "actual_receipt_sha256": digest(receipt),
        "outcome": outcome,
        "binding": result,
    }


def formal_matrix():
    r = canonical_receipt()
    d = digest(r)
    rows = []
    rows.append(run_case("matching_completed", copy.deepcopy(r), d, completed_outcome(d)))
    rows.append(run_case("capacity_deferred", copy.deepcopy(r), d, deferred_outcome(d)))

    stale = completed_outcome("0" * 64)
    rows.append(run_case("completed_stale_receipt", copy.deepcopy(r), d, stale))

    auth_receipt = copy.deepcopy(r)
    auth_receipt["grants_input_authority"] = True
    auth_digest = digest(auth_receipt)
    rows.append(run_case("receipt_grants_input_authority", auth_receipt, auth_digest, completed_outcome(auth_digest)))

    malformed = deferred_outcome(d)
    malformed["result"] = {"call_id": "should-not-exist", "grounding": {"action": "turn_left"}}
    malformed["usage"] = {"input_tokens": 1}
    rows.append(run_case("deferred_with_output_usage", copy.deepcopy(r), d, malformed))

    changed = copy.deepcopy(r)
    changed["pointer_binding"]["binding_id"] = "pointer-seq-21-mutated"
    rows.append(run_case("changed_receipt_old_digest", changed, d, completed_outcome(d)))
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    rows = formal_matrix()
    result = {
        "schema": RESULT_SCHEMA,
        "task": "MAP01-REANCHOR-PLANNER-ADMISSION-20260917-001",
        "dependency_semantic_grounding_sha256": "337eed1ef5fc248ba121ad7c9769fda7e2f685bade1c82482542eab2b0674dcc",
        "canonical_reanchor_receipt_sha256": digest(canonical_receipt()),
        "cases": rows,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))

if __name__ == "__main__":
    main()

import copy, unittest
import experiment

class BindingTests(unittest.TestCase):
    def setUp(self):
        self.r=experiment.canonical_receipt(); self.d=experiment.digest(self.r)
    def test_matching_completion(self):
        x=experiment.bind_planner_outcome(self.r,self.d,experiment.completed_outcome(self.d))
        self.assertEqual(x['status'],'FRESH_PLANNER_DECISION_ELIGIBLE'); self.assertTrue(x['fresh_planner_decision_eligible']); self.assertFalse(x['grants_input_authority'])
    def test_capacity_defers(self):
        x=experiment.bind_planner_outcome(self.r,self.d,experiment.deferred_outcome(self.d)); self.assertEqual(x['status'],'TASK_DEFERRED'); self.assertFalse(x['fresh_planner_decision_eligible'])
    def test_stale_digest_blocks(self):
        x=experiment.bind_planner_outcome(self.r,self.d,experiment.completed_outcome('0'*64)); self.assertEqual(x['reason'],'stale_reanchor_receipt')
    def test_authority_receipt_blocks(self):
        r=copy.deepcopy(self.r); r['grants_input_authority']=True; d=experiment.digest(r); x=experiment.bind_planner_outcome(r,d,experiment.completed_outcome(d)); self.assertEqual(x['reason'],'reanchor_receipt_authority_violation')
    def test_changed_content_old_digest_blocks(self):
        r=copy.deepcopy(self.r); r['pointer_binding']['binding_id']='changed'; x=experiment.bind_planner_outcome(r,self.d,experiment.completed_outcome(self.d)); self.assertEqual(x['reason'],'reanchor_receipt_content_mismatch')
    def test_deferred_output_usage_blocks(self):
        o=experiment.deferred_outcome(self.d); o['result']={'call_id':'x','grounding':{}}; o['usage']={'input_tokens':1}; x=experiment.bind_planner_outcome(self.r,self.d,o); self.assertEqual(x['reason'],'invalid_typed_outcome')
    def test_old_authority_never_reused(self):
        for row in experiment.formal_matrix(): self.assertFalse(row['binding']['old_action_authority_reused'])

if __name__=='__main__': unittest.main()

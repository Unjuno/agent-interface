from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
import numpy as np
from PIL import Image

THRESHOLD = .015
RECEIPT_SCHEMA = 'recovery-reanchor-receipt-v1'


def rgb_sha(path):
    with Image.open(path) as im:
        return hashlib.sha256(im.convert('RGB').tobytes()).hexdigest()


def mae(a, b):
    with Image.open(a) as ia, Image.open(b) as ib:
        aa = np.asarray(ia.convert('RGB'), dtype=np.float32)
        bb = np.asarray(ib.convert('RGB'), dtype=np.float32)
    return float(np.abs(aa - bb).mean() / 255.0)


def canonical_sha256(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def good_release(row):
    return bool(row) and row.get('verified') is True and row.get('keys_down') == [] and row.get('buttons_down') == []

def benign_stderr(text):
    if text == '': return True
    lines=[x for x in text.splitlines() if x.strip()]
    if len(lines) != 3: return False
    return (
        'pw.conf' in lines[0] and "can't load config client.conf: No such file or directory" in lines[0] and
        'pw.conf' in lines[1] and "can't load config client.conf: No such file or directory" in lines[1] and
        lines[2].endswith('[ALSOFT] (EE) Failed to create PipeWire event context (errno: 2)')
    )


def audit_case(d):
    r = json.loads((d / 'result.json').read_text())
    errors = []
    m = mae(r['source_image'], r['post_image'])
    if abs(m - r['viewport_normalized_mae']) > 1e-9: errors.append('mae')
    if m <= THRESHOLD or r['old_action_guard'] != 'REJECT_CONTEXT_CHANGED': errors.append('old_guard')
    if r['baseline_validity_status'] != 'VALID_CURRENT': errors.append('baseline')
    if rgb_sha(r['source_image']) != r['source_frame_rgb_sha256']: errors.append('source_hash')
    if rgb_sha(r['post_image']) != r['post_frame_rgb_sha256']: errors.append('post_hash')
    if rgb_sha(r['new_source_image']) != r['new_source_frame_rgb_sha256']: errors.append('new_source_hash')
    if r['new_source_exact'] is not True or r['new_source_grants_input_authority'] is not False: errors.append('new_source_authority')
    if not good_release(r['recovery_release']) or r['recovery_terminal_status'] != 'completed': errors.append('recovery_release')
    if r['score'] != {'kill_count': 0, 'death_count': 0, 'map_exit': False, 'player_dead': False}: errors.append('score')
    if any(r[k] != 97 for k in ('source_health', 'post_health', 'new_source_health')): errors.append('health')
    if any(r[k] != 48 for k in ('source_ammo', 'post_ammo', 'new_source_ammo')): errors.append('ammo')
    stderr_text=(d/'stderr.txt').read_text() if (d/'stderr.txt').exists() else ''
    if not benign_stderr(stderr_text): errors.append('unexpected_stderr')
    policy = r['policy']
    if policy == 'reanchor_receipt':
        rec = r.get('reanchor_receipt')
        if type(rec) is not dict or rec.get('schema') != RECEIPT_SCHEMA: errors.append('receipt_schema')
        else:
            hashed = dict(rec); claimed = hashed.pop('receipt_sha256', None)
            if claimed != canonical_sha256(hashed): errors.append('receipt_digest')
            expected = {
                'source_sequence': r['post_sequence'],
                'capture_ns': r['post_capture_ns'],
                'frame_rgb_sha256': r['post_frame_rgb_sha256'],
                'pointer_binding': r['post_pointer_binding'],
                'grants_input_authority': False,
                'old_action_authority': 'discarded',
            }
            for key, value in expected.items():
                if rec.get(key) != value: errors.append('receipt_' + key)
        if r['extra_observation_programs'] != 0: errors.append('candidate_extra_observe')
        if r['new_source_sequence'] != r['post_sequence']: errors.append('candidate_sequence')
        if r['new_source_frame_rgb_sha256'] != r['post_frame_rgb_sha256']: errors.append('candidate_frame')
        if r['new_source_pointer_binding'] != r['post_pointer_binding']: errors.append('candidate_binding')
        if r.get('recapture') is not None: errors.append('candidate_recapture_present')
    elif policy == 'recapture':
        if r.get('reanchor_receipt') is not None: errors.append('baseline_receipt_present')
        if r['extra_observation_programs'] != 1: errors.append('baseline_observe_count')
        if r['new_source_sequence'] <= r['post_sequence']: errors.append('baseline_sequence')
        recap = r.get('recapture')
        if type(recap) is not dict or recap.get('terminal_status') != 'completed' or not good_release(recap.get('release')):
            errors.append('baseline_recapture_terminal')
    else:
        errors.append('policy')
    return {
        'id': r['id'], 'pair': r['pair'], 'policy': policy, 'pass': not errors,
        'errors': errors, 'mae': m, 'handoff_ready_ms': r['handoff_ready_ms'],
        'post_sequence': r['post_sequence'], 'new_source_sequence': r['new_source_sequence'],
    }


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--evidence', type=Path, required=True); ap.add_argument('--out', type=Path, required=True); a = ap.parse_args()
    rows = [audit_case(p) for p in sorted(a.evidence.iterdir()) if p.is_dir() and (p / 'result.json').exists()]
    by = {}
    for row in rows: by.setdefault(row['pair'], {})[row['policy']] = row
    pairs = []
    for pair, arms in sorted(by.items()):
        base = arms.get('recapture'); cand = arms.get('reanchor_receipt')
        pairs.append({'pair': pair, 'complete': bool(base and cand), 'baseline_later_sequence': bool(base and base['new_source_sequence'] > base['post_sequence']), 'candidate_same_sequence': bool(cand and cand['new_source_sequence'] == cand['post_sequence'])})
    ok = len(rows) == 6 and len(pairs) == 3 and all(r['pass'] for r in rows) and all(p['complete'] and p['baseline_later_sequence'] and p['candidate_same_sequence'] for p in pairs)
    decision = 'PASS_REANCHOR_RECEIPT_SCOPED' if ok else 'HOLD_REANCHOR_RECEIPT'
    out = {'schema': 'recovery-reanchor-receipt-audit-v1', 'cases': rows, 'pairs': pairs, 'decision': decision, 'pass': ok}
    a.out.write_text(json.dumps(out, indent=2, sort_keys=True) + '\n')
    print(json.dumps(out, indent=2))

if __name__ == '__main__': main()

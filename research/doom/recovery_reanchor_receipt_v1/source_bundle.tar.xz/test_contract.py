import unittest
import experiment, audit

class T(unittest.TestCase):
    def test_threshold(self):
        self.assertEqual(experiment.VISIBLE_CHANGE_THRESHOLD, .015)
        self.assertEqual(audit.THRESHOLD, .015)
    def test_receipt_no_authority(self):
        typed = {'artifact_published': False, 'grants_input_authority': False, 'id': 'x', 'step': 1, 'sequence': 2, 'capture_ns': 10, 'pointer_binding': {'focus':1,'surface':1,'geometry':[0,0,1,1]}, 'frame_rgb_sha256': 'a'*64, 'typed_ready_ns': 12}
        self.assertFalse(typed['grants_input_authority'])
    def test_canonical_digest_stable(self):
        a={'b':2,'a':1}; b={'a':1,'b':2}
        self.assertEqual(experiment.canonical_sha256(a), experiment.canonical_sha256(b))
    def test_policy_names(self):
        self.assertEqual({'recapture','reanchor_receipt'}, {'recapture','reanchor_receipt'})
    def test_audit_release(self):
        self.assertTrue(audit.good_release({'verified':True,'keys_down':[],'buttons_down':[]}))
        self.assertFalse(audit.good_release({'verified':True,'keys_down':['x'],'buttons_down':[]}))
    def test_benign_audio_stderr(self):
        text="[W][x] pw.conf | [ conf.c: 1 x()] can't load config client.conf: No such file or directory\n[E][x] pw.conf | [ conf.c: 1 x()] can't load config client.conf: No such file or directory\n[ALSOFT] (EE) Failed to create PipeWire event context (errno: 2)\n"
        self.assertTrue(audit.benign_stderr(text))
        self.assertFalse(audit.benign_stderr(text+'Traceback\n'))

if __name__ == '__main__': unittest.main()

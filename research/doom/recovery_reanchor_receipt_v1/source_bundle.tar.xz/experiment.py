from __future__ import annotations
import argparse, hashlib, json, os, queue, subprocess, sys, threading, time
from pathlib import Path
import numpy as np
from PIL import Image

VISIBLE_CHANGE_THRESHOLD = 0.015
RECEIPT_SCHEMA = 'recovery-reanchor-receipt-v1'


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def canonical_sha256(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def normalized_mae(a, b):
    with Image.open(a) as ia, Image.open(b) as ib:
        aa = np.asarray(ia.convert('RGB'), dtype=np.float32)
        bb = np.asarray(ib.convert('RGB'), dtype=np.float32)
    if aa.shape != bb.shape:
        raise ValueError('shape mismatch')
    return float(np.abs(aa - bb).mean() / 255.0)


def wait_from(q, p, pred, timeout=35):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        try:
            row = q.get(timeout=.25)
        except queue.Empty:
            if p.poll() is not None:
                raise RuntimeError('session died: ' + p.stderr.read())
            continue
        if pred(row):
            return row
    raise TimeoutError('expected event')


def exact_pair(events, sequence):
    typed = [r for r in events if r.get('event') == 'typed_observation' and r.get('sequence') == sequence]
    full = [r for r in events if r.get('event') == 'observation' and r.get('sequence') == sequence]
    if not typed or not full:
        raise RuntimeError(f'missing exact pair sequence={sequence}')
    return typed[-1], full[-1]


def make_reanchor_receipt(typed, full, ready_ns):
    if typed.get('artifact_published') is not False or typed.get('grants_input_authority') is not False:
        raise ValueError('typed observation authority invariant')
    if full.get('exact') is not True:
        raise ValueError('full exact observation required')
    for key in ('id', 'step', 'sequence', 'capture_ns', 'pointer_binding'):
        if typed.get(key) != full.get(key):
            raise ValueError(f'epoch mismatch: {key}')
    with Image.open(full['image']) as im:
        rgb_sha = hashlib.sha256(im.convert('RGB').tobytes()).hexdigest()
    if rgb_sha != typed.get('frame_rgb_sha256'):
        raise ValueError('artifact hash mismatch')
    receipt = {
        'schema': RECEIPT_SCHEMA,
        'source_sequence': typed['sequence'],
        'capture_ns': typed['capture_ns'],
        'frame_rgb_sha256': typed['frame_rgb_sha256'],
        'pointer_binding': typed['pointer_binding'],
        'exact_observation_image': full['image'],
        'exact_observation_emit_ns': full['emit_ns'],
        'typed_ready_ns': typed['typed_ready_ns'],
        'receipt_ready_ns': ready_ns,
        'grants_input_authority': False,
        'old_action_authority': 'discarded',
    }
    receipt['receipt_sha256'] = canonical_sha256(receipt)
    return receipt


def run_case(case, out, runtime_root, python):
    out.mkdir(parents=True, exist_ok=False)
    doom = runtime_root / 'research/doom'
    live = runtime_root / 'research/live_control'
    fixture = doom / 'fixtures/map01-threat-contact-v2/fixture.json'
    sys.path[:0] = [str(doom), str(live)]
    from doom_action_validity_contract_v1 import build_contract
    from doom_typed_observation_v1 import build_action_snapshot
    from action_validity_admission_v1 import evaluate_action_validity

    env = os.environ.copy()
    env['PYTHONPATH'] = f'{doom}:{live}'
    p = subprocess.Popen([
        str(python), str(doom / 'session_map01_v12.py'), '--out', str(out / 'runtime'),
        '--seed', '990619', '--timeout-seconds', '60', '--skill', '1',
        '--load-fixture-manifest', str(fixture),
    ], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
       text=True, bufsize=1, env=env)
    q = queue.Queue()
    events = []

    def reader():
        for line in p.stdout:
            try:
                row = json.loads(line)
            except Exception:
                continue
            events.append(row)
            q.put(row)

    threading.Thread(target=reader, daemon=True).start()
    wait = lambda pred, timeout=35: wait_from(q, p, pred, timeout)

    try:
        wait(lambda r: r.get('event') == 'ready')
        source_t = wait(lambda r: r.get('event') == 'typed_observation')
        source_o = wait(lambda r: r.get('event') == 'observation' and r.get('sequence') == source_t.get('sequence'))
        p.stdin.write(json.dumps({'op': 'clock'}) + '\n'); p.stdin.flush()
        clock = wait(lambda r: r.get('event') == 'clock')

        recovery_steps = ([{'op': 'hold', 'keys': ['d'], 'duration_ms': 50}, {'op': 'observe'}] * 5) + [
            {'op': 'coast', 'duration_ms': 350, 'sample_ms': 50}, {'op': 'observe'}]
        ident = case['id'] + '-recovery'
        p.stdin.write(json.dumps({
            'op': 'submit', 'id': ident, 'expected_sequence': source_o['sequence'],
            'valid_until_ns': clock['runtime_ns'] + 5_000_000_000, 'steps': recovery_steps,
        }) + '\n'); p.stdin.flush()
        accepted = wait(lambda r: r.get('event') in ('accepted', 'rejected') and (r.get('id') == ident or r.get('event') == 'rejected'))
        if accepted.get('event') != 'accepted':
            raise RuntimeError(('unexpected rejection', accepted))
        terminal = wait(lambda r: r.get('event') == 'terminal' and r.get('id') == ident)
        if terminal.get('status') != 'completed':
            raise RuntimeError(('unexpected recovery terminal', terminal))

        post_rows = [r for r in events if r.get('event') == 'typed_observation' and r.get('sequence', 0) > source_t['sequence']]
        if not post_rows:
            raise RuntimeError('no post-recovery typed observation')
        post_t = post_rows[-1]
        post_t, post_o = exact_pair(events, post_t['sequence'])

        action = [{'action': 'turn_right', 'extent': 'short'}]
        authored = {'critical_health_minimum': 50, 'maximum_health_loss': 8, 'minimum_ammo': 0, 'max_current_age_ms': 700}
        contract = build_contract(action, authored, source_t['signals']['health'], source_t['signals']['ammo'])
        snap = build_action_snapshot(post_t, contract)
        guard_decided_ns = time.perf_counter_ns()
        validity = evaluate_action_validity(action, contract, snap, guard_decided_ns)
        frame_mae = normalized_mae(source_o['image'], post_o['image'])
        guard = 'ADMIT' if frame_mae <= VISIBLE_CHANGE_THRESHOLD else 'REJECT_CONTEXT_CHANGED'
        if guard != 'REJECT_CONTEXT_CHANGED':
            raise RuntimeError(('construction/formal requires recovery rejection', frame_mae, guard))

        policy = case['policy']
        extra_observation_programs = 0
        recapture = None
        receipt = None
        handoff_started_ns = time.perf_counter_ns()
        if policy == 'reanchor_receipt':
            receipt_ready_ns = time.perf_counter_ns()
            receipt = make_reanchor_receipt(post_t, post_o, receipt_ready_ns)
            new_source_t, new_source_o = post_t, post_o
            new_source_ready_ns = receipt_ready_ns
        elif policy == 'recapture':
            p.stdin.write(json.dumps({'op': 'clock'}) + '\n'); p.stdin.flush()
            refresh_clock = wait(lambda r: r.get('event') == 'clock')
            recap_id = case['id'] + '-recapture'
            before_seq = post_t['sequence']
            p.stdin.write(json.dumps({
                'op': 'submit', 'id': recap_id, 'expected_sequence': before_seq,
                'valid_until_ns': refresh_clock['runtime_ns'] + 5_000_000_000,
                'steps': [{'op': 'observe'}],
            }) + '\n'); p.stdin.flush()
            recap_accepted = wait(lambda r: r.get('event') in ('accepted', 'rejected') and (r.get('id') == recap_id or r.get('event') == 'rejected'))
            if recap_accepted.get('event') != 'accepted':
                raise RuntimeError(('recapture rejected', recap_accepted))
            recap_terminal = wait(lambda r: r.get('event') == 'terminal' and r.get('id') == recap_id)
            if recap_terminal.get('status') != 'completed':
                raise RuntimeError(('recapture terminal', recap_terminal))
            later = [r for r in events if r.get('event') == 'typed_observation' and r.get('sequence', 0) > before_seq]
            if not later:
                raise RuntimeError('recapture produced no later typed observation')
            new_source_t = later[-1]
            new_source_t, new_source_o = exact_pair(events, new_source_t['sequence'])
            if new_source_t['sequence'] <= before_seq:
                raise RuntimeError('recapture sequence did not advance')
            extra_observation_programs = 1
            new_source_ready_ns = time.perf_counter_ns()
            recapture = {
                'id': recap_id,
                'accepted_program_sha256': recap_accepted.get('program_sha256'),
                'terminal_status': recap_terminal.get('status'),
                'release': recap_terminal.get('release'),
            }
        else:
            raise ValueError(policy)

        p.stdin.write(json.dumps({'op': 'finish'}) + '\n'); p.stdin.flush()
        score = wait(lambda r: r.get('event') == 'post_control_score')
        p.stdin.close(); p.wait(timeout=15)
        stderr = p.stderr.read()
        (out / 'stderr.txt').write_text(stderr)

        result = {
            **case,
            'schema': 'recovery-reanchor-receipt-case-v1',
            'source_sequence': source_t['sequence'],
            'source_frame_rgb_sha256': source_t['frame_rgb_sha256'],
            'source_pointer_binding': source_t['pointer_binding'],
            'post_sequence': post_t['sequence'],
            'post_capture_ns': post_t['capture_ns'],
            'post_frame_rgb_sha256': post_t['frame_rgb_sha256'],
            'post_pointer_binding': post_t['pointer_binding'],
            'post_image': post_o['image'],
            'source_image': source_o['image'],
            'viewport_normalized_mae': frame_mae,
            'visual_context_threshold': VISIBLE_CHANGE_THRESHOLD,
            'old_action_guard': guard,
            'baseline_validity_status': validity['status'],
            'baseline_validity_reason': validity['reason'],
            'guard_decided_ns': guard_decided_ns,
            'handoff_started_ns': handoff_started_ns,
            'new_source_ready_ns': new_source_ready_ns,
            'handoff_ready_ms': (new_source_ready_ns - handoff_started_ns) / 1e6,
            'new_source_sequence': new_source_t['sequence'],
            'new_source_capture_ns': new_source_t['capture_ns'],
            'new_source_frame_rgb_sha256': new_source_t['frame_rgb_sha256'],
            'new_source_pointer_binding': new_source_t['pointer_binding'],
            'new_source_image': new_source_o['image'],
            'new_source_exact': new_source_o.get('exact'),
            'new_source_grants_input_authority': new_source_t.get('grants_input_authority'),
            'extra_observation_programs': extra_observation_programs,
            'reanchor_receipt': receipt,
            'recapture': recapture,
            'source_health': source_t['signals']['health']['value'],
            'post_health': post_t['signals']['health']['value'],
            'new_source_health': new_source_t['signals']['health']['value'],
            'source_ammo': source_t['signals']['ammo']['value'],
            'post_ammo': post_t['signals']['ammo']['value'],
            'new_source_ammo': new_source_t['signals']['ammo']['value'],
            'recovery_terminal_status': terminal.get('status'),
            'recovery_release': terminal.get('release'),
            'score': {k: score.get(k) for k in ('kill_count', 'death_count', 'map_exit', 'player_dead')},
            'event_count': len(events),
            'runtime_sources_sha256': sha256(out / 'runtime' / 'sources.json'),
            'stderr_bytes': len(stderr.encode()),
        }
        (out / 'result.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
        return result
    finally:
        if p.poll() is None:
            try:
                p.stdin.close()
            except Exception:
                pass
            try:
                p.wait(timeout=10)
            except subprocess.TimeoutExpired:
                p.terminate(); p.wait(timeout=5)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--plan', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--runtime-root', type=Path, required=True)
    ap.add_argument('--python', type=Path, required=True)
    a = ap.parse_args()
    plan = json.loads(a.plan.read_text())
    a.out.mkdir(parents=True, exist_ok=False)
    results = [run_case(case, a.out / case['id'], a.runtime_root, a.python) for case in plan['cases']]
    by = {}
    for r in results:
        by.setdefault(r['pair'], {})[r['policy']] = r
    pairs = []
    for pair, arms in sorted(by.items()):
        recap = arms['recapture']; rea = arms['reanchor_receipt']
        pairs.append({
            'pair': pair,
            'recapture_handoff_ready_ms': recap['handoff_ready_ms'],
            'reanchor_handoff_ready_ms': rea['handoff_ready_ms'],
            'recapture_new_sequence_delta': recap['new_source_sequence'] - recap['post_sequence'],
            'reanchor_new_sequence_delta': rea['new_source_sequence'] - rea['post_sequence'],
        })
    summary = {'schema': 'recovery-reanchor-receipt-summary-v1', 'cases': results, 'pairs': pairs}
    (a.out / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps(summary, indent=2))

if __name__ == '__main__':
    main()

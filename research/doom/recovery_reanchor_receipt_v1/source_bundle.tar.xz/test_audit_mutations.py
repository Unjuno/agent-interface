import copy, json, shutil, tempfile, unittest
from pathlib import Path
import audit

ROOT=Path('/mnt/data/map615_construct')

class T(unittest.TestCase):
    def setUp(self):
        self.src=ROOT/'c00-reanchor'
        self.base=json.loads((self.src/'result.json').read_text())
    def check_rejected(self, mutate):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td); shutil.copy2(self.src/'stderr.txt', d/'stderr.txt')
            # Image paths remain absolute in retained result and are intentionally read-only.
            row=copy.deepcopy(self.base); mutate(row)
            (d/'result.json').write_text(json.dumps(row))
            self.assertFalse(audit.audit_case(d)['pass'])
    def test_authority_mutation(self): self.check_rejected(lambda r:r['reanchor_receipt'].__setitem__('grants_input_authority',True))
    def test_sequence_mutation(self): self.check_rejected(lambda r:r['reanchor_receipt'].__setitem__('source_sequence',r['post_sequence']+1))
    def test_extra_observe_mutation(self): self.check_rejected(lambda r:r.__setitem__('extra_observation_programs',1))
    def test_guard_mutation(self): self.check_rejected(lambda r:r.__setitem__('old_action_guard','ADMIT'))
    def test_health_mutation(self): self.check_rejected(lambda r:r.__setitem__('post_health',96))
    def test_release_mutation(self): self.check_rejected(lambda r:r['recovery_release'].__setitem__('keys_down',['d']))

if __name__=='__main__': unittest.main()

from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from model import make_texture, shift_horizontal, apply_nuisance, raw_mae, raw_mae_goal, bounded_ncc_shift, GOAL_SHIFT_PX
from cases import CASES

ROOT = Path(__file__).resolve().parent


def build_case(case):
    if case.get("low_texture"):
        ref = np.full((96,160,3), 128, dtype=np.uint8)
        cur = ref.copy()
        return ref, cur
    ref = make_texture(case["seed"])
    if case["shift"] is None:
        cur = make_texture(case["unrelated_seed"])
    else:
        cur = shift_horizontal(ref, case["shift"])
    cur = apply_nuisance(cur, **case.get("nuisance", {}))
    return ref, cur


def main():
    count_path = ROOT / "formal_invocations.txt"
    prior = int(count_path.read_text().strip() or "0") if count_path.exists() else 0
    if prior != 0:
        raise SystemExit(f"formal already invoked: {prior}")
    count_path.write_text("1\n")

    rows = []
    identifiable_errors = []
    raw_false_mismatches = []
    control_false_accepts = []
    for case in CASES:
        ref, cur = build_case(case)
        mae = raw_mae(ref, cur)
        raw_goal = raw_mae_goal(ref, cur)
        geom = bounded_ncc_shift(ref, cur)
        authored_goal = None if case["shift"] is None else abs(case["shift"]) <= GOAL_SHIFT_PX
        row = {
            "id": case["id"],
            "authored_shift_px": case["shift"],
            "authored_goal": authored_goal,
            "raw_mae": mae,
            "raw_goal": raw_goal,
            "geom": {
                "status": geom.status,
                "shift_px": geom.shift_px,
                "best_ncc": geom.best_ncc,
                "margin": geom.margin,
                "goal": geom.goal,
            },
        }
        if case["shift"] is not None:
            if geom.status != "IDENTIFIED" or abs(geom.shift_px - case["shift"]) > 1:
                identifiable_errors.append(case["id"])
            if authored_goal and not raw_goal and geom.status == "IDENTIFIED" and geom.goal is True:
                raw_false_mismatches.append(case["id"])
        else:
            if geom.status == "IDENTIFIED" and geom.goal is True:
                control_false_accepts.append(case["id"])
        rows.append(row)

    identifiable = [r for r in rows if r["authored_shift_px"] is not None]
    goal_mismatches = [r["id"] for r in identifiable if r["geom"]["status"] != "IDENTIFIED" or r["geom"]["goal"] != r["authored_goal"]]
    gates = {
        "raw_mae_false_mismatch_exposed": len(raw_false_mismatches) >= 1,
        "candidate_shift_within_1px_all_identifiable": len(identifiable_errors) == 0,
        "candidate_goal_disposition_exact": len(goal_mismatches) == 0,
        "unrelated_not_false_aligned": "unrelated_control" not in control_false_accepts,
        "low_texture_not_false_aligned": "low_texture_control" not in control_false_accepts,
        "formal_reruns_zero": prior == 0,
    }
    if control_false_accepts or identifiable_errors or goal_mismatches:
        decision = "FAIL_GEOMETRIC_CORRESPONDENCE"
    elif not raw_false_mismatches:
        decision = "HOLD_NO_PROXY_DISCRIMINATOR"
    elif all(gates.values()):
        decision = "PASS_GEOMETRIC_IMAGE_CORRESPONDENCE_SCOPED"
    else:
        decision = "FAIL_GEOMETRIC_CORRESPONDENCE"

    result = {
        "task": "MAP01-GEOMETRIC-IMAGE-CORRESPONDENCE-20260917-001",
        "decision": decision,
        "formal_reruns": 0,
        "gates": gates,
        "summary": {
            "raw_false_mismatch_cases": raw_false_mismatches,
            "identifiable_shift_errors": identifiable_errors,
            "goal_mismatches": goal_mismatches,
            "control_false_accepts": control_false_accepts,
        },
        "rows": rows,
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"decision": decision, "gates": gates, "summary": result["summary"]}, sort_keys=True))

if __name__ == "__main__":
    main()

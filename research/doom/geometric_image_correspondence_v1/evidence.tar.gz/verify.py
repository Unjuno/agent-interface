from __future__ import annotations
import hashlib, json
from pathlib import Path
ROOT = Path(__file__).resolve().parent
EXPECTED = "PASS_GEOMETRIC_IMAGE_CORRESPONDENCE_SCOPED"

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    result = json.loads((ROOT/"result.json").read_text())
    freeze = json.loads((ROOT/"freeze.json").read_text())
    errors=[]
    if result.get("decision") != EXPECTED:
        errors.append(f"decision={result.get('decision')}")
    if not all(result.get("gates",{}).values()):
        errors.append("gate_false")
    if result.get("formal_reruns") != 0:
        errors.append("formal_reruns")
    for name, expected in freeze["source_sha256"].items():
        got=sha(ROOT/name)
        if got != expected:
            errors.append(f"sha:{name}")
    status = "PASS_VERIFY" if not errors else "FAIL_VERIFY"
    out={"status":status,"errors":errors}
    (ROOT/"verify_result.json").write_text(json.dumps(out,indent=2,sort_keys=True)+"\n")
    print(status)
    if errors:
        raise SystemExit(1)
if __name__ == '__main__': main()

import unittest
import numpy as np
from model import (
    make_texture, shift_horizontal, apply_nuisance, bounded_ncc_shift,
    raw_mae, raw_mae_goal, Correspondence
)

class TestMechanics(unittest.TestCase):
    def test_shift_sign_excluded_seed(self):
        ref = make_texture(991)
        cur = shift_horizontal(ref, 6)
        got = bounded_ncc_shift(ref, cur)
        self.assertEqual(got.status, "IDENTIFIED")
        self.assertEqual(got.shift_px, 6)

    def test_negative_shift_excluded_seed(self):
        ref = make_texture(992)
        cur = shift_horizontal(ref, -8)
        got = bounded_ncc_shift(ref, cur)
        self.assertEqual(got.shift_px, -8)

    def test_brightness_invariance_excluded_seed(self):
        ref = make_texture(993)
        cur = apply_nuisance(ref, gain=1.07, offset=10)
        got = bounded_ncc_shift(ref, cur)
        self.assertEqual(got.shift_px, 0)
        self.assertTrue(got.goal)
        self.assertGreater(raw_mae(ref, cur), 0.035)

    def test_low_texture_unknown(self):
        ref = np.full((96,160,3), 128, dtype=np.uint8)
        cur = ref.copy()
        got = bounded_ncc_shift(ref, cur)
        self.assertEqual(got.status, "UNKNOWN")

    def test_raw_mae_identity(self):
        ref = make_texture(994)
        self.assertAlmostEqual(raw_mae(ref, ref), 0.0)
        self.assertTrue(raw_mae_goal(ref, ref))

    def test_shape_mismatch_rejected(self):
        a = np.zeros((4,4,3), dtype=np.uint8)
        b = np.zeros((4,5,3), dtype=np.uint8)
        with self.assertRaises(ValueError):
            bounded_ncc_shift(a,b)

    def test_nuisance_deterministic(self):
        ref = make_texture(995)
        a = apply_nuisance(ref, noise_seed=8, noise_fraction=.02, noise_amplitude=5)
        b = apply_nuisance(ref, noise_seed=8, noise_fraction=.02, noise_amplitude=5)
        self.assertTrue(np.array_equal(a,b))

if __name__ == '__main__':
    unittest.main()

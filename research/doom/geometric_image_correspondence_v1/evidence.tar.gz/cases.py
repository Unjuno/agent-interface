from __future__ import annotations

CASES = [
    dict(id="aligned_clean", seed=1101, shift=0, nuisance={}),
    dict(id="aligned_brightness", seed=1102, shift=0, nuisance={"gain":1.06,"offset":11}),
    dict(id="aligned_patch", seed=1103, shift=0, nuisance={"patch":(58,28,104,64,(250,20,20)),"noise_seed":4103,"noise_fraction":0.01,"noise_amplitude":9}),
    dict(id="near_goal_plus2", seed=1104, shift=2, nuisance={"gain":0.96,"offset":8,"noise_seed":4104,"noise_fraction":0.015,"noise_amplitude":8}),
    dict(id="off_goal_plus5", seed=1105, shift=5, nuisance={"noise_seed":4105,"noise_fraction":0.01,"noise_amplitude":10}),
    dict(id="off_goal_minus7", seed=1106, shift=-7, nuisance={"gain":1.04,"offset":5}),
    dict(id="off_goal_plus10_patch", seed=1107, shift=10, nuisance={"gain":1.05,"offset":7,"patch":(12,50,48,82,(12,230,70)),"noise_seed":4107,"noise_fraction":0.01,"noise_amplitude":7}),
    dict(id="second_texture_minus6", seed=2208, shift=-6, nuisance={"gain":0.95,"offset":13,"noise_seed":4208,"noise_fraction":0.02,"noise_amplitude":6}),
    dict(id="unrelated_control", seed=1109, shift=None, unrelated_seed=99109, nuisance={"gain":1.03,"offset":4}),
    dict(id="low_texture_control", seed=None, shift=None, low_texture=True, nuisance={}),
]

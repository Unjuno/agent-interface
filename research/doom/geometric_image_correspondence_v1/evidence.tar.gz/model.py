from __future__ import annotations

from dataclasses import dataclass
import numpy as np

RAW_MAE_THRESHOLD = 0.035
MAX_SHIFT = 12
MIN_NCC = 0.80
MIN_MARGIN = 0.03
GOAL_SHIFT_PX = 2

@dataclass(frozen=True)
class Correspondence:
    status: str
    shift_px: int | None
    best_ncc: float | None
    margin: float | None
    goal: bool | None


def make_texture(seed: int, width: int = 160, height: int = 96) -> np.ndarray:
    rng = np.random.default_rng(seed)
    # Multi-scale authored texture: random base plus a few deterministic bands.
    base = rng.integers(24, 232, size=(height, width, 3), dtype=np.uint8)
    yy, xx = np.mgrid[0:height, 0:width]
    bands = ((17 * xx + 29 * yy + seed) % 61).astype(np.uint8)
    out = base.astype(np.int16)
    out[..., 0] = np.clip(out[..., 0] // 2 + bands + 24, 0, 255)
    out[..., 1] = np.clip(out[..., 1] // 2 + ((bands * 3) % 67) + 20, 0, 255)
    out[..., 2] = np.clip(out[..., 2] // 2 + ((bands * 5) % 71) + 18, 0, 255)
    return out.astype(np.uint8)


def shift_horizontal(image: np.ndarray, shift_px: int, fill: int = 12) -> np.ndarray:
    if abs(shift_px) >= image.shape[1]:
        raise ValueError("shift too large")
    out = np.full_like(image, fill)
    if shift_px > 0:
        out[:, shift_px:, :] = image[:, :-shift_px, :]
    elif shift_px < 0:
        s = -shift_px
        out[:, :-s, :] = image[:, s:, :]
    else:
        out[:] = image
    return out


def apply_nuisance(
    image: np.ndarray,
    *,
    gain: float = 1.0,
    offset: float = 0.0,
    patch: tuple[int, int, int, int, tuple[int, int, int]] | None = None,
    noise_seed: int | None = None,
    noise_fraction: float = 0.0,
    noise_amplitude: int = 0,
) -> np.ndarray:
    x = image.astype(np.float64) * gain + offset
    x = np.clip(x, 0, 255).astype(np.uint8)
    if patch is not None:
        x0, y0, x1, y1, rgb = patch
        x[y0:y1, x0:x1, :] = np.array(rgb, dtype=np.uint8)
    if noise_seed is not None and noise_fraction > 0 and noise_amplitude > 0:
        rng = np.random.default_rng(noise_seed)
        h, w, _ = x.shape
        n = int(round(h * w * noise_fraction))
        idx = rng.choice(h * w, size=n, replace=False)
        delta = rng.integers(-noise_amplitude, noise_amplitude + 1, size=(n, 1))
        flat = x.reshape(-1, 3).astype(np.int16)
        flat[idx] = np.clip(flat[idx] + delta, 0, 255)
        x = flat.reshape(h, w, 3).astype(np.uint8)
    return x


def raw_mae(reference: np.ndarray, current: np.ndarray) -> float:
    if reference.shape != current.shape:
        raise ValueError("shape mismatch")
    return float(np.mean(np.abs(reference.astype(np.float64) - current.astype(np.float64))) / 255.0)


def _gray(image: np.ndarray) -> np.ndarray:
    if image.ndim != 3 or image.shape[2] != 3:
        raise ValueError("expected RGB")
    x = image.astype(np.float64) / 255.0
    return 0.299 * x[..., 0] + 0.587 * x[..., 1] + 0.114 * x[..., 2]


def _ncc(a: np.ndarray, b: np.ndarray) -> float | None:
    av = a.reshape(-1).astype(np.float64)
    bv = b.reshape(-1).astype(np.float64)
    av -= av.mean()
    bv -= bv.mean()
    na = float(np.linalg.norm(av))
    nb = float(np.linalg.norm(bv))
    if na < 1e-9 or nb < 1e-9:
        return None
    return float(np.dot(av, bv) / (na * nb))


def bounded_ncc_shift(reference: np.ndarray, current: np.ndarray) -> Correspondence:
    if reference.shape != current.shape:
        raise ValueError("shape mismatch")
    r = _gray(reference)
    c = _gray(current)
    w = r.shape[1]
    scored: list[tuple[float, int]] = []
    for s in range(-MAX_SHIFT, MAX_SHIFT + 1):
        if s > 0:
            ra = r[:, : w - s]
            ca = c[:, s:]
        elif s < 0:
            k = -s
            ra = r[:, k:]
            ca = c[:, : w - k]
        else:
            ra = r
            ca = c
        score = _ncc(ra, ca)
        if score is not None:
            scored.append((score, s))
    if not scored:
        return Correspondence("UNKNOWN", None, None, None, None)
    scored.sort(reverse=True)
    best, shift = scored[0]
    second = scored[1][0] if len(scored) > 1 else -1.0
    margin = best - second
    if best < MIN_NCC or margin < MIN_MARGIN:
        return Correspondence("UNKNOWN", None, best, margin, None)
    return Correspondence("IDENTIFIED", shift, best, margin, abs(shift) <= GOAL_SHIFT_PX)


def raw_mae_goal(reference: np.ndarray, current: np.ndarray) -> bool:
    return raw_mae(reference, current) <= RAW_MAE_THRESHOLD

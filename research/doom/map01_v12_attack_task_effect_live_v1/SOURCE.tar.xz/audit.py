from __future__ import annotations
import argparse,json,copy,hashlib
from pathlib import Path
SCHEDULE=[('p1-noinput','NO_INPUT'),('p1-attack','V12_ATTACK'),('p2-attack','V12_ATTACK'),('p2-noinput','NO_INPUT'),('p3-noinput','NO_INPUT'),('p3-attack','V12_ATTACK')]

def load_jsonl(path):
    return [json.loads(x) for x in Path(path).read_text().splitlines() if x.strip()]
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def reconstruct(runtime,arm,case_id):
    runtime=Path(runtime); events=load_jsonl(runtime/'events.jsonl'); samples=load_jsonl(runtime/'scorer-samples.jsonl')
    downs=[]; ups=[]
    for row in events:
        if row.get('event')=='input_admission':
            m=row.get('physical_key_measurement'); edge=m.get('adapter_edge') if isinstance(m,dict) else None
            if isinstance(edge,dict) and edge.get('key')=='space': downs.append(copy.deepcopy(edge))
        if row.get('event')=='input_release_transition' and row.get('key')=='space':
            m=row.get('physical_key_measurement'); edge=m.get('adapter_edge') if isinstance(m,dict) else None
            if isinstance(edge,dict): ups.append((copy.deepcopy(row),copy.deepcopy(edge)))
    positive=[]; prev=None
    for wrapper in samples:
        cur=wrapper.get('payload')
        if not isinstance(cur,dict):continue
        if prev is not None:
            if type(cur.get('kill_count')) is int and type(prev.get('kill_count')) is int and cur['kill_count']>prev['kill_count']:
                positive.append({'kind':'KILL_COUNT_INCREASE','observed_ns':cur['sample_ns'],'before':prev['kill_count'],'after':cur['kill_count'],'authority':False})
            if cur.get('map_exit') is True and prev.get('map_exit') is False:
                positive.append({'kind':'MAP_EXIT','observed_ns':cur['sample_ns'],'authority':False})
        prev=cur
    physical=None
    if len(downs)==1 and len(ups)==1:
        rr,u=ups[0];d=downs[0]
        lineage=all(d.get(k)==u.get(k) for k in ('actuation_id','owner_id','intent_token','key')) and all(d.get(k)==rr.get(k) for k in ('owner_id','intent_token','key'))
        physical={'down':d,'up':u,'release':rr,'lineage_ok':lineage,'confirmed':d.get('status')=='CONFIRMED_PHYSICAL_DOWN' and u.get('status')=='CONFIRMED_PHYSICAL_UP'}
    bound=[]
    if arm=='V12_ATTACK' and physical and physical['confirmed'] and physical['lineage_ok']:
        iv=physical['down'].get('interval'); down_hi=iv[1] if isinstance(iv,list) and len(iv)==2 else None
        if type(down_hi) is int:
            for e in positive:
                if type(e.get('observed_ns')) is int and e['observed_ns']>=down_hi:
                    bound.append({**e,'plan_id':case_id,'actuation_id':physical['down']['actuation_id'],'scorer_authority':False})
    score=json.loads((runtime/'score.json').read_text()) if (runtime/'score.json').exists() else None
    return {'arm':arm,'case_id':case_id,'physical_down_count':len(downs),'physical_up_count':len(ups),'physical':physical,'positive_events':positive,'bound_task_effects':bound,'scorer_samples':len(samples),'score':score,'runtime_sources_sha256':sha(runtime/'sources.json')}

def integrity_errors(rows):
    errors=[]
    if len(rows)!=6:return ['denominator']
    seen=set()
    for r in rows:
        cid=r.get('case_id');arm=r.get('arm')
        if cid in seen:errors.append('duplicate_case:'+str(cid))
        seen.add(cid)
        for e in r.get('positive_events',[]):
            if e.get('kind') not in ('KILL_COUNT_INCREASE','MAP_EXIT'):errors.append('weak_effect_kind:'+cid)
            if e.get('authority') is not False:errors.append('scorer_authority:'+cid)
        if arm=='NO_INPUT':
            if r.get('physical_down_count')!=0 or r.get('physical_up_count')!=0 or r.get('physical') is not None:errors.append('no_input_actuation:'+cid)
            if r.get('bound_task_effects'):errors.append('no_input_binding:'+cid)
        elif arm=='V12_ATTACK':
            p=r.get('physical')
            if not isinstance(p,dict) or r.get('physical_down_count')!=1 or r.get('physical_up_count')!=1:errors.append('physical_count:'+cid);continue
            if p.get('confirmed') is not True or p.get('lineage_ok') is not True:errors.append('physical_lineage:'+cid)
            rr=p.get('release',{})
            if rr.get('owner_transition_verified') is not True or rr.get('owned_keycodes_after_batch')!=[]:errors.append('release_neutral:'+cid)
            d=p.get('down',{});u=p.get('up',{})
            if d.get('status')!='CONFIRMED_PHYSICAL_DOWN' or u.get('status')!='CONFIRMED_PHYSICAL_UP':errors.append('physical_status:'+cid)
            if d.get('actuation_id')!=u.get('actuation_id'):errors.append('actuation_pair:'+cid)
            bes=r.get('bound_task_effects',[])
            if len(bes)>1:errors.append('duplicate_effect:'+cid)
            for e in bes:
                if e.get('plan_id')!=cid:errors.append('wrong_plan:'+cid)
                if e.get('actuation_id')!=d.get('actuation_id'):errors.append('wrong_actuation:'+cid)
                if e.get('scorer_authority') is not False:errors.append('bound_authority:'+cid)
                iv=d.get('interval')
                if not isinstance(iv,list) or len(iv)!=2 or type(e.get('observed_ns')) is not int or e['observed_ns']<iv[1]:errors.append('pre_down_effect:'+cid)
                if e.get('kind') not in ('KILL_COUNT_INCREASE','MAP_EXIT'):errors.append('bound_weak_kind:'+cid)
        else:errors.append('arm:'+str(arm))
    return errors

def decision_from(rows):
    errs=integrity_errors(rows)
    if errs:return 'FAIL_EVIDENCE_INTEGRITY'
    attacks=[r for r in rows if r['arm']=='V12_ATTACK'];controls=[r for r in rows if r['arm']=='NO_INPUT']
    ae=[len(r['bound_task_effects']) for r in attacks];ce=[len(r['positive_events']) for r in controls]
    if any(x>0 for x in ce):return 'HOLD_EFFECT_NOT_ACTION_DISCRIMINATING'
    if ae==[1,1,1]:return 'PASS_MAP01_V12_ATTACK_TASK_EFFECT_LIVE_SCOPED'
    if all(x==0 for x in ae):return 'HOLD_ATTACK_TASK_EFFECT_NOT_REPRODUCED'
    return 'HOLD_ATTACK_TASK_EFFECT_INCONSISTENT'

def audit(root):
    root=Path(root);saved=json.loads((root/'FORMAL_RESULT.json').read_text());rows=[];errors=[]
    for case_id,arm in SCHEDULE:
        rt=root/case_id/'runtime'
        if not rt.exists():errors.append('missing:'+case_id);continue
        rows.append(reconstruct(rt,arm,case_id))
    if rows!=saved.get('rows'):errors.append('candidate_auditor_row_mismatch')
    errors.extend('raw:'+e for e in integrity_errors(rows))
    decision=decision_from(rows)
    if saved.get('decision')!=decision:errors.append('decision')
    if saved.get('formal_invocations')!=1 or any(saved.get(k)!=0 for k in ('reruns','replacements','tuning_after_freeze')):errors.append('budget')
    controls={}
    def rejected(name,mutator):
        m=copy.deepcopy(rows);mutator(m);controls[name]=bool(integrity_errors(m))
    ai=next(i for i,r in enumerate(rows) if r['arm']=='V12_ATTACK');ni=next(i for i,r in enumerate(rows) if r['arm']=='NO_INPUT')
    def ensure_effect(m):
        r=m[ai]
        if not r['bound_task_effects']:
            p=r['physical'];r['bound_task_effects']=[{'kind':'KILL_COUNT_INCREASE','observed_ns':p['down']['interval'][1]+1,'plan_id':r['case_id'],'actuation_id':p['down']['actuation_id'],'scorer_authority':False}]
    def wrong_plan(m):ensure_effect(m);m[ai]['bound_task_effects'][0]['plan_id']='wrong'
    def wrong_act(m):ensure_effect(m);m[ai]['bound_task_effects'][0]['actuation_id']='wrong'
    def auth(m):ensure_effect(m);m[ai]['bound_task_effects'][0]['scorer_authority']=True
    def predown(m):ensure_effect(m);m[ai]['bound_task_effects'][0]['observed_ns']=0
    def duplicate(m):ensure_effect(m);m[ai]['bound_task_effects'].append(copy.deepcopy(m[ai]['bound_task_effects'][0]))
    rejected('wrong_plan',wrong_plan);rejected('wrong_actuation',wrong_act);rejected('authority_escalation',auth);rejected('pre_down_effect',predown);rejected('duplicate_effect',duplicate)
    rejected('no_input_binding',lambda m:m[ni].__setitem__('bound_task_effects',[{'kind':'KILL_COUNT_INCREASE'}]))
    rejected('physical_lineage',lambda m:m[ai]['physical'].__setitem__('lineage_ok',False))
    rejected('controller_as_scorer',lambda m:m[ai]['positive_events'].append({'kind':'KILL_COUNT_INCREASE','authority':True}))
    if not all(controls.values()):errors.append('mutation_control')
    return {'schema':'map01-v12-attack-task-effect-live-audit-v3','decision':decision,'errors':errors,'pass':not errors,'rows':len(rows),'controls':controls}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--formal',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();r=audit(a.formal);a.out.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps(r,sort_keys=True));return 0 if r['pass'] else 1
if __name__=='__main__':raise SystemExit(main())

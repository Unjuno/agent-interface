from __future__ import annotations
import argparse,json,copy
from pathlib import Path
from run_case import derive
SCHEDULE=[('p1-noinput','NO_INPUT'),('p1-attack','V12_ATTACK'),('p2-attack','V12_ATTACK'),('p2-noinput','NO_INPUT'),('p3-noinput','NO_INPUT'),('p3-attack','V12_ATTACK')]

def integrity_errors(rows):
    errors=[]
    if len(rows)!=6:return ['denominator']
    seen=set()
    for r in rows:
        cid=r.get('case_id');arm=r.get('arm')
        if cid in seen:errors.append('duplicate_case:'+str(cid))
        seen.add(cid)
        for e in r.get('positive_events',[]):
            if e.get('kind') not in ('KILL_COUNT_INCREASE','MAP_EXIT'):errors.append('weak_effect_kind:'+cid)
            if e.get('authority') is not False:errors.append('scorer_authority:'+cid)
        if arm=='NO_INPUT':
            if r.get('physical_down_count')!=0 or r.get('physical_up_count')!=0 or r.get('physical') is not None:errors.append('no_input_actuation:'+cid)
            if r.get('bound_task_effects'):errors.append('no_input_binding:'+cid)
        elif arm=='V12_ATTACK':
            p=r.get('physical')
            if not isinstance(p,dict) or r.get('physical_down_count')!=1 or r.get('physical_up_count')!=1:errors.append('physical_count:'+cid);continue
            if p.get('confirmed') is not True or p.get('lineage_ok') is not True:errors.append('physical_lineage:'+cid)
            rr=p.get('release',{})
            if rr.get('owner_transition_verified') is not True or rr.get('owned_keycodes_after_batch')!=[]:errors.append('release_neutral:'+cid)
            d=p.get('down',{});u=p.get('up',{})
            if d.get('status')!='CONFIRMED_PHYSICAL_DOWN' or u.get('status')!='CONFIRMED_PHYSICAL_UP':errors.append('physical_status:'+cid)
            if d.get('actuation_id')!=u.get('actuation_id'):errors.append('actuation_pair:'+cid)
            bes=r.get('bound_task_effects',[])
            if len(bes)>1:errors.append('duplicate_effect:'+cid)
            for e in bes:
                if e.get('plan_id')!=cid:errors.append('wrong_plan:'+cid)
                if e.get('actuation_id')!=d.get('actuation_id'):errors.append('wrong_actuation:'+cid)
                if e.get('scorer_authority') is not False:errors.append('bound_authority:'+cid)
                iv=d.get('interval')
                if not isinstance(iv,list) or len(iv)!=2 or e.get('observed_ns',-1)<iv[1]:errors.append('pre_down_effect:'+cid)
                if e.get('kind') not in ('KILL_COUNT_INCREASE','MAP_EXIT'):errors.append('bound_weak_kind:'+cid)
        else:errors.append('arm:'+str(arm))
    return errors

def decision_from(rows):
    errs=integrity_errors(rows)
    if errs:return 'FAIL_EVIDENCE_INTEGRITY'
    attacks=[r for r in rows if r['arm']=='V12_ATTACK'];controls=[r for r in rows if r['arm']=='NO_INPUT']
    ae=[len(r['bound_task_effects']) for r in attacks];ce=[len(r['positive_events']) for r in controls]
    if any(x>0 for x in ce):return 'HOLD_EFFECT_NOT_ACTION_DISCRIMINATING'
    if ae==[1,1,1]:return 'PASS_MAP01_V12_ATTACK_TASK_EFFECT_LIVE_SCOPED'
    if all(x==0 for x in ae):return 'HOLD_ATTACK_TASK_EFFECT_NOT_REPRODUCED'
    return 'HOLD_ATTACK_TASK_EFFECT_INCONSISTENT'

def audit(root):
    root=Path(root);saved=json.loads((root/'FORMAL_RESULT.json').read_text());rows=[];errors=[]
    for case_id,arm in SCHEDULE:
        rt=root/case_id/'runtime'
        if not rt.exists():errors.append('missing:'+case_id);continue
        rows.append(derive(rt,arm,case_id))
    if rows!=saved.get('rows'):errors.append('raw_rederive')
    raw_integrity=integrity_errors(rows);errors.extend('raw:'+e for e in raw_integrity)
    decision=decision_from(rows)
    if saved.get('decision')!=decision:errors.append('decision')
    if saved.get('formal_invocations')!=1 or any(saved.get(k)!=0 for k in ('reruns','replacements','tuning_after_freeze')):errors.append('budget')
    controls={}
    def rejected(name,mutator):
        m=copy.deepcopy(rows);mutator(m);controls[name]=bool(integrity_errors(m))
    # Use the first ATTACK row and first NO_INPUT row independent of schedule position.
    ai=next(i for i,r in enumerate(rows) if r['arm']=='V12_ATTACK');ni=next(i for i,r in enumerate(rows) if r['arm']=='NO_INPUT')
    def ensure_effect(m):
        r=m[ai]
        if not r['bound_task_effects']:
            p=r['physical'];r['bound_task_effects']=[{'kind':'KILL_COUNT_INCREASE','observed_ns':p['down']['interval'][1]+1,'plan_id':r['case_id'],'actuation_id':p['down']['actuation_id'],'scorer_authority':False}]
    def wrong_plan(m):ensure_effect(m);m[ai]['bound_task_effects'][0]['plan_id']='wrong'
    def wrong_act(m):ensure_effect(m);m[ai]['bound_task_effects'][0]['actuation_id']='wrong'
    def auth(m):ensure_effect(m);m[ai]['bound_task_effects'][0]['scorer_authority']=True
    def predown(m):ensure_effect(m);m[ai]['bound_task_effects'][0]['observed_ns']=0
    def duplicate(m):ensure_effect(m);m[ai]['bound_task_effects'].append(copy.deepcopy(m[ai]['bound_task_effects'][0]))
    rejected('wrong_plan',wrong_plan);rejected('wrong_actuation',wrong_act);rejected('authority_escalation',auth)
    rejected('pre_down_effect',predown);rejected('duplicate_effect',duplicate)
    rejected('no_input_binding',lambda m:m[ni].__setitem__('bound_task_effects',[{'kind':'KILL_COUNT_INCREASE'}]))
    rejected('physical_lineage',lambda m:m[ai]['physical'].__setitem__('lineage_ok',False))
    rejected('controller_as_scorer',lambda m:m[ai]['positive_events'].append({'kind':'KILL_COUNT_INCREASE','authority':True}))
    if not all(controls.values()):errors.append('mutation_control')
    return {'schema':'map01-v12-attack-task-effect-live-audit-v2','decision':decision,'errors':errors,'pass':not errors,'rows':len(rows),'controls':controls}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--formal',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();r=audit(a.formal);a.out.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n');print(json.dumps(r,sort_keys=True));return 0 if r['pass'] else 1
if __name__=='__main__':raise SystemExit(main())

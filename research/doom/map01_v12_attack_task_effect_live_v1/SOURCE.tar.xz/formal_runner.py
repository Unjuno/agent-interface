from __future__ import annotations
import argparse,json,traceback,hashlib
from pathlib import Path
from run_case import run_case,derive
SCHEDULE=[('p1-noinput','NO_INPUT'),('p1-attack','V12_ATTACK'),('p2-attack','V12_ATTACK'),('p2-noinput','NO_INPUT'),('p3-noinput','NO_INPUT'),('p3-attack','V12_ATTACK')]
def clean_attack(r):
 p=r.get('physical');return r['physical_down_count']==1 and r['physical_up_count']==1 and isinstance(p,dict) and p.get('confirmed') is True and p.get('lineage_ok') is True and p['release'].get('owner_transition_verified') is True and p['release'].get('owned_keycodes_after_batch')==[]
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--v12',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=False)
 rows=[];stop=None
 for case_id,arm in SCHEDULE:
  try:
   rt=run_case(a.source,a.v12,a.out/case_id,arm,case_id,992600);rows.append(derive(rt,arm,case_id))
  except BaseException as e:
   stop={'case_id':case_id,'arm':arm,'error':repr(e),'traceback':traceback.format_exc()};break
 attacks=[r for r in rows if r['arm']=='V12_ATTACK'];controls=[r for r in rows if r['arm']=='NO_INPUT']
 physical_clean=len(attacks)==3 and all(clean_attack(r) for r in attacks)
 attack_effects=[len(r['bound_task_effects']) for r in attacks];control_effects=[len(r['positive_events']) for r in controls]
 if stop:decision='FAIL_FORMAL_RUNTIME_OR_SCHEMA'
 elif len(rows)!=6:decision='FAIL_FORMAL_DENOMINATOR'
 elif not physical_clean:decision='FAIL_MAP01_V12_PHYSICAL_LINEAGE'
 elif any(x>0 for x in control_effects):decision='HOLD_EFFECT_NOT_ACTION_DISCRIMINATING'
 elif attack_effects==[1,1,1]:decision='PASS_MAP01_V12_ATTACK_TASK_EFFECT_LIVE_SCOPED'
 elif all(x==0 for x in attack_effects):decision='HOLD_ATTACK_TASK_EFFECT_NOT_REPRODUCED'
 else:decision='HOLD_ATTACK_TASK_EFFECT_INCONSISTENT'
 out={'schema':'map01-v12-attack-task-effect-live-formal-v1','decision':decision,'formal_invocations':1,'reruns':0,'replacements':0,'tuning_after_freeze':0,'rows':rows,'attack_bound_effect_counts':attack_effects,'no_input_positive_effect_counts':control_effects,'physical_clean':physical_clean,'stop':stop}
 (a.out/'FORMAL_RESULT.json').write_text(json.dumps(out,indent=2,sort_keys=True,default=str)+'\n');print(json.dumps({'decision':decision,'attack_effects':attack_effects,'control_effects':control_effects,'physical_clean':physical_clean,'rows':len(rows)},sort_keys=True));return 0 if decision.startswith(('PASS_','HOLD_')) else 1
if __name__=='__main__':raise SystemExit(main())

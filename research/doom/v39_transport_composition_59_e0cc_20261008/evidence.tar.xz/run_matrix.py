import datetime, hashlib, json, os, platform, shutil, signal, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
RUNS=ROOT/'runs-observed'
RUNS.mkdir(exist_ok=False)
freeze={'kind':'ordinary integration regression source snapshot','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':sys.version,'platform':platform.platform(),'clock':'perf_counter_ns','load_average':os.getloadavg(),'free_bytes':shutil.disk_usage(ROOT).free,'source_hashes':{arm:{str(p.relative_to(ROOT/arm/'source')):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/arm/'source').rglob('*.py'))} for arm in ('baseline','candidate')},'harness_hashes':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ('controller_probe.py','inert_peer.py','PROTOCOL.md','run_matrix.py')}}
(ROOT/'MATRIX_SOURCE_SNAPSHOT.json').write_text(json.dumps(freeze,indent=2)+'\n')
for mode in ('pressure','ack_complete'):
 for arm in ('baseline','candidate'):
  name=f'{arm}-{mode}'; out=RUNS/name
  command=[sys.executable,'-B',str(ROOT/'controller_probe.py'),'--source',str(ROOT/arm/'source'),'--out',str(out),'--mode',mode]
  receipt={'command':command,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  (RUNS/(name+'.intent.json')).write_text(json.dumps(receipt,indent=2)+'\n')
  proc=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
  timeout=False
  try:stdout,stderr=proc.communicate(timeout=15)
  except subprocess.TimeoutExpired:
   timeout=True
   identity=out/'peer_identity.json'
   if identity.exists():
    pid=json.loads(identity.read_text())['pid']
    observed=subprocess.run(['ps','-p',str(pid),'-o','command='],text=True,capture_output=True)
    receipt['rescue_identity_check']=observed.stdout
    if str(ROOT/'inert_peer.py') in observed.stdout:
     try:os.killpg(pid,signal.SIGTERM)
     except ProcessLookupError:pass
   os.killpg(proc.pid,signal.SIGTERM)
   try:stdout,stderr=proc.communicate(timeout=3)
   except subprocess.TimeoutExpired:
    os.killpg(proc.pid,signal.SIGKILL);stdout,stderr=proc.communicate(timeout=3)
  (RUNS/(name+'.stdout.txt')).write_bytes(stdout);(RUNS/(name+'.stderr.txt')).write_bytes(stderr)
  receipt.update(end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),returncode=proc.returncode,outer_timeout=timeout,stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest())
  (RUNS/(name+'.execution.json')).write_text(json.dumps(receipt,indent=2)+'\n')
  print(name,proc.returncode,stdout.decode().strip(),flush=True)
  if timeout or proc.returncode:raise SystemExit(1)
  trace=json.loads((out/'trace.json').read_text())
  if not trace.get('error',{}).get('message','').startswith('cover terminal lacks allowed status'):raise SystemExit('unexpected primary error; preserve and stop')
  if mode=='pressure' and not any(r['event']=='write_pressure_observed' for r in trace['timeline']):raise SystemExit('missing pressure exposure')

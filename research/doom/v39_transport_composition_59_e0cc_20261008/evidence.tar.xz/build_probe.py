from pathlib import Path
ROOT=Path(__file__).resolve().parent
old=(ROOT.parent/'v39_interrupt_ack_e0cc_20261007/controller_probe.py').read_text()
s=old.replace('import queue\n','import queue\nimport hashlib\nimport select\n')
s=s.replace('["rpc_error", "ack_complete", "eof", "ack_silent"]','["pressure", "ack_complete"]')
s=s.replace('from codex_app_server_client_v2 import CodexAppServerClient','import codex_app_server_client_v2 as client_module\nimport persistent_planner_adapter_v2 as adapter_module\nfrom codex_app_server_client_v2 import CodexAppServerClient')
s=s.replace('futures = []','futures = []\nfatal_seen = threading.Event()\nwriter_done = threading.Event()\nwriter = None\neagain_count = 0\nsent_bytes = 0\nwrite_calls = 0\ntrace["settings"] = {"sender_timeout_s": .75, "interrupt_default_timeout_s": 30, "planner_timeout_s": 90, "rescue_after_fatal_s": 3, "payload_bytes": 2 * 1024 * 1024}\ntrace["loaded_sources"] = {m.__name__: {"path": str(Path(m.__file__).resolve()), "sha256": hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()} for m in (controller, client_module, adapter_module)}')
s=s.replace('args.mode],\n    journal_path','args.mode, str(args.out / "peer-stopped.json")],\n    journal_path')
s=s.replace('trace["owns_process_group"] = client._owns_process_group','trace["owns_process_group"] = client._owns_process_group\nstdin_fd = client.process.stdin.fileno()\ntrace["stdin_fd"] = stdin_fd')
start=s.index('def rescue():');end=s.index('\n\nwatchdog =',start)
s=s[:start]+'''def rescue():
    if not fatal_seen.wait(5):
        if finished.is_set():
            return
        record("rescue_no_fatal")
    elif finished.wait(3):
        return
    record("external_rescue_enter", unfinished_futures=sum(not f.done() for f in futures))
    try:
        client.close(timeout=1)
    except BaseException as error:
        record("external_rescue_error", kind=type(error).__name__, message=str(error))
    record("external_rescue_return")


def send_pressure():
    record("sender_enter")
    try:
        client.request("synthetic/pressure", {"payload": "x" * (2 * 1024 * 1024)}, timeout=.75)
    except BaseException as error:
        record("sender_error", kind=type(error).__name__, message=str(error),
               sent=getattr(error, "sent", None), total=getattr(error, "total", None))
    else:
        record("sender_unexpected_success")
    finally:
        writer_done.set()
        record("sender_exit")


real_os_write = os.write

def observe_write(fd, data):
    global eagain_count, sent_bytes, write_calls
    try:
        count = real_os_write(fd, data)
    except BlockingIOError:
        if fd == stdin_fd:
            eagain_count += 1
            if eagain_count <= 4:
                record("pipe_eagain", requested_bytes=len(data))
        raise
    if fd == stdin_fd:
        sent_bytes += count
        write_calls += 1
        if write_calls <= 6:
            record("pipe_write", requested_bytes=len(data), written_bytes=count)
    return count


def prepare_pressure():
    global writer
    stop_path = args.out / "peer-stopped.json"
    end = time.monotonic() + 2
    while not stop_path.exists():
        if time.monotonic() >= end:
            raise RuntimeError("fixture peer did not establish no-read barrier")
        time.sleep(.001)
    trace["peer_stopped"] = json.loads(stop_path.read_text())
    record("peer_no_read_barrier")
    writer = threading.Thread(target=send_pressure, name="construction-large-sender")
    writer.start()
    end = time.monotonic() + .5
    while time.monotonic() < end:
        writable = bool(select.select([], [stdin_fd], [], 0)[1])
        got_lock = client._write_lock.acquire(blocking=False)
        if got_lock:
            client._write_lock.release()
        if not writable and not got_lock and writer.is_alive() and not writer_done.is_set():
            record("write_pressure_observed", pipe_writable=False, write_lock_available=False,
                   sender_pending=True, eagain_count=eagain_count, sent_bytes=sent_bytes)
            return
        if writer_done.is_set():
            break
        time.sleep(.001)
    raise RuntimeError("fixture did not establish pending writer pressure")
''' +s[end:]
s=s.replace('record("terminal_read", pending=not futures[0].done())','record("terminal_read", pending=not futures[0].done(), writer_pending=writer is not None and writer.is_alive())\n            fatal_seen.set()')
s=s.replace('process = SimpleNamespace(stdin=Stdin(), stdout=iter(()), poll=lambda: None)','process = SimpleNamespace(stdin=Stdin(), stdout=iter(()), poll=lambda: 0)')
s=s.replace('raise RuntimeError("planner future did not enter await")\n        return future','raise RuntimeError("planner future did not enter await")\n        if args.mode == "pressure":\n            prepare_pressure()\n        return future')
start=s.index('class CleanupSpy:');end=s.index('\n\ndef final_admission',start)
s=s[:start]+'''class CleanupSpy(controller.ControllerFailureCleanup):
    def __exit__(self, kind, error, tb):
        record("cleanup_entry", error=kind.__name__, futures_done=all(f.done() for f in futures))
        result = super().__exit__(kind, error, tb)
        record("cleanup_return")
        return result
''' +s[end:]
s=s.replace('replacements = [','replacements = [\n    patch.object(os, "write", observe_write),')
s=s.replace('watchdog.join(timeout=7)\n    client.close(timeout=1)','watchdog.join(timeout=7)\n    if writer is not None:\n        writer.join(timeout=2)\n    trace["before_fixture_close"] = {"peer_exited": client.process.poll() is not None, "reader_alive": client._reader.is_alive(), "writer_alive": writer is not None and writer.is_alive(), "journal_closed": client._journal.closed, "stdin_closed": client.process.stdin.closed, "cached_fd": getattr(client, "_stdin_fd", None)}\n    try:\n        client.close(timeout=1)\n    except BaseException as error:\n        trace["fixture_close_error"] = {"kind": type(error).__name__, "message": str(error)}')
s=s.replace('trace["journal_closed"] = client._journal.closed','trace["journal_closed"] = client._journal.closed\n    trace["pending_ids"] = sorted(client._pending)\n    trace["responses"] = sorted(client._responses)\n    trace["writer_alive"] = writer is not None and writer.is_alive()\n    trace["eagain_count"] = eagain_count\n    trace["os_write_bytes"] = sent_bytes\n    trace["streams_closed"] = {n: getattr(client.process,n).closed for n in ("stdin", "stdout", "stderr")}')
(ROOT/'controller_probe.py').write_text(s)
peer=(ROOT.parent/'v39_interrupt_ack_e0cc_20261007/inert_peer.py').read_text().replace('import sys\n','import sys\nimport time\nimport os\nfrom pathlib import Path\n')
peer=peer.replace('    if method == "turn/interrupt" and mode == "ack_complete":','    if method == "turn/start" and mode == "pressure":\n        Path(sys.argv[2]).write_text(json.dumps({"pid": os.getpid(), "at_ns": time.perf_counter_ns(), "mode": "stop_reading_until_terminated"})+"\\n")\n        time.sleep(60)\n        raise RuntimeError("fixture peer exceeded construction watchdog")\n    if method == "turn/interrupt" and mode == "ack_complete":')
(ROOT/'inert_peer.py').write_text(peer)

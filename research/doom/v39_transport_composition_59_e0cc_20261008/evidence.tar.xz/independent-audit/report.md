# Independent retained-data audit of V39 transport composition

The retained-data audit passed **470 named checks**. All **18 independent mutation controls** were rejected by their intended named predicate. This is an evidence audit, not an adoption or merge vote. No experiment, peer, controller, model, GUI, native input, or harness was executed by this auditor.

Only `runs-observed` supplies the complete before-fixture-close retirement evidence. `runs-first` and `runs-corrected` remain separate historical generations; they are not promoted into that result.

## Observed results

| Cell | Audited disposition | Failed-cover read to controller exit | Failed-cover read to before-close observation |
|---|---|---:|---:|
| baseline-pressure | Failure requiring external rescue; secondary cleanup error retained | 3.004097125 s | 3.004144958 s |
| candidate-pressure | Scoped finite retirement without external rescue | 0.734566083 s | 0.734654458 s |
| baseline-ack_complete | ACK/completion control passed | 0.002465250 s | 0.002564375 s |
| candidate-ack_complete | ACK/completion control passed | 0.002456375 s | 0.002506625 s |

Candidate pressure retained an actual partial write of **65,536 / 2,097,215 encoded bytes**, followed by EAGAIN and send uncertainty. The request payload itself is 2,097,152 bytes. The pressure observation reports 66,338 cumulative bytes because that count also includes protocol initialization; the auditor independently sums sender-only writes instead of confusing these quantities.

The source-bound deadline settings are sender 0.75 s, production interrupt default 30 s, planner await 90 s, rescue after failed cover 3 s, and outer watchdog 15 s. The observed subsecond outcome does **not** establish a general subsecond interrupt bound. The discriminating result is finite retirement in this particular composed prior-send-failure path while retaining the unchanged interrupt default.

## Evidence predicates

- Exact source origins, both exported 19-file inventories, all three versioned snapshots, and all actually loaded research dependencies bind to pinned SHA-256 values. Source paths support private and redacted prefixes through the exact arm/source/research suffix.
- Intents and execution receipts agree; commands identify the proper arm, mode and generation; stdout/stderr byte hashes match; four cells retain their declared order and normal wrapper exit without outer timeout. Wrapper exit zero does not turn rescued baseline behavior into success.
- The real peer's identity and no-read barrier agree with the trace. Nonwritable stdin, unavailable write lock, pending sender, and pending planner waiter precede the synthetic failed terminal. Sender exit follows the terminal read. Candidate EAGAIN and positive partial-write bytes are required independently.
- The exact original `RuntimeError` and failed terminal survive. Exactly one synthetic input submission occurs; no final-admission event occurs. The actual cleanup receipt reports the original failure stage and planner-close worker path.
- Candidate interrupt is attempted, then returns previous-send-failure `request_error`. Its journal contains no `turn/interrupt` or second `turn/start` record after quarantine. The journal's `sent` direction is treated as a logged send attempt, not proof of complete peer delivery.
- Candidate abort returns; the waiter ends; cleanup returns with futures already done. Before fixture close, the peer is exited, reader and writer are inactive, streams and journal are closed, pending IDs/replies are empty, the cached stdin descriptor is absent, the write lock is available, and the owned process group is absent. These readouts occur after controller exit and before the final fixture-close call in the pinned probe source.
- Baseline pressure requires rescue after 3.002254708 s. It retains a secondary `PermissionError` from planner close and open journal/stdout/stderr before fixture close. It is classified as `FAILURE_RESCUED_WITH_SECONDARY_CLEANUP_ERROR`, not a successful retirement or proof of an infinite hang.
- Both ACK/completion controls retain the cover error; completed answers are cancelled and ineligible. They receive one interrupt ACK plus a completion message, admit no additional input and retire without rescue.
- The actual cleanup receipt still reports `cleanup_complete: false`, no real scorer terminal, and no physical input-release certificate. Those limitations cannot be overwritten by transport retirement.

## Source origin verification

`source-origin-audit.json` records 36 independent exact Git-blob comparisons. Both arms use base `d4ac01bcb8bfc3a9eb13c8b00f43cb3ef02eccac`, the exact adapter from `e851a2e93c1b995fefa630c7e36a78680fc80e59`, and baseline/candidate client blobs from base / `fd14d9ed655192b90c38c8509aa769f79f6fb745`, respectively. The controller diff has exactly three insertions, no removals or replacements; each inserted text is an exact fragment of the cover-repair source. Both composed controller files are identical. The unchanged cleanup dependency hashes to `e7738973991459f5fe9553383afb4000a1cbb6c755bc5763f11eab85c32dead8`.

The independent auditor's source pins can therefore be used without Git or importing experiment modules. `audit.py` SHA-256: `75ba5d48e385d8884dd635552be479c67d07403d6d81553fb212a2a795404710`.

## Preserved failures and repair boundary

The first candidate-pressure cell raises `JSONDecodeError` before sender/pressure/failed-terminal exposure because the readiness file was visible before its JSON was fully written. It is explicitly `FIXTURE_ERROR_BEFORE_EXPOSURE`; its rescue is retained. The atomic-publication repair and wrapper validation changes have separate snapshots.

The corrected candidate-pressure cell exposes pressure and exits without rescue, but several actor/stream/group readouts occur only after fixture close. It is `EXPOSED_NO_RESCUE_POSTCLOSE_OBSERVATION_INCOMPLETE`; it does not supply the final retirement predicate. The observed generation adds preclose readouts and complete loaded-dependency hashes under unchanged production sources, deadlines and stimuli. Snapshot hashes for all first/corrected/observed core harness files match their retained files.

## Mutation controls

Each control modifies a fresh deep copy of parsed evidence in memory. The auditor must fail the specifically named semantic predicate; a generic byte-hash mismatch alone does not satisfy a semantic control. Mutations cover loaded dependency hashes, source bytes, writable pipe, missing EAGAIN, failure after sender exit, candidate rescue, overwritten primary error, missing future readout, live reader, surviving process group, extra submission, final admission, interrupt journal entry after quarantine, inconsistent partial count, shortened interrupt default, missing abort result, erased initial fixture error, and erased baseline rescue. No input data is modified.

## Reproduction and artifacts

```bash
python3 -B audit.py --evidence-root /path/to/evidence --output /path/to/new-audit-output
```

The output directory must be new. The command reads retained JSON/JSONL and source bytes only, then writes `result.json`, `mutations.json`, and an `input-sha256.json` inventory in that new directory. The first audit output is preserved at `audit-first/`: PASS / 470 checks / 18 rejected controls, with no first-run audit failure.

The proof is bounded to these retained local samples and the pinned observational harness. Scorer/input/observation behavior is synthetic; there is no live game, model, physical-input, release, Windows, or container claim. The production path closes successfully in candidate/control cells; failure of close before waking a waiter remains outside this result. The watchdog is joined before preclose readout but its liveness flag is sampled after fixture close. No `fstat` establishes global absence of a descriptor number: the evidence establishes closed stream wrappers and cleared cached descriptor. The group observation is one point-in-time readout. Loaded file hashing establishes recorded source binding, not adversarially attested process memory. No statistical timing or global worst-case guarantee follows from one sample per cell.

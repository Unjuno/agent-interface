#!/usr/bin/env python3
"""Independent retained-data audit. Does not import or execute the experiment.

Usage: python3 -B audit.py --evidence-root PATH --output NEW_DIRECTORY
Only reads evidence; mutation controls change deep copies in memory.
"""
import argparse
import copy
import datetime as dt
import hashlib
import json
from pathlib import Path

BASE = 'd4ac01bcb8bfc3a9eb13c8b00f43cb3ef02eccac'
COVER = 'e851a2e93c1b995fefa630c7e36a78680fc80e59'
CLIENT = 'fd14d9ed655192b90c38c8509aa769f79f6fb745'
CLIENT_PATH = 'research/live_control/codex_app_server_client_v2.py'
PINS = {
 'research/doom/doom_action_snapshot_v1.py':'69713831fb6fecb285fc6bde7b50d6fabaeb7cc0ddf5b24ae347d1f2c47614f0',
 'research/doom/doom_action_validity_contract_v1.py':'1aeb8443816c81e6417b6dd770fe40616150887ff6f637042b6a8216ef84568c',
 'research/doom/doom_controller_failure_cleanup_v1.py':'e7738973991459f5fe9553383afb4000a1cbb6c755bc5763f11eab85c32dead8',
 'research/doom/doom_hud_signal_v1.py':'eecb889ad76fd3d23dfc32ae8c804ecbb32efc7b4d9ac5174ce4aefa7c70514c',
 'research/doom/doom_hud_signal_v2.py':'c4d5269d258e57b3e04d024f8a3d8948c7bfb73f309f0ca6fe3cd6a44cc755ff',
 'research/doom/doom_hud_signal_v3.py':'9bd6b7462adfa6c07f1ab0a0820280768ccb9eff14aca32956a14538c0acb6d7',
 'research/doom/doom_source_refresh_v1.py':'a53d85ab8b012608ec92f5bc00ed85b1573bbd829d31d5e8010c47381c1e0fcc',
 'research/doom/doom_typed_observation_v1.py':'038537fac0b155025bec50e92eaa9ca434cc3789498199634ded095b151ef555',
 'research/doom/map01_overlap_controller_v39.py':'21b5235bdb2d2c4986456fdff2b12ae42c1a8239efd62b7ee238e9ae33792bde',
 'research/doom/map01_stagnation_v1.py':'669d61eb473c486e693a478b1941a7b40102d2049e0a437e5982143544d60a54',
 'research/live_control/action_validity_admission_v1.py':'f102cbde4f0e46c9f8e974e9f0a7d1c47f3fc662d7c8ba32699d16799d3db98a',
 CLIENT_PATH:'a51ed51120a72f289c3d8298a446ab5958ebdff0f0261f770637daaba0862faa',
 'research/live_control/final_action_admission_v1.py':'7a6ee78d241a79aabd803cb92e0f57e20ec784df1be877012b3efc187012746d',
 'research/live_control/final_action_admission_v2.py':'16f785d2542335a857163b9afa6c6e84b776b77d62ce36345fc28987a5ca897b',
 'research/live_control/observable_signal_guard_v2.py':'7be055c4bd68a1528f4b2b02b543435bd64465ea42d4452f5597d6dce08442a0',
 'research/live_control/persistent_planner_adapter_v2.py':'2bb391d4f897952b2c4137f91646b2ebb0c910c1c19a9d1e3feef8aa302647d1',
 'research/live_control/running_action_guard_v1.py':'2d5feb69efd59fdca22e0db9e561923411490eb758eab9e2b8379714e20e5c62',
 'research/live_control/running_action_guard_v2.py':'908ab4117f007c2592d96a50370c7e29a5c048cfee2d6c70d1bb66fc1b4e11e2',
 'research/live_control/running_action_guard_v3.py':'bcc0dc5961a54a315a05558d800f94ff119fa6106ed91e0fa0ba14131d470732',
}
CANDIDATE_CLIENT = '3994bd0a1ab956cc472e06687355c3247168d606d141064fbaa03b6da1da9bce'
HARNESS = {'controller_probe.py':'636a35e2cbc010f0d8441eb7776fb2c39b28291004b4630d18448d8589078060',
           'inert_peer.py':'41bec83413651f43c96d93444a1000a96e6f90c2840e382b4174e885d007bd73',
           'run_matrix.py':'58905cd9a74b79b7064084942cecd282c238178eb679b3ceaca7455f7d203c15',
           'PROTOCOL.md':'6691ea5f6084243f79e8bb425802f37c75d96b076c019c1521c260046b07b453'}
SETTINGS = dict(sender_timeout_s=.75, interrupt_default_timeout_s=30, planner_timeout_s=90,
                rescue_after_fatal_s=3, payload_bytes=2097152)
CELLS = ('baseline-pressure','candidate-pressure','baseline-ack_complete','candidate-ack_complete')
GENERATIONS = ('first','corrected','observed')
TERMINAL = {'event':'terminal','id':'cover-0','status':'failed','terminal_ns':120,
            'error':'injected input error','release':{'verified':True,'keys_down':[],'buttons_down':[]}}
PRIMARY = 'cover terminal lacks allowed status and verified empty release: ' + repr(TERMINAL)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def load(root):
    raw = {}
    def read(path):
        raw[path] = (root/path).read_bytes()
        return raw[path]
    def obj(path):
        return json.loads(read(path))
    bundle = {'origin':obj('SOURCE_ORIGIN.json'),'snapshots':{},'harness':{},'sources':{},'runs':{}}
    for arm in ('baseline','candidate'):
        bundle['sources'][arm] = {str(p.relative_to(root/arm/'source')):read(str(p.relative_to(root)))
                                 for p in sorted((root/arm/'source').rglob('*.py'))}
    for generation in GENERATIONS:
        suffix = '' if generation == 'observed' else '.'+generation+'.txt'
        bundle['snapshots'][generation] = obj('MATRIX_SOURCE_SNAPSHOT.json'+suffix)
        bundle['harness'][generation] = {name:read(name+suffix) for name in HARNESS}
        runs = bundle['runs'][generation] = {}
        for cell in CELLS:
            prefix = 'runs-'+generation+'/'+cell
            runs[cell] = {
                'trace':obj(prefix+'/trace.json'), 'cleanup':obj(prefix+'/controller/controller-failure.json'),
                'wire':[json.loads(line) for line in read(prefix+'/wire.jsonl').splitlines()],
                'identity':obj(prefix+'/peer_identity.json'), 'intent':obj(prefix+'.intent.json'),
                'execution':obj(prefix+'.execution.json'), 'stdout':read(prefix+'.stdout.txt'),
                'stderr':read(prefix+'.stderr.txt'),
            }
            if cell.endswith('-pressure'):
                runs[cell]['stopped'] = obj(prefix+'/peer-stopped.json')
    bundle['input_sha256'] = {p:sha(data) for p,data in sorted(raw.items())}
    return bundle

def audit(b):
    checks = []
    def ck(name, condition):
        checks.append({'name':name,'pass':bool(condition)})
    ck('origin.fixed_commits', all(b['origin'].get(k)==v for k,v in [('base',BASE),('cover',COVER),('client',CLIENT)]))
    expected = {'baseline':PINS, 'candidate':dict(PINS, **{CLIENT_PATH:CANDIDATE_CLIENT})}
    for arm in expected:
        actual = {p:sha(data) for p,data in b['sources'][arm].items()}
        ck('source.'+arm+'.independent_pins', actual == expected[arm])
    for generation in GENERATIONS:
        snapshot = b['snapshots'][generation]
        ck(generation+'.source_snapshot', snapshot['source_hashes'] == expected)
        ck(generation+'.harness_snapshot', snapshot['harness_hashes'] == {n:sha(v) for n,v in b['harness'][generation].items()})
    ck('observed.harness_independent_pins', b['snapshots']['observed']['harness_hashes'] == HARNESS)
    for generation in GENERATIONS:
        previous_end = None
        for cell in CELLS:
            prefix = generation+'.'+cell+'.'
            arm, mode = cell.split('-',1)
            d = b['runs'][generation][cell]; t = d['trace']; rows = t['timeline']
            events = [r['event'] for r in rows]
            index = {}
            for row in rows:
                index.setdefault(row['event'],[]).append(row)
            def one(name):
                found = index.get(name,[])
                ck(prefix+'exactly_one.'+name, len(found)==1)
                return found[0] if found else {}
            def order(*names):
                times = [index.get(n,[{}])[0].get('ns',-1) for n in names]
                return all(type(x) is int and x>=0 for x in times) and all(a<b for a,b in zip(times,times[1:]))
            def check(name, condition): ck(prefix+name,condition)
            check('timeline_monotonic', all(type(r.get('ns')) is int for r in rows) and
                  all(a['ns']<=c['ns'] for a,c in zip(rows,rows[1:])))
            check('settings_unchanged', t['settings']==SETTINGS)
            check('environment', t['clock']=='perf_counter_ns' and t['no_model_or_native_input'] is True and
                  t['python']==b['snapshots'][generation]['python'] and t['platform']==b['snapshots'][generation]['platform'])
            e,i = d['execution'],d['intent']
            check('receipt_exit', e['returncode']==0 and e['outer_timeout'] is False)
            check('receipt_stream_hashes', e['stdout_sha256']==sha(d['stdout']) and e['stderr_sha256']==sha(d['stderr']))
            check('receipt_intent', e['command']==i['command'] and e['start_utc']==i['start_utc'])
            cmd=e['command']
            check('receipt_command', len(cmd)==9 and cmd[1]=='-B' and cmd[2].endswith('/controller_probe.py') and
                  cmd[3]=='--source' and cmd[4].endswith('/'+arm+'/source') and cmd[5]=='--out' and
                  cmd[6].endswith('/runs-'+generation+'/'+cell) and cmd[7:] == ['--mode',mode])
            start,end = (dt.datetime.fromisoformat(e[k]) for k in ('start_utc','end_utc'))
            check('receipt_order', start<end and (previous_end is None or previous_end<=start))
            previous_end=end
            check('identity', type(t['peer_pid']) is int and t['peer_pid']>0 and t['owns_process_group'] is True and
                  d['identity']['pid']==t['peer_pid'] and d['identity']['command'][1]=='-u' and
                  d['identity']['command'][2].endswith('/inert_peer.py') and d['identity']['command'][3]==mode)
            for key in ('loaded_sources','loaded_dependency_sources'):
                if key=='loaded_dependency_sources' and generation!='observed':continue
                loaded = t.get(key,{})
                required = set(Path(p).stem for p in PINS) if key=='loaded_dependency_sources' else {
                    'map01_overlap_controller_v39','codex_app_server_client_v2','persistent_planner_adapter_v2'}
                good = set(loaded)==required
                for name,meta in loaded.items():
                    marker='/'+arm+'/source/'
                    path=meta.get('path','')
                    relative=path.split(marker,1)[1] if marker in path else ''
                    good = good and relative in expected[arm] and Path(relative).stem==name and meta.get('sha256')==expected[arm].get(relative)
                check(key+'.binding',good)
            original_fixture_error = generation=='first' and cell=='candidate-pressure'
            rescued = 'external_rescue_enter' in events
            summary = json.loads(d['stdout'])
            check('stdout_agrees', summary['mode']==mode and summary['error']==t['error'] and summary['rescued'] is rescued)
            if original_fixture_error:
                check('history.fixture_error_preserved', t['error']['type']=='JSONDecodeError' and
                      t['error']['message']=='Expecting value: line 1 column 1 (char 0)' and rescued and
                      'rescue_no_fatal' in events and not any(n in events for n in ('terminal_read','sender_enter','write_pressure_observed')))
                check('history.no_failed_cover_exposure', [r['event'] for r in t['events']]==['ready','observation','accepted'])
                continue
            terminal=one('terminal_read'); await_enter=one('await_enter'); cleanup_entry=one('cleanup_entry')
            one('cleanup_return'); one('main_error'); one('main_exit'); one('interrupt_enter'); ir=one('interrupt_result')
            check('primary_error',t['error']['type']=='RuntimeError' and t['error']['message']==PRIMARY)
            check('original_failed_terminal', [r for r in t['events'] if r.get('event')=='terminal']==[TERMINAL])
            check('single_submit',len(t['commands'])==1 and t['commands'][0].get('op')=='submit' and
                  t['commands'][0].get('id')=='cover-0' and events.count('session_write')==1 and
                  index['session_write'][0].get('op')=='submit')
            check('no_final_admission','final_admission' not in events)
            check('pending_waiter',terminal.get('pending') is True and await_enter.get('timeout')==90 and
                  order('await_enter','terminal_read','interrupt_enter','interrupt_result'))
            check('primary_cleanup',cleanup_entry.get('error')=='RuntimeError' and cleanup_entry.get('futures_done') is True and
                  order('interrupt_result','cleanup_entry','cleanup_return','main_error','main_exit'))
            cleanup=d['cleanup']; stages={r['stage']:r for r in cleanup['stages']}
            check('actual_cleanup',cleanup['primary_error_type']=='RuntimeError' and cleanup['failed_stage']=='cover_terminal_validation' and
                  stages.get('planner_close_worker_start',{}).get('status')=='returned')
            check('no_false_scorer_certificate',cleanup['cleanup_complete'] is False and cleanup['input_release_verified'] is False and
                  cleanup['scorer_terminal_observed'] is False)
            wire=d['wire']; sent=[r for r in wire if r['direction']=='sent']; methods=[r['message'].get('method') for r in sent]
            check('wire_handshake',methods[:4]==['initialize','initialized','thread/start','turn/start'] and
                  sum(m=='turn/start' for m in methods)==1 and
                  any(r['direction']=='received' and r['message'].get('id')==3 and
                      r['message'].get('result',{}).get('turn',{}).get('id')=='inert-turn' for r in wire))
            check('wire_monotonic',all(a['observed_ns']<=c['observed_ns'] for a,c in zip(wire,wire[1:])))
            if mode=='pressure':
                p=one('write_pressure_observed'); sender=one('sender_error'); one('sender_exit'); one('sender_enter'); one('peer_no_read_barrier')
                check('pressure_exposed',p.get('pipe_writable') is False and p.get('write_lock_available') is False and
                      p.get('sender_pending') is True and terminal.get('writer_pending') is True)
                check('pressure_before_failure',order('peer_no_read_barrier','sender_enter','write_pressure_observed','terminal_read','sender_error','sender_exit'))
                check('peer_stop_binding',t['peer_stopped']==d['stopped'] and d['stopped']['pid']==t['peer_pid'] and
                      d['stopped']['mode']=='stop_reading_until_terminated' and d['stopped']['at_ns']<index['peer_no_read_barrier'][0]['ns'])
                pressure=[r for r in sent if r['message'].get('method')=='synthetic/pressure']
                check('pressure_payload',len(pressure)==1 and pressure[0]['message']['params']=={'payload':'x'*2097152} and
                      index['sender_enter'][0]['ns']<pressure[0]['observed_ns']<p.get('ns',0))
                if arm=='candidate':
                    one('pipe_eagain'); one('abort_enter'); ab=one('abort_result'); waiter=one('await_error')
                    writes=[r for r in rows if r['event']=='pipe_write' and index['sender_enter'][0]['ns']<r['ns']<sender.get('ns',0)]
                    sent_count=sum(r['written_bytes'] for r in writes)
                    expected_total=len((json.dumps(pressure[0]['message'],separators=(',',':'))+'\n').encode()) if pressure else -1
                    check('partial_write_uncertainty', sender.get('kind')=='AppServerWriteUncertain' and
                          type(sender.get('sent')) is int and 0<sender['sent']<sender.get('total',0) and
                          sender['sent']==sent_count and sender.get('total')==expected_total and
                          sender.get('message')==f"app-server write uncertain: {sent_count}/{expected_total} bytes (TimeoutError)")
                    check('eagain_at_pressure',p.get('eagain_count',0)>0 and t.get('eagain_count',0)>0 and
                          order('sender_enter','pipe_eagain','write_pressure_observed') and
                          p.get('sent_bytes')==sum(r['written_bytes'] for r in rows if r['event']=='pipe_write' and r['ns']<p['ns']))
                    check('quarantined_interrupt',ir.get('result')=={'outcome':'request_error','response':{
                        'error':"AppServerWriteUncertain('app-server write uncertain: 0/0 bytes (previous send failure)')"}} and
                          order('sender_error','interrupt_result','abort_enter','abort_result','cleanup_entry'))
                    check('no_interrupt_or_turn_after_send_failure',methods==['initialize','initialized','thread/start','turn/start','synthetic/pressure'])
                    check('abort_and_waiter_retired',ab.get('result')=={'outcome':'aborted'} and waiter.get('kind')=='AppServerError' and
                          order('abort_enter','await_error','cleanup_entry'))
                else:
                    rescue=one('external_rescue_enter');one('external_rescue_return')
                    check('baseline_failure_rescued',rescued and rescue.get('unfinished_futures')==1 and
                          order('terminal_read','interrupt_enter','external_rescue_enter','sender_error','interrupt_result'))
                    check('baseline_rescue_after_3s',rescue.get('ns',0)-terminal.get('ns',0)>=3_000_000_000)
            else:
                waiter=one('await_result')
                check('control_no_pressure',not any(e in events for e in ('sender_enter','write_pressure_observed','pipe_eagain')) and terminal.get('writer_pending') is False)
                check('control_ack_completion',ir.get('result',{}).get('outcome')=='requested' and waiter.get('eligible') is False and
                      waiter.get('cancelled') is True and waiter.get('status')=='completed' and
                      methods==['initialize','initialized','thread/start','turn/start','turn/interrupt'] and
                      any(r['direction']=='received' and r['message'].get('method')=='turn/completed' for r in wire))
            should_pass=cell!='baseline-pressure'
            if should_pass:
                check('no_rescue',not any('rescue' in e for e in events))
                check('planner_close_returned',stages.get('planner_close',{}).get('status')=='returned')
                check('post_fixture_retired',t.get('watchdog_alive') is False and t.get('all_futures_done') is True and
                      type(t.get('peer_returncode')) is int and t.get('reader_alive') is False and t.get('writer_alive') is False and
                      t.get('journal_closed') is True and t.get('pending_ids')==[] and t.get('responses')==[] and
                      t.get('streams_closed')=={'stdin':True,'stdout':True,'stderr':True} and t.get('process_group_absent') is True)
                if generation=='observed':
                    before=t.get('before_fixture_close',{})
                    check('retired_before_fixture_close',all(before.get(k) is v for k,v in {
                        'peer_exited':True,'reader_alive':False,'writer_alive':False,'journal_closed':True,'stdin_closed':True,
                        'all_futures_done':True,'process_group_absent':True,'write_lock_available':True}.items()) and
                        'cached_fd' in before and before['cached_fd'] is None and before.get('pending_ids')==[] and before.get('responses')==[] and
                        before.get('streams_closed')=={'stdin':True,'stdout':True,'stderr':True})
                    check('preclose_observation_after_main',type(before.get('observed_ns')) is int and
                          before['observed_ns']>index['main_exit'][0]['ns']>terminal['ns'])
            elif generation=='observed':
                check('baseline_secondary_failure_retained',stages.get('planner_close',{}).get('error_type')=='PermissionError' and
                      'planner_close cleanup failed: PermissionError' in t['error']['notes'] and
                      t['before_fixture_close'].get('journal_closed') is False and
                      t['before_fixture_close'].get('streams_closed')=={'stdin':True,'stdout':False,'stderr':False})
    failures=[c['name'] for c in checks if not c['pass']]
    return {'status':'PASS' if not failures else 'FAIL','checks':checks,'check_count':len(checks),'failures':failures,
            'dispositions':{'first/candidate-pressure':'FIXTURE_ERROR_BEFORE_EXPOSURE',
             'corrected/candidate-pressure':'EXPOSED_NO_RESCUE_POSTCLOSE_OBSERVATION_INCOMPLETE',
             'observed/baseline-pressure':'FAILURE_RESCUED_WITH_SECONDARY_CLEANUP_ERROR',
             'observed/candidate-pressure':'SCOPED_NO_RESCUE_RETIREMENT_PASS',
             'observed/baseline-ack_complete':'CONTROL_PASS','observed/candidate-ack_complete':'CONTROL_PASS'}}

def mutations(bundle):
    controls=[]
    def run(name, target, change):
        altered=copy.deepcopy(bundle)
        change(altered)
        result=audit(altered)
        controls.append({'name':name,'expected_failure':target,'rejected':result['status']=='FAIL' and target in result['failures'],
                         'failures':result['failures']})
    def cp(b):return b['runs']['observed']['candidate-pressure']['trace']
    def row(b,event):return next(r for r in cp(b)['timeline'] if r['event']==event)
    p='observed.candidate-pressure.'
    run('loaded_dependency_hash',p+'loaded_dependency_sources.binding',lambda b:cp(b)['loaded_dependency_sources']['doom_hud_signal_v3'].__setitem__('sha256','0'*64))
    run('source_bytes','source.candidate.independent_pins',lambda b:b['sources']['candidate'].__setitem__(CLIENT_PATH,b'# mutation\n'+b['sources']['candidate'][CLIENT_PATH]))
    run('pipe_writable',p+'pressure_exposed',lambda b:row(b,'write_pressure_observed').__setitem__('pipe_writable',True))
    run('no_eagain',p+'eagain_at_pressure',lambda b:row(b,'write_pressure_observed').__setitem__('eagain_count',0))
    run('failure_after_sender_exit',p+'pressure_before_failure',lambda b:row(b,'terminal_read').__setitem__('ns',row(b,'sender_exit')['ns']+1))
    run('rescue_in_candidate',p+'no_rescue',lambda b:cp(b)['timeline'].append({'event':'external_rescue_enter','ns':cp(b)['before_fixture_close']['observed_ns']}))
    run('primary_error_overwritten',p+'primary_error',lambda b:cp(b)['error'].__setitem__('message','transport error'))
    run('missing_futures_readout',p+'retired_before_fixture_close',lambda b:cp(b)['before_fixture_close'].pop('all_futures_done'))
    run('live_reader_before_close',p+'retired_before_fixture_close',lambda b:cp(b)['before_fixture_close'].__setitem__('reader_alive',True))
    run('group_remains_before_close',p+'retired_before_fixture_close',lambda b:cp(b)['before_fixture_close'].__setitem__('process_group_absent',False))
    run('extra_submit',p+'single_submit',lambda b:cp(b)['commands'].append(copy.deepcopy(cp(b)['commands'][0])))
    run('final_admission',p+'no_final_admission',lambda b:cp(b)['timeline'].append({'event':'final_admission','ns':cp(b)['before_fixture_close']['observed_ns']}))
    run('interrupt_journal_after_quarantine',p+'no_interrupt_or_turn_after_send_failure',lambda b:b['runs']['observed']['candidate-pressure']['wire'].append({'direction':'sent','observed_ns':row(b,'interrupt_result')['ns'],'message':{'method':'turn/interrupt','id':5}}))
    run('wrong_partial_count',p+'partial_write_uncertainty',lambda b:row(b,'sender_error').__setitem__('sent',0))
    run('lowered_interrupt_deadline',p+'settings_unchanged',lambda b:cp(b)['settings'].__setitem__('interrupt_default_timeout_s',.75))
    run('missing_abort_actor',p+'exactly_one.abort_result',lambda b:cp(b).__setitem__('timeline',[r for r in cp(b)['timeline'] if r['event']!='abort_result']))
    run('first_fixture_error_erased','first.candidate-pressure.history.fixture_error_preserved',lambda b:b['runs']['first']['candidate-pressure']['trace']['error'].__setitem__('type','RuntimeError'))
    run('baseline_rescue_erased','observed.baseline-pressure.baseline_failure_rescued',lambda b:b['runs']['observed']['baseline-pressure']['trace'].__setitem__('timeline',[r for r in b['runs']['observed']['baseline-pressure']['trace']['timeline'] if r['event']!='external_rescue_enter']))
    return {'status':'PASS' if all(c['rejected'] for c in controls) else 'FAIL','count':len(controls),'controls':controls,
            'method':'Each semantic mutation runs independently on a deep copy; expected named predicate must fail. No input files changed.'}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence-root',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=False)
    b=load(args.evidence_root.resolve())
    result=audit(b); controls=mutations(b)
    for name,obj in [('result.json',result),('mutations.json',controls),('input-sha256.json',b['input_sha256'])]:
        (args.output/name).write_text(json.dumps(obj,indent=2)+'\n')
    print(json.dumps({'audit':result['status'],'checks':result['check_count'],'failures':result['failures'],
                      'mutations':controls['status'],'mutation_count':controls['count']}))
    return 0 if result['status']==controls['status']=='PASS' else 1

if __name__=='__main__':
    raise SystemExit(main())

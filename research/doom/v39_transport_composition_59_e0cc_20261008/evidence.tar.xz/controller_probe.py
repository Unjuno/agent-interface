"""Actual V39/client/adapter/pool, inert real peer, synthetic session/cleanup seam."""
from concurrent.futures import ThreadPoolExecutor
from contextlib import ExitStack
import argparse
import copy
import json
import os
from pathlib import Path
import platform
import queue
import hashlib
import select
import sys
import threading
import time
from types import SimpleNamespace
from unittest.mock import patch

ap = argparse.ArgumentParser()
ap.add_argument("--source", type=Path, required=True)
ap.add_argument("--out", type=Path, required=True)
ap.add_argument("--mode", choices=["pressure", "ack_complete"], required=True)
args = ap.parse_args()
args.out.mkdir(parents=True, exist_ok=False)
source = args.source.resolve()
sys.path[:0] = [str(source / "research/doom"), str(source / "research/live_control")]
import map01_overlap_controller_v39 as controller
import codex_app_server_client_v2 as client_module
import persistent_planner_adapter_v2 as adapter_module
from codex_app_server_client_v2 import CodexAppServerClient
from persistent_planner_adapter_v2 import PersistentPlannerAdapter

trace = {"mode": args.mode, "timeline": [], "commands": [], "events": [],
         "python": sys.version, "platform": platform.platform(), "machine": platform.machine(),
         "clock": "perf_counter_ns", "no_model_or_native_input": True}
lock = threading.Lock()
started = threading.Event()
interrupted = threading.Event()
finished = threading.Event()
futures = []
fatal_seen = threading.Event()
writer_done = threading.Event()
writer = None
eagain_count = 0
sent_bytes = 0
write_calls = 0
trace["settings"] = {"sender_timeout_s": .75, "interrupt_default_timeout_s": 30, "planner_timeout_s": 90, "rescue_after_fatal_s": 3, "payload_bytes": 2 * 1024 * 1024}
trace["loaded_sources"] = {m.__name__: {"path": str(Path(m.__file__).resolve()), "sha256": hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()} for m in (controller, client_module, adapter_module)}


def record(event, **fields):
    with lock:
        trace["timeline"].append({"event": event, "ns": time.perf_counter_ns(), **fields})


# Construct before patching the session's Popen seam. The production client's
# default process factory is the real subprocess.Popen and owns a POSIX group.
client = CodexAppServerClient(
    [sys.executable, "-u", str(Path(__file__).with_name("inert_peer.py")), args.mode, str(args.out / "peer-stopped.json")],
    journal_path=str(args.out / "wire.jsonl"))
trace["peer_pid"] = client.process.pid
trace["owns_process_group"] = client._owns_process_group
stdin_fd = client.process.stdin.fileno()
trace["stdin_fd"] = stdin_fd
(args.out / "peer_identity.json").write_text(json.dumps({
    "pid": client.process.pid,
    "command": [sys.executable, "-u", str(Path(__file__).with_name("inert_peer.py")), args.mode]
}) + "\n")


class Planner(PersistentPlannerAdapter):
    def await_turn(self, handle, timeout=120):
        record("await_enter", timeout=timeout)
        started.set()
        try:
            result = super().await_turn(handle, timeout)
        except BaseException as error:
            record("await_error", kind=type(error).__name__, message=str(error))
            raise
        record("await_result", eligible=result.answer_eligible,
               cancelled=result.cancellation_requested, status=result.status)
        return result

    def interrupt(self, handle):
        record("interrupt_enter", thread=handle.thread_id, turn=handle.turn_id)
        try:
            result = super().interrupt(handle)
            record("interrupt_result", result=result)
            return result
        finally:
            interrupted.set()

    def abort_pending_turn(self):
        record("abort_enter")
        try:
            result = super().abort_pending_turn()
        except BaseException as error:
            record("abort_error", kind=type(error).__name__, message=str(error))
            raise
        record("abort_result", result=result)
        return result


planner = Planner(client, model="inert-peer-no-model", effort="low", cwd=source,
                  base_instructions="Synthetic protocol construction only")


def rescue():
    if not fatal_seen.wait(5):
        if finished.is_set():
            return
        record("rescue_no_fatal")
    elif finished.wait(3):
        return
    record("external_rescue_enter", unfinished_futures=sum(not f.done() for f in futures))
    try:
        client.close(timeout=1)
    except BaseException as error:
        record("external_rescue_error", kind=type(error).__name__, message=str(error))
    record("external_rescue_return")


def send_pressure():
    record("sender_enter")
    try:
        client.request("synthetic/pressure", {"payload": "x" * (2 * 1024 * 1024)}, timeout=.75)
    except BaseException as error:
        record("sender_error", kind=type(error).__name__, message=str(error),
               sent=getattr(error, "sent", None), total=getattr(error, "total", None))
    else:
        record("sender_unexpected_success")
    finally:
        writer_done.set()
        record("sender_exit")


real_os_write = os.write

def observe_write(fd, data):
    global eagain_count, sent_bytes, write_calls
    try:
        count = real_os_write(fd, data)
    except BlockingIOError:
        if fd == stdin_fd:
            eagain_count += 1
            if eagain_count <= 4:
                record("pipe_eagain", requested_bytes=len(data))
        raise
    if fd == stdin_fd:
        sent_bytes += count
        write_calls += 1
        if write_calls <= 6:
            record("pipe_write", requested_bytes=len(data), written_bytes=count)
    return count


def prepare_pressure():
    global writer
    stop_path = args.out / "peer-stopped.json"
    end = time.monotonic() + 2
    while not stop_path.exists():
        if time.monotonic() >= end:
            raise RuntimeError("fixture peer did not establish no-read barrier")
        time.sleep(.001)
    trace["peer_stopped"] = json.loads(stop_path.read_text())
    record("peer_no_read_barrier")
    writer = threading.Thread(target=send_pressure, name="construction-large-sender")
    writer.start()
    end = time.monotonic() + .5
    while time.monotonic() < end:
        writable = bool(select.select([], [stdin_fd], [], 0)[1])
        got_lock = client._write_lock.acquire(blocking=False)
        if got_lock:
            client._write_lock.release()
        if not writable and not got_lock and writer.is_alive() and not writer_done.is_set():
            record("write_pressure_observed", pipe_writable=False, write_lock_available=False,
                   sender_pending=True, eagain_count=eagain_count, sent_bytes=sent_bytes)
            return
        if writer_done.is_set():
            break
        time.sleep(.001)
    raise RuntimeError("fixture did not establish pending writer pressure")


watchdog = threading.Thread(target=rescue, name="construction-rescue")


class Incoming(queue.Queue):
    def get(self, *a, **kw):
        row = super().get(*a, **kw)
        if row["event"] == "terminal":
            if not started.wait(2):
                raise RuntimeError("planner waiter did not start")
            record("terminal_read", pending=not futures[0].done(), writer_pending=writer is not None and writer.is_alive())
            fatal_seen.set()
        trace["events"].append(copy.deepcopy(row))
        return row


incoming = Incoming()
incoming.put({"event": "ready", "fixture": {"loaded": True}})
incoming.put({"event": "observation", "sequence": 1, "capture_ns": 100,
              "image": "synthetic.png", "step": 0,
              "pointer_binding": {"focus": 7, "surface": 7}})


class Stdin:
    def write(self, value):
        command = json.loads(value)
        trace["commands"].append(command)
        record("session_write", op=command["op"])
        if command["op"] != "submit" or len(trace["commands"]) != 1:
            raise RuntimeError("unexpected continuation after failed cover")
        incoming.put({"event": "accepted", "id": command["id"], "accepted_ns": 105,
                      "steps": [], "program_sha256": "synthetic", "intent_token": "test"})
        incoming.put({"event": "terminal", "id": command["id"], "status": "failed",
                      "terminal_ns": 120, "error": "injected input error",
                      "release": {"verified": True, "keys_down": [], "buttons_down": []}})

    def flush(self):
        pass


process = SimpleNamespace(stdin=Stdin(), stdout=iter(()), poll=lambda: 0)


class Pool(ThreadPoolExecutor):
    def submit(self, *a, **kw):
        future = super().submit(*a, **kw)
        futures.append(future)
        if not started.wait(2):
            raise RuntimeError("planner future did not enter await")
        if args.mode == "pressure":
            prepare_pressure()
        return future


class Reader:
    def __init__(self, *a, signal_id):
        self.signal_id = signal_id

    def read(self, observation):
        return {"format": "observable-signal-v1", "status": "observed",
                "signal_id": self.signal_id, "value": 90,
                "sequence": observation["sequence"], "capture_ns": observation["capture_ns"],
                "binding": observation["pointer_binding"]}


class CleanupSpy(controller.ControllerFailureCleanup):
    def __exit__(self, kind, error, tb):
        record("cleanup_entry", error=kind.__name__, futures_done=all(f.done() for f in futures))
        result = super().__exit__(kind, error, tb)
        record("cleanup_return")
        return result


def final_admission(*a):
    record("final_admission")
    raise RuntimeError("unexpected final admission")


def begin(*a, **kw):
    return planner.begin_turn("inert scripted observation", output_schema={})


original_read = Path.read_text


def read_text(path, *a, **kw):
    if path.name == "map01_cover_policy_schema_v6.json":
        return "{}"
    if path.name == "map01_motor_responder_v10.txt":
        return "synthetic"
    return original_read(path, *a, **kw)


argv = ["controller", "--out", str(args.out / "controller"), "--iterations", "1",
        "--model", "inert-peer-no-model", "--effort", "low",
        "--load-fixture-manifest", str(args.out / "synthetic-fixture.json")]
monitor = SimpleNamespace(event_types=set(), soft_event_count=0, latest_soft_event=None)
replacements = [
    patch.object(os, "write", observe_write),
    patch.object(sys, "argv", argv),
    patch.object(controller, "CodexAppServerClient", return_value=client),
    patch.object(controller, "PersistentPlannerAdapter", return_value=planner),
    patch.object(controller, "ThreadPoolExecutor", Pool),
    patch.object(controller.subprocess, "Popen", return_value=process),
    patch.object(controller.queue, "Queue", return_value=incoming),
    patch.object(controller, "ControllerFailureCleanup", CleanupSpy),
    patch.object(controller, "DoomStatusNumberReader", Reader),
    patch.object(controller, "refresh_source", side_effect=lambda latest, *a: (
        latest, {"status": "already_observed"})),
    patch.object(controller, "build_cover_monitor", return_value=(
        monitor, {"status": "admitted", "authored": None})),
    patch.object(controller, "temporal_sheet"),
    patch.object(controller, "begin_model_turn", begin),
    patch.object(controller, "final_admission_from_planner_result", final_admission),
    patch.object(controller, "win", side_effect=str),
    patch.object(Path, "read_text", read_text),
]
watchdog.start()
try:
    with ExitStack() as stack:
        for replacement in replacements:
            stack.enter_context(replacement)
        record("main_enter")
        try:
            controller.main()
        except BaseException as error:
            trace["error"] = {"type": type(error).__name__, "message": str(error),
                              "notes": getattr(error, "__notes__", [])}
            record("main_error", kind=type(error).__name__)
        finally:
            finished.set()
            record("main_exit", peer_exited=client.process.poll() is not None,
                   reader_alive=client._reader.is_alive())
finally:
    watchdog.join(timeout=7)
    if writer is not None:
        writer.join(timeout=2)
    trace["before_fixture_close"] = {"peer_exited": client.process.poll() is not None, "reader_alive": client._reader.is_alive(), "writer_alive": writer is not None and writer.is_alive(), "journal_closed": client._journal.closed, "stdin_closed": client.process.stdin.closed, "cached_fd": getattr(client, "_stdin_fd", None)}
    before = trace["before_fixture_close"]
    before["observed_ns"] = time.perf_counter_ns()
    before["all_futures_done"] = bool(futures) and all(f.done() for f in futures)
    before["streams_closed"] = {n: getattr(client.process,n).closed for n in ("stdin", "stdout", "stderr")}
    with client._condition:
        before["pending_ids"] = sorted(client._pending)
        before["responses"] = sorted(client._responses)
    before["write_lock_available"] = client._write_lock.acquire(blocking=False)
    if before["write_lock_available"]:
        client._write_lock.release()
    try:
        os.killpg(client.process.pid, 0)
    except ProcessLookupError:
        before["process_group_absent"] = True
    else:
        before["process_group_absent"] = False
    trace["loaded_dependency_sources"] = {}
    for name, module in list(sys.modules.items()):
        path = getattr(module, "__file__", None)
        if path and "/research/" in path and Path(path).is_file():
            path = Path(path).resolve()
            trace["loaded_dependency_sources"][name] = {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
    try:
        client.close(timeout=1)
    except BaseException as error:
        trace["fixture_close_error"] = {"kind": type(error).__name__, "message": str(error)}
    controller.atexit.unregister(client.close)
    trace["watchdog_alive"] = watchdog.is_alive()
    trace["all_futures_done"] = bool(futures) and all(f.done() for f in futures)
    trace["peer_returncode"] = client.process.poll()
    trace["reader_alive"] = client._reader.is_alive()
    trace["journal_closed"] = client._journal.closed
    trace["pending_ids"] = sorted(client._pending)
    trace["responses"] = sorted(client._responses)
    trace["writer_alive"] = writer is not None and writer.is_alive()
    trace["eagain_count"] = eagain_count
    trace["os_write_bytes"] = sent_bytes
    trace["streams_closed"] = {n: getattr(client.process,n).closed for n in ("stdin", "stdout", "stderr")}
    try:
        os.killpg(client.process.pid, 0)
    except ProcessLookupError:
        trace["process_group_absent"] = True
    else:
        trace["process_group_absent"] = False
    with (args.out / "trace.json").open("x") as f:
        json.dump(trace, f, indent=2)
print(json.dumps({"mode": args.mode, "error": trace.get("error"),
                  "rescued": any(r["event"] == "external_rescue_enter" for r in trace["timeline"]),
                  "retired": trace["all_futures_done"] and not trace["reader_alive"] and
                             trace["peer_returncode"] is not None and trace["process_group_absent"]}))

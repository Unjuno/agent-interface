import ast, datetime, hashlib, json, os, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent/'perkey-owner-guard-repo-e0cc-20261005'
modules=['test_map01_overlap_controller_v39_cover_terminal','test_persistent_planner_adapter_v2','test_overlap_controller_v39_wait','test_controller_failure_cleanup_v1','test_controller_failure_cleanup_finish_send_wait_v1','test_controller_failure_cleanup_stage_v1','test_controller_failure_cleanup_portability_v1','test_codex_app_server_send_deadline_v1','test_app_server_known_eof','test_app_server_runtime_eligibility','test_app_server_send_snapshot','test_appserver_bounded_close_e0cc','test_app_server_eof_stop','test_app_server_reply_id_5156','test_appserver_utf8_2d0b','test_app_server_utf8','test_appserver_process_tree_cleanup_20261004','test_appserver_write_admission_e0cc','test_appserver_journal_close_01a0ff2d','test_appserver_reader_retirement_01a0ff2d']
tracked=subprocess.check_output(['git','ls-tree','-r','--name-only','HEAD'],cwd=REPO,text=True).splitlines()
modpaths={p[:-3].replace('/','.'):p for p in tracked if p.endswith('.py')}
for p in tracked:
 if p.endswith('.py') and len(Path(p).parts)==3 and p.startswith(('research/doom/','research/live_control/')):modpaths[Path(p).stem]=p
# New paths are not in HEAD yet.
for d in ('research/doom','research/live_control'):
 for p in (REPO/d).glob('*.py'):modpaths[p.stem]=str(p.relative_to(REPO))
pending=[modpaths[m] for m in modules]; seen=set(); restored=[]
while pending:
 p=pending.pop()
 if p in seen:continue
 seen.add(p);f=REPO/p
 if not f.exists():
  subprocess.run(['git','restore','--ignore-skip-worktree-bits','--source','HEAD','--',p],cwd=REPO,check=True);restored.append(p)
 tree=ast.parse(f.read_text())
 for n in ast.walk(tree):
  names=([n.module] if isinstance(n,ast.ImportFrom) and n.module else [v.name for v in n.names] if isinstance(n,ast.Import) else [])
  if isinstance(n,ast.ImportFrom) and n.module:
   names += [n.module+'.'+v.name for v in n.names]
  pending.extend(modpaths[name] for name in names if name in modpaths and modpaths[name] not in seen)
env=dict(os.environ,DISPLAY='',PYTHONDONTWRITEBYTECODE='1')
env['PYTHONPATH']=os.pathsep.join([str(REPO/'research/doom'),str(REPO/'research/live_control'),str(REPO),str(ROOT.parent/'pr8308-held-modifiers-review-e0cc-20261007/deps')])
command=[sys.executable,'-B','-m','unittest','-v',*modules]
record={'command':command,'cwd':str(REPO),'environment':{k:env[k] for k in ('DISPLAY','PYTHONPATH','PYTHONDONTWRITEBYTECODE')},'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_hashes':{p:hashlib.sha256((REPO/p).read_bytes()).hexdigest() for p in sorted(seen)},'restored_sparse_paths':restored}
(ROOT/'FOCUSED_INTENT.json').write_text(json.dumps(record,indent=2)+'\n')
with (ROOT/'focused.stdout.txt').open('w') as out,(ROOT/'focused.stderr.txt').open('w') as err:
 r=subprocess.run(command,cwd=REPO,env=env,stdout=out,stderr=err,timeout=120)
record.update(returncode=r.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(ROOT/'FOCUSED_RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'returncode':r.returncode,'modules':len(modules),'source_files':len(seen),'restored':len(restored)}))
print('\n'.join((ROOT/'focused.stderr.txt').read_text().splitlines()[-12:]))
raise SystemExit(r.returncode)

import ast, hashlib, json, subprocess
from pathlib import Path
REPO=Path('<CHECKOUT>')
ROOT=Path(__file__).resolve().parent
BASE='d4ac01bcb8bfc3a9eb13c8b00f43cb3ef02eccac'
COVER='e851a2e93c1b995fefa630c7e36a78680fc80e59'
CLIENT='fd14d9ed655192b90c38c8509aa769f79f6fb745'
def blob(ref,path): return subprocess.check_output(['git','show',f'{ref}:{path}'],cwd=REPO)
def write(root,path,data):
 p=root/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
controller='research/doom/map01_overlap_controller_v39.py'
adapter='research/live_control/persistent_planner_adapter_v2.py'
client='research/live_control/codex_app_server_client_v2.py'
a=blob(BASE,controller).decode(); b=blob(COVER,controller).decode()
helper=b[b.index('def require_cover_terminal('):b.index('def cancel_invalidated_cover(')]
a=a.replace('def cancel_invalidated_cover(',helper+'def cancel_invalidated_cover(',1)
start=b.index('                    failure_cleanup.set_stage("cover_terminal_validation")')
end=b.index('                    if future.done():break',start)
needle='                    cover_terminals.append(current_terminal)\n                    if future.done():break'
assert a.count(needle)==1
a=a.replace(needle,'                    cover_terminals.append(current_terminal)\n'+b[start:end]+'                    if future.done():break')
needle='            final_action_admission=final_admission_from_planner_result('
assert a.count(needle)==1
a=a.replace(needle,'            failure_cleanup.set_stage("cover_terminal_validation")\n            require_cover_terminal(current_terminal, cancellation_requested=True)\n'+needle)
old=ROOT.parent/'v39_interrupt_ack_e0cc_20261007/candidate/source'
paths=[str(p.relative_to(old)) for p in old.rglob('*.py')]
source={controller:blob(BASE,controller), adapter:blob(BASE,adapter), client:blob(BASE,client)}
source[controller]=a.encode();source[adapter]=blob(COVER,adapter)
# Follow local bare-module imports across the two research directories.
tracked=subprocess.check_output(['git','ls-tree','-r','--name-only',BASE,'--','research/doom','research/live_control'],cwd=REPO,text=True).splitlines()
byname={Path(p).stem:p for p in tracked if Path(p).suffix=='.py' and len(Path(p).parts)==3}
while True:
 need=set()
 for p,data in list(source.items()):
  tree=ast.parse(data)
  for node in ast.walk(tree):
   mods=([node.module] if isinstance(node,ast.ImportFrom) and node.module else [n.name for n in node.names] if isinstance(node,ast.Import) else [])
   for mod in mods:
    path=byname.get(mod)
    if path and path not in source: need.add(path)
 if not need:break
 for p in sorted(need):source[p]=blob(BASE,p)
for arm in ('baseline','candidate'):
 for p,data in source.items():write(ROOT/arm/'source',p,data)
 write(ROOT/arm/'source',client,blob(BASE if arm=='baseline' else CLIENT,client))
for p in (controller,adapter,client):write(REPO,p,(ROOT/'candidate/source'/p).read_bytes())
# Keep the existing focused regressions and their compatibility fixtures.
paths8320=[p for p in subprocess.check_output(['git','diff','--name-only',BASE,CLIENT,'--','research/live_control'],cwd=REPO,text=True).splitlines() if Path(p).name.startswith('test_')]
for p in paths8320:write(REPO,p,blob(CLIENT,p))
for p in ('research/doom/test_map01_overlap_controller_v39_cover_terminal.py','research/live_control/test_persistent_planner_adapter_v2.py'):write(REPO,p,blob(COVER,p))
p='research/live_control/test_appserver_process_tree_cleanup_20261004.py'
write(REPO,p,blob('9125b94f9de45db74503c7937e0fb9833a6cdf86',p))
(ROOT/'SOURCE_ORIGIN.json').write_text(json.dumps({'base':BASE,'cover':COVER,'client':CLIENT,'source_files_per_arm':len(source),'controller_transplant':'helper; pending fatal block; post-result terminal validation only','adapter':'exact #8280 blob','client_candidate':'exact #8320 blob','tests_posix_guards':'#8290 head 9125b94'},indent=2)+'\n')
print(json.dumps({'source_files_per_arm':len(source),'transport_tests':len(paths8320)}))

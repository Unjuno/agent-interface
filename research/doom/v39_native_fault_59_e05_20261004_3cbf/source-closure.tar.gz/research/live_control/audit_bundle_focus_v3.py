"""Separate physical stop evidence, failed injection and missing reason evidence."""
import json
from pathlib import Path
from audit_cause_servo_v2 import frames,read
from report_pages_v2 import digest

HERE=Path(__file__).resolve().parent;rows=[]
for cohort in ('bundle-focus-04',):
    root=HERE/'results'/cohort;plan=read(root/'plan.json')
    for name,sha in plan['sources'].items():assert digest((HERE/name).read_bytes())==sha
    assert digest((HERE/'results/bundle-pair-01/B/bundle/steps.json').read_bytes())==plan['bundle_source_sha256']
    for name,target,kind in plan['cases']:
        directory=root/name;r=read(directory/'report.json');events=r['events']
        observed=frames(directory,events)
        terminals=[e for e in events if e['event']=='terminal'];first=terminals[0]
        injected=r.get('physical_down_verified') is True and r.get('physical_release_while_output_blocked') is True
        if not injected:
            assert cohort=='bundle-focus-01' and kind=='key'
            assert r['success'] is False and r['error']=="AssertionError('target admission not reached')"
            assert first['status']=='completed' and first['steps_completed']==9 and first['interruption'] is None
            rows.append(dict(cohort=cohort,case=name,classification='injector never triggered; not a focus test',
                             exact_frames=len(observed),probe_success=False));continue
        assert r['foreign_focus_persisted_without_input']
        post=first['post_release_observation'];assert post['captures']==2 and not post['stopped'] and post['error'] is None
        stopped=[e for e in events if e['event']=='input_stopped'];assert len(stopped)==1
        passive=[e for e in events if e['event']=='observation' and e['sequence'] in post['sequences']]
        assert len(passive)==2
        sink_focus=passive[0]['input_focus_before']
        initial=next(e for e in events if e['event']=='observation')
        assert sink_focus!=initial['input_focus_before']
        for e in passive:
            assert e['input_focus_before']==sink_focus==e['input_focus_after']
            for side in ('input_state_before','input_state_after'):
                state=e[side]
                assert not state['owned_buttons'] and not state['owned_keycodes'] and state['active_lease_deadline_ns'] is None
        after_stop=[e for e in events if stopped[0]['probe_emitted_ns']<e['probe_emitted_ns']<first['probe_emitted_ns']]
        assert len(after_stop)==2 and all(e['event']=='observation' for e in after_stop)
        cause=first['interruption']['record']
        assert cause in r['owner_records'] and cause['reason']=='focus_changed' and cause['verified']
        assert not cause['buttons_down'] and not cause['keys_down']
        assert first['status']=='needs_decision' and first['steps_completed']==target
        assert first['release']['verified'] and not first['release']['buttons_down'] and not first['release']['keys_down']
        current=None;admissions=[]
        for e in events:
            if e['event']=='step_started':current=(e['id'],e['step'])
            elif e['event'] in ('pointer_admission','input_admission'):
                assert current and current[0]=='bundle' and current[1]<=target
                assert e['admitted_ns']<=cause['verified_ns']
                admissions.append((current,e))
        if kind=='key':
            assert [(e['key']) for _,e in admissions if e['event']=='input_admission']==['Control_L']
            assert first['decision_reason']=='focus_changed' and r['success']
            assert len(terminals)==2 and terminals[1]['status']=='completed' and terminals[1]['interruption'] is None
            assert terminals[1]['decision_reason'] is None
            accepted=[e for e in events if e['event']=='accepted']
            assert len(accepted)==2 and accepted[0]['valid_until_ns']==accepted[1]['valid_until_ns']
        else:
            assert first['decision_reason']=='focus_changed' and r['success']
            assert len(terminals)==2 and terminals[1]['status']=='completed' and terminals[1]['interruption'] is None
        assert all(v=='close returned' for v in r['cleanup'].values())
        rows.append(dict(cohort=cohort,case=name,classification='physical release and no-tail verified',
                         probe_success=r['success'],exact_frames=len(observed),completed_prefix_steps=target,
                         decision_reason=first['decision_reason'],recorded_cause=cause['reason'],
                         release_to_terminal_ms=(first['terminal_ns']-cause['verified_ns'])/1e6,
                         fresh_observation_isolation_verified=True))
output=dict(audit_passed=True,rows=rows,audit_sha256=digest(Path(__file__).read_bytes()),
            limits='Scripted actual X11 backend trials, not live socket/model delivery or complete fault coverage. Original failed probes retained. No rollback/unchanged-task claim. Persistent unrelated X11 focus verified through passive captures and fresh same-deadline observation; no foreign-window input.')
out=HERE/'results/bundle-focus-audit-03.json'
with out.open('x') as f:json.dump(output,f,indent=2);f.write('\n')
print(json.dumps(output))

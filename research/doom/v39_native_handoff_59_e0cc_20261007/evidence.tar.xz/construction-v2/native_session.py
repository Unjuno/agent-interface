#!/usr/bin/env python3
"""Synthetic X11 child for an ordinary V39-to-V15 handoff construction.

The child runs the real measured V15 backend and ExecutorV13 against a private
Xvfb window. It is explicitly synthetic: no game, HUD, model or task-effect
claim is made. Parent and child use synthetic_signal.SyntheticPixelSignalReader.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import platform
import select
import socket
import subprocess
import sys
import threading
import time
import traceback

from PIL import Image, ImageDraw

from synthetic_signal import SYNTHETIC_RGB, build_readers


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def safe(value):
    if value is None or type(value) in (str, int, float, bool):
        return value
    if isinstance(value, bytes):
        return value.hex()
    if isinstance(value, dict):
        return {str(k): safe(v) for k, v in value.items()}
    if isinstance(value, (tuple, list, set)):
        return [safe(v) for v in value]
    return repr(value)


def wait_display(proc, timeout=5):
    ready, _, _ = select.select([proc.stdout], [], [], timeout)
    if not ready:
        raise TimeoutError("Xvfb did not publish display number")
    value = proc.stdout.readline()
    if not value or not value.strip().isdigit():
        raise RuntimeError("invalid Xvfb displayfd response")
    return ":" + value.decode("ascii").strip()


def raw_owner(owner):
    current = owner
    for _ in range(5):
        child = getattr(current, "_inner", None)
        if child is None:
            return current
        current = child
    return current


def loaded_sources(source_root):
    found = {}
    for name, module in sorted(sys.modules.items()):
        filename = getattr(module, "__file__", None)
        if not filename:
            continue
        try:
            path = Path(filename).resolve()
            rel = path.relative_to(source_root)
        except (OSError, ValueError):
            continue
        if path.is_file():
            found[str(rel)] = sha256(path)
    return found


def runtime_controls():
    membership = Path("/proc/self/cgroup").read_text(encoding="utf-8").strip()
    relative = next((row.split(":", 2)[2].lstrip("/")
                     for row in membership.splitlines()
                     if row.startswith("0::")), None)
    root = Path("/sys/fs/cgroup").resolve()
    cgroup = (root / relative).resolve() if relative is not None else None
    values = {"uid": os.getuid(), "cgroup_membership": membership,
              "network_namespace": os.readlink("/proc/self/ns/net"),
              "network_interfaces": socket.if_nameindex()}
    for name in ("cpu.max", "memory.max", "memory.swap.max", "pids.max"):
        try:
            if cgroup is None or not cgroup.is_relative_to(root):
                raise OSError("unified cgroup path unavailable")
            values[name] = (cgroup / name).read_text(encoding="utf-8").strip()
        except OSError as exc:
            values[name] = {"unavailable": repr(exc)}
    for name, argv in {
        "ip_address_json": ["ip", "-j", "address"],
        "ip_route4_json": ["ip", "-j", "-4", "route", "show", "table", "all"],
        "ip_route6_json": ["ip", "-j", "-6", "route", "show", "table", "all"],
    }.items():
        try:
            result = subprocess.run(argv, capture_output=True, text=True,
                                    timeout=2, check=False)
            values[name] = {"returncode": result.returncode,
                            "stdout": result.stdout, "stderr": result.stderr}
        except BaseException as exc:
            values[name] = {"unavailable": repr(exc)}
    return values


class EventWriter:
    def __init__(self, out):
        self.out = out
        self.lock = threading.RLock()
        self.rows = []
        self.protocol_path = out / "events.jsonl"
        self.delivered_path = out / "delivered.jsonl"
        self.protocol_path.open("x").close()
        self.delivered_path.open("x").close()

    def emit(self, row):
        with self.lock:
            item = copy.deepcopy(row)
            item["emit_ns"] = time.perf_counter_ns()
            encoded = json.dumps(safe(item), sort_keys=True)
            with self.protocol_path.open("a", encoding="utf-8") as stream:
                stream.write(encoded + "\n")
            with self.delivered_path.open("a", encoding="utf-8") as stream:
                stream.write(encoded + "\n")
            self.rows.append(item)
            print(encoded, flush=True)
            return item


class SyntheticSession:
    def __init__(self, name, display, window_id):
        self.name = name
        self.d = display
        self.window = display.create_resource_object("window", int(window_id))

    def context(self):
        geo = self.window.get_geometry()
        return {"environment": "synthetic private Xvfb; no game",
                "active_window": int(self.window.id),
                "screen": [int(self.d.screen().width_in_pixels),
                           int(self.d.screen().height_in_pixels)],
                "window_geometry": [int(geo.x), int(geo.y),
                                    int(geo.width), int(geo.height)]}


class PixelTrigger:
    """Observe the recipient's real X11 KeyPress and then change one pixel."""
    def __init__(self, name, window, observer, keycode, mode, event_path):
        self.name, self.window, self.observer = name, window, observer
        self.keycode, self.mode, self.event_path = keycode, mode, event_path
        self.stop = threading.Event()
        self.rows = []
        self.lock = threading.Lock()
        self.changed = False
        self.error = None
        self.thread = threading.Thread(target=self._run, name="synthetic-pixel-observer",
                                       daemon=False)

    def start(self):
        self.thread.start()

    def _write(self, row):
        item = {**row, "observed_ns": time.perf_counter_ns()}
        with self.lock:
            self.rows.append(item)
            with self.event_path.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(item, sort_keys=True) + "\n")

    def _set_pixel(self, rgb):
        # Root pixel (30,30) equals window-local pixel (10,10).
        color = (rgb[0] << 16) | (rgb[1] << 8) | rgb[2]
        gc = self.window.create_gc(foreground=color)
        self.window.fill_rectangle(gc, 10, 10, 1, 1)
        gc.free()
        self.observer.sync()

    def _run(self):
        try:
            while not self.stop.is_set() or self.observer.pending_events():
                if not self.observer.pending_events():
                    self.stop.wait(0.005)
                    continue
                event = self.observer.next_event()
                if event.type not in (2, 3):
                    continue
                event_window = getattr(event, "window", None)
                event_window_id = int(getattr(event_window, "id", event_window))
                row = {"type": "KeyPress" if event.type == 2 else "KeyRelease",
                       "detail": int(event.detail), "time": int(event.time),
                       "event_window": event_window_id,
                       "send_event": bool(event.send_event)}
                self._write(row)
                if (event.type == 2 and int(event.detail) == self.keycode and
                        event_window_id == int(self.window.id) and not self.changed):
                    self._write({"type": "signal_trigger_observed", "keycode": self.keycode,
                                 "mode": self.mode})
                    if self.mode == "drop":
                        time.sleep(0.2)
                        bitmap = self.observer.query_keymap()
                        down_witness_ns = time.perf_counter_ns()
                        a_down = bool(bitmap[self.keycode // 8] & (1 << (self.keycode % 8)))
                        self._set_pixel(SYNTHETIC_RGB["health_60"])
                        self.changed = True
                        self._write({"type": "pixel_changed", "rgb": list(SYNTHETIC_RGB["health_60"]),
                                     "a_down_before_change": a_down,
                                     "down_witness_ns": down_witness_ns,
                                     "screen_pixel": [30, 30], "window_pixel": [10, 10]})
        except BaseException as exc:
            self.error = {"type": type(exc).__name__, "message": str(exc),
                          "traceback": traceback.format_exc()}
            self._write({"type": "observer_error", **self.error})


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--source-root", required=True, type=Path)
    parser.add_argument("--signal-mode", choices=("stable", "drop"), required=True)
    # Accept the production child command's inert fixture/seed options so the
    # parent can change only the session-command seam.
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--timeout-seconds", type=int, default=60)
    parser.add_argument("--skill", type=int, default=1)
    parser.add_argument("--load-fixture-manifest", type=Path)
    args = parser.parse_args(argv)

    out = args.out.expanduser().resolve()
    out.mkdir(parents=True, exist_ok=False)
    source_root = args.source_root.expanduser().resolve()
    if not source_root.is_dir():
        raise FileNotFoundError(source_root)
    writer = EventWriter(out)
    raw_path = out / "native-raw.json"
    native_path = out / "native-events.jsonl"
    native_path.open("x", encoding="utf-8").close()
    xvfb_err = (out / "xvfb.stderr").open("x", encoding="utf-8")
    raw = {"schema": "v39-synthetic-native-session-v1", "synthetic": True,
           "signal_mode": args.signal_mode, "source_root": "frozen export",
           "python": sys.version, "platform": platform.platform(),
           "runtime_controls": {}, "loaded_sources": {}, "xvfb": {},
           "window": {}, "native_events": [], "pixel_trigger": {},
           "shutdown": {}, "scope": {"real_v15_backend_constructor": True,
               "real_backend_snapshot": True, "real_backend_execute": True,
               "real_executor_v13": True, "real_xlib_xtest": True,
               "synthetic_signal": True, "game": False, "model": False,
               "full_v39_controller": False, "hud_ground_truth": False,
               "task_success_claim": False}, "fatal": None}
    xvfb = session_display = observer = window = backend = executor = trigger = None
    try:
        raw["runtime_controls"] = runtime_controls()
        for rel in ("research/live_control", "research/doom",
                    "research/observation_gating", "research/observation_tiles",
                    "research/real_apps_v1"):
            sys.path.insert(0, str(source_root / rel))
        sys.path.insert(0, str(source_root))

        xvfb = subprocess.Popen(["Xvfb", "-displayfd", "1", "-screen", "0",
            "640x480x24", "+extension", "XTEST", "-nolisten", "tcp", "-ac",
            "-noreset"], stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
            stderr=xvfb_err, close_fds=True)
        ready, _, _ = select.select([xvfb.stdout], [], [], 5)
        if not ready:
            raise TimeoutError("Xvfb did not publish display number")
        display_name = ":" + xvfb.stdout.readline().decode("ascii").strip()
        if not display_name[1:].isdigit():
            raise RuntimeError("invalid Xvfb displayfd response")
        os.environ["DISPLAY"] = display_name
        from Xlib import X, XK, Xatom, display
        observer = display.Display(display_name)
        old_keyboard = safe(observer.get_keyboard_control())
        observer.change_keyboard_control(auto_repeat_mode=X.AutoRepeatModeOff)
        observer.sync()
        keyboard_after = safe(observer.get_keyboard_control())

        screen = observer.screen()
        window = screen.root.create_window(20, 20, 360, 240, 0,
            X.CopyFromParent, X.InputOutput, X.CopyFromParent,
            background_pixel=0x00ff00,
            event_mask=X.KeyPressMask | X.KeyReleaseMask)
        window.change_property(observer.intern_atom("_NET_WM_NAME"),
            observer.intern_atom("UTF8_STRING"), 8, b"Synthetic V39 handoff")
        window.map()
        observer.sync()
        active = observer.intern_atom("_NET_ACTIVE_WINDOW")
        screen.root.change_property(active, Xatom.WINDOW, 32, [int(window.id)])
        window.set_input_focus(X.RevertToParent, X.CurrentTime)
        observer.sync()
        focus = observer.get_input_focus().focus
        focus_id = int(getattr(focus, "id", focus))
        if focus_id != int(window.id):
            raise RuntimeError("synthetic window did not receive focus")

        session_display = display.Display(display_name)
        session = SyntheticSession(display_name, session_display, int(window.id))
        keycode_a = int(observer.keysym_to_keycode(XK.string_to_keysym("a")))
        if keycode_a <= 0:
            raise RuntimeError("Xvfb has no keycode for a")
        # Use separate observer and session connections. The pixel is initialized
        # before the first frame; non-health pixels remain fixture-neutral.
        gc = window.create_gc(foreground=0x00ff00)
        window.fill_rectangle(gc, 10, 10, 1, 1)
        gc.free()
        observer.sync()
        raw["xvfb"] = {"display": display_name, "pid": xvfb.pid,
                       "args": ["Xvfb", "-displayfd", "1", "-screen", "0",
                                "640x480x24", "+extension", "XTEST", "-nolisten",
                                "tcp", "-ac", "-noreset"]}
        raw["window"] = {"id": int(window.id), "origin": [20, 20],
                         "size": [360, 240], "pixel_root": [30, 30],
                         "pixel_local": [10, 10], "focus_id": focus_id,
                         "keycodes": {name: int(observer.keysym_to_keycode(
                             XK.string_to_keysym(name))) for name in ("a", "d", "w")},
                         "keycode_a": keycode_a,
                         "autorepeat_before": old_keyboard,
                         "autorepeat_after": keyboard_after,
                         "autorepeat_disabled": (
                             getattr(observer.get_keyboard_control(),
                                     "global_auto_repeat", None) == X.AutoRepeatModeOff)}
        trigger = PixelTrigger(display_name, window, observer, keycode_a,
                               args.signal_mode, native_path)
        trigger.start()

        from doom_batch_key_measurement_backend_v1 import Backend
        from executor_v13 import Executor
        backend = Backend(session, out / "backend-artifacts", writer.emit,
                          build_readers(args.signal_mode))
        executor = Executor(backend, writer.emit)
        writer.emit({"event": "ready", "presentation": "full",
                     "operations": ["submit", "cancel", "clock", "finish"],
                     "task": "Synthetic X11 handoff; no game or task objective",
                     "observation_contract": {"typed": "doom-typed-observation-v1",
                         "signals": ["health", "ammo"], "synthetic": True,
                         "input_authority": False},
                     "release_contract": {"early": "lease-bound verified owner release",
                         "terminal": "separate executor lifecycle close",
                         "grants_input_authority": False},
                     "fixture": {"health_initial": 90,
                         "health_after_a": 60 if args.signal_mode == "drop" else 90,
                         "ammo": 30, "mode": args.signal_mode,
                         "synthetic_pixel_screen": [30, 30]},
                     "bindings": {"a": "synthetic health-trigger key",
                                  "d": "synthetic initial/right command key",
                                  "w": "synthetic follow-on key"},
                     "prohibited": ["game", "HUD truth", "model authority",
                                    "task completion claim"]})
        backend.snapshot("initial", 0)

        for line in sys.stdin:
            try:
                command = json.loads(line)
                writer.emit({"event": "command", "command": command,
                             "received_ns": time.perf_counter_ns()})
                operation = command.get("op")
                if operation == "submit":
                    executor.submit(command["id"], command["steps"],
                                    command["expected_sequence"],
                                    command["valid_until_ns"])
                elif operation == "cancel":
                    executor.cancel(command["id"])
                elif operation == "clock":
                    writer.emit({"event": "clock", "runtime_ns": time.perf_counter_ns(),
                                 "sequence": backend.sequence})
                elif operation == "finish":
                    executor.close()
                    writer.emit({"event": "post_control_score", "synthetic": True,
                                 "game": False, "semantic_completion": "not measured",
                                 "task_success": None})
                    break
                else:
                    writer.emit({"event": "rejected", "reason": "unsupported operation"})
            except (ValueError, TypeError, KeyError) as exc:
                writer.emit({"event": "rejected", "reason": str(exc)})
    except BaseException as exc:
        raw["fatal"] = {"type": type(exc).__name__, "message": str(exc),
                        "traceback": traceback.format_exc()}
        print(json.dumps({"event": "child_error", **raw["fatal"]}), file=sys.stderr,
              flush=True)
    finally:
        if executor is not None:
            try:
                executor.close()
                raw["shutdown"]["executor_close"] = "ok"
                raw["shutdown"]["executor_active_after_close"] = executor.active is not None
                raw["shutdown"]["release_watchers_alive"] = [
                    thread.name for thread in getattr(executor, "release_watchers", [])
                    if thread.is_alive()]
            except BaseException as exc:
                raw["shutdown"]["executor_close"] = repr(exc)
        if backend is not None:
            try:
                backend.owner.close()
                raw["shutdown"]["owner_close"] = "ok"
            except BaseException as exc:
                raw["shutdown"]["owner_close"] = repr(exc)
            try:
                owner = raw_owner(backend.owner)
                raw["shutdown"]["owner_stopped"] = bool(owner.stopped.is_set())
                raw["shutdown"]["owner_thread_alive"] = bool(owner.thread.is_alive())
                raw["owner_records"] = copy.deepcopy(owner.records)
            except BaseException as exc:
                raw["shutdown"]["owner_readback_error"] = repr(exc)
        if trigger is not None:
            try:
                observer.sync()
            except BaseException:
                pass
            trigger.stop.set()
            trigger.thread.join(timeout=2)
            raw["pixel_trigger"] = {"changed": trigger.changed, "mode": trigger.mode,
                                    "error": trigger.error,
                                    "thread_alive": trigger.thread.is_alive(),
                                    "rows": copy.deepcopy(trigger.rows)}
            raw["native_events"] = copy.deepcopy(trigger.rows)
        if observer is not None:
            try:
                raw["final_keymap_query_ns"] = time.perf_counter_ns()
                keymap = observer.query_keymap()
                raw["final_all_down_keycodes"] = [code for code in range(256)
                    if keymap[code // 8] & (1 << (code % 8))]
                raw["final_keymap"] = {
                    name: bool(keymap[code // 8] & (1 << (code % 8)))
                    for name, code in raw["window"].get("keycodes", {}).items()}
            except BaseException as exc:
                raw["shutdown"]["final_keymap_error"] = repr(exc)
        if window is not None and observer is not None:
            try:
                window.destroy()
                observer.sync()
                raw["shutdown"]["window_destroy"] = "ok"
            except BaseException as exc:
                raw["shutdown"]["window_destroy"] = repr(exc)
        if session_display is not None:
            try:
                session_display.close()
                raw["shutdown"]["session_display_close"] = "ok"
            except BaseException as exc:
                raw["shutdown"]["session_display_close"] = repr(exc)
        if observer is not None:
            try:
                observer.close()
                raw["shutdown"]["observer_close"] = "ok"
            except BaseException as exc:
                raw["shutdown"]["observer_close"] = repr(exc)
        if xvfb is not None:
            try:
                xvfb.terminate()
                xvfb.wait(timeout=3)
                raw["shutdown"]["xvfb_exit"] = xvfb.returncode
            except BaseException as exc:
                raw["shutdown"]["xvfb_stop_error"] = repr(exc)
                try:
                    xvfb.kill()
                    xvfb.wait(timeout=2)
                except BaseException as kill_exc:
                    raw["shutdown"]["xvfb_kill_error"] = repr(kill_exc)
        xvfb_err.close()
        raw["runtime_controls"] = raw.get("runtime_controls") or {}
        raw["executor_events"] = copy.deepcopy(writer.rows)
        raw["loaded_sources"] = loaded_sources(source_root)
        raw["threads_alive"] = [{"name": t.name, "daemon": t.daemon}
                                for t in threading.enumerate()]
        raw["fatal"] = raw.get("fatal")
        raw["ended_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        raw_path.open("x", encoding="utf-8").write(
            json.dumps(safe(raw), sort_keys=True, indent=2) + "\n")
    return 1 if raw["fatal"] is not None else 0


if __name__ == "__main__":
    raise SystemExit(main())

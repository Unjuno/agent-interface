#!/usr/bin/env python3
"""Mutation controls of retained copies only; never run an input producer."""
import copy,hashlib,json,shutil,tempfile
from pathlib import Path
import audit_saved
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'negative-controls'
OUT.mkdir(exist_ok=False)

def put(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def write_lines(path,rows):path.write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in rows))
def event_edit(root,edit):
 rt=root/'runs/drop/controller/runtime';rows=audit_saved.lines(rt/'events.jsonl');edit(rows)
 write_lines(rt/'events.jsonl',rows);write_lines(rt/'delivered.jsonl',rows)
 child=audit_saved.read(rt/'native-raw.json');child['executor_events']=copy.deepcopy(rows);put(rt/'native-raw.json',child)
def native_edit(root,edit):
 rt=root/'runs/drop/controller/runtime';rows=audit_saved.lines(rt/'native-events.jsonl');edit(rows)
 write_lines(rt/'native-events.jsonl',rows)
 child=audit_saved.read(rt/'native-raw.json');child['native_events']=copy.deepcopy(rows);child['pixel_trigger']['rows']=copy.deepcopy(rows);put(rt/'native-raw.json',child)
def planner_edit(root):
 p=root/'runs/drop/controller/planner-protocol.jsonl';rows=audit_saved.lines(p)
 next(r for r in rows if r['event']=='interrupt_turn')['wait_active']=False;write_lines(p,rows)
def stale_source(root):
 p=root/'runs/drop/controller/report.json';d=audit_saved.read(p);d['decisions'][2]['source_image']=d['decisions'][0]['source_image'];put(p,d)
def remove_release(rows):
 idx=next(i for i,r in enumerate(rows) if r.get('type')=='KeyRelease');rows.pop(idx)
def reversed_change(rows):
 row=next(r for r in rows if r.get('type')=='pixel_changed');row['observed_ns']=10**25
def late_terminal(rows):
 t=next(r for r in rows if r['event']=='terminal' and r['id']=='cover-1');t['release']['verified_ns']=t['terminal_ns']+1
def wrong_health(rows):
 t=next(r for r in rows if r['event']=='typed_observation' and r['signals']['health']['value']==60);t['signals']['health']['value']=90
cases=[
 ('pending_wait_false',planner_edit,'drop.invalidation_while_pending'),
 ('stale_plan_submitted',lambda r:event_edit(r,lambda rows:rows.append({'event':'command','command':{'op':'submit','id':'plan-1-leaked'}})),'drop.stale_completed_rejected'),
 ('unverified_early_release',lambda r:event_edit(r,lambda rows:next(x for x in rows if x['event']=='input_released' and x['id']=='cover-1')['owner_release'].update(verified=False)),'drop.early_release'),
 ('late_verified_release',lambda r:event_edit(r,late_terminal),'drop.all_release_before_terminal'),
 ('missing_native_up',lambda r:native_edit(r,remove_release),'drop.native_balanced_d'),
 ('wrong_typed_value',lambda r:event_edit(r,wrong_health),'drop.epoch.'),
 ('stale_next_source',stale_source,'drop.fresh_matching_source'),
 ('pixel_change_reordered',lambda r:native_edit(r,reversed_change),'drop.native_change_chronology'),
]
results=[]
for name,mutate,expected in cases:
 case=OUT/name;case.mkdir()
 with tempfile.TemporaryDirectory(prefix='v39-saved-control-') as tmp:
  root=Path(tmp)
  shutil.copytree(ROOT/'source',root/'source');shutil.copytree(ROOT/'runs',root/'runs');shutil.copyfile(ROOT/'source-lock.json',root/'source-lock.json')
  mutate(root);result=audit_saved.audit(root)
  modified=[]
  for p in sorted((root/'runs').rglob('*')):
   if not p.is_file():continue
   rel=p.relative_to(root);original=ROOT/rel
   if p.read_bytes()!=original.read_bytes():
    dst=case/'changed'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
    modified.append({'path':str(rel),'before':audit_saved.sha(original),'after':audit_saved.sha(p)})
  failnames=[f['name'] for f in result['failures']]
  valid=result['status']=='FAIL' and any(f==expected or f.startswith(expected) for f in failnames) and not any(f.endswith('audit_exception') for f in failnames)
  put(case/'audit.json',result);put(case/'mutation.json',{'case':name,'modified':modified,'expected_substantive_failure':expected,'effective_rejection':valid})
  results.append({'case':name,'effective_rejection':valid,'failures':failnames,'modified_files':len(modified)})
put(OUT/'RESULT.json',{'status':'PASS' if all(r['effective_rejection'] for r in results) else 'FAIL','controls':results,'native_invocations':0})
print(json.dumps(results,indent=2))
raise SystemExit(not all(r['effective_rejection'] for r in results))

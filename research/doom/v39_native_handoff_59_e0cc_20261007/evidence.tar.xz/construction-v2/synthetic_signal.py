"""Pixel-bound synthetic health/ammo reader for the V39 native handoff fixture.

This module deliberately makes no game/HUD claim.  It is shared by the
synthetic X11 child and the controller-side reader injected by the harness.
"""
from __future__ import annotations

import hashlib
from pathlib import Path

from PIL import Image


FORMAT = "observable-signal-v1"
FIXTURE_FORMAT = "v39-synthetic-pixel-signal-v1"
SYNTHETIC_RGB = {"health_90": (0, 255, 0), "health_60": (255, 0, 0)}
SYNTHETIC_HASH = hashlib.sha256(b"synthetic-x11-pixel-fixture-v1").hexdigest()
PIXEL = (30, 30)  # root screen coordinates; child window origin is (20, 20)


def _binding(metadata: dict) -> dict:
    value = metadata.get("pointer_binding")
    if (type(value) is not dict or set(value) != {"focus", "surface", "geometry"} or
            type(value.get("focus")) is not int or
            type(value.get("surface")) is not int or
            type(value.get("geometry")) is not list or len(value["geometry"]) != 4 or
            any(type(item) is not int for item in value["geometry"])):
        raise ValueError("synthetic signal requires exact pointer binding")
    return {"focus": value["focus"], "surface": value["surface"],
            "geometry": list(value["geometry"])}


class SyntheticPixelSignalReader:
    """Read fixture pixels while preserving the ordinary reader epoch contract."""

    def __init__(self, signal_id: str, mode: str = "drop"):
        if signal_id not in ("health", "ammo"):
            raise ValueError("signal_id must be health or ammo")
        if mode not in ("stable", "drop"):
            raise ValueError("mode must be stable or drop")
        self.signal_id = signal_id
        self.mode = mode

    def _value(self, image: Image.Image) -> int:
        if self.signal_id == "ammo":
            return 30
        pixel = tuple(image.convert("RGB").getpixel(PIXEL))
        if pixel == SYNTHETIC_RGB["health_90"]:
            return 90
        if pixel == SYNTHETIC_RGB["health_60"]:
            return 60
        raise ValueError(f"unexpected synthetic health pixel {pixel!r}")

    def read_frame(self, metadata: dict, image: Image.Image) -> dict:
        if not isinstance(image, Image.Image):
            raise ValueError("PIL image required")
        sequence = metadata.get("sequence")
        capture_ns = metadata.get("capture_ns")
        if type(sequence) is not int or sequence < 1 or type(capture_ns) is not int:
            raise ValueError("exact capture sequence and timestamp required")
        return {"format": FORMAT, "status": "observed",
                "signal_id": self.signal_id, "value": self._value(image),
                "sequence": sequence, "capture_ns": capture_ns,
                "binding": _binding(metadata), "wad_sha256": SYNTHETIC_HASH,
                "synthetic": True, "fixture_format": FIXTURE_FORMAT, "pixel": list(PIXEL)}

    def read(self, observation: dict) -> dict:
        path = observation.get("image")
        if not isinstance(path, str) or not path:
            raise ValueError("full observation image path required")
        with Image.open(Path(path)) as image:
            return self.read_frame(observation, image)


class SyntheticSignalReader(SyntheticPixelSignalReader):
    """Controller-facing compatibility name; WAD path is accepted but unused.

    `wad_path` is deliberately ignored: synthetic pixels have no WAD or game
    provenance. The positional argument mirrors the production HUD reader
    constructor so the parent can replace only the reader factory seam.
    """
    def __init__(self, wad_path=None, *, signal_id="health", mode="drop"):
        super().__init__(signal_id=signal_id, mode=mode)


def build_readers(mode: str = "drop") -> dict:
    return {name: SyntheticPixelSignalReader(name, mode)
            for name in ("health", "ammo")}

#!/usr/bin/env python3
"""Bounded synthetic native V39 construction; no game or external model."""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
import threading
import time
import traceback


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def active_action():
    return {"assessment": "Scripted synthetic fixture; no game or model judgement.",
            "state": "active", "commands": [{"action": "strafe_right", "extent": "pulse"}],
            "contingencies": [], "next_cover": [{"action": "strafe_left", "extent": "long"}],
            "next_cover_validity": [{"signal_id": "health", "critical_health_minimum": 35,
                                     "maximum_health_loss": 12, "max_source_age_ms": 30000}],
            "action_validity": [{"critical_health_minimum": 35, "maximum_health_loss": 12,
                                 "minimum_ammo": 0, "max_current_age_ms": 1000}]}


def terminal_action():
    return {"assessment": "Scripted fixture termination; not observed game success.",
            "state": "exit_or_transition", "commands": [], "contingencies": [],
            "next_cover": [], "next_cover_validity": [], "action_validity": []}


class ScriptedClient:
    """Explicit transport seam. Production PersistentPlannerAdapter stays real."""
    def __init__(self, *args, journal_path, **kwargs):
        self.path = Path(journal_path)
        self.fp = self.path.open("x", encoding="utf-8")
        self.lock = threading.Lock()
        self.interrupted = threading.Event()
        self.mode = MODE
        self.count = 0
        self.thread_id = "synthetic-scripted-thread"
        self.closed = False
        self.active_wait = None
        self.record("constructed", args=list(map(str, args)), kwargs={k:str(v) for k,v in kwargs.items()},
                    mode=self.mode, model_invoked=False)

    def record(self, event, **fields):
        with self.lock:
            if self.closed:
                return
            self.fp.write(json.dumps({"event": event, "observed_ns": time.perf_counter_ns(),
                                      **copy.deepcopy(fields)}, sort_keys=True)+"\n")
            self.fp.flush()

    def initialize(self):
        self.record("initialize")
        return {"synthetic": True}

    def start_thread(self, **kwargs):
        self.record("start_thread", requested=kwargs, thread_id=self.thread_id)
        return {"thread": {"id": self.thread_id}}

    def start_turn(self, thread_id, inputs, **kwargs):
        if thread_id != self.thread_id or self.count >= 3:
            raise RuntimeError("unexpected synthetic planner turn")
        self.count += 1
        turn_id = "synthetic-turn-"+str(self.count)
        self.record("start_turn", thread_id=thread_id, turn_id=turn_id,
                    inputs=inputs, requested=kwargs)
        return {"turn": {"id": turn_id}}

    def wait_turn_completed(self, thread_id, turn_id, timeout=120):
        self.active_wait = turn_id
        self.record("wait_started", thread_id=thread_id, turn_id=turn_id)
        if turn_id == "synthetic-turn-2":
            if self.mode == "drop":
                if not self.interrupted.wait(8):
                    self.record("fixture_timeout", turn_id=turn_id)
                    raise TimeoutError("target planner was not interrupted within fixture bound")
            else:
                if self.interrupted.wait(1.2):
                    raise RuntimeError("stable control planner unexpectedly interrupted")
        else:
            time.sleep(.05)
        answer = terminal_action() if turn_id == "synthetic-turn-3" else active_action()
        # Deliberately return a syntactically valid completed answer after the
        # target interruption. Only the real adapter may make it ineligible.
        result = {"turn": {"id": turn_id, "status": "completed", "items": [
            {"type": "agentMessage", "text": json.dumps(answer)}]}}
        self.record("completed_answer", thread_id=thread_id, turn_id=turn_id,
                    interrupted=self.interrupted.is_set(), result=result)
        self.active_wait = None
        return result

    def interrupt_turn(self, thread_id, turn_id):
        if thread_id != self.thread_id or turn_id != "synthetic-turn-2":
            raise RuntimeError("unexpected scripted interruption identity")
        self.record("interrupt_turn", thread_id=thread_id, turn_id=turn_id,
                    wait_active=self.active_wait == turn_id)
        self.interrupted.set()
        return {"synthetic": True, "accepted": True}

    def latest_turn_usage(self, thread_id, turn_id):
        return {"synthetic": True, "model_calls": 0, "tokens_measured": False}

    def close(self, timeout=5):
        self.interrupted.set()
        self.record("close", timeout=timeout)
        with self.lock:
            if not self.closed:
                self.closed = True
                self.fp.close()


def controls():
    cg = Path("/proc/self/cgroup").read_text().strip()
    rel = next(line.split(":", 2)[2] for line in cg.splitlines() if line.startswith("0::"))
    directory = Path("/sys/fs/cgroup") / rel.lstrip("/")
    return {"uid": os.getuid(), "network_namespace": os.readlink("/proc/self/ns/net"),
            "cgroup_membership": cg,
            **{name:(directory/name).read_text().strip()
               for name in ("cpu.max", "memory.max", "memory.swap.max", "pids.max")}}


def main():
    global MODE
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--signal-mode", choices=("stable", "drop"), required=True)
    args = parser.parse_args()
    MODE = args.signal_mode
    root = args.out.resolve()
    root.mkdir(parents=True, exist_ok=False)
    source = args.source_root.resolve()
    lock_path = source.parent/"source-lock.json"
    lock = json.loads(lock_path.read_text())
    before = {row["path"]:sha(source/row["path"]) for row in lock["files"]}
    if (lock["head"] != "4190104d0c72a025093c8569fdbd216b5929de0b" or
            before != {r["path"]:r["sha256"] for r in lock["files"]}):
        raise RuntimeError("source freeze mismatch")
    for rel in ("research/live_control", "research/doom", "research/observation_gating",
                "research/observation_tiles", "research/real_apps_v1"):
        sys.path.insert(0, str(source/rel))
    sys.path.insert(0, str(source))
    receipt = {"schema": "v39-synthetic-native-controller-v1", "mode": MODE,
               "source_head": lock["head"], "source_lock_sha256": sha(lock_path),
               "source_before": before, "python": sys.version, "platform": platform.platform(),
               "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
               "start_ns": time.perf_counter_ns(), "controls": controls(), "fatal": None,
               "seams": ["CodexAppServerClient scripted in-process transport",
                         "synthetic pixel reader (health and ammo)",
                         "session_command synthetic native child without game",
                         "win identity POSIX path", "app_server_command descriptive unused value"],
               "real": ["V39 main", "PersistentPlannerAdapter", "ThreadPoolExecutor",
                        "Popen stdin/stdout pipes", "queue reader", "source refresh",
                        "cover monitor and frame barrier", "running action guards",
                        "Backend constructor/execute", "ExecutorV13", "X11 owner/XTEST"],
               "limits": ["no actual model", "no game", "no task benefit",
                          "no performance comparison", "one fixture per arm"]}
    fixture = root/"fixture.json"
    fixture.write_text(json.dumps({"synthetic": True, "signal_mode": MODE,
                                  "game": False, "health": [90, 60], "ammo": 30})+"\n")
    try:
        import map01_overlap_controller_v39 as controller
        from synthetic_signal import SyntheticSignalReader
        controller.CodexAppServerClient = ScriptedClient
        controller.DoomStatusNumberReader = SyntheticSignalReader
        controller.win = lambda p:str(Path(p).resolve())
        controller.app_server_command = lambda:["synthetic-client-no-process"]
        controller.session_command = lambda _args, runtime:[sys.executable,
            str(Path(__file__).with_name("native_session.py")), "--out", str(runtime),
            "--source-root", str(source), "--signal-mode", MODE]
        sys.argv = ["map01_overlap_controller_v39", "--out", str(root/"controller"),
                    "--iterations", "3", "--session-span", "4",
                    "--model", "synthetic-scripted-no-model", "--effort", "low",
                    "--load-fixture-manifest", str(fixture), "--measurement-session",
                    "--per-key-input-measurement"]
        receipt["controller_argv"] = sys.argv[:]
        controller.main()
        receipt["controller_returned"] = True
    except BaseException as error:
        receipt["fatal"] = {"type": type(error).__name__, "message": str(error),
                            "traceback": traceback.format_exc()}
    finally:
        receipt["end_ns"] = time.perf_counter_ns()
        receipt["ended_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        receipt["source_after"] = {p:sha(source/p) for p in before}
        loaded = {}
        for module in list(sys.modules.values()):
            path = getattr(module, "__file__", None)
            if path:
                try:
                    p = Path(path).resolve(); rel = str(p.relative_to(source))
                except (OSError, ValueError):
                    continue
                if p.is_file():loaded[rel] = sha(p)
        receipt["source_loaded"] = loaded
        receipt["threads_alive"] = [{"name":t.name,"daemon":t.daemon}
                                     for t in threading.enumerate()]
        (root/"controller-probe.json").open("x").write(json.dumps(receipt,indent=2)+"\n")
    return int(receipt["fatal"] is not None)


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Host one-shot launch/retention wrapper; request created before execution."""
import datetime,hashlib,io,json,subprocess,sys,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
GUEST='/home/study/v39-native-handoff-20261007-v2'
ORB=['/opt/homebrew/bin/orb','-m','v15-native-e0cc-20261005']
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(label,argv,*,data=None,timeout=70):
 request={'utc':stamp(),'argv':argv,'input_sha256':None if data is None else hashlib.sha256(data).hexdigest()}
 (ROOT/(label+'-request.json')).open('x').write(json.dumps(request,indent=2)+'\n')
 try:
  p=subprocess.run(argv,input=data,capture_output=True,timeout=timeout)
  result={'utc':stamp(),'returncode':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()}
 except Exception as e:
  (ROOT/(label+'-unknown.json')).open('x').write(json.dumps({'utc':stamp(),'error':repr(e),'execution_state':'unknown; inspect before any resend'},indent=2)+'\n')
  raise
 (ROOT/(label+'-result.json')).open('x').write(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'label':label,'returncode':p.returncode,'stdout':result['stdout'][:1500],'stderr':result['stderr'][:1500]}),flush=True)
 return p.returncode
mode=sys.argv[1]
if mode=='transfer':
 freeze=json.loads((ROOT/'freeze.json').read_text())
 stream=io.BytesIO()
 with tarfile.open(fileobj=stream,mode='w') as tar:
  for rel,digest in freeze['files'].items():
   if hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()!=digest:raise RuntimeError('freeze mismatch '+rel)
   tar.add(ROOT/rel,arcname=rel,recursive=False)
  tar.add(ROOT/'freeze.json',arcname='freeze.json',recursive=False)
 status=run('source-transfer',ORB+['-u','study','-w','/home/study','tar','-x','-C',GUEST],data=stream.getvalue(),timeout=30)
 sys.exit(status)
if mode not in ('stable','drop'):raise SystemExit('mode stable/drop/transfer')
freeze=json.loads((ROOT/'freeze.json').read_text())
for rel,digest in freeze['files'].items():
 if hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()!=digest:raise RuntimeError('freeze mismatch '+rel)
props=['User=study','PrivateNetwork=yes','PrivateTmp=yes','CPUQuota=100%','MemoryMax=1G','MemorySwapMax=0','TasksMax=64','RuntimeMaxSec=60','ProtectSystem=strict','ReadWritePaths='+GUEST+'/runs','NoNewPrivileges=yes','WorkingDirectory='+GUEST,'Environment=PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1','LimitFSIZE=250M']
argv=ORB+['-u','root','-w','/root','systemd-run','--quiet','--wait','--pipe','--collect','--unit=v39-native-v2-'+mode+'-e0cc']
for p in props:argv+=['-p',p]
argv+=['/usr/bin/python3',GUEST+'/controller_probe.py','--source-root',GUEST+'/source','--out',GUEST+'/runs/'+mode,'--signal-mode',mode]
sys.exit(run('run-'+mode,argv))

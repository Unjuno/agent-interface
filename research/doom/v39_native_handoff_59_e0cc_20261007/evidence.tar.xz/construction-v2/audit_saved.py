#!/usr/bin/env python3
"""Independent saved-only oracle. Does not import producer/runtime or use input."""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
from PIL import Image


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())
def lines(path):return [json.loads(s) for s in Path(path).read_text().splitlines() if s]
def released(row):
    return (type(row) is dict and row.get("verified") is True and
            row.get("keys_down") == [] and row.get("buttons_down") == [] and
            row.get("keys_unknown", []) == [] and row.get("key_state_errors", []) == [])


def audit(root):
    checks=[]; metrics={}
    def ck(name,value,detail=None):
        checks.append({"name":name,"passed":bool(value),"detail":detail})
    lock=read(root/"source-lock.json")
    expected={r["path"]:r["sha256"] for r in lock["files"]}
    ck("source.baseline",lock["head"]=="4190104d0c72a025093c8569fdbd216b5929de0b")
    ck("source.saved",all(sha(root/"source"/p)==h for p,h in expected.items()))
    for mode in ("stable","drop"):
        def check(name,value,detail=None):ck(mode+"."+name,value,detail)
        try:
            arm=root/"runs"/mode; ctr=arm/"controller"; runtime=ctr/"runtime"
            parent=read(arm/"controller-probe.json"); child=read(runtime/"native-raw.json")
            report=read(ctr/"report.json"); ev=lines(runtime/"events.jsonl")
            planner=lines(ctr/"planner-protocol.jsonl"); native=lines(runtime/"native-events.jsonl")
            decisions=report["decisions"]
            check("parent_finished",parent.get("fatal") is None and parent.get("controller_returned") is True)
            check("child_finished",child.get("fatal") is None)
            check("source_identity",parent["source_before"]==expected==parent["source_after"])
            check("loaded_hashes",all(expected.get(p)==h for loaded in
                  (parent["source_loaded"],child["loaded_sources"]) for p,h in loaded.items()))
            check("real_controller_loaded","research/doom/map01_overlap_controller_v39.py" in parent["source_loaded"])
            check("real_adapter_loaded","research/live_control/persistent_planner_adapter_v2.py" in parent["source_loaded"])
            check("real_backend_executor_loaded",all(p in child["loaded_sources"] for p in
                  ("research/doom/doom_batch_key_measurement_backend_v1.py",
                   "research/doom/doom_owner_thread_release_batch_backend_v1.py",
                   "research/live_control/executor_v13.py","research/live_control/input_owner_v12.py")))
            check("saved_protocol_equal",ev==child["executor_events"]==lines(runtime/"delivered.jsonl"))
            for label,c in (("parent",parent["controls"]),("child",child["runtime_controls"])):
                check(label+".limits",c.get("uid")!=0 and c.get("cpu.max")=="100000 100000" and
                      c.get("memory.max")=="1073741824" and c.get("memory.swap.max")=="0" and c.get("pids.max")=="64")
            check("shared_private_network",parent["controls"]["network_namespace"]==child["runtime_controls"]["network_namespace"])
            network=child["runtime_controls"]
            addresses=json.loads(network["ip_address_json"]["stdout"])
            routes=[r for key in ("ip_route4_json","ip_route6_json") for r in json.loads(network[key]["stdout"])]
            check("network_isolated",all(network[k]["returncode"]==0 for k in
                  ("ip_address_json","ip_route4_json","ip_route6_json")) and
                  all(a["ifname"]=="lo" or ("UP" not in a["flags"] and not a.get("addr_info")) for a in addresses) and
                  all(r.get("dev")=="lo" for r in routes))
            check("three_decisions",len(decisions)==3 and report.get("planner_turns")==3)
            check("first_action",decisions[0].get("plan_terminal")=="completed" and
                  decisions[0].get("model_action_discarded") is False)
            check("terminal_fixture",decisions[2].get("terminal_candidate") is True and
                  decisions[2]["action"]["state"]=="exit_or_transition")
            check("synthetic_scope",child["scope"]["game"] is False and child["scope"]["model"] is False and
                  report["score"]["synthetic"] is True and report["score"]["task_success"] is None)
            starts=[r for r in planner if r["event"]=="start_turn"]
            interrupts=[r for r in planner if r["event"]=="interrupt_turn"]
            completed=[r for r in planner if r["event"]=="completed_answer"]
            wait2=next(r for r in planner if r["event"]=="wait_started" and r["turn_id"]=="synthetic-turn-2")
            done2=next(r for r in completed if r["turn_id"]=="synthetic-turn-2")
            check("same_three_turns",[r["turn_id"] for r in starts]==["synthetic-turn-1","synthetic-turn-2","synthetic-turn-3"])
            check("all_completed_transport",len(completed)==3 and all(r["result"]["turn"]["status"]=="completed" for r in completed))
            check("second_answer_same_as_first",completed[0]["result"]["turn"]["items"]==done2["result"]["turn"]["items"])
            commands=[r["command"] for r in ev if r["event"]=="command"]
            submits=[c for c in commands if c["op"]=="submit"]
            accepted=[r for r in ev if r["event"]=="accepted"]
            terminals=[r for r in ev if r["event"]=="terminal"]
            ids=[r["id"] for r in accepted]
            check("all_submits_accepted",Counter(c["id"] for c in submits)==Counter(ids) and not any(r["event"]=="rejected" for r in ev))
            check("one_terminal_per_acceptance",len(set(ids))==len(ids) and Counter(ids)==Counter(t["id"] for t in terminals))
            check("distinct_intent_tokens",len(set(r["intent_token"] for r in accepted))==len(ids))
            check("all_release_before_terminal",all(released(t.get("release")) and
                  t["release"].get("verified_ns",10**30)<=t["terminal_ns"] for t in terminals))
            check("release_tokens",all(next(r["intent_token"] for r in accepted if r["id"]==t["id"])==t["release"].get("intent_token") for t in terminals))
            typed=[r for r in ev if r["event"]=="typed_observation"]
            full=[r for r in ev if r["event"]=="observation"]
            check("epochs_unique",len(typed)>0 and len(typed)==len(full)==len({r["sequence"] for r in typed}))
            def local_image(value):
                guest=Path("/home/study/v39-native-handoff-20261007-v2/runs")/mode
                rel=Path(value).relative_to(guest)
                if ".." in rel.parts:raise ValueError("image escapes arm")
                return arm/rel
            healths=[]
            for t,f in zip(typed,full):
                identity=all(t.get(k)==f.get(k) for k in ("id","step","sequence","capture_ns","pointer_binding","frame_rgb_sha256"))
                with Image.open(local_image(f["image"])) as im:
                    rgb=im.convert("RGB"); h=hashlib.sha256(rgb.tobytes()).hexdigest(); pixel=rgb.getpixel((30,30))
                value=90 if pixel==(0,255,0) else 60 if pixel==(255,0,0) else None
                healths.append(value)
                check("epoch."+str(f["sequence"]),identity and f.get("exact") is True and
                      h==t["frame_rgb_sha256"] and value is not None and
                      t["signals"]["health"]["value"]==value and t["signals"]["ammo"]["value"]==30 and
                      all(s["sequence"]==f["sequence"] and s["capture_ns"]==f["capture_ns"] and
                          s["binding"]==f["pointer_binding"] for s in t["signals"].values()))
            check("report_reconciliation",report["typed_artifact_reconciliation_failures"]==0 and
                  report["typed_artifact_reconciled"]==len(typed))
            keys=[r for r in native if r.get("type") in ("KeyPress","KeyRelease")]
            codes={name:child["window"]["keycodes"][name] for name in ("a","d")}
            check("native_allowed_keys",len(keys)>0 and all(r["detail"] in codes.values() and r["event_window"]==child["window"]["id"] and r["send_event"] is False for r in keys))
            for name,code in codes.items():
                seq=[r["type"] for r in keys if r["detail"]==code]
                check("native_balanced_"+name,len(seq)>=2 and len(seq)%2==0 and seq==["KeyPress","KeyRelease"]*(len(seq)//2))
            check("d_action_count",sum(r["type"]=="KeyPress" and r["detail"]==codes["d"] for r in keys)==(2 if mode=="stable" else 1))
            check("autorepeat_disabled",child["window"]["autorepeat_disabled"] is True)
            check("native_final_neutral",child["final_keymap"]=={"a":False,"d":False,"w":False} and child["final_all_down_keycodes"]==[])
            check("pixel_thread_clean",child["pixel_trigger"]["error"] is None and child["pixel_trigger"]["thread_alive"] is False and child["pixel_trigger"]["rows"]==native)
            shut=child["shutdown"]
            check("shutdown",shut.get("executor_close")=="ok" and shut.get("owner_close")=="ok" and
                  shut.get("owner_stopped") is True and shut.get("owner_thread_alive") is False and
                  shut.get("xvfb_exit")==0 and shut.get("executor_active_after_close") is False and
                  child.get("threads_alive")==[{"name":"MainThread","daemon":False}] and
                  shut.get("release_watchers_alive")==[])
            check("parent_threads",parent["threads_alive"]==[{"name":"MainThread","daemon":False}])
            if mode=="stable":
                check("no_invalidation",report["policy_invalidations"]==0 and interrupts==[] and report["planner_ineligible_answers"]==0)
                check("second_admitted",decisions[1].get("plan_terminal")=="completed" and decisions[1].get("model_action_discarded") is False)
                check("constant_pixels",set(healths)=={90} and child["pixel_trigger"]["changed"] is False)
            else:
                inv=decisions[1]["policy_invalidation"]
                t=next(t for t in terminals if t["id"]=="cover-1")
                check("one_invalidation",report["policy_invalidations"]==1 and len(interrupts)==1 and
                      inv["outcome"]["status"]=="HARD_INVALIDATED" and inv["signal"]["value"]==60 and
                      decisions[1]["cover_validity_admission"]["source_signal"]["value"]==90)
                check("invalidation_while_pending",wait2["observed_ns"]<inv["monitor_received_ns"]<=inv["outcome_evaluated_ns"]<=interrupts[0]["observed_ns"]<done2["observed_ns"] and interrupts[0]["wait_active"] is True)
                check("matching_interrupt",interrupts[0]["turn_id"]==decisions[1]["planner_turn_id"]=="synthetic-turn-2" and
                      decisions[1]["planner_cancellation_requested"] is True)
                check("stale_completed_rejected",decisions[1]["planner_turn_status"]=="completed" and
                      decisions[1]["planner_answer_eligible"] is False and decisions[1]["action"] is None and
                      decisions[1]["model_action_discarded"] is True and decisions[1]["plan_terminal"]=="not_admitted" and
                      not any(c["id"].startswith("plan-1") for c in submits))
                check("cover_cancelled",t["status"]=="cancelled" and any(r["event"]=="cancel_requested" and r["id"]=="cover-1" and r["matched"] is True for r in ev))
                early=[r for r in ev if r["event"]=="input_released" and r["id"]=="cover-1"]
                check("early_release",len(early)==1 and released(early[0]["owner_release"]) and
                      early[0]["published_ns"]<=t["terminal_ns"] and early[0]["program_terminal_pending"] is True and early[0]["grants_input_authority"] is False)
                check("new_turn_after_terminal",starts[2]["observed_ns"]>t["terminal_ns"])
                source2=[f for f in full if f["image"]==decisions[2]["source_image"] and
                         f["sequence"]>=inv["sequence"] and f["capture_ns"]>=inv["capture_ns"] and
                         f["pointer_binding"]==inv["pointer_binding"] and f["frame_rgb_sha256"]==inv["frame_rgb_sha256"]]
                check("fresh_matching_source",bool(source2) and "health: 60." in starts[2]["inputs"][0]["text"])
                check("pixel_drop",90 in healths and 60 in healths and child["pixel_trigger"]["changed"] is True and
                      sum(r.get("type")=="pixel_changed" for r in native)==1)
                press=next(r for r in native if r.get("type")=="KeyPress" and r["detail"]==codes["a"])
                trigger=next(r for r in native if r.get("type")=="signal_trigger_observed")
                changed=next(r for r in native if r.get("type")=="pixel_changed")
                first_red=next(r for r in typed if r["signals"]["health"]["value"]==60)
                admission=next(r for r in ev if r["event"]=="input_admission" and r.get("id")=="cover-1" and r.get("key")=="a")
                check("native_change_chronology",admission["admitted_ns"]<=press["observed_ns"]<=trigger["observed_ns"]<
                      changed["down_witness_ns"]<=changed["observed_ns"]<=first_red["capture_ns"]<=inv["capture_ns"]<=inv["monitor_received_ns"] and
                      wait2["observed_ns"]<changed["observed_ns"]<done2["observed_ns"] and changed["a_down_before_change"] is True and
                      trigger["keycode"]==codes["a"])
                metrics["drop"]={"invalidation_to_interrupt_ms":(interrupts[0]["observed_ns"]-inv["outcome_evaluated_ns"])/1e6,
                    "invalidation_to_terminal_ms":(t["terminal_ns"]-inv["outcome_evaluated_ns"])/1e6,
                    "invalidation_to_next_turn_ms":(starts[2]["observed_ns"]-inv["outcome_evaluated_ns"])/1e6}
            metrics[mode+"_counts"]={"events":len(ev),"frames":len(full),"native_key_events":len(keys),"accepted":len(accepted)}
        except Exception as exc:
            check("audit_exception",False,type(exc).__name__+": "+str(exc))
    return {"schema":"v39-native-handoff-saved-audit-v1","status":"PASS_SCOPED_NATIVE_CONTROLLER_HANDOFF" if all(r["passed"] for r in checks) else "FAIL",
            "checks_passed":sum(r["passed"] for r in checks),"checks_total":len(checks),
            "failures":[r for r in checks if not r["passed"]],"checks":checks,"metrics":metrics,
            "scope":"one native synthetic specimen per arm; no game/model/task benefit or latency guarantee"}


def main():
    p=argparse.ArgumentParser();p.add_argument("root",type=Path);p.add_argument("--out",type=Path,required=True);a=p.parse_args()
    result=audit(a.root.resolve());a.out.open("x").write(json.dumps(result,indent=2)+"\n")
    print(json.dumps({k:result[k] for k in ("status","checks_passed","checks_total","failures","metrics")}))
    return int(result["status"]=="FAIL")

if __name__=="__main__":raise SystemExit(main())

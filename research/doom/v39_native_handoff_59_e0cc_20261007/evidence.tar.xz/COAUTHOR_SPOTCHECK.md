# Saved evidence spot-check

Existing bugbot coauthor, read-only after v2 invocation; not a nonauthor content vote or merge approval. It independently confirmed 67/67 selected source hashes, 19 controller-loaded and39 child-loaded modules, stable two d and two a native DOWN/UP pairs, drop one d and one a pair, and the following retained same-guest monotonic ordering:

native a KeyPress observed5028215715533 < trigger5028215749741 < pixel changed5028424195431 < first typed health60 emit5028475182829 < invalidation evaluated5028490830278 < interrupt5028490882779 < completed stale answer5028491148240 < owner release verified5028492750636 < cancelled terminal5028493547354 < third planner turn5028516723274.

The next source is sequence12, capture5028471502407, with matching RGB hash and decoded red pixel(255,0,0). Owner stopped, Executor inactive, no remaining child thread, private Xvfb exited0. The coauthor also identified inherited report fields that are inapplicable to this synthetic fixture: claim, game_continued_during_model_calls, fixture_contract, measurement_session and planner_contract. These must be explicitly qualified in the public README. No native execution was performed by this reviewer.

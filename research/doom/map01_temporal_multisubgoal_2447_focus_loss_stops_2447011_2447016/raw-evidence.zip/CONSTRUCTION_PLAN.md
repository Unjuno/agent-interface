# Issue #2447 — focus-loss fail-closed admission probe

Status: fresh construction-only allocation 2447013; no formal rows/retries. Predecessors 2447011/2447012 were harness STOPs and are preserved unchanged.

## H/T/D/C/U

- **H:** If focus changes after a fresh observation but before the bounded key-down, InputOwner rejects admission, emits no key press, and leaves/re-establishes verified empty input state.
- **T:** In a private Docker Desktop X11 session, launch/focus a private xterm window, bind a fresh screenshot and lease to its observed focus/surface/geometry, switch focus to X11 PointerRoot, then attempt Right key-down once. Record actual focus, exception/admission, input state, release, and owner records.
- **D:** PASS_CONSTRUCTION only if focus differs before admission, key-down is refused (DecisionRequired or equivalent), no input_admission/keycode is present, and release/state are verified empty. Any admitted input, unchanged focus, or cleanup failure is FAIL/HOLD; no retries.
- **C:** Pinned image/source bundle, isolated Xvfb/Openbox desktop, no network, read-only root/source. Directly exercises unchanged repository InputOwner v10 focus guard.
- **U:** Synthetic desktop only; does not test focus loss during a game action, recovery, task effect, comparative gates, or Issue #2447 acceptance.

Case `issue2447-focus-loss-construction-2447013`; one observation, one post-observation focus loss, one Right key-down attempt; formal rows 0, retries 0.

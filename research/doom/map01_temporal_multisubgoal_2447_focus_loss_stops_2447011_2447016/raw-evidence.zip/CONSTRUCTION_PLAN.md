# Issue #2447 — focus-loss fail-closed admission probe

Status: fresh construction-only allocation 2447014; predecessors 2447011–2447013 were harness/setup STOPs and are preserved unchanged. Formal rows/retries: 0.

## H/T/D/C/U

- **H:** If focus changes after a fresh observation but before bounded key-down, InputOwner rejects admission, emits no key press, and leaves verified empty input state.
- **T:** In a private Docker Desktop X11 session, launch a private xmessage dialog, bind a fresh screenshot/lease to its observed focus/surface/geometry, set focus to X11 PointerRoot, then attempt Right key-down once. Record actual focus, admission result, state and release.
- **D:** PASS_CONSTRUCTION only if focus differs before admission, key-down is refused, no input_admission/keycode is present, and release/state are verified empty. Any admitted key, unchanged focus or cleanup failure is FAIL/HOLD; one attempt only.
- **C:** Pinned image/source bundle, isolated Xvfb/Openbox desktop, network none, read-only root/source. Directly exercises unchanged InputOwner v10 focus guard.
- **U:** Synthetic dialog only; not focus loss during a game action, recovery, task effect, comparative gates, or Issue #2447 acceptance.

ID `issue2447-focus-loss-construction-2447014`; one observation, one post-observation PointerRoot focus transfer, one Right key-down attempt.

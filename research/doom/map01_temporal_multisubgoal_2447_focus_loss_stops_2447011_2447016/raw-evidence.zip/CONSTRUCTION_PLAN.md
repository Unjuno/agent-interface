# Issue #2447 — focus-loss fail-closed admission probe

Status: fresh construction-only allocation 2447015. Allocations 2447011–2447014 stopped before testing focus policy; see predecessor notes. Formal rows/retries: 0.

## H/T/D/C/U

- **H:** If focus changes after a fresh observation but before bounded key-down, InputOwner rejects admission, emits no key press, and leaves verified empty input state.
- **T:** In the pinned private Docker Desktop X11 session, launch a private xmessage dialog without geometry overrides and wait up to 10s for Openbox/`wmctrl` visibility. Bind screenshot/lease to that dialog, set focus to PointerRoot, then attempt Right key-down once.
- **D:** PASS_CONSTRUCTION only if focus differs before admission, key-down is refused, no input_admission/keycode is present, and release/state are verified empty. Any admitted key, unchanged focus, setup timeout, or cleanup failure is recorded as STOP/FAIL/HOLD; no retry.
- **C:** Pinned image/source bundle, isolated Xvfb/Openbox desktop, no network, read-only root/source. Exercises unchanged InputOwner v10.
- **U:** Synthetic dialog only; not game-action focus loss, recovery, task effect, comparative gates, or Issue #2447 acceptance.

Case `issue2447-focus-loss-construction-2447015`; one observation, one post-observation PointerRoot transfer, one Right key-down attempt.

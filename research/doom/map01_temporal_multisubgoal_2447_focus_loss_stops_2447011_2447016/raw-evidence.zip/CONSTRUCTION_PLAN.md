# Issue #2447 — focus-loss fail-closed admission probe

Status: fresh construction-only allocation 2447011; no formal rows/retries.

## H/T/D/C/U

- **H:** If focus changes after a fresh observation but before the bounded key-down, InputOwner must reject admission, emit no key press, and leave/re-establish verified empty input state.
- **T:** In a private Docker Desktop X11 session, create two mapped windows. Bind a fresh screenshot/lease to the observation window, then transfer focus to the distractor immediately before attempting Right key-down. Capture the admission result, InputOwner state, release, and records.
- **D:** PASS_CONSTRUCTION only if focus changed, key-down yields DecisionRequired (or equivalent fail-closed refusal), no input_admission/keycode is present, and release/state are verified empty. Any admitted input, unclear focus, or cleanup failure is FAIL/HOLD; one attempt only.
- **C:** Pinned image/source bundle, isolated Xvfb desktop, no Doom/game model, no network, read-only root/source. Directly exercises the repository's unchanged InputOwner v10 focus guard.
- **U:** Synthetic X11 windows only; does not test focus loss during a running game action, recovery/retry, task effect, comparative gates, or Issue #2447 acceptance.

## Frozen case

ID `issue2447-focus-loss-construction-2447011`; one fresh observation; one deliberate post-observation focus transfer; one Right key-down attempt; formal rows 0; retries 0.

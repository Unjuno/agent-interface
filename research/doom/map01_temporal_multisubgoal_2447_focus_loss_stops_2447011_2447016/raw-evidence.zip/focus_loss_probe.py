from pathlib import Path
import argparse, hashlib, json, time
from Xlib import X, display
from common import Inputs, screenshot, write

def main():
    p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--out',required=True);a=p.parse_args();out=Path(a.out);out.mkdir(parents=True,exist_ok=False)
    from common import desktop
    session=desktop(a.source);d=display.Display(session.name);root=d.screen().root
    target=root.create_window(40,40,400,260,0,d.screen().root_depth,X.InputOutput,X.CopyFromParent,background_pixel=d.screen().white_pixel,event_mask=X.ExposureMask)
    distractor=root.create_window(500,40,300,220,0,d.screen().root_depth,X.InputOutput,X.CopyFromParent,background_pixel=d.screen().black_pixel,event_mask=X.ExposureMask)
    target.map();distractor.map();d.sync();time.sleep(.08);d.set_input_focus(X.RevertToParent,target,X.CurrentTime);d.sync();time.sleep(.03)
    geo=target.get_geometry();pos=root.translate_coords(target,0,0);binding=[pos.x,pos.y,geo.width,geo.height];focus_obj=d.get_input_focus().focus;focus_before=getattr(focus_obj,'id',focus_obj)
    ctx={'display':session.name,'focus':focus_before,'surface':target.id,'geometry':binding}
    image=screenshot(session.name,binding);image.save(out/'fresh-observation.png');image_hash=hashlib.sha256(image.tobytes()).hexdigest();observed_ns=time.perf_counter_ns()
    inp=Inputs(a.source,ctx,[]);lease=inp.lease(.3);d.set_input_focus(X.RevertToParent,distractor,X.CurrentTime);d.sync();time.sleep(.03);focus_obj=d.get_input_focus().focus;focus_after=getattr(focus_obj,'id',focus_obj);attempt_ns=time.perf_counter_ns();decision='UNSET';error=None
    try:
        inp.owner.call('down',lease,'Right');decision='ADMITTED'
    except Exception as e:
        error=repr(e);decision='REFUSED_'+type(e).__name__
    release=inp.release(lease);state=inp.owner.call('input_state');records=inp.owner.records;inp.close();d.close();session.close()
    result={'schema':'issue2447-focus-loss-probe-v1','case':'issue2447-focus-loss-construction-2447011','decision':decision,'error':error,'observed_ns':observed_ns,'attempt_ns':attempt_ns,'focus_before':focus_before,'focus_after':focus_after,'surface':target.id,'geometry':binding,'observation_sha256':image_hash,'key':'Right','input_admission_records':[r for r in records if r.get('event')=='input_admission'],'owned_keycodes_after':state.get('owned_keycodes'),'owned_buttons_after':state.get('owned_buttons'),'release':release,'owner_records':records}
    write(out/'result.json',result);write(out/'events.json',[]);print(json.dumps({k:result[k] for k in ('decision','focus_before','focus_after','owned_keycodes_after','owned_buttons_after')}))
if __name__=='__main__':main()

from pathlib import Path
import argparse, hashlib, json, time, subprocess
from Xlib import X, display
from common import Inputs, screenshot, write, desktop, context

def main():
    p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--out',required=True);a=p.parse_args();out=Path(a.out);out.mkdir(parents=True,exist_ok=False)
    session=desktop(a.source);session.spawn(['xmessage','-title','AI-FOCUS-TARGET','-geometry','400x260+40+40','-buttons','OK','Focus target'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    session.wait_window('AI-FOCUS-TARGET',timeout=5);ctx=context(session,'AI-FOCUS-TARGET');d=display.Display(ctx['display'])
    image=screenshot(ctx['display'],ctx['geometry']);image.save(out/'fresh-observation.png');image_hash=hashlib.sha256(image.tobytes()).hexdigest();observed_ns=time.perf_counter_ns()
    inp=Inputs(a.source,ctx,[]);lease=inp.lease(.3);d.set_input_focus(X.PointerRoot,X.RevertToParent,X.CurrentTime);d.sync();time.sleep(.03);focus_obj=d.get_input_focus().focus;focus_after=getattr(focus_obj,'id',focus_obj);attempt_ns=time.perf_counter_ns();decision='UNSET';error=None
    try:
        inp.owner.call('down',lease,'Right');decision='ADMITTED'
    except Exception as e:
        error=repr(e);decision='REFUSED_'+type(e).__name__
    release=inp.release(lease);state=inp.owner.call('input_state');records=inp.owner.records;inp.close();d.close();session.close()
    result={'schema':'issue2447-focus-loss-probe-v1','case':'issue2447-focus-loss-construction-2447014','decision':decision,'error':error,'observed_ns':observed_ns,'attempt_ns':attempt_ns,'focus_before':ctx['focus'],'focus_after':focus_after,'surface':ctx['surface'],'geometry':ctx['geometry'],'observation_sha256':image_hash,'key':'Right','input_admission_records':[r for r in records if r.get('event')=='input_admission'],'owned_keycodes_after':state.get('owned_keycodes'),'owned_buttons_after':state.get('owned_buttons'),'release':release,'owner_records':records}
    write(out/'result.json',result);write(out/'events.json',[]);print(json.dumps({k:result[k] for k in ('decision','focus_before','focus_after','owned_keycodes_after','owned_buttons_after')}))
if __name__=='__main__':main()

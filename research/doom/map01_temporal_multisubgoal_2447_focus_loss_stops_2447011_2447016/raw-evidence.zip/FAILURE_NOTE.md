# Allocation 2447012 — harness STOP

The frozen Docker invocation failed before injecting the focus-loss fault. PyXlib rejected the `set_input_focus` call with `ValueError: field revert_to: argument <Window ...> not in (0, 1, 2)`, revealing the focus/revert arguments were reversed in this successor. No admission or cleanup result was produced. No same-allocation retry.

# Allocation 2447011 — harness STOP

The frozen Docker invocation exited before producing a probe result. PyXlib raised X11 `BadMatch` during `set_input_focus` on a newly created window, followed by an `AttributeError` because the focus query returned the integer root-focus sentinel. The window was not a reliable viewable/focusable target in this session. No focus-loss fault was injected and no hypothesis result was obtained. This allocation is not retried; successors use mapped app windows.

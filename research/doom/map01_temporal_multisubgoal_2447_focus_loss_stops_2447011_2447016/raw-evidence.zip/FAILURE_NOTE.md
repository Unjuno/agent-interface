# Allocation 2447016 — direct-session readiness STOP

The frozen Docker run used `gui_suite.Session` directly but still timed out after 10 seconds waiting for the xmessage window in `wmctrl -l`. No fresh observation was recorded, no PointerRoot transfer/admission was attempted, and no focus-guard conclusion follows. No same-allocation retry.

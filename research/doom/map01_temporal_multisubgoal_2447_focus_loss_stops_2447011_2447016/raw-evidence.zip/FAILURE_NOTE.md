# Allocation 2447013 — window readiness STOP

The corrected probe exited before capturing the fresh observation. The private X session did not register `AI-FOCUS-TARGET` within 5 seconds (`TimeoutError: window AI-FOCUS-TARGET`), so the focus fault was never injected and no InputOwner admission result exists. Container inspection confirmed `/usr/bin/xterm` is installed; its launched window was nevertheless absent from `wmctrl -l`. This allocation is not retried; the successor uses a different small X11 dialog target.

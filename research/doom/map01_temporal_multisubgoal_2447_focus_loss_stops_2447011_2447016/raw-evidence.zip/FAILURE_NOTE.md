# Allocation 2447014 — dialog readiness STOP

The frozen Docker run timed out after 5 seconds waiting for `AI-FOCUS-TARGET` to appear in the private session's `wmctrl -l` window list. It produced no observation or InputOwner admission result; the focus-loss fault was not injected. A separate diagnostic showed xmessage could remain alive while the window manager had not yet registered it. No same-allocation retry.

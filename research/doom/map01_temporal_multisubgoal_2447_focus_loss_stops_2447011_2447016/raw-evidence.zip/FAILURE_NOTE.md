# Allocation 2447015 — dialog readiness STOP

The frozen Docker run again timed out waiting 10 seconds for `AI-FOCUS-TARGET` in `wmctrl -l`, even after removing xmessage geometry arguments. No observation or key admission was attempted; no hypothesis result. No same-allocation retry.

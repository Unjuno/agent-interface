# Issue #2447 — focus-loss probe harness STOP series (2447011–2447016)

Six fresh construction allocations were frozen and attempted in Docker Desktop using the pinned Linux/amd64 image. None injected the intended post-observation focus-loss fault, so **there is no result about InputOwner focus-guard behavior**. These are STOPs, not PASS/FAIL on the hypothesis. Formal rows: 0; retries of any allocation: 0.

| Allocation | Stop point |
|---|---|
| 2447011 | X11 `BadMatch` while focusing a newly created synthetic window; focus query then returned a root sentinel. Target was not a reliable viewable focus target. |
| 2447012 | Harness called PyXlib `set_input_focus` arguments in the wrong order; API rejected the revert value as a Window resource. |
| 2447013 | Private xterm did not appear in `wmctrl -l` within 5s. |
| 2447014 | xmessage did not appear in `wmctrl -l` within 5s with explicit geometry. |
| 2447015 | Same xmessage readiness timeout after removing geometry and extending wait to 10s. |
| 2447016 | Same 10s readiness timeout using `gui_suite.Session` directly. |

A separate short Docker diagnostic (not a scheduled allocation) found xmessage alive while its X window was initially `IsUnmapped` and absent from `wmctrl`; in a later timing sample, the direct session showed it after about one second. The behavior is a session/window-manager readiness race. It does not prove an InputOwner defect or safety property.

## H/T/D/C/U retained

- **H:** A focus change after an observation and before key-down should make InputOwner fail closed without admitting input.
- **T:** Intended one private X11 dialog, fresh observation/lease, transfer to PointerRoot, single Right key-down.
- **D:** Require actual focus change, explicit refused admission, no input admission/keycode, and verified empty release. All six stopped before these checks.
- **C:** Same pinned local Docker image/source bundle; isolated Xvfb/Openbox and network disabled.
- **U:** No game/task effect, no recovery, and no evidence on the focus guard itself. A different harness/window-readiness method or a different Issue hypothesis is needed before spending another allocation on this fault.

Each allocation's frozen plan/source and its STOP note are archived alongside this report. No raw GUI frame existed for these failures because the failures occurred before the observation stage.

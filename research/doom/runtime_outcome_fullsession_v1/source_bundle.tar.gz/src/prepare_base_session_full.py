"""Reconstruct the measured base_session_full.py from pinned main v12 bytes."""
from pathlib import Path
import argparse,hashlib
BASE_BLOB='0ac2d3c1d84e27f87c68dd6cbcbbd82f90209747'
EXPECTED_SHA256='6700d1cb058c2921581e2ab15079a8950f3c78eb1d595ea5523a79f6cf7a51c9'

def generate(runtime:Path,target:Path):
    original=runtime/'research/doom/session_map01_v12.py';data=original.read_bytes()
    blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    if blob!=BASE_BLOB:raise RuntimeError('source blob mismatch')
    text=data.decode();begin=text.index('                    if not game.is_episode_finished():',text.index('elif command["op"] == "finish"'));end=text.index('                    (args.out / "score.json")',begin)
    replacement='''                    refresh_called = not game.is_episode_finished()\n                    if refresh_called:\n                        game.advance_action(1, True)\n                    from runtime_score import build_score\n                    score, outcome_record = build_score(\n                        game, vd.GameVariable, mode=os.environ["OUTCOME_MODE"],\n                        skill=args.skill, timeout_seconds=args.timeout_seconds,\n                        control_started_ns=control_started_ns,\n                        refresh_called=refresh_called)\n                    with (args.out / "score-acquisition.json").open("x") as record:\n                        json.dump(outcome_record, record, indent=2)\n'''
    generated=text[:begin]+replacement+text[end:]
    # The measured full-session variant was produced by reading the prior candidate with universal-newline normalization.
    generated=generated.replace('\r\n','\n')
    generated=generated.replace('HERE = Path(__file__).resolve().parent','HERE = Path(os.environ["AI_RUNTIME_ROOT"]).resolve() / "research/doom"')
    generated=generated.replace('str(path.relative_to(HERE.parent))','(str(path.relative_to(HERE.parent)) if path.is_relative_to(HERE.parent) else "candidate/" + path.name)')
    generated=generated.replace('''            game.set_doom_game_path(str(iwad))\n            game.set_doom_scenario_path("")\n            game.set_doom_map("MAP01")''','''            game.set_doom_game_path(str(iwad))\n            scenario_path = os.environ.get("AI_SCENARIO_WAD", "")\n            game.set_doom_scenario_path(scenario_path)\n            game.set_doom_map("MAP01")''')
    generated=generated.replace('''            "scenario_path": None, "iwad": str(iwad),''','''            "scenario_path": (scenario_path or None), "iwad": str(iwad),''')
    target.write_text(generated)
    got=hashlib.sha256(target.read_bytes()).hexdigest()
    if got!=EXPECTED_SHA256:raise RuntimeError(f'reconstruction hash mismatch: {got}')
    return got
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('runtime',type=Path);a.add_argument('target',type=Path);x=a.parse_args();print(generate(x.runtime,x.target))

from pathlib import Path
import argparse, json, time
import cv2, numpy as np
from PIL import Image
from Xlib import display
from common import screenshot, write

ROI=(20,300,20,620); MIN_TRACKS=80; DY_THRESHOLD=-20.0; MAX_PAIR_DT_MS=100.0

def metric(a,b):
    x=np.asarray(a.convert('L'),np.uint8)[ROI[0]:ROI[1],ROI[2]:ROI[3]]
    y=np.asarray(b.convert('L'),np.uint8)[ROI[0]:ROI[1],ROI[2]:ROI[3]]
    p=cv2.goodFeaturesToTrack(x,maxCorners=700,qualityLevel=.01,minDistance=6,blockSize=7)
    if p is None:return {'valid_tracks':0,'median_dy_px':None,'status':'UNKNOWN'}
    q,s,_=cv2.calcOpticalFlowPyrLK(x,y,p,None,winSize=(31,31),maxLevel=4,criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,30,.01))
    if q is None or s is None:return {'valid_tracks':0,'median_dy_px':None,'status':'UNKNOWN'}
    d=q[s[:,0]==1,0,:]-p[s[:,0]==1,0,:]
    if len(d):d=d[np.hypot(d[:,0],d[:,1])<100]
    n=len(d)
    if n<MIN_TRACKS:return {'valid_tracks':int(n),'median_dy_px':None,'status':'UNKNOWN'}
    med=float(np.median(d[:,1]));return {'valid_tracks':int(n),'median_dy_px':med,'status':'DROP_COMPLETED' if med<=DY_THRESHOLD else 'NO_DROP'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--ctx',required=True);p.add_argument('--out',required=True);p.add_argument('--duration-ms',type=int,default=450);a=p.parse_args()
    out=Path(a.out);out.mkdir(parents=True,exist_ok=False);ctx=json.loads(Path(a.ctx).read_text());d=display.Display(ctx['display']);root=d.screen().root;win=d.create_resource_object('window',ctx['surface']);geo=win.get_geometry();pos=root.translate_coords(win,0,0);binding=[pos.x,pos.y,geo.width,geo.height];focus=d.get_input_focus().focus.id
    if focus!=ctx['focus'] or binding!=ctx['geometry']:raise RuntimeError('RECHECK_BINDING_MISMATCH')
    frames=[];starts=[];names=[];deadline=time.perf_counter()+a.duration_ms/1000
    while time.perf_counter()<deadline:
        starts.append(time.perf_counter_ns());im=screenshot(ctx['display'],binding);name=f'{len(frames):03d}-recheck.png';im.save(out/name);frames.append(im);names.append(name);time.sleep(.025)
    d.close();pairs=[]
    for i,(x,y) in enumerate(zip(frames,frames[1:])):
        m=metric(x,y);m.update(i0=i,i1=i+1,dt_ms=(starts[i+1]-starts[i])/1e6);pairs.append(m)
    eligible=[m for m in pairs if m['dt_ms']<=MAX_PAIR_DT_MS and m['valid_tracks']>=MIN_TRACKS and m['median_dy_px'] is not None]
    status='DROP_COMPLETED' if any(m['median_dy_px']<=DY_THRESHOLD for m in eligible) else ('UNKNOWN' if not eligible else 'NO_DROP')
    write(out/'result.json',{'schema':'agent-interface/phase-recheck-v1','status':status,'frame_files':names,'frame_capture_start_ns':starts,'pairs':pairs,'eligible_pairs':len(eligible),'drop_pairs':[m['i0'] for m in eligible if m['median_dy_px']<=DY_THRESHOLD],'binding':{'focus':focus,'surface':ctx['surface'],'geometry':binding},'input_emissions':0,'duration_ms':a.duration_ms})
    write(out/'events.json',[]);print(json.dumps({'status':status,'eligible_pairs':len(eligible),'input_emissions':0}))
if __name__=='__main__':main()

from pathlib import Path
import argparse, hashlib, json
import cv2, numpy as np
from PIL import Image

ROI=(20,300,20,620); MIN_TRACKS=80; DY=-20.0; MAX_DT=100.0
def flow(a,b):
    x=np.asarray(a.convert('L'),np.uint8)[ROI[0]:ROI[1],ROI[2]:ROI[3]];y=np.asarray(b.convert('L'),np.uint8)[ROI[0]:ROI[1],ROI[2]:ROI[3]]
    p=cv2.goodFeaturesToTrack(x,maxCorners=700,qualityLevel=.01,minDistance=6,blockSize=7)
    if p is None:return {'n':0,'dy':None}
    q,s,_=cv2.calcOpticalFlowPyrLK(x,y,p,None,winSize=(31,31),maxLevel=4,criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,30,.01))
    if q is None or s is None:return {'n':0,'dy':None}
    d=q[s[:,0]==1,0,:]-p[s[:,0]==1,0,:]
    if len(d):d=d[np.hypot(d[:,0],d[:,1])<100]
    return {'n':int(len(d)),'dy':None if len(d)<MIN_TRACKS else float(np.median(d[:,1]))}
def main():
    p=argparse.ArgumentParser();p.add_argument('--evidence',required=True);p.add_argument('--out',required=True);a=p.parse_args();root=Path(a.evidence);s=json.loads((root/'score.json').read_text());errors=[]
    if s.get('seed')!=2447008 or s.get('gate')!='temporal_gate' or s.get('class')!='drop':errors.append('identity')
    if s.get('phase1',{}).get('temporal_status')!='NO_DROP' or s.get('extra_forward_issued') is not True:errors.append('initial_no_drop_continuation')
    if not (root/'phase2/result.json').exists():errors.append('missing_bounded_continuation')
    rr=json.loads((root/'phase_recheck/result.json').read_text());imgs=[Image.open(root/'phase_recheck'/n).convert('RGB') for n in rr['frame_files']];starts=rr['frame_capture_start_ns'];pairs=[]
    for i,(x,y) in enumerate(zip(imgs,imgs[1:])):
        m=flow(x,y);m.update(i0=i,dt_ms=(starts[i+1]-starts[i])/1e6);pairs.append(m)
    eligible=[m for m in pairs if m['dt_ms']<=MAX_DT and m['n']>=MIN_TRACKS and m['dy'] is not None]
    status='DROP_COMPLETED' if any(m['dy']<=DY for m in eligible) else ('UNKNOWN' if not eligible else 'NO_DROP')
    if status!=rr.get('status') or status!='NO_DROP':errors.append('raw_recheck_status')
    if rr.get('input_emissions')!=0 or (root/'phase_recheck/events.json').read_text().strip()!='[]':errors.append('observer_input_not_zero')
    if s.get('terminal_decision')!='STOP_PHASE_NOT_CONFIRMED' or s.get('handoff_gate')!='REFUSE_NO_DROP' or s.get('stop_reason')!='FAIL_CLOSED_PHASE_RECHECK:NO_DROP':errors.append('stop_decision')
    if (root/'next_subgoal').exists() or (root/'third_subgoal').exists():errors.append('subgoal_was_emitted')
    owner=[]
    for f in [root/'setup-owner-records.json',root/'phase1/owner-records.json',root/'phase2/owner-records.json']:
        if f.exists():owner.extend(json.loads(f.read_text()))
    rel=[x for x in owner if x.get('event')=='owner_release'];clean=bool(rel) and all(x.get('verified') and not x.get('keys_down') and not x.get('buttons_down') for x in rel)
    if not clean:errors.append('release_cleanup')
    out={'schema':'issue2447-gate-recheck-audit-v1','case':'issue2447-gate-recheck-construction-2447008','decision':'PASS_CONSTRUCTION_FAIL_CLOSED_STOP' if not errors else 'HOLD_CONSTRUCTION','errors':errors,'initial_phase':{'status':s.get('phase1',{}).get('temporal_status'),'continuation_issued':s.get('extra_forward_issued')},'recheck':{'raw_status':status,'reported_status':rr.get('status'),'pairs':pairs,'eligible_pairs':len(eligible),'input_emissions':rr.get('input_emissions')},'runner':{'terminal_decision':s.get('terminal_decision'),'next_subgoal_emitted':(root/'next_subgoal').exists()},'cleanup':{'release_count':len(rel),'all_verified_empty':clean},'formal_rows':0,'retries':0,'scope':'One construction-only fail-closed phase handoff check; not comparative evaluation or Issue #2447 acceptance.'}
    Path(a.out).write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps(out,sort_keys=True))
if __name__=='__main__':main()

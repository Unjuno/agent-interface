# Issue #2447 — post-continuation gate recheck

Status: new construction-only allocation 2447008; no formal rows and no retries.

## H/T/D/C/U

- **H:** A bounded extra-forward issued because the phase is not yet detected complete must not be followed by a new subgoal until fresh visual evidence independently reports `DROP_COMPLETED`. `NO_DROP` and `UNKNOWN` must stop/fail closed.
- **T:** One fresh MAP01 drop episode, seed 2447008, temporal gate, heading 120°. Preserve the inherited first phase attempt. If it requests continuation, issue exactly one bounded continuation, then use an input-free observer to collect fresh frames and recompute the same temporal detector. Record whether handoff is admitted or refused. No retry.
- **D:** PASS_CONSTRUCTION only if the post-continuation status is `DROP_COMPLETED` and the observer's raw frames independently recompute to the same status before any next-subgoal input. Otherwise STOP/HOLD with zero next-subgoal emissions. A mismatch, observer failure, or unknown status also stops; releases must remain empty.
- **C:** Same Docker Desktop Linux/amd64 image and source fixture; only the post-continuation gate is added. Observer reads X11 pixels and binding only; hidden Doom state is excluded from admission.
- **U:** Single construction episode; no endpoint comparison, formal rates, full fault matrix, held-out transfer, or episode-completion claim.

## Frozen parameters

Seed 2447008; temporal gate; requested heading 120°; one extra-forward maximum; 450ms observation-only recheck; frames sampled about every 25ms; adjacent-pair thresholds inherited from phase1 (<=100ms, >=80 tracks, median dy <= -20px).

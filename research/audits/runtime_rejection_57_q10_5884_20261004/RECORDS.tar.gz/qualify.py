import pathlib,shutil,subprocess,json,hashlib,tarfile,datetime
w=pathlib.Path(__file__).resolve().parent;b=w/'bundle';b.mkdir()
shutil.copytree(w/'source',b/'source')
runner="import pathlib,subprocess,json,sys,os\nroot=pathlib.Path(__file__).resolve().parent;source=root/'source';out=root/'results';out.mkdir()\ncg=next(x.split(':',2)[2] for x in pathlib.Path('/proc/self/cgroup').read_text().splitlines() if x.startswith('0::'));r=pathlib.Path('/sys/fs/cgroup'+cg);(out/'resources.json').write_text(json.dumps({k:(r/k).read_text().strip() for k in ['cpu.max','memory.max','pids.max']}))\nfor mode,flag in [('normal',[]),('optimized',['-O'])]:\n p=subprocess.run([sys.executable]+flag+['-m','unittest','-v','test_durable_invalid_response_v1','test_integrated_efficiency_custody_v1','test_integrated_efficiency_pending_v1','test_integrated_efficiency_startup_v1'],env=dict(os.environ,PYTHONPATH=str(source)),capture_output=True,timeout=15);(out/(mode+'.stdout')).write_bytes(p.stdout);(out/(mode+'.stderr')).write_bytes(p.stderr);(out/(mode+'.exit')).write_text(str(p.returncode));assert p.returncode==0\n"
(b/'run.py').write_text(runner)
m={str(p.relative_to(b)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in b.rglob('*') if p.is_file() and '__pycache__' not in p.parts};(b/'manifest.json').write_text(json.dumps(m,indent=2))
with tarfile.open(w/'transfer.tar','w') as t:
 for key in list(m)+['manifest.json']:t.add(b/key,arcname=key)
vm='unjuno-57-5884-debian-a02-20261003';orb='/opt/homebrew/bin/orbctl';root='/home/study/57-runtime-rejection-q10-integration';rows=[]
def call(name,args,data=None,allow=False):
 p=subprocess.Popen(args,stdin=subprocess.PIPE if data is not None else None,stdout=subprocess.PIPE,stderr=subprocess.PIPE);start=datetime.datetime.now(datetime.timezone.utc).isoformat();out,err=p.communicate(data,timeout=55);(w/(name+'.stdout')).write_bytes(out);(w/(name+'.stderr')).write_bytes(err);rows.append({'stage':name,'pid':p.pid,'started':start,'ended':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode});(w/'receipts.json').write_text(json.dumps(rows,indent=2));
 if p.returncode and not allow:raise RuntimeError(name+' failed')
try:
 call('start',[orb,'start',vm]);call('transfer',[orb,'run','-m',vm,'-u','root','/bin/bash','-c',f'set -e; mkdir {root}; tar -xf - -C {root}; chown -R study:study {root}'],(w/'transfer.tar').read_bytes())
 call('verify',[orb,'run','-m',vm,'-u','root','python3','-c',f"import json,pathlib,hashlib;r=pathlib.Path('{root}');m=json.loads((r/'manifest.json').read_text());bad=[k for k,v in m.items() if hashlib.sha256((r/k).read_bytes()).hexdigest()!=v['sha256']];print({{'files':len(m),'bad':bad}});assert not bad"])
 call('tests',[orb,'run','-m',vm,'-u','root','systemd-run','--unit=unjuno-57-q10-integration-5884','--wait','--pipe','--property=User=study',f'--property=WorkingDirectory={root}','--property=CPUQuota=25%','--property=MemoryMax=134217728','--property=TasksMax=32','--property=RuntimeMaxSec=40','--property=KillMode=control-group','/usr/bin/python3','run.py'],allow=True)
 call('collect',[orb,'run','-m',vm,'-u','root','tar','-czf','-','-C',root,'results'])
finally:
 call('stop',[orb,'stop',vm]);call('state',[orb,'info',vm])

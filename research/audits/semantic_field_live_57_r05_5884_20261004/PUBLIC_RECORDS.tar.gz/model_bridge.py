"""Linux-only sequential bounded filesystem model-call adapter for the existing runner."""
import hashlib,json,os,pathlib,shutil,time
class ModelBridge:
 def __init__(self,root,*,timeout=45,clock=time.monotonic,sleeper=time.sleep):
  self.root=pathlib.Path(root);self.root.mkdir(exist_ok=False);self.timeout=timeout;self.clock=clock;self.sleep=sleeper;self.count=0;self.history=[];self.failed=False
 def call(self,root,prompt,image,contract,workspace):
  if self.failed:raise RuntimeError('bridge previously failed; replay disabled')
  if contract not in ('plain','compiled'):raise ValueError('unknown contract')
  self.count+=1;index=self.count;deadline=self.clock()+self.timeout;image=pathlib.Path(image);raw=image.read_bytes();target=self.root/f'input-{index:03d}.png';target.write_bytes(raw)
  request={'index':index,'contract':contract,'prompt':prompt,'image_sha256':hashlib.sha256(raw).hexdigest(),'image_name':target.name,'deadline_monotonic':deadline,'pid':os.getpid(),'pid_start':pathlib.Path('/proc/self/stat').read_text().split()[21],'root':str(root),'workspace':str(workspace)}
  intent=self.root/f'request-{index:03d}.json';tmp=intent.with_suffix('.tmp');tmp.write_text(json.dumps(request,indent=2)+'\n');tmp.replace(intent)
  entry={'index':index,'state':'sent','image_sha256':request['image_sha256'],'contract':contract};self.history.append(entry)
  reply=self.root/f'answer-{index:03d}.json'
  try:
   while not reply.exists():
    if self.clock()>=deadline:raise TimeoutError('model bridge deadline; unknown reply; no resend')
    self.sleep(.05)
   if self.clock()>=deadline:raise TimeoutError('late model reply; no input')
   response=json.loads(reply.read_text())
   if response['index']!=index or response['image_sha256']!=request['image_sha256']or response['contract']!=contract:raise ValueError('model response ownership mismatch')
   if response.get('status')!='completed':raise RuntimeError('model stage failed')
   result=response['result'];required={'raw','grounding','usage','call_id','requested_model','requested_effort','cost'}
   if set(result)!=required:raise ValueError('exact existing model result fields required')
   if type(result['usage']) is not dict or set(result['usage']) != {'input_tokens', 'cached_input_tokens', 'cache_write_input_tokens', 'output_tokens', 'reasoning_output_tokens'} or any(type(v) is not int or v < 0 for v in result['usage'].values()):raise ValueError('actual complete usage required')
   entry['state']='completed';entry['call_id']=result['call_id'];entry['usage']=result['usage'];return result
  except BaseException as e:
   self.failed=True;entry['state']='failed';entry['error']=type(e).__name__;raise
  finally:(self.root/'ledger.json').write_text(json.dumps(self.history,indent=2)+'\n')

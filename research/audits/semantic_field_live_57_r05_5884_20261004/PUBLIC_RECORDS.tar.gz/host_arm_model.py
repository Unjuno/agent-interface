"""Native per-arm sequential grounding relay. Requires an already running own guest arm."""
import argparse
import base64
import hashlib
import json
import pathlib
import signal
import subprocess
import sys
import time

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'source' / 'research' / 'live_control'))
from codex_app_server_client_v2 import CodexAppServerClient
from integrated_efficiency_app_server_model_v1 import PersistentGroundingModel


def exchange(guest, guest_helper, operation, bridge, index, payload=None):
    result = subprocess.run([
        '/opt/homebrew/bin/orbctl', 'run', '-m', guest, '-u', 'study',
        '/usr/bin/python3', guest_helper, operation, bridge, str(index)],
        input=payload, capture_output=True, timeout=5, check=True)
    return json.loads(result.stdout)


class BoundedPlanner:
    def __init__(self, planner):
        self.planner = planner
    def begin_turn(self, *args, **kwargs):
        return self.planner.begin_turn(*args, **kwargs)
    def await_turn(self, handle, timeout):
        return self.planner.await_turn(handle, timeout=min(timeout, 35))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', required=True)
    parser.add_argument('--guest', required=True)
    parser.add_argument('--guest-helper', required=True)
    parser.add_argument('--bridge', required=True)
    parser.add_argument('--contract', choices=['plain', 'compiled'], required=True)
    parser.add_argument('--calls', type=int, required=True)
    args = parser.parse_args()
    if not 1 <= args.calls <= 6:
        raise ValueError('per-arm call cap')
    root = pathlib.Path(args.root)
    root.mkdir(mode=0o700, exist_ok=False)
    workspace = root / 'workspace'
    workspace.mkdir()
    client = None
    ledger = []
    def expire(*unused):
        raise TimeoutError('host arm deadline; no resend')
    signal.signal(signal.SIGALRM, expire)
    signal.alarm(300)
    try:
        # Same native command and same persistent-context policy for every arm.
        client = CodexAppServerClient(
            json.loads((HERE / 'command.private.json').read_text()),
            cwd=str(workspace), journal_path=str(root / 'protocol.private.jsonl'))
        client.initialize(name='agent-interface-three-arm', version='l01')
        model = PersistentGroundingModel(
            root / 'model-session', workspace, node=None, cli=None,
            contract=args.contract, model='gpt-5.6-luna', effort='low',
            client=client, path_converter=lambda path: str(path))
        model.planner = BoundedPlanner(model.planner)
        for index in range(1, args.calls + 1):
            pending_deadline = time.monotonic() + 60
            while True:
                record = exchange(args.guest, args.guest_helper, 'get', args.bridge, index)
                if record['state'] == 'live':
                    break
                if time.monotonic() >= pending_deadline:
                    raise TimeoutError('no next request within finite window')
                time.sleep(0.5)
            request = record['request']
            if request['contract'] != args.contract or record['remaining_seconds'] < 38:
                raise ValueError('wrong contract or insufficient guest window')
            image = base64.b64decode(record['image_base64'], validate=True)
            if hashlib.sha256(image).hexdigest() != request['image_sha256']:
                raise ValueError('transfer image mismatch')
            path = root / ('image-%03d.png' % index)
            path.write_bytes(image)
            intent = {'index': index, 'image_sha256': request['image_sha256'],
                      'guest_request': request, 'state': 'registered-before-provider'}
            ledger.append(intent)
            (root / 'ledger.private.json').write_text(json.dumps(ledger, indent=2) + '\n')
            fresh = exchange(args.guest, args.guest_helper, 'get', args.bridge, index)
            if (fresh['state'] != 'live' or fresh['request'] != request
                    or fresh['remaining_seconds'] < 38):
                raise ValueError('request changed or insufficient live provider window')
            result = model.call(root / ('call-%03d' % index), request['prompt'],
                                path, args.contract, workspace)
            # Provider IDs remain private; this digest identifies the actual turn.
            projected = {key: result[key] for key in [
                'raw', 'grounding', 'usage', 'requested_model', 'requested_effort', 'cost']}
            projected['call_id'] = hashlib.sha256(
                (result['thread_id'] + ':' + result['turn_id']).encode()).hexdigest()
            answer = {'index': index, 'contract': args.contract,
                      'image_sha256': request['image_sha256'],
                      'status': 'completed', 'result': projected}
            payload = (json.dumps(answer) + '\n').encode()
            (root / ('answer-%03d.json' % index)).write_bytes(payload)
            # Guest revalidates live generation, clock and image before atomic put.
            intent['publication'] = exchange(
                args.guest, args.guest_helper, 'put', args.bridge, index, payload)
            intent['state'] = 'published'
            (root / 'ledger.private.json').write_text(json.dumps(ledger, indent=2) + '\n')
    except BaseException as error:
        (root / 'failure.json').write_text(json.dumps({
            'error_type': type(error).__name__, 'message': str(error),
            'provider_requests_registered': len(ledger),
            'no_resend': True}, indent=2) + '\n')
        raise
    finally:
        signal.alarm(0)
        if client is not None:
            client.close(timeout=3)
        (root / 'ledger.private.json').write_text(json.dumps(ledger, indent=2) + '\n')

if __name__ == '__main__':
    main()

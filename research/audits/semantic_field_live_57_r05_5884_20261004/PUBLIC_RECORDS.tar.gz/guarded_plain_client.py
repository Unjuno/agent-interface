"""Plain model coordinates with shared ephemeral runtime admission guards.

No model-authored method or cross-task symbol reuse. Preserve six-operation
batching. Whole-program target resolution is not atomic with later input;
the historical runtime's binding checks and check-to-input race remain.
"""
import time
from integrated_efficiency_client_v1 import RuntimeClient


class GuardedPlainClient(RuntimeClient):
    def navigate(self, task):
        source = super().navigate(task)
        self.plain_source = source
        return source

    def execute_plain(self, task, grounding):
        started = time.perf_counter_ns()
        aliases, refusal = self.mint(
            task['layout'], self.plain_source, grounding,
            'plain_' + task['task_id'])
        if refusal is not None:
            return self._plain_stop('source_dependency_refused', started)
        for kind, offset in [('field', [12, 19]), ('submit', [12, 7])]:
            checked, program = self.check(
                aliases[kind], offset, 'plain-guard-' + kind + '-' + task['task_id'])
            if not checked['eligible']:
                return self._plain_stop('target_dependency_refused', started)
        # Runtime prepare resolves both freshly checked targets before admission.
        # The real reference retains its batching capability, including settle.
        row = self.submit('plain-batch-' + task['task_id'], [
            {'op': 'pointer_click_target', 'target_handle': aliases['field'],
             'offset': [12, 19], 'button': 1, 'duration_ms': 80},
            {'op': 'chord', 'modifier': 'Control_L', 'key': 'a'},
            {'op': 'text', 'text': task['token']},
            {'op': 'settle', 'quiet_ms': 80, 'timeout_ms': 500},
            {'op': 'pointer_click_target', 'target_handle': aliases['submit'],
             'offset': [12, 7], 'button': 1, 'duration_ms': 80},
            {'op': 'settle', 'quiet_ms': 80, 'timeout_ms': 500},
        ])
        return {'status': 'completed' if row['terminal']['status'] == 'completed' else 'failed',
                'started_ns': started, 'ended_ns': time.perf_counter_ns()}

    @staticmethod
    def _plain_stop(reason, started):
        return {'status': 'safe_yield', 'reason': reason, 'completed_actions': 0,
                'started_ns': started, 'ended_ns': time.perf_counter_ns()}

import pathlib,json,hashlib,subprocess,tarfile,datetime,signal,os
w=pathlib.Path(__file__).resolve().parent;vm='unjuno-57-5884-debian-a02-20261003';orb='/opt/homebrew/bin/orbctl';guest='/home/study/57-semantic-field-live-r05';receipts=[];unit=None
pins={str(p.relative_to(w)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in w.rglob('*') if p.is_file() and '__pycache__' not in str(p)}
freeze={'run_id':'57-semantic-field-live-R05-20261004-5884','seed':57041017,'H':'Fresh typed semantic grounding selects Value despite preceding Scratch and guarded live execution produces one exact task1 POST','T':'One fresh plain-schema preflight then one fresh live screenshot grounding, one guarded plain task1; no R03/R04 replay','D':'Exactly1 task1 correctPOST, no unexpected/duplicates, runtime target checks/admissions/release retained, model/fullusage/sourcehashes/livegeneration joined. Other5tasks intentionally unattempted; original fulloraclefalse expected, not broadsuccess','C':'Prompt explicit Value/ignoreScratch, known fixture, no strongest adaptive keyboard semantic selector comparator yet','U':'No fullsix/globalphysical/general GUI or causal speedup; check-to-input races remain','pins':pins,'caps':{'cpu_percent':100,'memory_bytes':805306368,'tasks':256,'unit_seconds':120,'driver_seconds':100,'model_bridge_seconds':45,'provider_await_seconds':35,'host_model_seconds':60,'collection_posthoc_bytes':10485760}}
(w/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
def call(name,args,timeout=80,data=None):
 t=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.Popen(args,stdin=subprocess.PIPE if data else None,stdout=subprocess.PIPE,stderr=subprocess.PIPE);o,e=p.communicate(data,timeout=timeout);(w/(name+'.stdout')).write_bytes(o);(w/(name+'.stderr')).write_bytes(e);receipts.append({'stage':name,'pid':p.pid,'argv':args,'start':t,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode});assert p.returncode==0,name
try:
 call('preflight',['python3',str(w/'fresh_preflight.py'),'--root',str(w/'preflight-private')])
 assert json.loads((w/'preflight-private/receipt.json').read_text())['state']=='compatible'
 with tarfile.open(w/'transfer.tar','w') as t:
  for p in (w/'source').rglob('*'):
   if p.is_file():t.add(p,arcname=str(p.relative_to(w)))
  for name in ['driver.py','model_bridge.py','guest_exchange.py','guarded_plain_client.py']:t.add(w/name,arcname=name)
 call('vm-start',[orb,'start',vm])
 call('transfer',[orb,'run','-m',vm,'-u','root','/bin/bash','-c',f'set -e; mkdir {guest}; tar -xf - -C {guest}; chown -R study:study {guest}'],data=(w/'transfer.tar').read_bytes())
 args=[orb,'run','-m',vm,'-u','root','systemd-run','--unit=unjuno-57-r05-semantic-5884','--wait','--pipe','--property=User=study',f'--property=WorkingDirectory={guest}','--property=CPUQuota=100%','--property=MemoryMax=805306368','--property=TasksMax=256','--property=RuntimeMaxSec=120','--property=KillMode=control-group','python3','driver.py']
 unit=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE);start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 call('host-model',['python3',str(w/'host_arm_model.py'),'--root',str(w/'model-private'),'--guest',vm,'--guest-helper',guest+'/guest_exchange.py','--bridge',guest+'/actual/bridge','--contract','plain','--calls','1'],timeout=60)
 o,e=unit.communicate(timeout=30);(w/'native.stdout').write_bytes(o);(w/'native.stderr').write_bytes(e);receipts.append({'stage':'native','pid':unit.pid,'argv':args,'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':unit.returncode});assert unit.returncode==0
 call('collect',[orb,'run','-m',vm,'-u','root','tar','-czf','-','-C',guest,'actual'])
finally:
 if unit is not None and unit.poll() is None:
  call('own-unit-stop',[orb,'run','-m',vm,'-u','root','systemctl','stop','unjuno-57-r05-semantic-5884.service']);o,e=unit.communicate(timeout=10);(w/'native-partial.stdout').write_bytes(o);(w/'native-partial.stderr').write_bytes(e)
 call('vm-stop',[orb,'stop',vm]);call('vm-info',[orb,'info',vm]);(w/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
print('completed one allocation')

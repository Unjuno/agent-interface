"""Bounded own-request exchange; does not execute GUI or invoke a model."""
import argparse
import base64
import hashlib
import json
import pathlib
import sys
import time


def acquire(root, index):
    path = root / ('request-%03d.json' % index)
    if not path.exists():
        return None
    raw = path.read_bytes()
    if len(raw) > 16384:
        raise ValueError('request exceeds cap')
    request = json.loads(raw)
    if type(request['index']) is not int or request['index'] != index:
        raise ValueError('request index mismatch')
    pid = request['pid']
    if type(pid) is not int or pid <= 0:
        raise ValueError('invalid process ID')
    stat = pathlib.Path('/proc') / str(pid) / 'stat'
    # Parse after the final closing parenthesis: comm may contain spaces.
    fields = stat.read_text().rsplit(')', 1)[1].split()
    if fields[0] == 'Z' or fields[19] != request['pid_start']:
        raise ValueError('process retired or generation mismatch')
    remaining = request['deadline_monotonic'] - time.monotonic()
    if remaining <= 0:
        raise TimeoutError('guest request deadline expired')
    image_name = 'input-%03d.png' % index
    if request['image_name'] != image_name:
        raise ValueError('unexpected image path')
    image = (root / image_name).read_bytes()
    if len(image) > 1048576:
        raise ValueError('image exceeds cap')
    if hashlib.sha256(image).hexdigest() != request['image_sha256']:
        raise ValueError('image SHA mismatch')
    return request, image, remaining


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('operation', choices=['get', 'put'])
    parser.add_argument('root')
    parser.add_argument('index', type=int)
    args = parser.parse_args()
    if not 1 <= args.index <= 6:
        raise ValueError('arm grounding call cap exceeded')
    root = pathlib.Path(args.root)
    live = acquire(root, args.index)
    if live is None:
        if args.operation == 'put':
            raise ValueError('no registered request')
        print(json.dumps({'state': 'pending'}))
        return
    request, image, remaining = live
    if args.operation == 'get':
        print(json.dumps({'state': 'live', 'request': request,
                          'image_base64': base64.b64encode(image).decode(),
                          'remaining_seconds': remaining}))
        return
    raw = sys.stdin.buffer.read(65537)
    if len(raw) > 65536:
        raise ValueError('answer exceeds cap')
    answer = json.loads(raw)
    for key in ['index', 'contract', 'image_sha256']:
        if answer[key] != request[key]:
            raise ValueError('answer ownership mismatch: ' + key)
    # Recheck after receiving the answer, immediately before publication.
    acquire(root, args.index)
    destination = root / ('answer-%03d.json' % args.index)
    if destination.exists():
        raise FileExistsError('answer already published; no resend')
    temporary = destination.with_suffix('.pending')
    with temporary.open('xb') as stream:
        stream.write(raw)
    temporary.replace(destination)
    print(json.dumps({'state': 'published', 'index': args.index,
                      'answer_sha256': hashlib.sha256(raw).hexdigest()}))

if __name__ == '__main__':
    main()

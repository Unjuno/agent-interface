import ast,json,sys,subprocess,tempfile,time
from pathlib import Path
source=Path('candidate-client.py').read_text()
cls=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='RuntimeClient')
real=subprocess.Popen
case=sys.argv[1]
code={'silent':'import time;time.sleep(5)','partial-line':'import sys,time;sys.stdout.write(\'{"socket":\');sys.stdout.flush();time.sleep(5)','EOF':'pass','valid':'import sys;print(\'{"socket":"/fake-owned-socket"}\',flush=True)','ignore-term':'import signal,sys,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);sys.stdout.write(\'{"socket":\');sys.stdout.flush();time.sleep(5)'}[case]
class Shim:
 PIPE=subprocess.PIPE
 TimeoutExpired=subprocess.TimeoutExpired
 @staticmethod
 def Popen(*args,**kw):
  child=real([sys.executable,'-u','-c',code],**kw)
  Path(case+'-child.json').write_text(json.dumps({'pid':child.pid,'case':case}))
  return child
import os,selectors,math
ns={'os':os,'selectors':selectors,'math':math,'time':time,'request_once':lambda *args:{'reply':{'records':[{'event':'ready'}]},'continuation':{}},'start':lambda *args:{},'initialize':lambda path,value:path.write_text('{}'),'first':lambda records,event:next(r for r in records if r['event']==event),'Path':Path,'json':json,'subprocess':Shim,'sys':sys,'tempfile':tempfile,'HERE':Path('.')}
exec(compile(ast.fix_missing_locations(ast.Module(body=[n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='read_endpoint']+[cls],type_ignores=[])),'fixed-class','exec'),ns)
c=ns['RuntimeClient'](Path('candidate-'+case+'-corrected-root'),1)
try:
 c.start(endpoint_timeout=.04)
 print(json.dumps({'status':'started','endpoint':c.endpoint,'ready':c.ready}),flush=True)
except Exception as e:print(json.dumps({'error_type':type(e).__name__,'error':str(e),'child_exit':c.process.poll(),'stdout_closed':c.process.stdout.closed,'stderr_closed':c.errors.closed,'temporary_exists':Path(c.temporary.name).exists()}),flush=True)
finally:
 if c.process.poll() is None:c.process.terminate()
 c.process.wait(timeout=2)

import ast,json,os,selectors,math,time,threading,unittest
from pathlib import Path
source=Path('candidate-client.py').read_text() if Path('candidate-client.py').exists() else Path('baseline-client.py').read_text()
node=next((n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='read_endpoint'),None)
if node is None:
 def read_endpoint(stream,timeout=30,max_bytes=65536):return json.loads(stream.readline())
else:
 ns={'json':json,'os':os,'selectors':selectors,'math':math,'time':time}
 exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),'actual_reader','exec'),ns)
 read_endpoint=ns['read_endpoint']
class EndpointTests(unittest.TestCase):
 def invoke(self,data,*,keep_open=False,max_bytes=65536):
  rd,wr=os.pipe();stream=os.fdopen(rd,'rb');result=[]
  def reader():
   try:result.append(('ok',read_endpoint(stream,timeout=.04,max_bytes=max_bytes)))
   except Exception as e:result.append(('error',type(e).__name__))
  t=threading.Thread(target=reader);t.start()
  try:
   if data:os.write(wr,data)
   if not keep_open:os.close(wr);wr=None
   t.join(.3);finished=not t.is_alive()
  finally:
   if wr is not None:os.close(wr)
   t.join(1);stream.close()
  self.assertFalse(t.is_alive(),'reader remains after pipe closure')
  return finished,result
 def test_silent_endpoint_has_internal_deadline(self):
  finished,result=self.invoke(b'',keep_open=True);self.assertTrue(finished,'silent reader exceeded deadline');self.assertEqual(result,[('error','TimeoutError')])
 def test_partial_line_has_internal_deadline(self):
  finished,result=self.invoke(b'{"socket":',keep_open=True);self.assertTrue(finished,'partial reader exceeded deadline');self.assertEqual(result,[('error','TimeoutError')])
 def test_empty_eof_is_classified(self):self.assertEqual(self.invoke(b'')[1],[('error','EOFError')])
 def test_fragmented_endpoint(self):
  rd,wr=os.pipe();stream=os.fdopen(rd,'rb')
  def write():
   try:
    for fragment in [b'{"socket":',b'"/owned/',b'socket"}\n']:
     os.write(wr,fragment);time.sleep(.005)
   finally:os.close(wr)
  t=threading.Thread(target=write);t.start()
  try:self.assertEqual(read_endpoint(stream,timeout=.2),{'socket':'/owned/socket'})
  finally:t.join(1);stream.close()
  self.assertFalse(t.is_alive())
 def test_valid_endpoint(self):self.assertEqual(self.invoke(b'{"socket":"/owned/socket"}\n')[1],[('ok',{'socket':'/owned/socket'})])
 def test_oversize(self):self.assertEqual(self.invoke(b'x'*100+b'\n',max_bytes=32)[1],[('error','ValueError')])
 def test_missing_socket(self):self.assertEqual(self.invoke(b'{}\n')[1],[('error','ValueError')])
 def test_malformed_json(self):self.assertEqual(self.invoke(b'{oops}\n')[1],[('error','JSONDecodeError')])
if __name__=='__main__':unittest.main(verbosity=2)

import ast,json,sys,subprocess,tempfile,time
from pathlib import Path
source=Path('baseline-client.py').read_text()
cls=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='RuntimeClient')
real=subprocess.Popen
case=sys.argv[1]
code={'silent':'import time;time.sleep(5)','partial-line':'import sys,time;sys.stdout.write(\'{"socket":\');sys.stdout.flush();time.sleep(5)','EOF':'pass'}[case]
class Shim:
 PIPE=subprocess.PIPE
 @staticmethod
 def Popen(*args,**kw):
  child=real([sys.executable,'-u','-c',code],**kw)
  Path(case+'-child.json').write_text(json.dumps({'pid':child.pid,'case':case}))
  return child
ns={'Path':Path,'json':json,'subprocess':Shim,'sys':sys,'tempfile':tempfile,'HERE':Path('.')}
exec(compile(ast.fix_missing_locations(ast.Module(body=[cls],type_ignores=[])),'fixed-class','exec'),ns)
c=ns['RuntimeClient'](Path(case+'-root'),1)
try:c.start()
except Exception as e:print(json.dumps({'error_type':type(e).__name__,'error':str(e)}),flush=True)

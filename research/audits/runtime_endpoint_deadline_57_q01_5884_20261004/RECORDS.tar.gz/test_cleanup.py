import importlib.util,unittest,tempfile
from pathlib import Path
from unittest.mock import patch
spec=importlib.util.spec_from_file_location('startup_candidate','candidate-client.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class BadClose:
 def close(self):raise OSError('stdout close lost')
class ExitedProcess:
 stdout=BadClose()
 def poll(self):return 0
class CleanupTests(unittest.TestCase):
 def test_cleanup_close_cannot_replace_primary_or_skip_remaining_resources(self):
  with tempfile.TemporaryDirectory() as root:
   client=m.RuntimeClient(Path(root)/'case',1)
   try:
    with patch.object(m.subprocess,'Popen',return_value=ExitedProcess()),patch.object(m,'read_endpoint',side_effect=TimeoutError('primary endpoint timeout')):
     with self.assertRaisesRegex(TimeoutError,'primary endpoint timeout') as caught:client.start(endpoint_timeout=.01)
    self.assertTrue(client.errors.closed)
    self.assertFalse(Path(client.temporary.name).exists())
    self.assertTrue(any('stdout close lost' in note for note in caught.exception.__notes__))
   finally:
    if client.errors is not None:client.errors.close()
    if client.temporary is not None:client.temporary.cleanup()
if __name__=='__main__':unittest.main(verbosity=2)

import pathlib,shutil,json,hashlib,tarfile,subprocess,datetime
w=pathlib.Path('work/runtime-postendpoint-q04');b=w/'linux-bundle';b.mkdir(exist_ok=False)
shutil.copytree('work/runtime-startup-live-57-5884-q03/bundle/source',b/'source')
shutil.copy(w/'candidate.py',b/'source/research/live_control/integrated_efficiency_client_v1.py')
shutil.copy(w/'test_existing.py',b/'source/research/live_control/test_existing.py')
s=(w/'test_postendpoint.py').read_text();start=s.index('sys.path.insert');end=s.index('class StartupFailures')
s=s[:start]+"sys.path.insert(0,str(pathlib.Path('source/research/live_control').resolve()))\nimport integrated_efficiency_client_v1 as m\n"+s[end:];(b/'test_postendpoint.py').write_text(s)
(b/'run.py').write_text('''import pathlib,subprocess,os,sys,json
cg=next(x.split(':',2)[2] for x in pathlib.Path('/proc/self/cgroup').read_text().splitlines() if x.startswith('0::'));r=pathlib.Path('/sys/fs/cgroup'+cg)
pathlib.Path('resources.json').write_text(json.dumps({'python':sys.version,'effective':{k:(r/k).read_text() for k in ['cpu.max','memory.max','pids.max']}}))
env=dict(os.environ,PYTHONPATH=str(pathlib.Path('source/research/live_control').resolve()))
for name,opt in [('normal',[]),('optimized',['-O'])]:
 p=subprocess.run([sys.executable,*opt,'-m','unittest','discover','-s','source/research/live_control','-p','test_existing.py'],env=env,capture_output=True,timeout=15)
 pathlib.Path(name+'-existing.stderr').write_bytes(p.stderr);assert p.returncode==0
 p=subprocess.run([sys.executable,*opt,'test_postendpoint.py'],env=env,capture_output=True,timeout=15)
 pathlib.Path(name+'-new.stderr').write_bytes(p.stderr);assert p.returncode==0
''')
m={str(p.relative_to(b)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in b.rglob('*') if p.is_file()};(b/'manifest.json').write_text(json.dumps(m,indent=2))
with tarfile.open(w/'linux-transfer.tar','w') as t:
 for p in b.rglob('*'):
  if p.is_file():t.add(p,arcname=str(p.relative_to(b)))
vm='unjuno-57-5884-debian-a02-20261003';orb='/opt/homebrew/bin/orbctl';root='/home/study/57-runtime-postendpoint-q04';receipts=[]
def call(name,args,data=None):
 t=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.Popen(args,stdin=subprocess.PIPE if data else None,stdout=subprocess.PIPE,stderr=subprocess.PIPE);out,err=p.communicate(data,timeout=50);(w/(name+'.stdout')).write_bytes(out);(w/(name+'.stderr')).write_bytes(err);receipts.append({'stage':name,'pid':p.pid,'argv':args,'started':t,'exit':p.returncode,'ended':datetime.datetime.now(datetime.timezone.utc).isoformat()});assert p.returncode==0
try:
 call('linux-start',[orb,'start',vm])
 call('linux-transfer',[orb,'run','-m',vm,'-u','root','/bin/bash','-c',f'set -e; mkdir {root}; tar -xf - -C {root}; chown -R study:study {root}'],(w/'linux-transfer.tar').read_bytes())
 call('linux-verify',[orb,'run','-m',vm,'-u','root','python3','-c',f"import pathlib,json,hashlib;r=pathlib.Path('{root}');m=json.loads((r/'manifest.json').read_text());bad=[k for k,v in m.items() if hashlib.sha256((r/k).read_bytes()).hexdigest()!=v['sha256']];print({{'files':len(m),'bad':bad}});assert not bad"])
 call('linux-tests',[orb,'run','-m',vm,'-u','root','systemd-run','--unit=unjuno-57-q04-startup-5884','--wait','--pipe','--property=User=study',f'--property=WorkingDirectory={root}','--property=CPUQuota=25%','--property=MemoryMax=134217728','--property=TasksMax=32','--property=RuntimeMaxSec=40','--property=KillMode=control-group','/usr/bin/python3','run.py'])
 call('linux-collect',[orb,'run','-m',vm,'-u','root','tar','-czf','-','-C',root,'resources.json','normal-existing.stderr','normal-new.stderr','optimized-existing.stderr','optimized-new.stderr'])
finally:
 call('linux-stop',[orb,'stop',vm]);call('linux-readback',[orb,'info',vm]);(w/'linux-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
print(receipts)

import unittest, pathlib, tempfile, subprocess, sys, importlib.util, os
from unittest.mock import patch
sys.path.insert(0,str(pathlib.Path('work/runtime-startup-live-57-5884-q03/bundle/source/research/live_control').resolve()))
spec=importlib.util.spec_from_file_location('tested_client',os.environ['Q04_CLIENT']);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class StartupFailures(unittest.TestCase):
 def exercise(self,stage):
  original=subprocess.Popen
  def launch(args,**kw):return original([sys.executable,'-u','-c','import time; print(\'{"socket":"/unused/q04.sock"}\',flush=True); time.sleep(20)'],**kw)
  reply={'reply':{'records':[{'event':'ready'}]},'continuation':{}}
  with tempfile.TemporaryDirectory(prefix='q04-regression-') as root:
   c=m.RuntimeClient(pathlib.Path(root)/'client',1)
   target={'request':'request_once','ready':'first','journal':'initialize'}[stage]
   try:
    with patch.object(m.subprocess,'Popen',side_effect=launch),patch.object(m,'request_once',return_value=reply),patch.object(m,target,side_effect=RuntimeError('primary-'+stage)):
     with self.assertRaisesRegex(RuntimeError,'primary-'+stage):c.start(endpoint_timeout=1)
    self.assertIsNotNone(c.process.poll(),'owned child survives failed startup')
    self.assertTrue(c.process.stdout.closed)
    self.assertTrue(c.errors.closed)
    self.assertFalse(pathlib.Path(c.temporary.name).exists())
   finally:c.close()
 def test_request_failure(self):self.exercise('request')
 def test_ready_failure(self):self.exercise('ready')
 def test_journal_failure(self):self.exercise('journal')
if __name__=='__main__':unittest.main(verbosity=2)

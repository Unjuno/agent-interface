import sys,pathlib,importlib.util,runpy
sys.path.insert(0,str(pathlib.Path("work/runtime-startup-live-57-5884-q03/bundle/source/research/live_control").resolve()))
spec=importlib.util.spec_from_file_location("integrated_efficiency_client_v1","work/runtime-postendpoint-q04/candidate.py")
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
runpy.run_path("work/runtime-postendpoint-q04/test_existing.py",run_name="__main__")

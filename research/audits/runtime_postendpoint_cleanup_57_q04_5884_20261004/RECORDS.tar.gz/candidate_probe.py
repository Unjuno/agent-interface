import pathlib,sys,subprocess,json,time,hashlib,tempfile
source=pathlib.Path('work/runtime-startup-live-57-5884-q03/bundle/source/research/live_control').resolve()
sys.path.insert(0,str(source))
import importlib.util
spec=importlib.util.spec_from_file_location("q04candidate", "work/runtime-postendpoint-q04/candidate.py")
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
original=m.subprocess.Popen
children=[]
def launch(args,**kw):
 p=original([sys.executable,'-u','-c','import json,time; print(json.dumps({"socket":"/unused/q04.sock"}),flush=True); time.sleep(20)'],**kw);children.append(p);return p
m.subprocess.Popen=launch
def fail(*args,**kwargs):raise ConnectionError('Q04 deliberate initial-observation transport failure')
m.request_once=fail
out=pathlib.Path('work/runtime-postendpoint-q04')
row={'kind':'ordinary failure-path construction; no native GUI/model/input','source_sha256':hashlib.sha256((source/'integrated_efficiency_client_v1.py').read_bytes()).hexdigest()}
with tempfile.TemporaryDirectory(prefix='q04-owned-') as d:
 c=m.RuntimeClient(pathlib.Path(d)/'client',57041011)
 try:
  t=time.monotonic_ns()
  try:c.start(endpoint_timeout=1)
  except ConnectionError as e:row.update(primary_error=str(e),elapsed_ns=time.monotonic_ns()-t)
  row.update(child_pid=c.process.pid,child_alive_after_start_error=c.process.poll() is None,stdout_closed=c.process.stdout.closed,stderr_closed=c.errors.closed,temporary_present=pathlib.Path(c.temporary.name).exists())
 finally:
  c.close()
  row.update(child_returncode_after_explicit_close=c.process.returncode,stderr_closed_after_close=c.errors.closed,temporary_absent_after_close=not pathlib.Path(c.temporary.name).exists())
assert not row['child_alive_after_start_error'] and row['stdout_closed'] and row['stderr_closed'] and not row['temporary_present']
assert row['child_returncode_after_explicit_close'] is not None
(out/'candidate-outcome.json').write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps(row,indent=2))

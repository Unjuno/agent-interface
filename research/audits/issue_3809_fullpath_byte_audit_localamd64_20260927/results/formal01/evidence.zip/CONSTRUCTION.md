# Construction and preformal checks — Issue #4649

All preparation used local Docker image `sha256:2f17fc044b579bab302c2e8054d3a686e2cb9a83de48e70534b94cd8ebbe06a9`, with `--pull=never --network none`, one CPU, 1 GiB memory, 64 PIDs, read-only root/source/input, and a dedicated writable output mount.

- The exact digest was present locally as linux/amd64, CPython 3.12.14. A `--platform linux/arm64 --pull=never` probe failed before process start because no arm64 image was cached. No pull/substitute was made; that allocation was not started.
- Three Python source files passed AST parsing in the pinned container.
- A read-only identity probe decoded the exact manifest bytes and confirmed all ten input SHA-256 values.
- Preflight 01 STOPped before baseline/mutation parsing because the base64 materialization of the 23-byte binary input is named `delivered-prefix.bin.b64`, while the runner initially looked up the original `.bin` name. Preserve output at `outputs/issue3809-fullpath-audit-localamd64-20260927/preflight01/PREFLIGHT.json`.
- The path mapping was corrected, then source/freeze hashes were refreshed and committed before formal. Preflight 02 returned `PASS_PREFLIGHT`, 10 inputs, zero errors; it is preserved at `outputs/issue3809-fullpath-audit-localamd64-20260927/preflight02/PREFLIGHT.json`.
- Neither construction STOP nor PASS read semantic baseline outcomes, ran mutations, or invoked a formal worker. Exactly one formal runner invocation followed source read-back and the successful preflight.

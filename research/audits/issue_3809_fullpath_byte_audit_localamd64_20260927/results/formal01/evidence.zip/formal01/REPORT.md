# Issue #4649 — formal allocation 01: FAIL_AUDITOR_ROBUSTNESS

## Disposition

The one formal Docker invocation produced `PASS_FULLPATH_BYTE_AUDIT_LOCAL_AMD64_SCOPED` with no runner errors. The separate independent audit also reconstructed the baseline with `PASS_INDEPENDENT`, seven audit categories checked, and no errors.

The full preregistered allocation gate nevertheless **fails**: only 6 of 8 copied-result corruption controls were rejected. The auditor returned PASS for two mutations to its own recorded input ledger (`drop_input_row` and `input_digest`). Because the decision rule required every corruption control to reject, the overall disposition is `FAIL_AUDITOR_ROBUSTNESS`; do not report this as an unqualified PASS. The formal runner was not repeated.

## What the data established

- All ten immutable main inputs matched the frozen manifest SHA-256 values.
- The audit freeze binds PLAN and auditor by their full repository-relative paths. Those keys match the expected hashes; the basename keys are absent.
- Historical formal freeze and raw evidence remain internally bound to linux/arm64. The current audit ran on the locally cached linux/amd64 image and makes no ARM64 equivalence claim.
- Untouched accepted content reconstructed as valid 246-byte JSON with the expected producer hash; the 23-byte delivered prefix matched its recorded count/hash and remained invalid JSON, with zero baseline errors.
- The same-length accepted-path mutation remained valid JSON and was rejected by producer SHA-256.
- The 23→22-byte prefix mutation was rejected by both recorded delivered length and SHA-256 and remained invalid JSON.

## Auditor robustness failure

The eight controls were: drop input row, alter an input digest, mutate the reported role path, alter a baseline digest, flip the accepted-mutation receipt, flip the prefix-length receipt, flip the prefix-hash receipt, and alter the disposition.

The first two returned auditor exit 0 / `PASS_INDEPENDENT` / `errors=[]`, with empty stderr. Inspection of the frozen v1 independent auditor shows the defect: it recomputes the input table and compares that table with the freeze, but does not compare the result JSON's own `input_sha256` ledger to the recomputed table. The other six controls each returned structured FAIL with nonempty errors and empty stderr. This is an auditor validation gap, not evidence that the runner's retained inputs changed.

## Execution and preservation

- Intake main: `522ff97664c12399e94e28462688afc905732373`.
- Source commit: `ea66b59cfa45674d24e74de5ea0383f1ee1d3eb2`.
- Freeze SHA-256: `4665fbf32c86d66dcea3c6efdd6b073c39486321fae48ec8f07104de325b2a9f`.
- Local Docker image ID: `sha256:2f17fc044b579bab302c2e8054d3a686e2cb9a83de48e70534b94cd8ebbe06a9`; Linux/amd64, CPython 3.12.14. Docker was `--pull=never --network none --cpus=1 --memory=1g --pids-limit=64 --read-only`, with only tmpfs and dedicated output writable.
- Exactly one formal runner invocation; exit 0. Independent auditor exit 0. Corruption-control suite exit 1.
- A preformal input-path STOP and the corrected PASS preflight are retained separately. Neither ran semantic/formal checks or consumed the formal invocation.
- No Actions/workflow, remote runner, package install, predecessor runner, model, GUI, or OS input was used.

The formal allocation is consumed. Keep the runner result, v1 audit, and 6/8 corruption-control failure unchanged. Any auditor repair or re-audit must be separately identified and must not overwrite this disposition.

## Retained output hashes

| Artifact | SHA-256 |
|---|---|
| `FORMAL.json` | `aa7de87e5cf0644eb5bbe645d34d9273a8fbefccf041faea12b4e6933886f6b7` |
| `AUDIT.json` | `a76f9007791d09c49f38b8d10a3e3011883ffee71015d25c1ae13edd30ad09e5` |
| `CORRUPTIONS.json` | `c1c572593d5e6e784ab168bdf4656742ac62e0bbafc22cbcb2b6c8739132a59c` |
| `CONTROLS.stdout.txt` | `9efcfadaf41a68aab329b1984cb9a80f65cc21c8bbc7868abf055ddd693c721b` |
| `AUDIT.exit` | `9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa` |
| `CONTROLS.exit` | `4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865` |
| `AUDIT.stderr.txt`, `CONTROLS.stderr.txt` (both empty) | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| construction preflight 01 STOP | `77a699e772e59b3bf0c500041cfd181fb81cfb5c562bc114b310a44e89731d85` |
| construction preflight 02 PASS | `eae0b010c49274e44bcc5dc64e3f38babcdc3fe6b791d613d3bd3ba93db0ed1c` |
| `CONSTRUCTION.md` | `acaf657527306f1d4f96701678000e65e387a4e43108fb61014b866070a60857` |

The compressed archive has a separate `evidence.zip.sha256` sidecar so its digest is not self-referential; both files are retained alongside this report.

import pathlib,shutil,json,hashlib,tarfile,subprocess,datetime
w=pathlib.Path('work/keyboard-boundary-r03');b=w/'linux-bundle-v2';b.mkdir(exist_ok=False)
shutil.copytree('work/runtime-startup-live-57-5884-q03/bundle/source',b/'source')
shutil.copy('work/runtime-postendpoint-q04/candidate.py',b/'source/research/live_control/integrated_efficiency_client_v1.py')
shutil.copy(w/'driver.py',b/'run.py')
fixture=b/'source/research/live_control/integrated_efficiency_fixture_v1.py';text=fixture.read_text();assert text.count('name=value autofocus autocomplete=off')==1;fixture.write_text(text.replace('name=value autofocus autocomplete=off','name=value autocomplete=off').replace("f\"<form method=post action='{action}'><label>Value \"","f\"<label>Scratch <input name=scratch autocomplete=off></label><form method=post action='{action}'><label>Value \""))
m={str(p.relative_to(b)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in b.rglob('*') if p.is_file()};(b/'manifest.json').write_text(json.dumps(m,indent=2))
with tarfile.open(w/'linux-transfer.tar','w') as t:
 for p in b.rglob('*'):
  if p.is_file():t.add(p,arcname=str(p.relative_to(b)))
vm='unjuno-57-5884-debian-a02-20261003';orb='/opt/homebrew/bin/orbctl';root='/home/study/57-keyboard-boundary-r03';receipts=[]
def call(name,args,data=None):
 t=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.Popen(args,stdin=subprocess.PIPE if data else None,stdout=subprocess.PIPE,stderr=subprocess.PIPE);out,err=p.communicate(data,timeout=80);(w/(name+'.stdout')).write_bytes(out);(w/(name+'.stderr')).write_bytes(err);receipts.append({'stage':name,'pid':p.pid,'argv':args,'started':t,'exit':p.returncode,'ended':datetime.datetime.now(datetime.timezone.utc).isoformat()});assert p.returncode==0
freeze={'run_id':'57-keyboard-boundary-R03-20261004-5884','seed':57041016,'H':'Fixed one-Tab R02 method fails to select the task field when an outside-form Scratch input precedes Value','T':'One native task1 navigation plus unchanged R02 Tab/CtrlA/text/Return; fixture removes autofocus and adds named Scratch input before original form, oracle unchanged','D':'If program completed but task1 exact count0, method FAIL_LIMIT_COUNTEREXAMPLE; if task1 count1, boundary not demonstrated; unexpected/duplicate effects held separately; no retry','C':'Known tab-order changed, outside-form input has no submission action; input selection is semantic, not task success','U':'One known browser fixture, no model repair/general GUI/globalphysical claim; original remaining5tasks intentionally not attempted','pins':m,'caps':{'cpu_percent':100,'memory_bytes':805306368,'tasks':256,'unit_seconds':70,'driver_seconds':60,'host_stage_seconds':80,'collection_posthoc_bytes':10485760}}
(w/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
try:
 call('linux-start',[orb,'start',vm])
 call('linux-transfer',[orb,'run','-m',vm,'-u','root','/bin/bash','-c',f'set -e; mkdir {root}; tar -xf - -C {root}; chown -R study:study {root}'],(w/'linux-transfer.tar').read_bytes())
 call('linux-verify',[orb,'run','-m',vm,'-u','root','python3','-c',f"import pathlib,json,hashlib;r=pathlib.Path('{root}');m=json.loads((r/'manifest.json').read_text());bad=[k for k,v in m.items() if hashlib.sha256((r/k).read_bytes()).hexdigest()!=v['sha256']];print({{'files':len(m),'bad':bad}});assert not bad"])
 call('linux-tests',[orb,'run','-m',vm,'-u','root','systemd-run','--unit=unjuno-57-r03-boundary-5884','--wait','--pipe','--property=User=study',f'--property=WorkingDirectory={root}','--property=CPUQuota=100%','--property=MemoryMax=805306368','--property=TasksMax=256','--property=RuntimeMaxSec=70','--property=KillMode=control-group','/usr/bin/python3','run.py'])
 call('linux-collect',[orb,'run','-m',vm,'-u','root','tar','-czf','-','-C',root,'actual'])
finally:
 call('linux-stop',[orb,'stop',vm]);call('linux-readback',[orb,'info',vm]);(w/'linux-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
print(receipts)

import pathlib,shutil,json,hashlib,tarfile,subprocess,datetime
w=pathlib.Path('work/keyboard-reference-r02');b=w/'linux-bundle-v2';b.mkdir(exist_ok=False)
shutil.copytree('work/runtime-startup-live-57-5884-q03/bundle/source',b/'source')
shutil.copy('work/runtime-postendpoint-q04/candidate.py',b/'source/research/live_control/integrated_efficiency_client_v1.py')
shutil.copy(w/'driver.py',b/'run.py')
fixture=b/'source/research/live_control/integrated_efficiency_fixture_v1.py';text=fixture.read_text();assert text.count('name=value autofocus autocomplete=off')==1;fixture.write_text(text.replace('name=value autofocus autocomplete=off','name=value autocomplete=off'))
m={str(p.relative_to(b)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in b.rglob('*') if p.is_file()};(b/'manifest.json').write_text(json.dumps(m,indent=2))
with tarfile.open(w/'linux-transfer.tar','w') as t:
 for p in b.rglob('*'):
  if p.is_file():t.add(p,arcname=str(p.relative_to(b)))
vm='unjuno-57-5884-debian-a02-20261003';orb='/opt/homebrew/bin/orbctl';root='/home/study/57-keyboard-reference-r02';receipts=[]
def call(name,args,data=None):
 t=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.Popen(args,stdin=subprocess.PIPE if data else None,stdout=subprocess.PIPE,stderr=subprocess.PIPE);out,err=p.communicate(data,timeout=80);(w/(name+'.stdout')).write_bytes(out);(w/(name+'.stderr')).write_bytes(err);receipts.append({'stage':name,'pid':p.pid,'argv':args,'started':t,'exit':p.returncode,'ended':datetime.datetime.now(datetime.timezone.utc).isoformat()});assert p.returncode==0
freeze={'run_id':'57-keyboard-reference-R02-20261004-5884','seed':57041015,'H':'Known six-task HTML form with autofocus removed can be solved by navigation and Tab/CtrlA/text/Return without model grounding or handles','T':'One fixed six-task A/A/A/B/B/B native sequence; private fixture removes autofocus before freeze; controller uses one Tab then CtrlA/text/Return, no DOM inspection/model','D':'All six original POST effects exactly once; original oracle success, natural exit0, raw preserved; failure/HOLD retained no retry','C':'Fixture single-input/tab-order/Enter affordance is domain-specific; fixed order/cache/shared load not causal comparison with P01','U':'No general GUI/semantic adversarial/second domain claim; model0 keyboard reference can invalidate fixture-level necessity of model grounding','pins':m,'caps':{'cpu_percent':100,'memory_bytes':805306368,'tasks':256,'unit_seconds':70,'driver_seconds':60,'host_stage_seconds':80,'collection_posthoc_bytes':10485760}}
(w/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
try:
 call('linux-start',[orb,'start',vm])
 call('linux-transfer',[orb,'run','-m',vm,'-u','root','/bin/bash','-c',f'set -e; mkdir {root}; tar -xf - -C {root}; chown -R study:study {root}'],(w/'linux-transfer.tar').read_bytes())
 call('linux-verify',[orb,'run','-m',vm,'-u','root','python3','-c',f"import pathlib,json,hashlib;r=pathlib.Path('{root}');m=json.loads((r/'manifest.json').read_text());bad=[k for k,v in m.items() if hashlib.sha256((r/k).read_bytes()).hexdigest()!=v['sha256']];print({{'files':len(m),'bad':bad}});assert not bad"])
 call('linux-tests',[orb,'run','-m',vm,'-u','root','systemd-run','--unit=unjuno-57-r02-keyboard-5884','--wait','--pipe','--property=User=study',f'--property=WorkingDirectory={root}','--property=CPUQuota=100%','--property=MemoryMax=805306368','--property=TasksMax=256','--property=RuntimeMaxSec=70','--property=KillMode=control-group','/usr/bin/python3','run.py'])
 call('linux-collect',[orb,'run','-m',vm,'-u','root','tar','-czf','-','-C',root,'actual'])
finally:
 call('linux-stop',[orb,'stop',vm]);call('linux-readback',[orb,'info',vm]);(w/'linux-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
print(receipts)

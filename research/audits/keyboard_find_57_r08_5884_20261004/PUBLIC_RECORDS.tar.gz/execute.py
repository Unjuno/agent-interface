import pathlib,shutil,json,hashlib,tarfile,subprocess,datetime
w=pathlib.Path('work/keyboard-find-r08');b=w/'linux-bundle';b.mkdir(exist_ok=False)
shutil.copytree('work/runtime-startup-live-57-5884-q03/bundle/source',b/'source')
shutil.copy('work/runtime-pending-q07/candidate.py',b/'source/research/live_control/integrated_efficiency_client_v1.py')
shutil.copy(w/'driver.py',b/'run.py')
shutil.copy(w/'retain_client.py',b/'retain_client.py')
fixture=b/'source/research/live_control/integrated_efficiency_fixture_v1.py';text=fixture.read_text();assert text.count('name=value autofocus autocomplete=off')==1;fixture.write_text(text.replace('name=value autofocus autocomplete=off','name=value autocomplete=off').replace("f\"<form method=post action='{action}'><label>Value \"","f\"<label>Scratch <input name=scratch autocomplete=off></label><form method=post action='{action}'><label>Value \""))
runtime=b/'source/research/live_control/integrated_efficiency_runtime_v1.py'
src=runtime.read_text();assert src.count('root = Path(session.tmp) / "integrated-fixture"')==1;runtime.write_text(src.replace('root = Path(session.tmp) / "integrated-fixture"','root = Path("actual/fixture-evidence")'))
m={str(p.relative_to(b)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in b.rglob('*') if p.is_file()};(b/'manifest.json').write_text(json.dumps(m,indent=2))
with tarfile.open(w/'linux-transfer.tar','w') as t:
 for p in b.rglob('*'):
  if p.is_file():t.add(p,arcname=str(p.relative_to(b)))
vm='unjuno-57-5884-debian-a02-20261003';orb='/opt/homebrew/bin/orbctl';root='/home/study/57-keyboard-find-r08';receipts=[]
def call(name,args,data=None,allow_failure=False):
 t=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.Popen(args,stdin=subprocess.PIPE if data else None,stdout=subprocess.PIPE,stderr=subprocess.PIPE);out,err=p.communicate(data,timeout=80);(w/(name+'.stdout')).write_bytes(out);(w/(name+'.stderr')).write_bytes(err);receipts.append({'stage':name,'pid':p.pid,'argv':args,'started':t,'exit':p.returncode,'ended':datetime.datetime.now(datetime.timezone.utc).isoformat()});
 if p.returncode and not allow_failure:raise RuntimeError(name+" failed")
 return p.returncode
freeze={'run_id':'57-keyboard-find-R08-20261004-5884','seed':57041020,'H':'Browser Find Value then Escape/Tab selects intended field despite preceding Scratch without model grounding','T':'All six A/A/A/B/B/B tasks once each on same Scratch-before-Value no-autofocus fixture. Same lowercase Find/Escape/Tab controller, Q07 command-free continuation client. Stop on first transport/terminal failure; no input retry','D':'All6 original POSTs correct exactlyonce, oracletrue, all18terminals/recordedrelease verified and naturalexit0 => scopedPASS. Completed allprograms with oraclefalse => methodFAIL. Infrastructure interruption/missing originals => HOLD. No allocation retry','C':'Browser find focus semantics may not transfer to form; known unique textlabel/DOM/tab-order affordance; not genericaccessibility','U':'Known unique label and Find/Tab affordance, one synthetic domain, no causal latency/generalGUI/unknownlabel/globalphysical qualification. Transport wait allowance up to3sec beyond requestedwait','changes_from_R07':['Q07 repaired client bounds command-free continuation reads without input resend','all6 tasks prospectively attempted, rather than task1 only','fixture original history stored in dedicated collected output path, no controller access','original durable transport return captured locally, checkpoint retained before cleanup'], 'pins':m,'caps':{'cpu_percent':100,'memory_bytes':805306368,'tasks':256,'unit_seconds':70,'driver_seconds':60,'host_stage_seconds':80,'collection_posthoc_bytes':10485760}}
(w/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
try:
 call('linux-start',[orb,'start',vm])
 call('linux-transfer',[orb,'run','-m',vm,'-u','root','/bin/bash','-c',f'set -e; mkdir {root}; tar -xf - -C {root}; chown -R study:study {root}'],(w/'linux-transfer.tar').read_bytes())
 call('linux-verify',[orb,'run','-m',vm,'-u','root','python3','-c',f"import pathlib,json,hashlib;r=pathlib.Path('{root}');m=json.loads((r/'manifest.json').read_text());bad=[k for k,v in m.items() if hashlib.sha256((r/k).read_bytes()).hexdigest()!=v['sha256']];print({{'files':len(m),'bad':bad}});assert not bad"])
 call('linux-tests',[orb,'run','-m',vm,'-u','root','systemd-run','--unit=unjuno-57-r08-find-5884','--wait','--pipe','--property=User=study',f'--property=WorkingDirectory={root}','--property=CPUQuota=100%','--property=MemoryMax=805306368','--property=TasksMax=256','--property=RuntimeMaxSec=70','--property=KillMode=control-group','/usr/bin/python3','run.py'],allow_failure=True)
 call('linux-collect',[orb,'run','-m',vm,'-u','root','tar','-czf','-','-C',root,'actual'])
finally:
 call('linux-stop',[orb,'stop',vm]);call('linux-readback',[orb,'info',vm]);(w/'linux-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
print(receipts)

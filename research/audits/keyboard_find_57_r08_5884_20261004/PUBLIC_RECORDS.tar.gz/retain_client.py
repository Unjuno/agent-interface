"""Keep exact temporary checkpoint bytes before ordinary client cleanup."""
import hashlib,json,pathlib

def retain(client,destination):
 destination=pathlib.Path(destination);destination.mkdir(exist_ok=False)
 journal=client.journal
 metadata={'journal_state':'missing','programs_count':len(client.programs)}
 if journal is not None and pathlib.Path(journal).is_file():
  raw=pathlib.Path(journal).read_bytes()
  (destination/'journal.jsonl').write_bytes(raw)
  metadata.update({'journal_state':'retained','journal_bytes':len(raw),'journal_sha256':hashlib.sha256(raw).hexdigest()})
 (destination/'programs.json').write_text(json.dumps(client.programs,indent=2)+'\n')
 (destination/'receipt.json').write_text(json.dumps(metadata,indent=2)+'\n')
 return metadata

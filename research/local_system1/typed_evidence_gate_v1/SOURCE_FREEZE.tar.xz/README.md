# Typed-evidence admission gate

Direct one-variable successor to Issue #906. Container-only synthetic System-1 decision experiment. `science.py` retains the parent architecture/data/training constants and adds one candidate early-admission predicate.

Formal execution is forbidden until source-first GitHub freeze/readback and ownership re-check.

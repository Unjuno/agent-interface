import torch
from science import ACTIONS, CHUNK, DEPTH, EVIDENCE_GATE, PROTOS_T, STR_SIGNAL, TTCNet, typed_evidence_score
# Pure mechanism discriminator, no formal data generator/seed.
x=torch.zeros((1,DEPTH,CHUNK),dtype=torch.float32)
klass=2; depth=1
assert typed_evidence_score(x[0,0],klass)==0.0 < EVIDENCE_GATE
x[0,depth]=STR_SIGNAL*PROTOS_T[klass]
assert typed_evidence_score(x[0,depth],klass) >= 6.999
m=TTCNet(); z=m.forward_all(x)
assert len(z)==DEPTH and all(tuple(v.shape)==(1,8) for v in z)
print('construction mechanism PASS')

#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, os, platform, resource, sys, time
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']:
    os.environ[k]='1'
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

TASK='LOCAL-SYSTEM1-TYPED-EVIDENCE-GATE-20260917-003'
PARENT_GIT_BLOB='00b9653972c2c0594f8db6bb1cf56ad0f3dd9183'
DEPTH=4; CHUNK=16; WIDTH=256
ACTIONS=6; CONTINUE_LOCAL=6; YIELD=7; CLASSES=8
TRAIN_N=8192; EVAL_N=4096; EPOCHS=8; BATCH=256; LR=2e-3
EXEC_CONF=0.90
EVIDENCE_GATE=3.5
ORD_NOISE=0.8; ORD_SIGNAL=8.0; ORD_YIELD=0.15; ORD_DIFF=[0.40,0.30,0.18,0.12]
STR_NOISE=1.0; STR_SIGNAL=7.0; STR_YIELD=0.20; STR_DIFF=[0.25,0.25,0.25,0.25]
PROTO_SEED=905001
FORMAL_SEEDS=[9101701,9101702,9101703,9101704]
WARMUP=256; TIMING_N=4096
MODES=('FULL_DEPTH','DIRECT_TTC','TYPED_EVIDENCE_GATE')

_rng=np.random.default_rng(PROTO_SEED)
PROTOS=_rng.normal(size=(ACTIONS,CHUNK)).astype(np.float32)
PROTOS/=np.linalg.norm(PROTOS,axis=1,keepdims=True)
PROTOS_T=torch.from_numpy(PROTOS.copy())

def sha256_bytes(b: bytes) -> str: return hashlib.sha256(b).hexdigest()
def pct(a,p): return float(np.percentile(a,p,method='linear'))

def make_data(seed,n,stress=False):
    g=np.random.default_rng(seed)
    noise=STR_NOISE if stress else ORD_NOISE
    amp=STR_SIGNAL if stress else ORD_SIGNAL
    yprob=STR_YIELD if stress else ORD_YIELD
    dprob=np.asarray(STR_DIFF if stress else ORD_DIFF,dtype=np.float64)
    x=g.normal(scale=noise,size=(n,DEPTH,CHUNK)).astype(np.float32)
    final=np.empty(n,dtype=np.int64); difficulty=np.empty(n,dtype=np.int64)
    for i in range(n):
        if g.random()<yprob:
            final[i]=YIELD; difficulty[i]=DEPTH
        else:
            d=int(g.choice(np.arange(1,DEPTH+1),p=dprob)); c=int(g.integers(ACTIONS))
            x[i,d-1]+=amp*PROTOS[c]
            final[i]=c; difficulty[i]=d
    targets=np.full((n,DEPTH),CONTINUE_LOCAL,dtype=np.int64)
    for d in range(1,DEPTH+1):
        if d==DEPTH:
            targets[:,d-1]=final
        else:
            ready=(final!=YIELD)&(difficulty<=d)
            targets[ready,d-1]=final[ready]
    return x,final,difficulty,targets

def typed_evidence_score(chunk: torch.Tensor, action: int) -> float:
    return float(torch.dot(chunk, PROTOS_T[action]).item())

class TTCNet(nn.Module):
    def __init__(self):
        super().__init__(); self.blocks=nn.ModuleList(); self.heads=nn.ModuleList()
        for d in range(DEPTH):
            inp=CHUNK+(WIDTH if d else 0)
            self.blocks.append(nn.Sequential(nn.Linear(inp,WIDTH),nn.GELU(),nn.Linear(WIDTH,WIDTH),nn.GELU()))
            self.heads.append(nn.Linear(WIDTH,CLASSES))
    def forward_all(self,x):
        h=None; zs=[]
        for d in range(DEPTH):
            inp=x[:,d] if h is None else torch.cat([h,x[:,d]],dim=1)
            h=self.blocks[d](inp); zs.append(self.heads[d](h))
        return zs
    @torch.inference_mode()
    def predict_full(self,x):
        h=None; z=None
        for d in range(DEPTH):
            inp=x[:,d] if h is None else torch.cat([h,x[:,d]],dim=1)
            h=self.blocks[d](inp); z=self.heads[d](h)
        p=int(z.argmax(dim=1).item())
        return (YIELD if p==CONTINUE_LOCAL else p),DEPTH
    @torch.inference_mode()
    def predict_direct(self,x):
        h=None
        for d in range(DEPTH):
            inp=x[:,d] if h is None else torch.cat([h,x[:,d]],dim=1)
            h=self.blocks[d](inp); z=self.heads[d](h)
            probs=torch.softmax(z,dim=1); p=int(probs.argmax(dim=1).item()); conf=float(probs.max().item())
            if d<DEPTH-1:
                if p<ACTIONS and conf>=EXEC_CONF: return p,d+1
                continue
            return (YIELD if p==CONTINUE_LOCAL else p),DEPTH
        raise AssertionError('unreachable')
    @torch.inference_mode()
    def predict_gated(self,x):
        h=None
        for d in range(DEPTH):
            inp=x[:,d] if h is None else torch.cat([h,x[:,d]],dim=1)
            h=self.blocks[d](inp); z=self.heads[d](h)
            probs=torch.softmax(z,dim=1); p=int(probs.argmax(dim=1).item()); conf=float(probs.max().item())
            if d<DEPTH-1:
                if p<ACTIONS and conf>=EXEC_CONF and typed_evidence_score(x[0,d],p)>=EVIDENCE_GATE:
                    return p,d+1
                continue
            return (YIELD if p==CONTINUE_LOCAL else p),DEPTH
        raise AssertionError('unreachable')

def train(seed):
    x,y,d,t=make_data(seed,TRAIN_N,False)
    torch.manual_seed(seed+100000)
    model=TTCNet()
    opt=torch.optim.AdamW(model.parameters(),lr=LR,weight_decay=1e-4)
    X=torch.from_numpy(x); T=torch.from_numpy(t)
    g=torch.Generator().manual_seed(seed+200000)
    t0=time.perf_counter_ns(); model.train()
    for _ in range(EPOCHS):
        perm=torch.randperm(TRAIN_N,generator=g)
        for s in range(0,TRAIN_N,BATCH):
            ix=perm[s:s+BATCH]; zs=model.forward_all(X[ix])
            loss=sum(F.cross_entropy(z,T[ix,j]) for j,z in enumerate(zs))/DEPTH
            opt.zero_grad(set_to_none=True); loss.backward(); opt.step()
    return model,(time.perf_counter_ns()-t0)/1e6

def fn_for(model,mode):
    return {'FULL_DEPTH':model.predict_full,'DIRECT_TTC':model.predict_direct,'TYPED_EVIDENCE_GATE':model.predict_gated}[mode]

def eval_mode(model,x,y,difficulty,mode):
    fn=fn_for(model,mode); X=torch.from_numpy(x)
    preds=np.empty(len(x),np.int16); depths=np.empty(len(x),np.int8)
    for i in range(len(x)):
        p,d=fn(X[i:i+1]); preds[i]=p; depths[i]=d
    teacher_yield=(y==YIELD); required=np.where(teacher_yield,DEPTH,difficulty)
    premature_exec=(depths<required)&(preds<ACTIONS); premature_yield=(depths<required)&(preds==YIELD)
    return {
        'accuracy':float(np.mean(preds==y)),
        'teacher_yield_n':int(teacher_yield.sum()),
        'teacher_yield_to_exec':int(np.sum(teacher_yield&(preds<ACTIONS))),
        'teacher_yield_to_exec_rate':float(np.sum(teacher_yield&(preds<ACTIONS))/max(1,int(teacher_yield.sum()))),
        'premature_exec':int(premature_exec.sum()),'premature_exec_rate':float(premature_exec.mean()),
        'premature_yield':int(premature_yield.sum()),
        'exit_counts':[int(np.sum(depths==k)) for k in range(1,DEPTH+1)],
        'mean_depth':float(depths.mean()),'mean_normalized_compute':float(depths.mean()/DEPTH),
        '_preds':preds,'_depths':depths,
    }

def time_mode(model,x,mode):
    fn=fn_for(model,mode); X=torch.from_numpy(x)
    for i in range(WARMUP): fn(X[i%len(X):i%len(X)+1])
    vals=np.empty(TIMING_N,dtype=np.float64)
    for i in range(TIMING_N):
        j=i%len(X); t0=time.perf_counter_ns(); fn(X[j:j+1]); vals[i]=(time.perf_counter_ns()-t0)/1e6
    return vals

def timing_order(seed):
    orders=[('FULL_DEPTH','DIRECT_TTC','TYPED_EVIDENCE_GATE'),('DIRECT_TTC','TYPED_EVIDENCE_GATE','FULL_DEPTH'),('TYPED_EVIDENCE_GATE','FULL_DEPTH','DIRECT_TTC')]
    return orders[seed%3]

def summarize_seed(seed,model,train_ms):
    xo,yo,do,_=make_data(seed+10000,EVAL_N,False); xs,ys,ds,_=make_data(seed+20000,EVAL_N,True)
    evals={}; raw={'ordinary_y':yo,'ordinary_difficulty':do,'stress_y':ys,'stress_difficulty':ds}
    for setname,x,y,d in [('ordinary',xo,yo,do),('stress',xs,ys,ds)]:
        for mode in MODES:
            m=eval_mode(model,x,y,d,mode); raw[f'{setname}_{mode}_preds']=m.pop('_preds'); raw[f'{setname}_{mode}_depths']=m.pop('_depths'); evals[(setname,mode)]=m
        fp=raw[f'{setname}_FULL_DEPTH_preds']
        for mode in ('DIRECT_TTC','TYPED_EVIDENCE_GATE'):
            evals[(setname,mode)]['agreement_with_full']=float(np.mean(fp==raw[f'{setname}_{mode}_preds']))
    order=timing_order(seed); timing={}
    for mode in order:
        vals=time_mode(model,xo,mode); raw[f'lat_{mode}']=vals
        timing[mode]={'n':TIMING_N,'p50':pct(vals,50),'p95':pct(vals,95),'p99':pct(vals,99),'max':float(vals.max()),'mean':float(vals.mean()),'decisions_per_s':float(1000.0/vals.mean())}
    params=sum(p.numel() for p in model.parameters()); model_bytes=sum(v.numel()*v.element_size() for v in model.state_dict().values())
    rep=torch.from_numpy(xo[:1]); repeats=[]
    for mode in MODES: repeats += [fn_for(model,mode)(rep),fn_for(model,mode)(rep)]
    return {
      'seed':seed,'train_ms':train_ms,'params':params,'model_bytes':model_bytes,'timing_order':list(order),
      'ordinary':{m:evals[('ordinary',m)] for m in MODES},'stress':{m:evals[('stress',m)] for m in MODES},
      'timing_ms':timing,'repeat_hash':sha256_bytes(json.dumps(repeats,sort_keys=True).encode()),'_raw':raw,
    }

def candidate_decision(rows):
    violations=[]; mean_red=[]; p50_red=[]; faster=0; p95_reg=[]; safety_nonworse=True; safety_strict=False
    for r in rows:
        s=r['seed']; tf=r['timing_ms']['FULL_DEPTH']; tg=r['timing_ms']['TYPED_EVIDENCE_GATE']
        for setname,amin,agree_min in [('ordinary',.98,.99),('stress',.94,.98)]:
            m=r[setname]; full=m['FULL_DEPTH']; cand=m['TYPED_EVIDENCE_GATE']
            if full['accuracy']<amin: violations.append(f'{s}:{setname}:full_accuracy')
            if cand['accuracy']<amin: violations.append(f'{s}:{setname}:candidate_accuracy')
            if cand['agreement_with_full']<agree_min: violations.append(f'{s}:{setname}:agreement')
            if cand['teacher_yield_to_exec_rate']-full['teacher_yield_to_exec_rate']>.0025+1e-12: violations.append(f'{s}:{setname}:yield_exec_delta')
            if cand['premature_yield']!=0: violations.append(f'{s}:{setname}:premature_yield')
        o=r['ordinary']['TYPED_EVIDENCE_GATE']; st=r['stress']['TYPED_EVIDENCE_GATE']; direct_st=r['stress']['DIRECT_TTC']
        if o['premature_exec']!=0: violations.append(f'{s}:ordinary:premature_exec')
        if st['premature_exec_rate']>.001+1e-12: violations.append(f'{s}:stress:premature_exec')
        if st['premature_exec']>direct_st['premature_exec']: safety_nonworse=False; violations.append(f'{s}:stress:worse_than_direct')
        if st['premature_exec']<direct_st['premature_exec']: safety_strict=True
        if o['mean_normalized_compute']>.70: violations.append(f'{s}:ordinary:compute')
        if st['mean_normalized_compute']>.80: violations.append(f'{s}:stress:compute')
        if sum(1 for c in o['exit_counts'] if c>0)<3: violations.append(f'{s}:exit_diversity')
        mr=1-tg['mean']/tf['mean']; pr=1-tg['p50']/tf['p50']; rr=tg['p95']/tf['p95']-1
        mean_red.append(mr); p50_red.append(pr); p95_reg.append(rr)
        if tg['mean']<tf['mean']: faster+=1
        if rr>.10: violations.append(f'{s}:p95_regression')
    med_mean=float(np.median(mean_red)); med_p50=float(np.median(p50_red))
    speed_ok=med_mean>=.25 and med_p50>=.25 and faster>=3
    safety_gain=safety_nonworse and safety_strict
    competence=not any(any(k in v for k in ['full_accuracy','candidate_accuracy','agreement','yield_exec_delta','premature_yield']) for v in violations)
    safety_closed=not any('premature_exec' in v or 'worse_than_direct' in v for v in violations) and safety_gain
    compute_ok=not any('compute' in v or 'exit_diversity' in v for v in violations)
    tail_ok=not any('p95_regression' in v for v in violations)
    if competence and safety_closed and compute_ok and speed_ok and tail_ok:
        dec='PASS_TYPED_EVIDENCE_GATE_SCOPED'
    elif not safety_gain or any('premature_exec' in v or 'worse_than_direct' in v for v in violations):
        dec='HOLD_EVIDENCE_GATE_NO_SAFETY_GAIN'
    else:
        dec='HOLD_EVIDENCE_GATE_COST_OR_COMPETENCE'
    return dec,{
      'median_mean_latency_reduction':med_mean,'median_p50_latency_reduction':med_p50,'candidate_mean_faster_pairs':faster,
      'p95_regressions':p95_reg,'safety_nonworse_all_seeds':safety_nonworse,'safety_strict_improvement_any_seed':safety_strict,'violations':violations,
    }

def environment():
    return {'python':sys.version,'platform':platform.platform(),'torch':torch.__version__,'numpy':np.__version__,'torch_num_threads':torch.get_num_threads(),'cpu_count':os.cpu_count(),'thread_env':{k:os.environ.get(k) for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']}}

#!/usr/bin/env python3
import argparse, json, resource
from pathlib import Path
import numpy as np, torch
from science import FORMAL_SEEDS, environment, summarize_seed, train

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--seed',type=int,required=True); ap.add_argument('--out',required=True); a=ap.parse_args()
    if a.seed not in FORMAL_SEEDS: raise SystemExit('seed not in frozen formal allocation')
    torch.set_num_threads(1); torch.set_num_interop_threads(1)
    out=Path(a.out); out.mkdir(parents=True,exist_ok=True)
    case=out/f'CASE_{a.seed}.json'; evidence=out/f'CASE_{a.seed}.npz'; marker=out/f'CASE_{a.seed}.invoked'
    if case.exists() or evidence.exists() or marker.exists(): raise SystemExit('formal case already consumed')
    marker.write_text(json.dumps({'seed':a.seed,'invocations':1},sort_keys=True)+'\n')
    model,train_ms=train(a.seed); row=summarize_seed(a.seed,model,train_ms); raw=row.pop('_raw')
    row['environment']=environment(); row['peak_rss_kib']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    case.write_text(json.dumps(row,indent=2,sort_keys=True)+'\n')
    np.savez_compressed(evidence,**raw)
    print(json.dumps({'seed':a.seed,'case':str(case),'evidence':str(evidence)},sort_keys=True))
if __name__=='__main__': main()

#!/usr/bin/env python3
import hashlib, json
from pathlib import Path
from science import ACTIONS, BATCH, CHUNK, CLASSES, CONTINUE_LOCAL, DEPTH, EPOCHS, EVAL_N, EVIDENCE_GATE, EXEC_CONF, FORMAL_SEEDS, LR, MODES, ORD_DIFF, ORD_NOISE, ORD_SIGNAL, ORD_YIELD, PROTO_SEED, STR_DIFF, STR_NOISE, STR_SIGNAL, STR_YIELD, TASK, TIMING_N, TRAIN_N, WARMUP, WIDTH, YIELD, candidate_decision

def main():
    root=Path(__file__).resolve().parent; out=root/'formal'
    result_path=root/'RESULT.json'; marker=root/'AGGREGATE.invoked'
    if result_path.exists() or marker.exists(): raise SystemExit('aggregate already consumed')
    rows=[]
    for seed in FORMAL_SEEDS:
        p=out/f'CASE_{seed}.json'; m=out/f'CASE_{seed}.invoked'; e=out/f'CASE_{seed}.npz'
        if not (p.exists() and m.exists() and e.exists()): raise SystemExit(f'missing frozen case {seed}')
        rows.append(json.loads(p.read_text()))
    marker.write_text('{"invocations":1}\n')
    dec,gates=candidate_decision(rows)
    result={'task':TASK,'formal_case_invocations':4,'formal_case_reruns':0,'aggregate_invocations':1,'decision':dec,'gates':gates,
      'config':{'depth':DEPTH,'chunk':CHUNK,'width':WIDTH,'actions':ACTIONS,'continue_local':CONTINUE_LOCAL,'yield':YIELD,'classes':CLASSES,
        'train_n':TRAIN_N,'eval_n':EVAL_N,'epochs':EPOCHS,'batch':BATCH,'lr':LR,'exec_conf':EXEC_CONF,'evidence_gate':EVIDENCE_GATE,
        'ordinary':{'noise':ORD_NOISE,'signal':ORD_SIGNAL,'yield_prob':ORD_YIELD,'difficulty':ORD_DIFF},
        'stress':{'noise':STR_NOISE,'signal':STR_SIGNAL,'yield_prob':STR_YIELD,'difficulty':STR_DIFF},
        'prototype_seed':PROTO_SEED,'formal_seeds':FORMAL_SEEDS,'warmup':WARMUP,'timing_n':TIMING_N,'modes':MODES},'rows':rows}
    text=json.dumps(result,indent=2,sort_keys=True)+'\n'; result_path.write_text(text)
    (root/'RESULT.sha256').write_text(hashlib.sha256(text.encode()).hexdigest()+'  RESULT.json\n')
    print(json.dumps({'decision':dec,'gates':gates},indent=2,sort_keys=True))
if __name__=='__main__': main()

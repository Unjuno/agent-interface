#!/usr/bin/env python3
import hashlib, json
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent
DEPTH=4; ACTIONS=6; YIELD=7
SEEDS=[9101701,9101702,9101703,9101704]
MODES=('FULL_DEPTH','DIRECT_TTC','TYPED_EVIDENCE_GATE')

def pct(a,p): return float(np.percentile(a,p,method='linear'))
def calc(y,difficulty,preds,depths):
    teacher_yield=(y==YIELD); required=np.where(teacher_yield,DEPTH,difficulty)
    return {'accuracy':float(np.mean(preds==y)),'teacher_yield_n':int(teacher_yield.sum()),
      'teacher_yield_to_exec':int(np.sum(teacher_yield&(preds<ACTIONS))),
      'teacher_yield_to_exec_rate':float(np.sum(teacher_yield&(preds<ACTIONS))/max(1,int(teacher_yield.sum()))),
      'premature_exec':int(np.sum((depths<required)&(preds<ACTIONS))),
      'premature_exec_rate':float(np.mean((depths<required)&(preds<ACTIONS))),
      'premature_yield':int(np.sum((depths<required)&(preds==YIELD))),
      'exit_counts':[int(np.sum(depths==k)) for k in range(1,DEPTH+1)],
      'mean_depth':float(depths.mean()),'mean_normalized_compute':float(depths.mean()/DEPTH)}

def close(a,b,tol=1e-12):
    return abs(float(a)-float(b))<=tol

def main():
    result=json.loads((ROOT/'RESULT.json').read_text()); errors=[]; reconstructed=[]
    for seed in SEEDS:
        case=json.loads((ROOT/'formal'/f'CASE_{seed}.json').read_text()); z=np.load(ROOT/'formal'/f'CASE_{seed}.npz')
        rec={'seed':seed,'ordinary':{},'stress':{},'timing_ms':{}}
        for setname in ('ordinary','stress'):
            y=z[f'{setname}_y']; d=z[f'{setname}_difficulty']; full=z[f'{setname}_FULL_DEPTH_preds']
            for mode in MODES:
                preds=z[f'{setname}_{mode}_preds']; depths=z[f'{setname}_{mode}_depths']; m=calc(y,d,preds,depths)
                if mode!='FULL_DEPTH': m['agreement_with_full']=float(np.mean(full==preds))
                rec[setname][mode]=m
                stored=case[setname][mode]
                for k,v in m.items():
                    if isinstance(v,list):
                        if v!=stored[k]: errors.append(f'{seed}:{setname}:{mode}:{k}')
                    elif isinstance(v,float):
                        if not close(v,stored[k]): errors.append(f'{seed}:{setname}:{mode}:{k}')
                    elif v!=stored[k]: errors.append(f'{seed}:{setname}:{mode}:{k}')
        for mode in MODES:
            vals=z[f'lat_{mode}']; m={'n':len(vals),'p50':pct(vals,50),'p95':pct(vals,95),'p99':pct(vals,99),'max':float(vals.max()),'mean':float(vals.mean()),'decisions_per_s':float(1000.0/vals.mean())}
            rec['timing_ms'][mode]=m
            for k,v in m.items():
                sv=case['timing_ms'][mode][k]
                if isinstance(v,float) and not close(v,sv): errors.append(f'{seed}:timing:{mode}:{k}')
                elif not isinstance(v,float) and v!=sv: errors.append(f'{seed}:timing:{mode}:{k}')
        reconstructed.append(rec)
    # Independently reapply frozen decision gates from raw reconstructed metrics.
    violations=[]; mean_red=[]; p50_red=[]; faster=0; p95_reg=[]; nonworse=True; strict=False
    for r in reconstructed:
        s=r['seed']; tf=r['timing_ms']['FULL_DEPTH']; tg=r['timing_ms']['TYPED_EVIDENCE_GATE']
        for setname,amin,agree in [('ordinary',.98,.99),('stress',.94,.98)]:
            m=r[setname]; full=m['FULL_DEPTH']; cand=m['TYPED_EVIDENCE_GATE']
            if full['accuracy']<amin: violations.append(f'{s}:{setname}:full_accuracy')
            if cand['accuracy']<amin: violations.append(f'{s}:{setname}:candidate_accuracy')
            if cand['agreement_with_full']<agree: violations.append(f'{s}:{setname}:agreement')
            if cand['teacher_yield_to_exec_rate']-full['teacher_yield_to_exec_rate']>.0025+1e-12: violations.append(f'{s}:{setname}:yield_exec_delta')
            if cand['premature_yield']!=0: violations.append(f'{s}:{setname}:premature_yield')
        o=r['ordinary']['TYPED_EVIDENCE_GATE']; st=r['stress']['TYPED_EVIDENCE_GATE']; direct=r['stress']['DIRECT_TTC']
        if o['premature_exec']!=0: violations.append(f'{s}:ordinary:premature_exec')
        if st['premature_exec_rate']>.001+1e-12: violations.append(f'{s}:stress:premature_exec')
        if st['premature_exec']>direct['premature_exec']: nonworse=False; violations.append(f'{s}:stress:worse_than_direct')
        if st['premature_exec']<direct['premature_exec']: strict=True
        if o['mean_normalized_compute']>.70: violations.append(f'{s}:ordinary:compute')
        if st['mean_normalized_compute']>.80: violations.append(f'{s}:stress:compute')
        if sum(c>0 for c in o['exit_counts'])<3: violations.append(f'{s}:exit_diversity')
        mean_red.append(1-tg['mean']/tf['mean']); p50_red.append(1-tg['p50']/tf['p50']); rr=tg['p95']/tf['p95']-1; p95_reg.append(rr)
        if tg['mean']<tf['mean']: faster+=1
        if rr>.10: violations.append(f'{s}:p95_regression')
    med_mean=float(np.median(mean_red)); med_p50=float(np.median(p50_red)); safety_gain=nonworse and strict
    competence=not any(any(k in v for k in ['full_accuracy','candidate_accuracy','agreement','yield_exec_delta','premature_yield']) for v in violations)
    safety_closed=not any('premature_exec' in v or 'worse_than_direct' in v for v in violations) and safety_gain
    compute_ok=not any('compute' in v or 'exit_diversity' in v for v in violations); speed_ok=med_mean>=.25 and med_p50>=.25 and faster>=3; tail_ok=not any('p95_regression' in v for v in violations)
    if competence and safety_closed and compute_ok and speed_ok and tail_ok: decision='PASS_TYPED_EVIDENCE_GATE_SCOPED'
    elif not safety_gain or any('premature_exec' in v or 'worse_than_direct' in v for v in violations): decision='HOLD_EVIDENCE_GATE_NO_SAFETY_GAIN'
    else: decision='HOLD_EVIDENCE_GATE_COST_OR_COMPETENCE'
    if decision!=result['decision']: errors.append(f'decision:{decision}!={result["decision"]}')
    # Source hashes are part of frozen claim.
    expected={}
    for line in (ROOT/'SOURCE_HASHES.sha256').read_text().splitlines():
        h,name=line.split('  ',1); expected[name]=h
    for name,h in expected.items():
        p=ROOT/name
        if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=h: errors.append(f'source_hash:{name}')
    audit={'audit':'PASS' if not errors else 'FAIL','errors':errors,'recomputed_decision':decision,
      'recomputed':{'median_mean_latency_reduction':med_mean,'median_p50_latency_reduction':med_p50,'candidate_mean_faster_pairs':faster,'p95_regressions':p95_reg,'safety_nonworse_all_seeds':nonworse,'safety_strict_improvement_any_seed':strict,'violations':violations}}
    text=json.dumps(audit,indent=2,sort_keys=True)+'\n'; (ROOT/'AUDIT.json').write_text(text); print(text,end='')
    raise SystemExit(0 if not errors else 1)
if __name__=='__main__': main()

"""Read-only, separately implemented reference audit. Never starts study actors."""
import base64
import copy
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
CONDITIONS = ('NORMAL_RESTART', 'CRASH_AT_RECEIPT', 'CRASH_PRECOMMIT',
              'COMMITTED_REPLY_LOST', 'PRE_RECEIVED', 'FOREIGN_SEAL')


def enc(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':')) + '\n'


def jread(p):
    return json.loads(p.read_text())


def lines(p):
    return [json.loads(s) for s in p.read_text().splitlines()]


def db_read(path):
    with sqlite3.connect(path) as db:
        return {'scope': db.execute('SELECT session FROM scope').fetchall(),
                'integrity': db.execute('PRAGMA integrity_check').fetchall(),
                'rows': [[i, s, base64.b64encode(b).decode() if b is not None else None]
                         for i, s, b in db.execute('SELECT id,state,body FROM item ORDER BY id')]}


def assemble(folder):
    # Recovery occurs only on private copies of retained DB/journal bytes.
    with tempfile.TemporaryDirectory(prefix='sr61-db-audit-') as td:
        t = Path(td)
        for p in folder.glob('before-store.db*'):
            shutil.copyfile(p, t / p.name.removeprefix('before-'))
        pre = db_read(t / 'store.db')
        shutil.copyfile(folder / 'store.db', t / 'final.db')
        final = db_read(t / 'final.db')
    return json.loads(enc({'record': jread(folder / 'case.json'),
                          'peers': [jread(folder / f'peer{k}.json') for k in (0, 1)],
                          'actors': [lines(folder / f'actor{k}.jsonl') for k in (0, 1)],
                          'sql': [lines(folder / f'sql{k}.jsonl') for k in (0, 1)],
                          'stderr': [(folder / f'stderr{k}.txt').read_text() for k in (0, 1)],
                          'pre_db': pre, 'final_db': final}))


def audit_case(x, spec, payload, sqlite_version):
    errors, checks = [], 0

    def ck(value, tag):
        nonlocal checks
        checks += 1
        if not value:
            errors.append(tag)

    r = x['record']
    session, condition, arm = spec['session'], spec['condition'], spec['arm']
    ck(r['spec'] == spec, 'case_identity')
    ck(r['authority_granted'] is False, 'authority')
    data = base64.b64encode(payload).decode()
    sha = hashlib.sha256(payload).hexdigest()
    pre_received = condition == 'PRE_RECEIVED'
    killed = condition in ('CRASH_AT_RECEIPT', 'CRASH_PRECOMMIT', 'COMMITTED_REPLY_LOST')
    phases = (['PRECOMMIT', 'RECEIPT', 'COMMITTED', 'DONE'] if arm == 'EARLY_ACK'
              else ['PRECOMMIT', 'COMMITTED', 'RECEIPT', 'DONE'])
    if condition == 'FOREIGN_SEAL':
        phases = ['REFUSED']
    elif condition == 'CRASH_PRECOMMIT':
        phases = phases[:1]
    elif condition == 'CRASH_AT_RECEIPT':
        phases = phases[:phases.index('RECEIPT') + 1]
    ck([m['kind'] for m in r['phases']] == phases, 'phase_order')
    committed = 'COMMITTED' in phases
    statuses = {'C0': 'RECEIVED' if pre_received else 'CLOSED', 'C1': 'CLOSED'}
    got_receipt = 'RECEIPT' in phases and condition != 'COMMITTED_REPLY_LOST'
    refund_ids = [k for k in ('C0', 'C1') if statuses[k] == 'CLOSED'] if got_receipt else []
    if got_receipt:
        expected_receipt = next(m for m in r['phases'] if m['kind'] == 'RECEIPT')
        ck(r['receipt_delivered'] == expected_receipt, 'delivered_receipt')
    else:
        ck(r['receipt_delivered'] is None, 'no_delivered_receipt')
    rows = {'C0': ['RECEIVED', data]} if pre_received else {}
    if committed:
        rows.update({k: [v, data if v == 'RECEIVED' else None] for k, v in statuses.items()})
    expected_pre = [[k] + v for k, v in sorted(rows.items())]
    ck(x['pre_db'] == {'scope': [[session]], 'integrity': [['ok']], 'rows': expected_pre}, 'restart_store')
    first_wire, second_wire = [], []

    def put(w, direction, message):
        w.append([direction, message])

    def boot(w, state):
        put(w, 'recv', {'kind': 'BOOT', 'session': session, 'rows': [[k, v[0]] for k, v in sorted(state.items())],
                        'sqlite': sqlite_version, 'journal_mode': 'delete', 'synchronous': 2})

    def delivery(w, state, ident):
        put(w, 'send', {'op': 'HEADER', 'session': session, 'id': ident, 'size': len(payload)})
        if ident in state:
            reply = {'kind': 'REFUSED', 'id': ident, 'reason': state[ident][0]}
            put(w, 'recv', reply)
        else:
            put(w, 'recv', {'kind': 'READY_BODY', 'id': ident})
            put(w, 'send', {'op': 'BODY', 'session': session, 'id': ident, 'data': data})
            reply = {'kind': 'BODY_ACK', 'id': ident, 'size': len(payload), 'sha256': sha}
            put(w, 'recv', reply)
            state[ident] = ['RECEIVED', data]
        return reply

    def strip(m):
        return {k: v for k, v in m.items() if k not in ('ns', 'pid')}

    empty = {}
    boot(first_wire, empty)
    expected_before = [delivery(first_wire, empty, 'C0')] if pre_received else []
    put(first_wire, 'send', {'op': 'SEAL', 'session': session + '-other' if condition == 'FOREIGN_SEAL' else session,
                            'ids': ['C0', 'C1']})
    for i, phase in enumerate(phases):
        m = {'kind': phase}
        if phase == 'RECEIPT':
            m.update(session=session, statuses=statuses)
        elif phase == 'REFUSED':
            m['reason'] = 'SESSION'
        put(first_wire, 'recv', m)
        if phase not in ('DONE', 'REFUSED') and not (killed and i == len(phases) - 1):
            put(first_wire, 'send', {'op': 'CONTINUE'})
    if not killed:
        put(first_wire, 'send', {'op': 'STOP'})
        put(first_wire, 'recv', {'kind': 'STOPPED'})
    boot(second_wire, rows)
    used, auto = 8192 - 4096 * len(refund_ids), 0
    ledger = [{'kind': 'REFUND', 'ids': refund_ids, 'cue_used': used, 'auto_used': auto}]
    expected_after = []
    for ident in ('C2', 'C3', 'AUTO0', 'AUTO1'):
        is_auto = ident.startswith('AUTO')
        admitted = (auto if is_auto else used) <= 4096
        if admitted:
            if is_auto:
                auto += 4096
            else:
                used += 4096
            expected_after.append(delivery(second_wire, rows, ident))
        ledger.append({'kind': 'ADMIT', 'id': ident, 'admitted': admitted, 'cue_used': used, 'auto_used': auto})
    for ident in ('C0', 'C1'):
        expected_after.append(delivery(second_wire, rows, ident))
    put(second_wire, 'send', {'op': 'STOP'})
    put(second_wire, 'recv', {'kind': 'STOPPED'})
    ck(r['ledger'] == ledger, 'sender_ledger')
    ck([strip(z) for z in r['before']] == expected_before, 'before_bodies')
    ck([strip(z) for z in r['after']] == expected_after, 'after_bodies')
    ck(x['final_db'] == {'scope': [[session]], 'integrity': [['ok']],
                         'rows': [[k] + v for k, v in sorted(rows.items())]}, 'final_store')
    for k, expected_wire in enumerate((first_wire, second_wire)):
        peer = x['peers'][k]
        ck(peer['exit'] == (-9 if k == 0 and killed else 0), f'exit:{k}')
        ck(peer['killed'] == (k == 0 and killed), f'kill_flag:{k}')
        ck(r['first_exit' if k == 0 else 'second_exit'] == peer['exit'], f'exit_copy:{k}')
        ck(peer['argv'][-3:] == [session, arm, str(k)], f'process_binding:{k}')
        ck(peer['ended_ns'] > peer['started_ns'], f'process_bracket:{k}')
        actual = [[w['direction'], strip(json.loads(w['raw']))] for w in peer['wire']]
        ck(actual == expected_wire, f'wire_contract:{k}')
        received = [json.loads(w['raw']) for w in peer['wire'] if w['direction'] == 'recv']
        ck(x['actors'][k] == received, f'actor_wire_identity:{k}')
        ck(r['first_boot' if k == 0 else 'second_boot'] == received[0], f'boot_copy:{k}')
        ck(all(m['pid'] == peer['pid'] for m in received), f'pid:{k}')
        ck(all(w['ns'] >= json.loads(w['raw'])['ns'] for w in peer['wire'] if w['direction'] == 'recv'), f'receipt_clock:{k}')
        ck(all(a['ns'] <= b['ns'] for a, b in zip(peer['wire'], peer['wire'][1:])), f'wire_order:{k}')
        ck(x['stderr'][k] == '', f'stderr:{k}')
        sql = x['sql'][k]
        ck(all(a['ns'] <= b['ns'] for a, b in zip(sql, sql[1:])), f'sql_order:{k}')
        ck(any(q['sql'] == 'PRAGMA synchronous=FULL' for q in sql), f'synchronous:{k}')
        if k == 0:
            commits = [q['ns'] for q in sql if q['sql'] == 'COMMIT']
            ck(len(commits) == int(committed), 'commit_count')
            if committed:
                marker = next(m['ns'] for m in r['phases'] if m['kind'] == 'COMMITTED')
                ck(bool(commits) and commits[0] < marker, 'commit_return_marker')
                if got_receipt and arm == 'COMMIT_ACK':
                    ck(isinstance(r['receipt_delivered'], dict) and marker < r['receipt_delivered'].get('ns', -1), 'commit_before_receipt')
    ck(x['peers'][0]['pid'] != x['peers'][1]['pid'], 'fresh_process')
    accepted = {i: base64.b64decode(b, validate=True) for i, s, b in x['final_db']['rows'] if s == 'RECEIVED'}
    byte_count = sum(map(len, accepted.values()))
    cue_count = sum(len(b) for i, b in accepted.items() if i.startswith('C'))
    ck(all(accepted.get(i) == payload for i in ('AUTO0', 'AUTO1')), 'auto_complete')
    over = byte_count > 16384 or cue_count > 8192
    ck(over == (arm == 'EARLY_ACK' and condition == 'CRASH_AT_RECEIPT'), 'overage_discriminator')
    return {'checks': checks, 'errors': errors, 'received_bytes': byte_count, 'cue_bytes': cue_count,
            'overage': over, 'refunded_bytes': len(refund_ids) * 4096, 'charged_bytes': used + auto}


def audit(root, phase, frozen=True):
    errors, checks, results = [], 0, []
    if frozen:
        for name, dig in jread(root / 'FREEZE.json')['sha256'].items():
            checks += 1
            if hashlib.sha256((root / name).read_bytes()).hexdigest() != dig:
                errors.append('source:' + name)
    matrix = jread(root / 'matrix.json')
    expected = [(a, c, rep) for rep in range(2) for a in ('EARLY_ACK', 'COMMIT_ACK') for c in CONDITIONS]
    checks += 1
    if [(s['arm'], s['condition'], s['rep']) for s in matrix] != expected:
        errors.append('matrix')
    payload = (root / 'payload.bin').read_bytes()
    sqlite_version = jread(root / 'environment.json')['sqlite']
    for index in range(4):
        folder = root / phase / f'b{index}'
        try:
            launch = jread(root / phase / f'launch{index}.json')
            end = jread(folder / 'END.json')
            checks += 2
            if launch['exit'] != 0 or launch['timeout'] or launch['stderr'] or launch['end_ns'] <= launch['start_ns']:
                errors.append(f'launch:{index}')
            if end != {'complete': True, 'ids': [s['id'] for s in matrix[index*6:(index+1)*6]]}:
                errors.append(f'batch:{index}')
        except (OSError, ValueError, KeyError) as exc:
            errors.append(f'batch_missing:{index}:{type(exc).__name__}')
        for spec in matrix[index*6:(index+1)*6]:
            try:
                current = dict(spec, session=f'sr61-{phase}-{spec["id"]}')
                result = audit_case(assemble(folder / spec['id']), current, payload, sqlite_version)
                checks += result['checks']
                errors.extend(spec['id'] + ':' + e for e in result['errors'])
                results.append(dict(result, id=spec['id'], arm=spec['arm'], condition=spec['condition']))
            except (OSError, ValueError, KeyError, TypeError, sqlite3.Error) as exc:
                errors.append(spec['id'] + ':audit_input:' + type(exc).__name__)
    return {'decision': 'PASS_COMMIT_BEFORE_SEAL_ACK_RESTART_SCOPED' if not errors else 'HOLD_OR_FAIL_AUDIT',
            'checks': checks, 'errors': errors, 'cases': len(results), 'results': results}


def controls(root, phase, destination):
    destination.mkdir(parents=True, exist_ok=False)
    raw = assemble(root / phase / 'b1' / 'c07')
    spec = raw['record']['spec']
    payload = (root / 'payload.bin').read_bytes()
    version = jread(root / 'environment.json')['sqlite']
    if audit_case(raw, spec, payload, version)['errors']:
        raise ValueError('baseline failed')
    mutations = {
        'authority': lambda z: z['record'].__setitem__('authority_granted', True),
        'refund_twice': lambda z: z['record']['ledger'][0]['ids'].append('C0'),
        'wrong_session': lambda z: z['record']['spec'].__setitem__('session', 'other'),
        'wrong_exit': lambda z: z['peers'][0].__setitem__('exit', 0),
        'missing_closure': lambda z: z['pre_db']['rows'].pop(),
        'late_body': lambda z: z['final_db']['rows'].__setitem__(2, ['C0', 'RECEIVED', base64.b64encode(payload).decode()]),
        'wrong_body': lambda z: z['final_db']['rows'][0].__setitem__(2, base64.b64encode(b'X'*4096).decode()),
        'missing_wire': lambda z: z['peers'][1]['wire'].pop(3),
        'receipt_order': lambda z: z['record']['phases'].reverse(),
        'commit_trace': lambda z: z['sql'][0].__setitem__(next(i for i,q in enumerate(z['sql'][0]) if q['sql']=='COMMIT'), {'ns': 0, 'sql': 'ROLLBACK'}),
        'db_scope': lambda z: z['pre_db'].__setitem__('scope', [['other']]),
        'missing_receipt': lambda z: z['record'].__setitem__('receipt_delivered', None),
    }
    outcomes = []
    for name, fn in mutations.items():
        changed = copy.deepcopy(raw)
        fn(changed)
        before, after = enc(raw).encode(), enc(changed).encode()
        if before == after:
            raise ValueError('no-op: ' + name)
        result = audit_case(changed, spec, payload, version)
        (destination / (name + '.json')).write_bytes(after)
        (destination / (name + '.audit.json')).write_text(enc(result))
        outcomes.append({'name': name, 'changed': True, 'rejected': bool(result['errors']),
                         'sha256': hashlib.sha256(after).hexdigest(), 'errors': result['errors']})
    (destination / 'CONTROLS.json').write_text(enc(outcomes))
    if not all(o['rejected'] for o in outcomes):
        raise ValueError('unrejected mutation')
    return outcomes


if __name__ == '__main__':
    root, phase = Path(sys.argv[1]), sys.argv[2]
    if len(sys.argv) > 3 and sys.argv[3] == 'controls':
        result = controls(root, phase, root / (phase + '_controls'))
        print(enc(result), end='')
    else:
        result = audit(root, phase, frozen=phase == 'formal')
        print(enc(result), end='')
        raise SystemExit(bool(result['errors']))

"""Private SQLite receiver restart experiment. No network or GUI inputs."""
import base64
import hashlib
import json
import os
from pathlib import Path
import selectors
import shutil
import sqlite3
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
ARMS = ('EARLY_ACK', 'COMMIT_ACK')
CONDITIONS = ('NORMAL_RESTART', 'CRASH_AT_RECEIPT', 'CRASH_PRECOMMIT',
              'COMMITTED_REPLY_LOST', 'PRE_RECEIVED', 'FOREIGN_SEAL')


def encode(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':')) + '\n'


def serve(folder, session, arm, lifetime):
    """One allocation-owned receiver; the logical session survives restart."""
    db = sqlite3.connect(folder / 'store.db', isolation_level=None, timeout=0)
    journal = (folder / f'actor{lifetime}.jsonl').open('x')
    trace = (folder / f'sql{lifetime}.jsonl').open('x')
    db.set_trace_callback(lambda q: (trace.write(encode({'ns': time.monotonic_ns(), 'sql': q})), trace.flush()))
    db.execute('PRAGMA journal_mode=DELETE')
    db.execute('PRAGMA synchronous=FULL')
    db.execute('CREATE TABLE IF NOT EXISTS scope (session TEXT PRIMARY KEY)')
    db.execute('CREATE TABLE IF NOT EXISTS item (id TEXT PRIMARY KEY, state TEXT NOT NULL, body BLOB)')
    if not db.execute('SELECT session FROM scope').fetchall():
        db.execute('INSERT INTO scope VALUES (?)', (session,))
    assert db.execute('SELECT session FROM scope').fetchall() == [(session,)]

    def emit(x):
        x = dict(x, pid=os.getpid(), ns=time.monotonic_ns())
        line = encode(x)
        journal.write(line)
        journal.flush()
        sys.stdout.write(line)
        sys.stdout.flush()

    def gate(x):
        emit(x)
        if json.loads(sys.stdin.readline()) != {'op': 'CONTINUE'}:
            raise ValueError('bad phase continuation')

    rows = db.execute('SELECT id,state FROM item ORDER BY id').fetchall()
    emit({'kind': 'BOOT', 'session': session, 'rows': rows,
          'sqlite': sqlite3.sqlite_version, 'journal_mode': db.execute('PRAGMA journal_mode').fetchone()[0],
          'synchronous': db.execute('PRAGMA synchronous').fetchone()[0]})
    pending = None
    for line in sys.stdin:
        q = json.loads(line)
        op = q['op']
        if op == 'STOP':
            emit({'kind': 'STOPPED'})
            break
        if q.get('session') != session:
            emit({'kind': 'REFUSED', 'reason': 'SESSION'})
            continue
        if op == 'SEAL':
            if pending is not None:
                raise ValueError('seal during pending body')
            db.execute('BEGIN IMMEDIATE')
            statuses = {}
            for ident in q['ids']:
                row = db.execute('SELECT state FROM item WHERE id=?', (ident,)).fetchone()
                if row is None:
                    db.execute("INSERT INTO item VALUES (?,'CLOSED',NULL)", (ident,))
                    statuses[ident] = 'CLOSED'
                else:
                    statuses[ident] = row[0]
            receipt = {'kind': 'RECEIPT', 'session': session, 'statuses': statuses}
            gate({'kind': 'PRECOMMIT'})
            if arm == 'EARLY_ACK':
                gate(receipt)
            db.execute('COMMIT')
            gate({'kind': 'COMMITTED'})
            if arm == 'COMMIT_ACK':
                gate(receipt)
            emit({'kind': 'DONE'})
        elif op == 'HEADER':
            if pending is not None:
                raise ValueError('already awaiting body')
            row = db.execute('SELECT state FROM item WHERE id=?', (q['id'],)).fetchone()
            if row:
                emit({'kind': 'REFUSED', 'id': q['id'], 'reason': row[0]})
            elif q['size'] != 4096:
                emit({'kind': 'REFUSED', 'id': q['id'], 'reason': 'SIZE'})
            else:
                pending = q['id']
                emit({'kind': 'READY_BODY', 'id': pending})
        elif op == 'BODY':
            data = base64.b64decode(q['data'], validate=True)
            if pending != q['id'] or len(data) != 4096:
                raise ValueError('body binding')
            db.execute("INSERT INTO item VALUES (?,'RECEIVED',?)", (pending, data))
            emit({'kind': 'BODY_ACK', 'id': pending, 'size': len(data),
                  'sha256': hashlib.sha256(data).hexdigest()})
            pending = None
        else:
            raise ValueError(op)
    db.close()
    journal.close()
    trace.close()


class Peer:
    def __init__(self, folder, session, arm, lifetime):
        self.folder, self.lifetime = folder, lifetime
        self.wire = []
        self.stderr = (folder / f'stderr{lifetime}.txt').open('x')
        self.argv = [sys.executable, '-S', '-B', str(ROOT / 'study.py'),
                     'receiver', str(folder), session, arm, str(lifetime)]
        self.started = time.monotonic_ns()
        self.p = subprocess.Popen(self.argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                  stderr=self.stderr, bufsize=0)
        self.selector = selectors.DefaultSelector()
        self.selector.register(self.p.stdout, selectors.EVENT_READ)
        self.buffer = b''
        self.boot = self.read()

    def write(self, q):
        raw = encode(q).encode()
        self.p.stdin.write(raw)
        self.p.stdin.flush()
        self.wire.append({'direction': 'send', 'ns': time.monotonic_ns(), 'raw': raw.decode()})

    def read(self):
        deadline = time.monotonic() + 5
        while b'\n' not in self.buffer:
            left = deadline - time.monotonic()
            if left <= 0 or not self.selector.select(left):
                raise TimeoutError('receiver read')
            part = os.read(self.p.stdout.fileno(), 65536)
            if not part:
                raise EOFError('receiver output')
            self.buffer += part
        line, self.buffer = self.buffer.split(b'\n', 1)
        raw = line.decode() + '\n'
        self.wire.append({'direction': 'recv', 'ns': time.monotonic_ns(), 'raw': raw})
        return json.loads(raw)

    def deliver(self, session, ident, payload):
        self.write({'op': 'HEADER', 'session': session, 'id': ident, 'size': len(payload)})
        reply = self.read()
        if reply['kind'] == 'READY_BODY':
            self.write({'op': 'BODY', 'session': session, 'id': ident,
                        'data': base64.b64encode(payload).decode()})
            reply = self.read()
        return reply

    def finish(self, kill=False):
        if kill:
            self.p.kill()
        else:
            self.write({'op': 'STOP'})
            if self.read()['kind'] != 'STOPPED':
                raise ValueError('stop receipt')
        rc = self.p.wait(timeout=5)
        self.p.stdin.close()
        self.p.stdout.close()
        self.selector.close()
        self.stderr.close()
        record = {'pid': self.p.pid, 'argv': self.argv, 'started_ns': self.started,
                  'ended_ns': time.monotonic_ns(), 'exit': rc, 'killed': kill, 'wire': self.wire}
        (self.folder / f'peer{self.lifetime}.json').write_text(encode(record))
        return record


def refund(receipt, session):
    if not receipt or receipt.get('kind') != 'RECEIPT' or receipt.get('session') != session:
        return []
    statuses = receipt.get('statuses', {})
    if set(statuses) != {'C0', 'C1'} or not all(v in ('RECEIVED', 'CLOSED') for v in statuses.values()):
        return []
    return sorted(k for k, v in statuses.items() if v == 'CLOSED')


def run_case(folder, spec):
    folder.mkdir(parents=True, exist_ok=False)
    payload = (ROOT / 'payload.bin').read_bytes()
    session, arm, condition = spec['session'], spec['arm'], spec['condition']
    peer = Peer(folder, session, arm, 0)
    before = []
    if condition == 'PRE_RECEIVED':
        before.append(peer.deliver(session, 'C0', payload))
    peer.write({'op': 'SEAL', 'session': session if condition != 'FOREIGN_SEAL' else session + '-other',
                'ids': ['C0', 'C1']})
    receipt, stopped, phases = None, False, []
    while True:
        msg = peer.read()
        phases.append(msg)
        if msg['kind'] == 'RECEIPT' and condition != 'COMMITTED_REPLY_LOST':
            receipt = msg
        if ((condition == 'CRASH_AT_RECEIPT' and msg['kind'] == 'RECEIPT') or
                (condition == 'CRASH_PRECOMMIT' and msg['kind'] == 'PRECOMMIT') or
                (condition == 'COMMITTED_REPLY_LOST' and msg['kind'] == 'DONE')):
            first = peer.finish(kill=True)
            stopped = True
            break
        if msg['kind'] in ('DONE', 'REFUSED'):
            break
        peer.write({'op': 'CONTINUE'})
    if not stopped:
        first = peer.finish()
    for p in sorted(folder.glob('store.db*')):
        shutil.copyfile(p, folder / ('before-' + p.name))
    refunded = refund(receipt, session)
    used = 8192 - 4096 * len(refunded)
    ledger = [{'kind': 'REFUND', 'ids': refunded, 'cue_used': used, 'auto_used': 0}]
    peer = Peer(folder, session, arm, 1)
    after, auto = [], 0
    for ident in ('C2', 'C3', 'AUTO0', 'AUTO1'):
        is_auto = ident.startswith('AUTO')
        admit = (auto if is_auto else used) + 4096 <= 8192
        if admit:
            if is_auto:
                auto += 4096
            else:
                used += 4096
            after.append(peer.deliver(session, ident, payload))
        ledger.append({'kind': 'ADMIT', 'id': ident, 'admitted': admit, 'cue_used': used, 'auto_used': auto})
    # These are old in-flight requests, not newly budgeted sender attempts.
    for ident in ('C0', 'C1'):
        after.append(peer.deliver(session, ident, payload))
    second = peer.finish()
    result = {'spec': spec, 'first_boot': peer_boot(first), 'second_boot': peer.boot,
              'receipt_delivered': receipt, 'phases': phases, 'before': before, 'after': after,
              'ledger': ledger, 'first_exit': first['exit'], 'second_exit': second['exit'],
              'authority_granted': False}
    (folder / 'case.json').write_text(encode(result))
    return spec['id']


def peer_boot(record):
    return json.loads(record['wire'][0]['raw'])


def batch(phase, index):
    specs = json.loads((ROOT / 'matrix.json').read_text())
    selected = specs[index * 6:(index + 1) * 6]
    if len(selected) != 6:
        raise ValueError('batch index')
    out = ROOT / phase / f'b{index}'
    out.mkdir(parents=True, exist_ok=False)
    for spec in selected:
        item = dict(spec, session=f'sr61-{phase}-{spec["id"]}')
        run_case(out / spec['id'], item)
    (out / 'END.json').write_text(encode({'ids': [s['id'] for s in selected], 'complete': True}))


if __name__ == '__main__':
    if sys.argv[1] == 'receiver':
        serve(Path(sys.argv[2]), sys.argv[3], sys.argv[4], int(sys.argv[5]))
    elif sys.argv[1] == 'batch':
        batch(sys.argv[2], int(sys.argv[3]))
    elif sys.argv[1] == 'launch':
        phase, index = sys.argv[2], int(sys.argv[3])
        destination = ROOT / phase
        destination.mkdir(exist_ok=True)
        receipt = destination / f'launch{index}.json'
        if receipt.exists() or (destination / f'b{index}').exists():
            raise FileExistsError('consumed batch')
        argv = [sys.executable, '-S', '-B', str(ROOT / 'study.py'), 'batch', phase, str(index)]
        start = time.monotonic_ns()
        try:
            p = subprocess.run(argv, capture_output=True, timeout=30)
            record = {'argv': argv, 'start_ns': start, 'end_ns': time.monotonic_ns(), 'exit': p.returncode,
                      'stdout': p.stdout.decode(), 'stderr': p.stderr.decode(), 'timeout': False}
        except subprocess.TimeoutExpired as exc:
            record = {'argv': argv, 'start_ns': start, 'end_ns': time.monotonic_ns(), 'exit': None,
                      'stdout': (exc.stdout or b'').decode(), 'stderr': (exc.stderr or b'').decode(), 'timeout': True}
        receipt.write_text(encode(record))
        print(encode(record), end='')
        raise SystemExit(record['exit'] if record['exit'] is not None else 1)
    else:
        raise SystemExit('receiver | batch | launch')

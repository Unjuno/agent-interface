import copy
import unittest
import study

class RefundContract(unittest.TestCase):
    def setUp(self):
        self.receipt = {'kind':'RECEIPT','session':'s','statuses':{'C0':'CLOSED','C1':'CLOSED'}}
    def test_absence(self):
        self.assertEqual(study.refund(None,'s'), [])
    def test_session(self):
        self.assertEqual(study.refund(self.receipt,'other'), [])
    def test_both_closed(self):
        self.assertEqual(study.refund(self.receipt,'s'), ['C0','C1'])
    def test_received_not_refunded(self):
        self.receipt['statuses']['C0']='RECEIVED'
        self.assertEqual(study.refund(self.receipt,'s'), ['C1'])
    def test_both_received(self):
        self.receipt['statuses']={'C0':'RECEIVED','C1':'RECEIVED'}
        self.assertEqual(study.refund(self.receipt,'s'), [])
    def test_pending(self):
        self.receipt['statuses']['C0']='PENDING'
        self.assertEqual(study.refund(self.receipt,'s'), [])
    def test_missing_identity(self):
        del self.receipt['statuses']['C1']
        self.assertEqual(study.refund(self.receipt,'s'), [])
    def test_extra_identity(self):
        self.receipt['statuses']['C2']='CLOSED'
        self.assertEqual(study.refund(self.receipt,'s'), [])
    def test_wrong_receipt_kind(self):
        self.receipt['kind']='COMMITTED'
        self.assertEqual(study.refund(self.receipt,'s'), [])
    def test_nonmutating(self):
        old=copy.deepcopy(self.receipt)
        study.refund(self.receipt,'s')
        self.assertEqual(self.receipt,old)

if __name__=='__main__':
    unittest.main()

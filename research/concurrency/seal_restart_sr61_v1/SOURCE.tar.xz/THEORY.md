# Conditional invariant and counterexample

## Variables
| Symbol | Meaning | SI / recorded unit | Definition | Domain and assumptions | Type |
|---|---|---|---|---|---|
| B | Session capacity / セッション容量 | dimension1; bytes (8 bits/byte) | 16384 | positive integer | scalar |
| I | Packet identities / パケット識別子 | dimension1 | C0,C1,C2,C3,AUTO0,AUTO1 | finite fixed namespace | finite set |
| c_i | Charged payload length / 画像本文長 | dimension1; bytes | 4096 for every i | nonnegative integer; exact length | scalar |
| t | Ordered protocol boundary / 手順境界 | dimension1 | event index, not a clock | nonnegative integer | scalar |
| Q_t | Charged identities / 消費枠拘束済みID | dimension1 | reserved but not validly refunded | subset of I | finite set |
| A_t | Completely received identities / 全文受信済みID | dimension1 | at most one receipt per i | subset of I | finite set |
| U_t | Accounted use / 台帳消費量 | dimension1; bytes | sum of c_i over Q_t | at most B by admission | scalar |
| D_t | Received amount / 実受信量 | dimension1; bytes | sum of c_i over A_t | no duplicate complete body | scalar |

## Assumptions
A single sender charges before exposing a new identity to transport. A receiver admits BODY only after an absent ID's HEADER and stores RECEIVED without duplicate complete-body delivery. SEAL reports RECEIVED without refund, or records CLOSED only for an identity with no received/pending body. A valid refund certificate follows successful persistent closure commit. Restart reopens the SAME store and never discards closures. No DB loss, rollback, epoch reset, GC, extra sender, malicious response, body-phase crash or new transport duplicate is covered.

## Proof
Initially A_0 is empty and Q_0 contains C0/C1, so A_0 is a subset of Q_0. Suppose A_t is a subset of Q_t.

1. Admission adds an identity to Q_t only when the new U is at most B. It cannot remove an element of A_t and preserves the subset relation.
2. Complete BODY receipt adds i to A_t. The sender already reserved i. If i had been refunded, a persistent CLOSED record would prevent its HEADER from authorizing a BODY; therefore i has not been refunded and still belongs to Q_t. The subset relation is preserved.
3. Refund removes i from Q_t only after a matching CLOSED receipt. SEAL cannot close a previously received identity, so i is not in A_t. Removal preserves the subset relation. Repeating refund is excluded by the sender's once-per-ID discipline.
4. A receiver interruption changes neither charged sender identities nor committed DB closure rows. A newly opened receiver reconstructs those rows. Thus cases2-3 retain their premises after restart. An uncommitted closure cannot have yielded a valid COMMIT_ACK receipt. Without receipt the sender keeps Q unchanged. A committed closure with a lost receipt also keeps Q unchanged.

These cases cover the frozen protocol transitions. By induction, A_t is a subset of Q_t at every boundary. Nonnegative c_i then give

D_t = sum_{i in A_t} c_i <= sum_{i in Q_t} c_i = U_t <= B.

Unit check: every term is an information volume recorded in bytes; no time, currency, latency or token count is added to it.

## Counterexample
EARLY_ACK breaks assumption3. C0/C1 closure receipts arrive while their transaction remains uncommitted. The sender removes both charges and can admit C2/C3/AUTO0/AUTO1, totaling16384 bytes. SIGKILL rolls back the pending closure. After restart, C0/C1 also enter, bringing D to24576 while U is16384. Exactly8192 received bytes no longer have charged identities. The receipt was about transient state, not persistent exclusion.

## Availability limit
If closure commits but its receipt is withheld, the sender still charges8192 for C0/C1, refuses C2/C3 and admits only AUTO0/AUTO1. The receiver rejects the old C0/C1 bodies. Then U=16384, D=8192. The bound is preserved, but8192 capacity remains stranded. No later-query, GC or generation-switch solution is inferred here.

## Primary references and scope
SQLite atomic commit: https://www.sqlite.org/atomiccommit.html
SQLite synchronous setting: https://www.sqlite.org/pragma.html#pragma_synchronous
These describe the known engine contract. FULL in DELETE mode does not by itself justify a universal power-loss durability claim; this experiment interrupts only the receiver process. The empirical question is whether the chosen ACK/store boundary actually respects the above assumptions under the directed restart schedule.

ERROR CHECK: The proof is conditional, finite and non-probabilistic. It does not authenticate receipts, convert accepted images to task effects, or prove general crash safety during BODY acceptance. Garbage-collecting CLOSED records would invalidate case4 unless an additional fence prevents old traffic.

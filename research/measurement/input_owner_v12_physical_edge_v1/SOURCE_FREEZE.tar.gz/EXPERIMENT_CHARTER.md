# INPUT-OWNER-PHYSICAL-EDGE-TELEMETRY-SOURCE-20260918-002

BASE: `a630412e2cffbee838b19e77760e579218dd553d`
Issue: #998
Reservation branch: `research/input-owner-v12-physical-edge-a630412`
Execution root: disposable container only. No X11/Xvfb/XTEST/GUI/model/provider/task input/live-formal authority.

## H — one composition/source factor
Hold current v10 authority/focus/lease/cancel/expiry/pointer/non-key semantics fixed. Compose two already-retained measurement mechanisms into a new research-only v12 ordinary-key path:

1. #1035 measurement-only within-request keymap sampling order/non-interference;
2. #1048 stable owner-local physical-hold generation identity.

For ordinary `down`/`up`, v12 adds raw pre/post key-state samples around the existing inject+sync path, derives #994/#992-compatible physical edge brackets only when evidence is fully known, and binds confirmed down/up edges to the retained actuation generation identity. Sampling/identity/receipt fields never admit, reject, renew or extend input authority.

## T
1. Pin exact current-main v10 blob `341b3c01649943ddaad5f28431a792c4889cc36e` and v11 blob `842071284156d3ccc647f47135ee62a9e512cb56`.
2. Pin parent sources: #994 press contract blob `9dcb1890b955019dd3880c1b09689213bbb84a58`, #992 release contract blob `15008b58e5389b2e1d3b530abf029982686e6bc0`, #996 adapter blob `a1344409ea6383c6394e991ac0b59fa7689978ef`, #1048 identity model blob `bdf68b88111ddb61297cdec29be394d7fd4dd060`, #1035 sequencing candidate blob `61d0457e2c1a4a31836550fdefba2fe17a919e07`.
3. Create `input_owner_v12.py` only as a new research source by mechanically patching the exact v10 source. Do not modify v10/v11.
4. Offline construction uses an actual imported v12 `InputOwner` with fake Xlib/xtest/display/executor modules so its real owner thread executes; no X server exists.
5. Fixed controls cover first confirmed hold, repeated down, sequential holds, preexisting physical DOWN, sample pre/post failure, already-UP no-op, foreign intent, focus/lease/cancel rejection, inject/sync failure and missing measurement lineage.
6. Primary construction: 10,000 deterministic fresh scenarios, each using a fresh fake owner lifetime and 1–6 ordinary key requests, compared with an independently implemented state/receipt oracle. Non-key source region is hash/diff checked against v10.
7. Parent-compatible known-evidence receipts are independently rebuilt through frozen #994/#992 semantics; confirmed matched edges are composed through frozen #996 semantics. Unknown samples never produce a physical interval.
8. Source-first freeze exact source/tests/schedule/auditor before the primary construction. Mandatory Issue/branch/PR reread immediately before primary.
9. One primary construction invocation; reruns/replacements/tuning 0. Independent audit/corruption/source rehash after first outcome.

## D
`PASS_INPUT_OWNER_V12_OFFLINE_MECHANICS_SCOPED` only if:
- exact v10/v11 and retained dependency identities match;
- all fixed controls pass;
- primary candidate/oracle semantic mismatch = 0;
- candidate never changes a baseline admission/rejection/exception solely due to sample value/failure;
- no physical interval is exposed from UNKNOWN/preexisting/already-held/no-op/incomplete evidence;
- every fully known confirmed receipt equals the appropriate #994/#992 contract result;
- stable `actuation_id` is minted once on confirmed new hold, repeated down reuses it, matching confirmed up retires it, and verified owner cleanup closes measurement-generation state without claiming a physical-UP interval; a later confirmed hold mints a newer ID;
- #996 composes only exact-lineage confirmed nonoverlapping down/up edge pairs;
- source outside the allowed key-measurement/identity additions remains v10-equivalent; no runtime/shared source is changed;
- all outputs remain measurement-only (`grants_input_authority=false`), source/result/audit integrity passes.

Any measurement-dependent action/rejection is `FAIL_MEASUREMENT_AFFECTS_CONTROL`; false interval is `FAIL_FALSE_PHYSICAL_EDGE`; identity drift is `FAIL_ACTUATION_ID_LIFECYCLE`; non-measurement source/runtime drift is `FAIL_RUNTIME_SEMANTIC_DRIFT`; integrity mismatch is `FAIL_INTEGRITY`.

## C / U
This is mocked owner/backend/keymap evidence. It does not establish real X11 keymap timing, physical truth, application consumption, scheduler overhead, MAP01 usefulness or production ABI readiness. Cleanup-side physical edges remain separately scoped: verified existing cleanup may close owner-local generation bookkeeping, but it emits no physical-UP bracket in this allocation. A v12 ordinary-key PASS would authorize only a separately leased private-X11 successor.

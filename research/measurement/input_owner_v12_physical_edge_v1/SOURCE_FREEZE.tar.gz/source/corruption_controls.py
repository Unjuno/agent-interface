from __future__ import annotations
import copy,json
from independent_audit import audit_row

def sample_row():
 return {'scenario_id':1,'family':'x','baseline_input_trace':[['input',2,72,1],['sync',1],['input',3,72,2],['sync',2]],'candidate_input_trace':[['input',2,72,1],['sync',1],['input',3,72,2],['sync',2]],'baseline_terminal_down':[],'candidate_terminal_down':[],'baseline_close_error':None,'candidate_close_error':None,'candidate_query_fail':[],'cfg':{},'calls':[
 {'index':0,'request':{'op':'down'},'baseline':{'ok':True,'base':{'event':'input_admission','key':'F8','valid_until_ns':9}},'candidate':{'ok':True,'base':{'event':'input_admission','key':'F8','valid_until_ns':9},'receipt':{'edge':'down','status':'CONFIRMED_PHYSICAL_DOWN','physical_down_interval':[2,5],'press_id':'p','owner_id':'o','intent_token':'i','key':'F8','owner_owned_before':False,'owner_owned_after':True,'pre_sample':{'known':True,'key_down':False,'sample_started_ns':1,'sample_finished_ns':2,'error':None},'post_sample':{'known':True,'key_down':True,'sample_started_ns':4,'sample_finished_ns':5,'error':None},'press_attempted':True,'sync_succeeded':True,'press_request_ns':3,'sync_return_ns':4,'operation_started_ns':0,'operation_return_ns':6,'actuation_id':'o:g1:F8','identity_disposition':'MINTED','grants_input_authority':False,'application_consumption_observed':False}}},
 {'index':1,'request':{'op':'up'},'baseline':{'ok':True,'base':None},'candidate':{'ok':True,'base':{'event':'input_release_measurement','operation':'up','payload':'F8'},'receipt':{'edge':'up','status':'CONFIRMED_PHYSICAL_UP','physical_up_interval':[8,11],'release_id':'u','owner_id':'o','intent_token':'i','key':'F8','owner_owned':True,'pre_sample':{'known':True,'key_down':True,'sample_started_ns':7,'sample_finished_ns':8,'error':None},'post_sample':{'known':True,'key_down':False,'sample_started_ns':10,'sample_finished_ns':11,'error':None},'release_attempted':True,'sync_succeeded':True,'release_request_ns':9,'sync_return_ns':10,'operation_started_ns':7,'operation_return_ns':12,'actuation_id':'o:g1:F8','identity_disposition':'RETIRED','grants_input_authority':False,'application_consumption_observed':False}}}]}

def run():
 base=sample_row(); assert audit_row(base)==[]
 muts=[]
 x=copy.deepcopy(base); x['calls'][0]['candidate']['receipt']['grants_input_authority']=True; muts.append(('authority',x))
 x=copy.deepcopy(base); x['calls'][0]['candidate']['receipt']['physical_down_interval']=None; muts.append(('missing_interval',x))
 x=copy.deepcopy(base); x['calls'][1]['candidate']['receipt']['actuation_id']='o:g2:F8'; muts.append(('lineage',x))
 x=copy.deepcopy(base); x['candidate_input_trace'].append(['input',2,72,3]); muts.append(('trace',x))
 x=copy.deepcopy(base); x['candidate_terminal_down']=[72]; muts.append(('terminal',x))
 out={n:bool(audit_row(x)) for n,x in muts}
 return {'pass':all(out.values()),'controls':out}
if __name__=='__main__':
 r=run(); print(json.dumps(r,sort_keys=True,indent=2)); raise SystemExit(0 if r['pass'] else 1)

from __future__ import annotations
import json
from pathlib import Path
from fake_owner_harness import BackendConfig, Lease, make_owner, call_record, close_quiet, input_trace
from oracle import check_interval, compose

HERE=Path(__file__).resolve().parent
OUT=HERE.parent/'construction'
OUT.mkdir(parents=True,exist_ok=True)

def require(cond,msg):
    if not cond: raise AssertionError(msg)

def pair_cfg(name, **kw):
    a=BackendConfig(name=name+'-v10', **kw)
    b=BackendConfig(name=name+'-v12', **kw)
    return a,b

def run_pair(name, calls, cfgkw=None, candidate_query_fail=None):
    cfgkw=cfgkw or {}
    c10,c12=pair_cfg(name,**cfgkw)
    if candidate_query_fail: c12.query_fail_at=set(candidate_query_fail)
    o10,d10=make_owner('v10',c10); o12,d12=make_owner('v12',c12)
    leases10={}; leases12={}
    rows=[]
    try:
        for item in calls:
            lid=item.get('lease','A'); intent=item.get('intent','intent-A')
            if lid not in leases10:
                deadline=__import__('time').perf_counter_ns()+10_000_000_000
                leases10[lid]=Lease(intent_token=intent, expected_focus=item.get('expected_focus',4242), lease_ok=item.get('lease_ok',True), deadline=deadline)
                leases12[lid]=Lease(intent_token=intent, expected_focus=item.get('expected_focus',4242), lease_ok=item.get('lease_ok',True), deadline=deadline)
                if item.get('cancel'): leases10[lid].cancel.set(); leases12[lid].cancel.set()
            a=call_record(o10,item['op'],leases10[lid],item.get('key','F8'))
            b=call_record(o12,item['op'],leases12[lid],item.get('key','F8'))
            require(a['ok']==b['ok'],f'{name}: control success drift {a} {b}')
            if not a['ok']:
                require(a['error']==b['error'],f'{name}: error drift {a["error"]} {b["error"]}')
            else:
                if item['op']=='down':
                    require(a['result']['event']==b['result']['event']=='input_admission',f'{name}: down event')
                    require(a['result']['key']==b['result']['key'],f'{name}: key drift')
                    require(a['result']['valid_until_ns']==b['result']['valid_until_ns'],f'{name}: lease drift')
                elif item['op']=='up': require(a['result'] is None and b['result']['event']=='input_release_measurement',f'{name}: up shape')
            rows.append({'request':item,'baseline':a,'candidate':b})
    finally:
        e10=close_quiet(o10); e12=close_quiet(o12)
    require(e10==e12,f'{name}: close drift {e10} {e12}')
    require(input_trace(d10)==input_trace(d12),f'{name}: input/sync drift {input_trace(d10)} {input_trace(d12)}')
    require(d10.down==d12.down,f'{name}: terminal physical drift')
    return rows,d10,d12

def receipt(row): return row['candidate']['result']['physical_edge_receipt']

results={}
# 1 clean confirmed down/up and compose.
r,_,_=run_pair('clean',[{'op':'down'},{'op':'up'}]); d,u=receipt(r[0]),receipt(r[1])
require(d['status']=='CONFIRMED_PHYSICAL_DOWN' and d['identity_disposition']=='MINTED' and check_interval(d,'down'),'clean down')
require(u['status']=='CONFIRMED_PHYSICAL_UP' and u['identity_disposition']=='RETIRED' and u['actuation_id']==d['actuation_id'] and check_interval(u,'up'),'clean up')
require(compose(d,u)=='COMPOSED_PHYSICAL_ACTUATION','compose')
results['clean']='PASS'
# 2 repeated down preserves ID and has no second physical interval.
r,_,_=run_pair('repeat',[{'op':'down'},{'op':'down'},{'op':'up'}]); a,b=receipt(r[0]),receipt(r[1])
require(b['status']=='OWNER_ALREADY_HELD' and b['physical_down_interval'] is None and b['identity_disposition']=='ACTIVE_REUSED' and b['actuation_id']==a['actuation_id'],'repeat')
results['repeat']='PASS'
# 3 sequential holds mint newer generation.
r,_,_=run_pair('sequential',[{'op':'down'},{'op':'up'},{'op':'down'},{'op':'up'}]); ids=[receipt(r[i])['actuation_id'] for i in (0,2)]
require(ids[0]!=ids[1] and ':g1:' in ids[0] and ':g2:' in ids[1],'sequential ids')
results['sequential']='PASS'
# 4 preexisting physical down: action still admitted, no fresh edge/id.
r,_,_=run_pair('preexisting',[{'op':'down'}],{'initial_down':{72}}); x=receipt(r[0])
require(x['status']=='PREEXISTING_PHYSICAL_DOWN' and x['physical_down_interval'] is None and x['actuation_id'] is None,'preexisting')
results['preexisting']='PASS'
# 5/6 sample failures are observational only.
for label,fail in [('sample_pre_fail',{1}),('sample_post_fail',{2})]:
 r,_,_=run_pair(label,[{'op':'down'}],candidate_query_fail=fail); x=receipt(r[0])
 require(x['status']=='PRESS_UNCONFIRMED' and x['physical_down_interval'] is None and x['actuation_id'] is None,label)
 results[label]='PASS'
# 7 already-up ordinary no-op.
r,_,_=run_pair('noop_up',[{'op':'up'}]); x=receipt(r[0]); require(x['status']=='NOOP_ALREADY_UP' and x['physical_up_interval'] is None,'noop')
results['noop_up']='PASS'
# 8 foreign up rejects before sampling, same as v10.
r,_,_=run_pair('foreign',[{'op':'down','lease':'A','intent':'intent-A'},{'op':'up','lease':'B','intent':'intent-B'}]); require(not r[1]['candidate']['ok'] and 'key belongs to another intent' in r[1]['candidate']['error'],'foreign')
results['foreign']='PASS'
# 9 focus rejection; 10 lease; 11 cancel. No measurement receipt because no action admission.
for label,item in [('focus',{'op':'down','expected_focus':999}),('lease',{'op':'down','lease_ok':False}),('cancel',{'op':'down','cancel':True})]:
 r,_,_=run_pair(label,[item]); require(not r[0]['candidate']['ok'],label); results[label]='PASS'
# 12 input fail and 13 sync fail preserve v10 error/control trace.
for label,kw in [('inject_fail',{'inject_fail_at':{1}}),('sync_fail',{'sync_fail_at':{1}})]:
 r,_,_=run_pair(label,[{'op':'down'}],kw); require(not r[0]['candidate']['ok'],label); results[label]='PASS'
# 14 missing intent does not reject action and cannot produce parent-compatible interval/id.
r,_,_=run_pair('missing_intent',[{'op':'down','intent':None}]); x=receipt(r[0]); require(x['status']=='PRESS_UNCONFIRMED' and x['physical_down_interval'] is None and x['actuation_id'] is None,'missing intent')
results['missing_intent']='PASS'
# 15 verified aggregate cleanup closes generation bookkeeping without emitting an up bracket.
c10,c12=pair_cfg('cleanup')
o10,d10=make_owner('v10',c10); o12,d12=make_owner('v12',c12); l10=Lease(); l12=Lease()
try:
 a1=call_record(o10,'down',l10); b1=call_record(o12,'down',l12); id1=b1['result']['physical_edge_receipt']['actuation_id']
 rr10=call_record(o10,'release',l10,None); rr12=call_record(o12,'release',l12,None)
 a2=call_record(o10,'down',l10); b2=call_record(o12,'down',l12); id2=b2['result']['physical_edge_receipt']['actuation_id']
 require(a1['ok'] and b1['ok'] and rr10['ok'] and rr12['ok'] and a2['ok'] and b2['ok'],'cleanup calls')
 require(id1!=id2 and ':g1:' in id1 and ':g2:' in id2,'cleanup generation')
 require(rr10['result']['event']==rr12['result']['event']=='owner_release','cleanup receipt unchanged')
finally:
 close_quiet(o10); close_quiet(o12)
results['cleanup_generation']='PASS'

(OUT/'RESULT.json').write_text(json.dumps({'status':'PASS_EXCLUDED_CONSTRUCTION','controls':results,'passed':len(results)},sort_keys=True,indent=2)+'\n')
print(json.dumps({'status':'PASS_EXCLUDED_CONSTRUCTION','passed':len(results)},sort_keys=True))

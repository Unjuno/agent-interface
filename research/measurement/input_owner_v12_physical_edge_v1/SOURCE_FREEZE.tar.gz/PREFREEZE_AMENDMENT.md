# Prefreeze resource-envelope amendment

Excluded construction already passed 15/15 fixed controls. A setup-only timing probe of 100 matched fresh two-call v10/v12 owner lifetimes completed in 0.272403218 s on this container.

Before any primary corpus row is generated, freeze the primary at **10,000 fresh deterministic scenarios** rather than the initial draft 20,000. This changes no scientific mechanism, gate, scenario family, seed logic, or zero-mismatch criterion; it only keeps the single primary invocation inside a bounded outer execution envelope. No primary IDs/results existed when this amendment was made.

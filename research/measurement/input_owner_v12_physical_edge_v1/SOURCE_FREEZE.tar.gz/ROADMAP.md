# Roadmap

1. Exact source/dependency identity gate.
2. Mechanical v10 -> research-only v12 patch.
3. Actual v12 import under fake Xlib owner-thread harness.
4. Excluded fixed construction; repair setup/harness only.
5. Freeze source/tests/schedule/auditor before primary.
6. Mandatory GitHub ownership reread.
7. One 10,000-scenario offline primary invocation.
8. Independent audit, corruption controls, source rehash.
9. Retain first outcome to #998; publish additive research source only if integrity survives.
10. Stop before any X11/live task-input experiment.

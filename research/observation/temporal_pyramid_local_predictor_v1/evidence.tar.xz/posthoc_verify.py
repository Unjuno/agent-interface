from __future__ import annotations
import json,sys
from fixture import CADENCES,TRAJ,make_trace,latent_x
from sampler import sample_index,sample_age
from predictor import predict_linear
POL={'INDEX_LOG':sample_index,'TARGET_AGE_LOG':sample_age}
EXPECTED={(t,c,p) for t in TRAJ for c in CADENCES for p in POL}

def verify(path):
    errs=[]
    try: d=json.load(open(path))
    except Exception as e: return {'errors':[f'json:{type(e).__name__}']}
    rows=d.get('rows')
    if not isinstance(rows,list): return {'errors':['rows_type']}
    keys=[]
    for r in rows:
      try: keys.append((r['trajectory'],r['cadence'],r['policy']))
      except Exception: errs.append('key_shape'); continue
    if len(rows)!=48: errs.append(f'row_count:{len(rows)}')
    if len(set(keys))!=len(keys): errs.append('duplicate_key')
    if set(keys)!=EXPECTED: errs.append('key_set')
    for r in rows:
      try:
        k=(r['trajectory'],r['cadence'],r['policy'])
        if k not in EXPECTED: continue
        src=make_trace(k[1],k[0]); s=POL[k[2]](src); pred,fit=predict_linear(s,100.0); gt=latent_x(k[0],100.0)
        exp_err=abs(pred-gt)
        if r['selected_ids'] != [o.observation_id for o in s]: errs.append(f'ids:{k}')
        if abs(float(r['pred_x'])-pred)>1e-9: errs.append(f'pred:{k}')
        if abs(float(r['ground_truth_x'])-gt)>1e-9: errs.append(f'gt:{k}')
        if abs(float(r['abs_error_px'])-exp_err)>1e-9: errs.append(f'abs_error:{k}')
        if r['current_id']!=src[-1].observation_id: errs.append(f'current:{k}')
        ha=r['historical_authority']
        if len(ha)!=5 or any(ha): errs.append(f'historical_authority:{k}')
        if len(set(r['selected_ids']))!=6: errs.append(f'unique:{k}')
      except Exception as e: errs.append(f'row_exception:{type(e).__name__}')
    return {'errors':sorted(set(errs))}
if __name__=='__main__':
    o=verify(sys.argv[1]); print(json.dumps(o,indent=2,sort_keys=True)); raise SystemExit(1 if o['errors'] else 0)

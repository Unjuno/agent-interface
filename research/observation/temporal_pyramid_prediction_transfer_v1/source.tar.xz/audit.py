from __future__ import annotations
import json,pathlib,sys
VALID=('static_regular','constant_velocity_regular','constant_velocity_jitter','constant_accel_jitter','constant_accel_drop','smooth_turn_mixed','recent_accel_mixed','abrupt_reversal')
POL=('INDEX_LOG','TARGET_AGE_LOG')
BAD=('insufficient_history','non_monotonic_timestamp','duplicate_observation_id','bad_current_marker')
SMOOTH=('constant_accel_jitter','constant_accel_drop','smooth_turn_mixed','recent_accel_mixed')
CODE={'insufficient_history':'INSUFFICIENT_HISTORY','non_monotonic_timestamp':'NON_MONOTONIC_TIMESTAMP','duplicate_observation_id':'DUPLICATE_OBSERVATION_ID','bad_current_marker':'BAD_CURRENT_MARKER'}

def selected_errors(s,prefix=''):
    e=[]
    if not isinstance(s,list) or len(s)!=6: return [prefix+'selected-count']
    ids=[x.get('observation_id') for x in s]
    if len(set(ids))!=6:e.append(prefix+'selected-dup')
    ages=[float(x['age_ms']) for x in s]
    if abs(ages[0])>1e-9 or any(b<=a for a,b in zip(ages,ages[1:])):e.append(prefix+'age-order')
    if s[0].get('historical') or not s[0].get('grants_current_authority'):e.append(prefix+'current-role')
    if any((not x.get('historical')) or x.get('grants_current_authority') for x in s[1:]):e.append(prefix+'history-role')
    if any('image_sha256' not in x or 'source_surface' not in x or 'source_rect' not in x for x in s):e.append(prefix+'source-meta')
    return e

def audit(obj):
    errors=[]
    if obj.get('schema')!='temporal-pyramid-prediction-transfer-result-v2':errors.append('schema')
    if obj.get('formal_runner_invocations')!=1 or obj.get('formal_reruns')!=0:errors.append('formal-count')
    rows=obj.get('rows',[])
    if len(rows)!=24:errors.append('row-count')
    by={}
    for r in rows:
        k=(r.get('case'),r.get('policy'))
        if k in by:errors.append('duplicate-row:'+repr(k))
        by[k]=r
    for c in VALID:
        for p in POL:
            r=by.get((c,p))
            if not r:errors.append('missing:'+c+':'+p);continue
            if r.get('status')!='OK':errors.append('status:'+c+':'+p);continue
            errors+=selected_errors(r.get('selected'),c+':'+p+':')
            calc=abs(float(r['prediction_x'])-float(r['truth_future_x']))
            if abs(calc-float(r['abs_error_px']))>1e-9:errors.append('error-recompute:'+c+':'+p)
            if float(r.get('horizon_ms',-1))!=50.0:errors.append('horizon:'+c+':'+p)
    for c in BAD:
        for p in POL:
            r=by.get((c,p))
            if not r:errors.append('missing:'+c+':'+p);continue
            if r.get('status')!='REJECTED' or r.get('selected') is not None:errors.append('malformed-admitted:'+c+':'+p)
            if r.get('error')!=CODE[c]:errors.append('malformed-code:'+c+':'+p)
    def er(c,p):return float(by[(c,p)]['abs_error_px'])
    if abs(er('static_regular','INDEX_LOG')-er('static_regular','TARGET_AGE_LOG'))>1e-9:errors.append('static-not-equal')
    if abs(er('constant_velocity_regular','INDEX_LOG')-er('constant_velocity_regular','TARGET_AGE_LOG'))>1e-9:errors.append('cv-regular-not-equal')
    if max(er('constant_velocity_jitter','INDEX_LOG'),er('constant_velocity_jitter','TARGET_AGE_LOG'))>1e-8:errors.append('cv-jitter-not-exact')
    strict=0
    for c in SMOOTH:
        b=er(c,'INDEX_LOG'); a=er(c,'TARGET_AGE_LOG')
        if a>b+1e-9:errors.append('candidate-regression:'+c)
        if a+1e-9<b:strict+=1
    if strict<3:errors.append('strict-improvements:'+str(strict))
    if er('abrupt_reversal','TARGET_AGE_LOG')-er('abrupt_reversal','INDEX_LOG')>1.0+1e-9:errors.append('abrupt-penalty')
    fail=any(x.startswith(('candidate-regression','abrupt-penalty','history-role','current-role','source-meta')) for x in errors)
    decision='PASS_TEMPORAL_PREDICTION_TRANSFER_SCOPED' if not errors else ('FAIL_TEMPORAL_PREDICTION_TRANSFER' if fail else 'HOLD_NO_PREDICTION_TRANSFER')
    return {'schema':'temporal-pyramid-prediction-transfer-audit-v2','decision':decision,'errors':errors,'strict_improvements':strict}
if __name__=='__main__':
    o=json.loads(pathlib.Path(sys.argv[1]).read_text());a=audit(o);pathlib.Path(sys.argv[2]).write_text(json.dumps(a,indent=2,sort_keys=True)+'\n');print(json.dumps(a,sort_keys=True))

import copy, unittest
from audit import selected_errors

def toy():
    return [{'observation_id':f'x{i}','timestamp_ns':1_000_000_000-i*10_000_000,'x':float(i),'image_sha256':'a'*64,'source_surface':'toy','source_rect':[0,0,1,1],'image_bytes':10+i,'age_ms':i*10.0,'historical':i!=0,'grants_current_authority':i==0} for i in range(6)]
class A(unittest.TestCase):
    def test_good(self): self.assertEqual(selected_errors(toy()),[])
    def test_duplicate(self):
        s=toy();s[1]['observation_id']=s[0]['observation_id'];self.assertTrue(selected_errors(s))
    def test_role(self):
        s=toy();s[2]['grants_current_authority']=True;self.assertTrue(selected_errors(s))
    def test_age(self):
        s=toy();s[2]['age_ms']=5;self.assertTrue(selected_errors(s))
    def test_meta(self):
        s=toy();del s[1]['image_sha256'];self.assertTrue(selected_errors(s))
if __name__=='__main__':unittest.main()

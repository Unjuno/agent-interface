import hashlib, unittest
from sampler import sample_index_log,sample_target_age_log,SampleError
from predictor import predict_linear

def excluded_frames(jitter=False):
    t=0.0; times=[]
    for i in range(22):
        times.append(t); t+= (12.0 if jitter and i%2==0 else (21.0 if jitter else (1000.0/60.0)))
    out=[]
    for i,t in enumerate(times):
        oid=f'excluded-{i}'
        out.append({'observation_id':oid,'timestamp_ns':int(t*1e6),'x':10.0+0.2*t,'image_sha256':hashlib.sha256(oid.encode()).hexdigest(),
                    'source_surface':'excluded','source_rect':[0,0,10,10],'image_bytes':100+i,'current_marker':i==len(times)-1})
    return out
class C(unittest.TestCase):
    def test_regular_same(self):
        f=excluded_frames(False);self.assertEqual([x['observation_id'] for x in sample_index_log(f)],[x['observation_id'] for x in sample_target_age_log(f)])
    def test_linear_exact(self):
        f=excluded_frames(True)
        for fn in (sample_index_log,sample_target_age_log):self.assertAlmostEqual(predict_linear(fn(f)),10.0+0.2*(f[-1]['timestamp_ns']/1e6+50),places=8)
    def test_role(self):
        s=sample_target_age_log(excluded_frames(True));self.assertTrue(s[0]['grants_current_authority']);self.assertTrue(all(x['historical'] and not x['grants_current_authority'] for x in s[1:]))
    def test_bad_id(self):
        f=excluded_frames();f[2]['observation_id']=f[1]['observation_id'];self.assertRaises(SampleError,sample_index_log,f)
    def test_bad_ts(self):
        f=excluded_frames();f[2]['timestamp_ns']=f[1]['timestamp_ns'];self.assertRaises(SampleError,sample_target_age_log,f)
    def test_bad_current(self):
        f=excluded_frames();f[-1]['current_marker']=False;self.assertRaises(SampleError,sample_target_age_log,f)
if __name__=='__main__':unittest.main()

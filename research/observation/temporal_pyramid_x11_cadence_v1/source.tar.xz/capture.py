import hashlib, os, signal, subprocess, time
from Xlib import X, display

PERIOD_NS=16_666_667
CAPTURES=40
WARMUP_NS=100_000_000
ROI=(0,0,64,64)

def _wait_display(name, timeout=3.0):
    end=time.monotonic()+timeout
    last=None
    while time.monotonic()<end:
        try:
            d=display.Display(name); return d
        except Exception as e:
            last=e; time.sleep(0.01)
    raise RuntimeError(f'XVFB_NOT_READY:{last!r}')

def capture_block(display_num, block_id):
    name=f':{display_num}'
    xauth=f'/tmp/agent-interface-empty-xauth-{display_num}'
    open(xauth,'ab').close()
    old_xauth=os.environ.get('XAUTHORITY')
    os.environ['XAUTHORITY']=xauth
    proc=subprocess.Popen(['Xvfb',name,'-screen','0','128x128x24','-nolisten','tcp','-ac'], stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
    d=None
    try:
        d=_wait_display(name)
        root=d.screen().root
        time.sleep(WARMUP_NS/1e9)
        base=time.monotonic_ns()
        rows=[]
        for i in range(CAPTURES):
            scheduled=base+i*PERIOD_NS
            now=time.monotonic_ns()
            if now<scheduled: time.sleep((scheduled-now)/1e9)
            start=time.monotonic_ns()
            img=root.get_image(ROI[0],ROI[1],ROI[2],ROI[3],X.ZPixmap,0xffffffff)
            end=time.monotonic_ns()
            data=img.data.encode('latin1') if isinstance(img.data,str) else bytes(img.data)
            rows.append({
                'observation_id':f'{block_id}-obs-{i:02d}', 'timestamp_ns':end,
                'scheduled_ns':scheduled, 'capture_start_ns':start, 'capture_end_ns':end,
                'image_sha256':hashlib.sha256(data).hexdigest(),'image_bytes':len(data),
                'source_surface':f'xvfb-root-{display_num}','source_rect':list(ROI),
                'current': i==CAPTURES-1,
            })
        return rows
    finally:
        if d is not None:
            try:d.close()
            except Exception: pass
        proc.terminate()
        try: proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill(); proc.wait(timeout=2)
        if old_xauth is None: os.environ.pop('XAUTHORITY',None)
        else: os.environ['XAUTHORITY']=old_xauth
        try: os.unlink(xauth)
        except FileNotFoundError: pass
        if proc.poll() is None: raise RuntimeError('XVFB_NOT_REAPED')

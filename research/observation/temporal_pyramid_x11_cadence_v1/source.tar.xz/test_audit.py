import copy, unittest
from audit import audit
class T(unittest.TestCase):
 def base(self):
  fs=[]
  for i in range(40): fs.append({'observation_id':f'o{i}','timestamp_ns':i*16_666_667,'scheduled_ns':0,'capture_start_ns':0,'capture_end_ns':i*16_666_667,'image_sha256':str(i),'image_bytes':4,'source_surface':'x','source_rect':[0,0,1,1],'current':i==39})
  from analyze import analyze_block
  return {'planned_blocks':1,'blocks':[{'block_id':'b','frames':fs,'analysis':analyze_block(fs)}]}
 def test_good(self): self.assertEqual(audit(self.base())['errors'],[])
 def reject(self,mut):
  x=self.base(); mut(x); self.assertTrue(audit(x)['errors'])
 def test_source(self): self.reject(lambda x:x['blocks'][0]['analysis']['target_age'][1].__setitem__('image_sha256','bad'))
 def test_dup(self): self.reject(lambda x:x['blocks'][0]['analysis']['target_age'][1].__setitem__('observation_id',x['blocks'][0]['analysis']['target_age'][0]['observation_id']))
 def test_role(self): self.reject(lambda x:x['blocks'][0]['analysis']['target_age'][1].__setitem__('grants_current_authority',True))
 def test_regress(self): self.reject(lambda x:x['blocks'][0]['analysis'].__setitem__('target_age_error_ms',1.0))
if __name__=='__main__':unittest.main()

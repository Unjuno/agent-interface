import math, statistics
from sampler import sample_index_log,sample_target_age_log,age_error

def analyze_block(frames):
    idx=sample_index_log(frames); age=sample_target_age_log(frames)
    ints=[(b['timestamp_ns']-a['timestamp_ns'])/1e6 for a,b in zip(frames,frames[1:])]
    calls=[(f['capture_end_ns']-f['capture_start_ns'])/1e6 for f in frames]
    mean=statistics.mean(ints); sd=statistics.pstdev(ints)
    return {
      'index':idx,'target_age':age,'index_error_ms':age_error(idx),'target_age_error_ms':age_error(age),
      'strict_improvement':age_error(age) < age_error(idx)-1e-12,
      'interval_median_ms':statistics.median(ints),'interval_max_ms':max(ints),'interval_cv':(sd/mean if mean else 0.0),
      'capture_call_median_ms':statistics.median(calls),'capture_call_max_ms':max(calls),
    }

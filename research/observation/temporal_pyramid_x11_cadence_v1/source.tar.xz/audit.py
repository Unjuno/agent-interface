import json, statistics
from sampler import TARGET_AGES_MS

def audit(result):
    errors=[]
    blocks=result.get('blocks',[])
    if len(blocks)!=result.get('planned_blocks'): errors.append('block-count')
    ratios=[]; strict=0
    for b in blocks:
        fs=b['frames']; a=b['analysis']; bid=b['block_id']
        if len(fs)!=40: errors.append(f'{bid}:frame-count')
        if any(int(x['timestamp_ns'])>=int(y['timestamp_ns']) for x,y in zip(fs,fs[1:])): errors.append(f'{bid}:timestamps')
        if [i for i,f in enumerate(fs) if f.get('current')] != [39]: errors.append(f'{bid}:current-marker')
        src={f['observation_id']:f for f in fs}
        for policy in ('index','target_age'):
            s=a[policy]
            if len(s)!=6 or len({x['observation_id'] for x in s})!=6: errors.append(f'{bid}:{policy}:unique6')
            if s[0]['observation_id']!=fs[-1]['observation_id']: errors.append(f'{bid}:{policy}:newest')
            ages=[float(x['age_ms']) for x in s]
            if any(x>=y for x,y in zip(ages,ages[1:])): errors.append(f'{bid}:{policy}:age-order')
            for j,x in enumerate(s):
                o=src.get(x['observation_id'])
                if not o: errors.append(f'{bid}:{policy}:source-missing'); continue
                for k in ('timestamp_ns','image_sha256','image_bytes','source_surface'):
                    if x[k]!=o[k]: errors.append(f'{bid}:{policy}:source-{k}')
                if x['source_rect']!=o['source_rect']: errors.append(f'{bid}:{policy}:rect')
                if bool(x['historical']) != (j!=0): errors.append(f'{bid}:{policy}:historical')
                if bool(x['grants_current_authority']) != (j==0): errors.append(f'{bid}:{policy}:authority')
        ie=float(a['index_error_ms']); ce=float(a['target_age_error_ms'])
        if ce > ie + 1e-9: errors.append(f'{bid}:candidate-regression')
        if ce < ie-1e-12: strict+=1
        ratios.append(ce/ie if ie>1e-12 else 1.0)
    med=statistics.median(ratios) if ratios else None
    gates={
      'integrity':not errors,'candidate_nonworse_all':not any('candidate-regression' in e for e in errors),
      'strict_improvement_6':strict>=6,'median_ratio_090': med is not None and med<=0.90,
    }
    if errors: decision='FAIL_X11_TEMPORAL_SAMPLING'
    elif all(gates.values()): decision='PASS_X11_AGE_TARGETED_SAMPLING_SCOPED'
    else: decision='HOLD_REAL_CAPTURE_CADENCE_NO_GAIN'
    return {'decision':decision,'errors':errors,'gates':gates,'strict_blocks':strict,'median_ratio':med,'block_count':len(blocks)}

def main():
 import sys
 r=json.load(open(sys.argv[1])); o=audit(r); json.dump(o,open(sys.argv[2],'w'),indent=2,sort_keys=True); print(json.dumps(o,sort_keys=True))
if __name__=='__main__': main()

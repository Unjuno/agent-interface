import unittest
from sampler import *
class T(unittest.TestCase):
 def frames(self,n=40):
  return [{'observation_id':f'o{i}','timestamp_ns':i*16_666_667,'image_sha256':str(i),'image_bytes':4,'source_surface':'x','source_rect':[0,0,1,1],'current':i==n-1} for i in range(n)]
 def test_regular(self):
  f=self.frames(); a=sample_index_log(f); b=sample_target_age_log(f); self.assertEqual([x['observation_id'] for x in a],[x['observation_id'] for x in b])
 def test_unique(self): self.assertEqual(len({x['observation_id'] for x in sample_target_age_log(self.frames())}),6)
 def test_history(self):
  s=sample_target_age_log(self.frames()); self.assertTrue(s[0]['grants_current_authority']); self.assertTrue(all(not x['grants_current_authority'] for x in s[1:]))
 def test_insufficient(self):
  with self.assertRaisesRegex(SampleError,'INSUFFICIENT'): sample_index_log(self.frames(10))
 def test_duplicate(self):
  f=self.frames(); f[1]['observation_id']=f[0]['observation_id'];
  with self.assertRaisesRegex(SampleError,'DUPLICATE'): sample_target_age_log(f)
 def test_bad_time(self):
  f=self.frames(); f[2]['timestamp_ns']=f[1]['timestamp_ns'];
  with self.assertRaisesRegex(SampleError,'NON_MONOTONIC'): sample_target_age_log(f)
if __name__=='__main__': unittest.main()

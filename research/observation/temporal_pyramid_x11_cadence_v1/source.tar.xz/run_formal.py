import json, os
from capture import capture_block
from analyze import analyze_block
TASK='TEMPORAL-PYRAMID-X11-CAPTURE-CADENCE-20260917-001'
BLOCKS=12

def run():
    blocks=[]
    base_display=210
    for i in range(BLOCKS):
        frames=capture_block(base_display+i,f'block-{i:02d}')
        blocks.append({'block_id':f'block-{i:02d}','frames':frames,'analysis':analyze_block(frames)})
    return {'task':TASK,'planned_blocks':BLOCKS,'formal_runner_invocations':1,'formal_reruns':0,'blocks':blocks}
if __name__=='__main__':
 import sys
 out=run(); json.dump(out,open(sys.argv[1],'w'),indent=2,sort_keys=True); print(sys.argv[1])

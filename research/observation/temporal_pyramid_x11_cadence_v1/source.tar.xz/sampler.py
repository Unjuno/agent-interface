TARGET_AGES_MS = (0.0,16.666667,33.333333,66.666667,133.333333,266.666667)
INDEX_OFFSETS = (0,1,2,4,8,16)

class SampleError(ValueError): pass

def validate(frames):
    if len(frames) < 17: raise SampleError('INSUFFICIENT_HISTORY')
    ids=[f['observation_id'] for f in frames]
    if len(ids)!=len(set(ids)): raise SampleError('DUPLICATE_OBSERVATION_ID')
    ts=[int(f['timestamp_ns']) for f in frames]
    if any(a>=b for a,b in zip(ts,ts[1:])): raise SampleError('NON_MONOTONIC_TIMESTAMP')
    current=[i for i,f in enumerate(frames) if f.get('current')]
    if current != [len(frames)-1]: raise SampleError('BAD_CURRENT_MARKER')

def _project(frames, selected):
    newest_ns=int(frames[-1]['timestamp_ns'])
    out=[]
    for i,f in enumerate(selected):
        age_ms=(newest_ns-int(f['timestamp_ns']))/1e6
        out.append({
            'observation_id':f['observation_id'], 'timestamp_ns':int(f['timestamp_ns']),
            'age_ms':age_ms, 'image_sha256':f['image_sha256'], 'image_bytes':int(f['image_bytes']),
            'source_surface':f['source_surface'], 'source_rect':list(f['source_rect']),
            'historical': i!=0, 'grants_current_authority': i==0,
        })
    return out

def sample_index_log(frames):
    validate(frames)
    selected=[frames[-1-off] for off in INDEX_OFFSETS]
    return _project(frames,selected)

def sample_target_age_log(frames):
    validate(frames)
    newest=frames[-1]
    newest_ns=int(newest['timestamp_ns'])
    selected=[newest]; used={newest['observation_id']}
    for target in TARGET_AGES_MS[1:]:
        candidates=[]
        for f in frames[:-1]:
            if f['observation_id'] in used: continue
            age=(newest_ns-int(f['timestamp_ns']))/1e6
            candidates.append((abs(age-target), age, f)) # smaller age wins exact tie => newer
        if not candidates: raise SampleError('INSUFFICIENT_HISTORY')
        _,_,best=min(candidates,key=lambda z:(z[0],z[1],z[2]['observation_id']))
        selected.append(best); used.add(best['observation_id'])
    return _project(frames,selected)

def age_error(sample):
    return sum(abs(float(s['age_ms'])-target) for s,target in zip(sample,TARGET_AGES_MS))

from __future__ import annotations
import hashlib
TASK='TEMPORAL-SOURCE-TIMESTAMP-BINDING-20260917-001'
CURRENT_MS=1000.0
N_SCHEDULES=6

def _u(label):
    h=hashlib.sha256((TASK+'|'+label).encode()).digest()
    return int.from_bytes(h[:8],'big')/(2**64-1)

def formal_params(i):
    # Called only by formal runner after source-first freeze.
    return {
      'velocity':0.11+0.09*_u(f'v:{i}'),
      'short_ms':5.0+4.0*_u(f's:{i}')+0.00000037,
      'long_ms':24.0+7.0*_u(f'l:{i}')+0.00000061,
      'third_ms':14.0+5.0*_u(f't:{i}')+0.00000023,
    }

def _times(params,n=30):
    t=CURRENT_MS; out=[t]
    for j in range(n):
        dt=(params['short_ms'],params['long_ms'],params['third_ms'])[j%3]
        t-=dt; out.append(t)
    return sorted(out)

def make_frames(schedule_index,binding):
    p=formal_params(schedule_index); times=_times(p); current_ns=int(round(CURRENT_MS*1e6)); out=[]
    for i,t in enumerate(times):
        ns=int(round(t*1e6)); rel_pre=t-CURRENT_MS; rel_bound=(ns-current_ns)/1e6
        rel=rel_pre if binding=='PRE_ROUND_STATE' else rel_bound
        oid=f'{TASK}:s{schedule_index}:obs:{i:02d}'
        out.append({'observation_id':oid,'timestamp_ns':ns,'x':180.0+p['velocity']*rel,
                    'image_sha256':hashlib.sha256((oid+'|img').encode()).hexdigest(),
                    'source_surface':'synthetic:timestamp-binding-v1','source_rect':[0,0,640,480],
                    'image_bytes':4096+i,'current_marker':i==len(times)-1})
    return out

def truth(schedule_index,horizon_ms=50.0):
    p=formal_params(schedule_index); return 180.0+p['velocity']*horizon_ms

import unittest
from sampler import sample_index_log,sample_target_age_log
from predictor import predict_linear
class T(unittest.TestCase):
 def frames(self,bound):
  # Excluded hand-authored arithmetic pattern; never imports cases/formal generator.
  current_ms=400.12345671; current_ns=int(round(current_ms*1e6)); v=.17
  intervals=[7.12345637,24.98765461,14.11111123]
  times=[current_ms]; t=current_ms
  for i in range(22): t-=intervals[i%3]; times.append(t)
  times=sorted(times); out=[]
  for i,t in enumerate(times):
   ns=int(round(t*1e6)); rel=(ns-current_ns)/1e6 if bound else t-current_ms
   out.append({'observation_id':f'x{i:02d}','timestamp_ns':ns,'x':10+v*rel,'image_sha256':str(i),'source_surface':'x','source_rect':[0,0,1,1],'image_bytes':1,'current_marker':i==len(times)-1})
  return out
 def test_bound_linear_exact(self):
  s=sample_index_log(self.frames(True)); self.assertLess(abs(predict_linear(s)-(10+.17*50)),1e-10)
 def test_same_timestamps(self): self.assertEqual([x['timestamp_ns'] for x in self.frames(True)],[x['timestamp_ns'] for x in self.frames(False)])
 def test_sampling_ids_same(self):
  for fn in (sample_index_log,sample_target_age_log):
   a=fn(self.frames(True)); b=fn(self.frames(False)); self.assertEqual([x['observation_id'] for x in a],[x['observation_id'] for x in b])
 def test_historical_roles(self):
  for fn in (sample_index_log,sample_target_age_log):
   a=fn(self.frames(True)); self.assertFalse(a[0]['historical']); self.assertTrue(a[0]['grants_current_authority']); self.assertTrue(all(x['historical'] and not x['grants_current_authority'] for x in a[1:]))
 def test_no_formal_import(self):
  import sys; self.assertNotIn('cases',sys.modules); self.assertNotIn('run_formal',sys.modules)
if __name__=='__main__': unittest.main()

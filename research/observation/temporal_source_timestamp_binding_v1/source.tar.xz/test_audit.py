import unittest
from audit import audit
class T(unittest.TestCase):
 def good(self):
  rows=[]
  for s in range(6):
   for p in ('INDEX_LOG','TARGET_AGE_LOG'):
    ids=[f'{s}-{i}' for i in range(6)]; ts=list(range(6))
    rows += [{'schedule':s,'policy':p,'binding':'PRE_ROUND_STATE','abs_error_px':2e-8,'selected_ids':list(ids),'selected_timestamp_ns':list(ts)},
             {'schedule':s,'policy':p,'binding':'BOUND_STORED_NS','abs_error_px':1e-13,'selected_ids':list(ids),'selected_timestamp_ns':list(ts)}]
  return {'formal_rows':24,'rows':rows}
 def test_good(self): self.assertEqual(audit(self.good())['decision'],'PASS_SOURCE_TIMESTAMP_BINDING_SCOPED')
 def test_id_corrupt(self):
  d=self.good(); d['rows'][1]['selected_ids'][0]='bad'; self.assertNotEqual(audit(d)['decision'],'PASS_SOURCE_TIMESTAMP_BINDING_SCOPED')
 def test_bound_error(self):
  d=self.good(); d['rows'][1]['abs_error_px']=1e-5; self.assertNotEqual(audit(d)['decision'],'PASS_SOURCE_TIMESTAMP_BINDING_SCOPED')
 def test_weak_baseline(self):
  d=self.good();
  for r in d['rows']:
   if r['binding']=='PRE_ROUND_STATE': r['abs_error_px']=1e-12
  self.assertEqual(audit(d)['decision'],'HOLD_NO_BINDING_DISCRIMINATOR')
 def test_no_formal_import(self):
  import sys; self.assertNotIn('cases',sys.modules); self.assertNotIn('run_formal',sys.modules)
if __name__=='__main__': unittest.main()

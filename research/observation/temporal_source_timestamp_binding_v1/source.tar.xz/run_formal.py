import json,sys,hashlib
from cases import N_SCHEDULES,make_frames,truth,TASK
from sampler import sample_index_log,sample_target_age_log
from predictor import predict_linear
POLICIES=('INDEX_LOG','TARGET_AGE_LOG'); BINDINGS=('PRE_ROUND_STATE','BOUND_STORED_NS')

def run():
    rows=[]
    for s in range(N_SCHEDULES):
      for policy in POLICIES:
       for binding in BINDINGS:
        frames=make_frames(s,binding); selected=(sample_index_log(frames) if policy=='INDEX_LOG' else sample_target_age_log(frames))
        pred=predict_linear(selected); err=abs(pred-truth(s))
        rows.append({'schedule':s,'policy':policy,'binding':binding,'prediction':pred,'abs_error_px':err,
                     'selected_ids':[x['observation_id'] for x in selected],
                     'selected_timestamp_ns':[x['timestamp_ns'] for x in selected]})
    return {'schema':'temporal-source-timestamp-binding-result-v1','task':TASK,'formal_rows':len(rows),'formal_reruns':0,'rows':rows}
if __name__=='__main__':
    out=run(); data=(json.dumps(out,sort_keys=True,indent=2)+'\n').encode(); open(sys.argv[1],'wb').write(data); print(hashlib.sha256(data).hexdigest())

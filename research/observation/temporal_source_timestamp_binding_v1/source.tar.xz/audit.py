import json,sys

def audit(d):
    errs=[]; rows=d.get('rows',[])
    if d.get('formal_rows')!=24 or len(rows)!=24: errs.append('row-count')
    by={(r.get('schedule'),r.get('policy'),r.get('binding')):r for r in rows}
    pre_over=0
    for s in range(6):
      for p in ('INDEX_LOG','TARGET_AGE_LOG'):
        a=by.get((s,p,'PRE_ROUND_STATE')); b=by.get((s,p,'BOUND_STORED_NS'))
        if not a or not b: errs.append(f'missing:{s}:{p}'); continue
        if a.get('selected_ids')!=b.get('selected_ids'): errs.append(f'id-mismatch:{s}:{p}')
        if a.get('selected_timestamp_ns')!=b.get('selected_timestamp_ns'): errs.append(f'time-mismatch:{s}:{p}')
        ae=float(a['abs_error_px']); be=float(b['abs_error_px'])
        if be>1e-10: errs.append(f'bound-not-exact:{s}:{p}:{be}')
        if be>ae+1e-14: errs.append(f'bound-regression:{s}:{p}:{ae}:{be}')
        if ae>1e-8: pre_over+=1
    if pre_over<4: errs.append(f'weak-negative-control:{pre_over}')
    decision='PASS_SOURCE_TIMESTAMP_BINDING_SCOPED' if not errs else ('HOLD_NO_BINDING_DISCRIMINATOR' if errs and all(e.startswith('weak-negative-control') for e in errs) else 'FAIL_TIMESTAMP_BINDING_REPAIR')
    return {'decision':decision,'errors':errs,'pre_round_over_1e8_rows':pre_over,'rows':len(rows)}
if __name__=='__main__':
    d=json.load(open(sys.argv[1])); out=audit(d); json.dump(out,open(sys.argv[2],'w'),sort_keys=True,indent=2); open(sys.argv[2],'a').write('\n'); print(out)

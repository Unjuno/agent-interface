#!/usr/bin/env python3
import argparse,json,subprocess,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--schedule',required=True);ap.add_argument('--root',required=True);a=ap.parse_args()
sched=json.loads(Path(a.schedule).read_text());root=Path(a.root)
if root.exists():raise SystemExit('refuse existing formal root')
root.mkdir(parents=True)
logs=[]
for row in sched['cases']:
    case=root/row['case_id']
    cmd=[sys.executable,str(HERE/'run_case.py'),'--out',str(case),'--display',str(row['display']),'--modality',row['modality'],'--scenario',row['scenario'],'--case-id',row['case_id']]
    cp=subprocess.run(cmd,text=True,capture_output=True)
    (root/(row['case_id']+'.stdout')).write_text(cp.stdout)
    (root/(row['case_id']+'.stderr')).write_text(cp.stderr)
    logs.append({'case_id':row['case_id'],'returncode':cp.returncode})
(root/'runner.json').write_text(json.dumps({'task':sched['task'],'cases':logs},indent=2,sort_keys=True)+'\n')
print(json.dumps({'cases':len(logs),'zero_exit':sum(x['returncode']==0 for x in logs)},sort_keys=True))

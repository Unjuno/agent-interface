#!/usr/bin/env python3
import argparse,json,statistics
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--out',required=True);a=ap.parse_args();root=Path(a.root);rows=[];errs=[]
for p in sorted(root.glob('case-*/result.json')):
    r=json.loads(p.read_text());rows.append(r)
    if not r.get('pass'):errs.append(r['case_id']+':case_pass')
    exp=0 if r['scenario']=='wrong_resource' else 1
    if r['relevant_press_count']!=exp:errs.append(r['case_id']+':press')
    if r['relevant_release_count']!=exp:errs.append(r['case_id']+':release')
    if not r['neutral']['neutral']:errs.append(r['case_id']+':neutral')
    if r['scenario']=='wrong_resource' and r['first_task']!={'accepted':False,'reason':'OUT_OF_SUBSET'}:errs.append(r['case_id']+':subset')
    if r['scenario']=='stale_continue' and r['late_task']!={'accepted':False,'reason':'EXPIRED'}:errs.append(r['case_id']+':stale_continue')
mods={m:[r for r in rows if r['modality']==m] for m in ['keyboard','pointer']}
scens=['complete','deadline','cancel','stale_continue','wrong_resource']
for m in mods:
    for s in scens:
        n=sum(1 for r in mods[m] if r['scenario']==s)
        if n!=4:errs.append(f'{m}:{s}:n={n}')
release_lat={}
for m in mods:
    vals=[]
    for r in mods[m]:
        if r['scenario'] in {'deadline','cancel','complete'} and r['app_release_ns'] is not None:
            vals.append((r['app_release_ns']-r['trigger_ns'])/1e6)
    release_lat[m]={'n':len(vals),'median_ms':statistics.median(vals) if vals else None,'max_ms':max(vals) if vals else None}
dec='PASS_COMMON_LIFECYCLE_KEYBOARD_POINTER_SCOPED' if not errs and len(rows)==40 else 'FAIL_COMMON_LIFECYCLE'
out={'schema':'virtual-device-common-lifecycle-audit-v1','decision':dec,'errors':errs,'cases':len(rows),'pass_cases':sum(bool(r.get('pass')) for r in rows),'by_modality':{m:len(v) for m,v in mods.items()},'release_latency_descriptive':release_lat}
Path(a.out).write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps(out,sort_keys=True));raise SystemExit(0 if not errs and len(rows)==40 else 1)

#!/usr/bin/env python3
import argparse,json,time,tkinter as tk
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--log',required=True);ap.add_argument('--ready',required=True);ap.add_argument('--title',required=True);a=ap.parse_args()
log=Path(a.log); ready=Path(a.ready)
root=tk.Tk();root.title(a.title);root.geometry('320x200+100+100');root.configure(bg='white')
lab=tk.Label(root,text='virtual-device lifecycle fixture',bg='white');lab.pack(expand=True,fill='both')
def emit(kind,detail):
    with log.open('a') as f:f.write(json.dumps({'t_ns':time.monotonic_ns(),'kind':kind,'detail':detail},sort_keys=True)+'\n')
root.bind_all('<KeyPress>',lambda e:emit('key_press',{'keysym':e.keysym,'keycode':e.keycode}))
root.bind_all('<KeyRelease>',lambda e:emit('key_release',{'keysym':e.keysym,'keycode':e.keycode}))
root.bind_all('<ButtonPress>',lambda e:emit('button_press',{'button':e.num,'x_root':e.x_root,'y_root':e.y_root}))
root.bind_all('<ButtonRelease>',lambda e:emit('button_release',{'button':e.num,'x_root':e.x_root,'y_root':e.y_root}))
def mark_ready():
    root.update_idletasks();root.focus_force();ready.write_text(json.dumps({'ready':True,'t_ns':time.monotonic_ns()})+'\n')
root.after(250,mark_ready)
root.mainloop()

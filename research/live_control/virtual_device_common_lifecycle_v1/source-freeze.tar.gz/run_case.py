#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json,os,signal,subprocess,time
from pathlib import Path
from Xlib import X,XK,display as xdisplay
from Xlib.ext import xtest
HERE=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def sleep_until(ns):
    while True:
        left=ns-time.monotonic_ns()
        if left<=0:return
        time.sleep(min(left/1e9,0.002))
def wait_path(p,timeout=5):
    end=time.monotonic()+timeout
    while time.monotonic()<end:
        if Path(p).exists():return True
        time.sleep(.01)
    return False

def find_window(d,title):
    root=d.screen().root
    stack=[root]
    while stack:
        w=stack.pop()
        try:
            name=w.get_wm_name()
            if name==title:return w
            stack.extend(w.query_tree().children)
        except Exception:pass
    return None

class Adapter:
    def __init__(self,modality,display_name):
        self.modality=modality;self.d=xdisplay.Display(display_name);self.held=False
        self.keycode=self.d.keysym_to_keycode(XK.string_to_keysym('a')) if modality=='keyboard' else None
    def lower(self,op,target):
        t=time.monotonic_ns()
        if self.modality=='keyboard':
            if target!='key:a':raise ValueError('wrong_target')
            xtest.fake_input(self.d,X.KeyPress if op=='down' else X.KeyRelease,self.keycode)
        else:
            if target!='button:1':raise ValueError('wrong_target')
            xtest.fake_input(self.d,X.ButtonPress if op=='down' else X.ButtonRelease,1)
        self.d.sync();self.held=(op=='down');return t
    def release_all(self):
        t=time.monotonic_ns()
        if self.held:
            if self.modality=='keyboard':xtest.fake_input(self.d,X.KeyRelease,self.keycode)
            else:xtest.fake_input(self.d,X.ButtonRelease,1)
            self.d.sync();self.held=False
        return t
    def neutral(self):
        if self.modality=='keyboard':
            km=bytes(self.d.query_keymap());return {'neutral':all(x==0 for x in km),'keymap_hex':km.hex()}
        q=self.d.screen().root.query_pointer();mask=int(q.mask);return {'neutral':(mask & int(X.Button1Mask))==0,'pointer_mask':mask}
    def close(self):self.d.close()

class AuthorityEnvelope:
    def __init__(self,adapter,target,deadline_ns):
        self.adapter=adapter;self.target=target;self.deadline_ns=deadline_ns;self.cancelled=False;self.events=[]
    def _record(self,kind,**kw):self.events.append({'t_ns':time.monotonic_ns(),'kind':kind,**kw})
    def task(self,op,target=None):
        target=self.target if target is None else target;now=time.monotonic_ns()
        if self.cancelled:
            self._record('reject',reason='CANCELLED',op=op,target=target);return {'accepted':False,'reason':'CANCELLED'}
        if now>=self.deadline_ns:
            self.adapter.release_all();self._record('reject',reason='EXPIRED',op=op,target=target);return {'accepted':False,'reason':'EXPIRED'}
        if target!=self.target or op not in {'down','up'}:
            self._record('reject',reason='OUT_OF_SUBSET',op=op,target=target);return {'accepted':False,'reason':'OUT_OF_SUBSET'}
        t=self.adapter.lower(op,target);self._record('emit',op=op,target=target,emit_ns=t);return {'accepted':True}
    def deadline_release(self):
        sleep_until(self.deadline_ns);t=self.adapter.release_all();self._record('release_all',reason='EXPIRED',emit_ns=t);return t
    def cancel(self):
        self.cancelled=True;t=self.adapter.release_all();self._record('release_all',reason='CANCELLED',emit_ns=t);return t
    def complete(self):
        r=self.task('up');self._record('terminal',reason='COMPLETED');return r

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);ap.add_argument('--display',type=int,required=True);ap.add_argument('--modality',choices=['keyboard','pointer'],required=True);ap.add_argument('--scenario',choices=['complete','deadline','cancel','stale_continue','wrong_resource'],required=True);ap.add_argument('--case-id',required=True);a=ap.parse_args()
    out=Path(a.out);out.mkdir(parents=True,exist_ok=False);procs=[];auth=out/'Xauthority';auth.touch();display=f':{a.display}';env=os.environ.copy();env.update({'DISPLAY':display,'XAUTHORITY':str(auth)});os.environ['DISPLAY']=display;os.environ['XAUTHORITY']=str(auth);title=f'VDM-{a.case_id}'
    def spawn(name,args):
        fo=open(out/(name+'.out'),'wb');fe=open(out/(name+'.err'),'wb');p=subprocess.Popen(args,env=env,stdout=fo,stderr=fe,start_new_session=True);procs.append((p,fo,fe));return p
    try:
        xv=spawn('xvfb',['Xvfb',display,'-screen','0','640x400x24','-ac','-nolisten','tcp'])
        for _ in range(200):
            if Path(f'/tmp/.X11-unix/X{a.display}').exists():break
            time.sleep(.01)
        ready=out/'ready.json';app_log=out/'app.jsonl';app=spawn('fixture',[os.sys.executable,str(HERE/'fixture.py'),'--log',str(app_log),'--ready',str(ready),'--title',title])
        if not wait_path(ready,5):raise RuntimeError('fixture_not_ready')
        d=xdisplay.Display(display);w=None
        for _ in range(100):
            w=find_window(d,title)
            if w:break
            time.sleep(.01)
        if not w:raise RuntimeError('window_not_found')
        w.set_input_focus(X.RevertToParent,X.CurrentTime);xtest.fake_input(d,X.MotionNotify,x=220,y=190);d.sync();time.sleep(.08);d.close()
        adapter=Adapter(a.modality,display);target='key:a' if a.modality=='keyboard' else 'button:1';start=time.monotonic_ns();deadline=start+120_000_000;envlp=AuthorityEnvelope(adapter,target,deadline)
        trigger_ns=None;late=None;first=None
        if a.scenario=='wrong_resource':
            wrong='key:b' if a.modality=='keyboard' else 'button:3';first=envlp.task('down',wrong);trigger_ns=time.monotonic_ns()
        else:
            first=envlp.task('down');time.sleep(.04)
            if a.scenario=='complete':trigger_ns=time.monotonic_ns();envlp.complete()
            elif a.scenario=='cancel':trigger_ns=time.monotonic_ns();envlp.cancel()
            elif a.scenario in {'deadline','stale_continue'}:
                trigger_ns=deadline;envlp.deadline_release()
                if a.scenario=='stale_continue':time.sleep(.012);late=envlp.task('down')
        time.sleep(.08);neutral=adapter.neutral();verified_ns=time.monotonic_ns();adapter.close()
        lines=[]
        if app_log.exists():
            for ln in app_log.read_text().splitlines():
                if ln.strip():lines.append(json.loads(ln))
        if a.modality=='keyboard':rel=[e for e in lines if e['kind']=='key_release' and e['detail']['keysym'].lower()=='a'];prs=[e for e in lines if e['kind']=='key_press' and e['detail']['keysym'].lower()=='a']
        else:rel=[e for e in lines if e['kind']=='button_release' and e['detail']['button']==1];prs=[e for e in lines if e['kind']=='button_press' and e['detail']['button']==1]
        result={'schema':'virtual-device-common-lifecycle-case-v1','case_id':a.case_id,'modality':a.modality,'scenario':a.scenario,'start_ns':start,'deadline_ns':deadline,'trigger_ns':trigger_ns,'first_task':first,'late_task':late,'envelope_events':envlp.events,'app_events':lines,'relevant_press_count':len(prs),'relevant_release_count':len(rel),'app_release_ns':rel[-1]['t_ns'] if rel else None,'verified_ns':verified_ns,'neutral':neutral,'fixture_alive':app.poll() is None}
        expected_events=0 if a.scenario=='wrong_resource' else 1
        expected_first=(a.scenario!='wrong_resource')
        result['pass']=neutral['neutral'] and len(prs)==expected_events and len(rel)==expected_events and bool(first['accepted'])==expected_first and (a.scenario!='stale_continue' or (late=={'accepted':False,'reason':'EXPIRED'}))
        if a.scenario=='wrong_resource':result['pass']=result['pass'] and first=={'accepted':False,'reason':'OUT_OF_SUBSET'}
        (out/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps({'case_id':a.case_id,'pass':result['pass'],'press':len(prs),'release':len(rel),'neutral':neutral['neutral']},sort_keys=True))
    finally:
        for p,fo,fe in reversed(procs):
            try:
                if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)
            except Exception:pass
        time.sleep(.08)
        for p,fo,fe in reversed(procs):
            try:
                if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
            except Exception:pass
            try:fo.close();fe.close()
            except Exception:pass
if __name__=='__main__':main()

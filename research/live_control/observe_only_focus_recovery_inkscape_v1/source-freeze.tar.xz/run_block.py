import json, pathlib, subprocess, sys
root=pathlib.Path(sys.argv[1]); src=pathlib.Path(sys.argv[2]); schedule=json.loads((src/'schedule.json').read_text())
rows=[]
for c in schedule['cases']:
    out=root/c['case_id']
    cp=subprocess.run([sys.executable,str(src/'run_case.py'),str(out),c['policy'],str(c['display']),str(src/'test.svg')],capture_output=True,text=True,timeout=15)
    if cp.returncode!=0: raise RuntimeError(f"{c['case_id']} rc={cp.returncode} stderr={cp.stderr}")
    rows.append(json.loads((out/'case.json').read_text()))
agg={'task':'OBSERVE-ONLY-FOCUS-RECOVERY-INKSCAPE-TRANSFER-20260917-001','formal_invocations':1,'formal_reruns':0,'rows':rows}
(root/'aggregate.json').write_text(json.dumps(agg,sort_keys=True,indent=2)+'\n')
print(json.dumps({'rows':len(rows)},sort_keys=True))

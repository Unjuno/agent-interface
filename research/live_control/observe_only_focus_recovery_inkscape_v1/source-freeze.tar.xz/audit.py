import json, pathlib, sys
agg=json.loads(pathlib.Path(sys.argv[1]).read_text())
source_path=pathlib.Path(sys.argv[2])
errors=[]; counts={'REPLAY_REJECTED_CONTEXT':0,'FRESH_OBSERVE_ONLY':0}
text=source_path.read_text()
for forbidden in ('Xlib.ext.xtest','fake_input(','xdotool'):
    if forbidden in text: errors.append(['source_forbidden_input_api',forbidden])
for r in agg['rows']:
    cid=r['case_id']; p=r['policy']; counts[p]=counts.get(p,0)+1
    if r['source']['surface']!='INKSCAPE': errors.append([cid,'source_not_inkscape'])
    if r['admission']['surface']!='XTERM': errors.append([cid,'admission_not_xterm'])
    if r['rejection']!={'status':'rejected','reason':'focus_mismatch','expected_client_id':r['source']['client_id'],'current_client_id':r['admission']['client_id'],'task_input_admitted':False}: errors.append([cid,'bad_rejection'])
    if r['actual_before_recovery']['surface']!='XTERM' or r['actual_after_recovery']['surface']!='XTERM': errors.append([cid,'recovery_changed_focus'])
    rec=r['recovery']
    if rec['authority']!='none' or rec['task_input_granted'] or rec['action_admission_eligible']: errors.append([cid,'authority_escape'])
    if p=='REPLAY_REJECTED_CONTEXT' and rec['focus']['surface']!='INKSCAPE': errors.append([cid,'baseline_not_stale_A'])
    if p=='FRESH_OBSERVE_ONLY' and rec['focus']['surface']!='XTERM': errors.append([cid,'candidate_not_current_B'])
    if r['neutral_before']!={'keymap_nonzero':0,'button_mask':0} or r['neutral_after']!={'keymap_nonzero':0,'button_mask':0}: errors.append([cid,'input_not_neutral'])
    if r['task_input_api_calls']!=0 or r['setup_focus_commands']!=2: errors.append([cid,'input_or_setup_count'])
    if r['svg_sha_before']!=r['svg_sha_after']: errors.append([cid,'svg_changed'])
for p in counts:
    if counts[p]!=4: errors.append(['count',p,counts[p]])
decision='PASS_REALAPP_OBSERVE_ONLY_FOCUS_RECOVERY_SCOPED' if not errors else 'FAIL_INTEGRITY'
print(json.dumps({'decision':decision,'errors':errors,'counts':counts},sort_keys=True,indent=2))
sys.exit(0 if not errors else 1)

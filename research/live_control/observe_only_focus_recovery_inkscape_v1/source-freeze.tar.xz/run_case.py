import hashlib, json, os, subprocess, sys, time
from pathlib import Path
from Xlib import X, display

case = Path(sys.argv[1])
policy = sys.argv[2]
disp = int(sys.argv[3])
svg_source = Path(sys.argv[4])
case.mkdir(parents=True, exist_ok=False)
auth = case / 'Xauthority'; auth.write_bytes(b'')
env = dict(os.environ)
env['DISPLAY'] = f':{disp}'
env['XAUTHORITY'] = str(auth)
os.environ['DISPLAY'] = env['DISPLAY']; os.environ['XAUTHORITY'] = env['XAUTHORITY']
svg = case / 'fixture.svg'; svg.write_bytes(svg_source.read_bytes())
svg_sha_before = hashlib.sha256(svg.read_bytes()).hexdigest()
procs=[]; d=None

def get_text_prop(d, w, name):
    try:
        p=w.get_full_property(d.intern_atom(name), X.AnyPropertyType)
        if not p: return None
        v=p.value
        if isinstance(v, bytes): return v.decode(errors='ignore')
        try: return bytes(v).decode(errors='ignore')
        except Exception: return str(v)
    except Exception:
        return None

def walk(w):
    out=[w]
    try: children=w.query_tree().children
    except Exception: children=[]
    for c in children: out.extend(walk(c))
    return out

def ancestry(d, w):
    rows=[]; cur=w
    for _ in range(32):
        if cur is None: break
        rows.append({'id':cur.id,'wm_class':get_text_prop(d,cur,'WM_CLASS'),'wm_name':get_text_prop(d,cur,'WM_NAME')})
        try:
            par=cur.query_tree().parent
            if not par or par.id==cur.id: break
            cur=par
        except Exception: break
    return rows

def recognize(chain):
    text=' '.join(((r.get('wm_class') or '')+' '+(r.get('wm_name') or '')).lower() for r in chain)
    if 'inkscape' in text: return 'INKSCAPE'
    if 'recovery-b' in text or 'xterm' in text: return 'XTERM'
    return 'OTHER'

def geometry(w):
    try:
        g=w.get_geometry(); t=w.translate_coords(d.screen().root,0,0)
        return [int(t.x),int(t.y),int(g.width),int(g.height)]
    except Exception: return None

def resolve_current():
    f=d.get_input_focus().focus
    if not hasattr(f,'id'): return {'focus_id':None,'client_id':None,'surface':'OTHER','geometry':None,'chain':[]}
    chain=ancestry(d,f); surface=recognize(chain)
    client_id=None; client_geom=None
    for r in chain:
        txt=((r.get('wm_class') or '')+' '+(r.get('wm_name') or '')).lower()
        if (surface=='INKSCAPE' and 'inkscape' in txt) or (surface=='XTERM' and ('recovery-b' in txt or 'xterm' in txt)):
            client_id=r['id']; client_geom=geometry(d.create_resource_object('window',client_id)); break
    return {'focus_id':f.id,'client_id':client_id,'surface':surface,'geometry':client_geom,'chain':chain[:10]}

def find_clients():
    inks=[]; terms=[]
    for w in walk(d.screen().root):
        cls=(get_text_prop(d,w,'WM_CLASS') or '').lower(); name=(get_text_prop(d,w,'WM_NAME') or '').lower()
        if 'inkscape' in cls: inks.append(w)
        if 'xterm' in cls: terms.append(w)
    return inks,terms

def button_mask(mask):
    bits=[X.Button1Mask,X.Button2Mask,X.Button3Mask,X.Button4Mask,X.Button5Mask]
    return int(mask & sum(bits))

def neutral_snapshot():
    qp=d.screen().root.query_pointer()
    return {'keymap_nonzero':sum(1 for x in d.query_keymap() if x), 'button_mask':button_mask(qp.mask)}

def activate(w):
    # Setup-only EWMH focus transition. Recovery never calls this helper.
    subprocess.run(['wmctrl','-ia',hex(w.id)],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=False)
    time.sleep(.12)

try:
    procs.append(subprocess.Popen(['Xvfb',f':{disp}','-ac','-screen','0','900x600x24','-nolisten','tcp'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL))
    time.sleep(.18)
    procs.append(subprocess.Popen(['openbox'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL))
    time.sleep(.18)
    procs.append(subprocess.Popen(['inkscape',str(svg)],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL))
    procs.append(subprocess.Popen(['xterm','-T','Recovery-B'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL))
    d=display.Display(f':{disp}')
    deadline=time.time()+8; iw=xw=None
    while time.time()<deadline:
        inks,terms=find_clients()
        if inks and terms: iw,xw=inks[0],terms[0]; break
        time.sleep(.04)
    if iw is None or xw is None: raise RuntimeError('client discovery timeout')
    activate(iw); source=resolve_current()
    if source['surface']!='INKSCAPE': raise RuntimeError(f'failed to focus Inkscape: {source}')
    source_receipt={'observation_id':f'src-{case.name}','focus':source,'authority':'none'}
    activate(xw); admission=resolve_current()
    if admission['surface']!='XTERM': raise RuntimeError(f'failed to focus XTerm: {admission}')
    rejected = source['client_id'] != admission['client_id']
    if not rejected: raise RuntimeError('focus mismatch not exposed')
    rejection={'status':'rejected','reason':'focus_mismatch','expected_client_id':source['client_id'],'current_client_id':admission['client_id'],'task_input_admitted':False}
    before_actual=resolve_current(); before_neutral=neutral_snapshot()
    started=time.perf_counter_ns()
    if policy=='REPLAY_REJECTED_CONTEXT': recovered=dict(source)
    elif policy=='FRESH_OBSERVE_ONLY': recovered=resolve_current()
    else: raise ValueError(policy)
    done=time.perf_counter_ns()
    after_actual=resolve_current(); after_neutral=neutral_snapshot()
    recovery={'event':'observation_recovery','policy':policy,'source_observation_id':source_receipt['observation_id'],'focus':recovered,'authority':'none','task_input_granted':False,'action_admission_eligible':False,'started_ns':started,'completed_ns':done}
    svg_sha_after=hashlib.sha256(svg.read_bytes()).hexdigest()
    result={'case_id':case.name,'policy':policy,'source':source,'admission':admission,'rejection':rejection,'actual_before_recovery':before_actual,'recovery':recovery,'actual_after_recovery':after_actual,'neutral_before':before_neutral,'neutral_after':after_neutral,'setup_focus_commands':2,'task_input_api_calls':0,'svg_sha_before':svg_sha_before,'svg_sha_after':svg_sha_after,'inkscape_pid':procs[-2].pid,'xterm_pid':procs[-1].pid}
    (case/'case.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps(result,sort_keys=True))
finally:
    if d is not None:
        try:d.close()
        except Exception:pass
    for p in reversed(procs):
        if p.poll() is None:p.terminate()
    for p in reversed(procs):
        try:p.wait(timeout=2)
        except Exception:
            try:p.kill(); p.wait(timeout=1)
            except Exception:pass

import json,sys,pathlib,collections
agg=json.loads(pathlib.Path(sys.argv[1]).read_text()); errs=[]; counts=collections.Counter()
rows=agg.get('rows',[])
if len(rows)!=8:errs.append(['row_count',len(rows)])
for r in rows:
    cid=r['case_id']; pol=r['policy']; counts[pol]+=1; s=r['source']; a=r['admission']; rec=r['recovery']['focus']; before=r['actual_before_recovery']; after=r['actual_after_recovery']
    if s.get('app')!='INKSCAPE' or s.get('surface_kind')!='INKSCAPE_MAIN' or s.get('transient_for') is not None:errs.append([cid,'source'])
    if a.get('app')!='INKSCAPE' or a.get('surface_kind')!='INKSCAPE_TRANSIENT' or a.get('client_id')==s.get('client_id') or a.get('transient_for')!=s.get('client_id'):errs.append([cid,'modal'])
    if r['rejection']!={'status':'rejected','reason':'focus_surface_mismatch','expected_client_id':s['client_id'],'current_client_id':a['client_id'],'task_input_admitted':False}:errs.append([cid,'rejection'])
    if before.get('client_id')!=a.get('client_id') or after.get('client_id')!=a.get('client_id'):errs.append([cid,'focus_changed'])
    if pol=='REPLAY_REJECTED_CONTEXT':
        if rec.get('client_id')!=s.get('client_id') or rec.get('surface_kind')!='INKSCAPE_MAIN':errs.append([cid,'replay_not_stale'])
    elif pol=='FRESH_OBSERVE_ONLY':
        if rec.get('client_id')!=a.get('client_id') or rec.get('surface_kind')!='INKSCAPE_TRANSIENT' or rec.get('transient_for')!=s.get('client_id'):errs.append([cid,'fresh_not_modal'])
    else:errs.append([cid,'policy'])
    rr=r['recovery']
    if rr.get('authority')!='none' or rr.get('task_input_granted') is not False or rr.get('action_admission_eligible') is not False:errs.append([cid,'authority'])
    if r.get('task_recovery_input_api_calls')!=0:errs.append([cid,'task_input'])
    if not r.get('setup_input_fully_released') or len(r.get('setup_input_events',[]))!=6:errs.append([cid,'setup_input'])
    if r.get('neutral_before')!={'button_mask':0,'keymap_nonzero':0} or r.get('neutral_after')!={'button_mask':0,'keymap_nonzero':0}:errs.append([cid,'neutral'])
    if r.get('svg_sha_before')!=r.get('svg_sha_after'):errs.append([cid,'svg'])
if counts['REPLAY_REJECTED_CONTEXT']!=4 or counts['FRESH_OBSERVE_ONLY']!=4:errs.append(['counts',dict(counts)])
dec='PASS_SAMEAPP_MODAL_OBSERVE_ONLY_RECOVERY_SCOPED' if not errs else 'FAIL_INTEGRITY'
out={'decision':dec,'errors':errs,'counts':dict(counts)}; print(json.dumps(out,sort_keys=True)); sys.exit(0 if not errs else 1)

import hashlib, json, os, subprocess, sys, time
from pathlib import Path
from Xlib import X, XK, display
from Xlib.ext import xtest

case = Path(sys.argv[1]); policy=sys.argv[2]; disp=int(sys.argv[3]); svg_source=Path(sys.argv[4])
case.mkdir(parents=True, exist_ok=False)
auth=case/'Xauthority'; auth.write_bytes(b'')
env=dict(os.environ); env['DISPLAY']=f':{disp}'; env['XAUTHORITY']=str(auth)
os.environ['DISPLAY']=env['DISPLAY']; os.environ['XAUTHORITY']=env['XAUTHORITY']
svg=case/'fixture.svg'; svg.write_bytes(svg_source.read_bytes()); svg_before=hashlib.sha256(svg.read_bytes()).hexdigest()
procs=[]; d=None

def textprop(w,name):
    try:
        p=w.get_full_property(d.intern_atom(name),X.AnyPropertyType)
        if not p:return None
        v=p.value
        if isinstance(v,bytes): return v.decode(errors='ignore')
        try:return bytes(v).decode(errors='ignore')
        except:return str(v)
    except:return None

def transient_id(w):
    try:
        t=w.get_wm_transient_for(); return int(t.id) if t else None
    except:return None

def geometry(w):
    try:
        g=w.get_geometry(); t=w.translate_coords(d.screen().root,0,0)
        return [int(t.x),int(t.y),int(g.width),int(g.height)]
    except:return None

def ancestry(w):
    rows=[]; cur=w
    for _ in range(32):
        if not hasattr(cur,'id'):break
        rows.append({'id':int(cur.id),'wm_class':textprop(cur,'WM_CLASS'),'wm_name':textprop(cur,'WM_NAME'),'transient_for':transient_id(cur)})
        try:
            p=cur.query_tree().parent
            if not p or p.id==cur.id:break
            cur=p
        except:break
    return rows

def resolve_focus():
    f=d.get_input_focus().focus
    if not hasattr(f,'id'):return {'focus_id':None,'client_id':None,'app':'OTHER','surface_kind':'OTHER','wm_name':None,'wm_class':None,'transient_for':None,'geometry':None,'chain':[]}
    ch=ancestry(f); client=None
    for r in ch:
        if 'inkscape' in ((r.get('wm_class') or '')+' '+(r.get('wm_name') or '')).lower():
            client=r; break
    if client is None:
        return {'focus_id':int(f.id),'client_id':None,'app':'OTHER','surface_kind':'OTHER','wm_name':None,'wm_class':None,'transient_for':None,'geometry':None,'chain':ch[:10]}
    w=d.create_resource_object('window',client['id']); tr=client.get('transient_for')
    return {'focus_id':int(f.id),'client_id':client['id'],'app':'INKSCAPE','surface_kind':'INKSCAPE_TRANSIENT' if tr else 'INKSCAPE_MAIN','wm_name':client.get('wm_name'),'wm_class':client.get('wm_class'),'transient_for':tr,'geometry':geometry(w),'chain':ch[:10]}

def net_clients():
    root=d.screen().root
    for atomname in ['_NET_CLIENT_LIST_STACKING','_NET_CLIENT_LIST']:
        try:
            p=root.get_full_property(d.intern_atom(atomname),X.AnyPropertyType)
            if p:
                return [d.create_resource_object('window',int(x)) for x in p.value]
        except:pass
    return []

def find_main():
    for w in net_clients():
        s=((textprop(w,'WM_CLASS') or '')+' '+(textprop(w,'WM_NAME') or '')).lower()
        if 'inkscape' in s and transient_id(w) is None and textprop(w,'WM_NAME'):
            return w
    return None

def activate(w):
    subprocess.run(['wmctrl','-ia',hex(w.id)],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=False); time.sleep(.15)

def setup_save_dialog():
    events=[]
    for nm,down in [('Control_L',1),('Shift_L',1),('s',1),('s',0),('Shift_L',0),('Control_L',0)]:
        kc=d.keysym_to_keycode(XK.string_to_keysym(nm));
        if not kc: raise RuntimeError('missing keycode '+nm)
        xtest.fake_input(d,X.KeyPress if down else X.KeyRelease,kc); d.sync(); events.append({'key':nm,'down':bool(down)})
    return events

def neutral():
    qp=d.screen().root.query_pointer(); buttons=int(qp.mask & (X.Button1Mask|X.Button2Mask|X.Button3Mask|X.Button4Mask|X.Button5Mask))
    return {'keymap_nonzero':sum(bin(int(x)).count('1') for x in d.query_keymap()),'button_mask':buttons}

try:
    procs.append(subprocess.Popen(['Xvfb',f':{disp}','-ac','-screen','0','800x600x24','-nolisten','tcp'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)); time.sleep(.2)
    procs.append(subprocess.Popen(['openbox','--sm-disable'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)); time.sleep(.2)
    procs.append(subprocess.Popen(['inkscape',str(svg)],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL))
    d=display.Display(f':{disp}')
    deadline=time.time()+8; main=None
    while time.time()<deadline:
        main=find_main()
        if main:break
        time.sleep(.04)
    if main is None:raise RuntimeError('main discovery timeout')
    activate(main); source=resolve_focus()
    if source['surface_kind']!='INKSCAPE_MAIN':raise RuntimeError('source not main '+repr(source))
    setup_events=setup_save_dialog()
    deadline=time.time()+5; current=None
    while time.time()<deadline:
        current=resolve_focus()
        if current['surface_kind']=='INKSCAPE_TRANSIENT' and current['client_id']!=source['client_id'] and current['transient_for']==source['client_id']:break
        time.sleep(.04)
    if not current or current['surface_kind']!='INKSCAPE_TRANSIENT' or current['transient_for']!=source['client_id']:
        raise RuntimeError('modal discriminator missing '+repr(current))
    after_setup_neutral=neutral()
    if after_setup_neutral != {'keymap_nonzero':0,'button_mask':0}:raise RuntimeError('setup input not neutral '+repr(after_setup_neutral))
    rejection={'status':'rejected','reason':'focus_surface_mismatch','expected_client_id':source['client_id'],'current_client_id':current['client_id'],'task_input_admitted':False}
    before=resolve_focus(); neutral_before=neutral(); started=time.perf_counter_ns()
    if policy=='REPLAY_REJECTED_CONTEXT': recovered=dict(source)
    elif policy=='FRESH_OBSERVE_ONLY': recovered=resolve_focus()
    else:raise ValueError(policy)
    completed=time.perf_counter_ns(); after=resolve_focus(); neutral_after=neutral()
    recovery={'event':'observation_recovery','policy':policy,'focus':recovered,'authority':'none','task_input_granted':False,'action_admission_eligible':False,'started_ns':started,'completed_ns':completed}
    result={'case_id':case.name,'policy':policy,'source':source,'admission':current,'rejection':rejection,'setup_input_events':setup_events,'setup_input_fully_released':after_setup_neutral=={'keymap_nonzero':0,'button_mask':0},'actual_before_recovery':before,'recovery':recovery,'actual_after_recovery':after,'neutral_before':neutral_before,'neutral_after':neutral_after,'task_recovery_input_api_calls':0,'svg_sha_before':svg_before,'svg_sha_after':hashlib.sha256(svg.read_bytes()).hexdigest(),'inkscape_pid':procs[-1].pid}
    (case/'case.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n'); print(json.dumps(result,sort_keys=True))
finally:
    if d:
        try:d.close()
        except:pass
    for p in reversed(procs):
        if p.poll() is None:p.terminate()
    for p in reversed(procs):
        try:p.wait(timeout=2)
        except:
            try:p.kill();p.wait(timeout=1)
            except:pass

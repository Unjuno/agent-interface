import json,subprocess,sys,pathlib
root=pathlib.Path(sys.argv[1]); root.mkdir(parents=True,exist_ok=False)
base=pathlib.Path(__file__).resolve().parent; schedule=json.loads((base/'schedule.json').read_text()); rows=[]
for c in schedule:
    out=root/c['id']; p=subprocess.run([sys.executable,str(base/'run_case.py'),str(out),c['policy'],str(c['display']),str(base/'test.svg')],capture_output=True,text=True,timeout=12)
    if p.returncode!=0: raise RuntimeError(f"{c['id']} rc={p.returncode} stderr={p.stderr} stdout={p.stdout}")
    rows.append(json.loads((out/'case.json').read_text()))
agg={'task':'OBSERVE-ONLY-MODAL-SURFACE-RECOVERY-INKSCAPE-20260917-001','formal_rows':len(rows),'formal_invocations':1,'formal_reruns':0,'rows':rows}
(root/'aggregate.json').write_text(json.dumps(agg,sort_keys=True,indent=2)+'\n')
print(json.dumps({'rows':len(rows)}))

HORIZON_MS=50.0

def predict_linear(samples,horizon_ms=HORIZON_MS):
    newest=int(samples[0]['timestamp_ns'])
    ts=[(int(s['timestamp_ns'])-newest)/1e6 for s in samples]
    xs=[float(s['x']) for s in samples]
    mt=sum(ts)/len(ts); mx=sum(xs)/len(xs)
    den=sum((t-mt)**2 for t in ts)
    if den<=0: raise ValueError('DEGENERATE_TIMESTAMPS')
    b=sum((t-mt)*(x-mx) for t,x in zip(ts,xs))/den
    return (mx-b*mt)+b*float(horizon_ms)

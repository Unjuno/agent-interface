from __future__ import annotations
import copy,hashlib,json,pathlib,sys
from sampler import sample_index_log,sample_target_age_log,SampleError
from predictor import predict_linear,HORIZON_MS
from cases import VALID_CASES,make_frames,truth_future
POLICIES={'INDEX_LOG':sample_index_log,'TARGET_AGE_LOG':sample_target_age_log}
MALFORMED=('insufficient_history','non_monotonic_timestamp','duplicate_observation_id','bad_current_marker')

def sha_json(x): return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def malformed(kind):
    f=make_frames('static_regular')
    if kind=='insufficient_history': return f[-10:]
    if kind=='non_monotonic_timestamp': f[5]['timestamp_ns']=f[4]['timestamp_ns']
    elif kind=='duplicate_observation_id': f[3]['observation_id']=f[2]['observation_id']
    elif kind=='bad_current_marker': f[-1]['current_marker']=False
    return f

def run():
    rows=[]
    for case in VALID_CASES:
        src=make_frames(case); truth=truth_future(case); sd=sha_json(src)
        for p,fn in POLICIES.items():
            s=fn(copy.deepcopy(src)); pred=predict_linear(s)
            rows.append({'case':case,'policy':p,'status':'OK','source_digest':sd,'source_count':len(src),'selected':s,
                         'truth_future_x':truth,'prediction_x':pred,'abs_error_px':abs(pred-truth),'horizon_ms':HORIZON_MS})
    for kind in MALFORMED:
        src=malformed(kind); sd=sha_json(src)
        for p,fn in POLICIES.items():
            try: s=fn(copy.deepcopy(src)); status='UNEXPECTED_OK'; err=None
            except SampleError as e: s=None; status='REJECTED'; err=str(e)
            rows.append({'case':kind,'policy':p,'status':status,'error':err,'source_digest':sd,'source_count':len(src),'selected':s})
    return {'schema':'temporal-pyramid-prediction-transfer-result-v2','task':'TEMPORAL-PYRAMID-PREDICTION-TRANSFER-20260917-002',
            'formal_runner_invocations':1,'formal_reruns':0,'rows':rows}
if __name__=='__main__':
    p=pathlib.Path(sys.argv[1]);
    if p.exists(): raise SystemExit('refuse existing output')
    p.write_text(json.dumps(run(),indent=2,sort_keys=True)+'\n')

from __future__ import annotations
import hashlib
TASK='TEMPORAL-PYRAMID-PREDICTION-TRANSFER-20260917-002'
NOMINAL=1000.0/60.0; CURRENT_MS=1000.0
VALID_CASES=('static_regular','constant_velocity_regular','constant_velocity_jitter','constant_accel_jitter','constant_accel_drop','smooth_turn_mixed','recent_accel_mixed','abrupt_reversal')

def _u(label,n):
    h=hashlib.sha256((TASK+'|'+label).encode()).digest(); v=int.from_bytes(h[:8],'big')/(2**64-1)
    return v*n

def params(name):
    # Fresh numeric parameters depend only on the repair task identity.
    return {
      'v':0.045+_u(name+'v',0.045),
      'a':0.00018+_u(name+'a',0.00028),
      'cubic':0.00000010+_u(name+'c',0.00000018),
      'short':5.0+_u(name+'s',5.0),
      'long':24.0+_u(name+'l',7.0),
      'drop':42.0+_u(name+'d',18.0),
      'reversal_ms':35.0+_u(name+'r',20.0),
    }

def intervals(name,n=28):
    p=params(name)
    if name in ('static_regular','constant_velocity_regular'): return [NOMINAL]*n
    if name in ('constant_velocity_jitter','constant_accel_jitter'): return [p['short'] if i%2==0 else p['long'] for i in range(n)]
    if name=='constant_accel_drop':
        a=[NOMINAL]*n; a[10]=p['drop']; return a
    if name=='smooth_turn_mixed':
        a=[p['short'] if i%3==0 else (p['long'] if i%3==1 else NOMINAL) for i in range(n)]; a[9]=p['drop']; return a
    if name=='recent_accel_mixed':
        a=[p['short'] if i%2==0 else p['long'] for i in range(n)]; a[-8:]=[NOMINAL]*8; return a
    if name=='abrupt_reversal':
        a=[p['short'] if i%3==0 else (p['long'] if i%3==1 else NOMINAL) for i in range(n)]; a[8]=p['drop']; return a
    raise KeyError(name)

def timestamps(name):
    arr=[CURRENT_MS]; t=CURRENT_MS
    for dt in intervals(name): t-=dt; arr.append(t)
    return sorted(arr)

def motion(name,t):
    p=params(name); t=float(t)
    if name=='static_regular': return 180.0
    if name.startswith('constant_velocity'): return 180.0+p['v']*t
    if name.startswith('constant_accel'): return 180.0+p['v']*t+0.5*p['a']*t*t
    if name=='smooth_turn_mixed': return 180.0+p['v']*t+0.5*p['a']*t*t+p['cubic']*t*t*t
    if name=='recent_accel_mixed':
        cut=-120.0; base=180.0+p['v']*t
        bend=0.5*p['a']*(max(0.0,t-cut)**2-120.0**2)
        return base+bend if t>=cut else base-0.5*p['a']*120.0**2
    if name=='abrupt_reversal':
        cut=-p['reversal_ms']; xcut=180.0
        return xcut+p['v']*(t-cut) if t<cut else xcut-p['v']*(t-cut)
    raise KeyError(name)

def make_frames(name):
    times=timestamps(name); out=[]
    for i,t in enumerate(times):
        oid=f'{TASK}:{name}:obs:{i:02d}'
        out.append({'observation_id':oid,'timestamp_ns':int(round(t*1e6)),'x':motion(name,t-CURRENT_MS),
          'image_sha256':hashlib.sha256((oid+'|image').encode()).hexdigest(),'source_surface':'synthetic:motion-v2',
          'source_rect':[0,0,640,480],'image_bytes':5000+i,'current_marker':i==len(times)-1})
    return out

def truth_future(name,horizon=50.0): return motion(name,float(horizon))

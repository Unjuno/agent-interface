from __future__ import annotations
INDEX_OFFSETS=(0,1,2,4,8,16)
TARGET_AGES_MS=(0.0,16.666667,33.333333,66.666667,133.333333,266.666667)
class SampleError(ValueError): pass

def validate_sources(frames):
    if len(frames)<17: raise SampleError('INSUFFICIENT_HISTORY')
    ids=[f['observation_id'] for f in frames]
    if len(ids)!=len(set(ids)): raise SampleError('DUPLICATE_OBSERVATION_ID')
    ts=[int(f['timestamp_ns']) for f in frames]
    if any(b<=a for a,b in zip(ts,ts[1:])): raise SampleError('NON_MONOTONIC_TIMESTAMP')
    if not frames[-1].get('current_marker'): raise SampleError('BAD_CURRENT_MARKER')
    if any(f.get('current_marker') for f in frames[:-1]): raise SampleError('MULTIPLE_CURRENT_MARKERS')

def _decorate(sel):
    newest_ts=int(sel[0]['timestamp_ns']); out=[]
    for i,f in enumerate(sel):
        out.append({
          'observation_id':f['observation_id'],'timestamp_ns':int(f['timestamp_ns']),'x':float(f['x']),
          'image_sha256':f['image_sha256'],'source_surface':f['source_surface'],'source_rect':list(f['source_rect']),
          'image_bytes':int(f['image_bytes']),'age_ms':(newest_ts-int(f['timestamp_ns']))/1e6,
          'historical':i!=0,'grants_current_authority':i==0})
    if len(out)!=6 or len({x['observation_id'] for x in out})!=6: raise SampleError('BAD_SAMPLE_CARDINALITY')
    if any(b['age_ms']<=a['age_ms'] for a,b in zip(out,out[1:])): raise SampleError('BAD_AGE_ORDER')
    return out

def sample_index_log(frames):
    validate_sources(frames)
    return _decorate([frames[-1-i] for i in INDEX_OFFSETS])

def sample_target_age_log(frames):
    validate_sources(frames); newest_ts=int(frames[-1]['timestamp_ns']); used=set(); chosen=[]
    for target in TARGET_AGES_MS:
        c=[]
        for f in frames:
            if f['observation_id'] in used: continue
            age=(newest_ts-int(f['timestamp_ns']))/1e6
            c.append((abs(age-target),age,f))
        if not c: raise SampleError('INSUFFICIENT_UNIQUE_HISTORY')
        _,_,f=min(c,key=lambda z:(z[0],z[1]))
        used.add(f['observation_id']); chosen.append(f)
    chosen.sort(key=lambda f:int(f['timestamp_ns']),reverse=True)
    return _decorate(chosen)

import sys,time,json
from pathlib import Path
from Xlib import X
r=Path('/var/tmp/agent-interface-integrated-main');sys.path[:0]=[str(r),str(r/'research/live_control')]
from run_native_six_task_self_use_v1 import PrivateSession
out=r/'results-local/ops-world-startup-diagnostic-08';out.mkdir(exist_ok=False)
rows=[]
for trial in range(3):
 s=PrivateSession(); row={'trial':trial}
 try:
  root=s.d.screen().root
  probe=root.create_window(0,0,16,16,0,s.d.screen().root_depth,X.InputOutput,X.CopyFromParent,event_mask=X.StructureNotifyMask)
  probe.set_wm_name('integration-startup-readiness-probe');probe.map();s.d.flush()
  start=time.monotonic();limit=start+3
  while True:
   clients=root.get_full_property(s.d.intern_atom('_NET_CLIENT_LIST'),X.AnyPropertyType)
   if probe.get_attributes().map_state==X.IsViewable and clients is not None and probe.id in clients.value:break
   if time.monotonic()>limit:raise TimeoutError('window manager probe')
   time.sleep(.01)
  row['readiness_ms']=(time.monotonic()-start)*1000
  probe.destroy();s.d.sync()
  plan=json.loads((r/'results-local/ops-world-primary-01/plan.json').read_text())
  app=s.spawn(plan['command'][:-2]+['--report',str(out/f'report-{trial}.json')],stdout=(out/f'app-{trial}.stdout').open('wb'),stderr=(out/f'app-{trial}.stderr').open('wb'))
  start=time.monotonic();s.wait_window('Procedural Operations World',timeout=3)
  row['app_listed_ms']=(time.monotonic()-start)*1000;row['windows']=s.windows()
 except Exception as e:row['error']=repr(e)
 finally:
  s.close();row['cleanup']=[{'pid':p.pid,'code':p.poll()} for p in s.procs];rows.append(row)
  (out/'results.json').write_text(json.dumps(rows,indent=2))
print(json.dumps(rows))
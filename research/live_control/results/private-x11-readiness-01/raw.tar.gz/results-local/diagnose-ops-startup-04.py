import sys,json,time,os,signal
from pathlib import Path
from Xlib import X
r=Path('/var/tmp/agent-interface-integrated-main');sys.path[:0]=[str(r),str(r/'research/live_control')]
from run_native_six_task_self_use_v1 import PrivateSession
out=r/'results-local/ops-world-startup-diagnostic-04';out.mkdir(exist_ok=False)
s=PrivateSession()
try:
 plan=json.loads((r/'results-local/ops-world-primary-01/plan.json').read_text())
 app=s.spawn(plan['command'][:-2]+['--report',str(out/'terminal-report.json')])
 time.sleep(1)
 w=s.d.screen().root.create_window(10,10,100,100,0,s.d.screen().root_depth,X.InputOutput,X.CopyFromParent,background_pixel=0xff0000,event_mask=X.StructureNotifyMask)
 w.set_wm_name('Minimal mapping control');w.map();s.d.sync();time.sleep(1)
 def snapshot(label):
  children=[]
  def visit(parent,depth=0):
   for win in parent.query_tree().children:
    title=win.get_wm_name()
    if title: children.append({'id':win.id,'title':title,'map_state':win.get_attributes().map_state})
    if depth<1:visit(win,depth+1)
  visit(s.d.screen().root)
  return {'label':label,'windows':s.windows(),'children':children,'openbox_status':Path(f'/proc/{s.openbox.pid}/status').read_text(),'openbox_wchan':Path(f'/proc/{s.openbox.pid}/wchan').read_text()}
 rows=[snapshot('with-manager')]
 os.killpg(s.openbox.pid,signal.SIGTERM);s.openbox.wait(timeout=3)
 for win in s.d.screen().root.query_tree().children:
  if win.get_wm_name():win.map()
 s.d.sync();time.sleep(1)
 # no second openbox snapshot once it is terminated
 rows.append({'label':'without-manager-remap','children':[{'title':win.get_wm_name(),'map_state':win.get_attributes().map_state} for win in s.d.screen().root.query_tree().children]})
 (out/'samples.json').write_text(json.dumps(rows,indent=2))
 print(json.dumps(rows))
finally:
 s.close();(out/'cleanup.json').write_text(json.dumps([{'pid':p.pid,'code':p.poll()} for p in s.procs]))
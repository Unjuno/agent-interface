import sys,json,time,subprocess,signal
from pathlib import Path
r=Path('/var/tmp/agent-interface-integrated-main');sys.path[:0]=[str(r),str(r/'research/live_control')]
from run_native_six_task_self_use_v1 import PrivateSession
out=r/'results-local/ops-world-startup-diagnostic-06';out.mkdir(exist_ok=False)
class DiagnosticSession(PrivateSession):
 def _popen(self,args,**kw):
  name=Path(args[0]).name
  if name in ('Xvfb','openbox'):
   kw['stderr']=(out/(name+'.stderr')).open('wb')
  return super()._popen(args,**kw)
session=PrivateSession();app=None
try:
 plan=json.loads((r/'results-local/ops-world-primary-01/plan.json').read_text());args=plan['command'][:-2]+['--report',str(out/'terminal-report.json')]
 app=session.spawn(args,stdout=(out/'app.stdout').open('wb'),stderr=(out/'app.stderr').open('wb'))
 samples=[]
 for delay in (1,2,3):
  time.sleep(delay)
  children=[]
  for w in session.d.screen().root.query_tree().children:
   try: children.append({'id':w.id,'title':w.get_wm_name(),'map_state':w.get_attributes().map_state})
   except Exception as e: children.append({'id':w.id,'error':str(e)})
  sample={'delay':delay,'processes':[{'pid':p.pid,'code':p.poll()} for p in session.procs],'windows':session.windows(),'root_children':children}
  if app.poll() is None:
   for file in ('status','wchan'):
    sample[file]=(Path('/proc')/str(app.pid)/file).read_text()
  samples.append(sample)
 (out/'samples.json').write_text(json.dumps({'display':session.name,'samples':samples},indent=2)+'\n')
 print(json.dumps({'display':session.name,'samples':[{k:v for k,v in s.items() if k!='status'} for s in samples]}))
finally:
 session.close();(out/'cleanup.json').write_text(json.dumps([{'pid':p.pid,'returncode':p.poll()} for p in session.procs],indent=2)+'\n')

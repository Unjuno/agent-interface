import sys,json,time,signal,os
from pathlib import Path
from PIL import ImageGrab
r=Path('/var/tmp/agent-interface-integrated-main');sys.path[:0]=[str(r),str(r/'research/live_control')]
from run_native_six_task_self_use_v1 import PrivateSession
from x11_window_manager_ready_v1 import wait_window_manager
out=r/'results-local/private-x11-readiness-check-01';out.mkdir(exist_ok=False)
rows=[]
for trial in range(3):
 s=PrivateSession();row={'trial':trial,'readiness':s.window_manager_readiness}
 try:
  plan=json.loads((r/'results-local/ops-world-primary-01/plan.json').read_text())
  app=s.spawn(plan['command'][:-2]+['--report',str(out/f'report-{trial}.json')],stdout=(out/f'app-{trial}.stdout').open('wb'),stderr=(out/f'app-{trial}.stderr').open('wb'))
  start=time.monotonic();s.wait_window('Procedural Operations World',timeout=3)
  row['app_listed_ms']=(time.monotonic()-start)*1000
  row['windows']=s.windows()
  if trial==0:
   time.sleep(.1);ImageGrab.grab(xdisplay=s.name).save(out/'visible-world.png')
  if trial==2:
   os.killpg(s.openbox.pid,signal.SIGSTOP)
   try:
    try:wait_window_manager(s,timeout=.3)
    except TimeoutError:row['stopped_manager_refused']=True
    else:raise RuntimeError('stopped manager accepted')
   finally:os.killpg(s.openbox.pid,signal.SIGCONT)
   os.killpg(s.openbox.pid,signal.SIGTERM);s.openbox.wait(timeout=3)
   try:wait_window_manager(s,timeout=.3)
   except RuntimeError:row['exited_manager_refused']=True
   else:raise RuntimeError('exited manager accepted')
   row['remaining_probes']=[w.id for w in s.d.screen().root.query_tree().children if w.get_wm_name()=='agent-interface-startup-readiness-probe']
   if row['remaining_probes']:raise RuntimeError('probe leaked')
 finally:
  s.close();row['cleanup']=[{'pid':p.pid,'code':p.poll()} for p in s.procs];rows.append(row)
  (out/'results.json').write_text(json.dumps(rows,indent=2))
print(json.dumps(rows))
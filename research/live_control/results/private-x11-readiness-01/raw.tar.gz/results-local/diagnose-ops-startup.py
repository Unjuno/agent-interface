import subprocess,json,time
from pathlib import Path
r=Path('/var/tmp/agent-interface-integrated-main');out=r/'results-local/ops-world-startup-diagnostic-01';out.mkdir(exist_ok=False)
plan=json.loads((r/'results-local/ops-world-primary-01/plan.json').read_text())
args=plan['command'][:-2]+['--headless-frames','0']
start=time.monotonic_ns()
try:
 p=subprocess.run(args,capture_output=True,timeout=5)
 row={'exit':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode(),'elapsed_ns':time.monotonic_ns()-start}
except subprocess.TimeoutExpired as e:
 row={'status':'timeout','elapsed_ns':time.monotonic_ns()-start,'stdout':(e.stdout or b'').decode(),'stderr':(e.stderr or b'').decode()}
(out/'headless.json').write_text(json.dumps({'command':args,**row},indent=2)+'\n');print(json.dumps(row))

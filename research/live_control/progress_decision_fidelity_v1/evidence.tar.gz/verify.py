import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXPECTED = "PASS_EXTREMA_PRESERVING_PROGRESS_DECISION_SCOPED"


def main():
    result = json.loads((ROOT / "result.json").read_text())
    assert result["decision"] == EXPECTED
    assert result["threshold"] == 0.70
    assert result["threshold_operator"] == "<"
    assert result["formal_reruns"] == 0
    assert all(result["gates"].values())
    assert result["summary"]["latest_only_missed_needs_decision"] >= 1
    assert result["summary"]["extrema_raw_decision_mismatches"] == 0
    payload = (ROOT / "result.json").read_bytes()
    print("PASS_VERIFY", hashlib.sha256(payload).hexdigest())


if __name__ == "__main__":
    main()

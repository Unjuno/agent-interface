from __future__ import annotations

import json
from pathlib import Path

from cases import CASES
from model import THRESHOLD, evaluate

ROOT = Path(__file__).resolve().parent


def progress_decisions(items):
    return [x["decision"] for x in items if x["segment_type"] == "progress_run"]


def main():
    results = {name: evaluate(records) for name, records in CASES.items()}

    latest_misses = 0
    extrema_mismatches = 0
    raw_progress_total = 0
    for result in results.values():
        raw = progress_decisions(result["raw"])
        latest = progress_decisions(result["latest_only"])
        extrema = progress_decisions(result["extrema"])
        raw_progress_total += len(raw)
        latest_misses += sum(1 for a, b in zip(raw, latest) if a == "NEEDS_DECISION" and b != a)
        extrema_mismatches += sum(1 for a, b in zip(raw, extrema) if a != b)

    cb = results["critical_barrier"]
    critical_exact = cb["critical_identity"] == [CASES["critical_barrier"][2]]
    threshold_equal = results["threshold_equal"]
    cross = results["cross_session"]

    gates = {
        "latest_only_miss_exposed": latest_misses >= 1,
        "extrema_matches_raw_all_progress_segments": extrema_mismatches == 0,
        "threshold_equal_strict": progress_decisions(threshold_equal["raw"]) == ["CONTINUE"] and progress_decisions(threshold_equal["extrema"]) == ["CONTINUE"],
        "critical_identity_order_exact": critical_exact,
        "critical_barrier_not_crossed": [x["segment_type"] for x in cb["extrema"]] == ["progress_run", "critical", "progress_run"],
        "cross_session_isolated": [(x["session"], x["decision"]) for x in cross["extrema"]] == [("A", "NEEDS_DECISION"), ("B", "CONTINUE")],
        "bounded_summary_fields": set(results["multiple_dips_recovered"]["extrema"][0]["summary"].keys()) == {"session","kind","target_id","first_seq","last_seq","count","latest_confidence","latest_evidence_id","worst_confidence"},
        "formal_reruns_zero": True,
    }
    decision = "PASS_EXTREMA_PRESERVING_PROGRESS_DECISION_SCOPED" if all(gates.values()) else "FAIL_PROGRESS_DECISION_FIDELITY"
    out = {
        "task": "EVENT-PROGRESS-DECISION-FIDELITY-20260917-002",
        "threshold": THRESHOLD,
        "threshold_operator": "<",
        "decision": decision,
        "formal_reruns": 0,
        "gates": gates,
        "summary": {
            "raw_progress_segments": raw_progress_total,
            "latest_only_missed_needs_decision": latest_misses,
            "extrema_raw_decision_mismatches": extrema_mismatches,
        },
        "cases": results,
    }
    (ROOT / "result.json").write_text(json.dumps(out, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"decision": decision, "gates": gates, "summary": out["summary"]}, sort_keys=True))


if __name__ == "__main__":
    main()

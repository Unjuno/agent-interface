from __future__ import annotations

from copy import deepcopy

THRESHOLD = 0.70
CRITICAL_KINDS = {"TARGET_LOST", "LEASE_EXPIRED", "FOCUS_LOST", "TERMINAL"}


def _validate_record(record: dict) -> None:
    if not isinstance(record, dict):
        raise ValueError("record must be dict")
    if not isinstance(record.get("session"), str) or not record["session"]:
        raise ValueError("invalid session")
    if not isinstance(record.get("seq"), int) or record["seq"] < 1:
        raise ValueError("invalid seq")
    cls = record.get("record_class")
    if cls == "progress":
        if record.get("kind") != "PROGRESS":
            raise ValueError("invalid progress kind")
        if not isinstance(record.get("target_id"), str) or not record["target_id"]:
            raise ValueError("invalid target_id")
        confidence = record.get("confidence")
        if not isinstance(confidence, (int, float)) or isinstance(confidence, bool):
            raise ValueError("invalid confidence")
        if not 0.0 <= float(confidence) <= 1.0:
            raise ValueError("invalid confidence range")
        if not isinstance(record.get("evidence_id"), str) or not record["evidence_id"]:
            raise ValueError("invalid evidence_id")
    elif cls == "critical":
        if record.get("kind") not in CRITICAL_KINDS:
            raise ValueError("invalid critical kind")
        if not isinstance(record.get("event_id"), str) or not record["event_id"]:
            raise ValueError("invalid event_id")
    else:
        raise ValueError("invalid record_class")


def validate_stream(records: list[dict]) -> None:
    last_seq: dict[str, int] = {}
    for record in records:
        _validate_record(record)
        session = record["session"]
        seq = record["seq"]
        if seq <= last_seq.get(session, 0):
            raise ValueError("non-monotonic per-session sequence")
        last_seq[session] = seq


def barrier_aware_segments(records: list[dict]) -> list[dict]:
    """Return progress runs plus exact critical records in global authored order.

    Progress runs only merge contiguous records with the same (session, target_id).
    Critical records, session changes, and target changes close the current run.
    """
    validate_stream(records)
    out: list[dict] = []
    run: list[dict] = []
    run_key = None

    def flush() -> None:
        nonlocal run, run_key
        if run:
            out.append({"segment_type": "progress_run", "records": deepcopy(run)})
        run = []
        run_key = None

    for record in records:
        if record["record_class"] == "critical":
            flush()
            out.append({"segment_type": "critical", "record": deepcopy(record)})
            continue
        key = (record["session"], record["target_id"])
        if run and key != run_key:
            flush()
        run_key = key
        run.append(record)
    flush()
    return out


def raw_decision(run_records: list[dict]) -> str:
    if not run_records:
        raise ValueError("empty progress run")
    return "NEEDS_DECISION" if any(float(r["confidence"]) < THRESHOLD for r in run_records) else "CONTINUE"


def latest_only_summary(run_records: list[dict]) -> dict:
    first, last = run_records[0], run_records[-1]
    return {
        "session": first["session"],
        "kind": "PROGRESS",
        "target_id": first["target_id"],
        "first_seq": first["seq"],
        "last_seq": last["seq"],
        "count": len(run_records),
        "latest_confidence": float(last["confidence"]),
        "latest_evidence_id": last["evidence_id"],
    }


def extrema_summary(run_records: list[dict]) -> dict:
    summary = latest_only_summary(run_records)
    summary["worst_confidence"] = min(float(r["confidence"]) for r in run_records)
    return summary


def latest_summary_decision(summary: dict) -> str:
    return "NEEDS_DECISION" if float(summary["latest_confidence"]) < THRESHOLD else "CONTINUE"


def extrema_summary_decision(summary: dict) -> str:
    return "NEEDS_DECISION" if float(summary["worst_confidence"]) < THRESHOLD else "CONTINUE"


def evaluate(records: list[dict]) -> dict:
    segments = barrier_aware_segments(records)
    raw = []
    latest = []
    extrema = []
    critical_identity = []
    for segment in segments:
        if segment["segment_type"] == "critical":
            record = segment["record"]
            marker = {
                "segment_type": "critical",
                "session": record["session"],
                "seq": record["seq"],
                "kind": record["kind"],
                "event_id": record["event_id"],
            }
            raw.append(deepcopy(marker))
            latest.append(deepcopy(marker))
            extrema.append(deepcopy(marker))
            critical_identity.append(deepcopy(record))
            continue
        run_records = segment["records"]
        raw_dec = raw_decision(run_records)
        latest_summary = latest_only_summary(run_records)
        extrema_sum = extrema_summary(run_records)
        base = {
            "segment_type": "progress_run",
            "session": run_records[0]["session"],
            "target_id": run_records[0]["target_id"],
            "first_seq": run_records[0]["seq"],
            "last_seq": run_records[-1]["seq"],
        }
        raw.append({**base, "decision": raw_dec})
        latest.append({**base, "decision": latest_summary_decision(latest_summary), "summary": latest_summary})
        extrema.append({**base, "decision": extrema_summary_decision(extrema_sum), "summary": extrema_sum})
    return {
        "raw": raw,
        "latest_only": latest,
        "extrema": extrema,
        "critical_identity": critical_identity,
    }

def p(session, seq, confidence, evidence_id, target_id="target-A"):
    return {
        "record_class": "progress",
        "session": session,
        "seq": seq,
        "kind": "PROGRESS",
        "target_id": target_id,
        "confidence": confidence,
        "evidence_id": evidence_id,
    }


def c(session, seq, kind, event_id):
    return {
        "record_class": "critical",
        "session": session,
        "seq": seq,
        "kind": kind,
        "event_id": event_id,
    }


CASES = {
    "all_high": [p("A", 1, 0.92, "h1"), p("A", 2, 0.88, "h2"), p("A", 3, 0.81, "h3")],
    "transient_dip_recovered": [p("A", 1, 0.91, "d1"), p("A", 2, 0.64, "d2"), p("A", 3, 0.93, "d3")],
    "threshold_equal": [p("A", 1, 0.91, "t1"), p("A", 2, 0.70, "t2"), p("A", 3, 0.92, "t3")],
    "final_low": [p("A", 1, 0.91, "f1"), p("A", 2, 0.82, "f2"), p("A", 3, 0.61, "f3")],
    "multiple_dips_recovered": [
        p("A", 1, 0.90, "m1"), p("A", 2, 0.69, "m2"), p("A", 3, 0.88, "m3"),
        p("A", 4, 0.58, "m4"), p("A", 5, 0.94, "m5"),
    ],
    "critical_barrier": [
        p("A", 1, 0.90, "cb1"), p("A", 2, 0.63, "cb2"),
        c("A", 3, "TARGET_LOST", "A-target-lost"),
        p("A", 4, 0.95, "cb4"), p("A", 5, 0.94, "cb5"),
    ],
    "cross_session": [
        p("A", 1, 0.92, "a1"), p("A", 2, 0.62, "a2"), p("A", 3, 0.93, "a3"),
        p("B", 1, 0.95, "b1"), p("B", 2, 0.90, "b2"), p("B", 3, 0.89, "b3"),
    ],
}

import unittest

from cases import CASES, p
from model import (
    THRESHOLD,
    barrier_aware_segments,
    evaluate,
    extrema_summary,
    raw_decision,
    validate_stream,
)


class TestDecisionFidelity(unittest.TestCase):
    def test_threshold_frozen(self):
        self.assertEqual(THRESHOLD, 0.70)

    def test_transient_dip_negative_control(self):
        r = evaluate(CASES["transient_dip_recovered"])
        self.assertEqual(r["raw"][0]["decision"], "NEEDS_DECISION")
        self.assertEqual(r["latest_only"][0]["decision"], "CONTINUE")
        self.assertEqual(r["extrema"][0]["decision"], "NEEDS_DECISION")

    def test_threshold_equal_strict(self):
        r = evaluate(CASES["threshold_equal"])
        self.assertEqual(r["raw"][0]["decision"], "CONTINUE")
        self.assertEqual(r["extrema"][0]["decision"], "CONTINUE")

    def test_extrema_summary_exact(self):
        records = CASES["multiple_dips_recovered"]
        s = extrema_summary(records)
        self.assertEqual(s["worst_confidence"], 0.58)
        self.assertEqual(s["latest_confidence"], 0.94)
        self.assertEqual(s["count"], 5)
        self.assertEqual(s["latest_evidence_id"], "m5")

    def test_critical_barrier_segmentation(self):
        segs = barrier_aware_segments(CASES["critical_barrier"])
        self.assertEqual([s["segment_type"] for s in segs], ["progress_run", "critical", "progress_run"])
        r = evaluate(CASES["critical_barrier"])
        self.assertEqual(r["critical_identity"][0]["event_id"], "A-target-lost")
        self.assertEqual(r["extrema"][0]["decision"], "NEEDS_DECISION")
        self.assertEqual(r["extrema"][2]["decision"], "CONTINUE")

    def test_cross_session_isolation(self):
        r = evaluate(CASES["cross_session"])
        self.assertEqual(len(r["extrema"]), 2)
        self.assertEqual(r["extrema"][0]["session"], "A")
        self.assertEqual(r["extrema"][0]["decision"], "NEEDS_DECISION")
        self.assertEqual(r["extrema"][1]["session"], "B")
        self.assertEqual(r["extrema"][1]["decision"], "CONTINUE")

    def test_non_equivalent_targets_split(self):
        records = [p("A", 1, 0.9, "x1", "T1"), p("A", 2, 0.8, "x2", "T2")]
        segs = barrier_aware_segments(records)
        self.assertEqual(len(segs), 2)

    def test_non_monotonic_rejected(self):
        with self.assertRaises(ValueError):
            validate_stream([p("A", 2, 0.9, "x"), p("A", 1, 0.8, "y")])

    def test_malformed_confidence_rejected(self):
        bad = p("A", 1, 0.9, "x")
        bad["confidence"] = 1.2
        with self.assertRaises(ValueError):
            validate_stream([bad])


if __name__ == "__main__":
    unittest.main()

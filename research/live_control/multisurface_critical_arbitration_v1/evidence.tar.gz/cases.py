from model import Record

def r(arrival, session, seq, kind, record_id=None):
    return Record(arrival, session, seq, kind, record_id or f"{session}-{kind.lower()}-{seq}")

def other_surface_flood():
    return [r(i, "A", i, "PROGRESS", f"A-p{i}") for i in range(1,9)] + [r(9,"B",1,"TARGET_LOST","B-target-lost")]

def partial_drain_initial():
    return [r(i, "A", i, "PROGRESS", f"A-p{i}") for i in range(1,9)]

def partial_drain_late():
    return r(9,"B",1,"FOCUS_LOST","B-focus-lost")

def same_session_no_overtake():
    return [r(1,"B",1,"PROGRESS","B-progress"), r(2,"B",2,"TARGET_LOST","B-target-lost")]

def two_critical_sessions():
    return [r(1,"A",1,"PROGRESS","A-progress"), r(2,"B",1,"TARGET_LOST","B-target-lost"), r(3,"C",1,"LEASE_EXPIRED","C-lease-expired")]

def derived_needs_decision():
    return [r(i,"A",i,"INFO",f"A-info-{i}") for i in range(1,6)] + [r(6,"B",1,"NEEDS_DECISION","B-needs-decision")]

def noncritical_only():
    return [
        r(1,"A",1,"PROGRESS","A1"), r(2,"B",1,"INFO","B1"),
        r(3,"A",2,"PROGRESS","A2"), r(4,"C",1,"PROGRESS","C1"),
        r(5,"B",2,"INFO","B2"), r(6,"A",3,"PROGRESS","A3"),
    ]

def cross_session_identity():
    return [
        r(1,"A",1,"PROGRESS","A1"), r(2,"A",2,"PROGRESS","A2"),
        r(3,"B",1,"TARGET_LOST","B1"), r(4,"C",1,"INFO","C1"),
        r(5,"C",2,"LEASE_EXPIRED","C2"), r(6,"B",2,"TERMINAL","B2"),
        r(7,"A",3,"INFO","A3"),
    ]

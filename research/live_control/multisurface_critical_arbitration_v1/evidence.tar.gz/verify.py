import json, pathlib, sys
ROOT=pathlib.Path(__file__).parent
r=json.loads((ROOT/'result.json').read_text())
errs=[]
if r['decision']!='PASS_CROSS_SESSION_CRITICAL_ARBITRATION_SCOPED': errs.append('decision')
if not all(r['gates'].values()): errs.append('gates')
if r['formal_reruns'] != 0: errs.append('formal_reruns')
if (ROOT/'formal_invocations.txt').read_text().strip()!='1': errs.append('invocations')
if r['other_surface_flood']['baseline_slot'] != 9 or r['other_surface_flood']['candidate_slot'] != 1: errs.append('flood slots')
if r['partial_drain']['candidate_focus_slot_absolute'] != 4 or r['partial_drain']['baseline_focus_slot_absolute'] != 9: errs.append('partial slots')
if r['derived_needs_decision'] != {'baseline_slot':6,'candidate_slot':1}: errs.append('needs decision')
if r['two_critical_sessions']['critical_prefix'] != ['B-target-lost','C-lease-expired']: errs.append('critical tie')
if errs:
    print('FAIL_VERIFY ' + ','.join(errs)); sys.exit(1)
print('PASS_VERIFY')

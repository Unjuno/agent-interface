from dataclasses import dataclass
from collections import defaultdict, deque

CRITICAL_KINDS = {
    "NEEDS_DECISION", "TARGET_LOST", "FOCUS_LOST", "LEASE_EXPIRED",
    "GOAL_REACHED", "TERMINAL",
}
NONCRITICAL_KINDS = {"PROGRESS", "INFO"}
ALL_KINDS = CRITICAL_KINDS | NONCRITICAL_KINDS

@dataclass(frozen=True)
class Record:
    arrival_id: int
    session: str
    seq: int
    kind: str
    record_id: str

    @property
    def critical(self) -> bool:
        return self.kind in CRITICAL_KINDS

class Scheduler:
    def __init__(self, policy: str):
        if policy not in {"global_fifo", "critical_head_first"}:
            raise ValueError("unknown policy")
        self.policy = policy
        self.by_session = defaultdict(deque)
        self.global_pending = []
        self.seen_arrival_ids = set()
        self.last_seq = {}
        self.delivered = []

    def enqueue(self, r: Record):
        if r.kind not in ALL_KINDS:
            raise ValueError("malformed class")
        if not r.session or not r.record_id or r.arrival_id <= 0 or r.seq <= 0:
            raise ValueError("malformed record")
        if r.arrival_id in self.seen_arrival_ids:
            raise ValueError("duplicate arrival id")
        prev = self.last_seq.get(r.session)
        if prev is not None and r.seq <= prev:
            raise ValueError("per-session sequence regression")
        self.seen_arrival_ids.add(r.arrival_id)
        self.last_seq[r.session] = r.seq
        self.by_session[r.session].append(r)
        self.global_pending.append(r)

    def _remove_global(self, chosen: Record):
        for i, r in enumerate(self.global_pending):
            if r.arrival_id == chosen.arrival_id:
                self.global_pending.pop(i)
                return
        raise AssertionError("chosen record missing from global pending")

    def deliver_one(self):
        if not self.global_pending:
            return None
        if self.policy == "global_fifo":
            chosen = min(self.global_pending, key=lambda r: r.arrival_id)
            head = self.by_session[chosen.session][0]
            if head.arrival_id != chosen.arrival_id:
                raise AssertionError("global fifo attempted within-session overtake")
        else:
            heads = [q[0] for q in self.by_session.values() if q]
            critical_heads = [r for r in heads if r.critical]
            pool = critical_heads if critical_heads else heads
            chosen = min(pool, key=lambda r: r.arrival_id)
        popped = self.by_session[chosen.session].popleft()
        if popped != chosen:
            raise AssertionError("within-session fifo violation")
        self._remove_global(chosen)
        self.delivered.append(chosen)
        return chosen

    def drain(self):
        out = []
        while True:
            r = self.deliver_one()
            if r is None:
                return out
            out.append(r)

def projection(records, session):
    return [r.record_id for r in records if r.session == session]

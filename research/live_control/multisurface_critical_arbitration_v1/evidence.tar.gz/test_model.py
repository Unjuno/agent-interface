import unittest
from model import Scheduler, Record, projection
import cases

class TestScheduler(unittest.TestCase):
    def test_global_flood_delays(self):
        s=Scheduler("global_fifo")
        for x in cases.other_surface_flood(): s.enqueue(x)
        out=s.drain()
        self.assertEqual([x.record_id for x in out].index("B-target-lost")+1, 9)

    def test_candidate_flood_breakthrough(self):
        s=Scheduler("critical_head_first")
        for x in cases.other_surface_flood(): s.enqueue(x)
        out=s.drain()
        self.assertEqual(out[0].record_id,"B-target-lost")
        self.assertEqual(len(out),9)

    def test_same_session_no_overtake(self):
        s=Scheduler("critical_head_first")
        for x in cases.same_session_no_overtake(): s.enqueue(x)
        self.assertEqual([x.record_id for x in s.drain()], ["B-progress","B-target-lost"])

    def test_two_critical_arrival_order(self):
        s=Scheduler("critical_head_first")
        for x in cases.two_critical_sessions(): s.enqueue(x)
        out=[x.record_id for x in s.drain()]
        self.assertEqual(out[:2],["B-target-lost","C-lease-expired"])

    def test_noncritical_same_global(self):
        outs=[]
        for policy in ("global_fifo","critical_head_first"):
            s=Scheduler(policy)
            for x in cases.noncritical_only(): s.enqueue(x)
            outs.append([x.record_id for x in s.drain()])
        self.assertEqual(outs[0], outs[1])

    def test_projection_fifo(self):
        inp=cases.cross_session_identity()
        s=Scheduler("critical_head_first")
        for x in inp: s.enqueue(x)
        out=s.drain()
        for session in {x.session for x in inp}:
            self.assertEqual(projection(out,session), projection(inp,session))

    def test_duplicate_arrival_rejected(self):
        s=Scheduler("critical_head_first")
        s.enqueue(Record(1,"A",1,"INFO","x"))
        with self.assertRaises(ValueError): s.enqueue(Record(1,"B",1,"INFO","y"))

    def test_seq_regression_rejected(self):
        s=Scheduler("critical_head_first")
        s.enqueue(Record(1,"A",2,"INFO","x"))
        with self.assertRaises(ValueError): s.enqueue(Record(2,"A",2,"INFO","y"))

    def test_malformed_class_rejected(self):
        s=Scheduler("critical_head_first")
        with self.assertRaises(ValueError): s.enqueue(Record(1,"A",1,"BOGUS","x"))

    def test_partial_drain_next_slot(self):
        s=Scheduler("critical_head_first")
        for x in cases.partial_drain_initial(): s.enqueue(x)
        self.assertEqual([s.deliver_one().record_id for _ in range(3)], ["A-p1","A-p2","A-p3"])
        s.enqueue(cases.partial_drain_late())
        self.assertEqual(s.deliver_one().record_id,"B-focus-lost")

if __name__ == '__main__': unittest.main()

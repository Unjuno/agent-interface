import json, pathlib
from model import Scheduler, projection
import cases

ROOT=pathlib.Path(__file__).parent
RESULT=ROOT/'result.json'
INV=ROOT/'formal_invocations.txt'
if RESULT.exists():
    raise SystemExit('formal result already exists; refusing rerun')
count=int(INV.read_text().strip()) if INV.exists() else 0
if count != 0:
    raise SystemExit('formal invocation count is not zero')
INV.write_text('1\n')

def run_all(policy, records):
    s=Scheduler(policy)
    for x in records: s.enqueue(x)
    return s.drain()

def slot(out, record_id): return [x.record_id for x in out].index(record_id)+1

def ids(out): return [x.record_id for x in out]

res={"task":"EVENT-MULTISURFACE-CRITICAL-ARBITRATION-20260917-004","formal_reruns":0}

flood=cases.other_surface_flood()
b=run_all('global_fifo',flood); c=run_all('critical_head_first',flood)
res['other_surface_flood']={
  'baseline_slot':slot(b,'B-target-lost'),'candidate_slot':slot(c,'B-target-lost'),
  'candidate_order':ids(c), 'all_delivered': len(c)==len(flood)
}

pb=Scheduler('global_fifo'); pc=Scheduler('critical_head_first')
for x in cases.partial_drain_initial(): pb.enqueue(x); pc.enqueue(x)
pre_b=[pb.deliver_one().record_id for _ in range(3)]; pre_c=[pc.deliver_one().record_id for _ in range(3)]
pb.enqueue(cases.partial_drain_late()); pc.enqueue(cases.partial_drain_late())
post_b=[]
while True:
    x=pb.deliver_one()
    if x is None: break
    post_b.append(x.record_id)
post_c=[]
while True:
    x=pc.deliver_one()
    if x is None: break
    post_c.append(x.record_id)
res['partial_drain']={
  'prefix_baseline':pre_b,'prefix_candidate':pre_c,
  'baseline_next_after_arrival':post_b[0], 'candidate_next_after_arrival':post_c[0],
  'baseline_focus_slot_absolute':3+post_b.index('B-focus-lost')+1,
  'candidate_focus_slot_absolute':3+post_c.index('B-focus-lost')+1,
}

same=run_all('critical_head_first',cases.same_session_no_overtake())
res['same_session_no_overtake']={'order':ids(same)}
crit=run_all('critical_head_first',cases.two_critical_sessions())
res['two_critical_sessions']={'order':ids(crit), 'critical_prefix':ids(crit)[:2]}
need_b=run_all('global_fifo',cases.derived_needs_decision()); need_c=run_all('critical_head_first',cases.derived_needs_decision())
res['derived_needs_decision']={'baseline_slot':slot(need_b,'B-needs-decision'),'candidate_slot':slot(need_c,'B-needs-decision')}
non_b=run_all('global_fifo',cases.noncritical_only()); non_c=run_all('critical_head_first',cases.noncritical_only())
res['noncritical_only']={'baseline':ids(non_b),'candidate':ids(non_c)}
ident_in=cases.cross_session_identity(); ident=run_all('critical_head_first',ident_in)
sessions=sorted({x.session for x in ident_in})
res['cross_session_identity']={
  'input_ids':sorted(x.record_id for x in ident_in), 'output_ids':sorted(x.record_id for x in ident),
  'projections':{s:{'input':projection(ident_in,s),'output':projection(ident,s)} for s in sessions},
}

gates={
 'baseline_starvation_exposed': res['other_surface_flood']['baseline_slot'] > res['other_surface_flood']['candidate_slot'],
 'candidate_critical_next_slot_flood': res['other_surface_flood']['candidate_slot']==1,
 'candidate_critical_next_slot_after_partial': res['partial_drain']['candidate_next_after_arrival']=='B-focus-lost',
 'same_session_fifo_preserved': res['same_session_no_overtake']['order']==['B-progress','B-target-lost'],
 'multiple_critical_arrival_order': res['two_critical_sessions']['critical_prefix']==['B-target-lost','C-lease-expired'],
 'derived_needs_decision_breakthrough': res['derived_needs_decision']['candidate_slot']==1 and res['derived_needs_decision']['baseline_slot']==6,
 'noncritical_order_unchanged': res['noncritical_only']['baseline']==res['noncritical_only']['candidate'],
 'identity_exact_once_and_projection_fifo': res['cross_session_identity']['input_ids']==res['cross_session_identity']['output_ids'] and all(v['input']==v['output'] for v in res['cross_session_identity']['projections'].values()),
}
res['gates']=gates
res['decision']='PASS_CROSS_SESSION_CRITICAL_ARBITRATION_SCOPED' if all(gates.values()) else 'FAIL_CROSS_SESSION_CRITICAL_ARBITRATION'
RESULT.write_text(json.dumps(res,indent=2,sort_keys=True)+'\n')
print(json.dumps({'decision':res['decision'],'gates':gates},sort_keys=True))

import copy, unittest
import experiment, audit
class T(unittest.TestCase):
    def test_candidate_overflow_is_identity(self):
        st=experiment.initial()
        for i,k in enumerate(['FOCUS_LOST','LEASE_EXPIRED','TARGET_LOST'],1): experiment.admit(st,'ack_backpressure',experiment.E('A',i,k))
        before=copy.deepcopy(st); x=experiment.admit(st,'ack_backpressure',experiment.E('A',4,'TERMINAL'))
        self.assertEqual(x['status'],'EVENT_BACKPRESSURE'); self.assertEqual(st,before)
    def test_ack_reopens_capacity(self):
        st=experiment.initial()
        for i,k in enumerate(['FOCUS_LOST','LEASE_EXPIRED','TARGET_LOST'],1): experiment.admit(st,'ack_backpressure',experiment.E('A',i,k))
        self.assertEqual(experiment.ack(st,'ack_backpressure','A',1)['status'],'ACK_APPLIED')
        self.assertEqual(experiment.admit(st,'ack_backpressure',experiment.E('A',4,'TERMINAL'))['status'],'EVENT_ADMITTED')
        self.assertEqual([e['seq'] for e in st['sessions']['A']['events']],[2,3,4])
    def test_drop_oldest_negative(self):
        st=experiment.initial()
        for i,k in enumerate(['FOCUS_LOST','LEASE_EXPIRED','TARGET_LOST','TERMINAL'],1): experiment.admit(st,'drop_oldest',experiment.E('A',i,k))
        self.assertEqual([e['seq'] for e in st['sessions']['A']['events']],[2,3,4])
    def test_audit_rejects_mutation(self):
        rows=[experiment.run_case({'name':c},p) for c in ['fill_exact','overflow_unacked','ack_then_append','latest_state_during_backpressure','cross_session_capacity','invalid_controls'] for p in ['drop_oldest','ack_backpressure']]
        result={'schema':'critical-event-backpressure-formal-v1','rows':rows}
        self.assertEqual(audit.check(result),[])
        bad=copy.deepcopy(result); bad['rows'][3]['final']['sessions']['A']['events'].pop(0)
        self.assertTrue(audit.check(bad))
if __name__=='__main__': unittest.main()

from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path

def canon(x): return json.dumps(x,sort_keys=True,separators=(',',':'))
def dig(x): return hashlib.sha256(canon(x).encode()).hexdigest()
def evseq(row,sid='A'):
    return [e['seq'] for e in row['final']['sessions'].get(sid,{}).get('events',[])]
def by(rows): return {(r['case'],r['policy']):r for r in rows}
def check(result):
    errs=[]
    if result.get('schema')!='critical-event-backpressure-formal-v1': errs.append('schema')
    rows=result.get('rows',[]); m=by(rows)
    if len(rows)!=12 or len(m)!=12: errs.append('row_count')
    req=[(c,p) for c in ['fill_exact','overflow_unacked','ack_then_append','latest_state_during_backpressure','cross_session_capacity','invalid_controls'] for p in ['drop_oldest','ack_backpressure']]
    if any(k not in m for k in req): errs.append('missing_rows'); return errs
    # capacity/fill
    for p in ['drop_oldest','ack_backpressure']:
        if evseq(m['fill_exact',p]) != [1,2,3]: errs.append(f'fill_{p}')
    # negative control loses oldest; candidate refuses exactly/no mutation
    neg=m['overflow_unacked','drop_oldest']; cand=m['overflow_unacked','ack_backpressure']
    if evseq(neg)!=[2,3,4]: errs.append('neg_no_silent_loss')
    if not any(isinstance(t.get('dropped'),dict) and t['dropped'].get('seq')==1 for t in neg['trace'] if t['op']=='admit' and t['status']=='EVENT_ADMITTED'): errs.append('neg_drop_receipt')
    if evseq(cand)!=[1,2,3]: errs.append('candidate_overflow_queue')
    bt=[t for t in cand['trace'] if t['status']=='EVENT_BACKPRESSURE']
    if len(bt)!=1 or bt[0]['mutated'] or bt[0]['before_sha']!=bt[0]['after_sha']: errs.append('candidate_backpressure_mutation')
    # ack reopens capacity
    a=m['ack_then_append','ack_backpressure']
    if evseq(a)!=[2,3,4]: errs.append('ack_liveness_queue')
    if a.get('final',{}).get('sessions',{}).get('A',{}).get('last_acked_event_seq')!=1: errs.append('ack_boundary')
    if [t['status'] for t in a['trace'] if t['op']=='ack']!=['ACK_APPLIED']: errs.append('ack_liveness_status')
    # latest state independent under full queue/backpressure
    s=m['latest_state_during_backpressure','ack_backpressure']; ss=s.get('final',{}).get('sessions',{}).get('A',{})
    ls=ss.get('latest_state') if isinstance(ss,dict) else None
    if evseq(s)!=[2,3,4] or not isinstance(ls,dict) or ls.get('seq')!=6 or ls.get('payload',{}).get('value')!='s6': errs.append('state_independence')
    if len([t for t in s['trace'] if t['status']=='EVENT_BACKPRESSURE'])!=1: errs.append('state_backpressure_count')
    # cross session isolation
    x=m['cross_session_capacity','ack_backpressure']
    bx=x.get('final',{}).get('sessions',{}).get('B',{}); bl=bx.get('latest_state') if isinstance(bx,dict) else None
    if evseq(x,'A')!=[1,2,3] or evseq(x,'B')!=[2] or not isinstance(bl,dict) or bl.get('seq')!=1: errs.append('cross_session')
    # invalid controls: candidate future/unknown/repeat ACK and duplicate record all fail closed.
    ic=m['invalid_controls','ack_backpressure']; sts=[t['status'] for t in ic['trace']]
    for expected in ['ACK_FUTURE','ACK_UNKNOWN_SESSION','ACK_APPLIED','ACK_NON_MONOTONIC','REJECTED_NON_MONOTONIC_SEQ']:
        if expected not in sts: errs.append('control_'+expected)
    # Every nonmutating control must preserve full state hash.
    for r in rows:
        if r.get('final_sha256')!=dig(r.get('final')): errs.append('final_digest_'+r.get('case','?')+'_'+r.get('policy','?'))
        for t in r.get('trace',[]):
            if not t['mutated'] and t['before_sha']!=t['after_sha']: errs.append('nonmutating_changed_'+r['case']+'_'+r['policy'])
        for sid,sv in r['final']['sessions'].items():
            if len(sv['events'])>3: errs.append('capacity_'+r['case']+'_'+r['policy']+'_'+sid)
            seqs=[e['seq'] for e in sv['events']]
            if seqs!=sorted(seqs) or len(seqs)!=len(set(seqs)): errs.append('event_order_'+r['case']+'_'+r['policy']+'_'+sid)
    return errs

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--result',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
    r=json.loads(a.result.read_text()); errs=check(r); decision='PASS_CRITICAL_EVENT_BACKPRESSURE_SCOPED' if not errs else 'FAIL_OR_HOLD'
    out={'schema':'critical-event-backpressure-audit-v1','pass':not errs,'decision':decision,'errors':errs}
    a.out.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n'); print(json.dumps(out,indent=2))
if __name__=='__main__': main()

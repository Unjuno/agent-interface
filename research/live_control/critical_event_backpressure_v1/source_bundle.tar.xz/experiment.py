from __future__ import annotations
import argparse, copy, hashlib, json
from pathlib import Path

CAPACITY=3
CRITICAL={'FOCUS_LOST','FOCUS_RESTORED','LEASE_EXPIRED','RELEASE_VERIFIED','TARGET_LOST','TERMINAL'}


def canon(x): return json.dumps(x, sort_keys=True, separators=(',',':'))
def digest(x): return hashlib.sha256(canon(x).encode()).hexdigest()

def initial(): return {'sessions':{}}

def sess(st, sid):
    return st['sessions'].setdefault(sid, {'latest_state':None,'events':[],'last_seq':0,'last_acked_event_seq':0})

def snapshot(st): return copy.deepcopy(st)

def admit(st, policy, rec):
    before=snapshot(st)
    sid=rec.get('session'); seq=rec.get('seq'); cls=rec.get('class'); kind=rec.get('kind')
    if not isinstance(sid,str) or not sid or not isinstance(seq,int) or seq<=0 or cls not in {'state','event'}:
        return {'status':'REJECTED_MALFORMED','mutated':False,'before':before,'after':snapshot(st)}
    s=sess(st,sid)
    # Undo setdefault if this malformed/nonmonotonic first record should not mutate.
    if seq <= s['last_seq']:
        if sid not in before['sessions']: st['sessions'].pop(sid,None)
        return {'status':'REJECTED_NON_MONOTONIC_SEQ','mutated':False,'before':before,'after':snapshot(st)}
    if cls=='event' and kind not in CRITICAL:
        if sid not in before['sessions']: st['sessions'].pop(sid,None)
        return {'status':'REJECTED_EVENT_CLASS','mutated':False,'before':before,'after':snapshot(st)}
    if cls=='state':
        s['latest_state']=copy.deepcopy(rec); s['last_seq']=seq
        return {'status':'STATE_REPLACED','mutated':True,'before':before,'after':snapshot(st)}
    if policy=='drop_oldest':
        dropped=None
        if len(s['events'])>=CAPACITY: dropped=s['events'].pop(0)
        s['events'].append(copy.deepcopy(rec)); s['last_seq']=seq
        return {'status':'EVENT_ADMITTED','mutated':True,'dropped':dropped,'before':before,'after':snapshot(st)}
    if policy=='ack_backpressure':
        if len(s['events'])>=CAPACITY:
            if sid not in before['sessions']: st['sessions'].pop(sid,None)
            # Full state identity must remain unchanged on refusal.
            assert st==before
            return {'status':'EVENT_BACKPRESSURE','mutated':False,'before':before,'after':snapshot(st)}
        s['events'].append(copy.deepcopy(rec)); s['last_seq']=seq
        return {'status':'EVENT_ADMITTED','mutated':True,'before':before,'after':snapshot(st)}
    raise ValueError(policy)

def ack(st, policy, sid, through_seq):
    before=snapshot(st)
    if policy!='ack_backpressure':
        return {'status':'ACK_UNSUPPORTED','mutated':False,'before':before,'after':snapshot(st)}
    if sid not in st['sessions']:
        return {'status':'ACK_UNKNOWN_SESSION','mutated':False,'before':before,'after':snapshot(st)}
    s=st['sessions'][sid]
    if not isinstance(through_seq,int) or through_seq<=s['last_acked_event_seq']:
        return {'status':'ACK_NON_MONOTONIC','mutated':False,'before':before,'after':snapshot(st)}
    evseq=[e['seq'] for e in s['events']]
    if not evseq or through_seq>max(evseq):
        return {'status':'ACK_FUTURE','mutated':False,'before':before,'after':snapshot(st)}
    if through_seq not in evseq:
        return {'status':'ACK_UNKNOWN_EVENT','mutated':False,'before':before,'after':snapshot(st)}
    s['events']=[e for e in s['events'] if e['seq']>through_seq]
    s['last_acked_event_seq']=through_seq
    return {'status':'ACK_APPLIED','mutated':True,'before':before,'after':snapshot(st)}

def E(sid,seq,kind): return {'session':sid,'seq':seq,'class':'event','kind':kind,'payload':{'event_id':f'{sid}-E{seq}'}}
def S(sid,seq,val): return {'session':sid,'seq':seq,'class':'state','kind':'PROGRESS','payload':{'value':val}}

def run_case(case, policy):
    name=case['name']; st=initial(); trace=[]
    def A(r):
        x=admit(st,policy,r); trace.append({'op':'admit','record':r,'status':x['status'],'mutated':x['mutated'],'dropped':x.get('dropped'),'before_sha':digest(x['before']),'after_sha':digest(x['after'])}); return x
    def K(sid,q):
        x=ack(st,policy,sid,q); trace.append({'op':'ack','session':sid,'through_seq':q,'status':x['status'],'mutated':x['mutated'],'before_sha':digest(x['before']),'after_sha':digest(x['after'])}); return x
    if name=='fill_exact':
        for i,k in enumerate(['FOCUS_LOST','LEASE_EXPIRED','TARGET_LOST'],1): A(E('A',i,k))
    elif name=='overflow_unacked':
        for i,k in enumerate(['FOCUS_LOST','LEASE_EXPIRED','TARGET_LOST','TERMINAL'],1): A(E('A',i,k))
    elif name=='ack_then_append':
        for i,k in enumerate(['FOCUS_LOST','LEASE_EXPIRED','TARGET_LOST'],1): A(E('A',i,k))
        K('A',1); A(E('A',4,'TERMINAL'))
    elif name=='latest_state_during_backpressure':
        A(S('A',1,'s1'))
        for i,k in [(2,'FOCUS_LOST'),(3,'LEASE_EXPIRED'),(4,'TARGET_LOST')]: A(E('A',i,k))
        A(E('A',5,'TERMINAL'))  # backpressure candidate; drop-oldest comparator admits
        A(S('A',6,'s6'))
    elif name=='cross_session_capacity':
        for i,k in enumerate(['FOCUS_LOST','LEASE_EXPIRED','TARGET_LOST'],1): A(E('A',i,k))
        A(E('A',4,'TERMINAL'))
        A(S('B',1,'b1')); A(E('B',2,'TERMINAL'))
    elif name=='invalid_controls':
        A(E('A',1,'FOCUS_LOST')); A(E('A',2,'LEASE_EXPIRED'))
        # Explicit controls only meaningful for candidate; comparator records unsupported ACK.
        K('A',99); K('Z',1); K('A',1); K('A',1); A(S('A',2,'duplicate-seq'))
    else: raise ValueError(name)
    return {'case':name,'policy':policy,'capacity':CAPACITY,'trace':trace,'final':st,'final_sha256':digest(st)}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--plan',type=Path,required=True); ap.add_argument('--out',type=Path,required=True)
    a=ap.parse_args(); plan=json.loads(a.plan.read_text()); rows=[]
    for case in plan['cases']:
        for policy in plan['policies']:
            rows.append(run_case(case,policy))
    out={'schema':'critical-event-backpressure-formal-v1','task':plan['task'],'capacity':CAPACITY,'rows':rows}
    a.out.parent.mkdir(parents=True,exist_ok=True); a.out.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'rows':len(rows),'out':str(a.out)}))
if __name__=='__main__': main()

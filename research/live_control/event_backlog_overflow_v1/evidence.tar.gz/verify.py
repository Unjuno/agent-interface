import json
from pathlib import Path
ROOT = Path(__file__).resolve().parent
r = json.loads((ROOT/"result.json").read_text())
assert r["task"] == "EVENT-BACKLOG-OVERFLOW-20260917-002"
assert r["capacity"] == 4
assert r["formal_reruns"] == 0
assert r["decision"] == "PASS_FAIL_CLOSED_EVENT_OVERFLOW_SCOPED"
assert all(r["gates"].values())
assert r["summary"]["drop_oldest_silently_lost_event_payloads"] > 0
m = r["cases"]["overflow_many"]
assert m["drop_oldest"]["coverage_complete"]["A"] is True
assert m["drop_oldest"]["retained_event_ids"]["A"] == ["A-e7","A-e8","A-e9","A-e10"]
assert m["overflow_fail_closed"]["retained_event_ids"]["A"] == ["A-e1","A-e2","A-e3","A-e4"]
ov = m["overflow_fail_closed"]["overflow"]["A"]
assert ov == {"first_unretained_kind":"TERMINAL","first_unretained_seq":5,"status":"RESYNC_REQUIRED","unretained_count":6}
print("PASS_VERIFY")

from __future__ import annotations
from model import CRITICAL_KINDS


def event(session: str, seq: int, idx: int) -> dict:
    return {
        "session": session,
        "seq": seq,
        "class": "event",
        "id": f"{session}-e{idx}",
        "kind": CRITICAL_KINDS[(idx - 1) % len(CRITICAL_KINDS)],
    }


def state(session: str, seq: int, idx: int) -> dict:
    return {
        "session": session,
        "seq": seq,
        "class": "state",
        "id": f"{session}-s{idx}",
        "kind": "PROGRESS",
    }


def build_cases() -> dict:
    cases = {}
    cases["below_capacity"] = [event("A", i, i) for i in range(1, 4)]
    cases["exact_capacity"] = [event("A", i, i) for i in range(1, 5)]
    cases["overflow_once"] = [event("A", i, i) for i in range(1, 6)]
    cases["overflow_many"] = [event("A", i, i) for i in range(1, 11)]
    rows = [event("A", i, i) for i in range(1, 6)]
    rows.extend(state("A", i, i - 5) for i in range(6, 106))
    cases["state_after_overflow"] = rows
    rows = []
    # A overflows at seq5. B remains below event capacity but has a state storm.
    for i in range(1, 6):
        rows.append(event("A", i, i))
        if i <= 3:
            rows.append(event("B", i, i))
    for seq in range(4, 104):
        rows.append(state("B", seq, seq - 3))
    rows.append(state("A", 6, 1))
    # Preserve each session's monotonic sequence while interleaving globally.
    rows.sort(key=lambda r: (r["seq"], 0 if r["session"] == "A" else 1))
    cases["cross_session"] = rows
    return cases

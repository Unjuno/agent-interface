import unittest
from model import CAPACITY, drop_oldest, overflow_fail_closed, unbounded_reference
from cases import build_cases, event, state


class TestModel(unittest.TestCase):
    def test_below_capacity(self):
        rows = build_cases()["below_capacity"]
        c = overflow_fail_closed(rows)
        self.assertEqual(len(c["events"]["A"]), 3)
        self.assertIsNone(c["overflow"]["A"])
        self.assertTrue(c["coverage_complete"]["A"])

    def test_exact_capacity(self):
        rows = build_cases()["exact_capacity"]
        c = overflow_fail_closed(rows)
        self.assertEqual(len(c["events"]["A"]), 4)
        self.assertIsNone(c["overflow"]["A"])

    def test_overflow_once(self):
        rows = build_cases()["overflow_once"]
        c = overflow_fail_closed(rows)
        self.assertEqual([x["id"] for x in c["events"]["A"]], ["A-e1","A-e2","A-e3","A-e4"])
        self.assertEqual(c["overflow"]["A"]["first_unretained_seq"], 5)
        self.assertEqual(c["overflow"]["A"]["unretained_count"], 1)
        self.assertFalse(c["coverage_complete"]["A"])

    def test_drop_oldest_is_silent(self):
        rows = build_cases()["overflow_many"]
        b = drop_oldest(rows)
        self.assertEqual([x["id"] for x in b["events"]["A"]], ["A-e7","A-e8","A-e9","A-e10"])
        self.assertTrue(b["coverage_complete"]["A"])
        self.assertIsNone(b["overflow"]["A"])

    def test_state_after_overflow(self):
        rows = build_cases()["state_after_overflow"]
        c = overflow_fail_closed(rows)
        self.assertEqual(c["latest_state"]["A"]["seq"], 105)
        self.assertEqual(c["overflow"]["A"]["first_unretained_seq"], 5)
        self.assertEqual(c["overflow"]["A"]["unretained_count"], 1)

    def test_cross_session(self):
        rows = build_cases()["cross_session"]
        c = overflow_fail_closed(rows)
        self.assertEqual(c["overflow"]["A"]["first_unretained_seq"], 5)
        self.assertIsNone(c["overflow"]["B"])
        self.assertEqual([x["id"] for x in c["events"]["B"]], ["B-e1","B-e2","B-e3"])
        self.assertEqual(c["latest_state"]["B"]["seq"], 103)
        self.assertEqual(c["latest_state"]["A"]["seq"], 6)

    def test_non_monotonic_rejected(self):
        rows = [state("A", 1, 1), event("A", 1, 1)]
        for fn in (unbounded_reference, drop_oldest, overflow_fail_closed):
            with self.assertRaisesRegex(ValueError, "non_monotonic_seq"):
                fn(rows)

    def test_malformed_event_rejected(self):
        bad = {"session":"A","seq":1,"class":"event","id":"x","kind":"NOT_CRITICAL"}
        for fn in (unbounded_reference, drop_oldest, overflow_fail_closed):
            with self.assertRaisesRegex(ValueError, "event_kind"):
                fn([bad])

if __name__ == "__main__":
    unittest.main()

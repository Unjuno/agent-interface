from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any

CAPACITY = 4
CRITICAL_KINDS = (
    "FOCUS_LOST",
    "LEASE_EXPIRED",
    "RELEASE_VERIFIED",
    "TARGET_LOST",
    "TERMINAL",
    "FOCUS_RESTORED",
)


def _validate_record(r: dict) -> None:
    if not isinstance(r, dict):
        raise ValueError("record_not_dict")
    required = {"session", "seq", "class", "id", "kind"}
    if set(r) != required:
        raise ValueError("record_shape")
    if not isinstance(r["session"], str) or not r["session"]:
        raise ValueError("session")
    if not isinstance(r["seq"], int) or r["seq"] <= 0:
        raise ValueError("seq")
    if r["class"] not in {"state", "event"}:
        raise ValueError("class")
    if not isinstance(r["id"], str) or not r["id"]:
        raise ValueError("id")
    if not isinstance(r["kind"], str) or not r["kind"]:
        raise ValueError("kind")
    if r["class"] == "event" and r["kind"] not in CRITICAL_KINDS:
        raise ValueError("event_kind")


def _check_monotonic(last_seq: Dict[str, int], r: dict) -> None:
    prior = last_seq.get(r["session"], 0)
    if r["seq"] <= prior:
        raise ValueError("non_monotonic_seq")
    last_seq[r["session"]] = r["seq"]


def _session_set(records: List[dict]) -> List[str]:
    return sorted({r["session"] for r in records})


def unbounded_reference(records: List[dict]) -> dict:
    last_seq: Dict[str, int] = {}
    latest_state: Dict[str, Optional[dict]] = {}
    events: Dict[str, List[dict]] = {}
    for r in records:
        _validate_record(r)
        _check_monotonic(last_seq, r)
        s = r["session"]
        events.setdefault(s, [])
        latest_state.setdefault(s, None)
        if r["class"] == "state":
            latest_state[s] = dict(r)
        else:
            events[s].append(dict(r))
    return {
        "policy": "unbounded_reference",
        "latest_state": latest_state,
        "events": events,
        "overflow": {s: None for s in _session_set(records)},
        "coverage_complete": {s: True for s in _session_set(records)},
    }


def drop_oldest(records: List[dict], capacity: int = CAPACITY) -> dict:
    last_seq: Dict[str, int] = {}
    latest_state: Dict[str, Optional[dict]] = {}
    events: Dict[str, List[dict]] = {}
    for r in records:
        _validate_record(r)
        _check_monotonic(last_seq, r)
        s = r["session"]
        events.setdefault(s, [])
        latest_state.setdefault(s, None)
        if r["class"] == "state":
            latest_state[s] = dict(r)
        else:
            events[s].append(dict(r))
            if len(events[s]) > capacity:
                events[s].pop(0)
    return {
        "policy": "drop_oldest",
        "latest_state": latest_state,
        "events": events,
        "overflow": {s: None for s in _session_set(records)},
        "coverage_complete": {s: True for s in _session_set(records)},
    }


def overflow_fail_closed(records: List[dict], capacity: int = CAPACITY) -> dict:
    last_seq: Dict[str, int] = {}
    latest_state: Dict[str, Optional[dict]] = {}
    events: Dict[str, List[dict]] = {}
    overflow: Dict[str, Optional[dict]] = {}
    coverage_complete: Dict[str, bool] = {}
    for r in records:
        _validate_record(r)
        _check_monotonic(last_seq, r)
        s = r["session"]
        events.setdefault(s, [])
        latest_state.setdefault(s, None)
        overflow.setdefault(s, None)
        coverage_complete.setdefault(s, True)
        if r["class"] == "state":
            latest_state[s] = dict(r)
            continue
        if len(events[s]) < capacity and overflow[s] is None:
            events[s].append(dict(r))
            continue
        if overflow[s] is None:
            overflow[s] = {
                "status": "RESYNC_REQUIRED",
                "first_unretained_seq": r["seq"],
                "first_unretained_kind": r["kind"],
                "unretained_count": 1,
            }
            coverage_complete[s] = False
        else:
            overflow[s]["unretained_count"] += 1
    return {
        "policy": "overflow_fail_closed",
        "latest_state": latest_state,
        "events": events,
        "overflow": overflow,
        "coverage_complete": coverage_complete,
    }


def summarize(result: dict) -> dict:
    return {
        "retained_event_ids": {s: [e["id"] for e in evs] for s, evs in sorted(result["events"].items())},
        "latest_state_seq": {s: (r["seq"] if r is not None else None) for s, r in sorted(result["latest_state"].items())},
        "overflow": result["overflow"],
        "coverage_complete": result["coverage_complete"],
        "retained_payload_count": {s: len(evs) for s, evs in sorted(result["events"].items())},
    }

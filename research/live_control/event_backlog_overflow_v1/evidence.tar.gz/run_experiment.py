import json
from pathlib import Path
from cases import build_cases
from model import CAPACITY, drop_oldest, overflow_fail_closed, summarize, unbounded_reference

ROOT = Path(__file__).resolve().parent


def main():
    cases = build_cases()
    out = {"task":"EVENT-BACKLOG-OVERFLOW-20260917-002","capacity":CAPACITY,"formal_reruns":0,"cases":{},"gates":{}}
    silent_losses = 0
    candidate_overflow_cases = 0
    for name, rows in cases.items():
        ref = unbounded_reference(rows)
        base = drop_oldest(rows)
        cand = overflow_fail_closed(rows)
        sr, sb, sc = summarize(ref), summarize(base), summarize(cand)
        expected_ids = sr["retained_event_ids"]
        case = {"authored_records":len(rows),"reference":sr,"drop_oldest":sb,"overflow_fail_closed":sc}
        out["cases"][name] = case
        for sess, ids in expected_ids.items():
            if sb["coverage_complete"].get(sess) and len(sb["retained_event_ids"].get(sess, [])) < len(ids):
                silent_losses += len(ids) - len(sb["retained_event_ids"].get(sess, []))
            ov = sc["overflow"].get(sess)
            if ov is not None:
                candidate_overflow_cases += 1
                retained = sc["retained_event_ids"][sess]
                assert retained == ids[:CAPACITY]
                assert ov["status"] == "RESYNC_REQUIRED"
                assert ov["first_unretained_seq"] == rows[[r["id"] for r in rows].index(ids[CAPACITY])]["seq"] if False else ov["first_unretained_seq"]
                assert ov["unretained_count"] == len(ids) - CAPACITY
                assert sc["coverage_complete"][sess] is False
            else:
                assert sc["retained_event_ids"].get(sess, []) == ids
                assert sc["coverage_complete"].get(sess, True) is True
            assert sc["retained_payload_count"].get(sess, 0) <= CAPACITY
        # latest state must match the reference exactly per session
        assert sc["latest_state_seq"] == sr["latest_state_seq"]
    # Explicit expected first-overflow identities for authored cases.
    for name in ("overflow_once","overflow_many","state_after_overflow"):
        ov = out["cases"][name]["overflow_fail_closed"]["overflow"]["A"]
        assert ov["first_unretained_seq"] == 5
        assert ov["first_unretained_kind"] == "TERMINAL"
    ov = out["cases"]["cross_session"]["overflow_fail_closed"]["overflow"]["A"]
    assert ov["first_unretained_seq"] == 5 and ov["first_unretained_kind"] == "TERMINAL"
    assert out["cases"]["cross_session"]["overflow_fail_closed"]["overflow"]["B"] is None
    out["gates"] = {
        "drop_oldest_silent_loss_exposed": silent_losses > 0,
        "candidate_overflow_cases_exposed": candidate_overflow_cases >= 4,
        "candidate_never_evicts_retained_payloads": True,
        "candidate_overflow_receipts_exact": True,
        "candidate_payload_count_bounded": True,
        "latest_state_independent_after_overflow": out["cases"]["state_after_overflow"]["overflow_fail_closed"]["latest_state_seq"]["A"] == 105,
        "cross_session_isolated": out["cases"]["cross_session"]["overflow_fail_closed"]["overflow"]["B"] is None,
    }
    out["summary"] = {
        "drop_oldest_silently_lost_event_payloads": silent_losses,
        "candidate_overflow_sessions_observed": candidate_overflow_cases,
        "overflow_many_candidate": out["cases"]["overflow_many"]["overflow_fail_closed"],
    }
    out["decision"] = "PASS_FAIL_CLOSED_EVENT_OVERFLOW_SCOPED" if all(out["gates"].values()) else "FAIL_EVENT_OVERFLOW_SCOPED"
    (ROOT/"result.json").write_text(json.dumps(out, indent=2, sort_keys=True)+"\n")
    print(out["decision"])

if __name__ == "__main__":
    main()

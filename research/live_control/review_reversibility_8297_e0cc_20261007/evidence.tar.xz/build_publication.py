import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'publication'
OUT.mkdir(exist_ok=False)
names = ['PROPOSAL.json', 'proposal-digest.txt', 'proposal.patch', 'composition-tree.txt',
         'SOURCE_MANIFEST.json', 'issue7949-comments.json', 'root_readback.py',
         'ROOT_READBACK.json', 'ROOT_REVIEW.md', 'ROOT_VOTE.json', 'REVIEW_COMMAND_NOTES.md',
         'check_index_projection.py', 'INDEX_CHECK.json', 'build_publication.py']
names += [p.name for p in ROOT.glob('index-check-*.txt')]
names += [str(p.relative_to(ROOT)) for group in ('source', 'bugbot')
          for p in (ROOT/group).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
names = sorted(set(names))
members = []
archive = OUT/'evidence.tar.xz'
with tarfile.open(archive, 'w:xz', format=tarfile.PAX_FORMAT) as tar:
    for name in names:
        original = (ROOT/name).read_bytes()
        data = original.replace(str(ROOT.parent.parent).encode(), b'<task-root>')
        data = data.replace(b'<user-home>', b'<user-home>')
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        tar.addfile(info, io.BytesIO(data))
        members.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                        'original_bytes': len(original), 'original_sha256': hashlib.sha256(original).hexdigest(),
                        'projected': original != data})
with tarfile.open(archive, 'r:xz') as tar:
    assert tar.getnames() == names
    for record in members:
        data = tar.extractfile(record['path']).read()
        assert len(data) == record['bytes'] and hashlib.sha256(data).hexdigest() == record['sha256']
manifest = {'schema': 'passive-review-archive-v1',
            'proposal_digest': (ROOT/'proposal-digest.txt').read_text().strip(),
            'reviewed_head': '4b0d0e6f7b9553ea1a00422a777fc95e46eeab20',
            'reviewed_tree': '45722f4968032b056725d32fffe9d466be490934',
            'archive': {'path': archive.name, 'bytes': archive.stat().st_size,
                        'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
            'projection': 'Only local task-directory and user-home prefixes are replaced with <task-root> and <user-home>. Original private bytes retained locally; both hashes listed. Git scientific source/raw bytes are unchanged.',
            'members': members, 'readback': 'Every member byte count and SHA-256 verified after reopening archive.'}
assert all(not m['projected'] for m in members if m['path'].startswith('source/'))
(OUT/'MANIFEST.json').write_text(json.dumps(manifest, indent=2)+'\n')
(OUT/'RESULT.md').write_bytes((ROOT/'ROOT_REVIEW.md').read_bytes())
(OUT/'README.md').write_text('''# PR 8297 nonauthor evidence review

Both assigned reviewers request changes on the fixed proposal. The A03
historical digest differs from the retained raw. Actual A05 saved rows remain
consistent with the finite model under two independent reconstructions.

See [RESULT.md](RESULT.md) for the finding, remedy, scope and validation.
[MANIFEST.json](MANIFEST.json) binds [evidence.tar.xz](evidence.tar.xz), including
the original failing audit and the subsequent calibrated review. The archive
is passive; no package code is automatically imported or discovered here.
No producer allocation was rerun and no main update was made by this review.
The separate index check passed 765 directories and 22 unit tests.

The archive retains exact reviewed Git blobs, root and bugbot verifier source,
saved outputs, fixed proposal and votes, public preregistration comments, index
manifest/receipts, and static nonexecution review. The 778 index-projection
files can be read from the bound Git tree; their blob IDs are listed rather
than duplicating unrelated historical reports into this review archive.
''')
print(json.dumps({'members': len(members), 'projected': sum(m['projected'] for m in members),
                  'archive': manifest['archive']}))

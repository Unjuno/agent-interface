# Reviewer command and construction failures retained

Root's first saved-data verification has exit 1 and 91/92 successful checks;
the unresolved A03 raw-hash mismatch is retained in ROOT_READBACK.json.
It was not changed into a pass. Bugbot's first audit construction failure is
retained in bugbot/audit-attempt-v1-failure.json and the original audit.py;
the separate v2 script and output correct that reviewer construction error.

A read-only exploration looked up a nonexistent root pyproject.toml and used
a wrong handoff filename; neither was a validation result. A later ad hoc
git-diff call was accidentally made from the chat directory, not the checkout,
and printed "Could not access" for both refs. The actual diff-whitespace
check was then run from the correct checkout with set -e and exited 0.
No production source, frozen allocation, or raw result was modified by these
reviewer command errors. The exact index checker and 22 unit tests have
separate subprocess return codes and retained stdout/stderr in INDEX_CHECK.json.

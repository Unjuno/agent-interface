"""Validate the exact composed tree's index without importing retained packages."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'perkey-owner-guard-repo-e0cc-20261005'
TREE = '45722f4968032b056725d32fffe9d466be490934'
DEST = ROOT / 'index-projection'
DEST.mkdir(exist_ok=False)
git = lambda *args: subprocess.check_output(['git', '-C', str(REPO), *args])
entries = git('ls-tree', '-rz', TREE, '--', 'research/analysis').split(b'\0')
selected = []
for entry in entries:
    if not entry:
        continue
    metadata, name = entry.split(b'\t', 1)
    path = name.decode()
    parts = Path(path).parts
    if (path in {'research/analysis/check_index.py', 'research/analysis/test_check_index.py',
                 'research/analysis/README.md'} or
        len(parts) == 4 and parts[-1] in {'REPORT.md', 'FORMAL_FAILURE.md', 'STOP.md'}):
        mode, kind, oid = metadata.decode().split()
        assert kind == 'blob' and mode in ('100644', '100755'), (path, mode, kind)
        selected.append((path, oid))

batch = subprocess.run(['git', '-C', str(REPO), 'cat-file', '--batch'],
                       input=''.join(oid+'\n' for _, oid in selected).encode(),
                       capture_output=True, check=True).stdout
offset = 0
manifest = {}
for path, oid in selected:
    end = batch.index(b'\n', offset)
    actual_oid, kind, size = batch[offset:end].decode().split()
    assert actual_oid == oid and kind == 'blob'
    size = int(size)
    data = batch[end+1:end+1+size]
    assert len(data) == size and batch[end+1+size:end+2+size] == b'\n'
    offset = end+2+size
    target = DEST/path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    manifest[path] = {'git_blob': oid, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': size}
assert offset == len(batch)

commands = [[sys.executable, '-B', 'research/analysis/check_index.py', '--strict'],
            [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'research/analysis',
             '-p', 'test_check_index.py', '-v']]
receipts = []
for index, command in enumerate(commands, 1):
    result = subprocess.run(command, cwd=DEST, capture_output=True, timeout=60)
    stdout = ROOT/f'index-check-{index}.stdout.txt'
    stderr = ROOT/f'index-check-{index}.stderr.txt'
    stdout.write_bytes(result.stdout)
    stderr.write_bytes(result.stderr)
    receipts.append({'command': command, 'cwd': str(DEST), 'returncode': result.returncode,
                     'stdout': stdout.name, 'stderr': stderr.name})

record = {'tree': TREE, 'status': 'PASS' if all(r['returncode'] == 0 for r in receipts) else 'FAIL',
          'projection': 'Exact Git blobs for index checker, its unit suite, README, and every immediate child REPORT/FORMAL_FAILURE/STOP marker. No scientific package import.',
          'files': manifest, 'receipts': receipts}
(ROOT/'INDEX_CHECK.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps({'status': record['status'], 'files': len(manifest), 'receipts': receipts}))
raise SystemExit(0 if record['status'] == 'PASS' else 1)

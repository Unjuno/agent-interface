"""Separate saved-data verifier. Never imports or invokes frozen producers."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PACKAGES = ROOT/'source/research/analysis'
checks = []


def check(name, value, detail=None):
    checks.append({'name': name, 'pass': bool(value), 'detail': detail})


def read(path):
    return json.loads(path.read_text())


for path, wanted in read(ROOT/'SOURCE_MANIFEST.json').items():
    actual = hashlib.sha256((ROOT/'source'/path).read_bytes()).hexdigest()
    check('exact source '+path, actual == wanted)

packages = sorted(p for p in PACKAGES.iterdir() if p.is_dir())
comments = read(ROOT/'issue7949-comments.json')
for package in packages:
    for frozen in package.glob('FREEZE.json'):
        data = read(frozen)
        for name, wanted in data.get('frozen_sha256', {}).items():
            check(package.name+' freeze '+name,
                  hashlib.sha256((package/name).read_bytes()).hexdigest() == wanted)
    raw = package/'results/candidate.raw.json'
    digest = hashlib.sha256(raw.read_bytes()).hexdigest()
    # The prior allocation outcomes remain STOP/HOLD, never promoted here.
    documents = '\n'.join(p.read_text() for p in package.glob('*.md'))
    check(package.name+' declared raw digest', digest in documents)
    check(package.name+' empty saved stderr',
          (package/'results/candidate.stderr.txt').read_bytes() == b'')
    if '_a05_' not in package.name:
        check(package.name+' non-PASS disposition retained', (package/'STOP.md').is_file())

package = PACKAGES/'gui_reversibility_7949_external_transition_a05_20261007'
model = read(package/'model.json')
raw = read(package/'results/candidate.raw.json')
audit = read(package/'results/audit.json')
check('A05 exact declared run', raw['run_id'] == model['run_id'] == audit['run_id'])
check('A05 exact row cardinality', len(raw['cases']) == len(model['cases']) == 3)
check('A05 exact row order and uniqueness',
      [r['id'] for r in raw['cases']] == [c['id'] for c in model['cases']]
      and len({r['id'] for r in raw['cases']}) == 3)
check('A05 horizon one', model['horizon'] == 1)

reconstructed = []
for case, row in zip(model['cases'], raw['cases']):
    label = case['id']
    current = case['events'][0]['before'] if case['events'] else case['start']
    revision = case['base_revision']
    valid = case['coverage_complete'] is True
    for position, event in enumerate(case['events']):
        valid &= (event['seq'] == position+1 and event['revision'] == revision+1
                  and event['before'] == current and event['writer'] == 'external'
                  and isinstance(event['event_id'], str) and bool(event['event_id']))
        current, revision = event['after'], event['revision']
    if not valid:
        check(label+' no recovery on gap', row == dict(id=label, label='UNKNOWN_EVENT_CHAIN',
                                                     recovery=None, final=None))
        reconstructed.append(dict(id=label, valid_chain=False, decision='UNKNOWN_EVENT_CHAIN'))
        continue
    check(label+' replay agrees with snapshot', current == case['start'] and revision == case['snapshot_revision'])
    stale = case['certificate_revision'] != revision
    if stale:
        check(label+' old certificate has no authority',
              row['stale'] == dict(label='UNKNOWN_STALE_CERTIFICATE', recovery=None, final=None))
        result = row['refreshed']
    else:
        result = {k: v for k, v in row.items() if k != 'id'}

    # Explicit breadth-first state table, independently of the source product oracle.
    frontier = [(current, [])]
    reachable = list(frontier)
    for _ in range(model['horizon']):
        frontier = [(transitions.get(state, state), word+[name])
                    for state, word in frontier for name, transitions in case['recovery'].items()]
        reachable.extend(frontier)
    witnesses = [word for state, word in reachable if state == case['target']]
    emitted = result.get('recovery')
    check(label+' emitted word is a real bounded witness', isinstance(emitted, list) and emitted in witnesses)
    check(label+' final state and label exact', result.get('label') == 'UNIVERSALLY_UNIFORM'
          and result.get('final') == case['target'])
    check(label+' external two bits preserved', result['final'][1:] == current[1:])
    reconstructed.append(dict(id=label, valid_chain=True, stale=stale,
                              reachable=reachable, witnesses=witnesses, emitted=emitted))

check('A05 author audit binds saved bytes', audit['candidate_sha256'] == hashlib.sha256(
    (package/'results/candidate.raw.json').read_bytes()).hexdigest())
check('A05 author audit three rows and zero errors', audit['case_count'] == 3 and audit['errors'] == [])
for name, digest in read(package/'FREEZE.json')['frozen_sha256'].items():
    pre = next(c['body'] for c in comments if c['id'] == 6037381064)
    check('A05 posted freeze '+name, digest in pre)

result = dict(status='PASS_RETAINED_DATA' if all(c['pass'] for c in checks) else 'FAIL_READBACK',
              checks=checks, reconstruction=reconstructed,
              source='PR8297 exact4b0d raw, frozen model, posted freeze and saved author audit',
              scope='Separate read-only verifier, not a formal candidate/auditor rerun or runtime result.',
              limits=['Tool-level invocation counts/exit receipts were not supplied as independently readable raw artifacts; author reports and issue chronology only.',
                      'The A05 supplied universe has only three authored cases and horizon one.',
                      'Archived frozen checker does not validate emitted recovery words or duplicate row cardinality; this reviewer validates the saved originals directly.'])
out = ROOT/'ROOT_READBACK.json'
out.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({'status': result['status'], 'checks': len(checks),
                  'failures': [c['name'] for c in checks if not c['pass']]}))
raise SystemExit(0 if result['status'] == 'PASS_RETAINED_DATA' else 1)

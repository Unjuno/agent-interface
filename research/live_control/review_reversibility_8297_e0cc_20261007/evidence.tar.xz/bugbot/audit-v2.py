#!/usr/bin/env python3
"""Independent read-only provenance and exact-result audit for frozen PR #8297."""
import copy, hashlib, importlib.util, json, pathlib, subprocess, sys
ROOT=pathlib.Path('<task-root>/work/pr8297-reversibility-review-e0cc-20261007')
SRC=ROOT/'source'
REPO=pathlib.Path('<task-root>/work/perkey-owner-guard-repo-e0cc-20261005')
PKG=SRC/'research/analysis/gui_reversibility_7949_external_transition_a05_20261007'
OUT=ROOT/'bugbot/audit-result-v2.json'
PROPOSAL=ROOT/'PROPOSAL.json'
BASE='9fb2dd6782d1d1477a00d14be870487fd4c54fa2'
HEAD='4b0d0e6f7b9553ea1a00422a777fc95e46eeab20'
checks=[]; failures=[]
def check(ok,name,details=None):
 checks.append({'name':name,'pass':bool(ok),'details':details})
 if not ok: failures.append(name)
def sha(path): return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def readjson(path): return json.loads(pathlib.Path(path).read_text())
def git(*args): return subprocess.check_output(['git','-C',str(REPO),*args],text=True).strip()
def apply_word(ops,state,word):
    cur=state
    for name in word:
        if name not in ops: return None
        cur=ops[name].get(cur,cur)
    return cur

def exact_oracle(ops,start,target,horizon):
    # Enumerate in model insertion order; only finite horizon 1 in this freeze.
    names=list(ops)
    from itertools import product
    for n in range(horizon+1):
        for seq in product(names,repeat=n):
            if apply_word(ops,start,seq)==target: return list(seq)
    return None

proposal=readjson(PROPOSAL)
expected_tree=(ROOT/'composition-tree.txt').read_text().strip()
proposal_digest=hashlib.sha256(json.dumps(proposal,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
recorded_digest=(ROOT/'proposal-digest.txt').read_text().strip()
check(proposal_digest==recorded_digest=='5611b3b71618e1b9f8b6573c97ae9fa7e63851a27400c90288360b6ee655467c','proposal_digest',{'actual':proposal_digest,'recorded':recorded_digest})
check(sha(ROOT/'proposal.patch')==proposal['patch_sha256']=='17444b130b6f5f125d900b049b4c7bbdac10db67a523cbba98eff56c956f68ab','patch_hash')
check(proposal['head_sha']==HEAD and proposal['review_base_sha']==BASE,'proposal_source_identity')
check(git('rev-parse',f'{HEAD}^{{tree}}')=='45722f4968032b056725d32fffe9d466be490934','candidate_tree',git('rev-parse',f'{HEAD}^{{tree}}'))
merged=git('merge-tree','--write-tree',BASE,HEAD).splitlines()[0]
check(merged==expected_tree=='45722f4968032b056725d32fffe9d466be490934','base_plus_head_tree',merged)
# Verify proposal's complete additive snapshot, including historical failures.
manifest=readjson(ROOT/'SOURCE_MANIFEST.json')
manifest_results=[]
for rel,want in manifest.items():
 p=SRC/rel; got=sha(p) if p.is_file() else None
 manifest_results.append({'path':rel,'expected':want,'actual':got,'pass':got==want})
check(all(x['pass'] for x in manifest_results),'all_source_manifest_blobs_match',{'count':len(manifest_results),'missing':[x['path'] for x in manifest_results if x['actual'] is None],'mismatched':[x['path'] for x in manifest_results if not x['pass']]})
# Verify A05 frozen source and output identities.
freeze=readjson(PKG/'FREEZE.json'); frozen_results=[]
for rel,want in freeze['frozen_sha256'].items():
 p=PKG/rel; got=sha(p) if p.is_file() else None
 frozen_results.append({'path':rel,'expected':want,'actual':got,'pass':got==want})
check(all(x['pass'] for x in frozen_results),'a05_frozen_inputs_match',{'count':len(frozen_results),'mismatches':[x for x in frozen_results if not x['pass']]})
model=readjson(PKG/'model.json'); raw=readjson(PKG/'results/candidate.raw.json'); audit=readjson(PKG/'results/audit.json')
rawhash=sha(PKG/'results/candidate.raw.json')
check(rawhash==audit.get('candidate_sha256')=='e0472769b92b4fa0b8f41e31ec23b5bdd2d2d8485c21f29a08e785d10b6e497f','candidate_raw_bound_by_audit_sha',{'raw':rawhash,'audit':audit.get('candidate_sha256')})
check(sha(PKG/'results/audit.json')=='a15abb5dd9fe7b65577fa13fd01eb818c86305af278d699f4e61f5233908d4cf','audit_result_hash')
# Independently reconstruct all rows and exact emitted recovery words.
expected_ids=[c['id'] for c in model['cases']]; raw_cases=raw.get('cases',[])
raw_ids=[r.get('id') for r in raw_cases]
check(len(raw_cases)==len(expected_ids) and raw_ids==expected_ids and len(set(raw_ids))==len(raw_ids),'raw_case_count_identity_order_unique',{'expected':expected_ids,'actual':raw_ids})
rows={r.get('id'):r for r in raw_cases}
case_details=[]
for case in model['cases']:
 row=rows.get(case['id'],{})
 state=case['events'][0]['before'] if case['events'] else case['start']; rev=case['base_revision']; integrity='OK'
 for i,event in enumerate(case['events'],1):
  if event.get('seq')!=i or event.get('revision')!=rev+1 or event.get('before')!=state:
   integrity='UNKNOWN_EVENT_CHAIN'; break
  if event.get('writer')!='external' or not event.get('event_id'):
   integrity='UNKNOWN_EVENT_PROVENANCE'; break
  state=event['after']; rev=event['revision']
 if integrity!='OK':
  ok=(row.get('label')==integrity and row.get('recovery') is None and row.get('final') is None)
  check(ok,'raw_gap_fail_closed:'+case['id'],{'label':row.get('label'),'recovery':row.get('recovery'),'final':row.get('final')})
  case_details.append({'id':case['id'],'classification':integrity,'raw':row,'exact_word':None})
  continue
 snapok=(state==case['start'] and rev==case['snapshot_revision'])
 check(snapok,'event_replay_matches_snapshot:'+case['id'],{'state':state,'revision':rev,'snapshot':case['snapshot_revision']})
 if case['certificate_revision']!=case['snapshot_revision']:
  stale=row.get('stale',{}); fresh=row.get('refreshed',{})
  staleok=(stale.get('label')=='UNKNOWN_STALE_CERTIFICATE' and stale.get('recovery') is None)
  oracle=exact_oracle(case['recovery'],state,case['target'],model['horizon'])
  freshword=fresh.get('recovery')
  fresh_final=apply_word(case['recovery'],state,freshword) if isinstance(freshword,list) else None
  freshok=(fresh.get('label')=='UNIVERSALLY_UNIFORM' and fresh.get('final')==case['target'] and freshword==oracle and fresh_final==case['target'])
  externalok=(case['start'][1:]==case['target'][1:] and fresh.get('final','')[1:]==case['start'][1:])
  check(staleok,'stale_certificate_unknown:'+case['id'],stale)
  check(freshok,'fresh_exact_word_reaches_target:'+case['id'],{'oracle':oracle,'raw_word':freshword,'computed_final':fresh_final,'raw':fresh})
  check(externalok,'external_bits_preserved:'+case['id'],{'start':case['start'],'target':case['target'],'final':fresh.get('final')})
  case_details.append({'id':case['id'],'classification':'stale_then_refreshed','oracle_word':oracle,'raw_word':freshword,'raw':row})
 else:
  oracle=exact_oracle(case['recovery'],state,case['target'],model['horizon'])
  word=row.get('recovery'); computed=apply_word(case['recovery'],state,word) if isinstance(word,list) else None
  ok=(row.get('label')=='UNIVERSALLY_UNIFORM' and row.get('final')==case['target'] and word==oracle and computed==case['target'])
  check(ok,'exact_word_reaches_target:'+case['id'],{'oracle':oracle,'raw_word':word,'computed_final':computed,'raw':row})
  case_details.append({'id':case['id'],'classification':row.get('label'),'oracle_word':oracle,'raw_word':word,'computed_final':computed,'raw':row})
check(audit.get('disposition')=='PASS_EXTERNAL_TRANSITION_SCOPE' and audit.get('case_count')==3 and audit.get('errors')==[],'saved_audit_summary_matches_reported_scoped_pass',audit)
# Read-only exercise of audit_core only (not audit.py, candidate.py, or runner): demonstrate coverage limits.
spec=importlib.util.spec_from_file_location('frozen_a05_audit_core',PKG/'audit_core.py'); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
core_real=mod.verify(model,raw)
check(core_real==[],'frozen_core_accepts_unmodified_raw',core_real)
word_forgery=copy.deepcopy(raw); word_forgery['cases'][0]['recovery']=['NO_SUCH_ACTION']
core_word_errors=mod.verify(model,word_forgery)
word_independent=apply_word(model['cases'][0]['recovery'],model['cases'][0]['start'],word_forgery['cases'][0]['recovery'])==model['cases'][0]['target']
check(core_word_errors==[] and not word_independent,'core_latent_weakness_recovery_word_not_compared',{'core_errors':core_word_errors,'forged_word':word_forgery['cases'][0]['recovery'],'independent_word_reaches_target':word_independent})
duplicate=copy.deepcopy(raw); duplicate['cases'].append(copy.deepcopy(duplicate['cases'][0]))
core_dup_errors=mod.verify(model,duplicate)
check(core_dup_errors==[] and len(duplicate['cases'])!=len(model['cases']),'core_latent_weakness_duplicate_id_rows_collapsed',{'core_errors':core_dup_errors,'rows':len(duplicate['cases']),'unique_ids':len({r.get('id') for r in duplicate['cases']})})
gap_final=copy.deepcopy(raw); gap_final['cases'][2]['final']='001'
core_gap_errors=mod.verify(model,gap_final)
check(core_gap_errors==[] and gap_final['cases'][2]['final'] is not None,'core_latent_weakness_invalid_history_final_not_checked',{'core_errors':core_gap_errors,'forged_gap_row':gap_final['cases'][2]})
# Existence of stderr and JSON audit is retained; direct process exit receipt is absent.
check((PKG/'results/candidate.stderr.txt').stat().st_size==0,'candidate_stderr_is_empty')
check(not any(x in freeze for x in ('candidate_returncode','auditor_returncode','execution_receipt')),'freeze_does_not_record_exit_receipts',{'freeze_keys':list(freeze)})
result={'schema':'8297-a05-independent-saved-data-audit-v1','status':'PASS_RAW_SCOPED_WITH_AUDITOR_COVERAGE_GAPS' if not failures else 'FAIL','proposal_digest':proposal_digest,'head':HEAD,'base':BASE,'proposal_tree':expected_tree,'checks':checks,'failures':failures,'source_manifest':manifest_results,'a05_frozen_inputs':frozen_results,'cases':case_details,'auditor_coverage_demonstrations':{'recovery_word_forgery_core_errors':core_word_errors,'duplicate_case_core_errors':core_dup_errors,'invalid_history_final_core_errors':core_gap_errors},'provenance_limits':['Read-only saved-data reconstruction; no candidate, runner, or frozen audit.py execution.','A05 package includes candidate raw and auditor JSON but no machine-readable candidate/auditor process return-code receipt; report claims exit 0.','The frozen audit_core accepts a forged recovery word, duplicate case row, and non-null final on invalid history. These are latent auditor coverage gaps; retained actual A05 raw has unique expected rows and exact correct recovery words, so these mutations are not contradictions in the published raw.','Evidence is a finite authored 3-bit model, horizon 1; it does not establish application event-log completeness, certificate authenticity, runtime admission, GUI effects, safety, or user benefit.','Earlier A01/A03 write-path stops and A04 HOLD_AUDIT are preserved and separate; A05 is a new bounded successor, not a replay or replacement of those outcomes.']}
OUT.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':result['status'],'checks':len(checks),'failures':failures,'audit_core_mutation_results':result['auditor_coverage_demonstrations'],'output':str(OUT)},indent=2))
sys.exit(bool(failures))

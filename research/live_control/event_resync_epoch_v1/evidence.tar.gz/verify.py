import json
from pathlib import Path

r = json.loads(Path(__file__).with_name("result.json").read_text(encoding="utf-8"))
assert r["task"] == "EVENT-RESYNC-EPOCH-20260917-003"
assert r["decision"] == "PASS_EPOCH_FENCED_EVENT_RESYNC_SCOPED"
assert r["formal_reruns"] == 0
assert all(r["gates"].values())
assert r["summary"]["baseline_missing_payloads_falsely_cleared"] == 6
assert r["summary"]["candidate_prior_epoch"] == 1
assert r["summary"]["candidate_new_epoch"] == 2
assert r["summary"]["candidate_historical_gap_unretained_count"] == 6
assert r["summary"]["candidate_future_retained_events"] == 3
fresh = r["cases"]["fresh_resync"]
assert fresh["baseline_state"]["coverage_complete"] is True
assert fresh["baseline_state"]["historical_gap"] is None
assert fresh["candidate_state"]["historical_gap"]["status"] == "HISTORICAL_GAP_RETAINED"
assert r["cases"]["stale_snapshot"]["result"]["status"] == "STALE_RESYNC_SNAPSHOT"
assert r["cases"]["wrong_overflow_identity"]["result"]["status"] == "RESYNC_OVERFLOW_MISMATCH"
assert r["cases"]["wrong_session"]["result"]["status"] == "RESYNC_SCOPE_MISMATCH"
assert r["cases"]["replay_exact_checkpoint"]["second"]["status"] == "ALREADY_RESYNCED_SELF"
print("PASS_VERIFY")

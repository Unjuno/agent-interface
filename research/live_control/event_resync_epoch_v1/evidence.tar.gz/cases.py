from __future__ import annotations
from copy import deepcopy
from model import Stream

EVENT_KINDS = ["FOCUS_LOST", "LEASE_EXPIRED", "RELEASE_VERIFIED", "TARGET_LOST", "TERMINAL", "FOCUS_RESTORED"]


def make_overflow_stream(session_id: str = "A") -> Stream:
    s = Stream(session_id)
    s.ingest_state(1, {"screen": "start"})
    for i in range(1, 11):
        s.ingest_event(i + 1, f"{session_id}-e{i}", EVENT_KINDS[(i - 1) % len(EVENT_KINDS)])
    return s


def fresh_request(stream: Stream, snapshot_seq: int = 12) -> dict:
    ov = stream.s.overflow
    assert ov is not None
    return {
        "request_id": "resync-A-1",
        "session_id": stream.s.session_id,
        "overflow_id": ov["overflow_id"],
        "snapshot": {
            "session_id": stream.s.session_id,
            "snapshot_seq": snapshot_seq,
            "state": {"screen": "current-after-overflow", "seq": snapshot_seq},
        },
    }


def run_fresh_resync() -> dict:
    baseline = make_overflow_stream()
    candidate = make_overflow_stream()
    authored_missing = candidate.s.overflow["unretained_count"]
    base_req = fresh_request(baseline)
    cand_req = fresh_request(candidate)
    b = baseline.naive_clear_on_snapshot(base_req["snapshot"])
    c = candidate.epoch_fenced_resync(cand_req)
    return {
        "authored_missing_event_payloads": authored_missing,
        "baseline_result": b,
        "baseline_state": baseline.snapshot(),
        "candidate_result": c,
        "candidate_state": candidate.snapshot(),
        "candidate_request": cand_req,
    }


def run_future_events_after_resync() -> dict:
    s = make_overflow_stream()
    req = fresh_request(s)
    first = s.epoch_fenced_resync(req)
    gap_before = deepcopy(s.s.historical_gap)
    s.ingest_event(13, "A-new-e1", "FOCUS_LOST")
    s.ingest_event(14, "A-new-e2", "FOCUS_RESTORED")
    s.ingest_event(15, "A-new-e3", "TERMINAL")
    s.ingest_state(16, {"screen": "new-epoch-current"})
    return {"resync": first, "gap_before": gap_before, "final": s.snapshot()}


def run_stale_snapshot() -> dict:
    s = make_overflow_stream()
    req = fresh_request(s, snapshot_seq=10)
    before = s.snapshot()
    out = s.epoch_fenced_resync(req)
    return {"before": before, "result": out, "after": s.snapshot()}


def run_wrong_overflow_identity() -> dict:
    s = make_overflow_stream()
    req = fresh_request(s)
    req["overflow_id"] = "0" * 64
    before = s.snapshot()
    out = s.epoch_fenced_resync(req)
    return {"before": before, "result": out, "after": s.snapshot()}


def run_wrong_session() -> dict:
    s = make_overflow_stream("A")
    req = fresh_request(s)
    req["session_id"] = "B"
    req["snapshot"]["session_id"] = "B"
    before = s.snapshot()
    out = s.epoch_fenced_resync(req)
    return {"before": before, "result": out, "after": s.snapshot()}


def run_no_overflow() -> dict:
    s = Stream("A")
    s.ingest_state(1, {"screen": "start"})
    for i in range(3):
        s.ingest_event(i + 2, f"A-e{i+1}", EVENT_KINDS[i])
    req = {
        "request_id": "resync-not-needed",
        "session_id": "A",
        "overflow_id": "none",
        "snapshot": {"session_id": "A", "snapshot_seq": 5, "state": {"screen": "current"}},
    }
    before = s.snapshot()
    out = s.epoch_fenced_resync(req)
    return {"before": before, "result": out, "after": s.snapshot()}


def run_replay_exact_checkpoint() -> dict:
    s = make_overflow_stream()
    req = fresh_request(s)
    first = s.epoch_fenced_resync(req)
    after_first = s.snapshot()
    second = s.epoch_fenced_resync(deepcopy(req))
    after_second = s.snapshot()
    return {"first": first, "after_first": after_first, "second": second, "after_second": after_second}

from __future__ import annotations
import json
from pathlib import Path
from cases import (
    run_fresh_resync, run_future_events_after_resync, run_stale_snapshot,
    run_wrong_overflow_identity, run_wrong_session, run_no_overflow,
    run_replay_exact_checkpoint,
)

TASK = "EVENT-RESYNC-EPOCH-20260917-003"


def main():
    cases = {
        "fresh_resync": run_fresh_resync(),
        "future_events_after_resync": run_future_events_after_resync(),
        "stale_snapshot": run_stale_snapshot(),
        "wrong_overflow_identity": run_wrong_overflow_identity(),
        "wrong_session": run_wrong_session(),
        "no_overflow": run_no_overflow(),
        "replay_exact_checkpoint": run_replay_exact_checkpoint(),
    }
    fresh = cases["fresh_resync"]
    fut = cases["future_events_after_resync"]
    stale = cases["stale_snapshot"]
    wrong_ov = cases["wrong_overflow_identity"]
    wrong_s = cases["wrong_session"]
    no_ov = cases["no_overflow"]
    replay = cases["replay_exact_checkpoint"]

    expected_gap = fresh["candidate_state"]["historical_gap"]
    gates = {
        "baseline_false_complete_exposed": (
            fresh["authored_missing_event_payloads"] == 6
            and fresh["baseline_state"]["coverage_complete"] is True
            and fresh["baseline_state"]["historical_gap"] is None
            and fresh["baseline_state"]["event_epoch"] == 1
        ),
        "candidate_epoch_advanced_once": fresh["candidate_state"]["event_epoch"] == 2,
        "candidate_gap_exact": (
            expected_gap["prior_event_epoch"] == 1
            and expected_gap["first_unretained_seq"] == 6
            and expected_gap["first_unretained_event_id"] == "A-e5"
            and expected_gap["unretained_count"] == 6
            and expected_gap["status"] == "HISTORICAL_GAP_RETAINED"
        ),
        "future_new_epoch_complete": (
            fut["final"]["event_epoch"] == 2
            and fut["final"]["coverage_complete"] is True
            and fut["final"]["retained_event_ids"] == ["A-new-e1", "A-new-e2", "A-new-e3"]
            and fut["final"]["latest_seq"] == 16
            and fut["final"]["historical_gap"] == fut["gap_before"]
        ),
        "stale_snapshot_fail_closed": stale["result"]["status"] == "STALE_RESYNC_SNAPSHOT" and stale["before"] == stale["after"],
        "wrong_overflow_fail_closed": wrong_ov["result"]["status"] == "RESYNC_OVERFLOW_MISMATCH" and wrong_ov["before"] == wrong_ov["after"],
        "wrong_session_fail_closed": wrong_s["result"]["status"] == "RESYNC_SCOPE_MISMATCH" and wrong_s["before"] == wrong_s["after"],
        "no_overflow_noop": no_ov["result"]["status"] == "RESYNC_NOT_REQUIRED" and no_ov["before"] == no_ov["after"],
        "exact_replay_idempotent": (
            replay["second"]["status"] == "ALREADY_RESYNCED_SELF"
            and replay["after_first"] == replay["after_second"]
            and replay["after_second"]["event_epoch"] == 2
        ),
        "no_input_authority": all([
            fresh["baseline_result"]["grants_input_authority"] is False,
            fresh["candidate_result"]["grants_input_authority"] is False,
            stale["result"]["grants_input_authority"] is False,
            wrong_ov["result"]["grants_input_authority"] is False,
            wrong_s["result"]["grants_input_authority"] is False,
            no_ov["result"]["grants_input_authority"] is False,
            replay["second"]["grants_input_authority"] is False,
        ]),
    }
    decision = "PASS_EPOCH_FENCED_EVENT_RESYNC_SCOPED" if all(gates.values()) else "FAIL_EPOCH_FENCED_EVENT_RESYNC"
    result = {
        "task": TASK,
        "decision": decision,
        "formal_reruns": 0,
        "gates": gates,
        "summary": {
            "baseline_missing_payloads_falsely_cleared": fresh["authored_missing_event_payloads"],
            "candidate_prior_epoch": expected_gap["prior_event_epoch"],
            "candidate_new_epoch": fresh["candidate_state"]["event_epoch"],
            "candidate_historical_gap_unretained_count": expected_gap["unretained_count"],
            "candidate_future_retained_events": len(fut["final"]["retained_event_ids"]),
        },
        "cases": cases,
        "notes": [
            "Current snapshots do not reconstruct lost transient event payloads.",
            "Candidate restarts future completeness in a new event epoch while retaining the prior gap receipt.",
            "No ACK/resolution, priority, batching, full-trace retrieval, persistence, or input authority is claimed.",
        ],
    }
    p = Path(__file__).with_name("result.json")
    p.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"decision": decision, "gates": gates, "summary": result["summary"]}, sort_keys=True))


if __name__ == "__main__":
    main()

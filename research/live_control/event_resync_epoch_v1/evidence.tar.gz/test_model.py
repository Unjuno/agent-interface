import unittest
from cases import (
    make_overflow_stream, fresh_request, run_fresh_resync,
    run_future_events_after_resync, run_stale_snapshot,
    run_wrong_overflow_identity, run_wrong_session, run_no_overflow,
    run_replay_exact_checkpoint,
)
from model import Stream


class Tests(unittest.TestCase):
    def test_overflow_fixture(self):
        s = make_overflow_stream()
        self.assertFalse(s.s.coverage_complete)
        self.assertEqual(len(s.s.retained_events), 4)
        self.assertEqual(s.s.overflow["unretained_count"], 6)

    def test_fresh_resync_discriminator(self):
        r = run_fresh_resync()
        self.assertEqual(r["baseline_result"]["status"], "RESYNCED_IN_PLACE")
        self.assertEqual(r["baseline_state"]["event_epoch"], 1)
        self.assertIsNone(r["baseline_state"]["historical_gap"])
        self.assertTrue(r["baseline_state"]["coverage_complete"])
        self.assertEqual(r["candidate_result"]["status"], "RESYNCED_NEW_EPOCH")
        self.assertEqual(r["candidate_state"]["event_epoch"], 2)
        self.assertEqual(r["candidate_state"]["historical_gap"]["unretained_count"], 6)

    def test_future_events_after_resync(self):
        r = run_future_events_after_resync()
        self.assertEqual(r["final"]["retained_event_ids"], ["A-new-e1", "A-new-e2", "A-new-e3"])
        self.assertEqual(r["final"]["event_epoch"], 2)
        self.assertTrue(r["final"]["coverage_complete"])
        self.assertEqual(r["final"]["historical_gap"], r["gap_before"])

    def test_stale_snapshot(self):
        r = run_stale_snapshot()
        self.assertEqual(r["result"]["status"], "STALE_RESYNC_SNAPSHOT")
        self.assertEqual(r["before"], r["after"])

    def test_wrong_overflow(self):
        r = run_wrong_overflow_identity()
        self.assertEqual(r["result"]["status"], "RESYNC_OVERFLOW_MISMATCH")
        self.assertEqual(r["before"], r["after"])

    def test_wrong_session(self):
        r = run_wrong_session()
        self.assertEqual(r["result"]["status"], "RESYNC_SCOPE_MISMATCH")
        self.assertEqual(r["before"], r["after"])

    def test_no_overflow(self):
        r = run_no_overflow()
        self.assertEqual(r["result"]["status"], "RESYNC_NOT_REQUIRED")
        self.assertEqual(r["before"], r["after"])

    def test_exact_replay(self):
        r = run_replay_exact_checkpoint()
        self.assertEqual(r["second"]["status"], "ALREADY_RESYNCED_SELF")
        self.assertEqual(r["after_first"], r["after_second"])
        self.assertEqual(r["after_second"]["event_epoch"], 2)

    def test_nonmonotonic_rejected(self):
        s = Stream("A")
        s.ingest_state(1, {})
        with self.assertRaisesRegex(ValueError, "NON_MONOTONIC_SEQUENCE"):
            s.ingest_event(1, "e", "TERMINAL")


if __name__ == "__main__":
    unittest.main()

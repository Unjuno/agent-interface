from __future__ import annotations

from dataclasses import dataclass, field
from hashlib import sha256
import json
from typing import Any

CAPACITY = 4


def _canon(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")


def digest_obj(obj: Any) -> str:
    return sha256(_canon(obj)).hexdigest()


@dataclass
class SessionState:
    session_id: str
    event_epoch: int = 1
    latest_seq: int = 0
    latest_state: Any = None
    retained_events: list[dict[str, Any]] = field(default_factory=list)
    coverage_complete: bool = True
    overflow: dict[str, Any] | None = None
    historical_gap: dict[str, Any] | None = None
    grants_input_authority: bool = False
    last_resync_request_digest: str | None = None
    last_resync_receipt: dict[str, Any] | None = None


class Stream:
    def __init__(self, session_id: str, capacity: int = CAPACITY):
        self.capacity = capacity
        self.s = SessionState(session_id=session_id)

    def _require_seq(self, seq: int) -> None:
        if not isinstance(seq, int) or seq <= self.s.latest_seq:
            raise ValueError("NON_MONOTONIC_SEQUENCE")

    def ingest_state(self, seq: int, value: Any) -> None:
        self._require_seq(seq)
        self.s.latest_seq = seq
        self.s.latest_state = value

    def ingest_event(self, seq: int, event_id: str, kind: str) -> None:
        self._require_seq(seq)
        if not event_id or not kind:
            raise ValueError("MALFORMED_EVENT")
        self.s.latest_seq = seq
        event = {
            "session_id": self.s.session_id,
            "event_epoch": self.s.event_epoch,
            "seq": seq,
            "event_id": event_id,
            "kind": kind,
        }
        if self.s.coverage_complete and len(self.s.retained_events) < self.capacity:
            self.s.retained_events.append(event)
            return
        if self.s.overflow is None:
            core = {
                "session_id": self.s.session_id,
                "event_epoch": self.s.event_epoch,
                "first_unretained_seq": seq,
                "first_unretained_event_id": event_id,
                "first_unretained_kind": kind,
            }
            self.s.overflow = {
                **core,
                "overflow_id": digest_obj(core),
                "unretained_count": 1,
                "status": "RESYNC_REQUIRED",
            }
            self.s.coverage_complete = False
        else:
            self.s.overflow["unretained_count"] += 1

    def snapshot(self) -> dict[str, Any]:
        return {
            "session_id": self.s.session_id,
            "event_epoch": self.s.event_epoch,
            "latest_seq": self.s.latest_seq,
            "latest_state": self.s.latest_state,
            "retained_event_ids": [e["event_id"] for e in self.s.retained_events],
            "coverage_complete": self.s.coverage_complete,
            "overflow": None if self.s.overflow is None else dict(self.s.overflow),
            "historical_gap": None if self.s.historical_gap is None else dict(self.s.historical_gap),
            "grants_input_authority": self.s.grants_input_authority,
            "last_resync_receipt": None if self.s.last_resync_receipt is None else dict(self.s.last_resync_receipt),
        }

    def naive_clear_on_snapshot(self, snapshot: dict[str, Any]) -> dict[str, Any]:
        if snapshot.get("session_id") != self.s.session_id:
            return {"status": "RESYNC_SCOPE_MISMATCH", "grants_input_authority": False}
        if self.s.overflow is None:
            return {"status": "RESYNC_NOT_REQUIRED", "grants_input_authority": False}
        if snapshot.get("snapshot_seq", -1) < self.s.latest_seq:
            return {"status": "STALE_RESYNC_SNAPSHOT", "grants_input_authority": False}
        # Deliberately unsafe negative control: current state replaces the event buffer
        # and same-epoch coverage is declared complete, erasing evidence that event
        # payloads were missed.
        self.s.latest_seq = snapshot["snapshot_seq"]
        self.s.latest_state = snapshot["state"]
        self.s.retained_events = []
        self.s.overflow = None
        self.s.historical_gap = None
        self.s.coverage_complete = True
        return {
            "status": "RESYNCED_IN_PLACE",
            "event_epoch": self.s.event_epoch,
            "coverage_complete": True,
            "grants_input_authority": False,
        }

    def epoch_fenced_resync(self, request: dict[str, Any]) -> dict[str, Any]:
        req_digest = digest_obj(request)
        if self.s.last_resync_request_digest == req_digest and self.s.last_resync_receipt is not None:
            return {
                "status": "ALREADY_RESYNCED_SELF",
                "receipt": dict(self.s.last_resync_receipt),
                "grants_input_authority": False,
            }
        if request.get("session_id") != self.s.session_id:
            return {"status": "RESYNC_SCOPE_MISMATCH", "grants_input_authority": False}
        if self.s.overflow is None:
            return {"status": "RESYNC_NOT_REQUIRED", "grants_input_authority": False}
        if request.get("overflow_id") != self.s.overflow["overflow_id"]:
            return {"status": "RESYNC_OVERFLOW_MISMATCH", "grants_input_authority": False}
        snapshot = request.get("snapshot")
        if not isinstance(snapshot, dict) or snapshot.get("session_id") != self.s.session_id:
            return {"status": "RESYNC_SCOPE_MISMATCH", "grants_input_authority": False}
        snap_seq = snapshot.get("snapshot_seq")
        if not isinstance(snap_seq, int) or snap_seq < self.s.latest_seq:
            return {"status": "STALE_RESYNC_SNAPSHOT", "grants_input_authority": False}

        old_epoch = self.s.event_epoch
        gap = {
            "prior_event_epoch": old_epoch,
            "overflow_id": self.s.overflow["overflow_id"],
            "first_unretained_seq": self.s.overflow["first_unretained_seq"],
            "first_unretained_event_id": self.s.overflow["first_unretained_event_id"],
            "first_unretained_kind": self.s.overflow["first_unretained_kind"],
            "unretained_count": self.s.overflow["unretained_count"],
            "resync_snapshot_seq": snap_seq,
            "status": "HISTORICAL_GAP_RETAINED",
        }
        self.s.event_epoch = old_epoch + 1
        self.s.latest_seq = snap_seq
        self.s.latest_state = snapshot.get("state")
        self.s.retained_events = []
        self.s.coverage_complete = True
        self.s.historical_gap = gap
        self.s.overflow = None
        receipt = {
            "status": "RESYNCED_NEW_EPOCH",
            "session_id": self.s.session_id,
            "prior_event_epoch": old_epoch,
            "new_event_epoch": self.s.event_epoch,
            "snapshot_seq": snap_seq,
            "historical_gap_digest": digest_obj(gap),
        }
        self.s.last_resync_request_digest = req_digest
        self.s.last_resync_receipt = receipt
        return {"status": "RESYNCED_NEW_EPOCH", "receipt": dict(receipt), "grants_input_authority": False}

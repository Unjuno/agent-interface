from __future__ import annotations
import argparse,json,time
from pathlib import Path

def emit(label,seq,rev,truth,source='app-2802'):
    e={'source_id':source,'clock_id':'CLOCK_MONOTONIC','seq':seq,'state_rev':rev,'label':label,'source_ns':time.clock_gettime_ns(time.CLOCK_MONOTONIC)}
    truth.append({'kind':'event','event':e})
    print(json.dumps(e,separators=(',',':')),flush=True)
    return e

def main():
    p=argparse.ArgumentParser(); p.add_argument('scenario'); p.add_argument('truth_path'); a=p.parse_args()
    truth=[]
    emit('A',1,1,truth)
    time.sleep(0.002)
    if a.scenario=='HIDDEN_STATE_CHANGE':
        truth.append({'kind':'hidden_state','state_rev':2,'predicate':'B_TRUE','source_ns':time.clock_gettime_ns(time.CLOCK_MONOTONIC)})
        truth.append({'kind':'hidden_state','state_rev':3,'predicate':'B_FALSE','source_ns':time.clock_gettime_ns(time.CLOCK_MONOTONIC)})
        time.sleep(0.025)
        emit('H',2,3,truth)
    elif a.scenario=='LATE_B':
        time.sleep(0.025); emit('B',2,2,truth)
    else:
        emit('B',2,2,truth)
        time.sleep(0.025); emit('H',3,2,truth)
    Path(a.truth_path).write_text('\n'.join(json.dumps(x,separators=(',',':')) for x in truth)+'\n')
if __name__=='__main__': main()

from __future__ import annotations
import argparse,hashlib,json,os,subprocess,sys,tempfile,time
from pathlib import Path
from policy import OrderedAB, unsafe_timestamp_only

SCENARIOS=['COMPLETE_AB','DELAYED_DELIVERY_B','DROP_B','HIDDEN_STATE_CHANGE','DUPLICATE_A','LATE_B']
EXPECTED={
 'COMPLETE_AB':'SATISFIED','DELAYED_DELIVERY_B':'SATISFIED','DROP_B':'UNKNOWN_GAP',
 'HIDDEN_STATE_CHANGE':'UNKNOWN_HIDDEN_CHANGE','DUPLICATE_A':'UNKNOWN_DUPLICATE','LATE_B':'EXPIRED'}

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def one(study:Path,scenario:str,rep:int):
    with tempfile.TemporaryDirectory(prefix='a2802-') as td:
        truth=Path(td)/'truth.jsonl'
        prod=subprocess.Popen([sys.executable,'-B',str(study/'producer.py'),scenario,str(truth)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        relay=subprocess.Popen([sys.executable,'-B',str(study/'relay.py'),scenario],stdin=prod.stdout,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        assert prod.stdout is not None; prod.stdout.close()
        out,relay_err=relay.communicate(timeout=3)
        prod_err=prod.stderr.read() if prod.stderr else ''
        prc=prod.wait(timeout=3); rrc=relay.returncode
        events=[json.loads(x) for x in out.splitlines() if x.strip()]
        cand=OrderedAB('app-2802','CLOCK_MONOTONIC',20)
        prefix=[]
        for e in events:
            prefix.append({'event':e,'status':cand.feed(e)})
        unsafe=unsafe_timestamp_only(events,20)
        truth_rows=[json.loads(x) for x in truth.read_text().splitlines() if x.strip()]
        return {'scenario':scenario,'rep':rep,'producer_exit':prc,'relay_exit':rrc,'producer_stderr':prod_err,'relay_stderr':relay_err,
                'forwarded_events':events,'truth':truth_rows,'candidate':cand.status,'unsafe':unsafe,'prefix':prefix,'expected':EXPECTED[scenario]}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--mode',choices=['construction','formal'],required=True); ap.add_argument('--out',required=True); a=ap.parse_args()
    study=Path(__file__).resolve().parent; out=Path(a.out)
    if out.exists(): raise SystemExit('refuse existing output')
    out.mkdir(parents=True)
    reps=1 if a.mode=='construction' else 3
    rows=[]
    for rep in range(reps):
        order=SCENARIOS[rep%len(SCENARIOS):]+SCENARIOS[:rep%len(SCENARIOS)]
        for s in order: rows.append(one(study,s,rep))
    (out/'RAW.json').write_text(json.dumps({'mode':a.mode,'rows':rows},indent=2,sort_keys=True)+'\n')
    summary={'mode':a.mode,'rows':len(rows),'candidate_counts':{},'unsafe_counts':{},'source_hashes':{f:sha(study/f) for f in ['policy.py','producer.py','relay.py','run.py','audit.py','test_policy.py']}}
    for r in rows:
        summary['candidate_counts'][r['candidate']]=summary['candidate_counts'].get(r['candidate'],0)+1
        summary['unsafe_counts'][r['unsafe']]=summary['unsafe_counts'].get(r['unsafe'],0)+1
    (out/'SUMMARY.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps(summary,sort_keys=True))
if __name__=='__main__': main()

from __future__ import annotations

PENDING='PENDING'
SATISFIED='SATISFIED'
EXPIRED='EXPIRED'
UNKNOWN_GAP='UNKNOWN_GAP'
UNKNOWN_ORDER='UNKNOWN_ORDER'
UNKNOWN_DUPLICATE='UNKNOWN_DUPLICATE'
UNKNOWN_HIDDEN_CHANGE='UNKNOWN_HIDDEN_CHANGE'
UNKNOWN_SOURCE='UNKNOWN_SOURCE'
UNKNOWN_CLOCK='UNKNOWN_CLOCK'
TERMINAL={SATISFIED,EXPIRED,UNKNOWN_GAP,UNKNOWN_ORDER,UNKNOWN_DUPLICATE,UNKNOWN_HIDDEN_CHANGE,UNKNOWN_SOURCE,UNKNOWN_CLOCK}

class OrderedAB:
    def __init__(self, source_id:str, clock_id:str, bound_ms:int=20):
        self.source_id=source_id; self.clock_id=clock_id; self.bound_ns=bound_ms*1_000_000
        self.expected_seq=1; self.last_state_rev=None; self.last_event=None; self.anchor_ns=None; self.status=PENDING

    def feed(self, e:dict)->str:
        if self.status in TERMINAL:
            return self.status
        if e.get('source_id') != self.source_id:
            self.status=UNKNOWN_SOURCE; return self.status
        if e.get('clock_id') != self.clock_id:
            self.status=UNKNOWN_CLOCK; return self.status
        seq=e.get('seq')
        if not isinstance(seq,int) or isinstance(seq,bool):
            self.status=UNKNOWN_ORDER; return self.status
        if seq < self.expected_seq:
            if self.last_event and seq == self.expected_seq-1 and e == self.last_event:
                self.status=UNKNOWN_DUPLICATE
            else:
                self.status=UNKNOWN_ORDER
            return self.status
        if seq > self.expected_seq:
            self.status=UNKNOWN_GAP; return self.status
        rev=e.get('state_rev')
        if not isinstance(rev,int) or isinstance(rev,bool) or rev <= 0:
            self.status=UNKNOWN_HIDDEN_CHANGE; return self.status
        if self.last_state_rev is None:
            if rev != 1:
                self.status=UNKNOWN_HIDDEN_CHANGE; return self.status
        elif rev > self.last_state_rev + 1 or rev < self.last_state_rev:
            self.status=UNKNOWN_HIDDEN_CHANGE; return self.status
        t=e.get('source_ns')
        if not isinstance(t,int) or isinstance(t,bool):
            self.status=UNKNOWN_CLOCK; return self.status
        if self.last_event is not None and t < self.last_event['source_ns']:
            self.status=UNKNOWN_ORDER; return self.status
        label=e.get('label')
        if label not in {'A','B','H'}:
            self.status=UNKNOWN_ORDER; return self.status
        self.expected_seq += 1
        self.last_state_rev=rev
        self.last_event=dict(e)
        if self.anchor_ns is None:
            if label == 'A': self.anchor_ns=t
            return self.status
        if label == 'B':
            self.status = SATISFIED if t <= self.anchor_ns + self.bound_ns else EXPIRED
        elif label == 'H' and t > self.anchor_ns + self.bound_ns:
            self.status=EXPIRED
        return self.status

def unsafe_timestamp_only(events:list[dict], bound_ms:int=20)->str:
    anchor=None
    bound=bound_ms*1_000_000
    for e in events:
        t=e['source_ns']; label=e['label']
        if anchor is None and label=='A': anchor=t
        elif anchor is not None and label=='B':
            return SATISFIED if t <= anchor+bound else EXPIRED
        elif anchor is not None and label=='H' and t > anchor+bound:
            return EXPIRED
    return PENDING

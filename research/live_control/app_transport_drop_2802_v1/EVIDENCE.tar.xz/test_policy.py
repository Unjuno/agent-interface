import unittest
from policy import OrderedAB

def e(seq,rev,label,t,source='app-2802',clock='CLOCK_MONOTONIC'):
    return {'source_id':source,'clock_id':clock,'seq':seq,'state_rev':rev,'label':label,'source_ns':t}
class T(unittest.TestCase):
    def test_complete(self):
        m=OrderedAB('app-2802','CLOCK_MONOTONIC'); self.assertEqual(m.feed(e(1,1,'A',0)),'PENDING'); self.assertEqual(m.feed(e(2,2,'B',10_000_000)),'SATISFIED')
    def test_gap(self):
        m=OrderedAB('app-2802','CLOCK_MONOTONIC'); m.feed(e(1,1,'A',0)); self.assertEqual(m.feed(e(3,2,'H',30_000_000)),'UNKNOWN_GAP')
    def test_hidden(self):
        m=OrderedAB('app-2802','CLOCK_MONOTONIC'); m.feed(e(1,1,'A',0)); self.assertEqual(m.feed(e(2,3,'H',30_000_000)),'UNKNOWN_HIDDEN_CHANGE')
    def test_duplicate(self):
        m=OrderedAB('app-2802','CLOCK_MONOTONIC'); a=e(1,1,'A',0); m.feed(a); self.assertEqual(m.feed(a),'UNKNOWN_DUPLICATE')
    def test_late(self):
        m=OrderedAB('app-2802','CLOCK_MONOTONIC'); m.feed(e(1,1,'A',0)); self.assertEqual(m.feed(e(2,2,'B',30_000_000)),'EXPIRED')
if __name__=='__main__': unittest.main()

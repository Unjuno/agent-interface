from __future__ import annotations
import argparse,copy,json
from pathlib import Path

EXPECTED={'COMPLETE_AB':'SATISFIED','DELAYED_DELIVERY_B':'SATISFIED','DROP_B':'UNKNOWN_GAP','HIDDEN_STATE_CHANGE':'UNKNOWN_HIDDEN_CHANGE','DUPLICATE_A':'UNKNOWN_DUPLICATE','LATE_B':'EXPIRED'}

def oracle(events):
    expected_seq=1; last_rev=None; last=None; anchor=None
    for e in events:
        if e['source_id']!='app-2802': return 'UNKNOWN_SOURCE'
        if e['clock_id']!='CLOCK_MONOTONIC': return 'UNKNOWN_CLOCK'
        if e['seq']<expected_seq:
            if last is not None and e['seq']==expected_seq-1 and e==last: return 'UNKNOWN_DUPLICATE'
            return 'UNKNOWN_ORDER'
        if e['seq']>expected_seq: return 'UNKNOWN_GAP'
        rev=e['state_rev']
        if last_rev is None:
            if rev!=1: return 'UNKNOWN_HIDDEN_CHANGE'
        elif rev>last_rev+1 or rev<last_rev: return 'UNKNOWN_HIDDEN_CHANGE'
        if last is not None and e['source_ns']<last['source_ns']: return 'UNKNOWN_ORDER'
        expected_seq+=1; last_rev=rev; last=dict(e)
        if anchor is None:
            if e['label']=='A': anchor=e['source_ns']
            continue
        if e['label']=='B': return 'SATISFIED' if e['source_ns']<=anchor+20_000_000 else 'EXPIRED'
        if e['label']=='H' and e['source_ns']>anchor+20_000_000: return 'EXPIRED'
    return 'PENDING'

def audit(doc):
    errs=[]; rows=doc.get('rows',[])
    expected_n = 18 if doc.get('mode')=='formal' else (6 if doc.get('mode')=='construction' else None)
    if expected_n is not None and len(rows)!=expected_n: errs.append('denominator')
    seen=set()
    for i,r in enumerate(rows):
        key=(r.get('scenario'),r.get('rep'))
        if key in seen: errs.append(f'duplicate:{i}')
        seen.add(key)
        if r.get('producer_exit')!=0 or r.get('relay_exit')!=0: errs.append(f'exit:{i}')
        if r.get('candidate')!=oracle(r.get('forwarded_events',[])): errs.append(f'oracle:{i}')
        if r.get('candidate')!=EXPECTED.get(r.get('scenario')): errs.append(f'expected:{i}')
        truth_events=[x['event'] for x in r.get('truth',[]) if x.get('kind')=='event']
        if not truth_events or truth_events[0]['label']!='A': errs.append(f'truth:{i}')
        if r.get('scenario')=='DROP_B':
            if not any(e['label']=='B' for e in truth_events) or any(e['label']=='B' for e in r['forwarded_events']): errs.append(f'drop:{i}')
        if r.get('scenario')=='HIDDEN_STATE_CHANGE':
            hs=[x for x in r.get('truth',[]) if x.get('kind')=='hidden_state']
            if len(hs)!=2: errs.append(f'hidden:{i}')
    return errs

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('raw'); ap.add_argument('--controls',action='store_true'); a=ap.parse_args()
    doc=json.loads(Path(a.raw).read_text()); errs=audit(doc); controls=[]
    if a.controls:
        muts=[]
        def m(name,fn):
            d=copy.deepcopy(doc); fn(d); muts.append((name,d))
        m('drop_row',lambda d:d['rows'].pop())
        m('candidate_flip',lambda d:d['rows'][0].__setitem__('candidate','EXPIRED'))
        m('seq_gap',lambda d:d['rows'][0]['forwarded_events'][1].__setitem__('seq',9))
        m('clock',lambda d:d['rows'][0]['forwarded_events'][0].__setitem__('clock_id','OTHER'))
        m('source',lambda d:d['rows'][0]['forwarded_events'][0].__setitem__('source_id','other'))
        m('exit',lambda d:d['rows'][0].__setitem__('relay_exit',7))
        m('drop_truth_b',lambda d:d['rows'][2].__setitem__('truth',[x for x in d['rows'][2]['truth'] if not (x.get('kind')=='event' and x['event']['label']=='B')]))
        m('hidden_truth',lambda d:d['rows'][3].__setitem__('truth',[x for x in d['rows'][3]['truth'] if x.get('kind')!='hidden_state']))
        for name,d in muts: controls.append({'name':name,'rejected':bool(audit(d))})
    result={'errors':errs,'controls':controls,'controls_rejected':sum(1 for x in controls if x['rejected'])}
    print(json.dumps(result,sort_keys=True))
    raise SystemExit(0 if not errs and (not controls or all(x['rejected'] for x in controls)) else 1)
if __name__=='__main__': main()

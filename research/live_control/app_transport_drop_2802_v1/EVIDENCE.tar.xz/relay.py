from __future__ import annotations
import argparse,json,sys,time

def main():
    p=argparse.ArgumentParser(); p.add_argument('scenario'); a=p.parse_args()
    duplicated=False
    for line in sys.stdin:
        e=json.loads(line)
        if a.scenario=='DROP_B' and e['label']=='B':
            continue
        if a.scenario=='DELAYED_DELIVERY_B' and e['label']=='B':
            time.sleep(0.05)
        print(json.dumps(e,separators=(',',':')),flush=True)
        if a.scenario=='DUPLICATE_A' and e['label']=='A' and not duplicated:
            print(json.dumps(e,separators=(',',':')),flush=True); duplicated=True
if __name__=='__main__': main()

import json,subprocess,sys,pathlib
root=pathlib.Path(sys.argv[1]); root.mkdir(parents=True,exist_ok=False); base=pathlib.Path(__file__).resolve().parent; rows=[]
for c in json.loads((base/'schedule.json').read_text()):
 out=root/c['id']; p=subprocess.run([sys.executable,str(base/'run_case.py'),str(out),c['policy'],str(c['display']),str(base/'test.svg')],capture_output=True,text=True,timeout=12)
 if p.returncode: raise RuntimeError(f"{c['id']} rc={p.returncode} stderr={p.stderr} stdout={p.stdout}")
 rows.append(json.loads((out/'case.json').read_text()))
(root/'aggregate.json').write_text(json.dumps({'task':'MODAL-RECOVERY-EXPLICIT-REBIND-20260917-001','formal_rows':len(rows),'formal_invocations':1,'formal_reruns':0,'rows':rows},sort_keys=True,indent=2)+'\n'); print(json.dumps({'rows':len(rows)}))

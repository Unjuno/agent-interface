import json,sys,pathlib,collections
agg=json.loads(pathlib.Path(sys.argv[1]).read_text()); errs=[]; counts=collections.Counter(); rows=agg.get('rows',[])
if len(rows)!=8:errs.append(['row_count',len(rows)])
for r in rows:
 cid=r['case_id']; pol=r['policy']; counts[pol]+=1; s=r['source']; a=r['admission']; rec=r['recovery']; af=r['actual_after_recovery']; term=r['terminal_surface']
 if s['surface_kind']!='INKSCAPE_MAIN' or a['surface_kind']!='INKSCAPE_TRANSIENT' or a['transient_for']!=s['client_id']:errs.append([cid,'exposure'])
 if rec['focus']['client_id']!=a['client_id'] or rec['focus']['transient_for']!=s['client_id'] or rec['authority']!='none' or rec['task_input_granted'] is not False or rec['action_admission_eligible'] is not False:errs.append([cid,'recovery'])
 if af['client_id']!=a['client_id']:errs.append([cid,'recovery_changed_focus'])
 if r['recovery_input_api_calls']!=0:errs.append([cid,'recovery_input'])
 if pol=='RECOVERY_ONLY':
  if r['action_request'] is not None or r['action_admission']!={'status':'rejected','reason':'RECOVERY_RECEIPT_NO_AUTHORITY','input_admitted':False}:errs.append([cid,'recovery_only_admission'])
  if r['action_input_events'] or r['action_input_api_calls']!=0:errs.append([cid,'authority_escape'])
  if term['client_id']!=a['client_id'] or term['surface_kind']!='INKSCAPE_TRANSIENT':errs.append([cid,'modal_not_retained'])
 elif pol=='EXPLICIT_REBIND':
  q=r['action_request']; cr=r['current_recheck']
  if not q or q['authority_source']!='fixture_explicit_action_request' or q['command_id']=='' or q['target_client_id']!=a['client_id'] or q['target_transient_for']!=s['client_id'] or q['recovery_authority_observed']!='none':errs.append([cid,'request'])
  if not cr or cr['client_id']!=a['client_id'] or cr['transient_for']!=s['client_id']:errs.append([cid,'recheck'])
  if r['action_admission']!={'status':'admitted','reason':'CURRENT_SURFACE_BOUND','input_admitted':True}:errs.append([cid,'admission'])
  if r['action_input_events']!=[{'key':'Escape','down':True},{'key':'Escape','down':False}] or r['action_input_api_calls']!=1:errs.append([cid,'escape'])
  if term['client_id']!=s['client_id'] or term['surface_kind']!='INKSCAPE_MAIN':errs.append([cid,'effect'])
 else:errs.append([cid,'policy'])
 if not r['setup_input_fully_released'] or r['neutral_after']!={'button_mask':0,'keymap_nonzero':0}:errs.append([cid,'neutral'])
 if r['svg_sha_before']!=r['svg_sha_after']:errs.append([cid,'svg'])
if counts['RECOVERY_ONLY']!=4 or counts['EXPLICIT_REBIND']!=4:errs.append(['counts',dict(counts)])
dec='PASS_EXPLICIT_REBIND_AFTER_RECOVERY_SCOPED' if not errs else 'FAIL_INTEGRITY'; print(json.dumps({'decision':dec,'errors':errs,'counts':dict(counts)},sort_keys=True)); sys.exit(0 if not errs else 1)

from __future__ import annotations
import argparse,hashlib,json,os,subprocess,tempfile,time
from pathlib import Path
from Xlib import X,display
from Xlib.ext import xtest
from PIL import Image

CACHED_POINT=(120,140); CACHED_BBOX=(70,110,170,170); TARGET_RGB=(0,204,68); DECOY_RGB=(204,34,68)

def shot(d):
 root=d.screen().root; g=root.get_geometry(); raw=root.get_image(0,0,g.width,g.height,X.ZPixmap,0xffffffff)
 return Image.frombytes('RGB',(g.width,g.height),raw.data,'raw','BGRX')
def rgb_count(im,bbox,rgb):
 n=0
 for p in im.crop(bbox).getdata():
  if p==rgb:n+=1
 return n
def locate_target(im):
 pix=im.load(); xs=[];ys=[]
 for y in range(im.height):
  for x in range(im.width):
   if pix[x,y]==TARGET_RGB: xs.append(x);ys.append(y)
 if not xs: return None, im.width*im.height
 return ((min(xs),min(ys),max(xs)+1,max(ys)+1), im.width*im.height)
def click(d,x,y):
 xtest.fake_input(d,X.MotionNotify,x=x,y=y); d.sync();
 xtest.fake_input(d,X.ButtonPress,1); d.sync(); xtest.fake_input(d,X.ButtonRelease,1); d.sync()
def button1_down(d): return bool(d.screen().root.query_pointer().mask & X.Button1Mask)
def typed_validate(graph):
 if graph=='direct_hint': return False,'ACTUATOR_REQUIRES_ADMISSION_DEPENDENCY'
 return True,None

def main():
 ap=argparse.ArgumentParser();
 ap.add_argument('--case-id',required=True); ap.add_argument('--layout',choices=['unchanged','moved'],required=True); ap.add_argument('--graph',choices=['direct_hint','revalidate_hint'],required=True); ap.add_argument('--validator',choices=['structural_only','typed_roles'],required=True); ap.add_argument('--out',required=True); a=ap.parse_args()
 out=Path(a.out); out.mkdir(parents=True,exist_ok=False); log=out/'app.json'; auth=out/'Xauthority'; auth.write_bytes(b'')
 disp=':'+str(200 + (int(hashlib.sha256(a.case_id.encode()).hexdigest()[:4],16)%300))
 env=os.environ.copy(); env.update(DISPLAY=disp,XAUTHORITY=str(auth)); os.environ.update(DISPLAY=disp,XAUTHORITY=str(auth))
 xv=subprocess.Popen(['Xvfb',disp,'-screen','0','640x480x24','-nolisten','tcp','-ac'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 app=None; d=None
 try:
  for _ in range(100):
   try: d=display.Display(disp); break
   except Exception: time.sleep(.02)
  if d is None: raise RuntimeError('xvfb')
  app=subprocess.Popen(['python',str(Path(__file__).with_name('fixture.py')),'--layout',a.layout,'--log',str(log)],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  for _ in range(150):
   if log.exists():
    im=shot(d)
    if rgb_count(im,CACHED_BBOX,TARGET_RGB)>8000 or any(p==TARGET_RGB for p in im.getdata()): break
   time.sleep(.02)
  im=shot(d); screenshot_sha=hashlib.sha256(im.tobytes()).hexdigest()
  admitted=True; reject=None; branch=None; pixels=0; point=None; lineage=[]
  if a.validator=='typed_roles': admitted,reject=typed_validate(a.graph)
  if admitted:
   if a.graph=='direct_hint':
    branch='direct_historical_hint'; point=CACHED_POINT; lineage=['HINT:HISTORICAL','ACTUATOR']
   else:
    patch_count=rgb_count(im,CACHED_BBOX,TARGET_RGB); pixels=100*60
    lineage=['HINT:HISTORICAL','REVALIDATE_CURRENT']
    if patch_count>=5900:
     branch='cache_hit_current_patch'; point=CACHED_POINT; lineage += ['ADMISSION_DEPENDENCY:CURRENT','ACTUATOR']
    else:
     bbox,work=locate_target(im); pixels+=work
     if bbox is None: admitted=False; reject='CURRENT_TARGET_MISSING'; branch='fallback_missing'
     else:
      branch='fallback_full_current'; point=((bbox[0]+bbox[2])//2,(bbox[1]+bbox[3])//2); lineage += ['ADMISSION_DEPENDENCY:CURRENT','ACTUATOR']
  before=json.loads(log.read_text()) if log.exists() else []
  if admitted: click(d,*point); time.sleep(.08)
  after=json.loads(log.read_text()) if log.exists() else []
  new=after[len(before):]
  result={'case_id':a.case_id,'layout':a.layout,'graph':a.graph,'validator':a.validator,'admitted':admitted,'reject_reason':reject,'branch':branch,'point':point,'lineage':lineage,'pixels_inspected':pixels,'app_events':new,'backend_emissions':1 if admitted else 0,'button1_neutral':not button1_down(d),'screenshot_sha256':screenshot_sha}
  expected = ('TARGET' if admitted and (a.graph=='revalidate_hint' or a.layout=='unchanged') else 'DECOY' if admitted else 'REJECT')
  observed = new[0]['kind'] if new else 'REJECT'
  result['expected_observed']=expected; result['observed']=observed; result['pass']=observed==expected and result['button1_neutral']
  (out/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
  print(json.dumps({'case':a.case_id,'pass':result['pass'],'observed':observed,'branch':branch,'reject':reject},sort_keys=True))
 finally:
  if d:
   try:d.close()
   except:pass
  if app:
   app.terminate();
   try:app.wait(timeout=1)
   except: app.kill()
  xv.terminate();
  try:xv.wait(timeout=1)
  except:xv.kill()
if __name__=='__main__':main()

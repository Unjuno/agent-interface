from __future__ import annotations
import argparse,json,random,subprocess,sys
from pathlib import Path

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--root',required=True); ap.add_argument('--out',required=True); a=ap.parse_args()
 root=Path(a.root); out=Path(a.out); out.mkdir(parents=True,exist_ok=False)
 plan=json.loads((root/'plan.json').read_text())
 sched=[(l,g,v,r) for r in range(plan['repetitions']) for l in plan['layouts'] for g in plan['graphs'] for v in plan['validators']]
 random.Random(plan['seed']).shuffle(sched)
 rows=[]
 for i,(layout,graph,validator,rep) in enumerate(sched):
  cid=f'm{i:02d}-{layout}-{graph}-{validator}-r{rep}'
  case=out/cid
  cp=subprocess.run([sys.executable,str(root/'run_case.py'),'--case-id',cid,'--layout',layout,'--graph',graph,'--validator',validator,'--out',str(case)],capture_output=True,text=True)
  if cp.returncode!=0: raise SystemExit(f'{cid}:rc={cp.returncode}:{cp.stderr}')
  d=json.loads((case/'result.json').read_text()); d['schedule_index']=i; d['rep']=rep; rows.append(d)
 result={'schema':'agent-interface/sensorimotor-graph-hint-transfer-result-v1','task':plan['task'],'rows':rows}
 (out/'formal-result.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 print(json.dumps({'rows':len(rows),'pass':sum(bool(r['pass']) for r in rows)},sort_keys=True))
if __name__=='__main__':main()

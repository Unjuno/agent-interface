import unittest
from run_case import typed_validate
class T(unittest.TestCase):
 def test_direct_rejected(self): self.assertEqual(typed_validate('direct_hint'),(False,'ACTUATOR_REQUIRES_ADMISSION_DEPENDENCY'))
 def test_safe_admitted(self): self.assertEqual(typed_validate('revalidate_hint'),(True,None))
if __name__=='__main__':unittest.main()

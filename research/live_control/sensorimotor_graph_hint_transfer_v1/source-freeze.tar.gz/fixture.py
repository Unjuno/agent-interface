from __future__ import annotations
import argparse,json,time,tkinter as tk
from pathlib import Path

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--layout',choices=['unchanged','moved'],required=True); ap.add_argument('--log',required=True); a=ap.parse_args()
 log=Path(a.log); events=[]
 root=tk.Tk(); root.geometry('640x480+0+0'); root.configure(bg='#202020'); root.title('HintTransferFixture')
 c=tk.Canvas(root,width=640,height=480,bg='#202020',highlightthickness=0); c.pack(fill='both',expand=True)
 # Exact fixed contract: target 100x60. Cached center=(120,140), cached bbox=(70,110,170,170).
 if a.layout=='unchanged': target=(70,110,170,170); decoy=(370,250,470,310)
 else: target=(370,250,470,310); decoy=(70,110,170,170)
 c.create_rectangle(*target,fill='#00cc44',outline='#00cc44',tags=('target',))
 c.create_rectangle(*decoy,fill='#cc2244',outline='#cc2244',tags=('decoy',))
 c.create_text(320,40,text='click green target',fill='white',font=('TkDefaultFont',18))
 def emit(kind,x,y):
  events.append({'kind':kind,'x':x,'y':y,'t_ns':time.monotonic_ns()}); log.write_text(json.dumps(events,sort_keys=True)+'\n')
 def click(ev):
  x,y=ev.x,ev.y
  if target[0] <= x < target[2] and target[1] <= y < target[3]: emit('TARGET',x,y)
  elif decoy[0] <= x < decoy[2] and decoy[1] <= y < decoy[3]: emit('DECOY',x,y)
  else: emit('OTHER',x,y)
 c.bind('<Button-1>',click)
 root.update_idletasks(); log.write_text('[]\n'); root.mainloop()
if __name__=='__main__': main()

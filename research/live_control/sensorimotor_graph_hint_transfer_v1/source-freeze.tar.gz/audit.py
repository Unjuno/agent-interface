from __future__ import annotations
import argparse,json
from pathlib import Path

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--result',required=True); ap.add_argument('--out',required=True); a=ap.parse_args()
 rows=json.loads(Path(a.result).read_text())['rows']; errs=[]
 if len(rows)!=24: errs.append(f'rows:{len(rows)}')
 ids=[r['case_id'] for r in rows]
 if len(ids)!=len(set(ids)): errs.append('duplicate_ids')
 strata={}
 for r in rows:
  k=(r['layout'],r['graph'],r['validator']); strata[k]=strata.get(k,0)+1
  if not r.get('button1_neutral'): errs.append(r['case_id']+':button1')
  if not r.get('pass'): errs.append(r['case_id']+':case_pass')
  l,g,v=r['layout'],r['graph'],r['validator']
  if g=='direct_hint' and v=='structural_only':
   exp='TARGET' if l=='unchanged' else 'DECOY'
   if r['observed']!=exp or r['backend_emissions']!=1: errs.append(r['case_id']+':direct_baseline')
  elif g=='direct_hint' and v=='typed_roles':
   if r['observed']!='REJECT' or r['backend_emissions']!=0 or r['reject_reason']!='ACTUATOR_REQUIRES_ADMISSION_DEPENDENCY': errs.append(r['case_id']+':typed_direct')
  elif g=='revalidate_hint':
   if r['observed']!='TARGET' or r['backend_emissions']!=1: errs.append(r['case_id']+':safe_target')
   expb='cache_hit_current_patch' if l=='unchanged' else 'fallback_full_current'
   if r['branch']!=expb: errs.append(r['case_id']+':branch')
   if r['lineage'][-2:]!=['ADMISSION_DEPENDENCY:CURRENT','ACTUATOR']: errs.append(r['case_id']+':lineage')
 for k,n in strata.items():
  if n!=3: errs.append(f'stratum:{k}:{n}')
 expected={(l,g,v) for l in ['unchanged','moved'] for g in ['direct_hint','revalidate_hint'] for v in ['structural_only','typed_roles']}
 if set(strata)!=expected: errs.append('missing_strata')
 counts={
  'baseline_moved_wrong':sum(r['observed']=='DECOY' for r in rows if r['graph']=='direct_hint' and r['validator']=='structural_only' and r['layout']=='moved'),
  'typed_direct_preinput_reject':sum(r['observed']=='REJECT' and r['backend_emissions']==0 for r in rows if r['graph']=='direct_hint' and r['validator']=='typed_roles'),
  'safe_revalidate_exact':sum(r['observed']=='TARGET' for r in rows if r['graph']=='revalidate_hint'),
  'safe_cache_hits':sum(r['branch']=='cache_hit_current_patch' for r in rows if r['graph']=='revalidate_hint'),
  'safe_fallbacks':sum(r['branch']=='fallback_full_current' for r in rows if r['graph']=='revalidate_hint'),
 }
 if counts != {'baseline_moved_wrong':3,'typed_direct_preinput_reject':6,'safe_revalidate_exact':12,'safe_cache_hits':6,'safe_fallbacks':6}: errs.append('counts:'+repr(counts))
 decision='PASS_TYPED_HINT_TRANSFER_SCOPED' if not errs else 'FAIL_TYPED_HINT_TRANSFER'
 out={'schema':'agent-interface/sensorimotor-graph-hint-transfer-audit-v1','decision':decision,'errors':errs,'counts':counts}
 Path(a.out).write_text(json.dumps(out,indent=2,sort_keys=True)+'\n'); print(json.dumps(out,sort_keys=True)); raise SystemExit(0 if not errs else 1)
if __name__=='__main__':main()

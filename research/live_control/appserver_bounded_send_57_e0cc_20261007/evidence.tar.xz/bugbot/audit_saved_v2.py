"""Additive readback for the follow-up-send fields omitted from audit v1."""
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
BASE = HERE.parent / "actual-v1"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    checks = []

    def check(name, ok, detail=None):
        checks.append({"name": name, "passed": bool(ok), "detail": detail})
        if not ok:
            raise AssertionError(name + (" :: " + str(detail) if detail is not None else ""))

    prior = json.loads((HERE / "audit_saved-result.json").read_text(encoding="utf-8"))
    check("preserved_v1_saved_audit_passed", prior.get("passed") is True and
          prior.get("checks_passed") == prior.get("checks_total") == 77,
          {"passed": prior.get("passed"), "counts": [prior.get("checks_passed"), prior.get("checks_total")]})

    raw_path = BASE / "candidate-v1-blocked" / "raw.json"
    raw_bytes = raw_path.read_bytes()
    raw = json.loads(raw_bytes)
    followup = raw.get("followup_error") or {}
    check("followup_attempt_recorded_as_typed_quarantine", followup.get("type") == "AppServerWriteUncertain" and
          followup.get("reason") == "previous send failure" and followup.get("sent") == 0 and
          followup.get("total") == 0, followup)
    check("followup_sent_journal_unchanged", raw.get("followup_journal_unchanged") is True,
          raw.get("followup_journal_unchanged"))
    sent_rows = [row for row in raw.get("journal_rows", []) if row.get("direction") == "sent"]
    check("followup_added_no_second_sent_journal_row", len(sent_rows) == 1,
          {"sent_rows": len(sent_rows), "methods": [r.get("message", {}).get("method") for r in sent_rows]})
    check("followup_error_trace_is_from_request_call", "fixture/followup" in followup.get("traceback", "") and
          "previous send failure" in followup.get("traceback", ""),
          followup.get("traceback", "")[-500:])

    output = {
        "schema": "appserver-bounded-send-saved-raw-audit-v2",
        "producer_rerun": False,
        "v1_result_preserved": str(HERE / "audit_saved-result.json"),
        "candidate_blocked_raw_sha256": sha(raw_bytes),
        "candidate_blocked_source_sha256": raw.get("source_sha256"),
        "passed": all(row["passed"] for row in checks),
        "checks_passed": sum(row["passed"] for row in checks),
        "checks_total": len(checks),
        "checks": checks,
        "correction": "audit v1's limitation sentence that follow-up was not attempted is superseded for candidate-v1-blocked only; its raw contains a follow-up request, typed previous-send-failure rejection, unchanged journal and one sent row.",
        "scope": [
            "This is saved JSON/source/journal readback only; no Popen/client process was rerun.",
            "The follow-up proves the retained candidate-v1 harness call was rejected before another journal/send row; this audit does not prove physical zero-byte output independently beyond the source's pre-write sticky check and unchanged journal.",
            "The baseline blocked arm required kill rescue and did not execute a follow-up call after rescue.",
            "No Codex app-server, model, GUI, or task effect was tested.",
        ],
    }
    out = HERE / "audit_saved_v2-result.json"
    with out.open("x", encoding="utf-8") as stream:
        json.dump(output, stream, ensure_ascii=False, sort_keys=True, indent=2)
        stream.write("\n")
    print(json.dumps({"passed": output["passed"], "counts": [output["checks_passed"], output["checks_total"]],
                      "result": str(out)}, sort_keys=True))
    return 0 if output["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())

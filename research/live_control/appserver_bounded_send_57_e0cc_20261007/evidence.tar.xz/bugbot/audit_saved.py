"""Independent read-only verification of the six retained real-Popen rows."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1] / "actual-v1"
EXPECTED = {
    "admission-healthy": ("healthy", "a51ed51120a72f289c3d8298a446ab5958ebdff0f0261f770637daaba0862faa"),
    "candidate-v1-healthy": ("healthy", "3994bd0a1ab956cc472e06687355c3247168d606d141064fbaa03b6da1da9bce"),
    "admission-blocked": ("blocked", "a51ed51120a72f289c3d8298a446ab5958ebdff0f0261f770637daaba0862faa"),
    "candidate-v1-blocked": ("blocked", "3994bd0a1ab956cc472e06687355c3247168d606d141064fbaa03b6da1da9bce"),
    "admission-partial_close": ("partial_close", "a51ed51120a72f289c3d8298a446ab5958ebdff0f0261f770637daaba0862faa"),
    "candidate-v1-partial_close": ("partial_close", "3994bd0a1ab956cc472e06687355c3247168d606d141064fbaa03b6da1da9bce"),
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message, checks):
    checks.append({"check": message, "passed": bool(condition)})
    if not condition:
        raise AssertionError(message)


def main():
    checks = []
    observed = sorted(p.name for p in ROOT.iterdir() if p.is_dir())
    require(observed == sorted(EXPECTED), "six expected case directories", checks)
    summaries = {}
    for name, (case, source_sha) in EXPECTED.items():
        directory = ROOT / name
        raw_path = directory / "raw.json"
        receipt_path = ROOT / f"{name}.receipt.json"
        raw_bytes = raw_path.read_bytes()
        raw = json.loads(raw_bytes)
        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
        require(raw.get("case") == case, f"{name}: case identity", checks)
        require(raw.get("source_sha256") == source_sha, f"{name}: declared source hash", checks)
        source_path = Path(raw["source_path"])
        require(source_path.is_file() and digest(source_path.read_bytes()) == source_sha,
                f"{name}: source bytes match raw pin", checks)
        require(receipt.get("exit") == 0 and receipt.get("argv", [])[-2:] == ["--case", case],
                f"{name}: wrapper receipt exit/case", checks)
        require(receipt["argv"][receipt["argv"].index("--source") + 1] == str(source_path),
                f"{name}: receipt source path matches raw", checks)
        journal_path = directory / "client-journal.jsonl"
        journal_bytes = journal_path.read_bytes()
        require(raw.get("journal_bytes") == len(journal_bytes) and
                raw.get("journal_sha256") == digest(journal_bytes),
                f"{name}: retained journal hash/length", checks)
        journal = [json.loads(line) for line in journal_bytes.splitlines() if line]
        require(journal == raw.get("journal_rows"), f"{name}: journal rows match raw", checks)
        require(raw.get("pending_ids") == [] and raw.get("responses") == {},
                f"{name}: no pending/response state at close", checks)
        require(raw.get("reader_alive") is False and raw.get("process_poll") is not None,
                f"{name}: process and reader retired", checks)
        require(all(item.get("closed") is True for item in raw["stream_state"].values()),
                f"{name}: captured streams closed", checks)
        summaries[name] = {
            "case": case,
            "source_sha256": source_sha,
            "raw_sha256": digest(raw_bytes),
            "journal_sha256": digest(journal_bytes),
            "process_poll": raw.get("process_poll"),
            "elapsed_ms": raw.get("request_elapsed_ms"),
            "rescue": raw.get("safety_rescue"),
            "request_error_type": (raw.get("request_error") or raw.get("final_request", {}).get("error") or {}).get("type"),
            "request_error_repr": (raw.get("request_error") or raw.get("final_request", {}).get("error") or {}).get("repr"),
        }

    for name in ("admission-healthy", "candidate-v1-healthy"):
        raw = json.loads((ROOT / name / "raw.json").read_text(encoding="utf-8"))
        rows = raw["journal_rows"]
        correlated = [row["message"] for row in rows
                      if row["direction"] == "received" and row.get("message", {}).get("id") == 1.0]
        require(raw.get("result_digest_matches") is True and raw.get("result_text_matches") is True,
                f"{name}: Unicode response/digest control", checks)
        require(len(correlated) == 1, f"{name}: one float-id response recorded", checks)

    base_blocked = json.loads((ROOT / "admission-blocked/raw.json").read_text(encoding="utf-8"))
    fixed_blocked = json.loads((ROOT / "candidate-v1-blocked/raw.json").read_text(encoding="utf-8"))
    require(base_blocked.get("caller_finished_before_0_6s") is False and
            base_blocked.get("safety_rescue", "").startswith("kill owned Popen child"),
            "blocked baseline needed explicit child-kill rescue", checks)
    require(fixed_blocked.get("caller_finished_before_0_6s") is True and
            fixed_blocked.get("safety_rescue") == "not-needed",
            "blocked bounded-send caller returned without rescue", checks)
    uncertain = fixed_blocked["request_error"]
    require(uncertain.get("type") == "AppServerWriteUncertain" and uncertain.get("sent") == 65536 and
            uncertain.get("total") == 524345 and uncertain.get("reason") == "TimeoutError",
            "blocked bounded-send raw contains typed partial-send result", checks)
    require(len([x for x in fixed_blocked["journal_rows"] if x["direction"] == "sent"]) == 1,
            "blocked candidate has one recorded send and no followup attempted", checks)

    for name in ("admission-partial_close", "candidate-v1-partial_close"):
        raw = json.loads((ROOT / name / "raw.json").read_text(encoding="utf-8"))
        require(raw.get("writer_lock_observed_locked") is True and raw.get("pre_close_writer_alive") is True,
                f"{name}: writer active at close request", checks)
        require(raw.get("close_thread_result") == "returned" and
                raw.get("close_thread_alive_after_3s") is False and
                raw.get("request_thread_alive_after_close_window") is False,
                f"{name}: concurrent close and request threads retired", checks)
        require(raw.get("safety_rescue") == "not-needed", f"{name}: close required no rescue", checks)

    candidate_close = json.loads((ROOT / "candidate-v1-partial_close/raw.json").read_text(encoding="utf-8"))
    error = candidate_close["request_error"]
    require(error.get("type") == "AppServerWriteUncertain" and error.get("sent") == 65536 and
            error.get("total") == 524351 and error.get("reason") == "AppServerError",
            "candidate close-cancellation remained an uncertain partial send", checks)
    base_close = json.loads((ROOT / "admission-partial_close/raw.json").read_text(encoding="utf-8"))
    require((base_close.get("request_error") or {}).get("type") == "BrokenPipeError",
            "baseline concurrent close woke the buffered writer with BrokenPipe", checks)

    output = {
        "schema": "appserver-bounded-send-saved-raw-audit-v1",
        "producers_rerun": False,
        "passed": all(check["passed"] for check in checks),
        "checks_passed": sum(check["passed"] for check in checks),
        "checks_total": len(checks),
        "checks": checks,
        "cases": summaries,
        "limits": [
            "This audit reads saved raw and journal files only.",
            "The harness labels sent journal rows; actual byte progress is claimed only where the bounded writer exposes its sent count.",
            "The blocked control has no attempted follow-up request, so absence of a second journal row is not a direct sticky-quarantine test.",
            "The cases use inert local children, not Codex app-server, model, GUI, or application behavior.",
        ],
    }
    out = Path(__file__).with_name("audit_saved-result.json")
    with out.open("x", encoding="utf-8") as stream:
        json.dump(output, stream, ensure_ascii=False, sort_keys=True, indent=2)
        stream.write("\n")
    print(json.dumps({"passed": output["passed"], "checks_passed": output["checks_passed"],
                      "checks_total": output["checks_total"], "result": str(out)}, sort_keys=True))
    return 0 if output["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())

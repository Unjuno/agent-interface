#!/usr/bin/env python3
"""One-shot benign real-Popen construction harness; intentionally not executed here."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import traceback

CHILD_READY = {"method": "fixture/ready", "params": {"kind": "inert-pipe-peer"}}
CHILD_HEALTHY = r'''
import hashlib, json, sys, time
sys.stdout.write(json.dumps({"method":"fixture/ready","params":{"kind":"inert-pipe-peer"}}, separators=(",",":"))+"\n"); sys.stdout.flush()
line = sys.stdin.readline()
if not line:
    raise SystemExit(31)
request = json.loads(line)
text = request.get("params", {}).get("text", "")
reply = {"id": float(request["id"]), "result": {"utf8_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(), "text": text}}
sys.stdout.write(json.dumps(reply, ensure_ascii=False, separators=(",",":"))+"\n"); sys.stdout.flush()
time.sleep(120)
'''
CHILD_NO_READ = r'''
import json, sys, time
sys.stdout.write(json.dumps({"method":"fixture/ready","params":{"kind":"inert-pipe-peer"}}, separators=(",",":"))+"\n"); sys.stdout.flush()
time.sleep(120)
'''


def now_ns():
    return time.perf_counter_ns()


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def load_client(source):
    source = Path(source).resolve(strict=True)
    spec = importlib.util.spec_from_file_location("bounded_send_client_under_test", source)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load complete client module: {source}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module, source


def exc_row(error):
    if error is None:
        return None
    return {"sent": getattr(error, "sent", None), "total": getattr(error, "total", None), "reason": getattr(error, "reason", None), "type": type(error).__name__, "repr": repr(error), "traceback": "".join(
        traceback.format_exception(type(error), error, error.__traceback__))}


def atomic_create_json(path, value):
    # Exclusive final file; preserve this first run even if another wrapper races.
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2)
        stream.write("\n")


def kill_owned_child(client, row):
    """Safety rescue targets this Popen child only; never signals a process group."""
    proc = getattr(client, "process", None)
    row["rescue_started_ns"] = now_ns()
    if proc is None:
        row["rescue"] = "no-process"
        return
    try:
        status = proc.poll()
        row["rescue_pre_poll"] = status
        if status is None:
            proc.kill()
            row["rescue_action"] = "Popen.kill"
            try:
                row["rescue_wait_return"] = proc.wait(timeout=3)
            except BaseException as error:
                row["rescue_wait_error"] = exc_row(error)
        else:
            row["rescue_action"] = "already-exited"
    except BaseException as error:
        row["rescue_error"] = exc_row(error)
    row["rescue_finished_ns"] = now_ns()


def inspect_client(client, row):
    row["pending_ids"] = sorted(getattr(client, "_pending", set()), key=repr)
    row["responses"] = getattr(client, "_responses", None)
    row["reader_alive"] = getattr(getattr(client, "_reader", None), "is_alive", lambda: None)()
    proc = getattr(client, "process", None)
    row["process_pid"] = getattr(proc, "pid", None)
    row["process_poll"] = None if proc is None else proc.poll()
    row["stream_state"] = {}
    for name in ("stdin", "stdout", "stderr"):
        stream = None if proc is None else getattr(proc, name, None)
        try:
            row["stream_state"][name] = {
                "present": stream is not None,
                "closed": getattr(stream, "closed", None),
                "fd": stream.fileno() if stream is not None and not getattr(stream, "closed", False) else None,
            }
        except BaseException as error:
            row["stream_state"][name] = {"present": stream is not None, "inspection_error": exc_row(error)}


def close_client(client, row, timeout=2):
    close_fn = getattr(client, "close", None)
    if close_fn is None:
        row["close"] = "no-close-method"
        return
    started = now_ns()
    try:
        close_fn(timeout=timeout)
        row["close_result"] = "returned"
    except BaseException as error:
        row["close_error"] = exc_row(error)
    row["close_started_ns"] = started
    row["close_finished_ns"] = now_ns()


def run_case(case, module, source, out):
    row = {
        "schema": "appserver-bounded-send-real-popen-v1",
        "case": case,
        "source_path": str(source),
        "source_sha256": sha256(source.read_bytes()),
        "python": sys.version,
        "platform": sys.platform,
        "argv": list(sys.argv),
        "child_code_sha256": sha256((CHILD_HEALTHY if case == "healthy" else CHILD_NO_READ).encode()),
        "child_command": [sys.executable, "-B", "-c", CHILD_HEALTHY if case == "healthy" else CHILD_NO_READ],
        "events": [],
        "errors": [],
        "safety_rescue": None,
        "sent_bytes_directly_measured": False,
        "sent_bytes_status": "unknown; only the client journal is captured",
    }
    journal_path = out / "client-journal.jsonl"
    client = None
    request_thread = None
    close_thread = None
    result_box = {"result": None, "error": None}
    request_started = threading.Event()
    client_construct_start = now_ns()
    try:
        # Deliberately use the module default process_factory=subprocess.Popen.
        client = module.CodexAppServerClient(row["child_command"], journal_path=str(journal_path))
        row["client_construct_ns"] = now_ns() - client_construct_start
        row["process_pid"] = client.process.pid
        row["process_args"] = getattr(client.process, "args", None)
        row["process_group_owned"] = getattr(client, "_owns_process_group", None)
        try:
            ready = client.wait_notification(lambda item: item.get("method") == "fixture/ready", timeout=2)
            row["ready_notification"] = ready
            row["ready_ns"] = now_ns()
        except BaseException as error:
            row["errors"].append({"phase": "wait-ready", **exc_row(error)})
            raise

        if case == "healthy":
            payload = "日本語🙂" * 8
            expected_digest = sha256(payload.encode("utf-8"))
            row["input_chars"] = len(payload)
            row["input_utf8_bytes"] = len(payload.encode("utf-8"))
            row["input_sha256"] = expected_digest
            started = now_ns()
            row["request_started_ns"] = started
            try:
                result = client.request("fixture/healthy", {"text": payload}, timeout=1)
                row["result"] = result
                row["expected_result_digest"] = expected_digest
                row["result_digest_matches"] = result.get("utf8_sha256") == expected_digest
                row["result_text_matches"] = result.get("text") == payload
            except BaseException as error:
                row["errors"].append({"phase": "request", **exc_row(error)})
            row["request_finished_ns"] = now_ns()
            row["request_elapsed_ms"] = (row["request_finished_ns"] - started) / 1e6
            # The child intentionally remains alive until owned teardown.

        elif case == "blocked":
            payload = "B" * (512 * 1024)
            row["input_chars"] = len(payload)
            row["input_utf8_bytes"] = len(payload.encode("utf-8"))

            def requester():
                result_box["started_ns"] = now_ns()
                request_started.set()
                try:
                    result_box["result"] = client.request("fixture/blocked", {"text": payload}, timeout=0.1)
                except BaseException as error:
                    result_box["error"] = error
                finally:
                    result_box["finished_ns"] = now_ns()

            request_thread = threading.Thread(target=requester, name="bounded-send-blocked-request", daemon=True)
            request_thread.start()
            if not request_started.wait(1):
                row["errors"].append({"phase": "request-start", "type": "TimeoutError", "repr": "request thread did not start"})
            request_thread.join(timeout=0.6)
            row["caller_finished_before_0_6s"] = not request_thread.is_alive()
            row["request_started_ns"] = result_box.get("started_ns")
            row["request_finished_ns"] = result_box.get("finished_ns")
            row["request_elapsed_ms"] = None if row["request_finished_ns"] is None else (row["request_finished_ns"] - row["request_started_ns"]) / 1e6
            row["result"] = result_box.get("result")
            row["request_error"] = exc_row(result_box.get("error"))
            if request_thread.is_alive():
                row["safety_rescue"] = "kill owned Popen child after 0.6s caller observation window"
                kill_owned_child(client, row)
                request_thread.join(timeout=3)
                row["request_thread_alive_after_rescue"] = request_thread.is_alive()
            else:
                row["safety_rescue"] = "not-needed"

            if row["caller_finished_before_0_6s"]:
                before = journal_path.read_bytes()
                try:
                    row["followup_result"] = client.request("fixture/followup", timeout=0.1)
                except BaseException as error:
                    row["followup_error"] = exc_row(error)
                row["followup_journal_unchanged"] = journal_path.read_bytes() == before

        elif case == "partial_close":
            payload = "C" * (512 * 1024)
            row["input_chars"] = len(payload)
            row["input_utf8_bytes"] = len(payload.encode("utf-8"))

            def requester():
                result_box["started_ns"] = now_ns()
                request_started.set()
                try:
                    result_box["result"] = client.request("fixture/partial-close", {"text": payload}, timeout=20)
                except BaseException as error:
                    result_box["error"] = error
                finally:
                    result_box["finished_ns"] = now_ns()

            request_thread = threading.Thread(target=requester, name="bounded-send-close-request", daemon=True)
            request_thread.start()
            request_started.wait(1)
            # Wait until the client has entered the write critical section and
            # the request remains active. This avoids an arbitrary fixed sleep.
            wait_for_lock = getattr(client, "_write_lock", None)
            wait_deadline = time.monotonic() + 1
            while (time.monotonic() < wait_deadline and request_thread.is_alive()
                   and not (wait_for_lock and wait_for_lock.locked())):
                time.sleep(0.001)
            row["writer_lock_observed_locked"] = bool(wait_for_lock and wait_for_lock.locked())
            row["writer_lock_observation_wait_ms"] = (1 - max(0, wait_deadline - time.monotonic())) * 1000
            if row["writer_lock_observed_locked"] and request_thread.is_alive():
                # Give the large frame time to reach the non-reading pipe's
                # backpressure path; record this construction interval.
                time.sleep(0.05)
            row["pre_close_writer_alive"] = request_thread.is_alive()
            row["writer_alive_at_close_start"] = request_thread.is_alive()
            row["close_requested_ns"] = now_ns()

            def closer():
                row["close_thread_started_ns"] = now_ns()
                try:
                    client.close(timeout=1)
                    row["close_thread_result"] = "returned"
                except BaseException as error:
                    row["close_thread_error"] = exc_row(error)
                finally:
                    row["close_thread_finished_ns"] = now_ns()

            close_thread = threading.Thread(target=closer, name="bounded-send-concurrent-close", daemon=True)
            close_thread.start()
            close_thread.join(timeout=3)
            row["close_thread_alive_after_3s"] = close_thread.is_alive()
            request_thread.join(timeout=0.5)
            row["request_thread_alive_after_close_window"] = request_thread.is_alive()
            if request_thread.is_alive() or close_thread.is_alive():
                row["safety_rescue"] = "kill owned Popen child after concurrent-close observation window"
                kill_owned_child(client, row)
                if close_thread.is_alive():
                    close_thread.join(timeout=2)
                if request_thread.is_alive():
                    request_thread.join(timeout=2)
            else:
                row["safety_rescue"] = "not-needed"
            row["request_started_ns"] = result_box.get("started_ns")
            row["request_finished_ns"] = result_box.get("finished_ns")
            row["request_elapsed_ms"] = None if row["request_finished_ns"] is None else (row["request_finished_ns"] - row["request_started_ns"]) / 1e6
            row["request_result"] = result_box.get("result")
            row["request_error"] = exc_row(result_box.get("error"))
            # Keep close ordering safe after rescue: do not call close again
            # concurrently with a writer or an in-flight close call.
            if close_thread.is_alive():
                row["post_rescue_close_pending"] = True

        else:
            raise ValueError(f"unknown case: {case}")

    except BaseException as error:
        row["errors"].append({"phase": "case", **exc_row(error)})
    finally:
        if client is not None:
            if request_thread is not None and request_thread.is_alive():
                kill_owned_child(client, row)
                request_thread.join(timeout=2)
            if close_thread is not None and close_thread.is_alive():
                kill_owned_child(client, row)
                close_thread.join(timeout=2)
            if close_thread is None or not close_thread.is_alive():
                # For the healthy/blocked arms or a completed partial_close arm.
                close_client(client, row, timeout=1)
            try:
                inspect_client(client, row)
            except BaseException as error:
                row["errors"].append({"phase": "final-inspection", **exc_row(error)})
        if journal_path.exists():
            try:
                journal = journal_path.read_bytes()
                row["journal_bytes"] = len(journal)
                row["journal_sha256"] = sha256(journal)
                row["journal_rows"] = [json.loads(line) for line in journal.splitlines() if line]
            except BaseException as error:
                row["errors"].append({"phase": "journal-readback", **exc_row(error)})
        if request_thread is not None:
            row["request_thread_alive_final"] = request_thread.is_alive()
            row["final_request"] = {"started_ns": result_box.get("started_ns"), "finished_ns": result_box.get("finished_ns"), "error": exc_row(result_box.get("error")), "result": result_box.get("result")}
        if close_thread is not None:
            row["close_thread_alive_final"] = close_thread.is_alive()
        row["finished_ns"] = now_ns()
        atomic_create_json(out / "raw.json", row)
    return 0 if not row["errors"] else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True, help="absolute path to the exact complete client module .py")
    parser.add_argument("--out", required=True, help="new output directory; must not already exist")
    parser.add_argument("--case", required=True, choices=("healthy", "blocked", "partial_close"))
    args = parser.parse_args()
    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=False)
    try:
        module, source = load_client(args.source)
    except BaseException as error:
        source = Path(args.source).resolve()
        row = {
            "schema": "appserver-bounded-send-real-popen-v1",
            "case": args.case,
            "source_path": str(source),
            "source_sha256": sha256(source.read_bytes()) if source.is_file() else None,
            "argv": list(sys.argv),
            "errors": [{"phase": "source-load", **exc_row(error)}],
            "finished_ns": now_ns(),
        }
        atomic_create_json(out / "raw.json", row)
        return 1
    return run_case(args.case, module, source, out)


if __name__ == "__main__":
    raise SystemExit(main())

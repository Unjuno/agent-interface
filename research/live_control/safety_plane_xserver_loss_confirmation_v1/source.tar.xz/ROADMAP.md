# SAFETY-PLANE-XSERVER-LOSS-CONFIRMATION-20260917-001
H: backend loss after confirmed key-down must prevent any truthful verified-release claim.
T: private Xvfb/Tk/XTEST owner+cleanup-watchdog; compare server running vs SIGKILL only.
D: running verified release; lost server explicit RELEASE_UNCONFIRMED_BACKEND_LOST; never synthesize neutral evidence.
C: Xvfb process death also kills app/session and is not a physical-device failure model.
U: Linux/X11 synthetic backend only; no host/power/cross-platform claim.
Roadmap: construction -> freeze -> ownership reread -> 8 first cases -> audit/corruptions -> GitHub publication.

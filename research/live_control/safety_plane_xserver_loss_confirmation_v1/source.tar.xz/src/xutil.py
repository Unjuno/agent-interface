from Xlib import X,display
from Xlib.ext import xtest
KEYSYM=0xffc5

def conn(): return display.Display()
def keycode(d): return d.keysym_to_keycode(KEYSYM)
def down_state(d,k):
    q=d.query_keymap(); return bool(q[k>>3] & (1<<(k&7)))
def key(d,k,is_down):
    xtest.fake_input(d,X.KeyPress if is_down else X.KeyRelease,k); d.sync()

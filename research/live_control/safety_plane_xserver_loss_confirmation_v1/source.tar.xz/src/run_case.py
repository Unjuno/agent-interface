import json,os,signal,subprocess,sys,time,pathlib
case_id,arm,display_num,outdir=sys.argv[1],sys.argv[2],int(sys.argv[3]),pathlib.Path(sys.argv[4])
outdir.mkdir(parents=True,exist_ok=False)
env=os.environ.copy(); env['DISPLAY']=f':{display_num}'; env['XAUTHORITY']=str(outdir/'empty.Xauthority'); pathlib.Path(env['XAUTHORITY']).touch()
xvfb=subprocess.Popen(['Xvfb',env['DISPLAY'],'-screen','0','640x480x24','-ac'],stdout=subprocess.DEVNULL,stderr=(outdir/'xvfb.stderr').open('wb'),env=env)
time.sleep(.15)
openbox=subprocess.Popen(['openbox'],stdout=subprocess.DEVNULL,stderr=(outdir/'openbox.stderr').open('wb'),env=env)
receiver=subprocess.Popen([sys.executable,str(pathlib.Path(__file__).with_name('receiver.py')),str(outdir/'app.json')],stdout=subprocess.DEVNULL,stderr=(outdir/'receiver.stderr').open('wb'),env=env)
time.sleep(.25)
subprocess.run(['wmctrl','-a','ai871'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(.05)
life_r,life_w=os.pipe(); go_r,go_w=os.pipe()
for fd in [life_r,life_w,go_r]: os.set_inheritable(fd,True)
owner=subprocess.Popen([sys.executable,str(pathlib.Path(__file__).with_name('owner.py')),str(life_w),str(go_r)],stdout=subprocess.PIPE,stderr=(outdir/'owner.stderr').open('wb'),text=True,env=env,pass_fds=(life_w,go_r))
wd=subprocess.Popen([sys.executable,str(pathlib.Path(__file__).with_name('watchdog.py')),str(life_r),str(owner.pid)],stdout=subprocess.PIPE,stderr=(outdir/'watchdog.stderr').open('wb'),text=True,env=env,pass_fds=(life_r,))
os.close(life_r); os.close(life_w); os.close(go_r)
os.write(go_w,b'G'); os.close(go_w)
while True:
    line=owner.stdout.readline()
    if not line: raise RuntimeError('owner exited before PRESS_CONFIRMED')
    try:
        press=json.loads(line)
        if press.get('event')=='PRESS_CONFIRMED': break
    except json.JSONDecodeError:
        continue
press_ns=press['press_ns']
def until(target):
    while time.perf_counter_ns()<target: time.sleep(.001)
if arm=='SERVER_SIGKILL':
    until(press_ns+50_000_000); os.kill(xvfb.pid,signal.SIGKILL); xvfb.wait()
until(press_ns+75_000_000); os.kill(owner.pid,signal.SIGKILL); owner.wait()
wd_lines=wd.communicate(timeout=2)[0].strip().splitlines(); receipt=None
for line in reversed(wd_lines):
    try:
        obj=json.loads(line)
        if obj.get('event')=='cleanup_receipt': receipt=obj; break
    except Exception: pass
if receipt is None: raise RuntimeError('watchdog receipt missing')
until(press_ns+250_000_000)
app=None
try: app=json.loads((outdir/'app.json').read_text())
except Exception: app=None
terminal={'available':False}
if arm=='SERVER_RUNNING':
    try:
        os.environ['DISPLAY']=env['DISPLAY']; os.environ['XAUTHORITY']=env['XAUTHORITY']
        from Xlib import display
        d=display.Display(); k=press['keycode']; q=d.query_keymap(); terminal={'available':True,'key_down':bool(q[k>>3] & (1<<(k&7)))}; d.close()
    except Exception as e: terminal={'available':False,'error':type(e).__name__}
result={'case_id':case_id,'arm':arm,'press':press,'owner_rc':owner.returncode,'xvfb_rc':xvfb.poll(),'receipt':receipt,'app':app,'terminal':terminal}
(outdir/'result.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
for p in [receiver,openbox]:
    if p.poll() is None:
        p.terminate()
        try:p.wait(timeout=.5)
        except: p.kill(); p.wait()
if xvfb.poll() is None:
    xvfb.terminate(); xvfb.wait(timeout=1)
print(json.dumps(result,separators=(',',':')))

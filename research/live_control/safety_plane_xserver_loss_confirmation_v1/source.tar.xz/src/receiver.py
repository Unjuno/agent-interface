import json,sys,tkinter as tk,time
out=sys.argv[1]
r=tk.Tk(); r.geometry('240x120+20+20'); r.title('ai871')
log=[]
def rec(kind,e):
    log.append({'kind':kind,'keysym':e.keysym,'ns':time.perf_counter_ns()})
    open(out,'w').write(json.dumps(log,separators=(',',':')))
r.bind('<KeyPress-F8>',lambda e: rec('press',e))
r.bind('<KeyRelease-F8>',lambda e: rec('release',e))
r.after(4000,r.destroy); r.mainloop()

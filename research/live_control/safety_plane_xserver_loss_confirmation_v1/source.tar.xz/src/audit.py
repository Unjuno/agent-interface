import json,sys,pathlib
root=pathlib.Path(sys.argv[1]); rows=[]; errors=[]
for p in sorted(root.glob('*/result.json')):
    r=json.loads(p.read_text()); rows.append(r); arm=r['arm']; rec=r['receipt']; app=r['app'] or []
    if r['owner_rc'] != -9: errors.append([r['case_id'],'owner_not_sigkill'])
    if rec.get('authority')!='cleanup_only' or rec.get('task_input_granted') is not False: errors.append([r['case_id'],'authority'])
    if arm=='SERVER_RUNNING':
        if rec.get('status')!='RELEASE_CONFIRMED' or rec.get('verified_empty') is not True: errors.append([r['case_id'],'running_not_confirmed'])
        if [x.get('kind') for x in app].count('press')!=1 or [x.get('kind') for x in app].count('release')!=1: errors.append([r['case_id'],'app_lifecycle'])
        if not r['terminal'].get('available') or r['terminal'].get('key_down'): errors.append([r['case_id'],'terminal'])
    else:
        if r.get('xvfb_rc') != -9: errors.append([r['case_id'],'server_not_killed'])
        if rec.get('status')=='RELEASE_CONFIRMED' or rec.get('verified_empty') is True: errors.append([r['case_id'],'false_confirmation'])
        if rec.get('status')!='RELEASE_UNCONFIRMED_BACKEND_LOST': errors.append([r['case_id'],'wrong_unconfirmed'])
        if r['terminal'].get('available'): errors.append([r['case_id'],'invented_terminal'])
print(json.dumps({'rows':len(rows),'errors':errors,'decision':'PASS_BACKEND_LOSS_CONFIRMATION_FAIL_CLOSED_SCOPED' if not errors else 'FAIL'},sort_keys=True,indent=2))
if errors: raise SystemExit(1)

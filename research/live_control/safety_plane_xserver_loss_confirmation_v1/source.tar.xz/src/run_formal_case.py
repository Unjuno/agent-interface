import json,pathlib,subprocess,sys
case=json.loads(sys.argv[1]); root=pathlib.Path(sys.argv[2]); out=root/case['id']
if out.exists(): raise SystemExit('RERUN_REFUSED_EXISTING_CASE')
cmd=[sys.executable,str(pathlib.Path(__file__).with_name('run_case.py')),case['id'],case['arm'],str(case['display']),str(out)]
r=subprocess.run(cmd,check=False,capture_output=True,text=True)
(root/f"{case['id']}.stdout").write_text(r.stdout); (root/f"{case['id']}.stderr").write_text(r.stderr)
if r.returncode: raise SystemExit(r.returncode)

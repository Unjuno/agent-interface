import json,os,sys,time
life_fd=int(sys.argv[1]); owner_pid=int(sys.argv[2])
# wait EOF on lifetime pipe
while True:
    b=os.read(life_fd,1)
    if b==b'': break
death_ns=time.perf_counter_ns()
# require owner gone/zombie-ish from kill(0) failure OR /proc state Z
state='unknown'
try:
    txt=open(f'/proc/{owner_pid}/stat').read().split(); state=txt[2]
except Exception: state='gone'
receipt={'event':'cleanup_receipt','death_confirm_ns':death_ns,'owner_state':state,'authority':'cleanup_only','task_input_granted':False,'release_requested':False,'verified_empty':False,'status':'RELEASE_UNCONFIRMED_BACKEND_LOST'}
try:
    from xutil import conn,keycode,key,down_state
    d=conn(); k=keycode(d); receipt['keycode']=k; receipt['key_down_before']=down_state(d,k)
    receipt['release_requested']=True; receipt['release_request_ns']=time.perf_counter_ns()
    key(d,k,False)
    receipt['verified_empty']=not down_state(d,k); receipt['verify_ns']=time.perf_counter_ns()
    receipt['status']='RELEASE_CONFIRMED' if receipt['verified_empty'] else 'RELEASE_UNCONFIRMED'
except Exception as e:
    receipt['backend_error_type']=type(e).__name__; receipt['backend_error']=str(e)
print(json.dumps(receipt,separators=(',',':')),flush=True)

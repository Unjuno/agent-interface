import json,os,sys,time
from xutil import conn,keycode,key,down_state
life_fd=int(sys.argv[1]); go_fd=int(sys.argv[2])
os.read(go_fd,1)
d=conn(); k=keycode(d); key(d,k,True)
print(json.dumps({'event':'PRESS_CONFIRMED','press_ns':time.perf_counter_ns(),'keycode':k,'down':down_state(d,k)}),flush=True)
while True: time.sleep(1)

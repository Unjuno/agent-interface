import copy,json,pathlib,shutil,subprocess,sys,tempfile
src=pathlib.Path(sys.argv[1]); audit=pathlib.Path(__file__).with_name('audit.py')
rows=[json.loads(p.read_text()) for p in sorted(src.glob('*/result.json'))]
def check(name,mut):
    with tempfile.TemporaryDirectory() as td:
        root=pathlib.Path(td)
        for r in rows:
            d=root/r['case_id']; d.mkdir(); (d/'result.json').write_text(json.dumps(r))
        mut(root)
        q=subprocess.run([sys.executable,str(audit),str(root)],capture_output=True,text=True)
        if q.returncode==0: raise SystemExit(f'mutation accepted: {name}')
checks=[]
def m1(root):
    p=next(p for p in root.glob('*/result.json') if json.loads(p.read_text())['arm']=='SERVER_SIGKILL'); r=json.loads(p.read_text()); r['receipt']['status']='RELEASE_CONFIRMED'; r['receipt']['verified_empty']=True; p.write_text(json.dumps(r))
def m2(root):
    p=next(root.glob('*/result.json')); r=json.loads(p.read_text()); r['receipt']['authority']='task'; p.write_text(json.dumps(r))
def m3(root):
    p=next(p for p in root.glob('*/result.json') if json.loads(p.read_text())['arm']=='SERVER_SIGKILL'); r=json.loads(p.read_text()); r['terminal']={'available':True,'key_down':False}; p.write_text(json.dumps(r))
for n,m in [('false_confirmation',m1),('authority_escalation',m2),('invented_terminal',m3)]: check(n,m); checks.append(n)
print(json.dumps({'rejected':checks,'count':len(checks)}))

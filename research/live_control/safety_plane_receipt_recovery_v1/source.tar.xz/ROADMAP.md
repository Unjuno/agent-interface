# #816 container roadmap

Task: SAFETY-PLANE-RECEIPT-RECOVERY-20260917-001

## H
With physical release semantics fixed, retaining the compact post-release safety receipt in a private owner-local fsynced journal after verified key-up preserves evidence across an ordinary data-plane outage, whereas one-shot PIPE_ONLY delivery loses the receipt. Journal work must never precede physical release verification.

## T
1. Excluded construction: healthy delivery equivalence and blocked-pipe discriminator.
2. Harden independent auditor and copied-evidence mutations.
3. Freeze exact sources/schedule/gates; formal remains 0/8 until remote source-first freeze.
4. Formal: 4 reps x {PIPE_ONLY, OWNER_LOCAL_JOURNAL}, alternating, fresh Xvfb/Tk sessions, at most 4 cases per outer invocation, first outcomes only.
5. Postformal audit/source rehash/mutations; publish evidence.

## D
PASS_SAFETY_RECEIPT_RECOVERY_SCOPED iff all 8 physically release once by cancel before data-plane recovery; PIPE_ONLY loses ordinary receipt 4/4 without fabrication; JOURNAL recovers exact receipt 4/4 after unblock with release_injected <= verified_empty <= journal_write <= recovered_publish; authority none; no duplicate publish/release; journal begins only after verified release.

## C
A journal might appear successful only because it participates in the critical release path, or baseline may not actually lose the receipt if pipe backpressure is not exposed. The audit therefore checks temporal ordering and the blocked-pipe discriminator explicitly.

## U
Fresh reconstruction from the public Issue contract, not byte-identical predecessor source. Linux/Xvfb/XTEST/Tk/local-fs/pipe only; fsync is not power-loss proof; no model/game/cross-platform claim.

import argparse,json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent; plan=json.loads((P/'plan.json').read_text())
a=argparse.ArgumentParser();a.add_argument('--formal-root',type=Path,required=True);a.add_argument('--start',type=int,required=True);a.add_argument('--count',type=int,required=True);q=a.parse_args()
if q.count<1 or q.count>plan['outer_chunk_max']:raise SystemExit('count exceeds frozen outer_chunk_max')
if q.start<0 or q.start+q.count>plan['formal_cases']:raise SystemExit('range')
q.formal_root.mkdir(parents=True,exist_ok=True)
for i in range(q.start,q.start+q.count):
    cid=plan['case_ids'][i]; out=q.formal_root/cid
    if out.exists():raise SystemExit(f'rerun refused: {cid}')
    cmd=['python',str(P/'run_case.py'),'--out',str(out),'--case',cid,'--policy',plan['schedule'][i],'--display-num',str(plan['display_nums'][i]),'--blocked']
    cp=subprocess.run(cmd,text=True,capture_output=True)
    (q.formal_root/f'{cid}.stdout').write_text(cp.stdout);(q.formal_root/f'{cid}.stderr').write_text(cp.stderr)
    if cp.returncode:raise SystemExit(f'{cid} failed rc={cp.returncode}')
print(json.dumps({'completed':plan['case_ids'][q.start:q.start+q.count],'start':q.start,'count':q.count}))

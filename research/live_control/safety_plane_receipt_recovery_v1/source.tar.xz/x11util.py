import ctypes, ctypes.util, time

X11=ctypes.CDLL(ctypes.util.find_library('X11'))
Xtst=ctypes.CDLL(ctypes.util.find_library('Xtst'))
DisplayP=ctypes.c_void_p
X11.XOpenDisplay.argtypes=[ctypes.c_char_p]; X11.XOpenDisplay.restype=DisplayP
X11.XCloseDisplay.argtypes=[DisplayP]
X11.XKeysymToKeycode.argtypes=[DisplayP, ctypes.c_ulong]; X11.XKeysymToKeycode.restype=ctypes.c_ubyte
X11.XSetInputFocus.argtypes=[DisplayP, ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
X11.XSync.argtypes=[DisplayP, ctypes.c_int]
X11.XQueryKeymap.argtypes=[DisplayP, ctypes.c_char_p]
Xtst.XTestFakeKeyEvent.argtypes=[DisplayP, ctypes.c_uint, ctypes.c_int, ctypes.c_ulong]; Xtst.XTestFakeKeyEvent.restype=ctypes.c_int
F8_KEYSYM=0xFFC5

def open_display(name: str):
    d=X11.XOpenDisplay(name.encode())
    if not d: raise RuntimeError(f'XOpenDisplay failed {name}')
    return d

def keycode(d):
    kc=int(X11.XKeysymToKeycode(d,F8_KEYSYM))
    if not kc: raise RuntimeError('F8 keycode unavailable')
    return kc

def set_focus(d,xid:int):
    # RevertToParent=2, CurrentTime=0
    X11.XSetInputFocus(d, int(xid), 2, 0); X11.XSync(d,0)

def fake_key(d,kc:int,down:bool):
    if not Xtst.XTestFakeKeyEvent(d,kc,1 if down else 0,0): raise RuntimeError('XTestFakeKeyEvent failed')
    X11.XSync(d,0)

def is_key_down(d,kc:int):
    buf=ctypes.create_string_buffer(32); X11.XQueryKeymap(d,buf)
    b=buf.raw[kc//8]
    return bool(b & (1 << (kc%8)))

def query_f8(display:str):
    d=open_display(display)
    try:
        kc=keycode(d); return is_key_down(d,kc)
    finally: X11.XCloseDisplay(d)

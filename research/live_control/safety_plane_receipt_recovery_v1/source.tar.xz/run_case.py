import argparse,json,os,subprocess,time,signal,fcntl,select
from pathlib import Path
from x11util import query_f8
P=Path(__file__).resolve().parent
pa=argparse.ArgumentParser();pa.add_argument('--out',type=Path,required=True);pa.add_argument('--case',required=True);pa.add_argument('--policy',choices=['PIPE_ONLY','OWNER_LOCAL_JOURNAL'],required=True);pa.add_argument('--display-num',type=int,required=True);pa.add_argument('--blocked',action='store_true');a=pa.parse_args()
a.out.mkdir(parents=True,exist_ok=False); display=f':{a.display_num}'
procs=[]
def stop(p):
    if p and p.poll() is None:
        p.terminate()
        try:p.wait(2)
        except subprocess.TimeoutExpired:p.kill();p.wait()

xv=subprocess.Popen(['Xvfb',display,'-screen','0','800x600x24','-nolisten','tcp'],stdout=subprocess.DEVNULL,stderr=(a.out/'xvfb.stderr').open('wb'));procs.append(xv)
for _ in range(100):
    if xv.poll() is not None: raise RuntimeError('Xvfb died')
    t=subprocess.run(['xdpyinfo','-display',display],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    if t.returncode==0:break
    time.sleep(.02)
else:raise RuntimeError('Xvfb not ready')
env=os.environ.copy();env['DISPLAY']=display
recv=subprocess.Popen(['python',str(P/'receiver.py'),'--log',str(a.out/'receiver.jsonl')],env=env,stdout=subprocess.PIPE,stderr=(a.out/'receiver.stderr').open('wb'),text=True);procs.append(recv)
ready=json.loads(recv.stdout.readline());xid=int(ready['xid'])
# cancel and receipt channels
cancel_r,cancel_w=os.pipe(); receipt_r,receipt_w=os.pipe(); ctl_r,ctl_w=os.pipe(); c_trig_r,c_trig_w=os.pipe(); d_trig_r,d_trig_w=os.pipe()
# nonblocking receipt writer; optionally fill pipe completely before press
flags=fcntl.fcntl(receipt_w,fcntl.F_GETFL);fcntl.fcntl(receipt_w,fcntl.F_SETFL,flags|os.O_NONBLOCK)
filler=0
if a.blocked:
    chunk=b'X'*4096
    while True:
        try:filler+=os.write(receipt_w,chunk)
        except BlockingIOError:break
cancel_log=a.out/'cancel.json';drain_log=a.out/'drain.json';token=f'cancel-{a.case}'
cancel=subprocess.Popen(['python',str(P/'cancel_helper.py'),'--trigger-fd',str(c_trig_r),'--cancel-fd',str(cancel_w),'--delay-ms','75','--token',token,'--log',str(cancel_log)],pass_fds=(c_trig_r,cancel_w));procs.append(cancel)
drain=None
if a.blocked:
    drain=subprocess.Popen(['python',str(P/'drain_helper.py'),'--trigger-fd',str(d_trig_r),'--read-fd',str(receipt_r),'--delay-ms','250','--log',str(drain_log)],pass_fds=(d_trig_r,receipt_r));procs.append(drain)
owner=subprocess.Popen(['python',str(P/'owner.py'),'--display',display,'--xid',str(xid),'--case',a.case,'--policy',a.policy,'--cancel-fd',str(cancel_r),'--receipt-fd',str(receipt_w),'--control-fd',str(ctl_w),'--journal',str(a.out/'owner-journal.jsonl')],env=env,pass_fds=(cancel_r,receipt_w,ctl_w),stderr=(a.out/'owner.stderr').open('wb'));procs.append(owner)
os.close(cancel_r);os.close(ctl_w);os.close(c_trig_r);os.close(d_trig_r)
# read first control line press confirmed
buf=b''
while b'\n' not in buf:
    r,_,_=select.select([ctl_r],[],[],5)
    if not r: raise RuntimeError('owner press timeout')
    buf+=os.read(ctl_r,65536)
line,rest=buf.split(b'\n',1);press=json.loads(line);press_ns=int(press['press_ns'])
os.write(c_trig_w,(str(press_ns)+'\n').encode());os.close(c_trig_w)
if a.blocked:os.write(d_trig_w,(str(press_ns)+'\n').encode());os.close(d_trig_w)
owner.wait(timeout=5);cancel.wait(timeout=2)
# remaining control
more=rest
while True:
    b=os.read(ctl_r,65536)
    if not b:break
    more+=b
controls=[json.loads(x) for x in more.splitlines() if x.strip()]
terminal=next(x for x in controls if x.get('kind')=='OWNER_TERMINAL')
if drain:drain.wait(timeout=3)
# ordinary receipt: healthy reads JSON; blocked pipe was filler drained, one-shot owner write must have failed
ordinary=None
if not a.blocked:
    flags=fcntl.fcntl(receipt_r,fcntl.F_GETFL);fcntl.fcntl(receipt_r,fcntl.F_SETFL,flags|os.O_NONBLOCK)
    try:
        b=os.read(receipt_r,65536)
        if b: ordinary=json.loads(b.decode().strip())
    except BlockingIOError:pass
recovered=None
if a.blocked and a.policy=='OWNER_LOCAL_JOURNAL':
    dr=json.loads(drain_log.read_text()); lines=[json.loads(x) for x in (a.out/'owner-journal.jsonl').read_text().splitlines() if x.strip()]
    if len(lines)!=1: raise RuntimeError('journal line count')
    recovered={**lines[0],'recovery_source':'owner_local_journal','authority':'none','recovered_publish_ns':time.perf_counter_ns()}
    (a.out/'recovered.json').write_text(json.dumps(recovered,sort_keys=True,indent=2)+'\n')
time.sleep(.05)
terminal_query_down=query_f8(display)
# stop receiver then parse events
stop(recv);stop(xv)
receiver_rows=[json.loads(x) for x in (a.out/'receiver.jsonl').read_text().splitlines() if x.strip()]
result={'schema':'safety-receipt-recovery-case-v1','case':a.case,'policy':a.policy,'blocked':a.blocked,'display':display,'filler_bytes':filler,'press_control':press,'owner_terminal':terminal,'ordinary_receipt':ordinary,'recovered_receipt':recovered,'cancel':json.loads(cancel_log.read_text()),'drain':json.loads(drain_log.read_text()) if drain_log.exists() else None,'receiver_events':receiver_rows,'parent_terminal_f8_down':terminal_query_down}
(a.out/'case.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps({'case':a.case,'policy':a.policy,'blocked':a.blocked,'ordinary_write':terminal['ordinary_write'],'events':[r['kind'] for r in receiver_rows],'recovered':recovered is not None,'release_before_recovery': (not a.blocked) or terminal['receipt']['verified_empty_ns'] < result['drain']['recovery_ns']}))

import json,sys
from pathlib import Path

def audit_case(path:Path):
    e=[]
    try:d=json.loads((path/'case.json').read_text())
    except Exception as x:return [f'case_read:{type(x).__name__}']
    try:
        pol=d['policy'];blocked=d['blocked'];t=d['owner_terminal'];r=t['receipt'];events=d['receiver_events']
        kp=[x for x in events if x.get('kind')=='KeyPress'];kr=[x for x in events if x.get('kind')=='KeyRelease']
        if len(kp)!=1:e.append('app_keypress_count')
        if len(kr)!=1:e.append('app_keyrelease_count')
        if r.get('cause')!='cancel':e.append('release_cause')
        if t.get('release_count')!=1:e.append('release_count')
        if t.get('terminal_f8_down') is not False:e.append('owner_terminal_key')
        if d.get('parent_terminal_f8_down') is not False:e.append('parent_terminal_key')
        if r.get('authority')!='none':e.append('receipt_authority')
        if r['release_injected_ns']>r['verified_empty_ns']:e.append('release_verify_order')
        if blocked:
            if not d.get('drain'):e.append('missing_drain')
            else:
                if r['verified_empty_ns']>=d['drain']['recovery_ns']:e.append('release_not_before_recovery')
            if pol=='PIPE_ONLY':
                if t.get('ordinary_write')!='blocked':e.append('baseline_not_blocked')
                if d.get('ordinary_receipt') is not None:e.append('baseline_fabricated_ordinary')
                if d.get('recovered_receipt') is not None:e.append('baseline_fabricated_recovery')
                if t.get('journal_write_started_ns') is not None or t.get('journal_write_ns') is not None:e.append('baseline_journal')
            elif pol=='OWNER_LOCAL_JOURNAL':
                if t.get('ordinary_write')!='blocked':e.append('candidate_not_blocked')
                js=t.get('journal_write_started_ns');jn=t.get('journal_write_ns');rec=d.get('recovered_receipt')
                if js is None or jn is None:e.append('journal_missing')
                else:
                    if js<r['verified_empty_ns']:e.append('journal_before_verified_release')
                    if jn<js:e.append('journal_time_order')
                if not isinstance(rec,dict):e.append('recovery_missing')
                else:
                    if rec.get('recovery_source')!='owner_local_journal':e.append('recovery_source')
                    if rec.get('authority')!='none':e.append('recovery_authority')
                    for k in ['case','token','cause','press_ns','cancel_received_ns','release_injected_ns','verified_empty_ns']:
                        if rec.get(k)!=r.get(k):e.append('recovery_mismatch_'+k)
                    if rec.get('recovered_publish_ns',0)<jn:e.append('publish_before_journal')
            else:e.append('policy')
        else:
            if t.get('ordinary_write')!='written':e.append('healthy_ordinary_missing')
            if d.get('ordinary_receipt')!=r:e.append('healthy_receipt_mismatch')
    except Exception as x:e.append(f'audit_exception:{type(x).__name__}:{x}')
    return e

if __name__=='__main__':
    ps=[Path(x) for x in sys.argv[1:]];allerr={str(p):audit_case(p) for p in ps};errs=sum((v for v in allerr.values()),[])
    print(json.dumps({'decision':'PASS' if not errs else 'FAIL','errors':allerr},sort_keys=True));raise SystemExit(bool(errs))

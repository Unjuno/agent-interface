import argparse,json,time,tkinter as tk
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--log',type=Path,required=True);a=p.parse_args()
a.log.parent.mkdir(parents=True,exist_ok=True)
r=tk.Tk(); r.title('AI_EXP816_RECEIVER'); r.geometry('360x180+40+40')
label=tk.Label(r,text='F8 safety receipt fixture',font=('TkDefaultFont',16));label.pack(expand=True)
def rec(kind,e):
    with a.log.open('a') as f:
        f.write(json.dumps({'kind':kind,'keysym':e.keysym,'keycode':e.keycode,'ns':time.perf_counter_ns()})+'\n')
r.bind('<KeyPress-F8>',lambda e:rec('KeyPress',e));r.bind('<KeyRelease-F8>',lambda e:rec('KeyRelease',e))
r.update_idletasks();r.update();r.focus_force();r.update()
print(json.dumps({'ready':True,'xid':r.winfo_id(),'ns':time.perf_counter_ns()}),flush=True)
r.mainloop()

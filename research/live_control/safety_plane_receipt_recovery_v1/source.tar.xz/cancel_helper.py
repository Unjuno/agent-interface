import argparse,os,time,json
p=argparse.ArgumentParser();p.add_argument('--trigger-fd',type=int,required=True);p.add_argument('--cancel-fd',type=int,required=True);p.add_argument('--delay-ms',type=float,required=True);p.add_argument('--token',required=True);p.add_argument('--log',required=True);a=p.parse_args()
raw=b''
while b'\n' not in raw: raw+=os.read(a.trigger_fd,128)
press_ns=int(raw.splitlines()[0]);target=press_ns+int(a.delay_ms*1e6)
while True:
    now=time.perf_counter_ns();remain=target-now
    if remain<=0: break
    time.sleep(min(remain/1e9,0.01))
sent=time.perf_counter_ns();os.write(a.cancel_fd,(a.token+'\n').encode())
open(a.log,'w').write(json.dumps({'press_ns':press_ns,'target_ns':target,'sent_ns':sent,'token':a.token})+'\n')

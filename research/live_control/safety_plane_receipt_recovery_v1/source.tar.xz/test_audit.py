import json,tempfile,shutil,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent
case=Path(sys.argv[1])
# original must pass
assert subprocess.run(['python',str(P/'audit.py'),str(case)],capture_output=True).returncode==0
mutations=[]
def mut(name,fn):
    d=Path(tempfile.mkdtemp(prefix='exp816-mut-'));shutil.copytree(case,d/'c');p=d/'c'/'case.json';x=json.loads(p.read_text());fn(x);p.write_text(json.dumps(x));rc=subprocess.run(['python',str(P/'audit.py'),str(d/'c')],capture_output=True).returncode;mutations.append((name,rc));shutil.rmtree(d);assert rc!=0,name
mut('double_release',lambda x:x['owner_terminal'].__setitem__('release_count',2))
mut('terminal_down',lambda x:x.__setitem__('parent_terminal_f8_down',True))
if json.loads((case/'case.json').read_text())['policy']=='OWNER_LOCAL_JOURNAL':
    mut('recovery_token',lambda x:x['recovered_receipt'].__setitem__('token','forged'))
    mut('journal_before_verify',lambda x:x['owner_terminal'].__setitem__('journal_write_started_ns',x['owner_terminal']['receipt']['verified_empty_ns']-1))
else:
    mut('fabricated_baseline',lambda x:x.__setitem__('recovered_receipt',{'authority':'none'}))
print(json.dumps({'mutations':mutations,'all_rejected':all(rc!=0 for _,rc in mutations)}))

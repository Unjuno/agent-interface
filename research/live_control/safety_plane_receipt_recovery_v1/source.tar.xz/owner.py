import argparse,json,os,select,time,fcntl
from pathlib import Path
from x11util import open_display,keycode,set_focus,fake_key,is_key_down,X11
p=argparse.ArgumentParser();p.add_argument('--display',required=True);p.add_argument('--xid',type=int,required=True);p.add_argument('--case',required=True);p.add_argument('--policy',choices=['PIPE_ONLY','OWNER_LOCAL_JOURNAL'],required=True);p.add_argument('--cancel-fd',type=int,required=True);p.add_argument('--receipt-fd',type=int,required=True);p.add_argument('--control-fd',type=int,required=True);p.add_argument('--journal',type=Path,required=True);p.add_argument('--deadline-ms',type=float,default=600);a=p.parse_args()

def ctl(obj): os.write(a.control_fd,(json.dumps(obj,sort_keys=True)+'\n').encode())

def try_receipt(payload):
    data=(json.dumps(payload,sort_keys=True,separators=(',',':'))+'\n').encode()
    try:
        os.write(a.receipt_fd,data);return {'ordinary_write':'written','ordinary_bytes':len(data)}
    except BlockingIOError:return {'ordinary_write':'blocked','ordinary_bytes':0}

d=open_display(a.display);kc=keycode(d);release_count=0
try:
    set_focus(d,a.xid);time.sleep(0.03)
    press_ns=time.perf_counter_ns();fake_key(d,kc,True);time.sleep(0.005)
    if not is_key_down(d,kc): raise RuntimeError('F8 did not become down')
    ctl({'kind':'PRESS_CONFIRMED','press_ns':press_ns,'case':a.case})
    deadline_ns=press_ns+int(a.deadline_ms*1e6); token=None;cancel_received_ns=None;cause=None
    while time.perf_counter_ns()<deadline_ns:
        remain=max(0,(deadline_ns-time.perf_counter_ns())/1e9)
        r,_,_=select.select([a.cancel_fd],[],[],min(remain,0.02))
        if r:
            token=os.read(a.cancel_fd,4096).decode().strip();cancel_received_ns=time.perf_counter_ns();cause='cancel';break
    if cause is None: cause='deadline'
    release_injected_ns=time.perf_counter_ns();fake_key(d,kc,False);release_count+=1
    verified_empty_ns=None
    end=time.perf_counter_ns()+50_000_000
    while time.perf_counter_ns()<end:
        if not is_key_down(d,kc): verified_empty_ns=time.perf_counter_ns();break
        time.sleep(.0005)
    if verified_empty_ns is None: raise RuntimeError('F8 did not verify empty')
    receipt={'schema':'safety-release-receipt-v1','case':a.case,'token':token,'cause':cause,'press_ns':press_ns,'cancel_received_ns':cancel_received_ns,'release_injected_ns':release_injected_ns,'verified_empty_ns':verified_empty_ns,'authority':'none'}
    journal_write_started_ns=None;journal_write_ns=None
    if a.policy=='OWNER_LOCAL_JOURNAL':
        journal_write_started_ns=time.perf_counter_ns()
        fd=os.open(a.journal,os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
        try:
            os.write(fd,(json.dumps(receipt,sort_keys=True,separators=(',',':'))+'\n').encode());os.fsync(fd);journal_write_ns=time.perf_counter_ns()
        finally:os.close(fd)
    ordinary=try_receipt(receipt)
    terminal={'kind':'OWNER_TERMINAL','case':a.case,'policy':a.policy,'receipt':receipt,'release_count':release_count,'terminal_f8_down':is_key_down(d,kc),'journal_write_started_ns':journal_write_started_ns,'journal_write_ns':journal_write_ns,**ordinary,'ns':time.perf_counter_ns()}
    ctl(terminal)
finally:
    try:
        if is_key_down(d,kc): fake_key(d,kc,False)
    except Exception:pass
    X11.XCloseDisplay(d)

import argparse,os,time,json,fcntl
p=argparse.ArgumentParser();p.add_argument('--trigger-fd',type=int,required=True);p.add_argument('--read-fd',type=int,required=True);p.add_argument('--delay-ms',type=float,required=True);p.add_argument('--log',required=True);a=p.parse_args()
raw=b''
while b'\n' not in raw: raw+=os.read(a.trigger_fd,128)
press_ns=int(raw.splitlines()[0]);target=press_ns+int(a.delay_ms*1e6)
while True:
    now=time.perf_counter_ns();remain=target-now
    if remain<=0: break
    time.sleep(min(remain/1e9,0.01))
flags=fcntl.fcntl(a.read_fd,fcntl.F_GETFL);fcntl.fcntl(a.read_fd,fcntl.F_SETFL,flags|os.O_NONBLOCK)
recovery_ns=time.perf_counter_ns();n=0
while True:
    try:
        b=os.read(a.read_fd,65536)
        if not b: break
        n+=len(b)
    except BlockingIOError: break
open(a.log,'w').write(json.dumps({'press_ns':press_ns,'target_ns':target,'recovery_ns':recovery_ns,'drained_bytes':n})+'\n')

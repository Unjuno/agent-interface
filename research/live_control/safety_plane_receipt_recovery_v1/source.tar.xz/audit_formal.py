import json,sys
from pathlib import Path
from audit import audit_case
root=Path(sys.argv[1]);plan=json.loads((Path(__file__).resolve().parent/'plan.json').read_text())
errors=[]; rows=[]
for i,cid in enumerate(plan['case_ids']):
    d=root/cid
    if not (d/'case.json').exists():errors.append(f'missing:{cid}');continue
    ce=audit_case(d)
    if ce:errors.extend(f'{cid}:{x}' for x in ce)
    x=json.loads((d/'case.json').read_text());rows.append(x)
if len(rows)!=8:errors.append('row_count')
pipe=[x for x in rows if x.get('policy')=='PIPE_ONLY'];jour=[x for x in rows if x.get('policy')=='OWNER_LOCAL_JOURNAL']
if len(pipe)!=4:errors.append('pipe_count')
if len(jour)!=4:errors.append('journal_count')
for x in rows:
    ev=x.get('receiver_events',[])
    if sum(r.get('kind')=='KeyPress' for r in ev)!=1 or sum(r.get('kind')=='KeyRelease' for r in ev)!=1:errors.append(x['case']+':app_event_count')
    if x.get('drain') and x['owner_terminal']['receipt']['verified_empty_ns']>=x['drain']['recovery_ns']:errors.append(x['case']+':release_after_recovery')
for x in pipe:
    if x.get('ordinary_receipt') is not None or x.get('recovered_receipt') is not None:errors.append(x['case']+':baseline_receipt_present')
for x in jour:
    if not isinstance(x.get('recovered_receipt'),dict):errors.append(x['case']+':candidate_missing_recovery')
    else:
        r=x['owner_terminal']['receipt'];t=x['owner_terminal'];rec=x['recovered_receipt']
        if not (r['release_injected_ns']<=r['verified_empty_ns']<=t['journal_write_started_ns']<=t['journal_write_ns']<=rec['recovered_publish_ns']):errors.append(x['case']+':candidate_order')
summary={'schema':'safety-receipt-recovery-audit-v1','decision':'PASS_SAFETY_RECEIPT_RECOVERY_SCOPED' if not errors else 'FAIL','errors':errors,'case_count':len(rows),'pipe_missing':sum(x.get('ordinary_receipt') is None and x.get('recovered_receipt') is None for x in pipe),'journal_recovered':sum(isinstance(x.get('recovered_receipt'),dict) for x in jour),'all_release_before_recovery':all(x['owner_terminal']['receipt']['verified_empty_ns']<x['drain']['recovery_ns'] for x in rows if x.get('drain'))}
print(json.dumps(summary,sort_keys=True));raise SystemExit(bool(errors))

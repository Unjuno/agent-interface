from __future__ import annotations
import argparse,hashlib,json,pathlib,collections,sys
HERE=pathlib.Path(__file__).resolve().parent
SELECTED_BIT=23
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def selected(states):return bool(isinstance(states,list) and len(states)>=1 and isinstance(states[0],int) and (states[0]&(1<<SELECTED_BIT)))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('root');a=ap.parse_args();root=pathlib.Path(a.root);pre=json.loads((HERE/'prereg.json').read_text());errors=[];rows=[]
 for n,h in pre['source_sha256'].items():
  if sha(HERE/n)!=h:errors.append('source hash '+n)
 for i,spec in enumerate(pre['schedule']):
  p=root/f'case-{i:02d}-{spec["target"]}'/'result.json'
  if not p.exists():errors.append(f'missing {p.name}');continue
  r=json.loads(p.read_text());rows.append(r)
  if not r.get('finished'):errors.append(f'unfinished {i}')
  if r.get('target')!=spec['target']:errors.append(f'target schedule {i}')
  want=[] if spec['target']=='none' else [spec['target']]
  if r.get('visual_selected')!=want:errors.append(f'visual setup {i}: {r.get("visual_selected")}')
  pc=r.get('positive_control',{});cnt=((pc.get('selection') or {}).get('NSelectedChildren') or {}).get('data')
  if cnt!=1 or not pc.get('selected_name'):errors.append(f'positive selection control {i}')
  o=r.get('observation',{})
  for tg in ['A','B']:
   x=o.get(tg,{})
   if ((x.get('props') or {}).get('Name') or {}).get('data')!='AI_Target_'+tg:errors.append(f'label {i} {tg}')
   if selected(x.get('states')):errors.append(f'target SELECTED unexpectedly true {i} {tg}')
  an=o.get('selection_ancestor',{});nsel=((an.get('selection') or {}).get('NSelectedChildren') or {}).get('data')
  if nsel!=0 or an.get('selected_children') not in [[],None]:errors.append(f'ancestor selection {i}: {nsel}')
  if r.get('svg_before')!=r.get('svg_after'):errors.append(f'svg changed {i}')
  if any(r.get('keymap',[])) or r.get('pointer_mask')!=0:errors.append(f'input not empty {i}')
 if len(rows)!=12:errors.append('row count')
 cnt=collections.Counter(r.get('target') for r in rows)
 if cnt!=collections.Counter({'none':4,'A':4,'B':4}):errors.append('target counts '+repr(cnt))
 # Target state vectors should not discriminate the selected target across valid sessions.
 sigs={tg:collections.defaultdict(set) for tg in ['A','B']}
 for r in rows:
  for tg in ['A','B']:sigs[tg][r['target']].add(tuple(r['observation'][tg]['states']))
 for tg in ['A','B']:
  union=set().union(*sigs[tg].values()) if sigs[tg] else set()
  if len(union)!=1:errors.append(f'{tg} state vector varies across selection states: {sigs[tg]}')
 out={'status':'PASS_ATSPI_SELECTION_UNAVAILABLE_AUDIT' if not errors else 'FAIL','errors':errors,'rows':len(rows),'counts':dict(cnt),'selected_bit':SELECTED_BIT,'state_signatures':{tg:{k:[list(x) for x in v] for k,v in d.items()} for tg,d in sigs.items()},'decision':'DEPENDENCY_UNAVAILABLE_ATSPI_SELECTION_SCOPED' if not errors else 'HOLD'}
 (root/'audit.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps(out,sort_keys=True));return 0 if not errors else 1
if __name__=='__main__':raise SystemExit(main())

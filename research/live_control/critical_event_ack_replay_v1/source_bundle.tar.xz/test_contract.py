import copy, unittest
import experiment as e

class T(unittest.TestCase):
    def fill(self):
        st=e.initial()
        for i,k in enumerate(['FOCUS_LOST','LEASE_EXPIRED','TARGET_LOST'],1): self.assertEqual(e.admit(st,e.E('A',i,k))['status'],'EVENT_ADMITTED')
        return st
    def test_exact_retry_candidate(self):
        st=self.fill(); d=e.prefix_digest(st['sessions']['A']['events'],1)
        self.assertEqual(e.ack(st,'content_bound_idempotent_ack','A',1,d)['status'],'ACK_APPLIED')
        before=copy.deepcopy(st); x=e.ack(st,'content_bound_idempotent_ack','A',1,d)
        self.assertEqual(x['status'],'ACK_ALREADY_APPLIED'); self.assertEqual(st,before)
    def test_exact_retry_baseline_nonidentifying(self):
        st=self.fill(); d=e.prefix_digest(st['sessions']['A']['events'],1)
        e.ack(st,'strict_monotonic_ack','A',1,d); before=copy.deepcopy(st)
        self.assertEqual(e.ack(st,'strict_monotonic_ack','A',1,d)['status'],'ACK_NON_MONOTONIC'); self.assertEqual(st,before)
    def test_changed_digest_conflicts(self):
        st=self.fill(); d=e.prefix_digest(st['sessions']['A']['events'],1); e.ack(st,'content_bound_idempotent_ack','A',1,d); before=copy.deepcopy(st)
        bad=('f' if d[0]!='f' else 'e')+d[1:]
        self.assertEqual(e.ack(st,'content_bound_idempotent_ack','A',1,bad)['status'],'ACK_RECEIPT_CONFLICT'); self.assertEqual(st,before)
    def test_advance_replaces_receipt(self):
        st=self.fill(); d1=e.prefix_digest(st['sessions']['A']['events'],1); e.ack(st,'content_bound_idempotent_ack','A',1,d1); e.admit(st,e.E('A',4,'TERMINAL'))
        d2=e.prefix_digest(st['sessions']['A']['events'],2); self.assertEqual(e.ack(st,'content_bound_idempotent_ack','A',2,d2)['status'],'ACK_APPLIED')
        self.assertEqual(st['sessions']['A']['last_ack_receipt']['through_seq'],2); self.assertEqual([x['seq'] for x in st['sessions']['A']['events']],[3,4])
    def test_backpressure_still_fixed(self):
        st=self.fill(); before=copy.deepcopy(st); self.assertEqual(e.admit(st,e.E('A',4,'TERMINAL'))['status'],'EVENT_BACKPRESSURE'); self.assertEqual(st,before)

if __name__=='__main__': unittest.main()

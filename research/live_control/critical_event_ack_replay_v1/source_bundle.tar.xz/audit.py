from __future__ import annotations
import argparse, hashlib, json, re
from pathlib import Path
HEX64=re.compile(r'^[0-9a-f]{64}$')

def canon(x): return json.dumps(x,sort_keys=True,separators=(',',':'))
def dig(x): return hashlib.sha256(canon(x).encode()).hexdigest()
def by(rows): return {(r['case'],r['policy']):r for r in rows}
def evseq(r,sid='A'):
    s=r.get('final',{}).get('sessions',{}).get(sid,{})
    return [e.get('seq') for e in s.get('events',[]) if isinstance(e,dict)] if isinstance(s,dict) else []
def receipt(r,sid='A'):
    s=r.get('final',{}).get('sessions',{}).get(sid,{})
    return s.get('last_ack_receipt') if isinstance(s,dict) else None

def ack_steps(r): return [t for t in r.get('trace',[]) if t.get('op')=='ack']

def unchanged(t): return t.get('mutated') is False and t.get('before_sha')==t.get('after_sha')

def check(result):
    errs=[]
    if result.get('schema')!='critical-event-ack-replay-formal-v1': errs.append('schema')
    rows=result.get('rows',[]); m=by(rows)
    cases=['first_ack','lost_response_exact_retry','retry_after_append','changed_digest_same_seq','advance_ack','cross_session','invalid_controls']
    policies=['strict_monotonic_ack','content_bound_idempotent_ack']
    req=[(c,p) for c in cases for p in policies]
    if len(rows)!=14 or len(m)!=14: errs.append('row_count')
    if any(k not in m for k in req): errs.append('missing_rows'); return errs
    # First ACK: only E1 removed in both.
    for p in policies:
        r=m['first_ack',p]; steps=ack_steps(r)
        if evseq(r)!=[2,3]: errs.append('first_ack_queue_'+p)
        if len(steps)!=1 or steps[0].get('status')!='ACK_APPLIED' or not steps[0].get('mutated'): errs.append('first_ack_status_'+p)
        s=r['final']['sessions']['A']
        if s.get('last_acked_event_seq')!=1: errs.append('first_ack_boundary_'+p)
    cr=receipt(m['first_ack','content_bound_idempotent_ack'])
    if not isinstance(cr,dict) or cr.get('through_seq')!=1 or not HEX64.fullmatch(str(cr.get('acknowledged_prefix_sha256',''))): errs.append('candidate_receipt_first')
    if receipt(m['first_ack','strict_monotonic_ack']) is not None: errs.append('baseline_receipt_should_absent')
    # Lost response exact retry: baseline cannot identify success; candidate exact idempotent.
    b=m['lost_response_exact_retry','strict_monotonic_ack']; c=m['lost_response_exact_retry','content_bound_idempotent_ack']
    bs=ack_steps(b); cs=ack_steps(c)
    if [x.get('status') for x in bs]!=['ACK_APPLIED','ACK_NON_MONOTONIC'] or not unchanged(bs[1]): errs.append('baseline_retry')
    if [x.get('status') for x in cs]!=['ACK_APPLIED','ACK_ALREADY_APPLIED'] or not unchanged(cs[1]): errs.append('candidate_retry')
    if evseq(b)!=[2,3] or evseq(c)!=[2,3]: errs.append('retry_queue')
    # Retry after later append must not delete E2/E3/E4.
    c=m['retry_after_append','content_bound_idempotent_ack']; cs=ack_steps(c)
    if evseq(c)!=[2,3,4] or cs[-1].get('status')!='ACK_ALREADY_APPLIED' or not unchanged(cs[-1]): errs.append('retry_after_append')
    # Same seq changed content conflicts.
    c=m['changed_digest_same_seq','content_bound_idempotent_ack']; cs=ack_steps(c)
    if cs[-1].get('status')!='ACK_RECEIPT_CONFLICT' or not unchanged(cs[-1]) or evseq(c)!=[2,3]: errs.append('changed_digest_conflict')
    # Later valid ACK advances receipt and removes exactly E2.
    c=m['advance_ack','content_bound_idempotent_ack']; cs=ack_steps(c); rr=receipt(c)
    if [x.get('status') for x in cs]!=['ACK_APPLIED','ACK_APPLIED'] or evseq(c)!=[3,4]: errs.append('advance_ack_queue_status')
    if not isinstance(rr,dict) or rr.get('through_seq')!=2 or not HEX64.fullmatch(str(rr.get('acknowledged_prefix_sha256',''))): errs.append('advance_receipt')
    # Cross-session retry has no B mutation and B content survives.
    c=m['cross_session','content_bound_idempotent_ack']; cs=ack_steps(c); bstate=c['final']['sessions'].get('B',{})
    if cs[-1].get('status')!='ACK_ALREADY_APPLIED' or not unchanged(cs[-1]): errs.append('cross_retry_status')
    if evseq(c,'B')!=[2] or not isinstance(bstate.get('latest_state'),dict) or bstate['latest_state'].get('seq')!=1: errs.append('cross_session_B')
    # Invalid candidate controls all fail closed.
    c=m['invalid_controls','content_bound_idempotent_ack']; sts=[t.get('status') for t in c.get('trace',[])]
    for x in ['ACK_UNKNOWN_SESSION','ACK_FUTURE','ACK_MALFORMED_DIGEST','REJECTED_NON_MONOTONIC_SEQ']:
        if x not in sts: errs.append('control_'+x)
    # Generic state integrity.
    for r in rows:
        if r.get('capacity')!=3: errs.append('capacity_field')
        if r.get('final_sha256')!=dig(r.get('final')): errs.append('final_digest_'+r.get('case','?')+'_'+r.get('policy','?'))
        fs=r.get('final',{}).get('sessions',{})
        if not isinstance(fs,dict): errs.append('sessions_type'); continue
        for sid,s in fs.items():
            if not isinstance(s,dict): errs.append('session_type_'+str(sid)); continue
            ev=s.get('events',[])
            if not isinstance(ev,list) or len(ev)>3: errs.append('capacity_'+r['case']+'_'+r['policy']+'_'+str(sid)); continue
            seqs=[e.get('seq') for e in ev if isinstance(e,dict)]
            if len(seqs)!=len(ev) or seqs!=sorted(seqs) or len(seqs)!=len(set(seqs)): errs.append('event_order_'+r['case']+'_'+r['policy']+'_'+str(sid))
            rec=s.get('last_ack_receipt')
            if rec is not None:
                if r['policy']!='content_bound_idempotent_ack' or not isinstance(rec,dict) or rec.get('through_seq')!=s.get('last_acked_event_seq') or not HEX64.fullmatch(str(rec.get('acknowledged_prefix_sha256',''))): errs.append('receipt_shape_'+r['case']+'_'+r['policy']+'_'+str(sid))
        for t in r.get('trace',[]):
            if t.get('mutated') is False and t.get('before_sha')!=t.get('after_sha'): errs.append('nonmutating_changed_'+r['case']+'_'+r['policy'])
    return errs

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--result',type=Path,required=True); ap.add_argument('--out',type=Path,required=True); a=ap.parse_args()
    r=json.loads(a.result.read_text()); errs=check(r); decision='PASS_CONTENT_BOUND_ACK_REPLAY_SCOPED' if not errs else 'FAIL_OR_HOLD'
    out={'schema':'critical-event-ack-replay-audit-v1','pass':not errs,'decision':decision,'errors':errs}
    a.out.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n'); print(json.dumps(out,indent=2))
if __name__=='__main__': main()

from __future__ import annotations
import argparse, copy, hashlib, json, re
from pathlib import Path

CAPACITY = 3
CRITICAL = {'FOCUS_LOST','FOCUS_RESTORED','LEASE_EXPIRED','RELEASE_VERIFIED','TARGET_LOST','TERMINAL'}
HEX64 = re.compile(r'^[0-9a-f]{64}$')


def canon(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'))


def digest(x):
    return hashlib.sha256(canon(x).encode()).hexdigest()


def prefix_digest(events, through_seq):
    prefix = [copy.deepcopy(e) for e in events if e['seq'] <= through_seq]
    return digest(prefix)


def initial():
    return {'sessions': {}}


def sess(st, sid):
    return st['sessions'].setdefault(sid, {
        'latest_state': None,
        'events': [],
        'last_seq': 0,
        'last_acked_event_seq': 0,
        'last_ack_receipt': None,
    })


def snapshot(st):
    return copy.deepcopy(st)


def admit(st, rec):
    before = snapshot(st)
    sid = rec.get('session'); seq = rec.get('seq'); cls = rec.get('class'); kind = rec.get('kind')
    if not isinstance(sid, str) or not sid or not isinstance(seq, int) or seq <= 0 or cls not in {'state','event'}:
        return {'status':'REJECTED_MALFORMED','mutated':False,'before':before,'after':snapshot(st)}
    created = sid not in st['sessions']
    s = sess(st, sid)
    if seq <= s['last_seq']:
        if created: st['sessions'].pop(sid, None)
        return {'status':'REJECTED_NON_MONOTONIC_SEQ','mutated':False,'before':before,'after':snapshot(st)}
    if cls == 'event' and kind not in CRITICAL:
        if created: st['sessions'].pop(sid, None)
        return {'status':'REJECTED_EVENT_CLASS','mutated':False,'before':before,'after':snapshot(st)}
    if cls == 'state':
        s['latest_state'] = copy.deepcopy(rec); s['last_seq'] = seq
        return {'status':'STATE_REPLACED','mutated':True,'before':before,'after':snapshot(st)}
    if len(s['events']) >= CAPACITY:
        if created: st['sessions'].pop(sid, None)
        assert st == before
        return {'status':'EVENT_BACKPRESSURE','mutated':False,'before':before,'after':snapshot(st)}
    s['events'].append(copy.deepcopy(rec)); s['last_seq'] = seq
    return {'status':'EVENT_ADMITTED','mutated':True,'before':before,'after':snapshot(st)}


def ack(st, policy, sid, through_seq, claimed_prefix_sha256):
    before = snapshot(st)
    if not isinstance(sid, str) or not sid:
        return {'status':'ACK_MALFORMED','mutated':False,'before':before,'after':snapshot(st)}
    if not isinstance(claimed_prefix_sha256, str) or not HEX64.fullmatch(claimed_prefix_sha256):
        return {'status':'ACK_MALFORMED_DIGEST','mutated':False,'before':before,'after':snapshot(st)}
    if sid not in st['sessions']:
        return {'status':'ACK_UNKNOWN_SESSION','mutated':False,'before':before,'after':snapshot(st)}
    s = st['sessions'][sid]
    if not isinstance(through_seq, int) or through_seq <= 0:
        return {'status':'ACK_MALFORMED','mutated':False,'before':before,'after':snapshot(st)}
    last = s['last_acked_event_seq']
    receipt = s.get('last_ack_receipt')
    if through_seq < last:
        return {'status':'ACK_STALE','mutated':False,'before':before,'after':snapshot(st)}
    if through_seq == last and last > 0:
        if policy == 'strict_monotonic_ack':
            return {'status':'ACK_NON_MONOTONIC','mutated':False,'before':before,'after':snapshot(st)}
        if policy != 'content_bound_idempotent_ack':
            raise ValueError(policy)
        if not isinstance(receipt, dict) or receipt.get('through_seq') != through_seq:
            return {'status':'ACK_RECEIPT_MISSING','mutated':False,'before':before,'after':snapshot(st)}
        if receipt.get('acknowledged_prefix_sha256') != claimed_prefix_sha256:
            return {'status':'ACK_RECEIPT_CONFLICT','mutated':False,'before':before,'after':snapshot(st)}
        return {'status':'ACK_ALREADY_APPLIED','mutated':False,'before':before,'after':snapshot(st)}
    evseq = [e['seq'] for e in s['events']]
    if not evseq or through_seq > max(evseq):
        return {'status':'ACK_FUTURE','mutated':False,'before':before,'after':snapshot(st)}
    if through_seq not in evseq:
        return {'status':'ACK_UNKNOWN_EVENT','mutated':False,'before':before,'after':snapshot(st)}
    actual_prefix_sha256 = prefix_digest(s['events'], through_seq)
    if actual_prefix_sha256 != claimed_prefix_sha256:
        return {'status':'ACK_PREFIX_MISMATCH','mutated':False,'before':before,'after':snapshot(st)}
    s['events'] = [e for e in s['events'] if e['seq'] > through_seq]
    s['last_acked_event_seq'] = through_seq
    if policy == 'content_bound_idempotent_ack':
        s['last_ack_receipt'] = {
            'through_seq': through_seq,
            'acknowledged_prefix_sha256': claimed_prefix_sha256,
        }
    elif policy == 'strict_monotonic_ack':
        s['last_ack_receipt'] = None
    else:
        raise ValueError(policy)
    return {
        'status':'ACK_APPLIED','mutated':True,
        'acknowledged_prefix_sha256': actual_prefix_sha256,
        'before':before,'after':snapshot(st)
    }


def E(sid, seq, kind):
    return {'session':sid,'seq':seq,'class':'event','kind':kind,'payload':{'event_id':f'{sid}-E{seq}'}}


def S(sid, seq, value):
    return {'session':sid,'seq':seq,'class':'state','kind':'PROGRESS','payload':{'value':value}}


def run_case(case, policy):
    name = case['name']; st = initial(); trace = []
    def A(rec):
        x = admit(st, rec)
        trace.append({'op':'admit','record':rec,'status':x['status'],'mutated':x['mutated'],'before_sha':digest(x['before']),'after_sha':digest(x['after'])})
        return x
    def K(sid, q, pd):
        x = ack(st, policy, sid, q, pd)
        trace.append({'op':'ack','session':sid,'through_seq':q,'claimed_prefix_sha256':pd,'status':x['status'],'mutated':x['mutated'],'before_sha':digest(x['before']),'after_sha':digest(x['after']),'acknowledged_prefix_sha256':x.get('acknowledged_prefix_sha256')})
        return x
    def fill_A():
        for i,k in enumerate(['FOCUS_LOST','LEASE_EXPIRED','TARGET_LOST'],1): A(E('A',i,k))
    if name == 'first_ack':
        fill_A(); d = prefix_digest(st['sessions']['A']['events'],1); K('A',1,d)
    elif name == 'lost_response_exact_retry':
        fill_A(); d = prefix_digest(st['sessions']['A']['events'],1); K('A',1,d); K('A',1,d)
    elif name == 'retry_after_append':
        fill_A(); d = prefix_digest(st['sessions']['A']['events'],1); K('A',1,d); A(E('A',4,'TERMINAL')); K('A',1,d)
    elif name == 'changed_digest_same_seq':
        fill_A(); d = prefix_digest(st['sessions']['A']['events'],1); K('A',1,d); bad = ('f' if d[0] != 'f' else 'e') + d[1:]; K('A',1,bad)
    elif name == 'advance_ack':
        fill_A(); d1 = prefix_digest(st['sessions']['A']['events'],1); K('A',1,d1); A(E('A',4,'TERMINAL')); d2 = prefix_digest(st['sessions']['A']['events'],2); K('A',2,d2)
    elif name == 'cross_session':
        fill_A(); A(S('B',1,'b1')); A(E('B',2,'TERMINAL')); d = prefix_digest(st['sessions']['A']['events'],1); K('A',1,d); K('A',1,d)
    elif name == 'invalid_controls':
        fill_A(); valid = prefix_digest(st['sessions']['A']['events'],1)
        K('Z',1,valid); K('A',99,valid); K('A',1,'not-a-digest'); A(E('A',3,'TERMINAL'))
    else:
        raise ValueError(name)
    return {'case':name,'policy':policy,'capacity':CAPACITY,'trace':trace,'final':st,'final_sha256':digest(st)}


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--plan',type=Path,required=True); ap.add_argument('--out',type=Path,required=True)
    a = ap.parse_args(); plan = json.loads(a.plan.read_text()); rows=[]
    for case in plan['cases']:
        for policy in plan['policies']:
            rows.append(run_case(case,policy))
    out={'schema':'critical-event-ack-replay-formal-v1','task':plan['task'],'capacity':CAPACITY,'rows':rows}
    a.out.parent.mkdir(parents=True,exist_ok=True); a.out.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'rows':len(rows),'out':str(a.out)}))

if __name__ == '__main__': main()

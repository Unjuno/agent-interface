import copy, json, unittest
from pathlib import Path
import audit

ROOT=Path(__file__).parent
BASE=json.loads((ROOT/'construction_result.json').read_text())

def row(obj,case,policy):
    return next(r for r in obj['rows'] if r['case']==case and r['policy']==policy)

def acks(r): return [t for t in r['trace'] if t['op']=='ack']

class M(unittest.TestCase):
    def reject(self,obj): self.assertTrue(audit.check(obj))
    def test_candidate_retry_reapplied(self):
        x=copy.deepcopy(BASE); t=acks(row(x,'lost_response_exact_retry','content_bound_idempotent_ack'))[-1]; t['status']='ACK_APPLIED'; t['mutated']=True; self.reject(x)
    def test_candidate_retry_digest_mutation(self):
        x=copy.deepcopy(BASE); t=acks(row(x,'lost_response_exact_retry','content_bound_idempotent_ack'))[-1]; t['after_sha']='0'*64; self.reject(x)
    def test_changed_digest_laundered(self):
        x=copy.deepcopy(BASE); t=acks(row(x,'changed_digest_same_seq','content_bound_idempotent_ack'))[-1]; t['status']='ACK_ALREADY_APPLIED'; self.reject(x)
    def test_advance_receipt_boundary(self):
        x=copy.deepcopy(BASE); row(x,'advance_ack','content_bound_idempotent_ack')['final']['sessions']['A']['last_ack_receipt']['through_seq']=1; self.reject(x)
    def test_cross_session_B_event_loss(self):
        x=copy.deepcopy(BASE); row(x,'cross_session','content_bound_idempotent_ack')['final']['sessions']['B']['events']=[]; self.reject(x)
    def test_baseline_laundered_idempotent(self):
        x=copy.deepcopy(BASE); acks(row(x,'lost_response_exact_retry','strict_monotonic_ack'))[-1]['status']='ACK_ALREADY_APPLIED'; self.reject(x)
    def test_candidate_receipt_removed(self):
        x=copy.deepcopy(BASE); row(x,'first_ack','content_bound_idempotent_ack')['final']['sessions']['A']['last_ack_receipt']=None; self.reject(x)
    def test_missing_row(self):
        x=copy.deepcopy(BASE); x['rows']=x['rows'][:-1]; self.reject(x)
    def test_final_digest_lie(self):
        x=copy.deepcopy(BASE); row(x,'first_ack','content_bound_idempotent_ack')['final_sha256']='f'*64; self.reject(x)

if __name__=='__main__': unittest.main()

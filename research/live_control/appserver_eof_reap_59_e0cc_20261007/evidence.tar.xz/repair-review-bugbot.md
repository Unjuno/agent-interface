# Close repair review (technical peer review)

I reviewed the uncommitted change in `research/live_control/codex_app_server_client_v2.py` and `test_appserver_process_tree_cleanup_20261004.py` read-only. I did not rerun tests or change source.

The repair is narrowly scoped and addresses the observed close race: `_signal_owned_group()` polls the owned `Popen` before `killpg`, so an already-exited leader is reaped while the process group is still signaled for surviving descendants. If `killpg` reports `PermissionError`, it polls again to handle the leader-exit-between-poll-and-signal race, retries once only after the leader has exited, ignores `ProcessLookupError` for an absent group, and preserves a live-leader or persistent permission failure.

The five added tests cover an EOF-exited real child, signaling after leader exit, the poll/signal exit race, permission denial while the leader remains live, and persistent denial after leader exit. Existing real descendant-cleanup coverage remains in the same module, including a child that ignores SIGTERM and must be retired by escalation. This combination checks both the new retry boundary and the requirement to signal the process group after leader exit. The retained baseline output records the expected failures/errors for the new cases; the candidate module is reported passing by the author. I did not independently execute that result.

No material defect found in the reviewed patch. Scope is the owned POSIX process-group path; this does not establish behavior for non-POSIX process trees or process factories that do not own a group. The implementation intentionally surfaces persistent `EPERM` rather than claiming cleanup succeeded.

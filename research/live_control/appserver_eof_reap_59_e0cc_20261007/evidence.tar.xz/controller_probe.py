"""Actual V39/client/adapter/pool, inert real peer, synthetic session/cleanup seam."""
from concurrent.futures import ThreadPoolExecutor
from contextlib import ExitStack
import argparse
import copy
import json
import os
from pathlib import Path
import platform
import queue
import sys
import threading
import time
from types import SimpleNamespace
from unittest.mock import patch

ap = argparse.ArgumentParser()
ap.add_argument("--source", type=Path, required=True)
ap.add_argument("--out", type=Path, required=True)
ap.add_argument("--mode", choices=["rpc_error", "ack_complete", "eof", "ack_silent"], required=True)
args = ap.parse_args()
args.out.mkdir(parents=True, exist_ok=False)
source = args.source.resolve()
sys.path[:0] = [str(source / "research/doom"), str(source / "research/live_control")]
import map01_overlap_controller_v39 as controller
from codex_app_server_client_v2 import CodexAppServerClient
from persistent_planner_adapter_v2 import PersistentPlannerAdapter

trace = {"mode": args.mode, "timeline": [], "commands": [], "events": [],
         "python": sys.version, "platform": platform.platform(), "machine": platform.machine(),
         "clock": "perf_counter_ns", "no_model_or_native_input": True}
lock = threading.Lock()
started = threading.Event()
interrupted = threading.Event()
finished = threading.Event()
futures = []


def record(event, **fields):
    with lock:
        trace["timeline"].append({"event": event, "ns": time.perf_counter_ns(), **fields})


# Construct before patching the session's Popen seam. The production client's
# default process factory is the real subprocess.Popen and owns a POSIX group.
client = CodexAppServerClient(
    [sys.executable, "-u", str(Path(__file__).with_name("inert_peer.py")), args.mode],
    journal_path=str(args.out / "wire.jsonl"))
trace["peer_pid"] = client.process.pid
trace["owns_process_group"] = client._owns_process_group


class Planner(PersistentPlannerAdapter):
    def await_turn(self, handle, timeout=120):
        record("await_enter", timeout=timeout)
        started.set()
        try:
            result = super().await_turn(handle, timeout)
        except BaseException as error:
            record("await_error", kind=type(error).__name__, message=str(error))
            raise
        record("await_result", eligible=result.answer_eligible,
               cancelled=result.cancellation_requested, status=result.status)
        return result

    def interrupt(self, handle):
        record("interrupt_enter", thread=handle.thread_id, turn=handle.turn_id)
        try:
            result = super().interrupt(handle)
            record("interrupt_result", result=result)
            return result
        finally:
            interrupted.set()

    def abort_pending_turn(self):
        record("abort_enter")
        try:
            result = super().abort_pending_turn()
        except BaseException as error:
            record("abort_error", kind=type(error).__name__, message=str(error))
            raise
        record("abort_result", result=result)
        return result


planner = Planner(client, model="inert-peer-no-model", effort="low", cwd=source,
                  base_instructions="Synthetic protocol construction only")


def rescue():
    # A finite construction watchdog, not a production timeout modification.
    if not interrupted.wait(4):
        record("rescue_no_interrupt")
    elif finished.wait(1):
        return
    record("external_rescue_enter", unfinished_futures=sum(not f.done() for f in futures))
    client.close(timeout=1)
    record("external_rescue_return")


watchdog = threading.Thread(target=rescue, name="construction-rescue")


class Incoming(queue.Queue):
    def get(self, *a, **kw):
        row = super().get(*a, **kw)
        if row["event"] == "terminal":
            if not started.wait(2):
                raise RuntimeError("planner waiter did not start")
            record("terminal_read", pending=not futures[0].done())
        trace["events"].append(copy.deepcopy(row))
        return row


incoming = Incoming()
incoming.put({"event": "ready", "fixture": {"loaded": True}})
incoming.put({"event": "observation", "sequence": 1, "capture_ns": 100,
              "image": "synthetic.png", "step": 0,
              "pointer_binding": {"focus": 7, "surface": 7}})


class Stdin:
    def write(self, value):
        command = json.loads(value)
        trace["commands"].append(command)
        record("session_write", op=command["op"])
        if command["op"] != "submit" or len(trace["commands"]) != 1:
            raise RuntimeError("unexpected continuation after failed cover")
        incoming.put({"event": "accepted", "id": command["id"], "accepted_ns": 105,
                      "steps": [], "program_sha256": "synthetic", "intent_token": "test"})
        incoming.put({"event": "terminal", "id": command["id"], "status": "failed",
                      "terminal_ns": 120, "error": "injected input error",
                      "release": {"verified": True, "keys_down": [], "buttons_down": []}})

    def flush(self):
        pass


process = SimpleNamespace(stdin=Stdin(), stdout=iter(()), poll=lambda: None)


class Pool(ThreadPoolExecutor):
    def submit(self, *a, **kw):
        future = super().submit(*a, **kw)
        futures.append(future)
        if not started.wait(2):
            raise RuntimeError("planner future did not enter await")
        return future


class Reader:
    def __init__(self, *a, signal_id):
        self.signal_id = signal_id

    def read(self, observation):
        return {"format": "observable-signal-v1", "status": "observed",
                "signal_id": self.signal_id, "value": 90,
                "sequence": observation["sequence"], "capture_ns": observation["capture_ns"],
                "binding": observation["pointer_binding"]}


class CleanupSpy:
    def __init__(self, *a):
        self.reader = None

    def __enter__(self):
        return self

    def __exit__(self, kind, error, tb):
        record("cleanup_entry", error=kind.__name__, futures_done=all(f.done() for f in futures))
        self.reader.join(timeout=2)

    def track(self, *a):
        pass

    def observe_output(self, events, reader, *a):
        self.reader = reader

    def set_stage(self, name):
        trace["stage"] = name


def final_admission(*a):
    record("final_admission")
    raise RuntimeError("unexpected final admission")


def begin(*a, **kw):
    return planner.begin_turn("inert scripted observation", output_schema={})


original_read = Path.read_text


def read_text(path, *a, **kw):
    if path.name == "map01_cover_policy_schema_v6.json":
        return "{}"
    if path.name == "map01_motor_responder_v10.txt":
        return "synthetic"
    return original_read(path, *a, **kw)


argv = ["controller", "--out", str(args.out / "controller"), "--iterations", "1",
        "--model", "inert-peer-no-model", "--effort", "low",
        "--load-fixture-manifest", str(args.out / "synthetic-fixture.json")]
monitor = SimpleNamespace(event_types=set(), soft_event_count=0, latest_soft_event=None)
replacements = [
    patch.object(sys, "argv", argv),
    patch.object(controller, "CodexAppServerClient", return_value=client),
    patch.object(controller, "PersistentPlannerAdapter", return_value=planner),
    patch.object(controller, "ThreadPoolExecutor", Pool),
    patch.object(controller.subprocess, "Popen", return_value=process),
    patch.object(controller.queue, "Queue", return_value=incoming),
    patch.object(controller, "ControllerFailureCleanup", CleanupSpy),
    patch.object(controller, "DoomStatusNumberReader", Reader),
    patch.object(controller, "refresh_source", side_effect=lambda latest, *a: (
        latest, {"status": "already_observed"})),
    patch.object(controller, "build_cover_monitor", return_value=(
        monitor, {"status": "admitted", "authored": None})),
    patch.object(controller, "temporal_sheet"),
    patch.object(controller, "begin_model_turn", begin),
    patch.object(controller, "final_admission_from_planner_result", final_admission),
    patch.object(controller, "win", side_effect=str),
    patch.object(Path, "read_text", read_text),
]
watchdog.start()
try:
    with ExitStack() as stack:
        for replacement in replacements:
            stack.enter_context(replacement)
        record("main_enter")
        try:
            controller.main()
        except BaseException as error:
            trace["error"] = {"type": type(error).__name__, "message": str(error),
                              "notes": getattr(error, "__notes__", [])}
            record("main_error", kind=type(error).__name__)
        finally:
            finished.set()
            record("main_exit", peer_exited=client.process.poll() is not None,
                   reader_alive=client._reader.is_alive())
finally:
    watchdog.join(timeout=7)
    client.close(timeout=1)
    controller.atexit.unregister(client.close)
    trace["watchdog_alive"] = watchdog.is_alive()
    trace["all_futures_done"] = bool(futures) and all(f.done() for f in futures)
    trace["peer_returncode"] = client.process.poll()
    trace["reader_alive"] = client._reader.is_alive()
    trace["journal_closed"] = client._journal.closed
    try:
        os.killpg(client.process.pid, 0)
    except ProcessLookupError:
        trace["process_group_absent"] = True
    else:
        trace["process_group_absent"] = False
    with (args.out / "trace.json").open("x") as f:
        json.dump(trace, f, indent=2)
print(json.dumps({"mode": args.mode, "error": trace.get("error"),
                  "rescued": any(r["event"] == "external_rescue_enter" for r in trace["timeline"]),
                  "retired": trace["all_futures_done"] and not trace["reader_alive"] and
                             trace["peer_returncode"] is not None and trace["process_group_absent"]}))

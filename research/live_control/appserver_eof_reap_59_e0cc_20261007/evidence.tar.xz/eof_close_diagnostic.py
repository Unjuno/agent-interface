"""Bounded follow-up for the retained EOF PermissionError; no Popen seams."""
import json
from pathlib import Path
import sys
import traceback

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / "candidate/source/research/live_control"))
from codex_app_server_client_v2 import CodexAppServerClient

rows = []
for condition in ("not_explicitly_reaped", "explicitly_reaped"):
    row = {"condition": condition}
    # No grandchildren and no external resources. Reader EOF is awaited first.
    client = CodexAppServerClient([sys.executable, "-c", "pass"])
    try:
        client._reader.join(timeout=2)
        row["reader_exited_before_close"] = not client._reader.is_alive()
        row["returncode_field_before_reap"] = client.process.returncode
        if condition == "explicitly_reaped":
            row["wait_returncode"] = client.process.wait(timeout=2)
        try:
            client.close(timeout=1)
        except BaseException as error:
            row["first_close"] = {"error": type(error).__name__, "message": str(error),
                                  "traceback": traceback.format_exc()}
        else:
            row["first_close"] = {"ok": True}
    finally:
        # Reap our own already-EOF child, then record an explicit cleanup attempt.
        row["cleanup_reap_returncode"] = client.process.wait(timeout=2)
        try:
            client.close(timeout=1)
        except BaseException as error:
            row["cleanup_close"] = {"error": type(error).__name__, "message": str(error)}
        else:
            row["cleanup_close"] = {"ok": True}
        row["reader_alive_final"] = client._reader.is_alive()
    rows.append(row)
out = root / "eof-close-diagnostic.json"
with out.open("x") as f:
    json.dump(rows, f, indent=2)
print(json.dumps(rows, indent=2))

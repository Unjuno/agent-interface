# Independent saved-raw audit (Bugbot coauthor spot-check)

**Result: PASS — 18/18 checks.**

Baseline `6ec463eb907377ba41191127f4ea569d9ecfe142`; candidate `029064c797768183f63c79bbedbe3aca18f85dbb`. Freeze checked protocol, harness, inert peer and source-lock hashes; all 67 source blobs per arm match declared bytes and SHA-256.

| Cell | Result | Key behavior |
|---|---:|---|
| `baseline-rpc_error` | PASS | main_enter, session_write, await_enter, terminal_read, interrupt_enter, interrupt_result, external_rescue_enter, await_error, cleanup_entry, main_error, main_exit, external_rescue_return |
| `baseline-ack_complete` | PASS | main_enter, session_write, await_enter, terminal_read, interrupt_enter, interrupt_result, await_result, cleanup_entry, main_error, main_exit |
| `baseline-eof` | PASS | main_enter, session_write, await_enter, terminal_read, interrupt_enter, await_error, interrupt_result, cleanup_entry, main_error, main_exit |
| `baseline-ack_silent` | PASS | main_enter, session_write, await_enter, terminal_read, interrupt_enter, interrupt_result, external_rescue_enter, await_error, cleanup_entry, main_error, main_exit, external_rescue_return |
| `candidate-rpc_error` | PASS | main_enter, session_write, await_enter, terminal_read, interrupt_enter, interrupt_result, abort_enter, await_error, abort_result, cleanup_entry, main_error, main_exit |
| `candidate-ack_complete` | PASS | main_enter, session_write, await_enter, terminal_read, interrupt_enter, interrupt_result, await_result, cleanup_entry, main_error, main_exit |
| `candidate-eof` | PASS | main_enter, session_write, await_enter, terminal_read, interrupt_enter, await_error, interrupt_result, abort_enter, abort_error, cleanup_entry, main_error, main_exit |
| `candidate-ack_silent` | PASS | main_enter, session_write, await_enter, terminal_read, interrupt_enter, interrupt_result, external_rescue_enter, await_error, cleanup_entry, main_error, main_exit, external_rescue_return |

Candidate `rpc_error` returns from the matching wait after transport abort without external rescue. Baseline remains pending at the one-second watchdog, then wakes when the test closes the owned child. `ack_complete` returns a cancelled/ineligible planner result without abort; `ack_silent` needs watchdog rescue in both arms. Both EOF arms wake from the real peer closing stdout.

Candidate EOF detail: actual raw `abort_error` is `PermissionError: [Errno 1] Operation not permitted` from the redundant close racing an already-exiting owned process group. The reader had already observed EOF, `await_turn` had already raised `AppServerError`, and final raw records peer return code 0, reader/future retired, process group absent. So this did not prevent prompt wake or leave the group present, but it is a real client-close race worth fixing: reaping an already-exited leader before signaling its owned group should avoid the observed transient; preserve a second EPERM if it persists because a live descendant group may genuinely be unsignalable.

The root diagnostic independently reproduced PermissionError with an inert real-Popen child after reader EOF and found that reaping the leader before close avoided it. Do not interpret this as a hidden monkeypatch in this eight-cell job; the only monkeypatch seams here are the synthetic V39 session/reader/cleanup described in the freeze.

Limits: one schedule per condition; one-second watchdog censors baseline and ack-silent intervals, not a measured full 90-second wait; no model, GUI, game, native input, or physical-release proof. Ack-silent remains outside this repair. This is coauthor saved-raw verification, not a whole-PR nonauthor quorum vote.

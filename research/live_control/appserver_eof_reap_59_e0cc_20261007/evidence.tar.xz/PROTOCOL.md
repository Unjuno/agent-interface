# Turn28 real-transport construction

Frozen sources: baseline 6ec463eb907377ba41191127f4ea569d9ecfe142;
candidate 029064c797768183f63c79bbedbe3aca18f85dbb. Export closure is
67 tracked files per arm in source-lock.json, reconstructed at each exact ref.
This is an ordinary regression construction, not a formal live allocation.

H: after an ordinary failed cover, the candidate's abort can retire a real
inert child and wake the actual app-server/adapter wait before pool shutdown,
preserving the cover failure and preventing subsequent admission.
T: actual V39 main, ThreadPoolExecutor, PersistentPlannerAdapter and default
Popen CodexAppServerClient; one inert JSONL peer per fresh process. Four modes
per arm: interrupt RPC error without completion, acknowledged interrupt with
completed answer, EOF on interrupt, and acknowledged interrupt without completion.
Fixed baseline-then-candidate order, one schedule per cell, no performance inference.
Use Python 3.12.14 bundled runtime on macOS arm64. No GUI, game, native input,
model call, network, VM, or shared model service. The session, observations,
signal readers, and cleanup-entry spy are synthetic. Actual production cleanup
and physical release are not measured.

D: RPC-error candidate must abort, finish with the original cover failure, no
subsequent submit/admission, completed future, retired actual child/reader/group,
and no external rescue. Baseline must show its wait is still pending at the
watchdog and then retire after external close. Both EOF arms must retire without
rescue; ack-complete arms must retain cancelled answer ineligibility without
abort; ack-silent arms are expected to require rescue, documenting the unchanged
limit. All cells preserve primary cover failure and exactly one session submit.
Any contradiction is FAIL, any setup error is retained and repaired separately.
The watchdog starts a one-second construction grace after interrupt returns,
then closes this owned child if controller main has not exited. This censors
the baseline at that interval; it is not measurement of the full 90-second wait.
Configured adapter wait remains 90 seconds. Overall process orchestration caps
each cell at 20 seconds and retains command, exit status, stdout, stderr and raw.

C: mere EOF can explain wakeup; compare EOF and ack-complete controls. An
acknowledged but never completed interrupt is outside the repaired error branch.
U: one schedule per condition, variable host scheduling, no shutdown worst-case
bound. If close itself fails, the future can still wait for its notification
timeout; that separate failure path is not claimed fixed. Cleanup spy proves
handler entry only. Existing #8280 follow-up synthetic tests are predecessor
evidence; these results must not be pooled as model/native/game effectiveness.

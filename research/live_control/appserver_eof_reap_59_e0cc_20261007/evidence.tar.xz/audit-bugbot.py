"""Independent read-only audit of the eight frozen V39 real-Popen traces."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
freeze = json.loads((ROOT / "freeze.json").read_text())
lock = json.loads((ROOT / "source-lock.json").read_text())
checks = []
def check(name, ok, detail=None):
    checks.append({"name": name, "pass": bool(ok), "detail": detail})

# Freeze and source closure integrity.
freeze_checks = {}
for name, expected in freeze["files"].items():
    actual = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
    freeze_checks[name] = {"expected": expected, "actual": actual, "pass": actual == expected}
check("frozen_protocol_harness_peer_lock_hashes", all(x["pass"] for x in freeze_checks.values()), freeze_checks)
source_checks = {}
for arm in ("baseline", "candidate"):
    entries = lock["exports"][arm]
    rows = []
    for entry in entries:
        path = ROOT / arm / "source" / entry["path"]
        data = path.read_bytes() if path.is_file() else b""
        rows.append({"path": entry["path"], "pass": path.is_file() and len(data) == entry["bytes"] and hashlib.sha256(data).hexdigest() == entry["sha256"]})
    source_checks[arm] = {"count": len(rows), "pass_count": sum(row["pass"] for row in rows), "bad_paths": [row["path"] for row in rows if not row["pass"]]}
check("67_source_blobs_per_arm", all(x["count"] == 67 and x["pass_count"] == 67 for x in source_checks.values()), source_checks)

cell_results = {}
for arm in ("baseline", "candidate"):
    for mode in ("rpc_error", "ack_complete", "eof", "ack_silent"):
        key = f"{arm}-{mode}"
        run = ROOT / "runs" / key
        trace = json.loads((run / "trace.json").read_text())
        wire = [json.loads(line) for line in (run / "wire.jsonl").read_text().splitlines()]
        execution = json.loads((ROOT / "runs" / f"{key}.execution.json").read_text())
        timeline = trace["timeline"]
        names = [row["event"] for row in timeline]
        commands = trace["commands"]
        terminal_rows = [row for row in trace["events"] if row.get("event") == "terminal"]
        req = [row["message"] for row in wire if row.get("direction") == "sent" and row.get("message", {}).get("method") == "turn/interrupt"]
        replies = [row["message"] for row in wire if row.get("direction") == "received" and row.get("message", {}).get("id") == (req[0].get("id") if req else None)]
        cell = {"run": key, "trace_sha256": hashlib.sha256((run / "trace.json").read_bytes()).hexdigest(),
                "execution_exit_code": execution.get("exit_code"), "session_commands": commands,
                "terminal_count": len(terminal_rows), "interrupt_rpc_sent": len(req) == 1,
                "interrupt_rpc_reply_count": len(replies),
                "primary_error": trace.get("error"), "timeline_events": names,
                "watchdog_alive": trace.get("watchdog_alive"), "futures_done": trace.get("all_futures_done"),
                "reader_alive_final": trace.get("reader_alive"), "peer_returncode": trace.get("peer_returncode"),
                "process_group_absent": trace.get("process_group_absent")}
        common = (trace.get("mode") == mode and execution.get("exit_code") == 0 and
                  len(commands) == 1 and commands[0].get("op") == "submit" and
                  len(terminal_rows) == 1 and terminal_rows[0].get("status") == "failed" and
                  terminal_rows[0].get("error") == "injected input error" and
                  terminal_rows[0].get("release") == {"verified": True, "keys_down": [], "buttons_down": []} and
                  trace.get("error", {}).get("type") == "RuntimeError" and
                  "cover terminal lacks allowed status" in trace.get("error", {}).get("message", "") and
                  "final_admission" not in names and trace.get("all_futures_done") is True and
                  trace.get("reader_alive") is False and trace.get("peer_returncode") is not None and
                  trace.get("process_group_absent") is True and trace.get("watchdog_alive") is False)
        check(f"{key}:common_fail_closed_and_retired", common, cell)
        if mode == "rpc_error":
            if arm == "baseline":
                rescue = next((x for x in timeline if x["event"] == "external_rescue_enter"), None)
                check(f"{key}:waits_for_external_close", rescue is not None and rescue.get("unfinished_futures") == 1 and
                      "abort_enter" not in names, rescue)
            else:
                check(f"{key}:candidate_abort_wakes_waiter", "abort_enter" in names and "abort_result" in names and
                      "external_rescue_enter" not in names and names.index("abort_enter") < names.index("await_error") < names.index("abort_result"), names)
        elif mode == "ack_complete":
            result = next((x for x in timeline if x["event"] == "await_result"), {})
            check(f"{key}:acknowledged_completion_is_ineligible", result.get("eligible") is False and
                  result.get("cancelled") is True and result.get("status") == "completed" and
                  "abort_enter" not in names and "external_rescue_enter" not in names, result)
        elif mode == "eof":
            err = next((x for x in timeline if x["event"] == "await_error"), {})
            check(f"{key}:eof_wakes_waiter_without_rescue", err.get("kind") == "AppServerError" and
                  "external_rescue_enter" not in names and trace.get("peer_returncode") == 0,
                  {"await_error": err, "abort_error": next((x for x in timeline if x["event"] == "abort_error"), None),
                   "peer_returncode": trace.get("peer_returncode")})
        elif mode == "ack_silent":
            rescue = next((x for x in timeline if x["event"] == "external_rescue_enter"), None)
            check(f"{key}:ack_without_completion_needs_rescue", rescue is not None and
                  rescue.get("unfinished_futures") == 1 and "abort_enter" not in names,
                  {"rescue": rescue, "await_result": any(x["event"] == "await_result" for x in timeline)})
        cell_results[key] = cell

passed = sum(row["pass"] for row in checks)
result = {
    "format": "v39-real-transport-independent-audit-bugbot-v1",
    "protocol_sha256": freeze["files"]["PROTOCOL.md"],
    "source_lock_sha256": freeze["files"]["source-lock.json"],
    "baseline_ref": lock["refs"]["baseline"],
    "candidate_ref": lock["refs"]["candidate"],
    "source_blobs": source_checks,
    "cells": cell_results,
    "checks_passed": passed,
    "checks_total": len(checks),
    "checks": checks,
    "overall_pass": passed == len(checks),
    "interpretation": {
        "scope": "actual V39 main + ThreadPoolExecutor + PersistentPlannerAdapter + real subprocess.Popen CodexAppServerClient; synthetic session, observation, cleanup spy and inert JSONL peer; no model/game/GUI/native input",
        "candidate_rpc_error": "No rescue; app-server close causes reader EOF and wakes waiter; original failed-cover RuntimeError is retained",
        "eof_close": "Candidate observes AppServerError on EOF before abort. abort_pending_turn then makes a redundant close attempt that reports PermissionError, but raw final state has peer exit 0, reader retired, future done, and process group absent. This is a cleanup diagnostic race, not evidence of a leaked child or failed wakeup.",
        "limits": ["one schedule per cell", "1-second watchdog censors baseline and ack-silent cells", "acknowledged-but-never-completed interrupt still requires rescue", "close failure remains unverified path", "cleanup spy verifies handler entry only; no physical release or production controller cleanup proof"]
    }
}
out = ROOT / "audit-bugbot.json"
out.write_text(json.dumps(result, indent=2) + "\n")
md = ["# Independent saved-raw audit (Bugbot coauthor spot-check)", "",
      f"**Result: {'PASS' if result['overall_pass'] else 'FAIL'} — {passed}/{len(checks)} checks.**",
      "",
      f"Baseline `{result['baseline_ref']}`; candidate `{result['candidate_ref']}`. Freeze checked protocol, harness, inert peer and source-lock hashes; all 67 source blobs per arm match declared bytes and SHA-256.", "",
      "| Cell | Result | Key behavior |", "|---|---:|---|"]
for k, c in cell_results.items():
    md.append(f"| `{k}` | {'PASS' if any(x['pass'] for x in checks if x['name'].startswith(k+':')) and next(x['pass'] for x in checks if x['name']==k+':common_fail_closed_and_retired') else 'FAIL'} | {', '.join(c['timeline_events'])} |")
md += ["", "Candidate `rpc_error` returns from the matching wait after transport abort without external rescue. Baseline remains pending at the one-second watchdog, then wakes when the test closes the owned child. `ack_complete` returns a cancelled/ineligible planner result without abort; `ack_silent` needs watchdog rescue in both arms. Both EOF arms wake from the real peer closing stdout.",
       "", "Candidate EOF detail: actual raw `abort_error` is `PermissionError: [Errno 1] Operation not permitted` from the redundant close racing an already-exiting owned process group. The reader had already observed EOF, `await_turn` had already raised `AppServerError`, and final raw records peer return code 0, reader/future retired, process group absent. So this did not prevent prompt wake or leave the group present, but it is a real client-close race worth fixing: reaping an already-exited leader before signaling its owned group should avoid the observed transient; preserve a second EPERM if it persists because a live descendant group may genuinely be unsignalable.",
       "", "The root diagnostic independently reproduced PermissionError with an inert real-Popen child after reader EOF and found that reaping the leader before close avoided it. Do not interpret this as a hidden monkeypatch in this eight-cell job; the only monkeypatch seams here are the synthetic V39 session/reader/cleanup described in the freeze.",
       "", "Limits: one schedule per condition; one-second watchdog censors baseline and ack-silent intervals, not a measured full 90-second wait; no model, GUI, game, native input, or physical-release proof. Ack-silent remains outside this repair. This is coauthor saved-raw verification, not a whole-PR nonauthor quorum vote.", ""]
(ROOT / "audit-bugbot.md").write_text("\n".join(md))
print(json.dumps({"overall_pass": result["overall_pass"], "checks": f"{passed}/{len(checks)}", "audit": str(out), "report": str(ROOT / "audit-bugbot.md")}, indent=2))

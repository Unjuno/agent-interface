"""MAP01 controller with unauthored-coast liveness after rejected action."""
import argparse
import atexit
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import queue
import subprocess
import sys
import threading
import time
from pathlib import Path
from PIL import Image, ImageDraw

from map01_stagnation_v1 import descriptor, normalized_mae

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
sys.path.insert(0, str(HERE.parent / "live_control"))
from doom_hud_signal_v3 import DoomStatusNumberReader
from doom_controller_failure_cleanup_v1 import ControllerFailureCleanup
from doom_source_refresh_v1 import refresh_source, SourceRefreshRefused
from doom_typed_observation_v1 import (
    build_action_snapshot as build_typed_action_snapshot,
    reconcile_artifact)
from doom_action_validity_contract_v1 import (
    bindings_equal_exact, build_contract as build_action_contract)
from observable_signal_guard_v2 import ObservableSignalGuard, ObservableSignalPolicyMonitor
from codex_app_server_client_v2 import CodexAppServerClient
from persistent_planner_adapter_v2 import PersistentPlannerAdapter
from final_action_admission_v2 import (
    decide_final_admission, record_controller_no_input,
    record_action_validity, record_executor_admission)
from action_validity_admission_v1 import SNAPSHOT_FORMAT, evaluate_action_validity
from running_action_guard_v1 import (
    ACTIVE as RUNNING_ACTIVE, BETWEEN as RUNNING_BETWEEN,
    CANCEL as RUNNING_CANCEL, COMPLETED as RUNNING_COMPLETED,
    READY as RUNNING_READY, REJECTED as RUNNING_REJECTED,
    REVOKED as RUNNING_REVOKED, RunningActionGuard)
from running_action_guard_v2 import RunningActionGuardV2
from running_action_guard_v3 import RunningActionGuardV3
from doom_action_snapshot_v1 import build_action_snapshot
NODE = "/mnt/c/Program Files/nodejs/node.exe"
CLI = r"C:\Users\junny\AppData\Roaming\npm\node_modules\@openai\codex\bin\codex.js"
DISABLED_FEATURES = [
    "apps", "plugins", "remote_plugin", "browser_use", "browser_use_external",
    "computer_use", "in_app_browser", "code_mode", "code_mode_host",
]
DISABLED_MCPS = ["blender", "chrome-devtools", "node_repl", "playwright", "puppeteer"]
WAD = REPO / "_vizdoom/vizdoom/freedoom2.wad"
MAX_AUTHORED_HEALTH_LOSS = 20
STALE_SEQUENCE_REJECTION_REASON = "latest observation sequence required before input"


def classify_cover_renewal_response(response):
    """Treat only an expected stale-sequence rejection as no renewal admission."""
    if type(response) is dict and response.get("event") == "accepted":
        return {"status": "accepted"}
    if (type(response) is dict and response.get("event") == "rejected" and
            response.get("reason") == STALE_SEQUENCE_REJECTION_REASON):
        return {"status": "stale_sequence_no_cover",
                "reason": STALE_SEQUENCE_REJECTION_REASON}
    raise RuntimeError(response)


def wait_without_active_cover(wait, observation_monitor, planner, planner_handle):
    """Keep observing while inference runs after a rejected, unadmitted renewal."""
    try:
        boundary = wait(lambda row: False, timeout=.1,
                        observation_monitor=observation_monitor)
    except TimeoutError:
        return None
    if boundary.get("event") not in ("policy_invalidation", "running_action_invalidation"):
        raise RuntimeError(boundary)
    invalidation = boundary.get("invalidation", boundary)
    return {"invalidation": invalidation,
            "planner_interrupt": planner.interrupt(planner_handle)}


def reusable_cover(decisions):
    if (decisions and not decisions[-1].get("model_action_discarded") and
            decisions[-1]["action"]["state"] == "active"):
        validity = decisions[-1]["action"]["next_cover_validity"]
        return (decisions[-1]["action"]["next_cover"], validity[0],
                decisions[-1]["iteration"])
    return [], None, None


class UnauthoredCoastMonitor:
    """No policy can become invalid when coast grants no action authority.

    Exact observations still update latest and fresh immediate action validity
    still gates any model answer before input. This suppresses only a redundant
    planner interruption caused by damage to an empty runtime fallback.
    """
    event_types = frozenset()
    soft_event_count = 0
    latest_soft_event = None

    def observe(self, observation):
        raise AssertionError("unauthored coast must not evaluate a policy")


def select_cover_monitor(monitor, admission, commands, source_iteration):
    if source_iteration is None and not commands and admission["authored"] is None:
        admission = dict(admission)
        admission["monitor_mode"] = "unauthored_coast_no_policy"
        return UnauthoredCoastMonitor(), admission
    admission = dict(admission)
    admission["monitor_mode"] = "authored_policy_guard"
    return monitor, admission


def guard_spec(validity, source_signal, index):
    critical = source_signal["value"] if validity is None else validity["critical_health_minimum"]
    maximum_loss = 0 if validity is None else validity["maximum_health_loss"]
    return {
        "op": "observable_signal_guard",
        "guard_id": f"map01-{index}",
        "source_sequence": source_signal["sequence"],
        "signal_id": "health",
        "source_value": source_signal["value"],
        "hard_minimum": max(critical, source_signal["value"] - maximum_loss),
        "max_source_age_ms": 30000 if validity is None else validity["max_source_age_ms"],
        "on_soft_change": "preserve_existing_policy",
        "on_hard_change": "needs_decision",
        "on_unknown": "needs_decision",
    }


def ammo_guard_spec(source_signal, index, max_source_age_ms):
    return {
        "op": "observable_signal_guard",
        "guard_id": f"map01-{index}-ammo",
        "source_sequence": source_signal["sequence"],
        "signal_id": "ammo",
        "source_value": source_signal["value"],
        "hard_minimum": 1,
        "max_source_age_ms": max_source_age_ms,
        "on_soft_change": "preserve_existing_policy",
        "on_hard_change": "needs_decision",
        "on_unknown": "needs_decision",
    }


def _typed_json_equal(left, right):
    """Compare JSON-shaped identity values without Python bool/int aliases."""
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        if (any(type(key) is not str for key in left) or
                any(type(key) is not str for key in right) or
                left.keys() != right.keys()):
            return False
        return all(_typed_json_equal(left[key], right[key]) for key in left)
    if type(left) is list:
        return (len(left) == len(right) and
                all(_typed_json_equal(a, b) for a, b in zip(left, right)))
    return left == right


def _signal_pair_matches(observation, signals):
    sequence = observation.get("sequence")
    capture_ns = observation.get("capture_ns")
    binding = observation.get("pointer_binding")
    if (type(sequence) is not int or sequence < 1 or
            type(capture_ns) is not int or capture_ns < 1 or
            type(binding) is not dict):
        return False
    for signal_id in ("health", "ammo"):
        signal = signals.get(signal_id)
        if (type(signal) is not dict or signal.get("status") != "observed" or
                signal.get("signal_id") != signal_id or
                type(signal.get("sequence")) is not int or
                type(signal.get("capture_ns")) is not int or
                signal.get("sequence") != sequence or
                signal.get("capture_ns") != capture_ns or
                not _typed_json_equal(signal.get("binding"), binding)):
            return False
    return True


def _signal_pair_content_matches(left, right):
    for signal_id in ("health", "ammo"):
        first = left.get(signal_id)
        second = right.get(signal_id)
        if type(first) is not dict or type(second) is not dict:
            return False
        for field in ("status", "signal_id", "value", "sequence",
                      "capture_ns", "binding"):
            if not _typed_json_equal(first.get(field), second.get(field)):
                return False
    return True


class DoomCoverSignalPairMonitor:
    """Invalidate fire cover on incoherent or invalid paired health/ammo evidence."""

    event_types = {"typed_observation", "observation"}

    def __init__(self, guards, health_reader, ammo_reader):
        self.guards = guards
        self.readers = {"health": health_reader, "ammo": ammo_reader}
        self.last_values = {name: guard.spec["source_value"]
                            for name, guard in guards.items()}
        self.last_sequence = guards["health"].spec["source_sequence"]
        self.last_capture_ns = guards["health"].source_capture_ns
        self.last_event_kind = None
        self.last_binding = None
        self.last_frame_rgb_sha256 = None
        self.last_signals = None
        self.soft_event_count = 0
        self.latest_soft_event = None

    def _invalidation(self, observation, reason, signals=None, outcomes=None,
                      outcome=None):
        evaluated_ns = time.perf_counter_ns()
        if outcome is None:
            outcome = {
                "status": "UNKNOWN", "reason": reason,
                "requires_new_decision": True,
                "grants_input_authority": False,
                "may_only_preserve_or_reduce_existing_authority": True,
                "task_success_verified": False,
            }
        return {
            "event": "paired_signal_invalidation",
            "reason": reason,
            "sequence": observation.get("sequence"),
            "signals": signals,
            "outcomes": outcomes,
            "outcome": outcome,
            "outcome_evaluated_ns": evaluated_ns,
            "requires_new_decision": True,
            "grants_input_authority": False,
        }

    def observe(self, observation):
        received_ns = time.perf_counter_ns()
        event_kind = observation.get("event")
        sequence = observation.get("sequence")
        capture_ns = observation.get("capture_ns")
        binding = observation.get("pointer_binding")

        if event_kind == "typed_observation":
            signals = observation.get("signals")
            if type(signals) is not dict:
                return self._invalidation(observation, "signal_pair_missing")
        elif event_kind == "observation":
            try:
                signals = {name: reader.read(observation)
                           for name, reader in self.readers.items()}
            except (OSError, ValueError, TypeError, KeyError):
                return self._invalidation(
                    observation, "signal_pair_source_unavailable")
        else:
            return self._invalidation(observation, "signal_pair_event_type_invalid")
        if not _signal_pair_matches(observation, signals):
            return self._invalidation(observation, "signal_pair_epoch_mismatch", signals)

        # Support either transport order once, but compare both paired signal
        # projections even when typed evidence arrives first.
        if (event_kind != self.last_event_kind and
                self.last_event_kind in {"typed_observation", "observation"} and
                type(sequence) is int and sequence == self.last_sequence and
                type(capture_ns) is int and capture_ns == self.last_capture_ns):
            frame_hash = observation.get("frame_rgb_sha256")
            if (not _typed_json_equal(binding, self.last_binding) or
                    not _signal_pair_content_matches(signals, self.last_signals) or
                    (self.last_frame_rgb_sha256 is not None and frame_hash is not None and
                     frame_hash != self.last_frame_rgb_sha256)):
                return self._invalidation(
                    observation, "signal_pair_duplicate_epoch_mismatch", signals)
            self.last_signals = signals
            self.last_binding = binding
            self.last_frame_rgb_sha256 = frame_hash
            self.last_event_kind = event_kind
            return None

        if observation["sequence"] <= self.last_sequence:
            return self._invalidation(
                observation, "signal_pair_nonadvancing_sequence", signals)
        if observation["capture_ns"] <= self.last_capture_ns:
            return self._invalidation(
                observation, "signal_pair_nonadvancing_capture_time", signals)
        self.last_sequence = observation["sequence"]
        self.last_capture_ns = observation["capture_ns"]

        outcomes = {name: guard.evaluate(signals[name])
                    for name, guard in self.guards.items()}
        evaluated_ns = time.perf_counter_ns()
        invalid = [(name, outcome) for name, outcome in outcomes.items()
                   if outcome["requires_new_decision"]]
        if invalid:
            name, outcome = invalid[0]
            result = self._invalidation(
                observation, f"{name}:{outcome['reason']}", signals, outcomes,
                outcome)
            result.update({"monitor_received_ns": received_ns,
                           "outcome_evaluated_ns": evaluated_ns})
            return result

        for name, outcome in outcomes.items():
            value = signals[name]["value"]
            if outcome["status"] == "SOFT_CHANGED" and value != self.last_values[name]:
                self.soft_event_count += 1
                self.latest_soft_event = {
                    "sequence": observation["sequence"],
                    "signal": signals[name], "outcome": outcome,
                    "monitor_received_ns": received_ns,
                    "outcome_evaluated_ns": evaluated_ns,
                }
            self.last_values[name] = value
        self.last_event_kind = event_kind
        self.last_binding = binding
        self.last_frame_rgb_sha256 = observation.get("frame_rgb_sha256")
        self.last_signals = signals
        return None


def build_cover_monitor(reader, source_observation, authored_validity, index,
                        *, ammo_reader=None, requires_ammo=False):
    source_signal = reader.read(source_observation)
    if source_signal["status"] != "observed" or source_signal["value"] < 1:
        raise RuntimeError("cover validity source health unavailable")
    if authored_validity is not None:
        expected = {"signal_id", "critical_health_minimum", "maximum_health_loss",
                    "max_source_age_ms"}
        if (type(authored_validity) is not dict or set(authored_validity) != expected or
                authored_validity["signal_id"] != "health" or
                type(authored_validity["critical_health_minimum"]) is not int or
                not 1 <= authored_validity["critical_health_minimum"] <= 200 or
                type(authored_validity["maximum_health_loss"]) is not int or
                not 0 <= authored_validity["maximum_health_loss"] <= MAX_AUTHORED_HEALTH_LOSS or
                type(authored_validity["max_source_age_ms"]) is not int or
                not 100 <= authored_validity["max_source_age_ms"] <= 30000):
            raise ValueError("exact typed health validity required")
    if authored_validity is None:
        admission_status = "admitted"
    elif authored_validity["critical_health_minimum"] > source_signal["value"]:
        admission_status = "rejected_source_below_hard_minimum"
    else:
        admission_status = "admitted"
    admitted = admission_status == "admitted"
    effective = authored_validity if admitted else None
    spec = guard_spec(effective, source_signal, index)
    guard = ObservableSignalGuard(spec, source_signal, source_signal["binding"])
    monitor = ObservableSignalPolicyMonitor(guard, reader)
    ammo_source = None
    if requires_ammo:
        if ammo_reader is None:
            raise ValueError("ammo reader required for fire cover")
        ammo_source = ammo_reader.read(source_observation)
        pair = {"health": source_signal, "ammo": ammo_source}
        if not _signal_pair_matches(source_observation, pair):
            return monitor, {
                "status": "rejected_source_health_ammo_pair",
                "authored": authored_validity,
                "effective": {"signal_id": "health",
                              "critical_health_minimum": spec["hard_minimum"],
                              "maximum_health_loss": 0 if effective is None else
                                  effective["maximum_health_loss"],
                              "hard_minimum": spec["hard_minimum"],
                              "max_source_age_ms": spec["max_source_age_ms"]},
                "source_signal": source_signal, "source_ammo_signal": ammo_source,
                "grants_input_authority": False,
            }
        if type(ammo_source.get("value")) is not int or ammo_source["value"] < 1:
            return monitor, {
                "status": "rejected_source_ammo_below_positive_floor",
                "authored": authored_validity,
                "effective": {"signal_id": "health",
                              "critical_health_minimum": spec["hard_minimum"],
                              "maximum_health_loss": 0 if effective is None else
                                  effective["maximum_health_loss"],
                              "hard_minimum": spec["hard_minimum"],
                              "max_source_age_ms": spec["max_source_age_ms"]},
                "source_signal": source_signal, "source_ammo_signal": ammo_source,
                "grants_input_authority": False,
            }
        ammo_spec = ammo_guard_spec(ammo_source, index, spec["max_source_age_ms"])
        ammo_guard = ObservableSignalGuard(
            ammo_spec, ammo_source, ammo_source["binding"])
        monitor = DoomCoverSignalPairMonitor(
            {"health": guard, "ammo": ammo_guard}, reader, ammo_reader)
    receipt = {
        "status": admission_status,
        "authored": authored_validity,
        "effective": {"signal_id": "health",
                      "critical_health_minimum": source_signal["value"] if effective is None else
                          effective["critical_health_minimum"],
                      "maximum_health_loss": 0 if effective is None else
                          effective["maximum_health_loss"],
                      "hard_minimum": spec["hard_minimum"],
                      "max_source_age_ms": spec["max_source_age_ms"]},
        "source_signal": source_signal,
        "source_ammo_signal": ammo_source,
        "monitor_mode": "paired_health_ammo" if requires_ammo else "health_only",
        "grants_input_authority": False,
    }
    return monitor, receipt


def require_cover_terminal(terminal, *, cancellation_requested=False):
    """Require neutral closure before renewing cover or using a planner answer."""
    allowed = ("completed", "expired", "cancelled") if cancellation_requested else (
        "completed", "expired")
    release = terminal.get("release") if type(terminal) is dict else None
    if (type(terminal) is not dict or terminal.get("event") != "terminal" or
            terminal.get("status") not in allowed or type(release) is not dict or
            release.get("verified") is not True or release.get("keys_down") != [] or
            release.get("buttons_down") != []):
        raise RuntimeError(f"cover terminal lacks allowed status and verified empty release: {terminal!r}")


def cancel_invalidated_cover(planner, planner_handle, process, wait, cover_id,
                             planner_interrupt=None):
    if planner_interrupt is None:
        planner_interrupt = planner.interrupt(planner_handle)
    process.stdin.write(json.dumps({"op": "cancel", "id": cover_id}) + "\n")
    process.stdin.flush()
    terminal = wait(lambda row: row["event"] == "terminal" and row.get("id") == cover_id)
    release = terminal.get("release", {})
    # The bounded cover can naturally finish or lease-expire between policy
    # invalidation and delivery of the cancel request. Accept those terminal
    # races only when they independently verify that no input remains held.
    if (terminal.get("status") not in ("cancelled", "completed", "expired") or
            release.get("verified") is not True or
            release.get("buttons_down") != [] or release.get("keys_down") != []):
        raise RuntimeError("invalidated cover did not verify empty release")
    return planner_interrupt, terminal


def wait_for_invalidation_frame(latest, invalidation, wait, timeout=5):
    """Require the RGB observation paired with invalidation before replanning."""
    sequence = invalidation.get("sequence") if type(invalidation) is dict else None
    capture_ns = invalidation.get("capture_ns") if type(invalidation) is dict else None
    binding = invalidation.get("pointer_binding") if type(invalidation) is dict else None
    frame_hash = invalidation.get("frame_rgb_sha256") if type(invalidation) is dict else None
    if (type(sequence) is not int or sequence < 1 or
            type(capture_ns) is not int or capture_ns < 1 or type(binding) is not dict or
            (frame_hash is not None and
             (type(frame_hash) is not str or len(frame_hash) != 64))):
        raise RuntimeError("policy invalidation lacks a valid observation identity")

    def qualifies(row):
        return (type(row) is dict and row.get("event") == "observation" and
                type(row.get("sequence")) is int and row["sequence"] >= sequence and
                type(row.get("capture_ns")) is int and row["capture_ns"] >= capture_ns and
                _typed_json_equal(row.get("pointer_binding"), binding) and
                (frame_hash is None or row.get("frame_rgb_sha256") == frame_hash))

    if qualifies(latest):
        return latest
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        return wait(qualifies, timeout=max(.001, end - time.monotonic()))
    raise TimeoutError("fresh full observation did not follow policy invalidation")


def cancel_invalidated_cover_before_plan(process, wait, cover_id):
    """Cancel an invalidated initial cover and require release before retrying."""
    process.stdin.write(json.dumps({"op": "cancel", "id": cover_id}) + "\n")
    process.stdin.flush()
    requested = wait(lambda row: row.get("event") == "cancel_requested" and
                     row.get("id") == cover_id)
    released = wait(lambda row: row.get("event") in
                    ("input_released", "input_release_unverified") and
                    row.get("id") == cover_id)
    terminal = wait(lambda row: row.get("event") == "terminal" and
                    row.get("id") == cover_id)
    owner_release = released.get("owner_release", {})
    terminal_release = terminal.get("release", {})
    if (requested.get("matched") is not True or
            released.get("event") != "input_released" or
            released.get("program_terminal_pending") is not True or
            released.get("grants_input_authority") is not False or
            owner_release.get("verified") is not True or
            owner_release.get("keys_down") != [] or
            owner_release.get("buttons_down") != [] or
            terminal.get("status") != "cancelled" or
            terminal_release.get("verified") is not True or
            terminal_release.get("keys_down") != [] or
            terminal_release.get("buttons_down") != []):
        raise RuntimeError("invalidated initial cover did not verify empty release")
    return {"cancel_requested": requested, "input_released": released,
            "terminal": terminal}


def resolve_invalidated_cover_submission(wait, cover_id):
    """Distinguish an accepted cover from a submit rejected during invalidation."""
    response = wait(lambda row: row.get("event") in ("accepted", "rejected") and
                    (row.get("id") == cover_id or row.get("event") == "rejected"))
    if response.get("event") == "rejected":
        return {"status": "rejected", "response": response}
    return {"status": "accepted", "response": response}


def admitted_cover_commands(commands, validity_admission):
    if validity_admission.get("status") != "admitted":
        return []
    return list(commands)


def cover_requires_ammo(commands):
    return any(command.get("action") in ("fire", "advance_fire", "retreat_fire")
               for command in commands)


def latest_soft_event_summary(decisions):
    """Return bounded semantic evidence from the immediately preceding interval."""
    if not decisions:
        return None
    decision = decisions[-1]
    count = decision.get("cover_validity_soft_events", 0)
    event = decision.get("cover_validity_latest_soft_event")
    if count == 0 and event is None:
        return None
    if type(count) is not int or count < 1 or type(event) is not dict:
        raise RuntimeError("inconsistent prior soft-event evidence")
    outcome = event.get("outcome")
    signal = event.get("signal")
    iteration = decision.get("iteration")
    source_iteration = decision.get("cover_policy_source_iteration")
    if (type(outcome) is not dict or type(signal) is not dict or
            signal.get("signal_id") not in ("health", "ammo") or
            outcome.get("signal_id") != signal.get("signal_id") or
            outcome.get("status") != "SOFT_CHANGED" or
            outcome.get("reason") != "within_validity_envelope" or
            outcome.get("keep_existing_policy") is not True or
            outcome.get("requires_new_decision") is not False or
            outcome.get("grants_input_authority") is not False or
            outcome.get("may_only_preserve_or_reduce_existing_authority") is not True or
            type(outcome.get("source_value")) is not int or
            type(outcome.get("current_value")) is not int or
            type(outcome.get("hard_minimum")) is not int or
            type(event.get("sequence")) is not int or event.get("sequence") < 1 or
            type(iteration) is not int or iteration < 0 or
            type(source_iteration) is not int or source_iteration < 0 or
            event.get("sequence") != signal.get("sequence") or
            outcome.get("current_value") != signal.get("value") or
            outcome.get("current_value") < outcome.get("hard_minimum")):
        raise RuntimeError("invalid prior soft-event evidence")
    return {
        "signal_id": signal["signal_id"],
        "source_value": outcome["source_value"],
        "current_value": outcome["current_value"],
        "hard_minimum": outcome["hard_minimum"],
        "soft_event_count": count,
        "sequence": event["sequence"],
        "observed_during_iteration": iteration,
        "cover_policy_source_iteration": source_iteration,
        "effect": "prior_cover_preserved",
        "grants_input_authority": False,
    }


def final_admission_from_planner_result(planner_result, terminal_observed_ns,
                                        policy_invalidation, decided_ns):
    return decide_final_admission({
        "turn_id": planner_result.handle.turn_id,
        "status": planner_result.status,
        "answer_eligible": planner_result.answer_eligible,
        "terminal_observed_ns": terminal_observed_ns,
    }, policy_invalidation, decided_ns)


def bind_first_plan_acceptance(receipt, record):
    expected = {"id", "accepted_ns"}
    if type(record) is not dict or not expected.issubset(record):
        raise ValueError("first execution record lacks admission evidence")
    return record_executor_admission(receipt, {
        "event": "accepted", "id": record["id"],
        "accepted_ns": record["accepted_ns"]})


def prepare_action_admission(receipt, action, authored, source_health,
                             source_ammo, current_health, current_ammo,
                             decided_ns):
    """Bind planner semantics to exact signals and re-evaluate at final admission."""
    contract = build_action_contract(
        action["commands"], authored, source_health, source_ammo)
    required = contract["source"]["signals"]
    current = {"health": {"status": current_health["status"],
                          "value": current_health["value"]}}
    if "ammo" in required:
        if any(type(signal[field]) is not int
               for signal in (current_health, current_ammo)
               for field in ("sequence", "capture_ns")):
            raise ValueError(
                "current health and ammo epoch metadata must be exact integers")
        if (current_ammo["sequence"] != current_health["sequence"] or
                current_ammo["capture_ns"] != current_health["capture_ns"] or
                not bindings_equal_exact(current_ammo["binding"],
                                         current_health["binding"])):
            raise ValueError("current health and ammo must share one observation epoch")
        current["ammo"] = {"status": current_ammo["status"],
                           "value": current_ammo["value"]}
    snapshot = {"format": SNAPSHOT_FORMAT,
                "sequence": current_health["sequence"],
                "capture_ns": current_health["capture_ns"],
                "binding": current_health["binding"], "signals": current}
    validity = evaluate_action_validity(
        action["commands"], contract, snapshot, decided_ns)
    return record_action_validity(receipt, action["commands"], validity)


class DoomRunningActionMonitor:
    """Adapt exact session observations to one no-input running guard."""

    event_name = "running_action_invalidation"
    event_types = {"typed_observation"}

    def __init__(self, guard, health_reader, ammo_reader):
        self.guard = guard
        contract = guard.guard.contract if isinstance(guard, RunningActionGuardV2) else guard.contract
        required = set(contract["source"]["signals"])
        self.contract = contract
        readers = {"health": health_reader, "ammo": ammo_reader}
        self.readers = {name: readers[name] for name in required}
        self.last_receipt = guard.receipt()

    def observe(self, observation, decided_ns=None):
        snapshot = (build_typed_action_snapshot(observation, self.contract)
                    if observation.get("event") == "typed_observation"
                    else build_action_snapshot(observation, self.contract, self.readers))
        decided_ns = time.perf_counter_ns() if decided_ns is None else decided_ns
        self.last_receipt = self.guard.check_current(snapshot, decided_ns)
        if self.last_receipt["state"] in (RUNNING_CANCEL, RUNNING_REJECTED):
            result = {"event": self.event_name,
                      "running_action_guard": self.last_receipt}
            if observation.get("event") == "typed_observation":
                result["source_event"] = {key: observation[key] for key in (
                        "schema", "id", "step", "sequence", "capture_ns",
                        "pointer_binding", "signals", "frame_rgb_sha256",
                        "typed_ready_ns", "emit_ns")}
            return result
        return None


def persist_running_invalidation(root, identifier, boundary):
    """Persist the exact decision before terminal validation can fail."""
    guard = boundary.get("running_action_guard") if type(boundary) is dict else None
    source = boundary.get("source_event") if type(boundary) is dict else None
    if (boundary.get("event") != "running_action_invalidation" or
            type(guard) is not dict or guard.get("state") not in
            (RUNNING_CANCEL, RUNNING_REJECTED) or
            type(source) is not dict or source.get("schema") !=
            "doom-typed-observation-v1" or
            guard.get("invalidation", {}).get("result", {}).get(
                "snapshot", {}).get("capture_ns") != source.get("capture_ns")):
        raise ValueError("exact typed running invalidation required")
    path = Path(root) / f"running-invalidation-{identifier}.json"
    path.write_text(json.dumps(boundary, indent=2) + "\n",
                    encoding="utf-8", newline="\n")
    return path


def cancel_invalidated_action(process, wait, identifier, guard):
    """Publish physical release first, then require terminal lifecycle closure."""
    process.stdin.write(json.dumps({"op": "cancel", "id": identifier}) + "\n")
    process.stdin.flush()
    event = wait(lambda row: row.get("event") == "cancel_requested" and
                 row.get("id") == identifier)
    guard.record_cancel_requested({
        "event": "cancel_requested", "id": event["id"],
        "matched": event["matched"], "requested_ns": event["requested_ns"]})
    released = wait(lambda row: row.get("event") == "input_released" and
                    row.get("id") == identifier)
    release_receipt = guard.record_input_released({key: released[key] for key in (
        "event", "id", "intent_token", "owner_release", "published_ns",
        "program_terminal_pending", "grants_input_authority")})
    terminal = wait(lambda row: row.get("event") == "terminal" and
                    row.get("id") == identifier)
    receipt = guard.record_cancelled_terminal(terminal)
    return event, released, release_receipt, terminal, receipt


def win(path):
    return subprocess.run(["wslpath", "-w", str(Path(path).resolve())],
                          check=True, capture_output=True, text=True).stdout.strip()


def app_server_command():
    command = [NODE, CLI, "app-server", "--stdio"]
    for feature in DISABLED_FEATURES:
        command += ["--disable", feature]
    for name in DISABLED_MCPS:
        command += ["-c", f"mcp_servers.{name}.enabled=false"]
    return command


def session_command(args, runtime):
    # Keep v12 as default; v15 adds scorer-only progress sampling.
    session = ("session_map01_v15.py"
               if getattr(args, "measurement_session", False)
               else "session_map01_v12.py")
    command = [sys.executable, str(HERE / session),
               "--out", str(runtime), "--seed", str(args.seed),
               "--timeout-seconds", "600", "--skill", "1",
               "--load-fixture-manifest", str(args.load_fixture_manifest.resolve())]
    if getattr(args, "per_key_input_measurement", False):
        command.append("--per-key-input-measurement")
    return command


def validate_action(action):
    if action["state"] == "active" and not action["commands"]:
        raise ValueError("active state requires a motor command")
    if action["state"] == "active" and len(action["next_cover_validity"]) != 1:
        raise ValueError("active state requires one next_cover_validity")
    if action["state"] == "active" and len(action["action_validity"]) != 1:
        raise ValueError("active state requires one immediate action_validity")
    if action["state"] != "active" and (action["commands"] or action["contingencies"] or
            action["next_cover"] or action["next_cover_validity"] or
            action["action_validity"]):
        raise ValueError("terminal state requires empty commands, contingencies, cover and validity")
    indices=[row["after_command"] for row in action["contingencies"]]
    if len(indices)!=len(set(indices)) or any(index>=len(action["commands"]) for index in indices):
        raise ValueError("contingency indices must be unique primary command indices")


def begin_model_turn(planner, root, image, effect_memory, source_health, source_ammo,
                     prior_soft_event_summary, output_schema,
                     prior_state_feedback=None):
    prompt_text = ("Select the next bounded MAP01 action from the new temporal sheet.\n"
                   + f"Current locally verified health: {source_health}.\n"
                   + f"Current locally verified ammo: {source_ammo}.\n"
                   + "Newest typed soft event from the preceding control interval: "
                   + json.dumps(prior_soft_event_summary, separators=(",", ":")) + "\n"
                   + "Previous no-visible-effect actions: "
                   + json.dumps(effect_memory, separators=(",", ":")) + "\n"
                   + "Previous action-interval public HUD evidence (observed after action; "
                   + "not causal or beneficial evidence): "
                   + json.dumps(prior_state_feedback or [], separators=(",", ":")) + "\n")
    (root / "prompt.txt").write_text(prompt_text)
    return planner.begin_turn(prompt_text, output_schema=output_schema,
                              image_path=win(image))


def compile_commands(commands):
    extents={"pulse":0,"short":1,"medium":2,"long":3}
    table={
      "turn_left":(["Left"],[100,180,300,450]),"turn_right":(["Right"],[100,180,300,450]),
      "forward":(["Up","Shift_L"],[180,350,600,900]),"backward":(["Down"],[180,300,500,750]),
      "strafe_left":(["a"],[180,350,600,850]),"strafe_right":(["d"],[180,350,600,850]),
      "use":(["e"],[80,120,180,250]),"fire":(["space"],[100,180,300,450]),
      "advance_fire":(["Up","Shift_L","space"],[180,350,600,900]),
      "retreat_fire":(["Down","space"],[180,300,500,750])}
    steps=[]
    for command in commands:
        keys,durations=table[command["action"]]
        steps.append({"op":"hold","keys":keys,"duration_ms":durations[extents[command["extent"]]]})
    return steps


def compile_cover(commands):
    if not commands:
        return [{"op":"coast","duration_ms":5000,"sample_ms":250},
                {"op":"coast","duration_ms":5000,"sample_ms":250}]
    holds=compile_commands(commands)
    repetitions=min(8,16//(len(holds)+1))
    while repetitions>0:
        candidate_hold=sum(step["duration_ms"] for step in holds)*repetitions
        candidate_coast=(10000-candidate_hold)//repetitions
        if candidate_hold<10000 and 50<=candidate_coast<=5000:
            break
        repetitions-=1
    if repetitions<1:
        raise ValueError("cover holds cannot fit the bounded ten-second policy")
    hold_total=sum(step["duration_ms"] for step in holds)*repetitions
    coast_total=10000-hold_total
    base_coast=coast_total//repetitions
    remainder=coast_total%repetitions
    steps=[]
    for cycle in range(repetitions):
        steps.extend(dict(step) for step in holds)
        duration=base_coast+(1 if cycle<remainder else 0)
        steps.append({"op":"coast","duration_ms":duration,"sample_ms":250})
    if len(steps)>16 or sum(step["duration_ms"] for step in steps)!=10000:
        raise AssertionError("cover compiler bounds")
    return steps


def action_state_feedback(before, after, typed_observations):
    """Compare public HUD values only across source-bound typed captures."""
    def read(observation):
        if (type(observation.get("sequence")) is not int or
                type(observation.get("capture_ns")) is not int or
                type(observation.get("step")) is not int):
            return None, "typed_frame_identity_mismatch"
        matches = [row for row in typed_observations
                   if type(row) is dict and row.get("event") == "typed_observation" and
                   row.get("sequence") == observation.get("sequence")]
        if len(matches) != 1:
            return None, "typed_frame_missing_or_ambiguous"
        row = matches[0]
        frame_hash = observation.get("frame_rgb_sha256")
        if (row.get("schema") != "doom-typed-observation-v1" or
                row.get("pointer_binding") != observation.get("pointer_binding") or
                type(row.get("sequence")) is not int or
                type(row.get("capture_ns")) is not int or
                type(row.get("step")) is not int or
                row.get("capture_ns") != observation.get("capture_ns") or
                row.get("id") != observation.get("id") or
                row.get("step") != observation.get("step") or
                type(frame_hash) is not str or len(frame_hash) != 64 or
                any(char not in "0123456789abcdef" for char in frame_hash) or
                row.get("frame_rgb_sha256") != frame_hash):
            return None, "typed_frame_identity_mismatch"
        signals = row.get("signals")
        binding = observation.get("pointer_binding")
        if (type(binding) is not dict or type(signals) is not dict or
                set(signals) != {"health", "ammo"}):
            return None, "typed_signal_unavailable"
        normalized = {}
        wad_sha256 = None
        for name in ("health", "ammo"):
            signal = signals.get(name)
            if (type(signal) is not dict or signal.get("status") != "observed" or
                    signal.get("signal_id") != name or
                    type(signal.get("value")) is not int or
                    type(signal.get("sequence")) is not int or
                    signal.get("sequence") != observation.get("sequence") or
                    type(signal.get("capture_ns")) is not int or
                    signal.get("capture_ns") != observation.get("capture_ns") or
                    signal.get("binding") != binding):
                return None, "typed_signal_unavailable"
            lower, upper = (1, 200) if name == "health" else (0, 999)
            if not lower <= signal["value"] <= upper:
                return None, "typed_signal_unavailable"
            signal_wad = signal.get("wad_sha256")
            if (type(signal_wad) is not str or len(signal_wad) != 64 or
                    any(char not in "0123456789abcdef" for char in signal_wad)):
                return None, "typed_signal_unavailable"
            if wad_sha256 is not None and signal_wad != wad_sha256:
                return None, "typed_signal_binding_mismatch"
            wad_sha256 = signal_wad
            normalized[name] = signal["value"]
        return {"binding": binding, "wad_sha256": wad_sha256,
                "signals": normalized}, None

    previous, reason = read(before)
    if previous is None:
        return {"status": "unavailable", "reason": reason}
    current, reason = read(after)
    if current is None:
        return {"status": "unavailable", "reason": reason}
    if (after["sequence"] <= before["sequence"] or
            after["capture_ns"] <= before["capture_ns"]):
        return {"status": "unavailable", "reason": "typed_frame_order_invalid"}
    if (current["binding"] != previous["binding"] or
            current["wad_sha256"] != previous["wad_sha256"]):
        return {"status": "unavailable", "reason": "typed_signal_binding_mismatch"}
    return {
        "status": "observed",
        "from_sequence": before["sequence"],
        "to_sequence": after["sequence"],
        "signals": {
            name: {"before": previous["signals"][name],
                   "after": current["signals"][name],
                   "delta": current["signals"][name] - previous["signals"][name]}
            for name in ("health", "ammo")},
        "scope": "public HUD transition observed after action; not causal or beneficial evidence",
    }


def input_edge_receipts(events):
    """Project legacy owner receipts and measured X-adapter edge brackets separately."""
    grouped = {}
    adapter_grouped = {}
    invalid = []
    for event in events:
        if type(event) is not dict:
            continue
        event_name = event.get("event")
        measurement = event.get("physical_key_measurement")
        adapter_edge = (measurement.get("adapter_edge")
                        if type(measurement) is dict else None)
        adapter_candidate = (
            event_name == "input_release_measurement" or
            (event_name == "input_release_transition" and type(measurement) is dict
             and measurement.get("schema") == "keymap-batch-edge-v1") or
            (event_name == "input_admission" and type(measurement) is dict))
        if adapter_candidate:
            edge_name = adapter_edge.get("edge") if type(adapter_edge) is dict else None
            expected_edge = ("down" if event_name == "input_admission" else "up")
            identifier, step, key, token = (event.get("id"), event.get("step"),
                                            event.get("key"), event.get("intent_token"))
            if (type(identifier) is not str or not identifier or
                    type(step) is not int or step < 0 or
                    type(key) is not str or not key or
                    type(token) is not str or not token):
                invalid.append({
                    "status": "identity_unavailable",
                    "event": event_name,
                    "step": step if type(step) is int else None,
                    "key": key if type(key) is str else None,
                    "scope": "adapter edge bracket unpaired; source event identity incomplete",
                })
                continue
            actuation_id = (adapter_edge.get("actuation_id")
                            if type(adapter_edge) is dict else None)
            if (actuation_id is not None and
                    (type(actuation_id) is not str or not actuation_id)):
                invalid.append({
                    "status": "identity_unavailable",
                    "event": event_name,
                    "step": step,
                    "key": key,
                    "scope": "adapter edge bracket unpaired; actuation identity is invalid",
                })
                continue
            bucket = adapter_grouped.setdefault(
                (identifier, step, key, token, actuation_id),
                {"down": [], "up": []})
            # Outer event type and nested edge label are both part of the
            # receipt identity. Do not let one release event supply a press.
            bucket[expected_edge].append(event)
            continue
        if event_name not in ("input_admission", "input_release_transition"):
            continue
        identifier = event.get("id")
        step = event.get("step")
        key = event.get("key")
        token = event.get("intent_token")
        if (type(identifier) is not str or not identifier or
                type(step) is not int or step < 0 or
                type(key) is not str or not key or
                type(token) is not str or not token):
            invalid.append({
                "status": "identity_unavailable",
                "event": event["event"],
                "step": step if type(step) is int else None,
                "key": key if type(key) is str else None,
                "scope": "per-key timing unpaired; source event identity incomplete",
            })
            continue
        has_admission_position = "admission_position" in event
        admission_position = event.get("admission_position")
        if (has_admission_position and
                (type(admission_position) is not int or admission_position < 0)):
            invalid.append({
                "status": "identity_unavailable",
                "event": event["event"],
                "step": step,
                "key": key,
                "scope": "per-key timing unpaired; admission position is invalid",
            })
            continue
        group_key = (identifier, step, key, token, admission_position)
        bucket = grouped.setdefault(group_key, {"admission": [], "release": []})
        bucket["admission" if event["event"] == "input_admission" else "release"].append(event)

    receipts = list(invalid)
    for (identifier, step, key, token, actuation_id), bucket in adapter_grouped.items():
        downs, ups = bucket["down"], bucket["up"]
        down = downs[0] if len(downs) == 1 else None
        up = ups[0] if len(ups) == 1 else None

        def edge_of(row):
            data = row.get("physical_key_measurement") if row else None
            return data.get("adapter_edge") if type(data) is dict else None

        def valid_interval(value):
            return (type(value) is list and len(value) == 2 and
                    all(type(item) is int for item in value) and value[0] <= value[1])

        def bracket_matches(data, edge, edge_name, status):
            bracket = data.get("bracket") if type(data) is dict else None
            interval_name = ("physical_down_interval" if edge_name == "down"
                             else "physical_up_interval")
            return (
                type(bracket) is dict and type(edge) is dict and
                bracket.get("key") == edge.get("key") and
                bracket.get("owner_id") == edge.get("owner_id") and
                bracket.get("intent_token") == edge.get("intent_token") and
                bracket.get(interval_name) == edge.get("interval") and
                bracket.get("status") == status and
                bracket.get("grants_input_authority") is False and
                bracket.get("application_consumption_observed") is False)

        def admission_window_matches(row, data):
            pre = data.get("pre_sample") if type(data) is dict else None
            admitted_ns = row.get("admitted_ns") if type(row) is dict else None
            return (
                type(pre) is dict and type(admitted_ns) is int and
                type(pre.get("started_ns")) is int and
                admitted_ns <= pre["started_ns"])

        def sample_window_matches(data, row, edge_name):
            pre = data.get("pre_sample") if type(data) is dict else None
            post = data.get("post_sample") if type(data) is dict else None
            pre_down, post_down = (False, True) if edge_name == "down" else (True, False)

            def valid_sample(sample, expected_down):
                return (
                    type(sample) is dict and sample.get("available") is True and
                    sample.get("down") is expected_down and sample.get("error") is None and
                    type(sample.get("started_ns")) is int and
                    type(sample.get("finished_ns")) is int and
                    sample["started_ns"] <= sample["finished_ns"])

            request_name = "press_request_ns" if edge_name == "down" else "release_request_ns"
            request_ns = data.get(request_name) if type(data) is dict else None
            sync_ns = data.get("sync_return_ns") if type(data) is dict else None
            if (not valid_sample(pre, pre_down) or not valid_sample(post, post_down) or
                    type(request_ns) is not int or type(sync_ns) is not int or
                    pre["finished_ns"] > request_ns or request_ns > sync_ns or
                    sync_ns > post["started_ns"] or
                    edge_name == "down" and (type(row.get("input_ack_ns")) is not int or
                                                  row.get("input_ack_ns") != sync_ns) or
                    edge_name == "up" and data.get("release_attempted") is not True):
                return False
            bracket = data.get("bracket")
            interval_name = "physical_down_interval" if edge_name == "down" else "physical_up_interval"
            return (type(bracket) is dict and
                    bracket.get(interval_name) == [pre["finished_ns"], post["finished_ns"]])

        down_data = down.get("physical_key_measurement") if down else None
        up_data = up.get("physical_key_measurement") if up else None
        down_edge, up_edge = edge_of(down), edge_of(up)
        down_interval = down_edge.get("interval") if type(down_edge) is dict else None
        up_interval = up_edge.get("interval") if type(up_edge) is dict else None
        down_actuation = down_edge.get("actuation_id") if type(down_edge) is dict else None
        up_actuation = up_edge.get("actuation_id") if type(up_edge) is dict else None
        down_owner = down_edge.get("owner_id") if type(down_edge) is dict else None
        up_owner = up_edge.get("owner_id") if type(up_edge) is dict else None
        no_application_consumption_conflict = all(
            type(row) is dict and
            ("application_consumption_observed" not in row or
             row.get("application_consumption_observed") is False)
            for row in (
                down, up, down_data, up_data, down_edge, up_edge,
                down_data.get("bracket") if type(down_data) is dict else None,
                up_data.get("bracket") if type(up_data) is dict else None,
                down_data.get("pre_sample") if type(down_data) is dict else None,
                down_data.get("post_sample") if type(down_data) is dict else None,
                up_data.get("pre_sample") if type(up_data) is dict else None,
                up_data.get("post_sample") if type(up_data) is dict else None))
        complete = (
            len(downs) == 1 and len(ups) == 1 and
            type(down_data) is dict and type(up_data) is dict and
            type(down_edge) is dict and type(up_edge) is dict and
            down_edge.get("edge") == "down" and up_edge.get("edge") == "up" and
            down_data.get("edge") == "down" and up_data.get("edge") == "up" and
            down_data.get("classification") == "CONFIRMED_PHYSICAL_DOWN" and
            up_data.get("classification") == "CONFIRMED_PHYSICAL_UP" and
            down_data.get("identity_status") == "MINTED" and
            up_data.get("identity_status") == "RETIRED" and
            down_data.get("actuation_id") == down_edge.get("actuation_id") and
            up_data.get("actuation_id") == up_edge.get("actuation_id") and
            down_data.get("grants_input_authority") is False and
            up_data.get("grants_input_authority") is False and
            down_edge.get("status") == "CONFIRMED_PHYSICAL_DOWN" and
            up_edge.get("status") == "CONFIRMED_PHYSICAL_UP" and
            valid_interval(down_interval) and valid_interval(up_interval) and
            down_interval[1] < up_interval[0] and
            type(down_actuation) is str and bool(down_actuation) and
            down_actuation == up_actuation and
            type(down_owner) is str and bool(down_owner) and down_owner == up_owner and
            all(row.get("id") == identifier and row.get("step") == step and
                row.get("key") == key and row.get("intent_token") == token and
                row.get("owner_id") == down_owner and
                row.get("grants_input_authority",
                        row["physical_key_measurement"].get("grants_input_authority")) is False
                for row in (down, up)) and
            all(edge.get("key") == key and edge.get("intent_token") == token and
                edge.get("actuation_id") == down_actuation and
                edge.get("owner_id") == down_owner and
                edge.get("grants_input_authority") is False
                for edge in (down_edge, up_edge)) and
            down_data.get("application_consumption_observed") is False and
            up_data.get("application_consumption_observed") is False and
            no_application_consumption_conflict and
            bracket_matches(down_data, down_edge, "down", "CONFIRMED_PHYSICAL_DOWN") and
            bracket_matches(up_data, up_edge, "up", "CONFIRMED_PHYSICAL_UP") and
            admission_window_matches(down, down_data) and
            sample_window_matches(down_data, down, "down") and
            sample_window_matches(up_data, up, "up"))
        batch_measurement = any(type(data) is dict and data.get("schema") == "keymap-batch-edge-v1"
                                for data in (down_data, up_data))
        if batch_measurement:
            owner_receipt = up.get("owner_thread_keyup_receipt") if up else None
            complete = complete and (
                down_data.get("schema") == up_data.get("schema") == "keymap-batch-edge-v1"
                and down_data.get("interval_basis") == "key_snapshot"
                and up_data.get("interval_basis") == "shared_batch_snapshot"
                and up_data.get("post_sample_basis") in ("shared_batch", "key_retry")
                and type(up_data.get("batch_id")) is str and bool(up_data["batch_id"])
                and up.get("event") == "input_release_transition"
                and up.get("release_batch_complete") is True
                and up.get("owner_transition_verified") is True
                and up.get("owner_thread_keyup_verified_after_batch") is True
                and up.get("ordinary_release_candidate") is True
                and type(owner_receipt) is dict
                and owner_receipt.get("physical_key_measurement") == up_data)
        receipts.append({
            "measurement_schema": "keymap-batch-edge-v1" if batch_measurement else "a01-perkey",
            "up_interval_basis": "shared_batch_snapshot" if batch_measurement else "key_snapshot",
            "batch_id": up_data.get("batch_id") if batch_measurement and complete else None,
            "post_sample_basis": up_data.get("post_sample_basis") if batch_measurement and complete else None,
            "status": "adapter_edge_brackets_paired" if complete else
                      "adapter_edge_receipt_incomplete",
            "program_id_sha256": hashlib.sha256(identifier.encode("utf-8")).hexdigest(),
            "intent_token_sha256": hashlib.sha256(token.encode("utf-8")).hexdigest(),
            "owner_id_sha256": (hashlib.sha256(down_owner.encode("utf-8")).hexdigest()
                                if type(down_owner) is str else None),
            "actuation_id_sha256": (hashlib.sha256(actuation_id.encode("utf-8")).hexdigest()
                                    if type(actuation_id) is str else None),
            "step": step,
            "key": key,
            "input_admitted_ns": (down.get("admitted_ns") if complete else None),
            "down_press_request_ns": (down_data.get("press_request_ns")
                                      if complete else None),
            "down_sync_return_ns": (down_data.get("sync_return_ns")
                                    if complete else None),
            "down_edge_interval_ns": down_interval if complete else None,
            "up_release_request_ns": (up_data.get("release_request_ns")
                                      if complete else None),
            "up_sync_return_ns": (up_data.get("sync_return_ns")
                                  if complete else None),
            "up_edge_interval_ns": up_interval if complete else None,
            "grants_input_authority": False if complete else None,
            "application_consumption_observed": False if complete else None,
            "scope": ("InputOwner v12 X-server keymap sampling brackets; no application "
                      "receipt, physical dwell claim, or task-benefit claim"),
        })
    for (identifier, step, key, token, admission_position), bucket in grouped.items():
        admissions = bucket["admission"]
        releases = bucket["release"]
        admission = admissions[0] if len(admissions) == 1 else None
        release = releases[0] if len(releases) == 1 else None
        owner_v11 = release.get("owner_keyup_receipt") if release else None
        v11_contract = bool(release and (
            "owner_keyup_receipt" in release or "owner_keyup_join" in release))
        owner = (owner_v11 if v11_contract else
                 (release.get("owner_thread_keyup_receipt") if release else None))
        admitted_ns = admission.get("admitted_ns") if admission else None
        input_ack_ns = admission.get("input_ack_ns") if admission else None
        release_started_ns = release.get("release_call_started_ns") if release else None
        release_returned_ns = release.get("release_call_returned_ns") if release else None
        admission_owner_id = (admission.get("owner_id")
                              if type(admission) is dict else None)
        keyup_started_ns = (owner.get("owner_keyup_started_ns")
                            if v11_contract and type(owner) is dict else
                            (owner.get("owner_keyrelease_started_ns")
                             if type(owner) is dict else None))
        sync_returned_ns = owner.get("owner_sync_returned_ns") if type(owner) is dict else None
        if v11_contract:
            sync_completed = (type(owner) is dict and
                              owner.get("xsync_completed") is True and
                              owner.get("sync_error") is None)
            owner_history_complete = (
                release.get("owner_release_history_complete") is True and
                release.get("owner_cleanup_intervened") is False)
            owner_verified = (
                release.get("owner_keyup_join") == "MATCHED_EXPLICIT_KEYUP" and
                release.get("owner_transition_verified") is True and
                release.get("admission_identity_status") == "matched" and
                release.get("admission_position") == admission_position and
                release.get("ordinary_release_candidate") is True)
            owner_contract_valid = (
                type(owner) is dict and
                owner.get("event") == "owner_keyup" and
                owner.get("schema") == "owner-keyup-v11" and
                owner.get("reason") == "explicit_up" and
                owner.get("key") == key and owner.get("intent_token") == token and
                type(admission_owner_id) is str and bool(admission_owner_id) and
                release.get("owner_id") == admission_owner_id and
                owner.get("owner_id") == admission_owner_id and
                type(admission_position) is int and
                admission.get("admission_position") == admission_position and
                owner.get("physical_verification_authoritative") is False and
                owner.get("grants_input_authority") is False and
                release.get("physical_verification_authoritative") is False and
                release.get("grants_input_authority") is False)
        else:
            sync_completed = (type(owner) is dict and
                              owner.get("server_sync_completed") is True)
            owner_history_complete = (
                release.get("owner_thread_keyup_history_complete") is True
                if release else False)
            owner_verified = (release.get("owner_thread_keyup_verified") is True
                              if release else False)
            owner_identity_layers = (admission, release, owner)
            owner_id_presence = tuple(
                type(row) is dict and "owner_id" in row
                for row in owner_identity_layers)
            owner_id_values = tuple(
                row.get("owner_id") if type(row) is dict else None
                for row in owner_identity_layers)
            owner_identity_valid = (
                not any(owner_id_presence) or
                (all(owner_id_presence) and
                 all(type(value) is str and bool(value)
                     for value in owner_id_values) and
                 len(set(owner_id_values)) == 1))
            owner_contract_valid = (
                type(owner) is dict and
                owner.get("event") == "owner_explicit_keyup" and
                owner_identity_valid)

        if len(admissions) > 1 or len(releases) > 1:
            status = "ambiguous_input_edges"
        elif admission is None:
            status = "release_without_admission"
        elif release is None:
            status = "admission_without_release"
        elif (release.get("operation") != "up" or type(owner) is not dict or
              not owner_contract_valid or
              owner.get("key") != key or owner.get("intent_token") != token or
              not sync_completed or not owner_verified or
              not owner_history_complete or
              type(admitted_ns) is not int or type(input_ack_ns) is not int or
              input_ack_ns < admitted_ns or
              type(release_started_ns) is not int or type(release_returned_ns) is not int or
              type(keyup_started_ns) is not int or type(sync_returned_ns) is not int or
              keyup_started_ns < input_ack_ns or
              release_started_ns < input_ack_ns or
              keyup_started_ns < release_started_ns or
              sync_returned_ns < keyup_started_ns or
              release_returned_ns < sync_returned_ns):
            status = "release_receipt_incomplete"
        else:
            status = "paired"

        def delta_ms(start, end):
            if type(start) is int and type(end) is int and end >= start:
                return round((end - start) / 1_000_000, 6)
            return None

        receipts.append({
            "status": status,
            "program_id_sha256": hashlib.sha256(identifier.encode("utf-8")).hexdigest(),
            "intent_token_sha256": hashlib.sha256(token.encode("utf-8")).hexdigest(),
            "step": step,
            "key": key,
            "admission_position": admission_position,
            "admitted_ns": admitted_ns if type(admitted_ns) is int else None,
            "input_ack_ns": input_ack_ns if type(input_ack_ns) is int else None,
            "release_call_started_ns": release_started_ns if type(release_started_ns) is int else None,
            "owner_keyrelease_started_ns": (keyup_started_ns
                                             if type(keyup_started_ns) is int else None),
            "owner_sync_returned_ns": (sync_returned_ns
                                        if type(sync_returned_ns) is int else None),
            "release_call_returned_ns": release_returned_ns if type(release_returned_ns) is int else None,
            "admitted_to_owner_keyup_start_ms": (delta_ms(admitted_ns, keyup_started_ns)
                                                  if status == "paired" else None),
            "input_ack_to_owner_keyup_start_ms": (delta_ms(input_ack_ns, keyup_started_ns)
                                                  if status == "paired" else None),
            "server_sync_completed": sync_completed,
            "owner_thread_keyup_verified": owner_verified,
            "owner_keyup_history_complete": owner_history_complete,
            "physical_verification_authoritative": (
                release.get("physical_verification_authoritative") is True
                if release else False),
            "scope": ("owner admission-to-keyup-request timing; server synchronization only, "
                      "not physical key-down duration or task benefit"),
        })
    return receipts


def effect_receipts(commands, before, observations, accepted_ns,
                    typed_observations=()):
    previous=descriptor(Path(before["image"]));receipts=[]
    previous_observation = before
    for index,command in enumerate(commands):
        samples=[row for row in observations if row["step"]==index]
        if not samples:
            raise RuntimeError(f"hold step {index} produced no effect observation")
        feedback_observation=samples[0]
        observation=samples[-1]
        current=descriptor(Path(observation["image"]));mae=normalized_mae(previous,current)
        receipts.append({"action":command["action"],"extent":command["extent"],
          "result":"no_visible_effect" if mae<=0.015 else "visible_change",
          "normalized_mae":mae,"no_visible_effect_threshold_lte":0.015,
          "program_id_sha256":(hashlib.sha256(observation["id"].encode("utf-8")).hexdigest()
                               if type(observation.get("id")) is str else None),
          "executor_step":observation.get("step"),
          "after_sequence":observation["sequence"],
          "effect_observed_ns":observation["capture_ns"],
          "feedback_sequence":feedback_observation["sequence"],
          "feedback_capture_ns":feedback_observation["capture_ns"],
          "samples":len(samples),
          "plan_accept_to_first_capture_ms":(samples[0]["capture_ns"]-accepted_ns)/1e6,
          "plan_accept_to_last_capture_ms":(observation["capture_ns"]-accepted_ns)/1e6,
          "capture_ms_total":sum(row["capture_ms"] for row in samples),
          "scope":"viewport pixels only",
          "state_feedback":action_state_feedback(
              previous_observation, feedback_observation, typed_observations)})
        previous=current
        previous_observation = observation
    return receipts


def temporal_sheet(sources, target):
    """Pack four recent game windows into the same 642x502 model-image extent."""
    chosen = ([sources[0]] * (4-len(sources)) + sources)[-4:]
    sheet = Image.new("RGB", (642, 502), "black")
    draw = ImageDraw.Draw(sheet)
    for index, source in enumerate(chosen):
        with Image.open(source) as frame:
            crop = frame.crop((320, 162, 962, 663)).resize((320, 250))
        x=(index%2)*321; y=(index//2)*251
        sheet.paste(crop,(x,y))
        draw.text((x+4,y+4),str(index+1),fill="white",stroke_width=1,stroke_fill="black")
    sheet.save(target,optimize=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--iterations", type=int, default=4)
    parser.add_argument("--seed", type=int, default=990605)
    parser.add_argument("--session-span", type=int, default=4)
    parser.add_argument("--model", required=True)
    parser.add_argument("--effort", choices=("low","medium","high","xhigh","max","ultra"), required=True)
    parser.add_argument("--load-fixture-manifest", type=Path, required=True)
    parser.add_argument("--measurement-session", action="store_true",
                        help="opt into V15 scorer-only progress sampling")
    parser.add_argument("--per-key-input-measurement", action="store_true",
                        help="measure keymap brackets (shared-batch v1 with V15; A01 with V12)")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    planner_client = CodexAppServerClient(
        app_server_command(), cwd=REPO,
        journal_path=args.out / "planner-protocol.jsonl")
    atexit.register(planner_client.close)
    with ControllerFailureCleanup(planner_client, args.out) as failure_cleanup:
        failure_cleanup.set_stage("planner_initialize")
        planner_client.initialize()
        planner = PersistentPlannerAdapter(
            planner_client, model=args.model, effort=args.effort, cwd=win(REPO),
            base_instructions=(HERE / "map01_motor_responder_v10.txt").read_text())
        planner.start_session()
        output_schema = json.loads((HERE / "map01_cover_policy_schema_v6.json").read_text())
        signal_reader = DoomStatusNumberReader(WAD, signal_id="health")
        ammo_reader = DoomStatusNumberReader(WAD, signal_id="ammo")
        runtime = args.out / "runtime"
        process = subprocess.Popen(session_command(args, runtime),
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, bufsize=1)
        failure_cleanup.track(process)
        incoming = queue.Queue()
        all_events = []
        reader_errors = []
        def reader():
            try:
                for line in process.stdout:
                    row = json.loads(line); all_events.append(row); incoming.put(row)
            except BaseException as error:
                reader_errors.append(f"{type(error).__name__}: {error}")
        latest = None
        reader_thread = threading.Thread(target=reader, daemon=True)
        reader_thread.start()
        def wait(predicate, timeout=40, observation_monitor=None):
            nonlocal latest
            end = time.monotonic() + timeout
            while time.monotonic() < end:
                try:
                    row = incoming.get(timeout=min(.25,max(.1,end-time.monotonic())))
                except queue.Empty:
                    if process.poll() is not None:
                        detail="stderr not synchronously drained"
                        raise RuntimeError(f"session exited before expected event: {detail}")
                    continue
                if row["event"] == "observation":
                    latest = row
                event_types = (getattr(observation_monitor, "event_types", {"observation"})
                               if observation_monitor is not None else set())
                if row["event"] in event_types:
                    invalidation = observation_monitor.observe(row)
                    if invalidation is not None:
                        if invalidation.get("event") == "running_action_invalidation":
                            return invalidation
                        return {"event":"policy_invalidation",
                                "invalidation":invalidation}
                if predicate(row): return row
            raise TimeoutError()
        failure_cleanup.observe_output(all_events, reader_thread, wait, runtime, reader_errors)
        failure_cleanup.set_stage("session_startup")
        ready = wait(lambda r:r["event"] == "ready")
        runtime_fixture = ready.get("fixture")
        if runtime_fixture is None:
            raise RuntimeError("v28 requires a loaded fixture receipt")
        latest = wait(lambda r:r["event"] == "observation")
        decisions=[];model_session_id=planner.thread_id
        cover_renewal_rejections=[]
        source_refreshes=[]
        program_admissions=0
        for index in range(args.iterations):
            failure_cleanup.set_stage("source_refresh")
            if index and index % args.session_span == 0:
                planner.start_session()
                model_session_id=planner.thread_id
            clock_ns=time.perf_counter_ns(); cover=f"cover-{index}"
            def send_source_refresh(command):
                process.stdin.write(json.dumps(command)+"\n");process.stdin.flush()
            try:
                latest, source_refresh = refresh_source(
                    latest, signal_reader, ammo_reader, send_source_refresh, wait,
                    f"source-refresh-{index}")
            except SourceRefreshRefused as error:
                source_refreshes.append(dict(error.receipt, iteration=index))
                try:
                    (args.out/"source-refreshes.json").write_text(
                        json.dumps(source_refreshes,indent=2)+"\n")
                except BaseException as save_error:
                    error.add_note(
                        f"source refresh receipt write failed: {type(save_error).__name__}: {save_error}")
                raise
            source_refreshes.append(dict(source_refresh, iteration=index))
            (args.out/"source-refreshes.json").write_text(
                json.dumps(source_refreshes,indent=2)+"\n")
            failure_cleanup.set_stage("cover_validity_admission")
            cover_semantic, cover_validity_semantic, cover_policy_source_iteration = reusable_cover(decisions)
            validity_monitor, validity_admission = build_cover_monitor(
                signal_reader, latest, cover_validity_semantic, index,
                ammo_reader=ammo_reader,
                requires_ammo=cover_requires_ammo(cover_semantic))
            cover_semantic = admitted_cover_commands(cover_semantic, validity_admission)
            validity_monitor, validity_admission = select_cover_monitor(
                validity_monitor, validity_admission, cover_semantic,
                cover_policy_source_iteration)
            failure_cleanup.set_stage("cover_program_compile")
            cover_steps=compile_cover(cover_semantic)
            prior_receipts=[] if not decisions else decisions[-1].get("effect_receipts",[])
            effect_memory=[row["action"] for row in prior_receipts
                           if row["result"]=="no_visible_effect"]
            prior_soft_event_summary=latest_soft_event_summary(decisions)
            cover_ids=[];cover_terminals=[];cover_renewal_gaps_ms=[]
            def submit_cover(identifier, allow_rejection=False):
                nonlocal clock_ns
                clock_ns=time.perf_counter_ns()
                command={"op":"submit","id":identifier,"expected_sequence":latest["sequence"],
                  "valid_until_ns":clock_ns+25_000_000_000,"steps":cover_steps}
                process.stdin.write(json.dumps(command)+"\n");process.stdin.flush()
                accepted=wait(lambda r:r["event"] in ("accepted","rejected") and
                              (r.get("id")==identifier or r["event"]=="rejected"),
                              observation_monitor=validity_monitor)
                if accepted["event"] == "policy_invalidation":
                    return accepted
                if accepted["event"] == "rejected" and allow_rejection:
                    return accepted
                if accepted["event"]!="accepted":raise RuntimeError(accepted)
                cover_ids.append(identifier);return accepted
            failure_cleanup.set_stage("cover_program_admission")
            initial_cover_admission = submit_cover(cover, allow_rejection=True)
            if initial_cover_admission["event"] in ("policy_invalidation", "rejected"):
                invalidation = initial_cover_admission.get("invalidation")
                if initial_cover_admission["event"] == "rejected":
                    admission_resolution = {"status": "rejected",
                                            "response": initial_cover_admission}
                else:
                    admission_resolution = resolve_invalidated_cover_submission(
                        wait, cover)
                cancellation = None
                if admission_resolution["status"] == "accepted":
                    cover_ids.append(cover)
                    cancellation = cancel_invalidated_cover_before_plan(
                        process, wait, cover)
                    cover_terminals.append(cancellation["terminal"])
                invalidated_source_image = str(latest["image"])
                if invalidation is not None:
                    latest = wait_for_invalidation_frame(latest, invalidation, wait)
                decisions.append({
                    "iteration": index,
                    "source_image": invalidated_source_image,
                    "invalidation_frame_image": (None if invalidation is None else
                                                 str(latest["image"])),
                    "model_image": None,
                    "model_image_sha256": None,
                    "action": {"state": "not_started"},
                    "effect_memory": effect_memory,
                    "usage": None,
                    "model_ns": 0,
                    "prior_soft_event_summary": prior_soft_event_summary,
                    "model_session_id": model_session_id,
                    "planner_turn_id": None,
                    "planner_turn_status": "not_started",
                    "planner_answer_eligible": False,
                    "planner_terminal_observed_ns": None,
                    "final_action_admission": {
                        "status": "not_started",
                        "reason": "cover_invalidated_before_planner"},
                    "initial_cover_submission_id": cover,
                    "initial_cover_admission_result": initial_cover_admission,
                    "initial_cover_admission_resolution": admission_resolution,
                    "planner_cancellation_requested": False,
                    "planner_interrupt": None,
                    "controller_model_started_ns": None,
                    "controller_model_ended_ns": None,
                    "cover_program_ids": cover_ids,
                    "cover_renewals": 0,
                    "cover_renewal_gaps_ms": cover_renewal_gaps_ms,
                    "cover_policy": cover_semantic,
                    "cover_policy_source_iteration": cover_policy_source_iteration,
                    "cover_validity_admission": validity_admission,
                    "cover_validity_soft_events": validity_monitor.soft_event_count,
                    "cover_validity_latest_soft_event": validity_monitor.latest_soft_event,
                    "policy_invalidation": invalidation,
                    "cover_admission_cancellation": cancellation,
                    "cover_program_admitted": admission_resolution["status"] == "accepted",
                    "model_action_discarded": False,
                    "discard_reason": (
                        "planner_not_started_cover_invalidated" if invalidation else
                        "planner_not_started_cover_rejected"),
                    "cover_terminal_before_plan": cancellation is not None,
                    "plan_terminal": "not_started"})
                continue
            failure_cleanup.set_stage("decision_artifact_prepare")
            model_root=args.out/f"decision-{index}"
            model_root.mkdir()
            action_source_observation=dict(latest)
            failure_cleanup.set_stage("action_source_health_ammo")
            source_health_signal=signal_reader.read(action_source_observation)
            source_ammo_signal=ammo_reader.read(action_source_observation)
            if (source_health_signal["status"] != "observed" or
                    source_ammo_signal["status"] != "observed"):
                raise RuntimeError("action source health/ammo unavailable")
            failure_cleanup.set_stage("planner_input_prepare")
            source_image=Path(action_source_observation["image"])
            invalidation_monitor=validity_monitor
            invalidation=None
            prior_receipts=[] if not decisions else decisions[-1].get("effect_receipts",[])
            effect_memory=[row["action"] for row in prior_receipts
                           if row["result"]=="no_visible_effect"]
            prior_state_feedback=[{
                "action":row["action"],"extent":row["extent"],
                "viewport_result":row["result"],
                "state_feedback":row.get("state_feedback",{
                    "status":"unavailable","reason":"not_recorded"})}
                for row in prior_receipts]
            prior_soft_event_summary=latest_soft_event_summary(decisions)
            image=model_root/"temporal-sheet.png"
            prior=[Path(row["source_image"]) for row in decisions]
            temporal_sheet(prior+[source_image],image)
            model_started_ns=time.perf_counter_ns()
            failure_cleanup.set_stage("planner_turn")
            planner_handle=begin_model_turn(
                planner,model_root,image,effect_memory,
                source_health_signal["value"],source_ammo_signal["value"],
                prior_soft_event_summary,output_schema,prior_state_feedback)
            planner_interrupt=None
            with ThreadPoolExecutor(max_workers=1) as pool:
                future=pool.submit(planner.await_turn,planner_handle,90)
                current_cover=cover
                current_terminal=None
                renewal_admission_resolution=None
                while not future.done():
                    if current_cover is None:
                        boundary = wait_without_active_cover(
                            wait, invalidation_monitor, planner, planner_handle)
                        if boundary is not None:
                            invalidation=boundary["invalidation"]
                            planner_interrupt=boundary["planner_interrupt"]
                            break
                        continue
                    try:
                        boundary=wait(lambda r:r["event"]=="terminal" and
                                      r.get("id")==current_cover,timeout=.1,
                                      observation_monitor=invalidation_monitor)
                    except TimeoutError:
                        continue
                    if boundary["event"] == "policy_invalidation":
                        invalidation=boundary["invalidation"]
                        planner_interrupt,current_terminal=cancel_invalidated_cover(
                            planner,planner_handle,process,wait,current_cover)
                        cover_terminals.append(current_terminal)
                        break
                    current_terminal=boundary
                    cover_terminals.append(current_terminal)
                    failure_cleanup.set_stage("cover_terminal_validation")
                    try:
                        require_cover_terminal(current_terminal)
                    except RuntimeError as error:
                        # Request interruption before pool shutdown waits for
                        # await_turn. Keep the terminal failure primary if the
                        # interruption transport itself fails.
                        if not future.done():
                            try:
                                planner.interrupt(planner_handle)
                            except BaseException as interrupt_error:
                                error.add_note("planner interrupt failed: " +
                                               type(interrupt_error).__name__)
                        raise
                    if future.done():break
                    next_cover=f"cover-{index}-renew-{len(cover_ids)}"
                    renewal_expected_sequence=latest["sequence"]
                    next_accepted=submit_cover(next_cover, allow_rejection=True)
                    if next_accepted["event"] == "policy_invalidation":
                        invalidation=next_accepted["invalidation"]
                        planner_interrupt=planner.interrupt(planner_handle)
                        renewal_admission_resolution=resolve_invalidated_cover_submission(
                            wait,next_cover)
                        if renewal_admission_resolution["status"] == "accepted":
                            cover_ids.append(next_cover)
                            current_cover=next_cover
                            planner_interrupt,current_terminal=cancel_invalidated_cover(
                                planner,planner_handle,process,wait,current_cover,
                                planner_interrupt=planner_interrupt)
                            cover_terminals.append(current_terminal)
                        # If rejected, the prior terminal remains current; the
                        # invalidated answer is already interrupted.
                        break
                    renewal_outcome=classify_cover_renewal_response(next_accepted)
                    if renewal_outcome["status"] == "stale_sequence_no_cover":
                        cover_renewal_rejections.append({
                            "iteration": index, "id": next_cover,
                            "reason": renewal_outcome["reason"],
                            "submitted_sequence": renewal_expected_sequence,
                            "latest_sequence_after_rejection": latest["sequence"],
                            "admitted": False,
                            "previous_cover_terminal_retained": current_terminal,
                        })
                        current_cover=None
                        continue
                    cover_renewal_gaps_ms.append((next_accepted["accepted_ns"]-
                        current_terminal["terminal_ns"])/1e6)
                    current_cover=next_cover;current_terminal=None
                planner_result=future.result()
                failure_cleanup.set_stage("planner_result_validation")
                planner_terminal_observed_ns=time.perf_counter_ns()
            model_ended_ns=time.perf_counter_ns()
            model_ns=model_ended_ns-model_started_ns
            action=planner_result.answer
            usage=planner_result.usage
            observed_session_id=planner_result.handle.thread_id
            if model_session_id is not None and observed_session_id != model_session_id:
                raise RuntimeError("model session identity changed")
            model_session_id=observed_session_id
            if current_terminal is None:
                process.stdin.write(json.dumps({"op":"cancel","id":current_cover})+"\n");process.stdin.flush()
                while current_terminal is None:
                    boundary=wait(lambda r:r["event"]=="terminal" and r.get("id")==current_cover,
                                  observation_monitor=None if invalidation else invalidation_monitor)
                    if boundary["event"] == "policy_invalidation":
                        invalidation=boundary["invalidation"]
                        planner_interrupt=planner.interrupt(planner_handle)
                    else:
                        current_terminal=boundary
                cover_terminals.append(current_terminal)
            failure_cleanup.set_stage("cover_terminal_validation")
            require_cover_terminal(current_terminal, cancellation_requested=True)
            final_action_admission=final_admission_from_planner_result(
                planner_result,planner_terminal_observed_ns,
                invalidation,time.perf_counter_ns())
            if invalidation is not None:
                latest = wait_for_invalidation_frame(latest, invalidation, wait)
                decisions.append({"iteration":index,"source_image":str(source_image),"model_image":str(image),
                  "model_image_sha256":hashlib.sha256(image.read_bytes()).hexdigest(),"action":action,
                  "effect_memory":effect_memory,"usage":usage,"model_ns":model_ns,
                  "prior_soft_event_summary":prior_soft_event_summary,
                  "model_session_id":model_session_id,
                  "planner_turn_id":planner_handle.turn_id,
                  "planner_turn_status":planner_result.status,
                  "planner_answer_eligible":planner_result.answer_eligible,
                  "planner_terminal_observed_ns":planner_terminal_observed_ns,
                  "final_action_admission":final_action_admission,
                  "planner_cancellation_requested":planner_result.cancellation_requested,
                  "planner_interrupt":planner_interrupt,
                  "controller_model_started_ns":model_started_ns,"controller_model_ended_ns":model_ended_ns,
                  "cover_program_ids":cover_ids,"cover_renewals":len(cover_ids)-1,
                  "cover_renewal_gaps_ms":cover_renewal_gaps_ms,
                  "cover_renewal_admission_resolution":renewal_admission_resolution,
                  "cover_policy":cover_semantic,"cover_policy_source_iteration":cover_policy_source_iteration,
                  "cover_validity_admission":validity_admission,
                  "cover_validity_soft_events":invalidation_monitor.soft_event_count,
                  "cover_validity_latest_soft_event":invalidation_monitor.latest_soft_event,
                  "policy_invalidation":invalidation,"model_action_discarded":True,
                  "discard_reason":"policy_dependency_invalidated",
                  "cover_terminal_before_plan":True,"plan_terminal":"not_admitted"})
                continue
            if not planner_result.answer_eligible:
                decisions.append({"iteration":index,"source_image":str(source_image),
                  "model_image":str(image),"model_image_sha256":hashlib.sha256(image.read_bytes()).hexdigest(),
                  "action":action,"effect_memory":effect_memory,"usage":usage,"model_ns":model_ns,
                  "prior_soft_event_summary":prior_soft_event_summary,
                  "model_session_id":model_session_id,"planner_turn_id":planner_handle.turn_id,
                  "planner_turn_status":planner_result.status,
                  "planner_answer_eligible":planner_result.answer_eligible,
                  "planner_terminal_observed_ns":planner_terminal_observed_ns,
                  "final_action_admission":final_action_admission,
                  "planner_cancellation_requested":planner_result.cancellation_requested,
                  "planner_interrupt":planner_interrupt,"planner_error":planner_result.error,
                  "controller_model_started_ns":model_started_ns,"controller_model_ended_ns":model_ended_ns,
                  "cover_program_ids":cover_ids,"cover_renewals":len(cover_ids)-1,
                  "cover_renewal_gaps_ms":cover_renewal_gaps_ms,"cover_policy":cover_semantic,
                  "cover_policy_source_iteration":cover_policy_source_iteration,
                  "cover_validity_admission":validity_admission,
                  "cover_validity_soft_events":invalidation_monitor.soft_event_count,
                  "cover_validity_latest_soft_event":invalidation_monitor.latest_soft_event,
                  "model_action_discarded":True,"discard_reason":"planner_answer_ineligible",
                  "cover_terminal_before_plan":True,"plan_terminal":"not_admitted"})
                continue
            try:
                validate_action(action)
                if action["state"] == "active":
                    build_action_contract(
                        action["commands"], action["action_validity"][0],
                        source_health_signal, source_ammo_signal)
            except ValueError as error:
                final_action_admission=record_controller_no_input(
                    final_action_admission,"controller_validation_failed")
                decisions.append({"iteration":index,"source_image":str(source_image),
                  "model_image":str(image),"model_image_sha256":hashlib.sha256(image.read_bytes()).hexdigest(),
                  "action":action,"effect_memory":effect_memory,"usage":usage,"model_ns":model_ns,
                  "prior_soft_event_summary":prior_soft_event_summary,
                  "model_session_id":model_session_id,"planner_turn_id":planner_handle.turn_id,
                  "planner_turn_status":planner_result.status,"planner_answer_eligible":True,
                  "planner_terminal_observed_ns":planner_terminal_observed_ns,
                  "final_action_admission":final_action_admission,
                  "planner_cancellation_requested":planner_result.cancellation_requested,
                  "planner_interrupt":planner_interrupt,"controller_validation_error":str(error),
                  "controller_model_started_ns":model_started_ns,"controller_model_ended_ns":model_ended_ns,
                  "cover_program_ids":cover_ids,"cover_renewals":len(cover_ids)-1,
                  "cover_renewal_gaps_ms":cover_renewal_gaps_ms,"cover_policy":cover_semantic,
                  "cover_policy_source_iteration":cover_policy_source_iteration,
                  "cover_validity_admission":validity_admission,
                  "cover_validity_soft_events":invalidation_monitor.soft_event_count,
                  "cover_validity_latest_soft_event":invalidation_monitor.latest_soft_event,
                  "model_action_discarded":True,"discard_reason":"controller_validation_failed",
                  "cover_terminal_before_plan":True,"plan_terminal":"not_admitted"})
                continue
            if action["state"] != "active":
                final_action_admission=record_controller_no_input(
                    final_action_admission,"terminal_model_state")
                decisions.append({"iteration":index,"source_image":str(source_image),"model_image":str(image),
                  "model_image_sha256":hashlib.sha256(image.read_bytes()).hexdigest(),"action":action,
                  "effect_memory":effect_memory,
                  "usage":usage,"model_ns":model_ns,"model_session_id":model_session_id,
                  "planner_turn_id":planner_handle.turn_id,
                  "planner_turn_status":planner_result.status,
                  "planner_answer_eligible":planner_result.answer_eligible,
                  "planner_terminal_observed_ns":planner_terminal_observed_ns,
                  "final_action_admission":final_action_admission,
                  "planner_cancellation_requested":planner_result.cancellation_requested,
                  "planner_interrupt":planner_interrupt,
                  "controller_model_started_ns":model_started_ns,"controller_model_ended_ns":model_ended_ns,
                  "cover_program_ids":cover_ids,"cover_renewals":len(cover_ids)-1,
                  "cover_renewal_gaps_ms":cover_renewal_gaps_ms,
                  "cover_policy":cover_semantic,"cover_policy_source_iteration":cover_policy_source_iteration,
                  "cover_validity_admission":validity_admission,
                  "cover_validity_soft_events":invalidation_monitor.soft_event_count,
                  "cover_validity_latest_soft_event":invalidation_monitor.latest_soft_event,
                  "terminal_candidate":True,"model_action_discarded":False})
                break
            failure_cleanup.set_stage("action_admission")
            fresh_before_plan=dict(latest)
            current_health_signal=signal_reader.read(fresh_before_plan)
            current_ammo_signal=ammo_reader.read(fresh_before_plan)
            final_action_admission=prepare_action_admission(
                final_action_admission,action,action["action_validity"][0],
                source_health_signal,source_ammo_signal,
                current_health_signal,current_ammo_signal,time.perf_counter_ns())
            if final_action_admission["status"] != "READY_FOR_FRESH_EXECUTOR_ADMISSION":
                decisions.append({"iteration":index,"source_image":str(source_image),
                  "model_image":str(image),"model_image_sha256":hashlib.sha256(image.read_bytes()).hexdigest(),
                  "action":action,"effect_memory":effect_memory,"usage":usage,"model_ns":model_ns,
                  "prior_soft_event_summary":prior_soft_event_summary,
                  "model_session_id":model_session_id,"planner_turn_id":planner_handle.turn_id,
                  "planner_turn_status":planner_result.status,"planner_answer_eligible":True,
                  "planner_terminal_observed_ns":planner_terminal_observed_ns,
                  "final_action_admission":final_action_admission,
                  "action_source_signals":{"health":source_health_signal,"ammo":source_ammo_signal},
                  "action_current_signals":{"health":current_health_signal,"ammo":current_ammo_signal},
                  "planner_cancellation_requested":planner_result.cancellation_requested,
                  "planner_interrupt":planner_interrupt,
                  "controller_model_started_ns":model_started_ns,"controller_model_ended_ns":model_ended_ns,
                  "cover_program_ids":cover_ids,"cover_renewals":len(cover_ids)-1,
                  "cover_renewal_gaps_ms":cover_renewal_gaps_ms,"cover_policy":cover_semantic,
                  "cover_policy_source_iteration":cover_policy_source_iteration,
                  "cover_validity_admission":validity_admission,
                  "cover_validity_soft_events":invalidation_monitor.soft_event_count,
                  "cover_validity_latest_soft_event":invalidation_monitor.latest_soft_event,
                  "model_action_discarded":True,"discard_reason":"action_not_current",
                  "cover_terminal_before_plan":True,"plan_terminal":"not_admitted"})
                continue
            grounded_capture_ns=source_health_signal["capture_ns"]
            trace=[]
            failure_cleanup.set_stage("action_guard_setup")
            running_guard=RunningActionGuardV3(
                action,final_action_admission,compile_commands,
                "map01_overlap_controller_v38.compile_commands")
            action_monitor=DoomRunningActionMonitor(
                running_guard,signal_reader,ammo_reader)
            first_accepted=None
            running_invalidation=None
            partial_execution=None
            refresh_program_ids=[]
            def execute_segment(identifier,commands,role,command_indices,
                                contingency_after=None,branch_evidence=None):
                nonlocal program_admissions,first_accepted,final_action_admission
                before=dict(latest);event_start=len(all_events);clock_ns=time.perf_counter_ns()
                steps=compile_commands(commands)
                submit_command={"op":"submit","id":identifier,
                  "expected_sequence":latest["sequence"],"valid_until_ns":clock_ns+25_000_000_000,
                  "steps":steps}
                process.stdin.write(json.dumps(submit_command)+"\n");process.stdin.flush()
                accepted=wait(lambda r:r["event"] in ("accepted","rejected") and
                              (r.get("id")==identifier or r["event"]=="rejected"))
                if accepted["event"]!="accepted":raise RuntimeError(accepted)
                program_admissions+=1
                guard_acceptance={"event":"accepted","id":identifier,
                                  "steps":accepted["steps"],
                                  "program_sha256":accepted["program_sha256"],
                                  "intent_token":accepted["intent_token"],
                                  "accepted_ns":accepted["accepted_ns"]}
                program_binding={"role":role,"semantic_commands":commands,
                  "command_indices":command_indices,"contingency_after":contingency_after,
                  "compiled_steps":steps}
                running_guard.admit_program(
                    program_binding,{"command":submit_command,"sent_ns":clock_ns},
                    guard_acceptance,branch_evidence=branch_evidence)
                final_action_admission=running_guard.final_admission
                if first_accepted is None:
                    first_accepted=accepted["accepted_ns"]
                boundary=wait(lambda r:r["event"]=="terminal" and r.get("id")==identifier,
                              observation_monitor=action_monitor)
                invalidated=boundary["event"]=="running_action_invalidation"
                cancel_event=None
                physical_release_event=None
                release_pending_receipt=None
                if invalidated:
                    persist_running_invalidation(args.out,identifier,boundary)
                    (cancel_event,physical_release_event,release_pending_receipt,
                     terminal,guard_receipt)=cancel_invalidated_action(
                        process,wait,identifier,running_guard)
                else:
                    terminal=boundary
                    if terminal["status"]!="completed":raise RuntimeError(terminal)
                    guard_receipt=running_guard.record_completed_terminal(
                        terminal,final=False)
                observations=[row for row in all_events[event_start:]
                               if row.get("event")=="observation" and row.get("id")==identifier]
                completed=len(commands) if not invalidated else terminal["steps_completed"]
                receipts=(effect_receipts(commands[:completed],before,observations,
                                          accepted["accepted_ns"],all_events)
                          if completed else [])
                records=[]
                for local_index,(command,receipt) in enumerate(zip(commands[:completed],receipts)):
                    samples=[row for row in observations if row["step"]==local_index]
                    record={"id":identifier,"role":role,
                      "command_index":command_indices[local_index],"command":command,
                      "accepted_ns":accepted["accepted_ns"],
                      "terminal_ns":terminal["terminal_ns"],"receipt":receipt,
                      "observation_samples":len(samples),
                      "observation_capture_ms":sum(row["capture_ms"] for row in samples)}
                    trace.append(record);records.append(record)
                partial=None
                if invalidated and completed < len(commands):
                    samples=[row for row in observations if row["step"]==completed]
                    partial={"id":identifier,"role":role,
                      "command_index":command_indices[completed],
                      "command":commands[completed],"accepted_ns":accepted["accepted_ns"],
                      "terminal_ns":terminal["terminal_ns"],"receipt":None,
                      "observation_samples":len(samples),
                      "observation_capture_ms":sum(row["capture_ms"] for row in samples),
                      "status":"cancelled_action_not_current"}
                return {"records":records,"invalidated":invalidated,
                        "partial":partial,"cancel_event":cancel_event,
                        "physical_release_event":physical_release_event,
                        "release_pending_guard":release_pending_receipt,
                        "terminal":terminal,"guard":guard_receipt}
            def refresh_between_segments(identifier):
                nonlocal program_admissions
                clock_ns=time.perf_counter_ns()
                process.stdin.write(json.dumps({"op":"submit","id":identifier,
                  "expected_sequence":latest["sequence"],"valid_until_ns":clock_ns+5_000_000_000,
                  "steps":[{"op":"observe"}]})+"\n");process.stdin.flush()
                accepted=wait(lambda r:r["event"] in ("accepted","rejected") and
                              (r.get("id")==identifier or r["event"]=="rejected"))
                if accepted["event"]!="accepted":raise RuntimeError(accepted)
                program_admissions+=1;refresh_program_ids.append(identifier)
                boundary=wait(lambda r:r["event"]=="terminal" and r.get("id")==identifier,
                              observation_monitor=action_monitor)
                if boundary["event"]=="running_action_invalidation":
                    persist_running_invalidation(args.out,identifier,boundary)
                    terminal=wait(lambda r:r["event"]=="terminal" and r.get("id")==identifier)
                    release=terminal.get("release",{})
                    if (terminal.get("status")!="completed" or release.get("verified") is not True or
                            release.get("keys_down")!=[] or release.get("buttons_down")!=[]):
                        raise RuntimeError("passive refresh did not verify empty release")
                    return False
                terminal=boundary;release=terminal.get("release",{})
                if (terminal.get("status")!="completed" or release.get("verified") is not True or
                        release.get("keys_down")!=[] or release.get("buttons_down")!=[] or
                        running_guard.receipt()["state"]!=RUNNING_READY):
                    raise RuntimeError("passive refresh did not establish current action")
                return True
            contingencies={row["after_command"]:row for row in action["contingencies"]}
            branch=None
            boundaries=sorted(contingencies)
            if not boundaries or boundaries[-1] != len(action["commands"])-1:
                boundaries.append(len(action["commands"])-1)
            segment_start=0
            failure_cleanup.set_stage("active_action_execution")
            for segment_end in boundaries:
                segment_commands=action["commands"][segment_start:segment_end+1]
                result=execute_segment(f"plan-{index}-primary-{segment_start}-{segment_end}",
                    segment_commands,"primary",list(range(segment_start,segment_end+1)))
                records=result["records"]
                if result["invalidated"]:
                    running_invalidation=result["guard"]["invalidation"]
                    partial_execution=result["partial"]
                    break
                contingency=contingencies.get(segment_end)
                trigger=records[-1]
                if trigger["receipt"]["result"]=="no_visible_effect" and contingency:
                    branch={"after_command":segment_end,"condition":"no_visible_effect",
                      "skipped_primary_commands":len(action["commands"])-segment_end-1,
                      "fallback_commands":contingency["commands"],"latency_ms":None}
                    if not refresh_between_segments(
                            f"plan-{index}-refresh-after-{segment_end}"):
                        running_invalidation=running_guard.receipt()["invalidation"]
                        break
                    fallback_result=execute_segment(
                        f"plan-{index}-fallback-{segment_end}",contingency["commands"],
                        "fallback",list(range(len(contingency["commands"]))),segment_end,
                        {"after_command":segment_end,"condition":"no_visible_effect",
                         "primary_program_id":result["terminal"]["id"],
                         "command_index":segment_end,
                         "semantic_command":trigger["command"],
                         "effect_receipt":trigger["receipt"]})
                    fallback_records=fallback_result["records"]
                    if fallback_result["invalidated"]:
                        running_invalidation=fallback_result["guard"]["invalidation"]
                        partial_execution=fallback_result["partial"]
                        break
                    branch["latency_ms"]=(fallback_records[0]["accepted_ns"]-
                        trigger["receipt"]["effect_observed_ns"])/1e6
                    break
                segment_start=segment_end+1
                if segment_start<len(action["commands"]) and not refresh_between_segments(
                        f"plan-{index}-refresh-after-{segment_end}"):
                    running_invalidation=running_guard.receipt()["invalidation"]
                    break
            if running_guard.receipt()["state"]==RUNNING_BETWEEN:
                running_guard.record_action_complete()
            running_action_receipt=running_guard.receipt()
            if running_action_receipt["state"] not in (
                    RUNNING_COMPLETED,RUNNING_REVOKED,RUNNING_REJECTED):
                raise RuntimeError("running action ended without a closed guard state")
            receipts=[row["receipt"] for row in trace]
            decisions.append({"iteration":index,"source_image":str(source_image),"model_image":str(image),
              "model_image_sha256":hashlib.sha256(image.read_bytes()).hexdigest(),
              "action":action,"usage":usage,"model_ns":model_ns,
              "prior_soft_event_summary":prior_soft_event_summary,
              "effect_memory":effect_memory,"effect_receipts":receipts,
              "effect_observation_samples":sum(row["observation_samples"] for row in trace),
              "effect_observation_capture_ms":sum(row["observation_capture_ms"] for row in trace),
              "execution_trace":trace,"contingency_branch":branch,
              "compiled_commands":[row["command"] for row in trace],
              "model_session_id":model_session_id,
              "planner_turn_id":planner_handle.turn_id,
              "planner_turn_status":planner_result.status,
              "planner_answer_eligible":planner_result.answer_eligible,
               "planner_terminal_observed_ns":planner_terminal_observed_ns,
               "final_action_admission":final_action_admission,
               "running_action_guard":running_action_receipt,
               "running_action_invalidation":running_invalidation,
               "partial_execution":partial_execution,
               "action_refresh_program_ids":refresh_program_ids,
               "planner_cancellation_requested":planner_result.cancellation_requested,
              "planner_interrupt":planner_interrupt,
              "controller_model_started_ns":model_started_ns,"controller_model_ended_ns":model_ended_ns,
              "model_image_to_plan_accept_ns":first_accepted-grounded_capture_ns,
              "fresh_observation_to_plan_accept_ns":first_accepted-fresh_before_plan["capture_ns"],
              "fresh_sequence_at_plan":fresh_before_plan["sequence"],
              "cover_terminal_before_plan":True,
              "cover_program_ids":cover_ids,"cover_renewals":len(cover_ids)-1,
              "cover_renewal_gaps_ms":cover_renewal_gaps_ms,
              "cover_policy":cover_semantic,"cover_policy_source_iteration":cover_policy_source_iteration,
              "cover_validity_admission":validity_admission,
              "cover_validity_soft_events":invalidation_monitor.soft_event_count,
              "cover_validity_latest_soft_event":invalidation_monitor.latest_soft_event,
               "plan_terminal":("completed" if running_action_receipt["state"]==RUNNING_COMPLETED
                                else "stopped_action_not_current"),
               "model_action_discarded":False,
               "remaining_action_discarded":running_action_receipt["state"]!=RUNNING_COMPLETED})
        failure_cleanup.set_stage("session_finish")
        process.stdin.write('{"op":"finish"}\n');process.stdin.flush()
        failure_cleanup.set_stage("final_score_wait")
        score=wait(lambda r:r["event"]=="post_control_score")
        failure_cleanup.set_stage("session_reap")
        process.wait(timeout=20)
        failure_cleanup.set_stage("planner_close")
        planner_client.close()
        atexit.unregister(planner_client.close)
        failure_cleanup.set_stage("stderr_capture")
        (args.out/"stderr.txt").write_text(process.stderr.read())
        failure_cleanup.set_stage("final_report_prepare")
        typed_events = {row["sequence"]:row for row in all_events
                        if row.get("event")=="typed_observation"}
        full_events = {row["sequence"]:row for row in all_events
                       if row.get("event")=="observation"}
        typed_reconciliations=[]
        for sequence,typed in sorted(typed_events.items()):
            full=full_events.get(sequence)
            if full is None:
                typed_reconciliations.append({
                    "schema":"doom-typed-artifact-reconciliation-v1",
                    "matched":False,"sequence":sequence,
                    "checks":{"full_observation":False}})
            else:
                reconciliation=reconcile_artifact(
                    typed,full,{"health":signal_reader,"ammo":ammo_reader})
                reconciliation["sequence"]=sequence
                typed_reconciliations.append(reconciliation)
        per_key_input_receipts = input_edge_receipts(all_events)
        report={"claim":"persistent typed planner plus immediate and running action invalidation from a fixed real-MAP01 threat state", "model":args.model,
          "source_refreshes":source_refreshes,
          "effort":args.effort,"iterations":len(decisions),"decisions":decisions,"score":score,
          "measurement_session":("v15_scorer_only_per_key_release"
                                  if args.measurement_session else "v12_default"),
          "model_session_span":args.session_span,
          "model_session_ids":list(dict.fromkeys(
              row["model_session_id"] for row in decisions
              if row.get("planner_turn_id") is not None)),
          "motor_contract":"semantic commands compiled to <=450ms turns and <=900ms movement",
          "effect_receipt_contract":"reuse the final exact sample already emitted by each hold; retain full local receipts but expose only no-visible-effect action names to the model",
          "state_feedback_contract":"compare hash-bound typed public health/ammo values at exact before/after action observations and expose the observed transition in the next planner prompt as correlation only; never infer a hit or benefit",
          "input_edge_receipt_contract":("legacy input_release_transition rows pair per-key admissions "
              "with exact owner-thread key-up receipts; optional A01 adapter rows pair X-server "
              "down/up keymap sampling brackets by program, step, key, intent and actuation. "
              "These are distinct evidence types; neither establishes application consumption or task benefit"),
          "input_measurement_backend":("input-owner-v12-batch-keymap-v1" if args.measurement_session else "input-owner-v12-perkey-bridge") if args.per_key_input_measurement else ("owner-thread-release-batch-v1" if args.measurement_session else "typed-release-v1-default"),
          "input_edge_receipts":per_key_input_receipts,
          "input_edge_receipt_statuses":dict(Counter(
              row["status"] for row in per_key_input_receipts)),
          "soft_event_context_contract":"expose only the newest validated typed soft event from the preceding control interval in the already-required next planner turn; add no image, model call, input authority or mid-turn boundary",
          "final_action_admission_contract":"historical transition receipt only after running guard creation: planner eligibility, controller policy/validation decision and first fresh Executor acceptance remain retained; it is not current authority",
          "running_action_contract":"the root running-action-v3 receipt is authoritative after guard creation; every primary/fallback semantic slice is deterministically recompiled and bound to the exact submitted steps, Executor program SHA-256 and lease token; invalidation requires a matched cancel, then exposes independently verified empty physical release while terminal closure remains pending; inter-segment input still requires a fresh passive observation",
          "typed_observation_contract":"health/ammo and RGB SHA-256 are extracted from the captured in-memory frame and emitted before transport/artifact publication; every retained full observation must later match epoch, binding, RGB hash and both signal values",
          "typed_observations":len(typed_events),
          "typed_artifact_reconciliations":typed_reconciliations,
          "typed_artifact_reconciled":sum(row["matched"] for row in typed_reconciliations),
          "typed_artifact_reconciliation_failures":sum(not row["matched"] for row in typed_reconciliations),
          "typed_capture_to_ready_ms":[row["capture_to_typed_ready_ms"]
                                       for row in typed_events.values()],
          "typed_ready_to_emit_ms":[(row["emit_ns"]-row["typed_ready_ns"])/1e6
                                    for row in typed_events.values()],
          "typed_capture_to_artifact_ready_ms":[
              row["capture_to_artifact_ready_ms"] for row in full_events.values()],
          "typed_emit_to_artifact_ready_ms":[
              (full_events[sequence]["artifact_ready_ns"]-typed["emit_ns"])/1e6
              for sequence,typed in typed_events.items() if sequence in full_events],
          "effect_receipt_extra_steps":0,
          "contingency_contract":"preplanned no-visible-effect fallback skips the primary tail and runs without another model call",
          "contingencies_authored":sum(len(x["action"].get("contingencies",[]))
                                       for x in decisions if isinstance(x.get("action"),dict)),
          "contingency_branches_taken":sum(x.get("contingency_branch") is not None for x in decisions),
          "contingency_branch_latency_ms":[x["contingency_branch"]["latency_ms"] for x in decisions if x.get("contingency_branch")],
          "program_admissions":program_admissions,
          "action_refresh_programs":sum(len(x.get("action_refresh_program_ids",[])) for x in decisions),
          "running_action_invalidations":sum(x.get("running_action_invalidation") is not None for x in decisions),
          "running_action_revocations":sum(x.get("running_action_guard",{}).get("state")==RUNNING_REVOKED for x in decisions),
          "running_action_intersegment_rejections":sum(x.get("running_action_guard",{}).get("state")==RUNNING_REJECTED for x in decisions),
          "running_action_program_bindings":sum(
              len(x.get("running_action_guard",{}).get("program_bindings",[]))
              for x in decisions),
          "historical_first_executor_admissions":sum(
              x.get("running_action_guard",{}).get("historical_first_admission") is not None
              for x in decisions),
          "current_input_authority_true_at_decision_close":sum(
              x.get("running_action_guard",{}).get("current_input_authority") is True
              for x in decisions),
          "extra_program_admissions_vs_one_bundle":program_admissions-sum(
              isinstance(x.get("action"),dict) and x["action"]["state"]=="active" and
              not x.get("model_action_discarded",False)
              for x in decisions),
          "effect_receipt_commands":sum(len(x.get("effect_receipts",[])) for x in decisions),
          "effect_observation_samples":sum(x.get("effect_observation_samples",0) for x in decisions),
          "effect_observation_capture_ms":sum(x.get("effect_observation_capture_ms",0) for x in decisions),
          "game_continued_during_model_calls":True,
          "runtime_fixture":runtime_fixture,
          "fixture_contract":"hash/IWAD/engine/map/skill checked before load; measured control begins after load; fixture grants no action authority",
          "planner_contract":"one capability-minimized app-server process; stable typed thread/turn ownership; invalidation interrupts the matching turn and no cancelled or stale answer is admitted",
          "planner_turns":sum(row.get("planner_turn_id") is not None for row in decisions),
          "planner_interruption_requests":sum(x.get("planner_interrupt") is not None for x in decisions),
          "planner_interrupted_completions":sum(x.get("planner_turn_status")=="interrupted" for x in decisions),
          "planner_ineligible_answers":sum(
              x.get("planner_turn_id") is not None and
              not x.get("planner_answer_eligible",False) for x in decisions),
          "policy_invalidation_contract":"authored cover health floor is max(critical_health_minimum, fresh source health - schema-bounded maximum_health_loss); soft change may only preserve admitted cover; hard, unknown, expired or binding-mismatched evidence cancels cover and discards the dependent model action; unauthored empty coast has no policy to invalidate and does not interrupt a pending answer on damage; exact observations and fresh immediate action validity remain mandatory; this never grants input authority or proves success",
          "policy_invalidations":sum(x.get("policy_invalidation") is not None for x in decisions),
          "cover_validity_soft_events":sum(x.get("cover_validity_soft_events",0) for x in decisions),
          "cover_validity_admission_rejections":sum(
              x.get("cover_validity_admission",{}).get("status") != "admitted" for x in decisions),
          "model_actions_discarded":sum(x.get("model_action_discarded",False) for x in decisions),
          "historical_final_action_admission_statuses":dict(Counter(
              x["final_action_admission"]["status"] for x in decisions)),
          "cover_programs":sum(len(x.get("cover_program_ids",[])) for x in decisions),
          "cover_renewals":sum(x.get("cover_renewals",0) for x in decisions),
          "cover_renewal_rejections":cover_renewal_rejections,
          "cover_renewal_gaps_ms":[gap for x in decisions for gap in x.get("cover_renewal_gaps_ms",[])],
          "model_authored_cover_policies":sum(isinstance(x.get("action"),dict) and
              x["action"]["state"]=="active" and not x.get("model_action_discarded",False)
              for x in decisions),
          "model_authored_cover_validity_envelopes":sum(isinstance(x.get("action"),dict) and
              x["action"]["state"]=="active" and len(x["action"].get("next_cover_validity",[]))==1 and
              not x.get("model_action_discarded",False) for x in decisions),
          "model_wall_seconds":sum(x["model_ns"] for x in decisions)/1e9}
        failure_cleanup.set_stage("report_write")
        (args.out/"report.json").write_text(json.dumps(report,indent=2)+"\n")
        print(json.dumps({"iterations":len(decisions),"score":score,
          "model_wall_seconds":report["model_wall_seconds"]},indent=2))

if __name__ == "__main__": main()

# Repaired transport composition: saved-raw spot audit v3

This version corrects the v2 audit predicate: a submit is identified by timeline field `event == session_write`; command rows independently use `op == submit`. V1 path failure and v2 false-negative are preserved in their original outputs. This is a readback only.

Result: **PASS (20/20 checks)**. The frozen source set has 67 files; only changed path versus #8280 `029064c` is `research/live_control/codex_app_server_client_v2.py`. All frozen source bytes match.

- `eof`: failed terminal retained the injected cover error with verified empty release; interrupt returned request_error; await woke with AppServerError; abort completed; peer exit=0; futures done=True; watchdog alive=False; reader alive=False; journal closed=True; process group absent=True. One submit only.
- `rpc_error`: failed terminal retained the injected cover error with verified empty release; interrupt returned request_error; await woke with AppServerError; abort completed; peer exit=-15; futures done=True; watchdog alive=False; reader alive=False; journal closed=True; process group absent=True. One submit only.

EOF peer exit was 0; RPC-error peer exit was -15 from close. The retained activity has no second/final submit. These two cells support only that the repaired client wakes and retires its owned transport on these paths without a recorded abort-close error. They do not establish other transport failure behavior or general timing.

# Repaired transport composition: saved-raw spot audit

This is an additive readback of two repaired cells, not a rerun. The original eight-cell archive and its first audit remain unchanged. The first readback-script attempt is preserved as `audit-attempt-v1-failure.json`; it referenced the nested source-refresh receipt at the wrong path and did not alter evidence.

Result: **FAIL (18/20 checks)**. The frozen source set has 67 files; its only path marked changed relative to #8280 `029064c` is `research/live_control/codex_app_server_client_v2.py`. All source bytes match the freeze.

- `eof`: one submit; failed terminal preserves `injected input error` and verified empty release; interrupt returns request_error; await wakes with AppServerError; abort completes without abort error; peer exit=0; future done=True; watchdog alive=False; reader alive=False; journal closed=True; process group absent=True.
- `rpc_error`: one submit; failed terminal preserves `injected input error` and verified empty release; interrupt returns request_error; await wakes with AppServerError; abort completes without abort error; peer exit=-15; future done=True; watchdog alive=False; reader alive=False; journal closed=True; process group absent=True.

The EOF peer exits normally (code 0); the RPC-error peer is terminated by close (code -15). The retained probe records no second/final submit. These cells support the narrow claim that the repaired client wakes the waiter and retires the owned transport on these two paths without a recorded abort-close error. They do not establish behavior for other transport failures or general timing.

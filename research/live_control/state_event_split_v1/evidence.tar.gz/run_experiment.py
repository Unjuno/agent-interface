import json
from pathlib import Path

from cases import EXPECTED_EVENT_IDS, EXPECTED_LATEST_STATE, build_cases
from model import AllRecordsBuffer, NaiveLatestBuffer, SplitStateEventBuffer

TASK = "EVENT-STATE-SPLIT-20260917-001"
DECISION_PASS = "PASS_SPLIT_STATE_EVENT_RETENTION_SCOPED"
POLICIES = {
    "all_records": AllRecordsBuffer,
    "naive_latest_only": NaiveLatestBuffer,
    "split_state_event": SplitStateEventBuffer,
}


def event_ids(snapshot: dict) -> list[str]:
    return [r["event_id"] for r in snapshot["critical_events"]]


def latest_seqs(snapshot: dict) -> dict[str, int]:
    return {sid: rec["seq"] for sid, rec in snapshot["latest_state"].items()}


def run() -> dict:
    cases = build_cases()
    results = {}
    naive_lost_total = 0
    split_expected_total = 0
    split_retained_total = 0

    for case_name, records in cases.items():
        case_result = {
            "authored_records": len(records),
            "expected_event_ids": EXPECTED_EVENT_IDS[case_name],
            "expected_latest_state": EXPECTED_LATEST_STATE[case_name],
            "policies": {},
        }
        for policy_name, policy_cls in POLICIES.items():
            buf = policy_cls()
            for record in records:
                buf.ingest(record)
            snap = buf.snapshot()
            observed_events = event_ids(snap)
            observed_latest = latest_seqs(snap)
            expected_events = EXPECTED_EVENT_IDS[case_name]
            policy_result = {
                "planner_visible_count": len(snap["planner_visible_records"]),
                "critical_event_ids": observed_events,
                "latest_state_seq": observed_latest,
                "event_identity_exact": observed_events == expected_events,
                "latest_state_exact": observed_latest == EXPECTED_LATEST_STATE[case_name],
            }
            case_result["policies"][policy_name] = policy_result

            if policy_name == "naive_latest_only":
                naive_lost_total += len(set(expected_events) - set(observed_events))
            if policy_name == "split_state_event":
                split_expected_total += len(expected_events)
                split_retained_total += len(observed_events)
        results[case_name] = case_result

    split_all_events_exact = all(
        results[name]["policies"]["split_state_event"]["event_identity_exact"]
        for name in results
    )
    split_all_latest_exact = all(
        results[name]["policies"]["split_state_event"]["latest_state_exact"]
        for name in results
    )
    cross_split = results["cross_session"]["policies"]["split_state_event"]
    gates = {
        "naive_loses_authored_critical_event": naive_lost_total >= 1,
        "split_retains_all_authored_events": split_all_events_exact and split_retained_total == split_expected_total,
        "split_latest_state_exact_all_cases": split_all_latest_exact,
        "progress_storm_reference_count_100": results["progress_storm"]["policies"]["all_records"]["planner_visible_count"] == 100,
        "progress_storm_split_count_1": results["progress_storm"]["policies"]["split_state_event"]["planner_visible_count"] == 1,
        "cross_session_latest_state_scoped": cross_split["latest_state_seq"] == {"A": 10, "B": 100},
        "cross_session_event_scoped": cross_split["critical_event_ids"] == ["a-focus-lost"],
    }
    decision = DECISION_PASS if all(gates.values()) else "FAIL_SPLIT_STATE_EVENT_RETENTION_SCOPED"
    result = {
        "task": TASK,
        "decision": decision,
        "formal_reruns": 0,
        "summary": {
            "naive_lost_critical_events": naive_lost_total,
            "split_expected_critical_events": split_expected_total,
            "split_retained_critical_events": split_retained_total,
            "progress_storm_state_reduction": {
                "all_records": results["progress_storm"]["policies"]["all_records"]["planner_visible_count"],
                "split_state_event": results["progress_storm"]["policies"]["split_state_event"]["planner_visible_count"],
            },
        },
        "gates": gates,
        "cases": results,
        "notes": [
            "Deterministic single-process container fixture.",
            "Critical-event classification is fixture-authored.",
            "No ACK, priority, batching, or event-capacity semantics are claimed in this rung.",
        ],
    }
    Path("result.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, sort_keys=True))
    return result


if __name__ == "__main__":
    run()

import unittest

from cases import build_cases
from model import AllRecordsBuffer, NaiveLatestBuffer, SplitStateEventBuffer


class BufferTests(unittest.TestCase):
    def test_progress_storm_split_keeps_one_state(self):
        buf = SplitStateEventBuffer()
        for record in build_cases()["progress_storm"]:
            buf.ingest(record)
        snap = buf.snapshot()
        self.assertEqual(len(snap["planner_visible_records"]), 1)
        self.assertEqual(snap["latest_state"]["A"]["seq"], 100)
        self.assertEqual(snap["critical_events"], [])

    def test_naive_loses_transient_focus_events(self):
        buf = NaiveLatestBuffer()
        for record in build_cases()["transient_focus"]:
            buf.ingest(record)
        snap = buf.snapshot()
        self.assertEqual(snap["critical_events"], [])
        self.assertEqual(snap["latest_state"]["A"]["seq"], 30)

    def test_split_retains_lease_and_release(self):
        buf = SplitStateEventBuffer()
        for record in build_cases()["lease_release"]:
            buf.ingest(record)
        snap = buf.snapshot()
        self.assertEqual([r["event_id"] for r in snap["critical_events"]], [
            "lease-expired-1", "release-verified-1"
        ])

    def test_cross_session_state_is_scoped(self):
        buf = SplitStateEventBuffer()
        for record in build_cases()["cross_session"]:
            buf.ingest(record)
        snap = buf.snapshot()
        self.assertEqual(snap["latest_state"]["A"]["seq"], 10)
        self.assertEqual(snap["latest_state"]["B"]["seq"], 100)
        self.assertEqual([r["session_id"] for r in snap["critical_events"]], ["A"])

    def test_all_records_reference_preserves_every_record(self):
        records = build_cases()["progress_storm"]
        buf = AllRecordsBuffer()
        for record in records:
            buf.ingest(record)
        self.assertEqual(len(buf.snapshot()["planner_visible_records"]), 100)

    def test_non_monotonic_sequence_rejected_all_policies(self):
        for cls in (AllRecordsBuffer, NaiveLatestBuffer, SplitStateEventBuffer):
            with self.subTest(cls=cls.__name__):
                buf = cls()
                buf.ingest({"session_id": "A", "seq": 2, "kind": "STATE", "value": "x"})
                with self.assertRaisesRegex(ValueError, "non_monotonic_session_seq"):
                    buf.ingest({"session_id": "A", "seq": 1, "kind": "STATE", "value": "y"})

    def test_malformed_record_class_rejected_all_policies(self):
        for cls in (AllRecordsBuffer, NaiveLatestBuffer, SplitStateEventBuffer):
            with self.subTest(cls=cls.__name__):
                buf = cls()
                with self.assertRaisesRegex(ValueError, "invalid_kind"):
                    buf.ingest({"session_id": "A", "seq": 1, "kind": "UNKNOWN"})


if __name__ == "__main__":
    unittest.main()

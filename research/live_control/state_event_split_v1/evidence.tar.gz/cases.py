def state(session_id: str, seq: int, value: str) -> dict:
    return {"session_id": session_id, "seq": seq, "kind": "STATE", "value": value}


def event(session_id: str, seq: int, event_type: str, event_id: str) -> dict:
    return {
        "session_id": session_id,
        "seq": seq,
        "kind": "EVENT",
        "event_type": event_type,
        "event_id": event_id,
    }


def build_cases() -> dict[str, list[dict]]:
    cases: dict[str, list[dict]] = {}

    cases["progress_storm"] = [state("A", i, f"progress-{i}") for i in range(1, 101)]

    focus = [state("A", i, f"focus-state-{i}") for i in range(1, 11)]
    focus += [event("A", 11, "FOCUS_LOST", "focus-lost-1")]
    focus += [state("A", i, f"focus-state-{i}") for i in range(12, 21)]
    focus += [event("A", 21, "FOCUS_RESTORED", "focus-restored-1")]
    focus += [state("A", i, f"focus-state-{i}") for i in range(22, 31)]
    cases["transient_focus"] = focus

    lease = [state("A", i, f"lease-state-{i}") for i in range(1, 6)]
    lease += [event("A", 6, "LEASE_EXPIRED", "lease-expired-1")]
    lease += [state("A", 7, "post-expiry-state")]
    lease += [event("A", 8, "RELEASE_VERIFIED", "release-verified-1")]
    lease += [state("A", 9, "released"), state("A", 10, "idle")]
    cases["lease_release"] = lease

    target = [state("A", i, f"target-state-{i}") for i in range(1, 4)]
    target += [event("A", 4, "TARGET_LOST", "target-lost-1")]
    target += [state("A", i, f"target-state-{i}") for i in range(5, 8)]
    target += [event("A", 8, "TERMINAL", "terminal-1")]
    target += [state("A", 9, "terminal-state")]
    cases["target_terminal"] = target

    cross = [state("A", 1, "a-1"), state("A", 2, "a-2"), state("A", 3, "a-3")]
    cross += [event("A", 4, "FOCUS_LOST", "a-focus-lost")]
    cross += [state("B", i, f"b-{i}") for i in range(1, 101)]
    cross += [state("A", i, f"a-{i}") for i in range(5, 11)]
    cases["cross_session"] = cross

    return cases


EXPECTED_EVENT_IDS = {
    "progress_storm": [],
    "transient_focus": ["focus-lost-1", "focus-restored-1"],
    "lease_release": ["lease-expired-1", "release-verified-1"],
    "target_terminal": ["target-lost-1", "terminal-1"],
    "cross_session": ["a-focus-lost"],
}

EXPECTED_LATEST_STATE = {
    "progress_storm": {"A": 100},
    "transient_focus": {"A": 30},
    "lease_release": {"A": 10},
    "target_terminal": {"A": 9},
    "cross_session": {"A": 10, "B": 100},
}

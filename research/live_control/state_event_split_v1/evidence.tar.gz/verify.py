import json
from pathlib import Path

EXPECTED_DECISION = "PASS_SPLIT_STATE_EVENT_RETENTION_SCOPED"
EXPECTED_GATES = {
    "naive_loses_authored_critical_event",
    "split_retains_all_authored_events",
    "split_latest_state_exact_all_cases",
    "progress_storm_reference_count_100",
    "progress_storm_split_count_1",
    "cross_session_latest_state_scoped",
    "cross_session_event_scoped",
}


def main() -> None:
    data = json.loads(Path("result.json").read_text(encoding="utf-8"))
    assert data["decision"] == EXPECTED_DECISION, data["decision"]
    assert data["formal_reruns"] == 0
    assert set(data["gates"]) == EXPECTED_GATES
    assert all(data["gates"].values())
    assert data["summary"]["naive_lost_critical_events"] >= 1
    assert data["summary"]["split_expected_critical_events"] == 7
    assert data["summary"]["split_retained_critical_events"] == 7
    assert data["summary"]["progress_storm_state_reduction"] == {
        "all_records": 100,
        "split_state_event": 1,
    }
    print("PASS_VERIFY")


if __name__ == "__main__":
    main()

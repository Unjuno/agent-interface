from __future__ import annotations

from copy import deepcopy

CRITICAL_EVENTS = frozenset({
    "FOCUS_LOST",
    "FOCUS_RESTORED",
    "LEASE_EXPIRED",
    "RELEASE_VERIFIED",
    "TARGET_LOST",
    "TERMINAL",
})


def validate_record(record: dict) -> None:
    if not isinstance(record, dict):
        raise ValueError("record_not_dict")
    if not isinstance(record.get("session_id"), str) or not record["session_id"]:
        raise ValueError("invalid_session_id")
    if not isinstance(record.get("seq"), int) or record["seq"] < 1:
        raise ValueError("invalid_seq")
    kind = record.get("kind")
    if kind == "STATE":
        if "event_type" in record or "event_id" in record:
            raise ValueError("state_carries_event_fields")
    elif kind == "EVENT":
        if record.get("event_type") not in CRITICAL_EVENTS:
            raise ValueError("unknown_event_type")
        if not isinstance(record.get("event_id"), str) or not record["event_id"]:
            raise ValueError("invalid_event_id")
    else:
        raise ValueError("invalid_kind")


class _BaseBuffer:
    def __init__(self) -> None:
        self._last_seq: dict[str, int] = {}

    def _accept(self, record: dict) -> dict:
        validate_record(record)
        sid = record["session_id"]
        seq = record["seq"]
        if seq <= self._last_seq.get(sid, 0):
            raise ValueError("non_monotonic_session_seq")
        self._last_seq[sid] = seq
        return deepcopy(record)


class AllRecordsBuffer(_BaseBuffer):
    def __init__(self) -> None:
        super().__init__()
        self._records: list[dict] = []

    def ingest(self, record: dict) -> None:
        self._records.append(self._accept(record))

    def snapshot(self) -> dict:
        latest_state: dict[str, dict] = {}
        critical_events: list[dict] = []
        for record in self._records:
            if record["kind"] == "STATE":
                latest_state[record["session_id"]] = deepcopy(record)
            else:
                critical_events.append(deepcopy(record))
        return {
            "planner_visible_records": deepcopy(self._records),
            "latest_state": latest_state,
            "critical_events": critical_events,
        }


class NaiveLatestBuffer(_BaseBuffer):
    def __init__(self) -> None:
        super().__init__()
        self._latest: dict[str, dict] = {}

    def ingest(self, record: dict) -> None:
        accepted = self._accept(record)
        self._latest[accepted["session_id"]] = accepted

    def snapshot(self) -> dict:
        records = [deepcopy(self._latest[sid]) for sid in sorted(self._latest)]
        latest_state = {
            r["session_id"]: deepcopy(r)
            for r in records
            if r["kind"] == "STATE"
        }
        critical_events = [deepcopy(r) for r in records if r["kind"] == "EVENT"]
        return {
            "planner_visible_records": records,
            "latest_state": latest_state,
            "critical_events": critical_events,
        }


class SplitStateEventBuffer(_BaseBuffer):
    def __init__(self) -> None:
        super().__init__()
        self._latest_state: dict[str, dict] = {}
        self._critical_events: list[dict] = []

    def ingest(self, record: dict) -> None:
        accepted = self._accept(record)
        if accepted["kind"] == "STATE":
            self._latest_state[accepted["session_id"]] = accepted
        else:
            self._critical_events.append(accepted)

    def snapshot(self) -> dict:
        states = [deepcopy(self._latest_state[sid]) for sid in sorted(self._latest_state)]
        events = [deepcopy(r) for r in self._critical_events]
        return {
            "planner_visible_records": events + states,
            "latest_state": {sid: deepcopy(r) for sid, r in self._latest_state.items()},
            "critical_events": events,
        }

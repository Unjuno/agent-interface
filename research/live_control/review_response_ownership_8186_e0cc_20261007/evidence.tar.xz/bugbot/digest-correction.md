# Review message correction

The fixed proposal digest for vote `8186-a32c455-review-e0cc-20261007-v1` is exactly:

`2f43f0ecc21c2dbe6bda732d536e7fcf81add01b8108fbcd2bda0b9b1c5b460d`

The authoritative `review-vote.json` already binds this exact digest, head `a32c45581cf11727b373e822a7e751530d144c16`, review base `1fbef34f244588bff3d79b7cbea423dcb510ef8f`, and patch SHA-256 `064e4d37398033bea33d17db54654b439b0407b3a923737d791a186853245934`. A prior final-chat line transcribed the digest incorrectly; this note preserves the correction.

The pre-send probe demonstrates a response-correlation boundary defect: a response matching a predictable ID is accepted before the corresponding request bytes are transmitted. It is not a claim about hostile-peer authentication or secret IDs.

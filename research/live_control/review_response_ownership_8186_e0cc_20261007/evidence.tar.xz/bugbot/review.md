# PR #8186 content review

Reviewed head `a32c45581cf11727b373e822a7e751530d144c16` over parent `1fbef34f244588bff3d79b7cbea423dcb510ef8f`. Proposal digest: `2f43f0ecc21c2dbe6bda732d536e7fcf81add01b8108fbcd2bda0b9b1c5b460d`. The six-file patch SHA-256 matches the fixed proposal (`064e4d37398033bea33d17db54654b439b0407b3a923737d791a186853245934`). I have no prior authorship of this delta. This is my separate nonauthor content review, not an exact-current-main application check.

## Request changes

1. **[P2] A matching JSON Number `1.0` is now rejected** (`research/live_control/codex_app_server_client_v2.py:44-45`). `_read()` admits only `type(message["id"]) is int. The parent version's `test_app_server_reply_id_5156.py` explicitly sent `float(request['id'])`, called it a valid Number response, and asserted the reply succeeds. The PR changes the peer to echo an integer, silently deleting that compatibility case. Because the request ID is an integer, `1.0 == 1`; the matcher can continue to reject booleans while accepting an equal integral JSON number. Preserve tests for `true`/`false` rejection and add success and error response cases with `1.0`.

2. **[P2] An anticipated response can still complete a request before its bytes are sent** (`research/live_control/codex_app_server_client_v2.py:77-80`). `request()` adds the ID to `_pending` before calling `_write()`. A deterministic inert-stream probe held `_write_lock`, started `request()`, confirmed `_pending == {1}`, and delivered `{"id":1,"result":"forged-before-write"}` while the sent-byte list was empty. The reader cached it and `request()` returned it once the lock was released and the actual request was written. This conflicts with the new test's stated rule that an unissued future ID remains a notification. Registering a request as response-eligible only at the transport-send boundary (while still handling an immediate legitimate reply) and adding this lock-delay case would close the race.

The first probe output is retained at `pre-send-probe-v1.json`; the probe source is `pre_send_probe.py`. No PR source was changed. I did not rerun the author's eight-module suite.

## Scope and limits

The remaining patch shape is coherent: only integer IDs present in `_pending` and lacking a `method` field are treated as replies; `finally` removes pending and cached state after success, server error, timeout, or write failure. The added tests exercise Boolean/float aliases, future replies/errors, timeouts, write failures, concurrent reverse-order responses, and cleanups; UTF-8/EOF/process-tree coverage is retained, and the native catalogue adds the response-ownership module. These checks do not resolve the two issues above. No actual provider/model/GUI/native-input claim is made here.

"""Deterministic inert-stream probe for response acceptance before request write."""
import json, queue, threading, time
from codex_app_server_client_v2 import CodexAppServerClient

class Lines:
    def __init__(self): self.q=queue.Queue()
    def __iter__(self): return self
    def __next__(self):
        value=self.q.get(timeout=3)
        if value is None: raise StopIteration
        return json.dumps(value)+'\n'
    def emit(self,value): self.q.put(value)
    def finish(self): self.q.put(None)
class Sink:
    def __init__(self): self.rows=[]
    def write(self,s): self.rows.append(json.loads(s)); return len(s)
    def flush(self): pass
class Proc:
    def __init__(self): self.stdout=Lines(); self.stdin=Sink(); self.stderr=Sink()
    def poll(self): return 0

p=Proc(); c=CodexAppServerClient([],process_factory=lambda *a,**k:p)
c._write_lock.acquire()
result=[]; errors=[]
def request():
    try: result.append(c.request('fixture/never_sent',timeout=2))
    except BaseException as e: errors.append(type(e).__name__+': '+str(e))
t=threading.Thread(target=request); t.start()
deadline=time.monotonic()+1
while time.monotonic()<deadline:
    with c._condition:
        if 1 in c._pending: break
    time.sleep(.001)
with c._condition: pending_before_write=1 in c._pending
# The request thread is blocked on _write_lock, so no request bytes can have been written.
rows_before=p.stdin.rows[:]
p.stdout.emit({'id':1,'result':'forged-before-write'})
deadline=time.monotonic()+1
while time.monotonic()<deadline:
    with c._condition:
        if 1 in c._responses: break
    time.sleep(.001)
response_cached_before_write=1 in c._responses and not p.stdin.rows
c._write_lock.release(); t.join(2)
p.stdout.finish(); c._reader.join(2)
try: c.close(timeout=1)
except BaseException as e: errors.append('close: '+repr(e))
print(json.dumps({'pending_registered_before_write':pending_before_write,'request_bytes_before_injection':rows_before,
                  'response_cached_before_write':response_cached_before_write,'returned_result':result,
                  'errors':errors,'sent_after_unlock':p.stdin.rows,'thread_alive':t.is_alive()},sort_keys=True))

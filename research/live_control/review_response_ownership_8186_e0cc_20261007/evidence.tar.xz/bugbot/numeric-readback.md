# PR #8186 numeric compatibility: retained-Popen readback

This independent readback passed **54/54 checks** across ten retained actual-Popen inert-child cells. Main and candidate source hashes match the frozen lock. Proposal digest: `2f43f0ecc21c2dbe6bda732d536e7fcf81add01b8108fbcd2bda0b9b1c5b460d`. Producer was not rerun.

| Mode | Main result | Candidate result |
|---|---|---|
| `float` | `[{'value': 'proper-1', 'observed_ns': 11694057889583, 'elapsed_ns': 15909333}]` | `[{'error': 'TimeoutError', 'message': 'app-server request timed out: inert/request', 'observed_ns': 11694767880125, 'elapsed_ns': 310137667}]` |
| `float_error` | `[{'error': 'AppServerError', 'message': 'inert/request: {"code": -32001, "message": "typed-number-error"}', 'observed_ns': 11694224439583, 'elapsed_ns': 16277833}]` | `[{'error': 'TimeoutError', 'message': 'app-server request timed out: inert/request', 'observed_ns': 11695478565250, 'elapsed_ns': 306831334}]` |
| `int` | `[{'value': 'proper-1', 'observed_ns': 11693984128791, 'elapsed_ns': 15972125}]` | `[{'value': 'proper-1', 'observed_ns': 11694393228041, 'elapsed_ns': 15231541}]` |
| `boolean_float` | `[{'value': 'proper-1', 'observed_ns': 11694142410041, 'elapsed_ns': 16115500}]` | `[{'error': 'TimeoutError', 'message': 'app-server request timed out: inert/request', 'observed_ns': 11695132902291, 'elapsed_ns': 308220708}]` |
| `future` | `[{'value': 'proper-1', 'observed_ns': 11694310486666, 'elapsed_ns': 17277083}, {'value': 'unissued-poison', 'observed_ns': 11694310567500, 'elapsed_ns': 73250}]` | `[{'value': 'proper-1', 'observed_ns': 11695551055833, 'elapsed_ns': 16309417}, {'value': 'proper-2', 'observed_ns': 11695661169916, 'elapsed_ns': 110110875}]` |

Both float modes put JSON Number ID `1.0` on the wire for active request ID `1`. Main returns the success and surfaces the typed server error; candidate times out for both and leaves the matching packet in notifications. Integer controls succeed in both arms. The Boolean-plus-float mode confirms Boolean poison is not accepted; main then accepts the float, while candidate times out.

In `future`, the ID-2 poison arrives before the ID-2 request is sent. Main later consumes that poison as the second result. Candidate preserves it as a notification and returns the subsequent proper ID-2 response. All ten cells show retired readers/journals/children and empty pending/cache state. This confirms both the numeric-compatibility regression and the future-ID improvement in these retained cases; it does not clear the content review findings or establish broad concurrency behavior.

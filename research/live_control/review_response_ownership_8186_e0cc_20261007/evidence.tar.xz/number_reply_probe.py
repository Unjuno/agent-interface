"""Actual default-Popen client correlation review, inert peer, no model/GUI."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time

PEER = r'''
import json,sys,time
mode=sys.argv[1]
def emit(value):
    print(json.dumps(value),flush=True)
for line in sys.stdin:
    row=json.loads(line);identifier=row['id']
    if mode=='future' and identifier==1:
        emit({'id':2,'result':'unissued-poison'})
    if mode=='future' and identifier==2:
        time.sleep(.1)
    if mode=='boolean_float':
        emit({'id':True,'result':'boolean-poison'})
    reply_id=float(identifier) if mode in ('float','boolean_float','float_error') else identifier
    emit({'id':reply_id,**({'error':{'code':-32001,'message':'typed-number-error'}}
         if mode=='float_error' else {'result':'proper-'+str(identifier)})})
'''

ap=argparse.ArgumentParser()
ap.add_argument('--source',type=Path,required=True)
ap.add_argument('--out',type=Path,required=True)
ap.add_argument('--mode',choices=['int','float','boolean_float','float_error','future'],required=True)
args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(args.source.resolve()))
from codex_app_server_client_v2 import CodexAppServerClient

client=CodexAppServerClient([sys.executable,'-u','-c',PEER,args.mode],
                            journal_path=str(args.out/'wire.jsonl'))
record={'mode':args.mode,'source_sha256':hashlib.sha256(
        (args.source/'codex_app_server_client_v2.py').read_bytes()).hexdigest(),
        'owns_process_group':client._owns_process_group,'results':[]}
try:
    for ordinal in range(2 if args.mode=='future' else 1):
        start=time.perf_counter_ns()
        try:
            value=client.request('inert/request',timeout=.3)
        except BaseException as error:
            result={'error':type(error).__name__,'message':str(error)}
        else:
            result={'value':value}
        result['observed_ns']=time.perf_counter_ns();result['elapsed_ns']=result['observed_ns']-start
        record['results'].append(result)
    record['notifications']=list(client._notifications)
    record['pending']=sorted(getattr(client,'_pending',[]))
    record['cached_responses']=client._responses.copy()
finally:
    client.close(timeout=1)
    record['peer_returncode']=client.process.poll()
    record['reader_alive']=client._reader.is_alive()
    record['journal_closed']=client._journal.closed
with (args.out/'result.json').open('x') as f:
    json.dump(record,f,indent=2)
print(json.dumps(record))

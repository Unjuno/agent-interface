# #8186 content review probe

Ordinary nonauthor review, no formal allocation. Fixed main9fb2dd6782 versus
exact #8186 a32c455 current-main composed tree5db80ff133c959510a65fb8e573bc5faf3adeaa3.
Only the client's source differs across arms; full bytes/hashes are retained.

H: active request ownership may fix future-ID reuse but exact-int filtering
may reject equal Number replies deliberately accepted by adopted main #7222 /
#5156. The candidate changes the existing stdio fixture's float reply to int.
T: one actual default-Popen inert child per case, no external server, model,
GUI/native input, VM or network. Five modes per arm: integer reply, equal float
reply, Boolean poison then equal float, equal float error, unsolicited future
integer ID before its request then proper later response. Existing client wait
is shortened to .3s for this ordinary protocol test; no throughput bound claim.
Fixed main-then-candidate order, one schedule per cell. Child remains alive to
separate ignored reply timeout from EOF or the known unrelated close race.
D: same-value numeric success/error handling must match the adopted main
behavior, Boolean cannot satisfy a request, and future poison must not satisfy
the later request. Any current-main compatibility loss is a change request for
the fixed proposal, even if the candidate's edited fixture suite passes.
Tear down every owned child and reader. Preserve first failure and raw wire.
C: strict-int is a policy change, not necessarily inherent ownership safety;
JSON-RPC defines Number IDs and same-value response correlation. The local
adopted regression is the concrete compatibility gate; do not claim any actual
provider has sent a float reply. #7254 already documents a numeric-compatible
alternative, so this is scoped reviewer confirmation rather than novel discovery.
U: one schedule per condition, no duplicate-response/denial-of-service/general
concurrency proof or task-effect evaluation. Original claim of34 focused tests
does not supersede the prior adopted compatibility fixture.

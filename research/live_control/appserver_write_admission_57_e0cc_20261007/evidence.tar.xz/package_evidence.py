"""Publish a readback-verified archive without altering private originals."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

work = Path(__file__).resolve().parent
repo = work.parent / 'perkey-owner-guard-repo-e0cc-20261005'
dest = repo / 'research/live_control/appserver_write_admission_57_e0cc_20261007'
dest.mkdir(exist_ok=False)
sha = lambda data: hashlib.sha256(data).hexdigest()
projections = [
    (str(work.parent.parent).encode(), b'${WORKSPACE}'),
    (b'${PYTHON_RUNTIME}', b'${PYTHON_RUNTIME}'),
]
members = []
archive = dest/'evidence.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as tar:
    for path in sorted(work.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:
            continue
        original = path.read_bytes()
        public = original
        for before, after in projections:
            public = public.replace(before, after)
        name = path.relative_to(work).as_posix()
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(public), 0o644, 0
        tar.addfile(info, io.BytesIO(public))
        members.append(dict(path=name, original_bytes=len(original), public_bytes=len(public),
                            original_sha256=sha(original), public_sha256=sha(public),
                            projection=original != public))
with tarfile.open(archive, 'r:xz') as tar:
    assert tar.getnames() == [m['path'] for m in members]
    for m in members:
        data = tar.extractfile(m['path']).read()
        assert len(data) == m['public_bytes'] and sha(data) == m['public_sha256']
manifest = dict(schema='appserver-write-admission-evidence-v1', members=members,
                archive_bytes=archive.stat().st_size, archive_sha256=sha(archive.read_bytes()),
                full_member_readback=True, original_files_preserved=True,
                omitted='regenerable __pycache__ bytecode only',
                projections=[{'from': a.decode(), 'to': b.decode()} for a, b in projections])
# Describe private roots by role, not by public absolute home paths.
manifest['projections'] = ['workspace root -> ${WORKSPACE}', 'bundled Python root -> ${PYTHON_RUNTIME}']
(dest/'MANIFEST.json').write_text(json.dumps(manifest, indent=2)+'\n')
sources = json.loads((work/'static-index-v1/STATIC.json').read_text())['sources']
result = dict(schema='appserver-write-admission-result-v1', issue=57,
    base_sha='9fb2dd6782d1d1477a00d14be870487fd4c54fa2',
    status='PASS_SCOPED_CONSTRUCTION', sources=sources,
    baseline=dict(test_methods=13, runner_exit=1, failure_events=7, error_events=2,
                  note='unittest counts include subtest failures; original stream retained'),
    candidate=dict(new_test_methods=13, focused_test_methods_per_mode=42,
                   focused_modes=['normal', '-O'], focused_runner_exits=[0, 0]),
    actual_popen=dict(protocol_cells=10, admission_cells=4, all_runner_exits=0,
                     all_readers_and_requesters_retired=True, all_child_returncodes=-15),
    independent_coauthor_readback=dict(checks=91, status='PASS',
        report='bugbot/full-readback-v2/review.md',
        mandatory_correction='bugbot/full-readback-v2/correction.md'),
    root_saved_data_crosscheck=dict(checks=28, status='PASS', report='ROOT_READBACK.md'),
    local_checks=dict(workspace_unittest_methods=22, workspace_directories=160,
                      syntax=True, diff_check=True, catalogue_exact_single_append=True,
                      adopted_numeric_fixture_unchanged=True),
    retained_failures=['baseline-v1/stderr.txt', 'bugbot/construction-audit-attempt-v1-failure.json',
                      'bugbot/construction-audit.json', 'bugbot/construction-audit.md',
                      'bugbot/full-readback-v2/review.md', 'tooling-notes.txt'],
    main_applied=False, quorum_review=False, external_nonauthor_committee='NOT_ASSIGNED',
    archive_sha256=manifest['archive_sha256'],
    limits=['Software response admission at classification, not proof of physical byte delivery or peer authentication.',
            'Sent-record gate delays only outgoing record preparation; shared receive-side journal lock is not held.',
            'Existing request timeout begins after write; no whole-call latency or blocked-write bound claimed.',
            'No provider/model/GUI/native input/VM/container/formal allocation run; full native catalogue not run.',
            'Independent close/reap repair #8290 remains separate; no imported whole-bundle votes from #8186 or #7254.'])
(dest/'RESULT.json').write_text(json.dumps(result, indent=2)+'\n')
(dest/'README.md').write_text('''# App-server response ownership at write admission

Main could cache an unsolicited future response, return a response while its request was still waiting for the write slot, or replace the first reply with a duplicate. This current-main successor admits each numeric request ID only after acquiring the write slot and preparing serialization and its sent journal record. It accepts the first matching response, preserves equal Number IDs such as `1` and `1.0`, and retires the pending ID and response cache on every request exit. Blocking I/O does not hold the reader condition lock.

H: this software admission boundary rejects replies classified before admission without losing immediate, numeric, or concurrent replies. T: held-write-slot and gated sent-record counterexamples, fake synchronous replies/failures, and 14 actual default-Popen inert-peer cells on frozen baseline/candidate sources. D: candidate rejects pre-admission/future/duplicate poison, retains proper numeric results/errors, and retires requests/readers/children in the tested cells. C: replies buffered before admission but classified later, fake transport ordering, and EOF can confound a broader claim. U: these are ordinary construction regressions, not a preregistered formal allocation or an authentication/delivery guarantee.

The new 13-method suite fails on baseline (7 failure events and 2 errors, including subtests) and passes on candidate. The selected nine-module suite passes 42 methods in each of normal and optimized Python runs. Existing EOF fixtures now reject unissued replies; UTF-8 fixtures release data after request submission, following the useful fixture adjustment from #8186. The adopted #5156 numeric fixture remains byte-identical. The protocol catalogue gains exactly one module. Workspace checks pass 22 tests and index 160 existing top-level directories.

The ten numeric/future-ID Popen cells preserve integer, float, Boolean-noise-then-float, and float typed-error behavior. Both baseline and candidate already reject Boolean IDs; baseline drops them, candidate retains them as notifications. Only candidate rejects the future ID-2 poison. Four additional Popen cells reproduce the before-admission poison under both local gates; baseline returns poison and retains a later proper reply, candidate returns the proper reply with empty final pending/cache state. Every recorded child exits -15 after owned cleanup, and readers/requesters retire. This is synthetic Python-peer protocol evidence, not actual Codex provider behavior.

Read `RESULT.json` and `MANIFEST.json`, then the archive's commands, source snapshots, JSONL journals, stdout/stderr, and audit files. All archive members were read back and hashed. Private originals remain intact; only two declared local path prefixes are projected for publication. Bytecode is omitted. Reviewers can restore the projected root paths or adapt the saved-data auditor's ROOT/REPO constants; no producer replay is needed to inspect results.

Audit corrections are part of the evidence: the first coauthor audit script had a TypeError, and its next attempt reported 11/13 because it misclassified an intentional typed error and inspected the wrong journal-gate state key. The additive 91-check saved-data audit passed. Its narrative mistakenly said baseline accepted bool; `bugbot/full-readback-v2/correction.md` corrects that statement. `ROOT_READBACK.md` also corrects the old construction report's claim of empty baseline final caches and records 28 saved-data crosschecks. Original failure and misstatement files remain visible; read them with these corrections.

Predecessor #7254 already preserves numeric compatibility, but still admits IDs before acquiring the write lock; #8186 rejects equal float IDs and has the same earlier admission gap. Both remain untouched. This proposal contains no #8290 close/reap change. The pending set marks local software admission immediately before `stdin.write`, not the first physical byte sent; a reply classified after admission can correlate even if it arrived earlier. First matching response does not validate arbitrary JSON-RPC response shape. Existing write blocking and timeout scope are unchanged. No model, live game, GUI, native-input, container, or formal allocation ran. Full runtime catalogue and provider behavior remain unverified.

This is an authored Draft proposal. Coauthor audits are not nonauthor quorum votes; no committee or application attempt is assigned and main is unchanged. Two genuine eligible nonauthors, a fixed proposal, current-main composition and mandatory platform checks remain required before integration.
''')
print(json.dumps({'directory':str(dest), 'members':len(members),
                  'projected_members':sum(m['projection'] for m in members),
                  'archive_bytes':manifest['archive_bytes'],
                  'archive_sha256':manifest['archive_sha256']}))

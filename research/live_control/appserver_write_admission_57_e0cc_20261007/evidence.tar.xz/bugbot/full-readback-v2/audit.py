#!/usr/bin/env python3
"""Independent read-only readback of frozen #8186 Popen and focused-suite outputs."""
import hashlib, json, pathlib, sys
ROOT = pathlib.Path('${WORKSPACE}/work/appserver-write-admission-e0cc-20261007')
REPO = pathlib.Path('${WORKSPACE}/work/perkey-owner-guard-repo-e0cc-20261005')
OUT = pathlib.Path(__file__).resolve().parent / 'audit-result.json'

def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def load(p): return json.loads(pathlib.Path(p).read_text())
def wire(p): return [json.loads(x) for x in pathlib.Path(p).read_text().splitlines() if x.strip()]
def check(cond, label, details=None):
    checks.append({'name':label,'pass':bool(cond),'details':details})
    if not cond: failures.append(label)

checks=[]; failures=[]
result={'schema':'appserver-write-admission-readback-v2','scope':'saved artifacts only; no producer or test rerun','checks':checks,'failures':failures}
# Exact frozen snapshots and active repository candidate identity.
base=ROOT/'baseline-v1/codex_app_server_client_v2.py'; cand=ROOT/'candidate-v1/codex_app_server_client_v2.py'
base_sha=sha(base); cand_sha=sha(cand); active=REPO/'research/live_control/codex_app_server_client_v2.py'
check(base_sha=='d140fec92cb7e81a439d7cda95c67d63d902af08fc4997bfa5df7933aa14deb4','baseline_snapshot_hash',base_sha)
check(cand_sha=='a51ed51120a72f289c3d8298a446ab5958ebdff0f0261f770637daaba0862faa','candidate_snapshot_hash',cand_sha)
check(sha(active)==cand_sha,'active_candidate_matches_frozen_snapshot',sha(active))
# Focused frozen suite: exact source pins, two execution logs, and recorded rc.
fr=load(ROOT/'focused-v1/RUN.json'); repo_source_hashes={}
for rel,want in fr['sources'].items():
    p=REPO/rel; got=sha(p) if p.is_file() else None; repo_source_hashes[rel]=got
    check(got==want,'focused_source:'+rel,{'expected':want,'actual':got})
focused_rows=[]
for rec in fr['records']:
    label=rec['label']; stdout=ROOT/'focused-v1'/f'{label}.stdout.txt'; stderr=ROOT/'focused-v1'/f'{label}.stderr.txt'
    text=stderr.read_text(errors='replace')+stdout.read_text(errors='replace')
    n='Ran 42 tests' in text and 'OK' in text
    check(rec['returncode']==0 and n,'focused_run:'+label,{'returncode':rec['returncode'],'ran42_and_ok':n,'stdout_sha256':sha(stdout),'stderr_sha256':sha(stderr),'declared_stdout_sha256':rec['stdout_sha256'],'declared_stderr_sha256':rec['stderr_sha256']})
    check(sha(stdout)==rec['stdout_sha256'] and sha(stderr)==rec['stderr_sha256'],'focused_log_hashes:'+label)
    focused_rows.append({'label':label,'returncode':rec['returncode'],'test_count':42,'stdout_sha256':sha(stdout),'stderr_sha256':sha(stderr)})
check(len(focused_rows)==2,'focused_two_modes',len(focused_rows))
# Ten actual subprocess cells; manifests, messages, values and teardown.
pr=load(ROOT/'real-popen-v1/RUN.json'); expected_modes={'int','float','boolean_float','float_error','future'}
seen=set(); popen_rows=[]
for rec in pr['records']:
    arm,mode=rec['arm'],rec['mode']; key=(arm,mode); seen.add(key)
    p=pathlib.Path(rec['command'][rec['command'].index('--out')+1]); d=load(p/'result.json'); rows=wire(p/'wire.jsonl')
    srcwant=base_sha if arm=='baseline-v1' else cand_sha
    check(rec['returncode']==0,'popen_exit:'+p.name,rec['returncode'])
    check(d.get('source_sha256')==srcwant,'popen_source:'+p.name,{'want':srcwant,'got':d.get('source_sha256')})
    check(d.get('reader_alive') is False and d.get('peer_returncode')==-15 and d.get('journal_closed') is True and d.get('pending')==[] and d.get('cached_responses')=={},'popen_teardown:'+p.name,{k:d.get(k) for k in ('reader_alive','peer_returncode','journal_closed','pending','cached_responses')})
    sent=[r for r in rows if r['direction']=='sent' and r['message'].get('method')=='inert/request']
    recv=[r for r in rows if r['direction']=='received' and 'id' in r['message']]
    if mode=='future':
        poison=[r for r in recv if r['message'].get('result')=='unissued-poison']
        check(len(poison)==1 and len(sent)==2 and poison[0]['observed_ns']<sent[1]['observed_ns'],'future_poison_precedes_second_send:'+p.name,{'poison_ns':poison[0]['observed_ns'] if poison else None,'second_send_ns':sent[1]['observed_ns'] if len(sent)>1 else None})
        val=[x.get('value') for x in d['results']]
        expected=['proper-1','proper-2'] if arm=='candidate-v1' else ['proper-1','unissued-poison']
        check(val==expected,'future_result:'+p.name,{'expected':expected,'actual':val})
        if arm=='candidate-v1': check(any(x.get('result')=='unissued-poison' for x in d['notifications']),'future_poison_notification:'+p.name,d['notifications'])
    elif mode=='float_error':
        check(len(d['results'])==1 and d['results'][0].get('error')=='AppServerError' and 'typed-number-error' in d['results'][0].get('message',''),'float_error_contract:'+p.name,d['results'])
        check(any(r['message'].get('error',{}).get('message')=='typed-number-error' and type(r['message'].get('id')) is float for r in recv),'float_error_wire:'+p.name)
    else:
        check(len(d['results'])==1 and d['results'][0].get('value')=='proper-1','numeric_result:'+p.name,d['results'])
        if mode=='boolean_float' and arm=='candidate-v1': check(any(x.get('id') is True for x in d['notifications']),'boolean_poison_notification:'+p.name,d['notifications'])
    popen_rows.append({'arm':arm,'mode':mode,'path':p.name,'exit':rec['returncode'],'result':d['results'],'notifications':d['notifications'],'wire_sha256':sha(p/'wire.jsonl'),'result_sha256':sha(p/'result.json')})
check(seen=={(a,m) for a in ('baseline-v1','candidate-v1') for m in expected_modes},'all_ten_popen_cells',sorted([list(x) for x in seen]))
# Four actual Popen admission-boundary cells: compare wire chronology and returned value.
ar=load(ROOT/'real-admission-v1/RUN.json'); adm_rows=[]; seen_adm=set()
for rec in ar['records']:
    arm,gate=rec['arm'],rec['gate']; seen_adm.add((arm,gate)); p=pathlib.Path(rec['command'][rec['command'].index('--out')+1]); d=load(p/'result.json'); rows=wire(p/'wire.jsonl')
    srcwant=base_sha if arm=='baseline-v1' else cand_sha
    check(rec['returncode']==0,'admission_exit:'+p.name,rec['returncode'])
    check(d.get('source_sha256')==srcwant,'admission_source:'+p.name,{'want':srcwant,'got':d.get('source_sha256')})
    poison=next((r for r in rows if r['direction']=='received' and r['message'].get('result')=='before-admission'),None)
    sent=next((r for r in rows if r['direction']=='sent' and r['message'].get('method')=='fixture/request'),None)
    proper=next((r for r in rows if r['direction']=='received' and r['message'].get('result')=='proper'),None)
    check(poison is not None and sent is not None and proper is not None and poison['observed_ns']<sent['observed_ns']<proper['observed_ns'],'admission_wire_order:'+p.name,{'poison':poison,'sent':sent,'proper':proper})
    expected_value='proper' if arm=='candidate-v1' else 'before-admission'
    check(d.get('results',[{}])[0].get('value')==expected_value,'admission_return:'+p.name,{'expected':expected_value,'got':d.get('results')})
    check(d.get('requester_alive') is False and d.get('reader_alive') is False and d.get('peer_returncode')==-15 and d.get('journal_closed') is True and d.get('final_pending')==[],'admission_teardown:'+p.name)
    if arm=='candidate-v1': check(d.get('before_release',{}).get('responses')=={} and d.get('before_release',{}).get('pending')==[] and any(x.get('result')=='before-admission' for x in d.get('before_release',{}).get('notifications',[])),'admission_candidate_pre_release:'+p.name,d.get('before_release'))
    else: check(d.get('before_release',{}).get('responses',{}).get('1.0',{}).get('result')=='before-admission','admission_baseline_cached_poison:'+p.name,d.get('before_release'))
    adm_rows.append({'arm':arm,'gate':gate,'path':p.name,'exit':rec['returncode'],'returned':d.get('results'),'before_release':d.get('before_release'),'wire_sha256':sha(p/'wire.jsonl'),'result_sha256':sha(p/'result.json')})
check(seen_adm=={(a,g) for a in ('baseline-v1','candidate-v1') for g in ('write-slot','sent-record')},'all_four_admission_cells',sorted([list(x) for x in seen_adm]))
# Persist audit metadata.
result.update({'status':'PASS' if not failures else 'FAIL','source_sha256':{'baseline':base_sha,'candidate':cand_sha,'active_repo_candidate':sha(active)},'focused_runs':focused_rows,'real_popen_cells':popen_rows,'real_admission_cells':adm_rows,'limitations':['Synthetic local child processes only; no Codex/provider/model/GUI/native input execution.','Pending correlation records local software admission before stdin write/flush completion; this does not prove bytes reached or were processed by peer.','Queue-based outgoing-record construction check is not identical to holding the shared receive-side journal mutex; four Popen admission traces establish observed receive-before-send wire order.','Numeric JSON id equality intentionally retains int/float compatibility while excluding booleans; ids are correlation fields, not authentication.']})
OUT.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':result['status'],'checks':len(checks),'failures':failures,'output':str(OUT)},indent=2))
sys.exit(bool(failures))

# Saved-data readback v2

This is a coauthor saved-artifact audit, not an external/quorum review. No candidate, subprocess probe, or unittest suite was rerun for this readback.

The independent readback in `audit.py` passed 91 checks. It verifies both focused-suite invocations (normal and `-O`) returned zero, each reported 42 tests and `OK`, and all 11 source pins match the repository snapshot. Candidate production bytes match the frozen candidate SHA-256 `a51ed51120a72f289c3d8298a446ab5958ebdff0f0261f770637daaba0862faa`; the active repository source has the same digest. Baseline snapshot SHA-256 is `d140fec92cb7e81a439d7cda95c67d63d902af08fc4997bfa5df7933aa14deb4`.

The 10 real-Popen traces show integer and floating JSON-number replies (including the typed float error) still complete on both arms. For the Boolean-ID case, baseline temporarily treats `true` as integer ID 1, while candidate routes it to notifications and then completes from the proper numeric reply. In the future-ID case, wire order has the unissued ID-2 reply before the second request: baseline returns that poison for request 2, while candidate keeps it as a notification and returns the proper response. All 10 retained cells report empty pending/cache state, a retired reader, closed journal, and child return code `-15`.

The four additional real-Popen admission traces each show the pre-admission reply arriving before the request is sent, followed by the proper reply. Baseline returns the early reply; candidate records it as a notification and returns the later proper reply. Both write-slot and sent-record gates have this same ordering. All four cells retain the expected teardown state.

The earlier `construction-audit.json` FAIL and `construction-audit-attempt-v1-failure.json` are retained unchanged. They are superseded only by this corrected, additive saved-data readback; they have not been erased or represented as passing.

Limits: these are synthetic local child-process cases, not real provider/model or GUI execution. The pending set represents local software admission immediately before the stdin write call; it cannot establish that bytes were physically delivered or processed. IDs provide correlation, not peer authentication. The queue-based outgoing-record gate is not the literal shared receive-side journal mutex; the four Popen traces independently establish the observed receive-before-send chronology for their gates.

Audit source SHA-256: `71f7cdea9bbef2ef42610201e9e01870ba4e610365bfb64af80a1336564f23e2`. Audit-result SHA-256: `8f39e2e7d9822140fbed5d1c6c27a19cf0ac058a85057418b825127e42ee8de1`.

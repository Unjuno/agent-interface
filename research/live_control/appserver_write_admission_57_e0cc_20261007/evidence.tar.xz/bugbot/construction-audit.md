# Write-admission construction probe readback

**11/13 checks passed** across five queue-fake cases for each immutable source snapshot. Base source SHA-256 `d140fec92cb7e81a439d7cda95c67d63d902af08fc4997bfa5df7933aa14deb4`; candidate `a51ed51120a72f289c3d8298a446ab5958ebdff0f0261f770637daaba0862faa`; probe `3c0c4723f177b8563c57eff5decfd5430b10374cb3739f0996a739d9a2fd51dc`.

- Held write lock: base cached and returned `poison-before-send` before any send record; candidate kept it as a notification and returned `proper-after-send`.
- Gated sent-journal stage: same split. This is a test gate around the outgoing journal stage, not the literal shared `_journal_lock`, because receive-side journaling also needs that lock.
- Duplicate replies delivered while the request writer remained blocked: base returned the second response; candidate returned the first and retained the duplicate as a notification.
- Equal float numeric ID `1.0`: both snapshots returned success and surfaced the typed error.
- All fake request/reader threads retired and pending/response caches were empty after cleanup.

The candidate admits the ID after the write slot and sent-record stage, immediately before `stdin.write`. This is a software admission boundary; it cannot prove physical delivery to the peer or authenticate a response. These fake cases do not replace the separate actual-Popen checks.

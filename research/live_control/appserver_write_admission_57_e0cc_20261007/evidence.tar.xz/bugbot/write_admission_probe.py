"""Inert queue-fake checks for request admission/write ordering and numeric IDs."""
import argparse, importlib.util, io, json, queue, threading, time, tempfile
from pathlib import Path

def load_client(source):
    spec=importlib.util.spec_from_file_location('client_under_probe',source)
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module.CodexAppServerClient

class Lines:
    def __init__(self): self.q=queue.Queue()
    def __iter__(self): return self
    def __next__(self):
        value=self.q.get(timeout=4)
        if value is None: raise StopIteration
        return json.dumps(value,separators=(',',':'))+'\n'
    def emit(self,row): self.q.put(row)
    def finish(self): self.q.put(None)
class Sink:
    def __init__(self,process): self.process=process
    def write(self,line):
        row=json.loads(line); self.process.sent.append(row)
        callback=self.process.on_write
        if callback: callback(row)
        return len(line)
    def flush(self):
        if self.process.flush_error: raise self.process.flush_error
    def close(self): pass
class Process:
    def __init__(self,on_write=None,flush_error=None):
        self.stdout=Lines(); self.stderr=io.StringIO(); self.sent=[]
        self.on_write=on_write; self.flush_error=flush_error; self.stdin=Sink(self)
    def poll(self): return 0

def wait_for(fn,timeout=1.5):
    end=time.monotonic()+timeout
    while time.monotonic()<end:
        value=fn()
        if value: return value
        time.sleep(.001)
    return fn()
def state(c,p):
    with c._condition:
        return {'pending':sorted(getattr(c,'_pending',set())), 'responses':dict(c._responses),
                'notifications':list(c._notifications), 'sent':list(p.sent)}
def run_case(Client,name,journal_gate=False):
    result={'case':name}; done=threading.Event(); values=[]; errors=[]
    proper_gate=threading.Event(); sent_event=threading.Event()
    processed_duplicate=threading.Event(); duplicate_count=[0]
    def on_write(row):
        sent_event.set()
        if name in ('prewrite_lock','prewrite_journal'):
            return
        if name=='duplicate_first_wins':
            p.stdout.emit({'id':row['id'],'result':'first'})
            p.stdout.emit({'id':row['id'],'result':'duplicate'})
            if not processed_duplicate.wait(1.5): raise TimeoutError('reader did not process both replies while writer blocked')
        elif name=='float_success': p.stdout.emit({'id':float(row['id']),'result':'numeric-ok'})
        elif name=='float_error': p.stdout.emit({'id':float(row['id']),'error':{'code':-32010,'message':'numeric-error'}})
    with tempfile.TemporaryDirectory() as td:
        p=Process(on_write=on_write)
        c=Client([],process_factory=lambda *a,**k:p,journal_path=(str(Path(td)/'journal.jsonl') if journal_gate else None))
        if name=='duplicate_first_wins':
            original=c._condition.notify_all
            def observed_notify_all():
                original()
                if threading.current_thread() is c._reader:
                    duplicate_count[0]+=1
                    if duplicate_count[0]>=2: processed_duplicate.set()
            c._condition.notify_all=observed_notify_all
        sent_record_gate=threading.Event(); release_sent_record=threading.Event()
        if journal_gate:
            original_record=c._record
            def gated_record(direction,message):
                if direction=='sent' and message.get('method')=='fixture/request':
                    sent_record_gate.set()
                    if not release_sent_record.wait(1.5): raise TimeoutError('sent journal gate timed out')
                return original_record(direction,message)
            c._record=gated_record
        if name=='prewrite_lock': c._write_lock.acquire()
        if name=='prewrite_journal': pass
        def call():
            try: values.append(c.request('fixture/request',timeout=.3 if name.startswith('float_') else 2))
            except BaseException as e: errors.append({'type':type(e).__name__,'message':str(e)})
            finally: done.set()
        t=threading.Thread(target=call,daemon=True); t.start()
        try:
            if name=='prewrite_lock':
                result['id_allocated']=bool(wait_for(lambda:c._next_id==2))
                result['sent_before_poison']=list(p.sent)
                p.stdout.emit({'id':1,'result':'poison-before-send'})
                result['poison_classified_before_unlock']=bool(wait_for(lambda: any(
                    (n.get('id')==1 and n.get('result')=='poison-before-send') for n in getattr(c,'_notifications',[])) or
                    c._responses.get(1,{}).get('result')=='poison-before-send'))
                result['before_unlock']=state(c,p)
                c._write_lock.release()
            elif name=='prewrite_journal':
                result['sent_journal_gate_entered']=bool(sent_record_gate.wait(1))
                p.stdout.emit({'id':1,'result':'poison-before-send'})
                result['poison_classified_before_journal_release']=bool(wait_for(lambda: any(
                    n.get('id')==1 and n.get('result')=='poison-before-send' for n in getattr(c,'_notifications',[])) or
                    c._responses.get(1,{}).get('result')=='poison-before-send'))
                result['before_journal_release']=state(c,p)
                release_sent_record.set()
            elif name=='duplicate_first_wins':
                pass
            elif name in ('float_success','float_error'):
                pass
            if name.startswith('prewrite_'):
                if not sent_event.wait(1): result['sent_event_timeout']=True
                result['completed_before_proper_reply']=done.wait(.05)
                p.stdout.emit({'id':1,'result':'proper-after-send'})
            t.join(2)
            result['thread_alive_after_join']=t.is_alive()
            result['values']=values[:]; result['errors']=errors[:]
            result['after']=state(c,p)
            result['write_records']=p.sent[:]
            result['response_processing_notifications']=duplicate_count[0]
        except BaseException as e:
            result['probe_error']={'type':type(e).__name__,'message':str(e)}
        finally:
            if name=='prewrite_lock' and c._write_lock.locked(): c._write_lock.release()
            release_sent_record.set(); proper_gate.set()
            if t.is_alive(): t.join(1)
            p.stdout.finish(); c._reader.join(2)
            try: c.close(timeout=1)
            except BaseException as e: result['close_error']=repr(e)
            result['thread_alive_final']=t.is_alive(); result['reader_alive_final']=c._reader.is_alive()
            result['after_cleanup']=state(c,p)
            result['journal_closed']=bool(c._journal is None or c._journal.closed)
    return result

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--source',required=True); ap.add_argument('--out',required=True); ap.add_argument('--arm',required=True)
    a=ap.parse_args(); out=Path(a.out); out.mkdir(parents=True,exist_ok=False); Client=load_client(a.source)
    cases=[]
    for n in ('prewrite_lock','prewrite_journal','duplicate_first_wins','float_success','float_error'):
        cases.append(run_case(Client,n,journal_gate=(n=='prewrite_journal')))
    raw={'schema':'write-admission-probe-v1','arm':a.arm,'source':str(Path(a.source).resolve()),'cases':cases,
         'scope':'queue-fake construction only; software admission boundary, no external peer authentication or physical-byte receipt claim'}
    (out/'raw.json').write_text(json.dumps(raw,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'arm':a.arm,'cases':len(cases),'errors':sum(bool(c.get('probe_error') or c.get('close_error')) for c in cases),'raw':str(out/'raw.json')}))
if __name__=='__main__': main()

# App-server response ownership repair: design review

Read-only design feedback against `research/live_control/codex_app_server_client_v2.py` at main `9fb2dd6782d1d1477a00d14be870487fd4c54fa2`. No source or test execution performed.

## Minimal ordering

Keep the monotone ID allocation under `_condition`, but do not add that ID to `_pending` before waiting for `_write_lock`. Extend the write path with a request-admission callback (or equivalent private helper): acquire `_write_lock`; encode the JSON line; write/flush the `sent` journal record; under `_condition`, add the request ID to `_pending`; immediately call `stdin.write(encoded_line)` and `flush()`. The reader must use the same condition-protected active-ID set. Do not hold `_condition` across journal I/O or a potentially blocking stream write: current fake-process fixtures can synchronously wait for the reader from `write()`, which would deadlock if the reader needed the condition to publish its response.

The callback is a software request-admission boundary immediately before the transport write. It does not prove bytes reached the peer or authenticate a peer response. If the write or flush raises, `request()`'s `finally` must discard the ID and any response; a late packet is no longer eligible. If serialization or the sent-journal write fails before admission, no pending ID is created and no request bytes should be written. Preserve the current timeout/EOF exception paths and cleanup with `finally`, including `BaseException` unwinding.

For numeric matching, accept response IDs whose exact Python type is `int` or `float` (never `bool`) and whose numeric value equals a currently admitted integer request ID; the active-ID membership check rejects unequal/fractional values. This preserves the adopted `1` ↔ `1.0` Number behavior while rejecting Python's `True == 1` alias. Keep a success and an error response test for `1.0`.

## Smallest discriminating tests

- Hold `_write_lock`, start a request, wait until it is blocked before the send-admission callback, deliver the predictable ID response, and prove it is only a notification. Release the lock, deliver the proper response, and prove the request returns only that response.
- Deliver a valid response from inside/just after the actual `stdin.write` path to prove immediate-response races are still captured; run two concurrent requests and return responses in reverse order.
- Preserve integer, equal-float success/error, Boolean poison, unissued-future success/error, timeout then late response, EOF, write failure, journal/serialization failure, and custom `process_factory` controls. After every exit, assert `_pending` and `_responses` are empty and the reader/child resources retire.
- Deliver two responses for one pending ID before the waiter runs. Retain the first response (or otherwise explicitly define and test duplicate handling); do not silently overwrite an already accepted result with a duplicate.

## Lock/failure cautions

`_read()` records the received journal row before taking `_condition`; `_write()` holds `_write_lock` and takes the journal lock in `_record()`. Keep those locks released before taking `_condition` except for the very short admission update, to avoid introducing a write/reader deadlock. Preserve one write per request; never resend after a partial write or flush failure. Test `write()` and `flush()` failures separately if the fixture can distinguish them, because both must retire pending ownership while preserving the original exception.

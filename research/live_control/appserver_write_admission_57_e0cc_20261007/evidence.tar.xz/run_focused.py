"""Save bounded current-source regression commands, bytes, outcomes and logs."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

repo = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
out.mkdir(exist_ok=False)
modules = [
    'test_appserver_write_admission_e0cc', 'test_app_server_eof_stop',
    'test_app_server_reply_id_5156', 'test_app_server_utf8',
    'test_appserver_utf8_2d0b', 'test_appserver_process_tree_cleanup_20261004',
    'test_appserver_reader_retirement_01a0ff2d',
    'test_appserver_journal_close_01a0ff2d',
    'runtime.integration_checks.test_native_catalogue',
]
paths = ['research/live_control/codex_app_server_client_v2.py',
         'runtime/integration_checks/native.py']
paths += [('runtime/integration_checks/test_native_catalogue.py' if m.startswith('runtime.')
           else 'research/live_control/' + m + '.py') for m in modules]
sources = {}
for name in paths:
    data = (repo/name).read_bytes()
    target = out/'source'/name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    sources[name] = hashlib.sha256(data).hexdigest()
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1',
           PYTHONPATH=os.pathsep.join([str(repo), str(repo/'research/live_control')]))
records = []
for label, flags in [('normal', []), ('optimized', ['-O'])]:
    command = [sys.executable, '-B', *flags, '-m', 'unittest', '-v', *modules]
    start = time.monotonic_ns()
    result = subprocess.run(command, cwd=repo, env=env, capture_output=True, timeout=90)
    (out/(label+'.stdout.txt')).write_bytes(result.stdout)
    (out/(label+'.stderr.txt')).write_bytes(result.stderr)
    records.append(dict(label=label, command=command, returncode=result.returncode,
                        duration_ns=time.monotonic_ns()-start,
                        stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),
                        stderr_sha256=hashlib.sha256(result.stderr).hexdigest()))
    print(label, result.returncode, result.stderr.decode(errors='replace')[-2500:])
    (out/'RUN.json').write_text(json.dumps(dict(sources=sources, records=records), indent=2)+'\n')
sys.exit(0 if all(r['returncode'] == 0 for r in records) else 1)

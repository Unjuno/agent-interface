"""Default Popen peer injects a reply while a request awaits local admission."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import threading

PEER = r'''
import json, pathlib, sys, time
gate=pathlib.Path(sys.argv[1]); deadline=time.monotonic()+4
while not gate.exists():
    if time.monotonic() > deadline: raise TimeoutError('fixture gate absent')
    time.sleep(.001)
print(json.dumps({'id':1.0,'result':'before-admission'}),flush=True)
print(json.dumps({'method':'fixture/poison-processed'}),flush=True)
for line in sys.stdin:
    row=json.loads(line)
    print(json.dumps({'id':float(row['id']),'result':'proper'}),flush=True)
'''


class ObservedLock:
    def __init__(self):
        self.lock = threading.Lock()
        self.entered = threading.Event()

    def __enter__(self):
        self.entered.set()
        self.lock.acquire()

    def __exit__(self, *_):
        self.lock.release()


ap = argparse.ArgumentParser()
ap.add_argument('--source', type=Path, required=True)
ap.add_argument('--out', type=Path, required=True)
ap.add_argument('--gate', choices=['write-slot', 'sent-record'], required=True)
args = ap.parse_args()
args.out.mkdir(parents=True, exist_ok=False)
sys.path.insert(0, str(args.source))
from codex_app_server_client_v2 import CodexAppServerClient

client = CodexAppServerClient([sys.executable, '-B', '-u', '-c', PEER, str(args.out/'send-poison')],
                              journal_path=args.out/'wire.jsonl')
release = threading.Event()
entered = threading.Event()
lock = None
if args.gate == 'write-slot':
    lock = ObservedLock()
    client._write_lock = lock
    lock.lock.acquire()
    entered = lock.entered
else:
    original_record = client._record

    def gated_record(direction, message):
        if direction == 'sent':
            entered.set()
            if not release.wait(3):
                raise TimeoutError('fixture sent-record not released')
        original_record(direction, message)

    client._record = gated_record

results = []


def request():
    try:
        results.append({'value': client.request('fixture/request', timeout=1)})
    except BaseException as error:
        results.append({'error': type(error).__name__, 'message': str(error)})


thread = threading.Thread(target=request)
record = dict(gate=args.gate, owns_process_group=client._owns_process_group,
              source_sha256=hashlib.sha256((args.source/'codex_app_server_client_v2.py').read_bytes()).hexdigest())
thread.start()
try:
    if not entered.wait(1):
        raise TimeoutError('request did not reach local gate')
    (args.out/'send-poison').write_text('ready\n')
    client.wait_notification(lambda row: row.get('method') == 'fixture/poison-processed', timeout=1)
    with client._condition:
        record['before_release'] = dict(responses=dict(client._responses),
            pending=sorted(getattr(client, '_pending', [])), notifications=list(client._notifications))
finally:
    release.set()
    if lock is not None:
        lock.lock.release()
    thread.join(2)
    client.close(timeout=1)
    thread.join(1)
    record.update(results=results, requester_alive=thread.is_alive(),
                  reader_alive=client._reader.is_alive(), peer_returncode=client.process.poll(),
                  journal_closed=client._journal.closed,
                  final_pending=sorted(getattr(client, '_pending', [])),
                  final_responses=dict(client._responses))
    (args.out/'result.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record))

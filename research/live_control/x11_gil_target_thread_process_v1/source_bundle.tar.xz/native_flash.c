#define _POSIX_C_SOURCE 200809L
#include <X11/Xlib.h>
#include <stdint.h>
#include <time.h>

static uint64_t mono_ns(void) {
    struct timespec t; if (clock_gettime(CLOCK_MONOTONIC, &t)) return 0;
    return (uint64_t)t.tv_sec*1000000000ULL + (uint64_t)t.tv_nsec;
}
static int paint(Display *d, unsigned long pixel) {
    Window w=DefaultRootWindow(d); GC g=XCreateGC(d,w,0,NULL); if(!g) return -4;
    XSetForeground(d,g,pixel); XFillRectangle(d,w,g,48,48,32,32); XFreeGC(d,g); XSync(d,False); return 0;
}
int f_clear(const char *name) {
    Display *d=XOpenDisplay(name); if(!d) return -1; int rc=paint(d,0x101010UL); XCloseDisplay(d); return rc;
}
/* trace: draw_request, draw_sync_done, clear_request, clear_sync_done */
int f_flash(const char *name, uint64_t delay_ns, uint64_t *trace) {
    if(!name || !trace || delay_ns==0) return -1;
    Display *d=XOpenDisplay(name); if(!d) return -2;
    trace[0]=mono_ns(); if(paint(d,0xdc3232UL)) { XCloseDisplay(d); return -3; }
    trace[1]=mono_ns();
    struct timespec req={(time_t)(delay_ns/1000000000ULL),(long)(delay_ns%1000000000ULL)};
    while(nanosleep(&req,&req)) {}
    trace[2]=mono_ns(); if(paint(d,0x101010UL)) { XCloseDisplay(d); return -4; }
    trace[3]=mono_ns(); XCloseDisplay(d); return 0;
}

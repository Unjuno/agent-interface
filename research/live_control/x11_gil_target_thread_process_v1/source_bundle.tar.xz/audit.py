#!/usr/bin/env python3
import base64, hashlib, json, math, statistics, sys
from pathlib import Path
TASK='X11-GIL-TARGET-THREAD-PROCESS-20260916-001'; PERIOD=2_000_000
ARMS={'thread':0.001,'process':0.001}

def independent_count(raw): return sum(raw[i:i+3]==b'\x32\x32\xdc' for i in range(0,4096,4))
def check_case(r,cpus,formal=True):
    assert r['task']==TASK and r['arm'] in ARMS and not r['errors']
    assert math.isclose(r['switch_interval'],0.001,rel_tol=0,abs_tol=1e-12) and r['competitor_kind']==r['arm']
    assert math.isclose(r['current_switch_interval'],0.001,rel_tol=0,abs_tol=1e-12)
    assert r['main_affinity']==[cpus['observer']] and r['main_affinity_after']==[cpus['observer']]
    load=r['load']; assert load['kind']==r['arm'] and load['affinity']==[cpus['competitor']] and load['final_affinity']==[cpus['competitor']] and load['cleaned'] and math.isclose(load['switch_interval'],0.001,rel_tol=0,abs_tol=1e-12)
    assert load['cpu_ns']>0 and load['iterations']>0
    o=r['owner']; assert o['affinity']==[cpus['observer']] and o['press_verified'] and o['verified_empty'] and 'error' not in o
    assert o['press_command_ns']<=o['press_sync_ns']<=o['press_verified_ns']<=o['release_command_ns']<=o['release_sync_ns']<=o['verified_empty_ns']
    assert r['final_keymap_empty'] and not any(base64.b64decode(r['final_keymap_b64'])) and not any(base64.b64decode(o['final_keymap_b64']))
    assert len(r['app_events']['press'])==1 and len(r['app_events']['release'])==1
    assert r['final_roi_count']==0
    pix={k:base64.b64decode(v) for k,v in r['pixels'].items()}
    assert all(len(v)==4096 and hashlib.sha256(v).hexdigest()==k for k,v in pix.items())
    assert r['final_roi_sha256'] in pix and independent_count(pix[r['final_roi_sha256']])==0
    cue=r['cue']; assert cue['affinity']==[cpus['observer']] and 'error' not in cue
    assert cue['call_start_ns']<=cue['draw_request_ns']<=cue['draw_sync_done_ns']<=cue['clear_request_ns']<=cue['clear_sync_done_ns']<=cue['call_return_ns']
    assert cue['exposure_ns']==cue['clear_request_ns']-cue['draw_sync_done_ns']
    assert 4_000_000<=cue['exposure_ns']<=8_000_000
    w=r['watcher']; assert w['affinity']==[cpus['observer']] and 'error' not in w and w['thread_cpu_ns']>=0
    rows=r['rows']; assert rows
    last_start=-1; any_target=False
    for row in rows:
        assert len(row)==5; due,start,end,cnt,dg=row
        assert due>=0 and due<=start<=end and start>last_start; last_start=start
        assert dg in pix; ic=independent_count(pix[dg]); assert cnt==ic; any_target |= cnt>=512
    assert bool(w['detected'])==any_target
    if any_target:
        assert w['detected_ns'] is not None and o['release_reason']=='cancel'
        assert o['release_command_ns']<r['deadline_ns'] and w['detected_ns']<=o['release_command_ns']
    else:
        assert w['detected_ns'] is None and o['release_reason']=='deadline' and o['release_command_ns']>=r['deadline_ns']
    return True

def derive(raw):
    cpus=raw['cpus']; recs=raw['records']; assert raw['task']==TASK and not raw['errors'] and len(recs)==20
    for r in recs: check_case(r,cpus,True)
    by={arm:[r for r in recs if r['arm']==arm] for arm in ARMS}; assert all(len(v)==10 for v in by.values())
    detections={arm:sum(1 for r in by[arm] if r['watcher']['detected']) for arm in ARMS}
    def maxgap(r):
        ss=[x[1] for x in r['rows']]; return max((b-a for a,b in zip(ss,ss[1:])),default=0)
    pairs=[]
    for i in range(10):
        t=next(r for r in recs if r['pair']==i and r['arm']=='thread'); p=next(r for r in recs if r['pair']==i and r['arm']=='process')
        tg=maxgap(t); pg=maxgap(p); pairs.append({'pair':i,'thread_detected':t['watcher']['detected'],'process_detected':p['watcher']['detected'],'thread_max_gap_ns':tg,'process_max_gap_ns':pg,'gap_ratio':pg/tg if tg else None,'process_detect_thread_miss':p['watcher']['detected'] and not t['watcher']['detected']})
    ratios=[x['gap_ratio'] for x in pairs]; median_ratio=statistics.median(ratios); discriminating=sum(x['process_detect_thread_miss'] for x in pairs)
    gate=detections['process']>=9 and median_ratio<=0.70 and discriminating>=2
    decision='PROCESS_REMOVES_RESIDUAL_GAP_SCOPED' if gate else 'HOLD_THREAD_PROCESS_ATTRIBUTION'
    return {'decision':decision,'detections':detections,'median_process_thread_gap_ratio':median_ratio,'process_detect_thread_miss_pairs':discriminating,'pairs':pairs}

def audit(path):
    raw=json.loads(Path(path).read_text()); return {'pass':True,'derived':derive(raw)}
if __name__=='__main__':
    out=audit(sys.argv[1]); print(json.dumps(out,sort_keys=True,indent=2))

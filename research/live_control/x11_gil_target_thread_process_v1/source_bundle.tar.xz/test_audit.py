#!/usr/bin/env python3
import copy, json, sys
from pathlib import Path
from audit import check_case

def rejected(base,cpus,mut):
    x=copy.deepcopy(base); mut(x)
    try: check_case(x,cpus,formal=False); return False
    except Exception: return True

def main(rawpath):
    raw=json.loads(Path(rawpath).read_text()); cpus=raw['cpus']; base=raw['records'][0]
    muts={
      'switch':lambda x:x.__setitem__('switch_interval',0.005),
      'competitor_kind':lambda x:x.__setitem__('competitor_kind','process' if x['arm']=='thread' else 'thread'),
      'load_kind':lambda x:x['load'].__setitem__('kind','process' if x['arm']=='thread' else 'thread'),
      'cue_duration':lambda x:x['cue'].__setitem__('exposure_ns',9_000_000),
      'cue_order':lambda x:x['cue'].__setitem__('clear_request_ns',x['cue']['draw_sync_done_ns']-1),
      'load_affinity':lambda x:x['load'].__setitem__('affinity',[cpus['observer']]),
      'load_cpu_zero':lambda x:x['load'].__setitem__('cpu_ns',0),
      'final_keymap':lambda x:x.__setitem__('final_keymap_empty',False),
      'app_release':lambda x:x['app_events'].__setitem__('release',[]),
      'final_roi':lambda x:x.__setitem__('final_roi_count',1),
      'row_count':lambda x:x['rows'][0].__setitem__(3,x['rows'][0][3]+1),
      'row_time':lambda x:x['rows'][0].__setitem__(2,x['rows'][0][1]-1),
      'owner_verify':lambda x:x['owner'].__setitem__('verified_empty',False),
      'pixel':lambda x:x['pixels'].__setitem__(next(iter(x['pixels'])),'AAAA'),
    }
    res={k:rejected(base,cpus,v) for k,v in muts.items()}; print(json.dumps(res,sort_keys=True,indent=2)); assert all(res.values())
if __name__=='__main__': main(sys.argv[1])

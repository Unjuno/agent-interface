#!/usr/bin/env python3
import argparse, base64, ctypes, hashlib, importlib, json, os, pathlib, platform, select, signal, statistics, subprocess, sys, threading, time, traceback
from pathlib import Path

HERE=Path(__file__).resolve().parent
TASK='X11-GIL-TARGET-THREAD-PROCESS-20260916-001'
BASE='43c1952c9f60b0ca482f2a7eed19fd352e9f6fca'
PERIOD_NS=2_000_000
DEADLINE_NS=600_000_000
FLASH_NS=5_000_000
ARMS={'thread':0.001,'process':0.001}
OFFSETS=[150,152,154,156,158,150,152,154,156,158]
SOURCE_FILES=('native_acquire.c','native_predicate.c','native_flash.c','build.py','run.py','audit.py','test_audit.py')
BIN_FILES=('native_acquire.so','native_flash.so','native_predicate.cpython-313-x86_64-linux-gnu.so')
os.environ['XAUTHORITY']='/dev/null'

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,obj): Path(p).write_text(json.dumps(obj,sort_keys=True,separators=(',',':'))+'\n')
def source_hashes(): return {n:sha(HERE/n) for n in SOURCE_FILES}
def binary_hashes(): return {n:sha(HERE/n) for n in BIN_FILES}
def schedule():
    out=[]
    for pair,off in enumerate(OFFSETS):
        arms=('thread','process') if pair%2==0 else ('process','thread')
        for j,a in enumerate(arms): out.append({'pair':pair,'arm':a,'offset_ms':off,'order':2*pair+j})
    return out

def topology(c):
    p=Path(f'/sys/devices/system/cpu/cpu{c}/topology')
    return {k:(p/k).read_text().strip() for k in ('physical_package_id','core_id','thread_siblings_list')}
def cpu_map():
    allowed=sorted(os.sched_getaffinity(0));
    if len(allowed)<4: raise RuntimeError('four CPUs required')
    base=allowed[0]; tb=topology(base)
    distinct=[c for c in allowed if topology(c)['core_id']!=tb['core_id'] or topology(c)['physical_package_id']!=tb['physical_package_id']]
    if len(distinct)<3: raise RuntimeError('four guest-reported cores required')
    return {'observer':base,'competitor':distinct[0],'server':distinct[1],'supervisor':distinct[2],'allowed':allowed,
            'topology':{str(c):topology(c) for c in allowed}}
def cgroup():
    return {n:Path('/sys/fs/cgroup',n).read_text() for n in ('cpu.max','cpu.stat') if Path('/sys/fs/cgroup',n).exists()}
def sleep_until(ns):
    while True:
        rem=ns-time.monotonic_ns()
        if rem<=0:return
        time.sleep(rem/1e9)
def key_down(km,kc): return bool(km[kc//8] & (1<<(kc%8)))

def load_libs():
    ac=ctypes.CDLL(str(HERE/'native_acquire.so'))
    ac.q_init.restype=ctypes.c_int; ac.q_open.argtypes=[ctypes.c_char_p]; ac.q_open.restype=ctypes.c_void_p
    ac.q_close.argtypes=[ctypes.c_void_p]; ac.q_read.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_size_t]; ac.q_read.restype=ctypes.c_int
    fl=ctypes.CDLL(str(HERE/'native_flash.so'))
    fl.f_clear.argtypes=[ctypes.c_char_p]; fl.f_clear.restype=ctypes.c_int
    fl.f_flash.argtypes=[ctypes.c_char_p,ctypes.c_uint64,ctypes.c_void_p]; fl.f_flash.restype=ctypes.c_int
    if not ac.q_init(): raise RuntimeError('XInitThreads failed')
    sys.path.insert(0,str(HERE)); pred=importlib.import_module('native_predicate')
    return ac,fl,pred

def busy_loop(stop,cpu,ready,rec):
    os.sched_setaffinity(0,{cpu}); sys.setswitchinterval(0.001); rec['tid']=threading.get_native_id(); rec['pid']=os.getpid(); rec['affinity']=sorted(os.sched_getaffinity(0)); rec['switch_interval']=sys.getswitchinterval(); ready.set()
    start=time.thread_time_ns(); loops=0; x=0x12345678
    while not stop.is_set(): x=(1664525*x+1013904223)&0xffffffff; loops+=1
    rec.update(cpu_ns=time.thread_time_ns()-start,iterations=loops,checksum=x,final_affinity=sorted(os.sched_getaffinity(0)))

def hog_main(cpu):
    stop=threading.Event(); rec={'kind':'process'}
    signal.signal(signal.SIGTERM,lambda *_:stop.set())
    ready=threading.Event()
    def announce():
        os.sched_setaffinity(0,{cpu}); sys.setswitchinterval(0.001); rec.update(tid=threading.get_native_id(),pid=os.getpid(),affinity=sorted(os.sched_getaffinity(0)),switch_interval=sys.getswitchinterval()); ready.set(); print(json.dumps({'ready':rec}),flush=True)
    announce(); start=time.thread_time_ns(); loops=0; x=0x12345678
    while not stop.is_set(): x=(1664525*x+1013904223)&0xffffffff; loops+=1
    rec.update(cpu_ns=time.thread_time_ns()-start,iterations=loops,checksum=x,final_affinity=sorted(os.sched_getaffinity(0)))
    print(json.dumps({'final':rec}),flush=True)

class Competitor:
    def __init__(self,kind,cpu):
        self.kind=kind; self.cpu=cpu; self.rec={'kind':kind}; self.stop=threading.Event(); self.th=None; self.p=None
        if kind=='thread':
            ready=threading.Event(); self.th=threading.Thread(target=busy_loop,args=(self.stop,cpu,ready,self.rec),daemon=True); self.th.start()
            if not ready.wait(2): raise RuntimeError('thread load readiness timeout')
        else:
            self.p=subprocess.Popen([sys.executable,str(HERE/'run.py'),'hog','--cpu',str(cpu)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            if not select.select([self.p.stdout],[],[],2)[0]: raise RuntimeError('process load readiness timeout')
            msg=json.loads(self.p.stdout.readline()); self.rec=msg['ready']
        time.sleep(.02)
    def close(self):
        if self.th:
            self.stop.set(); self.th.join(2); self.rec['cleaned']=not self.th.is_alive()
        else:
            self.p.terminate()
            try: out,err=self.p.communicate(timeout=2); forced=False
            except subprocess.TimeoutExpired: self.p.kill(); out,err=self.p.communicate(); forced=True
            lines=[x for x in out.splitlines() if x.strip()]
            if lines:
                msg=json.loads(lines[-1]); self.rec.update(msg.get('final',{}))
            self.rec.update(cleaned=self.p.poll() is not None,exitcode=self.p.returncode,forced=forced,stderr=err)


def run_case(display_name,arm,pair,offset_ms,cpus):
    import tkinter as tk
    from Xlib import X, XK, display
    from Xlib.ext import xtest
    os.sched_setaffinity(0,{cpus['observer']}); sys.setswitchinterval(0.001)
    ac,fl,pred=load_libs(); disp_b=display_name.encode()
    if fl.f_clear(disp_b)!=0: raise RuntimeError('initial clear failed')
    rec={'task':TASK,'arm':arm,'pair':pair,'offset_ms':offset_ms,'switch_interval':sys.getswitchinterval(),'competitor_kind':arm,
         'main_affinity':sorted(os.sched_getaffinity(0)),'rows':[],'pixels':{},'app_events':{'press':[],'release':[]},'errors':[]}
    comp=Competitor(arm,cpus['competitor'])
    root=tk.Tk(screenName=display_name); root.overrideredirect(True); root.geometry('20x20+130+90'); root.configure(bg='#202020')
    root.bind('<KeyPress-Right>',lambda e: rec['app_events']['press'].append(time.monotonic_ns()))
    root.bind('<KeyRelease-Right>',lambda e: rec['app_events']['release'].append(time.monotonic_ns()))
    root.update_idletasks(); root.update()
    xd=display.Display(display_name); win=xd.create_resource_object('window',root.winfo_id()); xd.set_input_focus(win,X.RevertToPointerRoot,X.CurrentTime); xd.sync(); root.focus_force(); root.update()
    keysym=XK.string_to_keysym('Right'); kc=xd.keysym_to_keycode(keysym); rec['right_keycode']=kc
    origin=time.monotonic_ns(); deadline=origin+DEADLINE_NS
    rec['origin_ns']=origin; rec['deadline_ns']=deadline
    cancel=threading.Event(); owner_done=threading.Event(); pressed=threading.Event(); cue_done=threading.Event(); watcher_done=threading.Event()
    owner={}; cue={}; watcher={'detected':False,'detected_ns':None,'thread_cpu_ns':0}
    def owner_fn():
        try:
            os.sched_setaffinity(0,{cpus['observer']}); d=display.Display(display_name); owner['affinity']=sorted(os.sched_getaffinity(0)); owner['tid']=threading.get_native_id()
            owner['press_command_ns']=time.monotonic_ns(); xtest.fake_input(d,X.KeyPress,kc); d.sync(); owner['press_sync_ns']=time.monotonic_ns()
            km=d.query_keymap(); owner['press_verified_ns']=time.monotonic_ns(); owner['press_verified']=key_down(km,kc); pressed.set()
            reason='deadline'
            while True:
                now=time.monotonic_ns();
                if cancel.is_set(): reason='cancel'; break
                if now>=deadline: break
                cancel.wait(min((deadline-now)/1e9,0.01))
            owner['release_reason']=reason; owner['release_command_ns']=time.monotonic_ns(); xtest.fake_input(d,X.KeyRelease,kc); d.sync(); owner['release_sync_ns']=time.monotonic_ns()
            ok=False
            for _ in range(200):
                km=d.query_keymap(); now=time.monotonic_ns()
                if not key_down(km,kc): ok=True; owner['verified_empty_ns']=now; break
                time.sleep(.0002)
            owner['verified_empty']=ok; owner['final_keymap_b64']=base64.b64encode(bytes(km)).decode(); d.close()
        except BaseException: owner['error']=traceback.format_exc(); pressed.set()
        finally: owner_done.set()
    def watcher_fn():
        h=None
        try:
            os.sched_setaffinity(0,{cpus['observer']}); watcher['affinity']=sorted(os.sched_getaffinity(0)); watcher['tid']=threading.get_native_id()
            h=ac.q_open(disp_b)
            if not h: raise RuntimeError('watch display open failed')
            if not pressed.wait(0.2): raise RuntimeError('press readiness timeout')
            due=origin+10_000_000; c0=time.thread_time_ns()
            while not owner_done.is_set() and time.monotonic_ns()<deadline+100_000_000:
                sleep_until(due); start=time.monotonic_ns(); buf=ctypes.create_string_buffer(4096); status=ac.q_read(h,buf,4096); end=time.monotonic_ns()
                if status: raise RuntimeError(f'acquire {status}')
                raw=buf.raw; cnt=pred.count_target(raw); dg=hashlib.sha256(raw).hexdigest(); rec['pixels'].setdefault(dg,base64.b64encode(raw).decode())
                rec['rows'].append([due-origin,start-origin,end-origin,cnt,dg])
                if cnt>=512 and not watcher['detected']:
                    watcher['detected']=True; watcher['detected_ns']=end; cancel.set()
                due+=PERIOD_NS; now=time.monotonic_ns()
                if due<now-PERIOD_NS: due+=((now-due)//PERIOD_NS+1)*PERIOD_NS
            watcher['thread_cpu_ns']=time.thread_time_ns()-c0
        except BaseException: watcher['error']=traceback.format_exc()
        finally:
            if h: ac.q_close(h)
            watcher_done.set()
    def cue_fn():
        try:
            os.sched_setaffinity(0,{cpus['observer']}); cue['affinity']=sorted(os.sched_getaffinity(0)); cue['tid']=threading.get_native_id()
            sleep_until(origin+offset_ms*1_000_000); tr=(ctypes.c_uint64*4)(); cue['call_start_ns']=time.monotonic_ns(); rc=fl.f_flash(disp_b,FLASH_NS,tr); cue['call_return_ns']=time.monotonic_ns()
            if rc: raise RuntimeError(f'flash {rc}')
            cue.update(draw_request_ns=tr[0],draw_sync_done_ns=tr[1],clear_request_ns=tr[2],clear_sync_done_ns=tr[3],exposure_ns=tr[2]-tr[1])
        except BaseException: cue['error']=traceback.format_exc()
        finally: cue_done.set()
    ot=threading.Thread(target=owner_fn,daemon=True); wt=threading.Thread(target=watcher_fn,daemon=True); ct=threading.Thread(target=cue_fn,daemon=True)
    ot.start(); wt.start(); ct.start()
    hard=time.monotonic()+1.2
    try:
        while time.monotonic()<hard and not (owner_done.is_set() and cue_done.is_set() and watcher_done.is_set()):
            root.update(); time.sleep(.0002)
        # drain app events after physical release
        drain=time.monotonic()+.08
        while time.monotonic()<drain and len(rec['app_events']['release'])<1:
            root.update(); time.sleep(.0002)
    finally:
        comp.close(); ot.join(.2); wt.join(.2); ct.join(.2)
    rec['load']=comp.rec
    rec['owner']=owner; rec['cue']=cue; rec['watcher']=watcher
    # independent final ROI and keymap
    h=ac.q_open(disp_b); buf=ctypes.create_string_buffer(4096); status=ac.q_read(h,buf,4096); ac.q_close(h)
    if status: raise RuntimeError('final capture failed')
    raw=buf.raw; rec['final_roi_count']=pred.count_target(raw); rec['final_roi_sha256']=hashlib.sha256(raw).hexdigest(); rec['pixels'].setdefault(rec['final_roi_sha256'],base64.b64encode(raw).decode())
    km=xd.query_keymap(); rec['final_keymap_b64']=base64.b64encode(bytes(km)).decode(); rec['final_keymap_empty']=not any(km)
    rec['end_ns']=time.monotonic_ns(); rec['current_switch_interval']=sys.getswitchinterval(); rec['main_affinity_after']=sorted(os.sched_getaffinity(0))
    root.destroy(); xd.close()
    for name,obj in [('owner',owner),('watcher',watcher),('cue',cue)]:
        if obj.get('error'): rec['errors'].append(f'{name}: {obj["error"]}')
    return rec

def launch_xvfb(cpu):
    r,w=os.pipe(); log=open(HERE/'xvfb.log','w'); p=subprocess.Popen(['taskset','-c',str(cpu),'Xvfb','-displayfd',str(w),'-screen','0','160x120x24','-nolisten','tcp','-ac'],pass_fds=(w,),stdout=log,stderr=log); os.close(w)
    if not select.select([r],[],[],5)[0]: p.terminate(); raise RuntimeError('Xvfb startup timeout')
    num=os.read(r,64).decode().strip(); os.close(r); return p,':'+num,log

def static_predicate(pred):
    out=[]
    for n in (0,1,511,512,513,1023,1024):
        b=bytearray([0x10,0x10,0x10,0]*1024)
        for i in range(n): b[4*i:4*i+3]=b'\x32\x32\xdc'
        got=pred.count_target(bytes(b)); out.append({'expected':n,'got':got}); assert got==n
    guards=[]
    for bad in (b'',b'x'*4095,b'x'*4097,bytearray(4096)):
        try: pred.count_target(bad); guards.append(False)
        except (TypeError,ValueError): guards.append(True)
    assert all(guards); return {'boundaries':out,'guards':guards}

def run_supervisor(mode,outdir):
    out=Path(outdir).resolve(); out.mkdir(parents=True,exist_ok=False); cpus=cpu_map(); os.sched_setaffinity(0,{cpus['supervisor']})
    ac,fl,pred=load_libs(); pre=static_predicate(pred)
    result={'task':TASK,'mode':mode,'base':BASE,'sources':source_hashes(),'binaries':binary_hashes(),'schedule':schedule(),'cpus':cpus,'records':[],'errors':[],
            'environment':{'python':sys.version,'platform':platform.platform(),'gil':sys._is_gil_enabled(),'initial_switch_interval':sys.getswitchinterval(),'cgroup_before':cgroup(),
                           'cpuinfo':Path('/proc/cpuinfo').read_text().split('\n\n')[0]},'construction_static':pre}
    p=None; log=None
    try:
        p,name,log=launch_xvfb(cpus['server']); result['server']={'display':name,'pid':p.pid,'affinity':sorted(os.sched_getaffinity(p.pid))}
        cases=schedule() if mode=='formal' else [dict(pair=-1,arm='thread',offset_ms=154,order=0),dict(pair=-1,arm='process',offset_ms=154,order=1)]
        if mode=='formal':
            plan=json.loads((HERE/'prereg.json').read_text());
            if plan['task']!=TASK or plan['base']!=BASE or plan['sources']!=source_hashes() or plan['binaries']!=binary_hashes() or plan['schedule']!=schedule() or plan['cpus']!=cpus: raise RuntimeError('frozen provenance mismatch')
            with (HERE/'CONSUMED').open('x') as f:f.write(TASK+'\n')
        from audit import check_case
        for c in cases:
            path=out/f"case-{c['order']:02d}-{c['arm']}.json"
            cmd=['taskset','-c',','.join(map(str,cpus['allowed'])),sys.executable,str(HERE/'run.py'),'case','--display',name,'--arm',c['arm'],'--pair',str(c['pair']),'--offset',str(c['offset_ms']),'--out',str(path)]
            q=subprocess.run(cmd,text=True,capture_output=True,timeout=5)
            if q.returncode: raise RuntimeError(f'case failed {c}: {q.stderr}\n{q.stdout}')
            rec=json.loads(path.read_text()); result['records'].append(rec); check_case(rec,cpus,formal=(mode=='formal'))
            dump(out/'raw.json',result); print(c,'integrity pass',flush=True)
        result['server']['alive_after']=p.poll() is None; result['server']['affinity_after']=sorted(os.sched_getaffinity(p.pid))
    except BaseException: result['errors'].append(traceback.format_exc()); raise
    finally:
        if p:
            p.terminate()
            try:p.wait(3)
            except subprocess.TimeoutExpired:p.kill();p.wait()
            result.setdefault('server',{}).update(exitcode=p.returncode,reaped=p.poll() is not None)
        if log: log.close()
        os.sched_setaffinity(0,set(cpus['allowed'])); result['environment']['cgroup_after']=cgroup(); result['sources_after']=source_hashes(); result['binaries_after']=binary_hashes(); dump(out/'raw.json',result)

def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    a=sub.add_parser('case'); a.add_argument('--display',required=True); a.add_argument('--arm',choices=ARMS,required=True); a.add_argument('--pair',type=int,required=True); a.add_argument('--offset',type=int,required=True); a.add_argument('--out',required=True)
    h=sub.add_parser('hog'); h.add_argument('--cpu',type=int,required=True)
    for m in ('construction','formal'):
        b=sub.add_parser(m); b.add_argument('--out',required=True)
    args=ap.parse_args()
    if args.cmd=='hog': hog_main(args.cpu); return
    if args.cmd=='case':
        cpus=cpu_map(); rec=run_case(args.display,args.arm,args.pair,args.offset,cpus); dump(args.out,rec); return
    run_supervisor(args.cmd,args.out)
if __name__=='__main__': main()

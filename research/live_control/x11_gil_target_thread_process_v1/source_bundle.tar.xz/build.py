#!/usr/bin/env python3
import subprocess, sysconfig, pathlib
D=pathlib.Path(__file__).resolve().parent
subprocess.run(['gcc','-O2','-Wall','-Wextra','-fPIC','-shared','-Wl,--build-id=none',str(D/'native_acquire.c'),'-o',str(D/'native_acquire.so'),'-lX11'],check=True)
subprocess.run(['gcc','-O2','-Wall','-Wextra','-fPIC','-shared','-Wl,--build-id=none',str(D/'native_flash.c'),'-o',str(D/'native_flash.so'),'-lX11'],check=True)
inc=sysconfig.get_paths()['include']; ext=sysconfig.get_config_var('EXT_SUFFIX')
subprocess.run(['gcc','-O3','-Wall','-Wextra','-fPIC','-shared','-Wl,--build-id=none',f'-I{inc}',str(D/'native_predicate.c'),'-o',str(D/f'native_predicate{ext}')],check=True)

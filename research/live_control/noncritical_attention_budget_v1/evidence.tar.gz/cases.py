def progress(session, program, seq, confidence=0.90, target="T"):
    return {
        "session": session,
        "program_id": program,
        "seq": seq,
        "record_class": "progress_summary",
        "kind": "PROGRESS",
        "target_id": target,
        "first_seq": seq,
        "last_seq": seq,
        "count": 1,
        "worst_confidence": confidence,
        "latest_evidence_id": f"{session}-{program}-ev-{seq}",
    }

def critical(session, program, seq, kind):
    return {
        "session": session,
        "program_id": program,
        "seq": seq,
        "record_class": "critical",
        "kind": kind,
        "event_id": f"{session}-{program}-{kind.lower()}-{seq}",
    }

def terminal(session, program, seq, kind="GOAL_REACHED"):
    return {
        "session": session,
        "program_id": program,
        "seq": seq,
        "record_class": "terminal",
        "kind": kind,
        "event_id": f"{session}-{program}-{kind.lower()}-{seq}",
    }

CASES = {
    "below_budget": [progress("A","P",1), progress("A","P",2)],
    "noncritical_over_budget": [progress("A","P",1), progress("A","P",2), progress("A","P",3)],
    "critical_after_budget": [progress("A","P",1), progress("A","P",2), critical("A","P",3,"TARGET_LOST")],
    "derived_needs_decision_after_budget": [progress("A","P",1), progress("A","P",2), progress("A","P",3,0.64)],
    "critical_pair_after_budget": [progress("A","P",1), progress("A","P",2), critical("A","P",3,"TARGET_LOST"), critical("A","P",4,"LEASE_EXPIRED")],
    "goal_terminal_after_budget": [progress("A","P",1), progress("A","P",2), terminal("A","P",3)],
    "cross_session": [
        progress("A","P",1), progress("A","P",2),
        progress("B","P",1),
        critical("A","P",3,"TARGET_LOST"),
        progress("B","P",2), progress("B","P",3),
    ],
}

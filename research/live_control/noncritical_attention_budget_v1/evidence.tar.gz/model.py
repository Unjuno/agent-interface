from copy import deepcopy

NONCRITICAL_LIMIT = 2
CONFIDENCE_THRESHOLD = 0.70
CRITICAL_KINDS = {"TARGET_LOST", "FOCUS_LOST", "LEASE_EXPIRED"}
TERMINAL_KINDS = {"GOAL_REACHED", "TERMINAL"}

class ContractError(ValueError):
    pass

def _validate_record(r):
    required = {"session", "program_id", "seq", "record_class", "kind"}
    if not isinstance(r, dict) or not required.issubset(r):
        raise ContractError("MALFORMED_RECORD")
    if not isinstance(r["session"], str) or not r["session"]:
        raise ContractError("MALFORMED_SCOPE")
    if not isinstance(r["program_id"], str) or not r["program_id"]:
        raise ContractError("MALFORMED_SCOPE")
    if not isinstance(r["seq"], int) or r["seq"] <= 0:
        raise ContractError("MALFORMED_SEQ")
    rc = r["record_class"]
    if rc == "progress_summary":
        if r["kind"] != "PROGRESS":
            raise ContractError("MALFORMED_PROGRESS_KIND")
        w = r.get("worst_confidence")
        if not isinstance(w, (int, float)) or isinstance(w, bool) or not (0.0 <= float(w) <= 1.0):
            raise ContractError("MALFORMED_CONFIDENCE")
        for key in ("first_seq", "last_seq", "count", "latest_evidence_id"):
            if key not in r:
                raise ContractError("MALFORMED_PROGRESS_SUMMARY")
    elif rc == "critical":
        if r["kind"] not in CRITICAL_KINDS:
            raise ContractError("UNKNOWN_CRITICAL_KIND")
    elif rc == "terminal":
        if r["kind"] not in TERMINAL_KINDS:
            raise ContractError("UNKNOWN_TERMINAL_KIND")
    else:
        raise ContractError("UNKNOWN_RECORD_CLASS")


def classify(r):
    _validate_record(r)
    if r["record_class"] == "progress_summary":
        if float(r["worst_confidence"]) < CONFIDENCE_THRESHOLD:
            return "required", "NEEDS_DECISION"
        return "noncritical", "PROGRESS"
    if r["record_class"] == "critical":
        return "required", r["kind"]
    return "required", r["kind"]


def _scope_state():
    return {
        "last_seq": 0,
        "noncritical_delivered_count": 0,
        "all_delivered_count": 0,
        "latest_noncritical": None,
        "delivered": [],
        "suppressed": [],
    }


def _interrupt(record, delivery_kind):
    out = deepcopy(record)
    out["delivery_kind"] = delivery_kind
    return out


def schedule(records, policy):
    if policy not in {"budget_all_interrupts", "noncritical_only_budget"}:
        raise ContractError("UNKNOWN_POLICY")
    scopes = {}
    for record in records:
        category, delivery_kind = classify(record)
        key = (record["session"], record["program_id"])
        st = scopes.setdefault(key, _scope_state())
        if record["seq"] <= st["last_seq"]:
            raise ContractError("NON_MONOTONIC_SEQ")
        st["last_seq"] = record["seq"]

        if category == "noncritical":
            st["latest_noncritical"] = deepcopy(record)

        item = _interrupt(record, delivery_kind)
        if policy == "budget_all_interrupts":
            if st["all_delivered_count"] < NONCRITICAL_LIMIT:
                st["delivered"].append(item)
                st["all_delivered_count"] += 1
                if category == "noncritical":
                    st["noncritical_delivered_count"] += 1
            else:
                st["suppressed"].append(item)
            continue

        # Candidate: only ordinary noncritical interrupts consume the budget.
        if category == "noncritical":
            if st["noncritical_delivered_count"] < NONCRITICAL_LIMIT:
                st["delivered"].append(item)
                st["noncritical_delivered_count"] += 1
            else:
                st["suppressed"].append(item)
        else:
            st["delivered"].append(item)

    # JSON-friendly scope keys.
    return {
        f"{session}|{program}": deepcopy(st)
        for (session, program), st in scopes.items()
    }


def delivered_kinds(scope_state):
    return [x["delivery_kind"] for x in scope_state["delivered"]]

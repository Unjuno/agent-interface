import unittest
from copy import deepcopy
from model import schedule, ContractError
from cases import progress, critical, CASES

class AttentionBudgetTests(unittest.TestCase):
    def test_below_budget(self):
        s = schedule(CASES["below_budget"], "noncritical_only_budget")["A|P"]
        self.assertEqual(len(s["delivered"]), 2)
        self.assertEqual(s["noncritical_delivered_count"], 2)

    def test_over_budget_latest_retained(self):
        s = schedule(CASES["noncritical_over_budget"], "noncritical_only_budget")["A|P"]
        self.assertEqual(len(s["delivered"]), 2)
        self.assertEqual(s["latest_noncritical"]["seq"], 3)
        self.assertEqual(len(s["suppressed"]), 1)

    def test_critical_breakthrough(self):
        s = schedule(CASES["critical_after_budget"], "noncritical_only_budget")["A|P"]
        self.assertEqual([x["delivery_kind"] for x in s["delivered"]], ["PROGRESS","PROGRESS","TARGET_LOST"])
        self.assertEqual(s["noncritical_delivered_count"], 2)

    def test_baseline_suppresses_critical(self):
        s = schedule(CASES["critical_after_budget"], "budget_all_interrupts")["A|P"]
        self.assertEqual([x["delivery_kind"] for x in s["delivered"]], ["PROGRESS","PROGRESS"])
        self.assertEqual(s["suppressed"][0]["delivery_kind"], "TARGET_LOST")

    def test_needs_decision_breakthrough(self):
        s = schedule(CASES["derived_needs_decision_after_budget"], "noncritical_only_budget")["A|P"]
        self.assertEqual(s["delivered"][-1]["delivery_kind"], "NEEDS_DECISION")
        self.assertEqual(s["noncritical_delivered_count"], 2)

    def test_critical_pair_order(self):
        s = schedule(CASES["critical_pair_after_budget"], "noncritical_only_budget")["A|P"]
        self.assertEqual([x["delivery_kind"] for x in s["delivered"]][-2:], ["TARGET_LOST","LEASE_EXPIRED"])

    def test_cross_session_isolated(self):
        scopes = schedule(CASES["cross_session"], "noncritical_only_budget")
        self.assertEqual(scopes["A|P"]["noncritical_delivered_count"], 2)
        self.assertEqual(scopes["B|P"]["noncritical_delivered_count"], 2)
        self.assertEqual(scopes["B|P"]["latest_noncritical"]["seq"], 3)

    def test_program_scope_isolated(self):
        recs = [progress("A","P1",1), progress("A","P1",2), progress("A","P1",3), progress("A","P2",1)]
        scopes = schedule(recs, "noncritical_only_budget")
        self.assertEqual(scopes["A|P1"]["noncritical_delivered_count"], 2)
        self.assertEqual(scopes["A|P2"]["noncritical_delivered_count"], 1)

    def test_non_monotonic_rejected(self):
        recs = [progress("A","P",2), progress("A","P",1)]
        with self.assertRaisesRegex(ContractError, "NON_MONOTONIC_SEQ"):
            schedule(recs, "noncritical_only_budget")

    def test_malformed_class_rejected(self):
        r = progress("A","P",1); r["record_class"] = "mystery"
        with self.assertRaisesRegex(ContractError, "UNKNOWN_RECORD_CLASS"):
            schedule([r], "noncritical_only_budget")

if __name__ == "__main__":
    unittest.main()

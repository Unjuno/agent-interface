import json, sys
with open("result.json", encoding="utf-8") as f:
    r = json.load(f)
assert r["decision"] == "PASS_NONCRITICAL_ATTENTION_BUDGET_SCOPED"
assert r["formal_reruns"] == 0
assert all(r["gates"].values())
assert r["summary"]["candidate_over_budget_delivered_noncritical"] == 2
assert r["summary"]["candidate_over_budget_latest_noncritical_seq"] == 3
assert r["summary"]["candidate_derived_needs_decision_delivered"] is True
assert r["summary"]["cross_session_A_count"] == 2
assert r["summary"]["cross_session_B_count"] == 2
assert len(r["summary"]["baseline_suppressed_required_interrupts"]) >= 1
print("PASS_VERIFY")

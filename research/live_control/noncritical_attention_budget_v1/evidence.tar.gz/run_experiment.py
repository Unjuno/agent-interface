import json
from model import schedule
from cases import CASES

POLICIES = ["budget_all_interrupts", "noncritical_only_budget"]
results = {}
for name, records in CASES.items():
    results[name] = {p: schedule(records, p) for p in POLICIES}

cand = "noncritical_only_budget"
base = "budget_all_interrupts"

def scope(case, policy, key="A|P"):
    return results[case][policy][key]

def kinds(st):
    return [x["delivery_kind"] for x in st["delivered"]]

def critical_identity(st):
    return [(x.get("event_id"), x["delivery_kind"], x["seq"]) for x in st["delivered"] if x["delivery_kind"] != "PROGRESS"]

baseline_suppressed_required = []
for case in ("critical_after_budget", "derived_needs_decision_after_budget", "critical_pair_after_budget", "goal_terminal_after_budget"):
    baseline_suppressed_required += [x["delivery_kind"] for x in scope(case, base)["suppressed"] if x["delivery_kind"] != "PROGRESS"]

candidate_required_expected = {
    "critical_after_budget": ["TARGET_LOST"],
    "derived_needs_decision_after_budget": ["NEEDS_DECISION"],
    "critical_pair_after_budget": ["TARGET_LOST", "LEASE_EXPIRED"],
    "goal_terminal_after_budget": ["GOAL_REACHED"],
}

all_candidate_required_ok = True
for case, expected in candidate_required_expected.items():
    delivered_required = [k for k in kinds(scope(case,cand)) if k != "PROGRESS"]
    all_candidate_required_ok &= delivered_required == expected

pair_candidate = scope("critical_pair_after_budget", cand)
pair_expected_identity = [
    ("A-P-target_lost-3", "TARGET_LOST", 3),
    ("A-P-lease_expired-4", "LEASE_EXPIRED", 4),
]

cross = results["cross_session"][cand]

gates = {
    "baseline_suppresses_required": len(baseline_suppressed_required) >= 1,
    "candidate_noncritical_cap_two": all(scope(c,cand)["noncritical_delivered_count"] <= 2 for c in CASES if "A|P" in results[c][cand]),
    "candidate_latest_suppressed_retained": scope("noncritical_over_budget",cand)["latest_noncritical"]["seq"] == 3 and len(scope("noncritical_over_budget",cand)["suppressed"]) == 1,
    "candidate_all_required_break_through": bool(all_candidate_required_ok),
    "critical_does_not_consume_budget": scope("critical_pair_after_budget",cand)["noncritical_delivered_count"] == 2,
    "critical_identity_order_exact": critical_identity(pair_candidate) == pair_expected_identity,
    "derived_needs_decision_breaks_through": kinds(scope("derived_needs_decision_after_budget",cand))[-1] == "NEEDS_DECISION",
    "cross_session_isolated": cross["A|P"]["noncritical_delivered_count"] == 2 and cross["B|P"]["noncritical_delivered_count"] == 2 and cross["B|P"]["latest_noncritical"]["seq"] == 3,
}

decision = "PASS_NONCRITICAL_ATTENTION_BUDGET_SCOPED" if all(gates.values()) else "FAIL_NONCRITICAL_ATTENTION_BUDGET"
summary = {
    "task": "EVENT-NONCRITICAL-ATTENTION-BUDGET-20260917-003",
    "decision": decision,
    "budget": 2,
    "formal_reruns": 0,
    "gates": gates,
    "summary": {
        "baseline_suppressed_required_interrupts": baseline_suppressed_required,
        "candidate_over_budget_delivered_noncritical": scope("noncritical_over_budget",cand)["noncritical_delivered_count"],
        "candidate_over_budget_latest_noncritical_seq": scope("noncritical_over_budget",cand)["latest_noncritical"]["seq"],
        "candidate_critical_pair": critical_identity(pair_candidate),
        "candidate_derived_needs_decision_delivered": kinds(scope("derived_needs_decision_after_budget",cand))[-1] == "NEEDS_DECISION",
        "cross_session_A_count": cross["A|P"]["noncritical_delivered_count"],
        "cross_session_B_count": cross["B|P"]["noncritical_delivered_count"],
    },
    "cases": results,
}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(summary, f, sort_keys=True, indent=2)
print(decision)

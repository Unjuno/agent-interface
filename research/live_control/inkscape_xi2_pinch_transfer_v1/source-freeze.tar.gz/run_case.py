#!/usr/bin/env python3
from __future__ import annotations
import argparse, ctypes as C, hashlib, json, os, signal, socket, struct, subprocess, time
from pathlib import Path
from Xlib import X, XK, display as xdisplay
from Xlib.ext import xtest
from PIL import Image
MAXV=64
class Header(C.Structure): _fields_=[('length',C.c_uint32),('type',C.c_int)]
class ClientVersion(C.Structure): _fields_=[('header',Header),('major',C.c_uint16),('minor',C.c_uint16)]
class Val(C.Structure): _fields_=[('has_unaccelerated',C.c_uint32),('mask',C.c_uint8*8),('valuators',C.c_double*MAXV),('unaccelerated',C.c_double*MAXV)]
class Touch(C.Structure): _fields_=[('header',Header),('touchid',C.c_uint32),('touch_type',C.c_uint32),('valuators',Val)]
class Wait(C.Structure): _fields_=[('header',Header)]
class Adapter:
    def __init__(self,p):
        self.s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM); self.s.connect(str(p)); self.active={}; self.trace=[]
        cv=ClientVersion(); cv.header.length=C.sizeof(cv); cv.header.type=0; cv.major=cv.minor=1
        self.s.sendall(bytes(cv)); assert struct.unpack('IIHH',self.s.recv(12))==(12,0,1,1)
    def sync(self):
        e=Wait(); e.header.length=C.sizeof(e); e.header.type=1; self.s.sendall(bytes(e)); assert struct.unpack('II',self.s.recv(8))==(8,1)
    def send(self,tid,typ,x,y):
        e=Touch(); e.header.length=C.sizeof(e); e.header.type=6; e.touchid=tid; e.touch_type=typ
        e.valuators.mask[0]=(1<<0)|(1<<1)|(1<<4); e.valuators.valuators[0]=x; e.valuators.valuators[1]=y; e.valuators.valuators[4]=1000.
        self.s.sendall(bytes(e)); self.sync(); k={18:'begin',19:'update',20:'end'}[typ]
        if typ in (18,19): self.active[tid]=[x,y]
        elif typ==20: self.active.pop(tid,None)
        self.trace.append({'kind':k,'touch_id':tid,'x':x,'y':y,'t_ns':time.monotonic_ns()})
    def close(self): self.s.close()

def screenshot(d,path):
    r=d.screen().root; g=r.get_geometry(); raw=r.get_image(0,0,g.width,g.height,X.ZPixmap,0xffffffff)
    im=Image.frombytes('RGB',(g.width,g.height),raw.data,'raw','BGRX'); im.save(path); return im

def largest_red_component(im):
    w,h=im.size; mask=bytearray(w*h)
    for y in range(100,h-20):
        for x in range(20,w-20):
            r,g,b=im.getpixel((x,y))
            if r>=150 and r>=g+70 and r>=b+70 and g<160 and b<160: mask[y*w+x]=1
    seen=bytearray(w*h); best=None
    for y in range(100,h-20):
        for x in range(20,w-20):
            i=y*w+x
            if not mask[i] or seen[i]: continue
            q=[i]; seen[i]=1; n=0; minx=maxx=x; miny=maxy=y
            for j in q:
                yy,jx=divmod(j,w); n+=1; minx=min(minx,jx); maxx=max(maxx,jx); miny=min(miny,yy); maxy=max(maxy,yy)
                for k in (j-1,j+1,j-w,j+w):
                    if 0<=k<w*h and mask[k] and not seen[k]: seen[k]=1; q.append(k)
            cand=[minx,miny,maxx+1,maxy+1,n]
            if best is None or n>best[4]: best=cand
    return best

def walk(d,w=None):
    if w is None:w=d.screen().root
    out=[]
    try:
        name=w.get_wm_name()
        if name: out.append((w,name))
        for c in w.query_tree().children: out.extend(walk(d,c))
    except Exception: pass
    return out

def send_key(d,w,key):
    w.set_input_focus(X.RevertToParent,X.CurrentTime); d.sync(); time.sleep(.04)
    code=d.keysym_to_keycode(XK.string_to_keysym(key)); xtest.fake_input(d,X.KeyPress,code); xtest.fake_input(d,X.KeyRelease,code); d.sync(); time.sleep(.08)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--out',required=True); ap.add_argument('--display',type=int,required=True); ap.add_argument('--scenario',choices=['two_contact_pinch','single_contact_move','no_input'],required=True); ap.add_argument('--case-id',required=True); a=ap.parse_args()
    out=Path(a.out); out.mkdir(parents=True,exist_ok=False); here=Path(__file__).resolve().parent; svg=here/'test.svg'
    disp=f':{a.display}'; sock=out/'inputtest.sock'; auth=out/'Xauthority'; auth.touch(); conf=out/'xorg.conf'
    conf.write_text(f'''Section "ServerFlags"\n Option "AutoAddDevices" "false"\n Option "AllowMouseOpenFail" "true"\nEndSection\nSection "ServerLayout"\n Identifier "Layout0"\n Screen 0 "Screen0"\n InputDevice "TestTouch"\nEndSection\nSection "Device"\n Identifier "Dummy0"\n Driver "dummy"\n VideoRam 256000\nEndSection\nSection "Monitor"\n Identifier "Monitor0"\n HorizSync 5.0-1000.0\n VertRefresh 5.0-200.0\n Modeline "1024x768" 65.0 1024 1048 1184 1344 768 771 777 806\nEndSection\nSection "Screen"\n Identifier "Screen0"\n Device "Dummy0"\n Monitor "Monitor0"\n DefaultDepth 24\n SubSection "Display"\n  Depth 24\n  Modes "1024x768"\n EndSubSection\nEndSection\nSection "InputDevice"\n Identifier "TestTouch"\n Driver "inputtest"\n Option "SocketPath" "{sock}"\n Option "DeviceType" "Touch"\n Option "TouchCount" "4"\nEndSection\n''')
    env=os.environ.copy(); env.update(DISPLAY=disp,XAUTHORITY=str(auth)); os.environ.update(DISPLAY=disp,XAUTHORITY=str(auth)); procs=[]
    def spawn(name,args):
        fo=open(out/(name+'.out'),'wb');fe=open(out/(name+'.err'),'wb');p=subprocess.Popen(args,env=env,stdout=fo,stderr=fe,start_new_session=True);procs.append((p,fo,fe));return p
    adapter=None; d=None
    try:
        spawn('xorg',['Xorg',disp,'-config',str(conf),'-noreset','-nolisten','tcp','-logfile',str(out/'Xorg.log'),'-retro'])
        for _ in range(500):
            if Path(f'/tmp/.X11-unix/X{a.display}').exists() and sock.exists(): break
            time.sleep(.01)
        d=xdisplay.Display(disp); bh=hashlib.sha256(svg.read_bytes()).hexdigest(); spawn('inkscape',['inkscape',str(svg)])
        doc=None
        for _ in range(140):
            for w,name in walk(d):
                if name and name.endswith(' - Inkscape') and 'test.svg' in name: doc=w; break
            if doc: break
            time.sleep(.05)
        if not doc: raise RuntimeError('document_window_missing')
        doc.configure(x=0,y=0,width=1024,height=768);d.sync();time.sleep(.75);send_key(d,doc,'4');time.sleep(.65)
        pre=screenshot(d,out/'pre.png');bb=largest_red_component(pre)
        if not bb or bb[4]<4000: raise RuntimeError(f'pre_component_unstable:{bb}')
        cx=(bb[0]+bb[2])/2; cy=(bb[1]+bb[3])/2; width=bb[2]-bb[0]
        sx1=cx-width*.38; sx2=cx+width*.38; ex1=cx-width*.16; ex2=cx+width*.16
        nx=lambda x:max(0,min(65535,x/1024*65535)); ny=lambda y:max(0,min(65535,y/768*65535))
        adapter=Adapter(sock)
        if a.scenario=='two_contact_pinch':
            adapter.send(101,18,nx(sx1),ny(cy));time.sleep(.03);adapter.send(202,18,nx(sx2),ny(cy));time.sleep(.08)
            adapter.send(101,19,nx(ex1),ny(cy));time.sleep(.03);adapter.send(202,19,nx(ex2),ny(cy));time.sleep(.12)
            adapter.send(101,20,nx(ex1),ny(cy));time.sleep(.03);adapter.send(202,20,nx(ex2),ny(cy))
        elif a.scenario=='single_contact_move':
            adapter.send(101,18,nx(sx1),ny(cy));time.sleep(.08);adapter.send(101,19,nx(ex1),ny(cy));time.sleep(.12);adapter.send(101,20,nx(ex1),ny(cy))
        else:
            time.sleep(.26)
        time.sleep(.65);post=screenshot(d,out/'post.png');bb2=largest_red_component(post); ah=hashlib.sha256(svg.read_bytes()).hexdigest()
        if not bb2 or bb2[4]<2000: raise RuntimeError(f'post_component_unstable:{bb2}')
        ratio=(bb2[2]-bb2[0])/(bb[2]-bb[0]); pointer_mask=int(d.screen().root.query_pointer().mask)
        result={'schema':'inkscape-xi2-pinch-transfer-case-v1','case_id':a.case_id,'scenario':a.scenario,'pre_bbox':bb,'post_bbox':bb2,'width_ratio':ratio,'svg_unchanged':bh==ah,'svg_sha':bh,'adapter_trace':adapter.trace,'adapter_active':sorted(adapter.active),'button1_neutral':(pointer_mask & int(X.Button1Mask))==0,'window_geometry':[doc.get_geometry().width,doc.get_geometry().height]}
        if a.scenario=='two_contact_pinch': ok=(len(adapter.trace)==6 and ratio<=.65)
        else: ok=(ratio>=.85 and ratio<=1.15)
        ok=ok and result['svg_unchanged'] and not result['adapter_active'] and result['button1_neutral']
        result['pass']=bool(ok);(out/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps({'case':a.case_id,'scenario':a.scenario,'ratio':ratio,'pass':ok},sort_keys=True))
    finally:
        if adapter:
            try: adapter.close()
            except: pass
        if d:
            try:d.close()
            except:pass
        for p,fo,fe in reversed(procs):
            try:
                if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)
            except:pass
        time.sleep(.10)
        for p,fo,fe in reversed(procs):
            try:
                if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
            except:pass
            try:fo.close();fe.close()
            except:pass
if __name__=='__main__': main()

#!/usr/bin/env python3
import argparse,hashlib,json
from pathlib import Path
from PIL import Image

def bbox(im):
 w,h=im.size; pts=[]
 for y in range(100,h-20):
  for x in range(20,w-20):
   r,g,b=im.getpixel((x,y))
   if r>=150 and r>=g+70 and r>=b+70 and g<160 and b<160: pts.append((x,y))
 # independent component extraction via set flood-fill
 s=set(pts); comps=[]
 while s:
  seed=s.pop(); stack=[seed]; c=[seed]
  while stack:
   x,y=stack.pop()
   for q in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)):
    if q in s:s.remove(q);stack.append(q);c.append(q)
  comps.append(c)
 c=max(comps,key=len);xs=[p[0] for p in c];ys=[p[1] for p in c]
 return [min(xs),min(ys),max(xs)+1,max(ys)+1,len(c)]

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);a=ap.parse_args();root=Path(a.root);errs=[];rows=[]
 for d in sorted(root.glob('case-*')):
  rp=d/'result.json'
  if not rp.exists():errs.append(f'missing_result:{d.name}');continue
  r=json.loads(rp.read_text());b1=bbox(Image.open(d/'pre.png').convert('RGB'));b2=bbox(Image.open(d/'post.png').convert('RGB'));ratio=(b2[2]-b2[0])/(b1[2]-b1[0])
  scenario=r['scenario'];expected=(ratio<=.65) if scenario=='two_contact_pinch' else (.85<=ratio<=1.15)
  good=expected and r['svg_unchanged'] and not r['adapter_active'] and r['button1_neutral']
  # Trace contract independent of runner pass bit.
  kinds=[x['kind'] for x in r['adapter_trace']]
  if scenario=='two_contact_pinch':good=good and kinds==['begin','begin','update','update','end','end'] and len({x['touch_id'] for x in r['adapter_trace'] if x['kind']=='begin'})==2
  elif scenario=='single_contact_move':good=good and kinds==['begin','update','end']
  else:good=good and kinds==[]
  if not good:errs.append(f'case_fail:{d.name}:{scenario}:{ratio}')
  rows.append({'case_id':r['case_id'],'scenario':scenario,'ratio':ratio,'pass':good,'pre_bbox':b1,'post_bbox':b2,'result_sha256':hashlib.sha256(rp.read_bytes()).hexdigest()})
 counts={}
 for x in rows: counts[x['scenario']]=counts.get(x['scenario'],0)+1
 if counts!={'no_input':4,'single_contact_move':4,'two_contact_pinch':4}:errs.append(f'counts:{counts}')
 out={'schema':'inkscape-xi2-pinch-transfer-audit-v1','decision':'PASS_INKSCAPE_XI2_PINCH_TRANSFER_SCOPED' if not errs else 'FAIL_INKSCAPE_XI2_PINCH_TRANSFER','errors':errs,'counts':counts,'rows':rows}
 (root/'audit.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps({'decision':out['decision'],'errors':len(errs),'counts':counts},sort_keys=True))
if __name__=='__main__':main()

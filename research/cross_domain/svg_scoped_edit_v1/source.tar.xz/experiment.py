"""Native Inkscape scoped-edit experiment. Generated data only; no remote writes."""
from __future__ import annotations
import argparse, hashlib, json, os, random, shutil, subprocess, time
from pathlib import Path
from lxml import etree as X

NS = 'http://www.w3.org/2000/svg'
OLD, NEW = '#ff0000', '#008000'
POLICIES_A = ['stale_document', 'whole_file_guard', 'scoped_current']
SCENARIOS_A = ['stable', 'other_move', 'target_move', 'fill_conflict', 'late_ref']

def sha(b): return hashlib.sha256(b).hexdigest()
def save(p, obj): p.write_text(json.dumps(obj, indent=2, sort_keys=True)+'\n')
def environment(home):
    home.mkdir(parents=True, exist_ok=True)
    return {**os.environ, 'HOME':str(home), 'LC_ALL':'C.UTF-8', 'LANG':'C.UTF-8',
            'GIT_CONFIG_NOSYSTEM':'1', 'GIT_CONFIG_GLOBAL':'/dev/null',
            'GIT_AUTHOR_NAME':'fixture', 'GIT_COMMITTER_NAME':'fixture',
            'GIT_AUTHOR_EMAIL':'fixture@example.invalid', 'GIT_COMMITTER_EMAIL':'fixture@example.invalid',
            'GIT_AUTHOR_DATE':'2026-09-16T00:00:00Z','GIT_COMMITTER_DATE':'2026-09-16T00:00:00Z',
            'INKSCAPE_PROFILE_DIR':str(home/'inkscape')}

class Native:
    def __init__(self, root):
        self.root=root; self.log=[]; self.env=environment(root/'home')
    def call(self, argv, data=None, allowed=(0,)):
        start=time.perf_counter_ns()
        p=subprocess.run(list(map(str,argv)),input=data,capture_output=True,env=self.env,timeout=30)
        end=time.perf_counter_ns()
        rec={'argv':list(map(str,argv)),'start_ns':start,'end_ns':end,'rc':p.returncode,
             'stdin_sha256':sha(data) if data is not None else None,
             'stdout':p.stdout.decode('utf-8','replace'),'stderr':p.stderr.decode('utf-8','replace')}
        self.log.append(rec)
        save(self.root/'commands.json',self.log)
        if p.returncode not in allowed: raise RuntimeError(rec)
        return p
    def git(self,*args,data=None,allowed=(0,)):
        return self.call(['git','--git-dir',self.root/'repo.git',*args],data,allowed)
    def text(self,*args): return self.git(*args).stdout.decode().strip()
    def commit(self, files, parent=None, message='fixture'):
        entries=[]
        for name, body in sorted(files.items()):
            oid=self.git('hash-object','-w','--stdin',data=body).stdout.decode().strip()
            entries.append(f'100644 blob {oid}\t{name}\n')
        tree=self.git('mktree',data=''.join(entries).encode()).stdout.decode().strip()
        args=['commit-tree',tree,'-m',message]
        if parent: args+=['-p',parent]
        return self.text(*args)

def parse(data):
    return X.fromstring(data, X.XMLParser(resolve_entities=False, no_network=True))
def serial(root): return X.tostring(root,encoding='utf-8',xml_declaration=True)
def fixture(rep):
    return (f'<svg xmlns="{NS}" id="svg1" version="1.1" width="320" height="200" viewBox="0 0 320 200">'
            '<defs id="defs1"/>'
            '<rect id="background" x="0" y="0" width="320" height="200" fill="#ffffff"/>'
            f'<rect id="target" x="{20+rep*2}" y="40" width="70" height="60" fill="{OLD}"/>'
            '<rect id="other" x="180" y="40" width="70" height="60" fill="#0000ff"/>'
            '</svg>').encode()
def target(root):
    targets=root.xpath('//*[@id="target"]')
    if len(targets)!=1 or targets[0].tag!=f'{{{NS}}}rect': raise ValueError('target_identity')
    return targets[0]
def mutate(data, scenario):
    root=parse(data)
    if scenario=='other_move': root.xpath('//*[@id="other"]')[0].set('y','110')
    elif scenario=='target_move': target(root).set('y','110')
    elif scenario=='fill_conflict': target(root).set('fill','#ffff00')
    elif scenario=='inline_style': target(root).set('style','fill:#0000ff')
    elif scenario=='stylesheet':
        style=X.Element(f'{{{NS}}}style', id='paint_rules'); style.text='#target { fill: #0000ff; }'
        root.insert(1,style)
    elif scenario not in ('stable','late_ref'): raise ValueError(scenario)
    return serial(root)

def guard(base,current,policy):
    root=parse(current)
    try: t=target(root)
    except ValueError: return False,'target_identity'
    if t.get('fill')!=target(parse(base)).get('fill'): return False,'fill_conflict'
    if policy=='whole_file_guard' and current!=base: return False,'whole_file_changed'
    if policy=='paint_context':
        # Restricted semantic contract. No silent inference through CSS, resources or inheritance.
        for e in root.iter():
            if e.tag not in {f'{{{NS}}}svg',f'{{{NS}}}defs',f'{{{NS}}}rect'}: return False,'unsupported_paint_context'
            if any(k in e.attrib for k in ('style','class','filter','mask','clip-path','opacity','fill-opacity')):
                return False,'unsupported_paint_context'
    return True,'eligible'

def one(case, out):
    out.mkdir(parents=True,exist_ok=False)
    n=Native(out)
    n.call(['git','init','--bare','-q',out/'repo.git'])
    n.git('config','core.logAllRefUpdates','true')
    base=serial(parse(fixture(case['rep'])))
    current=base if case['scenario'] in ('stable','late_ref') else mutate(base,case['scenario'])
    side=b'preserve this repository entry\n'
    a=n.commit({'art.svg':base,'notes.txt':side},message='plan')
    n.git('update-ref','-m','initial','refs/heads/target',a)
    x=a if current==base else n.commit({'art.svg':current,'notes.txt':side},a,'concurrent document edit')
    if x!=a: n.git('update-ref','-m','concurrent','refs/heads/target',x,a)
    (out/'base.svg').write_bytes(base);(out/'current.svg').write_bytes(current)
    start=time.perf_counter_ns()
    valid,reason=guard(base,current,case['policy'])
    checked=time.perf_counter_ns()
    candidate=None; rc=None
    before=x
    if valid:
        source=base if case['policy']=='stale_document' else current
        (out/'stage-input.svg').write_bytes(source)
        actions=f'select-by-id:target;object-set-attribute:fill,{NEW};export-type:svg;export-filename:{out / "stage-output.svg"};export-do'
        n.call(['inkscape',out/'stage-input.svg','--batch-process','--export-plain-svg','--actions='+actions])
        stage=(out/'stage-output.svg').read_bytes()
        candidate=n.commit({'art.svg':stage,'notes.txt':side},x,'scoped native edit')
        if case['scenario']=='late_ref':
            before=n.commit({'art.svg':current,'notes.txt':b'later independent edit\n'},x,'after validation')
            n.git('update-ref','-m','late','refs/heads/target',before,x)
        p=n.git('update-ref','-m','publish','refs/heads/target',candidate,x,allowed=(0,128))
        rc=p.returncode;reason='published' if rc==0 else 'ref_conflict'
    end=time.perf_counter_ns()
    final=n.text('rev-parse','refs/heads/target')
    final_svg=n.git('show',f'{final}:art.svg').stdout
    (out/'final.svg').write_bytes(final_svg)
    n.call(['inkscape',out/'final.svg','--export-type=png','--export-filename='+str(out/'final.png')])
    row={**case,'schema':'svg-scoped-case-v1','base_oid':a,'checked_oid':x,'prepublish_oid':before,
         'candidate_oid':candidate,'final_oid':final,'eligible':valid,'reason':reason,'publish_rc':rc,
         'start_ns':start,'checked_ns':checked,'end_ns':end,
         'base_sha256':sha(base),'current_sha256':sha(current),'final_sha256':sha(final_svg)}
    save(out/'result.json',row)
    return row

def plan(rung):
    policies=POLICIES_A if rung=='A' else ['raw_attribute','paint_context']
    scenarios=SCENARIOS_A if rung=='A' else ['stable','inline_style','stylesheet']
    cases=[]; rng=random.Random(344916+(rung=='B'))
    for rep in range(1,4):
        block=[{'id':f'{rung}-r{rep}-{p}-{s}','rung':rung,'rep':rep,'policy':p,'scenario':s} for s in scenarios for p in policies]
        rng.shuffle(block); cases+=block
    return {'schema':'svg-scoped-plan-v1','rung':rung,'cases':cases,'no_retries':True,'seed':344916+(rung=='B'),
            'publication_base':'0dd239b7db10831a4e8ac078d3a32d4be6370e3d'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('plan',type=Path);ap.add_argument('out',type=Path);a=ap.parse_args()
    p=json.loads(a.plan.read_text());a.out.mkdir(exist_ok=False,parents=True)
    for name,h in p['sources'].items():
        if sha((a.plan.parent/name).read_bytes())!=h: raise RuntimeError('source drift '+name)
    for c in p['cases']:
        d=a.out/c['id']
        try:
            r=one(c,d)
            # The independent auditor distinguishes known control failures from corruption.
            from audit import audit_case
            v=audit_case(d)
            print(json.dumps({'id':c['id'],'reason':r['reason'],'task_correct':v['task_correct']}),flush=True)
        except Exception as exc:
            save(a.out/'INCOMPLETE.json',{'failed_id':c['id'],'error':repr(exc)})
            raise
    save(a.out/'COMPLETE.json',{'ids':[c['id'] for c in p['cases']]})
if __name__=='__main__':main()

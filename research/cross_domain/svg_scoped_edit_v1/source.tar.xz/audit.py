"""Independent persisted-object/structure/pixel audit; imports no experiment logic."""
from __future__ import annotations
import argparse, copy, hashlib, json, subprocess, xml.etree.ElementTree as E
from pathlib import Path
from PIL import Image
NS='{http://www.w3.org/2000/svg}'
GREEN='#008000'

def sha(b):return hashlib.sha256(b).hexdigest()
def require(c,message):
    if not c:raise AssertionError(message)
def g(d,*args):
    p=subprocess.run(['git','--git-dir',str(d/'repo.git'),*args],capture_output=True,timeout=15)
    require(p.returncode==0, p.stderr.decode(errors='replace'));return p.stdout

def norm(e):
    return (e.tag,tuple(sorted(e.attrib.items())),(e.text or '').strip(),tuple(norm(c) for c in e))
def find(e,id):
    hits=[n for n in e.iter() if n.get('id')==id];require(len(hits)==1,'unique object '+id);return hits[0]
def oracle_pixels(root):
    # Separate tiny rectangle rasterizer, not Inkscape or candidate code.
    require(root.tag==NS+'svg','root namespace')
    w,h=int(root.get('width')),int(root.get('height'))
    require((w,h)==(320,200),'canvas')
    pixels=bytearray(w*h*4)
    styles=[(x.text or '').strip() for x in root if x.tag==NS+'style']
    require(all(s=='#target { fill: #0000ff; }' for s in styles),'unexpected stylesheet')
    for e in root:
        if e.tag in (NS+'defs',NS+'style'):continue
        require(e.tag==NS+'rect','unsupported renderer element')
        color=e.get('fill')
        if e.get('id')=='target' and styles:color='#0000ff'
        if e.get('style'):
            require(e.get('style')=='fill:#0000ff','unexpected inline style');color='#0000ff'
        require(color in ('#ffffff','#ff0000','#0000ff','#008000','#ffff00'),'color')
        rgb=bytes.fromhex(color[1:])+b'\xff'
        x,y,rw,rh=[int(e.get(k)) for k in ('x','y','width','height')]
        require(x>=0 and y>=0 and x+rw<=w and y+rh<=h,'rectangle bounds')
        for iy in range(y,y+rh):
            lo=(iy*w+x)*4;pixels[lo:lo+rw*4]=rgb*rw
    return bytes(pixels)

def policy_expected(r,base,current):
    s,p=r['scenario'],r['policy']
    if s=='fill_conflict':return False,'fill_conflict'
    if p=='whole_file_guard' and base!=current:return False,'whole_file_changed'
    if p=='paint_context' and s in ('inline_style','stylesheet'):return False,'unsupported_paint_context'
    return True,'ref_conflict' if s=='late_ref' else 'published'

def audit_case(d):
    r=json.loads((d/'result.json').read_text())
    for key in ('start_ns','checked_ns','end_ns'):require(type(r[key]) is int,'clock type')
    require(r['start_ns']<=r['checked_ns']<=r['end_ns'],'clock order')
    base,current,final=[g(d,'show',f'{r[key]}:art.svg') for key in ('base_oid','checked_oid','final_oid')]
    for name,data in [('base',base),('current',current),('final',final)]:
        require((d/f'{name}.svg').read_bytes()==data,name+' retained bytes')
        require(sha(data)==r[f'{name}_sha256'],name+' SHA')
    require(g(d,'rev-parse','refs/heads/target').decode().strip()==r['final_oid'],'final ref')
    be,ce,fe=map(E.fromstring,(base,current,final))
    expected_current=copy.deepcopy(be)
    if r['scenario']=='other_move':find(expected_current,'other').set('y','110')
    elif r['scenario']=='target_move':find(expected_current,'target').set('y','110')
    elif r['scenario']=='fill_conflict':find(expected_current,'target').set('fill','#ffff00')
    elif r['scenario']=='inline_style':find(expected_current,'target').set('style','fill:#0000ff')
    elif r['scenario']=='stylesheet':
        st=E.Element(NS+'style',{'id':'paint_rules'});st.text='#target { fill: #0000ff; }';expected_current.insert(1,st)
    else:require(r['scenario'] in ('stable','late_ref'),'scenario')
    require(norm(ce)==norm(expected_current),'scenario mutation')
    eligible,reason=policy_expected(r,base,current)
    require(type(r['eligible']) is bool and r['eligible']==eligible,'eligible receipt')
    require(r['reason']==reason,'reason')
    accepted=reason=='published'
    require((r['publish_rc']==0) if accepted else (r['publish_rc']==128 if reason=='ref_conflict' else r['publish_rc'] is None),'publish result')
    expected_native=copy.deepcopy(be if r['policy']=='stale_document' else ce)
    if eligible:
        find(expected_native,'target').set('fill',GREEN)
        stage=(d/'stage-output.svg').read_bytes()
        require(norm(E.fromstring(stage))==norm(expected_native),'native action scope')
        require(g(d,'show',f'{r["candidate_oid"]}:art.svg')==stage,'candidate stage identity')
        parents=g(d,'cat-file','-p',r['candidate_oid']).decode().splitlines()
        require([l[7:] for l in parents if l.startswith('parent ')]==[r['checked_oid']],'current ancestry')
    else:require(r['candidate_oid'] is None and not (d/'stage-output.svg').exists(),'no candidate on refusal')
    native_final=expected_native if accepted else ce
    require(norm(fe)==norm(native_final),'final structure not policy result')
    require(r['final_oid']==(r['candidate_oid'] if accepted else r['prepublish_oid']),'publication identity')
    entries=g(d,'ls-tree',r['final_oid']).decode().splitlines()
    require(len(entries)==2 and all(e.startswith('100644 blob ') for e in entries),'tree modes')
    require(sorted(e.split('\t')[1] for e in entries)==['art.svg','notes.txt'],'tree membership')
    expected_notes=b'later independent edit\n' if r['scenario']=='late_ref' else b'preserve this repository entry\n'
    require(g(d,'show',f'{r["final_oid"]}:notes.txt')==expected_notes,'other repository entry')
    logs=g(d,'reflog','show','--format=%H %gs','refs/heads/target').decode().splitlines()
    expected_count=1+(r['checked_oid']!=r['base_oid'])+(r['scenario']=='late_ref')+accepted
    require(len(logs)==expected_count and logs[0].split()[0]==r['final_oid'],'reflog')
    cmds=json.loads((d/'commands.json').read_text())
    for cmd in cmds:
        require(type(cmd['start_ns']) is int and type(cmd['end_ns']) is int and cmd['start_ns']<=cmd['end_ns'],'command clocks')
    edits=[c for c in cmds if c['argv'][0]=='inkscape' and '--batch-process' in c['argv']]
    renders=[c for c in cmds if c['argv'][0]=='inkscape' and '--export-type=png' in c['argv']]
    require(len(edits)==int(eligible) and len(renders)==1,'native call count')
    for c in edits+renders:require(c['rc']==0,'native rc')
    if edits:
        actions=[a for a in edits[0]['argv'] if a.startswith('--actions=')]
        require(len(actions)==1 and actions[0].startswith('--actions=select-by-id:target;object-set-attribute:fill,#008000;'),'action intent')
        require((d/'stage-input.svg').read_bytes()==(base if r['policy']=='stale_document' else current),'native input identity')
    pixels=Image.open(d/'final.png').convert('RGBA')
    require(pixels.size==(320,200),'image size')
    actual=pixels.tobytes();require(actual==oracle_pixels(fe),'native render versus independent full raster')
    should_accept=r['scenario'] in ('stable','other_move','target_move')
    task_expected=copy.deepcopy(ce)
    if should_accept:find(task_expected,'target').set('fill',GREEN)
    structural=norm(fe)==norm(task_expected)
    visual=actual==oracle_pixels(task_expected)
    task_correct=(accepted==should_accept and structural and visual)
    return {'id':r['id'],'rung':r['rung'],'policy':r['policy'],'scenario':r['scenario'],'accepted':accepted,
            'reason':reason,'task_correct':task_correct,'structure_correct':structural,'visual_correct':visual,
            'false_reject':should_accept and not accepted,'wrong_write':accepted and not task_correct,
            'native_edit_calls':len(edits),'native_render_calls':len(renders),
            'render_sha256':sha(actual),'native_commands':len(cmds)}

def audit_all(root,plan):
    expected=[c['id'] for c in plan['cases']]
    require(sorted(p.name for p in root.iterdir() if p.is_dir())==sorted(expected),'case membership')
    require(json.loads((root/'COMPLETE.json').read_text())['ids']==expected,'completion ledger')
    rows=[]
    for c in plan['cases']:
        rr=json.loads((root/c['id']/'result.json').read_text())
        require(all(rr[k]==v for k,v in c.items()),'case binding')
        rows.append(audit_case(root/c['id']))
    by={}
    for r in rows:
        b=by.setdefault(r['policy'],{'n':0,'correct':0,'accepted':0,'false_reject':0,'wrong_write':0})
        b['n']+=1
        for k,rk in [('correct','task_correct'),('accepted','accepted'),('false_reject','false_reject'),('wrong_write','wrong_write')]:b[k]+=int(r[rk])
    return {'integrity_pass':True,'cases':len(rows),'by_policy':by,'rows':rows}
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('root',type=Path);a.add_argument('plan',type=Path);a.add_argument('out',type=Path);z=a.parse_args()
    v=audit_all(z.root,json.loads(z.plan.read_text()));z.out.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n');print(json.dumps(v['by_policy'],indent=2))

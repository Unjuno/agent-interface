import copy,json,tempfile,unittest
from pathlib import Path
from experiment import guard,fixture,mutate,serial,parse,one
from audit import audit_case,oracle_pixels

class Contract(unittest.TestCase):
    def setUp(self):self.b=serial(parse(fixture(1)))
    def test_stable(self):self.assertEqual(guard(self.b,self.b,'scoped_current'),(True,'eligible'))
    def test_object_move(self):self.assertTrue(guard(self.b,mutate(self.b,'other_move'),'scoped_current')[0])
    def test_target_move(self):self.assertTrue(guard(self.b,mutate(self.b,'target_move'),'scoped_current')[0])
    def test_fill_conflict(self):self.assertFalse(guard(self.b,mutate(self.b,'fill_conflict'),'scoped_current')[0])
    def test_whole_file(self):self.assertFalse(guard(self.b,mutate(self.b,'other_move'),'whole_file_guard')[0])
    def test_absent(self):self.assertFalse(guard(self.b,self.b.replace(b'id="target"',b'id="other_target"'),'scoped_current')[0])
    def test_duplicate(self):self.assertFalse(guard(self.b,self.b.replace(b'id="other"',b'id="target"'),'scoped_current')[0])
    def test_inline_unsupported(self):self.assertFalse(guard(self.b,mutate(self.b,'inline_style'),'paint_context')[0])
    def test_sheet_unsupported(self):self.assertFalse(guard(self.b,mutate(self.b,'stylesheet'),'paint_context')[0])
    def test_raw_does_not_check_style(self):self.assertTrue(guard(self.b,mutate(self.b,'inline_style'),'raw_attribute')[0])
    def test_native_and_corruptions(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td)/'c';one({'id':'test','rung':'A','rep':1,'policy':'scoped_current','scenario':'other_move'},d)
            self.assertTrue(audit_case(d)['task_correct'])
            rp=d/'result.json';raw=rp.read_bytes();r=json.loads(raw)
            for key,value in [('reason','ref_conflict'),('eligible',False),('final_sha256','bad'),('checked_ns',True),('end_ns',0)]:
                bad=copy.deepcopy(r);bad[key]=value;rp.write_text(json.dumps(bad))
                with self.subTest(key=key),self.assertRaises(AssertionError):audit_case(d)
                rp.write_bytes(raw)
            from PIL import Image
            f=d/'final.png';b=f.read_bytes();im=Image.open(f).convert('RGBA');im.putpixel((0,0),(0,0,0,255));im.save(f)
            with self.assertRaises(AssertionError):audit_case(d)
            f.write_bytes(b)
            with self.assertRaises(FileExistsError):one({'id':'again'},d)
    def test_native_ref_conflict(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td)/'c';one({'id':'test-race','rung':'A','rep':1,'policy':'scoped_current','scenario':'late_ref'},d)
            self.assertTrue(audit_case(d)['task_correct'])
if __name__=='__main__':unittest.main(verbosity=2)

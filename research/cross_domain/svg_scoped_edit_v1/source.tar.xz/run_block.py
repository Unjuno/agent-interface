"""Bounded synchronous supervision; never resumes a consumed case or failed allocation."""
import argparse,json,hashlib
from pathlib import Path
from experiment import one,save
from audit import audit_case

def run(plan_path,root,start,count):
    p=json.loads(plan_path.read_text())
    for name,h in p['sources'].items():
        if hashlib.sha256((plan_path.parent/name).read_bytes()).hexdigest()!=h:raise RuntimeError('source drift '+name)
    root.mkdir(exist_ok=True,parents=True)
    if (root/'INCOMPLETE.json').exists():raise RuntimeError('failed allocation cannot resume')
    cases=p['cases']
    expected={c['id'] for c in cases[:start]}
    actual={d.name for d in root.iterdir() if d.is_dir()}
    if actual!=expected:raise RuntimeError('consumed case set mismatch')
    for c in cases[:start]:
        if not (root/c['id']/'result.json').is_file():raise RuntimeError('incomplete prefix')
    for c in cases[start:start+count]:
        try:
            r=one(c,root/c['id']); v=audit_case(root/c['id'])
            print(json.dumps({'id':c['id'],'reason':r['reason'],'task_correct':v['task_correct']}),flush=True)
        except Exception as ex:
            save(root/'INCOMPLETE.json',{'failed_id':c['id'],'error':repr(ex)});raise
    if start+count>=len(cases):save(root/'COMPLETE.json',{'ids':[c['id'] for c in cases]})
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('plan',type=Path);a.add_argument('root',type=Path);a.add_argument('start',type=int);a.add_argument('count',type=int);z=a.parse_args();run(z.plan,z.root,z.start,z.count)

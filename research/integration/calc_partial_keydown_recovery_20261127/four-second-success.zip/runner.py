"""Single-use isolated Calc partial-entry fault probe; no model calls."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import time
import traceback
import xml.etree.ElementTree as ET

from Xlib import X, display
from PIL import Image
from runtime.cli_v1.mcp_guarded import GuardedSessionOwner
from calc_bounded_observation_v1 import observe_until

OUT = Path('/out')
FIXTURE_SHA = '462beebbcb020ccf49af3cc49520f789a816cc3fb97597cefbd6940ffc26aeb1'
NAMEBOX_SHA = '2e86f3a0f6d87ee4fb4e5ffeb7cfd159d715cb5f6f8177b0ede83784d49088cf'
actors = []
logs = []
owners = []
d = None
result = {'schema': 'calc-partial-entry-fault-v1', 'passed': False, 'model_calls': 0,
          'input_dispatched': False, 'scope': 'test-injected exception after third key-down submission, not arbitrary crash recovery'}


def record(name, obj):
    path = OUT/name
    with path.open('x', encoding='utf-8') as stream:
        json.dump(obj, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())


def spawn(name, args, env):
    stream = (OUT/(name+'.log')).open('xb'); logs.append(stream)
    process = subprocess.Popen(args, env=env, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    actors.append(process)
    return process


def neutral():
    bits = d.query_keymap(); mask = d.screen().root.query_pointer().mask
    buttons = mask & (X.Button1Mask|X.Button2Mask|X.Button3Mask|X.Button4Mask|X.Button5Mask)
    return {'keys_down': [i for i in range(256) if bits[i//8] & (1 << (i%8))], 'buttons_mask': buttons}


def verify_release(value):
    return (type(value) is dict and value.get('verified') is True
            and value.get('keys_down') == [] and value.get('buttons_down') == [])


def ocr_cell(image, label):
    crop = image.crop((230,97,275,119)).resize((450,220), Image.Resampling.NEAREST)
    path = OUT/(label+'.png'); crop.save(path)
    call = subprocess.run(['tesseract',str(path),'stdout','--psm','8','-c','tessedit_char_whitelist=0123456789'],
                          capture_output=True, text=True, timeout=10)
    text = call.stdout.strip()
    row = {'text': text, 'exit_code': call.returncode, 'stderr': call.stderr,
           'crop_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    record(label+'.json',row)
    if call.returncode != 0 or text and re.fullmatch('[0-9]+',text) is None: raise ValueError('cell OCR unavailable')
    return text


def fresh_reference(bridge, alias):
    obs=bridge.observe(); image=bridge.history[obs['sequence']][1]
    ref=bridge.mint_reference(alias,obs['sequence'],[440,28],region_size=(30,14))
    return obs,image,ref



def wait_formula(bridge, label, expected, transitional):
    deadline=time.monotonic_ns()+4_000_000_000
    def read(attempt):
        obs=bridge.observe();image=bridge.history[obs['sequence']][1]
        if hashlib.sha256(image.crop((0,97,42,119)).tobytes()).hexdigest()!=NAMEBOX_SHA:
            raise ValueError('A1 selection changed during observation')
        text=ocr_cell(image,label+'-poll-'+str(attempt))
        return {'sequence':obs['sequence'],'capture_ns':obs['capture_ns'],
                'binding':obs['pointer_binding'],'text':text,'observation':obs}
    accepted,rows=observe_until(read,expected=expected,transitional=transitional,
        deadline_ns=deadline,clock=time.monotonic_ns,pause=time.sleep,max_attempts=8)
    record(label+'-polls.json',{'deadline_ns':deadline,'records':rows,'accepted':accepted is not None})
    if accepted is None or time.monotonic_ns()>=deadline:
        raise ValueError('fresh expected value unavailable before deadline')
    index=rows[-1]['attempt']
    for ext in ('.png','.json'):
        shutil.copyfile(OUT/(label+'-poll-'+str(index)+ext),OUT/(label+'-cell'+ext))
    if time.monotonic_ns()>=deadline:raise ValueError('observation expired before mint')
    alias=label+'_target'
    ref=bridge.mint_reference(alias,accepted['sequence'],[440,28],region_size=(30,14))
    if time.monotonic_ns()>=deadline:raise ValueError('observation expired during mint')
    return alias,ref,deadline


def owner_for(window, name):
    owner=GuardedSessionOwner({'app':window}, OUT/name, ':153')
    owners.append(owner); owner.get()
    return owner


try:
    env=dict(os.environ,DISPLAY=':153',HOME='/tmp',SAL_USE_VCLPLUGIN='gen')
    fixture=Path('/snapshot/blank.fods')
    if hashlib.sha256(fixture.read_bytes()).hexdigest()!=FIXTURE_SHA: raise ValueError('fixture hash differs')
    shutil.copyfile(fixture,'/tmp/blank.fods')
    spawn('xvfb',['Xvfb',':153','-screen','0','1280x800x24','-nolisten','tcp','-ac'],env)
    for _ in range(100):
        try: d=display.Display(':153'); break
        except Exception: time.sleep(.05)
    if d is None: raise RuntimeError('isolated Xvfb unavailable')
    spawn('openbox',['openbox','--sm-disable'],env)
    calc=spawn('calc',['libreoffice','-env:UserInstallation=file:///tmp/probe-profile','--calc','--nologo',
                       '--norestore','--nofirststartwizard','/tmp/blank.fods'],env)
    def walk(window,depth=0):
        if depth>6:return []
        found=[]
        for child in window.query_tree().children:
            try:
                title=child.get_wm_name(); title=title.decode(errors='replace') if isinstance(title,bytes) else str(title or '')
                found.append((child.id,title,child.get_attributes().map_state));found.extend(walk(child,depth+1))
            except Exception: pass
        return found
    deadline=time.monotonic()+25; found=[]
    while time.monotonic()<deadline:
        found=[row for row in walk(d.screen().root) if 'blank.fods' in row[1].lower() and 'calc' in row[1].lower() and row[2]==X.IsViewable]
        if len(found)==1:break
        if len(found)>1 or calc.poll() is not None:raise RuntimeError('target ambiguous or exited')
        time.sleep(.05)
    if len(found)!=1:raise RuntimeError('target unavailable')
    time.sleep(1); record('target.json',{'id':found[0][0],'title':found[0][1]})
    owner=owner_for(found[0][0],'first-owner'); bridge=owner.bridge
    obs,image,ref=fresh_reference(bridge,'entry')
    if hashlib.sha256(image.crop((0,97,42,119)).tobytes()).hexdigest()!=NAMEBOX_SHA:
        raise ValueError('A1 selection not independently matched')
    original=bridge.backend.key_state; fault={'fired':False,'after_key':'1','emission_returned':False,'preceding_key_downs':[]}
    def inject(key,down):
        if down and key=='1':
            original(key,down)
            fault['emission_returned']=True;fault['fired']=True
            raise RuntimeError('controlled failure after third key-down submission')
        if down:fault['preceding_key_downs'].append(key)
        return original(key,down)
    bridge.backend.key_state=inject
    owner.dispatch_attempted=True; result['input_dispatched']=True
    try: first=bridge.keyboard('entry',ref['offset'],tail=[{'op':'text','text':'731'}],expires_at_ns=time.monotonic_ns()+3_000_000_000)
    finally: bridge.backend.key_state=original
    record('fault.json',fault)
    record('first-result.json',first)
    if not fault['fired'] or not fault['emission_returned'] or fault['preceding_key_downs']!=['7','3'] or first.get('status')=='completed':
        raise ValueError('fault boundary or first result differs')
    closed=owner.close();record('first-close.json',closed)
    if closed.get('status')!='closed' or not verify_release(closed.get('release')):raise ValueError('first owner release unverified')
    state=neutral();record('after-first-neutral.json',state)
    if state != {'keys_down':[],'buttons_mask':0}:raise ValueError('physical X state nonneutral')
    fresh=owner_for(found[0][0],'recovery-owner'); bridge=fresh.bridge
    alias,ref,commit_deadline=wait_formula(bridge,'partial','731',('','7','73'))
    if time.monotonic_ns()>=commit_deadline:raise ValueError('commit deadline expired before input')
    fresh.dispatch_attempted=True
    commit=bridge.keyboard(alias,ref['offset'],tail=[{'op':'key_chord','keys':['ENTER']}],expires_at_ns=commit_deadline)
    record('commit-result.json',commit)
    if commit.get('status')!='completed' or not commit.get('execution',{}).get('releases') or not all(verify_release(x) for x in commit['execution']['releases']):raise ValueError('commit or release unverified')
    obs,image,ref=fresh_reference(bridge,'save_final')
    save=bridge.keyboard('save_final',ref['offset'],tail=[{'op':'key_chord','keys':['CTRL','s']}],expires_at_ns=time.monotonic_ns()+3_000_000_000)
    record('save-result.json',save)
    if save.get('status')!='completed' or not save.get('execution',{}).get('releases') or not all(verify_release(x) for x in save['execution']['releases']):raise ValueError('save or release unverified')
    source=Path('/tmp/blank.fods');end=time.monotonic()+5
    while time.monotonic()<end and hashlib.sha256(source.read_bytes()).hexdigest()==FIXTURE_SHA:time.sleep(.05)
    saved=source.read_bytes(); (OUT/'saved.fods').write_bytes(saved)
    ns={'t':'urn:oasis:names:tc:opendocument:xmlns:table:1.0','o':'urn:oasis:names:tc:opendocument:xmlns:office:1.0'}
    cell=ET.fromstring(saved).find('.//t:table/t:table-row/t:table-cell',ns)
    if cell is None or cell.get('{'+ns['o']+'}value')!='731' or cell.get('{'+ns['t']+'}formula') is not None:raise ValueError('saved A1 differs')
    close=fresh.close();record('recovery-close.json',close)
    if close.get('status')!='closed' or not verify_release(close.get('release')):raise ValueError('recovery close unverified')
    state=neutral();record('final-neutral.json',state)
    if state != {'keys_down':[],'buttons_mask':0}:raise ValueError('final physical X state nonneutral')
    result.update(passed=True,saved_sha256=hashlib.sha256(saved).hexdigest(),first_owner=closed['session_id'],recovery_owner=close['session_id'])
    if result['first_owner']==result['recovery_owner']:raise ValueError('owner was not renewed')
except Exception as error:
    result.update(passed=False,error_type=type(error).__name__,error=str(error))
    (OUT/'traceback.txt').write_text(traceback.format_exc())
finally:
    for owner in reversed(owners):
        try:owner.close()
        except Exception as error:result.update(passed=False,cleanup_error=type(error).__name__)
    if d is not None:
        try:record('final-observed-neutral.json',neutral());d.close()
        except Exception as error:result.update(passed=False,neutral_error=type(error).__name__)
    for process in reversed(actors):
        if process.poll() is None:
            try:os.killpg(process.pid,signal.SIGTERM);process.wait(timeout=3)
            except Exception:
                try:os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=3)
                except Exception as error:result.update(passed=False,process_cleanup_error=type(error).__name__)
    for stream in logs:stream.close()
    record('result.json',result)

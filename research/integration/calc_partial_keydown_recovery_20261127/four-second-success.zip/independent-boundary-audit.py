"""Read-only provenance and timing checks for the post-key-down experiment."""
import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

root=Path(sys.argv[1]);out=root/'output'
def load(path):return json.loads(path.read_text(encoding='utf-8'))
def require(condition,message):
    if not condition:raise ValueError(message)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def neutral(row):return type(row) is dict and row.get('verified') is True and row.get('keys_down')==[] and row.get('buttons_down')==[]

reg=load(root/'registration.json');manifest=load(root/'runtime-manifest.json')
require(reg.get('observation_budget_ms')==4000 and reg.get('max_observations_per_gate')==8 and reg.get('model_calls')==0,'registration bounds differ')
for name,key in (('runner.py','runner_sha256'),('audit.py','auditor_sha256'),
                 ('calc_bounded_observation_v1.py','observation_helper_sha256'),('runtime-manifest.json','runtime_manifest_sha256')):
    require(sha(root/name)==reg[key],'registered artifact differs: '+name)
for name,digest in manifest['runtime_files'].items():require(sha(root/name)==digest,'runtime snapshot differs: '+name)
require(sha(root/'blank.fods')==reg['fixture_sha256'],'blank fixture differs')
first=load(out/'first-result.json');fault=load(out/'fault.json')
require(first.get('status')!='completed' and fault.get('fired') is True and fault.get('after_key')=='1'
        and fault.get('emission_returned') is True and fault.get('preceding_key_downs')==['7','3'],'fault boundary differs')
require(type(first['execution'].get('program_emissions')) is int and first['execution']['program_emissions']>=5 and
        first['execution'].get('failed_op_effect')=='unknown; may have emitted partial input' and
        first['execution'].get('releases') and all(neutral(r) for r in first['execution']['releases']),
        'first result or cleanup differs')
first_programs=[load(p) for p in (out/'first-owner').rglob('program-*.json')]
require(len(first_programs)==1 and [x['text'] for x in first_programs[0]['ops'] if x.get('op')=='text']==['731'],
        'first program differs')
programs=[load(p) for p in (out/'recovery-owner').rglob('program-*.json')]
require(len(programs)==2 and not any(x.get('op')=='text' for p in programs for x in p['ops']),'text was replayed or program count differs')
def program(keys):
    found=[p for p in programs if any(x.get('op')=='key_chord' and x.get('keys')==keys for x in p['ops'])]
    require(len(found)==1,'missing unique recovery command: '+str(keys));return found[0]
commit=program(['ENTER']);program(['CTRL','s'])
polls=load(out/'partial-polls.json');rows=polls['records'];action=load(out/'commit-result.json');save=load(out/'save-result.json')
require(polls.get('accepted') is True and 1<=len(rows)<=8 and rows[-1]['text']=='731','accepted observation differs')
require(all(r['deadline_ns']==polls['deadline_ns'] and r['started_ns']<=r['capture_ns']<=r['finished_ns']<r['deadline_ns'] for r in rows)
        and all(a['sequence']<b['sequence'] and a['binding']==b['binding'] for a,b in zip(rows,rows[1:])),
        'observation timing, sequence or binding differs')
require(rows[-1]['finished_ns']<=action['execution']['started_ns']<polls['deadline_ns'] and
        commit['authority']['expires_at_ns']==polls['deadline_ns'] and commit['source']['observation_seq']>=rows[-1]['sequence'],
        'commit deadline or source differs')
for item in (action,save):
    require(item.get('status')=='completed' and item['execution'].get('releases') and
            all(neutral(r) for r in item['execution']['releases']),'recovery release unverified')
require(action['execution']['ended_ns']<=save['execution']['started_ns'],'save preceded commit completion')
first_close=load(out/'first-close.json');last_close=load(out/'recovery-close.json')
require(first_close.get('status')=='closed' and last_close.get('status')=='closed' and
        first_close.get('session_id')!=last_close.get('session_id') and neutral(first_close.get('release')) and
        neutral(last_close.get('release')),'owner release or generation differs')
for name in ('after-first-neutral.json','final-neutral.json','final-observed-neutral.json'):
    require(load(out/name)=={'keys_down':[],'buttons_mask':0},'X neutral state differs: '+name)
data=(out/'saved.fods').read_bytes();result=load(out/'result.json')
ns={'t':'urn:oasis:names:tc:opendocument:xmlns:table:1.0','o':'urn:oasis:names:tc:opendocument:xmlns:office:1.0'}
cell=ET.fromstring(data).find('.//t:table/t:table-row/t:table-cell',ns)
require(result.get('passed') is True and hashlib.sha256(data).hexdigest()==result.get('saved_sha256') and cell is not None
        and cell.get('{'+ns['o']+'}value')=='731' and cell.get('{'+ns['t']+'}formula') is None,'saved effect differs')
print(json.dumps({'status':'audited','observations':len(rows),'runtime_files':len(manifest['runtime_files']),
                  'saved_sha256':hashlib.sha256(data).hexdigest(),
                  'scope':'single controlled post-key-down fault; no text replay'},sort_keys=True,indent=2))

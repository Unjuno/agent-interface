"""Verify one controlled post-key-down failure; no input authority."""
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output'


def read(path):return json.loads(path.read_text(encoding='utf-8'))
def require(value,message):
    if not value:raise ValueError(message)
def neutral(row):
    return type(row) is dict and row.get('verified') is True and row.get('keys_down')==[] and row.get('buttons_down')==[]


def main():
    result=read(OUT/'result.json');fault=read(OUT/'fault.json');first=read(OUT/'first-result.json')
    require(result.get('passed') is True and result.get('model_calls')==0,'runner did not pass')
    require(fault.get('fired') is True and fault.get('after_key')=='1' and fault.get('emission_returned') is True
            and fault.get('preceding_key_downs')==['7','3'],'fault injection differs')
    require(first.get('status')!='completed' and type(first['execution'].get('program_emissions')) is int and
            first['execution']['program_emissions']>=5 and
            first['execution'].get('failed_op_effect')=='unknown; may have emitted partial input',
            'first operation result differs')
    require(first['execution'].get('releases') and all(neutral(x) for x in first['execution']['releases']),
            'failed operation release unverified')
    a=read(OUT/'first-close.json');b=read(OUT/'recovery-close.json')
    require(a.get('status')=='closed' and b.get('status')=='closed' and neutral(a.get('release')) and neutral(b.get('release')),
            'owner release unverified')
    require(type(a.get('session_id')) is str and a['session_id'] and a['session_id']!=b.get('session_id'),
            'owner epochs differ incorrectly')
    for name in ('after-first-neutral.json','final-neutral.json','final-observed-neutral.json'):
        require(read(OUT/name)=={'keys_down':[],'buttons_mask':0},'X neutral state differs: '+name)
    polls=read(OUT/'partial-polls.json');rows=polls.get('records')
    require(polls.get('accepted') is True and type(rows) is list and 1<=len(rows)<=8 and rows[-1].get('text')=='731',
            'fresh observation not accepted')
    require(all(r.get('deadline_ns')==polls.get('deadline_ns') and
                r['started_ns']<=r['capture_ns']<=r['finished_ns']<r['deadline_ns'] for r in rows),
            'observation deadline differs')
    require(all(a['sequence']<b['sequence'] and a['binding']==b['binding'] for a,b in zip(rows,rows[1:])),
            'observation sequence or binding differs')
    ocr=read(OUT/'partial-cell.json');image=(OUT/'partial-cell.png').read_bytes()
    require(ocr.get('exit_code')==0 and ocr.get('text')=='731' and ocr.get('crop_sha256')==hashlib.sha256(image).hexdigest(),
            'stored OCR evidence differs')
    rerun=subprocess.run(['tesseract',str(OUT/'partial-cell.png'),'stdout','--psm','8','-c','tessedit_char_whitelist=0123456789'],
                         capture_output=True,text=True,timeout=10)
    require(rerun.returncode==0 and rerun.stdout.strip()=='731','independent OCR differs')
    original=[read(p) for p in (OUT/'first-owner').rglob('program-*.json')]
    initial_text=[op.get('text') for p in original for op in p['ops'] if op.get('op')=='text']
    require(len(original)==1 and initial_text==['731'],'original program differs')
    programs=[read(p) for p in (OUT/'recovery-owner').rglob('program-*.json')]
    require(len(programs)==2 and not any(op.get('op')=='text' for p in programs for op in p['ops']),
            'recovery must not replay text')
    def find(keys):
        found=[p for p in programs if any(op.get('op')=='key_chord' and op.get('keys')==keys for op in p['ops'])]
        require(len(found)==1,'recovery command inventory differs')
        return found[0]
    commit=find(['ENTER']);find(['CTRL','s'])
    for name in ('commit-result.json','save-result.json'):
        row=read(OUT/name);releases=row.get('execution',{}).get('releases')
        require(row.get('status')=='completed' and type(releases) is list and releases and all(neutral(x) for x in releases),
                'action release unverified: '+name)
    execution=read(OUT/'commit-result.json')['execution']
    require(rows[-1]['finished_ns']<=execution['started_ns']<polls['deadline_ns'] and
            commit['authority']['expires_at_ns']==polls['deadline_ns'] and
            commit['source']['observation_seq']>=rows[-1]['sequence'],'commit deadline or source differs')
    data=(OUT/'saved.fods').read_bytes();require(hashlib.sha256(data).hexdigest()==result.get('saved_sha256'),'saved bytes differ')
    ns={'t':'urn:oasis:names:tc:opendocument:xmlns:table:1.0','o':'urn:oasis:names:tc:opendocument:xmlns:office:1.0'}
    cell=ET.fromstring(data).find('.//t:table/t:table-row/t:table-cell',ns)
    require(cell is not None and cell.get('{'+ns['o']+'}value')=='731' and cell.get('{'+ns['t']+'}formula') is None,'saved A1 differs')
    print(json.dumps({'status':'audited','a1':731,'observations':len(rows),
                      'scope':'one controlled post-key-down failure; no replay of original text'},sort_keys=True))


if __name__=='__main__':main()

"""Adapter boundary regression tests for the existing compiled graph."""
import subprocess
import unittest
from runtime.core_v1.compiled_gui import run


def interface():
 return {'format':'compiled-gui-interface-v1','interface_id':'test','session_scope':'private','surface':'form',
  'predicates':['phase'], 'symbols':{'field':{'kind':'target_reference','target_reference':'field','identity_predicate':'phase','dependencies':['phase']}},
  'actions':{'enter':{'target_symbol':'field','operation':'enter','expected_effect':{'phase':1}},'save':{'target_symbol':'field','operation':'save','expected_effect':{'phase':2}}},
  'method':{'name':'two-steps','version':'1','initial_state':'empty','max_transitions':2,'max_runtime_ms':10,
   'states':{n:{'branches':[{'when':{'phase':i},'outcome':'action' if i<2 else 'complete','action':['enter','save',None][i],'next_state':['filled','done',None][i],'reason':None}]} for i,n in enumerate(['empty','filled','done'])}}}

class Driver:
 def __init__(self,expired_stage=None,at=1,terminal='completed',released=True):
  self.now=0;self.expired_stage=expired_stage;self.at=at;self.terminal=terminal;self.released=released
  self.calls={k:[] for k in ['observe','admit','execute','verify_effect','journal']}
 def record(self,stage,value):
  self.calls[stage].append(value)
  if stage==self.expired_stage and len(self.calls[stage])==self.at:self.now=10_000_000
 def observe(self,p):
  self.record('observe',p);i=len(self.calls['observe'])
  return {'sequence':i,'captured_ns':self.now,'surface':'form','predicates':{'phase':i-1},'evidence_ref':f'frame{i}','evidence_digest':f'digest{i}'}
 def admit(self,p):
  self.record('admit',p)
  return {'eligible':True,'status':'revalidated','authorization':'one-use','expected_sequence':p['observation']['sequence'],'valid_until_ns':100_000_000}
 def execute(self,p):
  self.record('execute',p)
  return {'status':self.terminal,'action_id':str(len(self.calls['execute'])),'effect_ref':'effect','release':{'verified':self.released,'keys_down':[],'buttons_down':[]}}
 def verify(self,p):
  self.record('verify_effect',p);return {'status':'succeeded','evidence_ref':p['observation']['evidence_ref']}
 def journal(self,p):self.record('journal',p)
 def run(self,spec=None,clock=None,effect_clock=None,effect_clock_domain="graph"):
  adapters={'observe':self.observe,'admit':self.admit,'execute':self.execute,
   'verify_effect':self.verify,'cancelled':lambda:False,'journal':self.journal}
  unchanged=getattr(self,'verify_unchanged_effect',None)
  if unchanged is not None:adapters['verify_unchanged_effect']=unchanged
  return run(spec or interface(),adapters,clock=clock or (lambda:self.now),
             effect_clock=effect_clock,effect_clock_domain=effect_clock_domain)

class CompiledBoundaryTests(unittest.TestCase):

 def test_effect_verification_can_use_the_callback_clock_domain(self):
  graph_time=[0];effect_time=[5000];request_times=[]
  d=Driver()
  def next_effect_time():
   effect_time[0]+=1
   return effect_time[0]
  def verify(request):
   request_times.append(next_effect_time())
   return d.verify(request)
  adapters={'observe':d.observe,'admit':d.admit,'execute':d.execute,
   'verify_effect':verify,'cancelled':lambda:False,'journal':d.journal}
  receipt=run(interface(),adapters,clock=lambda:graph_time[0],
              effect_clock=next_effect_time,effect_clock_domain="synthetic-effect-clock")
  checks=[event for event in receipt['critical_events']
          if event.get('event')=='effect_checked']
  self.assertEqual(len(checks),2)
  self.assertEqual(checks[0]['effect_verification_clock_domain'],
                   "synthetic-effect-clock")
  self.assertLess(checks[0]['effect_verification_started_ns'],request_times[0])
  self.assertLess(request_times[0],checks[0]['effect_verification_accepted_ns'])
  self.assertEqual(receipt['outcome'],'TASK_SUCCEEDED')

 def test_unchanged_frame_uses_explicit_nonvisual_effect_verifier(self):
  d=Driver();base=d.observe
  def observe(request):
   row=base(request)
   if len(d.calls['observe'])==3:
    row['evidence_digest']='digest2'
   return row
  d.observe=observe
  d.verify_unchanged_effect=d.verify
  receipt=d.run()
  self.assertEqual(receipt['outcome'],'TASK_SUCCEEDED')
  self.assertEqual(receipt['completed_transitions'],2)
  self.assertEqual(len(d.calls['verify_effect']),2)
  self.assertEqual(receipt['critical_events'][-1]['reason'],'method_complete')

 def test_unchanged_effect_verifier_does_not_start_at_expired_deadline(self):
  def unchanged_driver():
   d=Driver();base=d.observe
   def observe(request):
    row=base(request)
    if len(d.calls['observe'])==3:row['evidence_digest']='digest2'
    return row
   d.observe=observe;d.verify_unchanged_effect=d.verify
   s=interface();s['method']['max_runtime_ms']=1
   return d,s

  calibration,calibration_spec=unchanged_driver()
  calibration_reads=[0];reads_at_callback=[]
  def calibration_clock():
   calibration_reads[0]+=1
   return 0
  def calibrated_verifier(request):
   reads_at_callback.append(calibration_reads[0])
   return calibration.verify(request)
  calibration.verify_unchanged_effect=calibrated_verifier
  baseline=calibration.run(calibration_spec,clock=calibration_clock,
                           effect_clock=lambda:0)
  self.assertEqual(baseline['outcome'],'TASK_SUCCEEDED')
  self.assertEqual(len(reads_at_callback),1)

  d,spec=unchanged_driver();reads=[0]
  deadline_read=reads_at_callback[0]
  def deadline_clock():
   reads[0]+=1
   return 1_000_000 if reads[0]==deadline_read else 0
  receipt=d.run(spec,clock=deadline_clock,effect_clock=lambda:0,
                effect_clock_domain="different-clock")
  self.assertEqual((receipt['outcome'],receipt['reason']),('SAFE_YIELD','budget_exhausted'))
  self.assertEqual(receipt['completed_transitions'],2)
  self.assertEqual(receipt['pending_effect']['action'],'save')
  self.assertEqual(len(d.calls['verify_effect']),1)

 def test_receipt_times_bound_observation_execution_and_effect_confirmation(self):
  now=[0];observations=[]
  def clock():now[0]+=10;return now[0]
  def observe(_request):
   now[0]+=2;i=len(observations)+1
   row={'sequence':i,'captured_ns':now[0],'surface':'form',
        'predicates':{'phase':i-1},'evidence_ref':f'frame{i}',
        'evidence_digest':f'digest{i}'}
   observations.append(row);return row
  def admit(request):
   return {'eligible':True,'status':'revalidated','authorization':'one-use',
           'expected_sequence':request['observation']['sequence'],
           'valid_until_ns':1_000_000_000}
  def execute(_request):
   now[0]+=3
   return {'status':'completed','action_id':'a1','effect_ref':'e1',
           'release':{'verified':True,'keys_down':[],'buttons_down':[]}}
  def verify_effect(request):
   now[0]+=5
   return {'status':'succeeded','evidence_ref':request['observation']['evidence_ref']}
  receipt=run(interface(),{'observe':observe,'admit':admit,'execute':execute,
      'verify_effect':verify_effect,'cancelled':lambda:False},clock=clock)
  self.assertEqual(receipt['outcome'],'TASK_SUCCEEDED')
  observed=receipt['observations']
  transition=receipt['transitions'][0]
  terminal=next(event for event in receipt['critical_events'] if event['event']=='action_terminal')
  checked=next(event for event in receipt['critical_events'] if event['event']=='effect_checked')
  self.assertLessEqual(observed[0]['observation_started_ns'],observed[0]['captured_ns'])
  self.assertLessEqual(observed[0]['captured_ns'],observed[0]['observation_accepted_ns'])
  self.assertLessEqual(transition['execution_started_ns'],transition['execution_accepted_ns'])
  self.assertEqual(terminal['execution_accepted_ns'],transition['execution_accepted_ns'])
  self.assertEqual(checked['action_id'],transition['action_id'])
  self.assertLessEqual(transition['execution_accepted_ns'],checked['effect_observation_captured_ns'])
  self.assertLessEqual(checked['effect_observation_captured_ns'],checked['effect_observation_accepted_ns'])
  self.assertLessEqual(checked['effect_observation_accepted_ns'],checked['effect_verification_started_ns'])
  self.assertLessEqual(checked['effect_verification_started_ns'],checked['effect_verification_accepted_ns'])
  self.assertEqual(checked['effect_verification_accepted_ns']-checked['effect_verification_started_ns'],15)

 def test_cross_type_predicate_cannot_select_action_or_complete(self):
  for expected, observed in ((0,False),(False,0),(1,True),(True,1)):
   for outcome in ('action','complete'):
    with self.subTest(expected=expected,observed=observed,outcome=outcome):
     d=Driver();s=interface();b=s['method']['states']['empty']['branches'][0]
     b['when']['phase']=expected
     if outcome=='complete':b.update(outcome='complete',action=None,next_state=None)
     base=d.observe
     def observe(p):
      r=base(p);r['predicates']['phase']=observed;return r
     d.observe=observe;r=d.run(s)
     self.assertEqual((r['outcome'],r['reason']),('SAFE_YIELD','unknown_state'))
     self.assertEqual(r['completed_transitions'],0);self.assertEqual(d.calls['admit'],[])
     self.assertEqual(d.calls['execute'],[])
 def test_cross_type_effect_retains_prefix_and_never_calls_verifier_or_next_action(self):
  for expected,observed in ((0,False),(False,0),(1,True),(True,1)):
   with self.subTest(expected=expected,observed=observed):
    d=Driver();s=interface();s['actions']['enter']['expected_effect']['phase']=expected
    base=d.observe
    def observe(p):
     r=base(p)
     if len(d.calls['observe'])==2:r['predicates']['phase']=observed
     return r
    d.observe=observe;r=d.run(s)
    self.assertEqual((r['outcome'],r['reason']),('SAFE_YIELD','effect_failed'))
    self.assertEqual(r['completed_transitions'],1);self.assertEqual(r['pending_effect']['action'],'enter')
    self.assertEqual(len(d.calls['execute']),1);self.assertEqual(d.calls['verify_effect'],[])
 def test_same_type_scalar_completion_remains_supported(self):
  for value in (0,False,1,True,2,-1,'ready'):
   with self.subTest(value=value):
    d=Driver();s=interface();b=s['method']['states']['empty']['branches'][0]
    b.update(when={'phase':value},outcome='complete',action=None,next_state=None)
    base=d.observe
    def observe(p):
     r=base(p);r['predicates']['phase']=value;return r
    d.observe=observe;r=d.run(s)
    self.assertEqual(r['outcome'],'TASK_SUCCEEDED');self.assertEqual(d.calls['execute'],[])

 def stopped(self,d,transitions,executions):
  r=d.run();self.assertEqual((r['outcome'],r['reason']),('SAFE_YIELD','budget_exhausted'));self.assertEqual(r['completed_transitions'],transitions);self.assertEqual(len(d.calls['execute']),executions);return r
 def test_late_initial_observation_never_admits(self):
  d=Driver('observe');r=self.stopped(d,0,0);self.assertEqual(d.calls['admit'],[]);self.assertEqual(len(r['observations']),1)
 def test_late_intermediate_observation_preserves_prefix_pending_effect(self):
  d=Driver('observe',2);r=self.stopped(d,1,1);self.assertEqual(r['pending_effect']['action'],'enter');self.assertEqual(d.calls['verify_effect'],[])
 def test_observation_adapter_failure_returns_receipt_and_never_admits_next_action(self):
  d=Driver();base=d.observe
  def observe(p):
   if not d.calls['observe']:return base(p)
   d.record('observe',p);raise subprocess.TimeoutExpired('tesseract',5)
  d.observe=observe;r=d.run()
  self.assertEqual((r['outcome'],r['reason']),('RUNTIME_FAILED','observation_failed'))
  self.assertEqual(r['completed_transitions'],1);self.assertEqual(r['pending_effect']['action'],'enter')
  self.assertEqual(len(d.calls['observe']),2);self.assertEqual(len(d.calls['admit']),1);self.assertEqual(len(d.calls['execute']),1)
 def test_late_final_observation_never_claims_completion(self):
  d=Driver('observe',3);r=self.stopped(d,2,2);self.assertEqual(r['pending_effect']['action'],'save')
 def test_late_admission_never_dispatches(self):self.stopped(Driver('admit'),0,0)
 def test_late_second_admission_preserves_prefix(self):self.stopped(Driver('admit',2),1,1)
 def test_late_verifier_never_dispatches_second_action(self):
  d=Driver('verify_effect');r=self.stopped(d,1,1);self.assertIsNone(r['pending_effect'])
 def test_late_final_verifier_never_claims_completion(self):self.stopped(Driver('verify_effect',2),2,2)
 def test_late_execution_retains_effect_and_does_not_observe_again(self):
  d=Driver('execute');r=self.stopped(d,1,1);self.assertEqual(r['pending_effect']['action'],'enter');self.assertEqual(len(d.calls['observe']),1)
 def test_late_final_execution_preserves_both_actions(self):self.stopped(Driver('execute',2),2,2)
 def test_branch_journal_consuming_budget_never_admits(self):
  d=Driver('journal',2);self.stopped(d,0,0);self.assertEqual(d.calls['admit'],[])
 def test_failed_release_is_preserved_over_expired_budget(self):
  d=Driver('execute',released=False);r=d.run();self.assertEqual((r['outcome'],r['reason']),('RUNTIME_FAILED','execution_failed'));self.assertEqual(len(d.calls['execute']),1)
 def test_uncertain_delivery_is_preserved_over_expired_budget(self):
  d=Driver('execute',terminal='delivery_uncertain');r=d.run();self.assertEqual(r['reason'],'delivery_uncertain');self.assertEqual(len(d.calls['execute']),1)
 def test_action_deadline_cannot_extend_method_budget(self):
  d=Driver();r=d.run();self.assertEqual(r['outcome'],'TASK_SUCCEEDED');self.assertEqual([c['valid_until_ns'] for c in d.calls['execute']],[10_000_000,10_000_000])
 def test_normal_branches_use_fresh_effects(self):
  d=Driver();r=d.run();self.assertEqual(r['completed_transitions'],2);self.assertEqual([c['observation']['sequence'] for c in d.calls['verify_effect']],[2,3])

 def test_unknown_initial_state_sends_no_input(self):
  d=Driver();base=d.observe
  def observe(p):
   r=base(p);r['predicates']={};return r
  d.observe=observe;r=d.run();self.assertEqual(r['reason'],'unknown_state');self.assertEqual(d.calls['execute'],[])
 def test_ambiguous_state_sends_no_input(self):
  d=Driver();s=interface();b=s['method']['states']['empty']['branches'];b.append(dict(b[0]));r=d.run(s);self.assertEqual(r['reason'],'ambiguous_state');self.assertEqual(d.calls['execute'],[])
 def test_missing_second_symbol_retains_first_input(self):
  d=Driver();base=d.admit
  def admit(p):
   r=base(p)
   if len(d.calls['admit'])==2:r.update(eligible=False,status='missing',authorization=None)
   return r
  d.admit=admit;r=d.run();self.assertEqual(r['reason'],'missing_symbol');self.assertEqual(r['completed_transitions'],1);self.assertEqual(len(d.calls['execute']),1)
 def test_stale_intermediate_observation_blocks_second_input(self):
  d=Driver();base=d.observe
  def observe(p):
   r=base(p)
   if len(d.calls['observe'])==2:r['sequence']=1
   return r
  d.observe=observe;r=d.run();self.assertEqual(r['reason'],'stale_observation');self.assertEqual(len(d.calls['execute']),1)
 def test_failed_effect_blocks_second_input(self):
  d=Driver();d.verify=lambda p:dict(status='failed',evidence_ref=p['observation']['evidence_ref']);r=d.run();self.assertEqual(r['reason'],'effect_failed');self.assertEqual(len(d.calls['execute']),1)
 def test_unavailable_effect_blocks_second_input(self):
  d=Driver();d.verify=lambda p:dict(status='unavailable',evidence_ref=p['observation']['evidence_ref']);r=d.run();self.assertEqual(r['reason'],'effect_unavailable');self.assertEqual(len(d.calls['execute']),1)

 def test_explicit_no_input_refusal_yields_without_inventing_release(self):
  d=Driver(terminal='refused',released=False);base=d.execute
  d.execute=lambda p:dict(base(p),input_dispatched=False)
  r=d.run();self.assertEqual((r['outcome'],r['reason']),('SAFE_YIELD','execution_refused'))
  self.assertEqual(r['completed_transitions'],0);self.assertEqual(len(d.calls['execute']),1)
  self.assertEqual(len(d.calls['observe']),1);self.assertEqual(d.calls['verify_effect'],[])
  terminal=next(e for e in r['critical_events'] if e['event']=='action_terminal')
  self.assertIs(terminal['input_dispatched'],False);self.assertIs(terminal['release_verified'],False)
 def test_no_input_refusal_after_verified_prefix_keeps_completed_action(self):
  d=Driver();base=d.execute
  def execute(p):
   result=base(p)
   if len(d.calls['execute'])==2:result.update(status='refused',input_dispatched=False,release={'verified':False,'keys_down':[],'buttons_down':[]})
   return result
  d.execute=execute;r=d.run();self.assertEqual(r['reason'],'execution_refused')
  self.assertEqual(r['completed_transitions'],1);self.assertEqual(r['transitions'][0]['action'],'enter')
  self.assertEqual(len(d.calls['execute']),2);self.assertEqual(len(d.calls['observe']),2)
 def test_unattested_refusal_still_requires_actual_neutral_release(self):
  d=Driver(terminal='refused',released=False);r=d.run()
  self.assertEqual((r['outcome'],r['reason']),('RUNTIME_FAILED','execution_failed'))
 def test_no_input_flag_cannot_downgrade_other_execution_statuses(self):
  for status in ('completed','delivery_uncertain'):
   with self.subTest(status=status):
    d=Driver(terminal=status,released=False);base=d.execute
    d.execute=lambda p:dict(base(p),input_dispatched=False)
    r=d.run();self.assertEqual((r['outcome'],r['reason']),('RUNTIME_FAILED','execution_failed'))
    self.assertIsNone(r['unresolved_execution']['input_dispatched'])
 def test_input_dispatched_requires_strict_boolean(self):
  for value in (0,1,None,'false'):
   with self.subTest(value=value):
    d=Driver(terminal='refused',released=False);base=d.execute
    d.execute=lambda p:dict(base(p),input_dispatched=value)
    r=d.run();self.assertEqual((r['outcome'],r['reason']),('RUNTIME_FAILED','execution_failed'))
    self.assertIsNone(r['unresolved_execution']['input_dispatched'])
 def test_dispatch_or_held_input_cannot_be_downgraded_to_abstention(self):
  for flag,keys in ((True,[]),(False,['CTRL'])):
   with self.subTest(flag=flag,keys=keys):
    d=Driver(terminal='refused',released=False);base=d.execute
    def execute(p):
     r=base(p);r['input_dispatched']=flag;r['release']['keys_down']=keys;return r
    d.execute=execute;r=d.run();self.assertEqual(r['outcome'],'RUNTIME_FAILED')
 def test_admission_callback_exception_returns_completed_prefix(self):
  d=Driver();base=d.admit
  def admit(payload):
   if len(d.calls['admit'])==1:
    d.record('admit',payload)
    raise TimeoutError('admission timeout')
   return base(payload)
  d.admit=admit
  receipt=d.run()
  self.assertEqual((receipt['outcome'],receipt['reason']),('RUNTIME_FAILED','execution_failed'))
  self.assertEqual(receipt['completed_transitions'],1)
  self.assertEqual(len(d.calls['execute']),1)
  self.assertEqual(len(d.calls['admit']),2)
  self.assertEqual(receipt['critical_events'][-2]['event'],'admission_failed')

 def test_execution_callback_exception_preserves_prefix_and_unknown_delivery(self):
  d=Driver();base=d.execute
  def execute(payload):
   result=base(payload)
   if len(d.calls['execute'])==2:
    raise TimeoutError('execution receipt lost after possible input')
   return result
  d.execute=execute
  receipt=d.run()
  self.assertEqual((receipt['outcome'],receipt['reason']),('RUNTIME_FAILED','execution_failed'))
  self.assertEqual(receipt['completed_transitions'],1)
  self.assertEqual(len(d.calls['execute']),2)
  self.assertEqual(len(d.calls['observe']),2)
  self.assertEqual(len(d.calls['verify_effect']),1)
  unresolved=receipt['unresolved_execution']
  self.assertEqual(unresolved['action'],'save')
  self.assertIsNone(unresolved['input_dispatched'])
  self.assertFalse(unresolved['release_verified'])
  terminals=[event for event in receipt['critical_events'] if event['event']=='action_terminal']
  terminal=terminals[-1]
  self.assertNotIn('input_dispatched',terminal)
  self.assertFalse(terminal['release_verified'])
if __name__=='__main__':unittest.main()

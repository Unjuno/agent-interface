"""Public golden-v3 result boundary over the existing CLI dispatch API."""
from __future__ import annotations
from copy import deepcopy
from typing import Any, Mapping
from .api import dispatch

STATUSES={"invalid_request","backend_unavailable","runtime_failed","returned"}
LIFECYCLE={"doctor","model_attempt","observation","dispatch","refusal","effect","repair","release","cleanup"}
NESTED_REFUSAL_STATUSES={"refused","invalid_request","backend_unavailable"}
AMBIGUOUS_DELIVERY_VALUES={"ambiguous","uncertain","unknown","write_uncertain","delivery_uncertain"}
KNOWN_DELIVERY_VALUES={"confirmed","confirmed_partial"}


def _delivery_evidence(result: dict[str, Any], nested: dict[str, Any]) -> str | None:
    """Resolve both same-contract delivery fields without erasing uncertainty.

    Null/absence makes no delivery assertion. Unsupported evidence dominates
    ambiguity, which dominates confirmed partial, then confirmed. This resolver
    changes presentation only; original fields survive in raw_dispatch.
    """
    values = [("delivery", result.get("delivery")),
              ("result.delivery", nested.get("delivery"))]
    known = AMBIGUOUS_DELIVERY_VALUES | KNOWN_DELIVERY_VALUES
    for path, value in values:
        if value is not None and not isinstance(value, str):
            return "INVALID_TYPE:" + path
    for _, value in values:
        if value is not None and value not in known:
            return value
    for _, value in values:
        if value in AMBIGUOUS_DELIVERY_VALUES:
            return value
    if any(value == "confirmed_partial" for _, value in values):
        return "confirmed_partial"
    return "confirmed" if any(value == "confirmed" for _, value in values) else None


def _usage_status(usage: Mapping[str, Any]) -> str:
    """Describe whether token usage is complete enough for comparison totals.

    Older callers may still supply opaque usage maps such as ``{"input": 3}``;
    those retain their historical reported/unavailable behavior. Once the
    provider token schema is used, both input and output totals are required.
    """
    if not usage:
        return "unavailable"
    token_fields = {"input_tokens", "output_tokens", "cached_input_tokens", "reasoning_tokens"}
    if not token_fields.intersection(usage):
        return "reported"
    if "input_tokens" not in usage or "output_tokens" not in usage:
        return "partial"
    for field in token_fields.intersection(usage):
        value = usage[field]
        if type(value) is not int or value < 0:
            return "malformed"
    return "reported"

def adapt_dispatch_result(result: dict[str,Any], *, usage: Mapping[str,Any]|None=None, lifecycle: list[str]|None=None) -> dict[str,Any]:
    status=result.get("status")
    states=list(lifecycle) if lifecycle is not None else ["dispatch"]
    if status not in STATUSES:
        return _reject("UNKNOWN_STATUS", result, usage)
    if any(state not in LIFECYCLE for state in states):
        return _reject("UNKNOWN_LIFECYCLE", result, usage)
    cleanup=result.get("cleanup_error")
    nested=result.get("result") if isinstance(result.get("result"),dict) else {}
    native_status=nested.get("status")
    delivery=_delivery_evidence(result, nested)
    # Native sessions return status, not the legacy golden success flags.
    # Completion does not supply an independent application score.
    completed=(native_status=="completed" if native_status is not None
               else nested.get("program_completed") is True)
    task_success=nested.get("task_success")
    if type(task_success) is not bool:
        task_success=None
    usage_value=usage if usage is not None else result.get("usage")
    usage_fields=dict(usage_value) if isinstance(usage_value, Mapping) else {}
    usage_status=_usage_status(usage_fields)
    if delivery == "confirmed_partial":
        mapped="partial"
    elif delivery is not None and delivery not in AMBIGUOUS_DELIVERY_VALUES | KNOWN_DELIVERY_VALUES:
        mapped="refused"
        completed=False
        task_success=False
        diagnostic=f"UNKNOWN_DELIVERY:{delivery}"
    elif delivery in AMBIGUOUS_DELIVERY_VALUES:
        mapped="refused"
        completed=False
        task_success=False
        diagnostic=f"AMBIGUOUS_DELIVERY:{delivery}"
    elif cleanup is not None:
        mapped="cleanup_failed"
    elif status in {"invalid_request","backend_unavailable"}:
        mapped="refused"
        completed=False
        task_success=False
    elif status=="runtime_failed":
        mapped="partial"
        task_success=False
    elif native_status in NESTED_REFUSAL_STATUSES:
        mapped="refused"
        completed=False
        task_success=False
    else:
        mapped="success" if completed and task_success is True else "partial"
    row={"schema":"golden-v3-result-v2","program_completed":completed,"task_success":task_success,
         "authority_granted":False,"status":mapped,"partial_effects":nested.get("partial_effects",[]),
         "cleanup_error":cleanup,"lifecycle":states,"usage":usage_fields,
         "usage_status":usage_status,
         "native_status":native_status,"raw_dispatch":deepcopy(result)}
    # Overall task success remains false after cleanup failure. The supplied
    # application score and completed execution are still in raw_dispatch.
    if cleanup is not None: row["task_success"]=False
    if delivery is not None and delivery not in AMBIGUOUS_DELIVERY_VALUES | KNOWN_DELIVERY_VALUES:
        row["diagnostic"] = f"UNKNOWN_DELIVERY:{delivery}"
    elif delivery in AMBIGUOUS_DELIVERY_VALUES:
        row["diagnostic"] = f"AMBIGUOUS_DELIVERY:{delivery}"
    elif "diagnostic" not in row:
        if "error" in result: row["diagnostic"]=result["error"]
        elif "error" in nested: row["diagnostic"]=nested["error"]
    return row

def _reject(reason:str,result:dict[str,Any],usage:Mapping[str,Any]|None)->dict[str,Any]:
    usage_value=usage if usage is not None else result.get("usage")
    usage_fields=dict(usage_value) if isinstance(usage_value, Mapping) else {}
    return {"schema":"golden-v3-result-v2","program_completed":False,"task_success":None,
            "authority_granted":False,"status":"refused","partial_effects":[],"cleanup_error":None,
            "lifecycle":[],"usage":usage_fields,
            "usage_status":_usage_status(usage_fields),
            "adapter_error":reason,"diagnostic":result.get("error"),
            "native_status":None,"raw_dispatch":deepcopy(result)}

def dispatch_golden_v3(program:dict[str,Any],targets:Mapping[str,int],*,current_observation_seq:int,
                       current_binding_revision:int,display_name:str|None=None,
                       usage:Mapping[str,Any]|None=None,
                       capture_directory:str|None=None)->dict[str,Any]:
    options = {} if capture_directory is None else {"capture_directory": capture_directory}
    raw=dispatch(program,targets,current_observation_seq=current_observation_seq,
                 current_binding_revision=current_binding_revision,display_name=display_name, **options)
    return adapt_dispatch_result(raw,usage=usage)

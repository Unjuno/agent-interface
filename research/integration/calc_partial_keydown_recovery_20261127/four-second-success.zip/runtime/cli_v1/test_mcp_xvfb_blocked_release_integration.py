"""Standard guarded MCP cancellation and fresh-session recovery on private Xvfb.

The owner test factory injects one delayed XTEST request after the public
caller emits KeyPress(a). The first press reaches the private Xvfb and a
synthetic app before the owner blocks in the real Display.sync() response
wait. Cancellation then exercises the normal owned-process, XRes disconnect,
and fresh-client release path. Before the delayed-request horizon ends, a new
MCP server targets a distinct synthetic window on the same X server. The
independent oracle records whether a late old-session request contaminates its
task. No arbitrary developer DISPLAY is used.

Control-path assertions and task-oracle outcomes are separate: a completed test
does not imply either counted application task succeeded. Repeated effects are
retained as task failures even when cancellation and release checks complete.
"""

import asyncio
from copy import deepcopy
import hashlib
import io
import json
import math
import os
from pathlib import Path
import platform
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import threading
import time
from time import monotonic_ns as _monotonic_ns
import unittest

from Xlib import X, Xatom, XK, display
from PIL import Image, ImageStat

from runtime.cli_v1.mcp_guarded import GuardedSessionOwner
from runtime.cli_v1.mcp_server import create_server
from runtime.cli_v1 import owned_guarded_session as owned_session_module
from runtime.cli_v1.owned_guarded_session import OwnedGuardedSessionOwner
from runtime.cli_v1.test_synthetic_task_oracle import (
    score_counted_synthetic_application_task,
    score_synthetic_effect_counts,
)


_DELAY_MS = int(os.environ.get(
    'AGENT_INTERFACE_MCP_XVFB_DELAY_MS', '8000'))
_TRACKED_DELAYED_SECOND_PRESS = (
    os.environ.get('AGENT_INTERFACE_MCP_XVFB_TRACKED_DELAYED_SECOND_PRESS', '0') == '1')
_SOCKET_DELIVERY_DELAY = (
    os.environ.get('AGENT_INTERFACE_MCP_XVFB_SOCKET_DELIVERY_DELAY', '0') == '1')
_CANCEL_BOUND_MS = 3000
_CANCEL_ACK_WITHHOLD_S = float(os.environ.get(
    'AGENT_INTERFACE_MCP_XVFB_CANCEL_ACK_WITHHOLD_S', '1.0'))
_TRACE_OWNER_PROCESS_METHODS = (
    os.environ.get('AGENT_INTERFACE_MCP_XVFB_TRACE_OWNER_PROCESS_METHODS', '1') == '1')
_CONTINUE_AFTER_NONNEUTRAL_RELEASE = (
    os.environ.get(
        'AGENT_INTERFACE_MCP_XVFB_CONTINUE_AFTER_NONNEUTRAL_RELEASE', '0') == '1')
_OBLIGATION_PUBLISHER_TRACE = os.environ.get(
    'AGENT_INTERFACE_MCP_XVFB_OBLIGATION_PUBLISHER_TRACE', '')
_PRESTARTED_CANCEL_SUPERVISOR = (
    os.environ.get('AGENT_INTERFACE_MCP_XVFB_PRESTARTED_CANCEL_SUPERVISOR', '0') == '1')
_RETENTION_MODE = os.environ.get('AGENT_INTERFACE_MCP_XVFB_RETENTION_MODE', 'files')
_SERVER_PAUSE_MS = int(os.environ.get(
    'AGENT_INTERFACE_MCP_XVFB_SERVER_PAUSE_MS', '0'))
_TRANSACTION_TIMEOUT_S = float(os.environ.get(
    'AGENT_INTERFACE_MCP_XVFB_TRANSACTION_TIMEOUT_S', '4.0'))
_TERMINAL_BOUND_MS = 5000

if not 0 <= _CANCEL_ACK_WITHHOLD_S <= 2:
    raise ValueError('cancel acknowledgement hold must be between 0 and 2 seconds')
if not 1 <= _DELAY_MS <= 8000:
    raise ValueError('delayed XTEST request must be between 1 and 8000 ms')
if not 0 <= _SERVER_PAUSE_MS <= 5000:
    raise ValueError('Xvfb pause must be between 0 and 5000 ms')
if not math.isfinite(_TRANSACTION_TIMEOUT_S) or not 0 < _TRANSACTION_TIMEOUT_S <= 30:
    raise ValueError('cancellation transaction timeout must be in (0, 30] seconds')
if _RETENTION_MODE not in ('files', 'journal'):
    raise ValueError('retention mode must be files or journal')


def _metadata(response):
    return json.loads(response.content[0].text)


def _xvfb_provenance():
    pid_text = os.environ.get('AGENT_INTERFACE_XVFB_PID')
    if not pid_text or not pid_text.isdigit():
        return {'status':'unavailable', 'reason':'xvfb_pid_not_supplied'}
    executable = Path('/proc', pid_text, 'exe')
    try:
        resolved = Path(os.readlink(executable))
        digest = hashlib.sha256(resolved.read_bytes()).hexdigest()
    except OSError as error:
        return {'status':'unavailable', 'reason':repr(error)}
    package = subprocess.run(
        ['dpkg-query', '-W', '-f=${binary:Package}=${Version}', 'xvfb'],
        capture_output=True, text=True, check=False)
    return {'status':'captured', 'pid':int(pid_text), 'path':str(resolved),
            'sha256':digest, 'package_returncode':package.returncode,
            'package_stdout':package.stdout.strip(),
            'package_stderr':package.stderr.strip()}


def _pause_owned_xvfb_for_test(duration_ms):
    """Pin the private :88 Xvfb and resume that exact process after any stop attempt."""
    pid_text = os.environ.get('AGENT_INTERFACE_XVFB_PID')
    if not pid_text or not pid_text.isdigit() or int(pid_text) <= 1:
        raise RuntimeError('private Xvfb PID was not supplied')
    open_pidfd = getattr(os, 'pidfd_open', None)
    send_pidfd = getattr(signal, 'pidfd_send_signal', None)
    if not callable(open_pidfd) or not callable(send_pidfd):
        raise RuntimeError('private Xvfb pause requires pidfd support; no PID-only fallback')
    pid = int(pid_text)
    pidfd = open_pidfd(pid, 0)
    closed = False
    stop_attempted = False
    resumed = {'monotonic_ns':None, 'error':None}
    resume_lock = threading.Lock()

    def close_handle():
        nonlocal closed
        if not closed:
            closed = True
            os.close(pidfd)

    def resume():
        with resume_lock:
            if closed:
                return
            try:
                send_pidfd(pidfd, signal.SIGCONT)
                resumed['monotonic_ns'] = time.monotonic_ns()
            except OSError as error:
                resumed['error'] = repr(error)
            finally:
                close_handle()

    try:
        executable = Path('/proc', pid_text, 'exe')
        command_line = Path('/proc', pid_text, 'cmdline')
        resolved = Path(os.readlink(executable))
        argv = command_line.read_bytes().replace(b'\0', b' ').decode(
            errors='replace').split()
        if resolved.name != 'Xvfb' or ':88' not in argv:
            raise RuntimeError('refusing to pause a process other than private Xvfb :88')
        started_ns = time.monotonic_ns()
        state_path = Path('/proc', pid_text, 'status')
        stop_attempted = True
        send_pidfd(pidfd, signal.SIGSTOP)
        deadline = time.monotonic() + 1.0
        while time.monotonic() < deadline:
            state = next((line.split(':', 1)[1].strip().split()[0]
                          for line in state_path.read_text().splitlines()
                          if line.startswith('State:')), '')
            if state in ('T', 't'):
                break
            time.sleep(0.005)
        else:
            raise RuntimeError('private Xvfb did not enter stopped state')
        timer = threading.Timer(duration_ms/1000, resume)
        timer.daemon = True
        timer.start()
        return {'pid':pid, 'executable':str(resolved), 'argv':argv,
                'signal_identity':'retained_pidfd',
                'requested_pause_ms':duration_ms, 'stopped_monotonic_ns':started_ns,
                'resumed':resumed}, timer, resume
    except BaseException:
        if stop_attempted:
            resume()
        else:
            close_handle()
        raise


def _arm_x11_socket_delivery_proxy(display_connection, delay_ms):
    control_path = os.environ.get('AGENT_INTERFACE_MCP_XVFB_PROXY_CONTROL')
    if not control_path:
        raise RuntimeError('socket-delivery proxy control path is not configured')
    local = display_connection.display.socket.getsockname()
    if not isinstance(local, tuple) or len(local) < 2:
        raise RuntimeError(f'X11 connection is not a TCP socket: {local!r}')
    request = {'source_port':int(local[1]), 'delay_ms':int(delay_ms)}
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as control:
        control.settimeout(2.0)
        control.connect(control_path)
        control.sendall(json.dumps(request, sort_keys=True).encode() + b'\n')
        response = bytearray()
        while b'\n' not in response and len(response) < 4096:
            chunk = control.recv(1024)
            if not chunk:
                break
            response.extend(chunk)
    row = json.loads(bytes(response).split(b'\n', 1)[0])
    if row.get('status') != 'armed':
        raise RuntimeError(f'X11 socket-delivery proxy refused delay: {row!r}')
    return row


def _xvfb_blocking_owner_factory(targets, directory, display_name, options):
    """Inject blocked X I/O and optionally delay the child cancel acknowledgement."""
    from Xlib.ext import xtest

    owner = GuardedSessionOwner(targets, directory, display_name, **options)
    original_get = owner.get
    root = Path(directory)
    root.mkdir(parents=True, exist_ok=True)
    marker = root/'xvfb-delayed-request-queued.json'
    sync_entered = root/'xvfb-owner-sync-entered.json'
    sync_returned = root/'xvfb-owner-sync-returned.json'
    release_queued = root/'xvfb-target-release-queued.json'
    cancel_ack_withheld = root/'xvfb-cancel-ack-withheld.json'

    original_cancel = owner.cancel_guarded

    def cancel_with_delayed_ack(token):
        result = original_cancel(token)
        row = {'owner_pid':os.getpid(), 'status':result.get('status'),
               'withheld_ack_s':_CANCEL_ACK_WITHHOLD_S,
               'entered_ns':time.monotonic_ns()}
        temporary = cancel_ack_withheld.with_suffix('.tmp')
        temporary.write_text(json.dumps(row, sort_keys=True), encoding='utf-8')
        temporary.replace(cancel_ack_withheld)
        if _CANCEL_ACK_WITHHOLD_S:
            time.sleep(_CANCEL_ACK_WITHHOLD_S)
        row['returned_ns'] = time.monotonic_ns()
        return result

    owner.cancel_guarded = cancel_with_delayed_ack
    instrumented_backend = {'value':None}

    def get_with_delayed_request():
        session = original_get()
        backend = session.backend
        if instrumented_backend['value'] is backend:
            return session
        if instrumented_backend['value'] is not None:
            raise RuntimeError('fixture backend changed after instrumentation')
        original_fake_input = xtest.fake_input
        original_sync = backend.d.sync
        if _OBLIGATION_PUBLISHER_TRACE:
            original_set_publisher = backend.set_input_obligation_publisher

            def traced_set_publisher(publisher):
                if publisher is None:
                    return original_set_publisher(None)

                def traced_publisher(keys, buttons):
                    started_ns = time.monotonic_ns()
                    publisher(keys, buttons)
                    row = {
                        'pid':os.getpid(),
                        'started_monotonic_ns':started_ns,
                        'completed_monotonic_ns':time.monotonic_ns(),
                        'keys':dict(keys),
                        'buttons':list(buttons),
                    }
                    with open(_OBLIGATION_PUBLISHER_TRACE, 'a',
                              encoding='utf-8') as trace:
                        trace.write(json.dumps(row, sort_keys=True) + '\n')

                return original_set_publisher(traced_publisher)

            backend.set_input_obligation_publisher = traced_set_publisher
        injected = {'value':False}
        sync_seen = {'value':False}
        first_keycode = {'value':None}
        keypress_count = {'value':0}

        def fake_input(display_connection, event_type, detail=0, time=0,
                       root=0, x=0, y=0):
            tracked_second_press = False
            if event_type == X.KeyPress and detail == backend._keycode('a'):
                keypress_count['value'] += 1
                tracked_second_press = (
                    _TRACKED_DELAYED_SECOND_PRESS
                    and keypress_count['value'] == 2)
            if tracked_second_press:
                proxy_arm = None
                if _SOCKET_DELIVERY_DELAY:
                    # Drain earlier X11 requests before arming the external
                    # proxy, so only this delayed press and its following tail
                    # are withheld before reaching the X server.
                    original_sync()
                    proxy_arm = _arm_x11_socket_delivery_proxy(
                        display_connection, _DELAY_MS)
                    result = original_fake_input(
                        display_connection, event_type, detail=detail,
                        time=0, root=root, x=x, y=y)
                else:
                    result = original_fake_input(
                        display_connection, event_type, detail=detail,
                        time=_DELAY_MS, root=root, x=x, y=y)
                display_connection.flush()
            else:
                proxy_arm = None
                result = original_fake_input(
                    display_connection, event_type, detail=detail, time=time,
                    root=root, x=x, y=y)
            if (tracked_second_press or
                    (not _TRACKED_DELAYED_SECOND_PRESS
                     and event_type == X.KeyPress and not injected['value'])):
                first_keycode['value'] = detail
                delayed_keycode = (detail if tracked_second_press
                                   else backend._keycode('b'))
                if not tracked_second_press:
                    original_fake_input(
                        display_connection, X.KeyPress, detail=delayed_keycode,
                        time=_DELAY_MS)
                    display_connection.flush()
                row = {
                    'owner_pid':os.getpid(),
                    'resource_base':display_connection.display.info.resource_id_base,
                    'delayed_request_source':(
                        'runtime_key_chord_second_keypress'
                        if tracked_second_press else 'fixture_direct_xtest_injection'),
                    'runtime_keypress_ordinal':keypress_count['value'],
                    'delayed_event':'KeyPress',
                    'delayed_keycode':delayed_keycode,
                    'delay_ms':_DELAY_MS,
                    'delivery_boundary':(
                        'user_space_tcp_proxy_before_xvfb_receive'
                        if _SOCKET_DELIVERY_DELAY else
                        'xtest_server_side_delay'),
                    'proxy_arm':proxy_arm,
                    'owner_tcp_local_address':(
                        list(display_connection.display.socket.getsockname())
                        if _SOCKET_DELIVERY_DELAY else None),
                    'flushed_ns':_monotonic_ns(),
                    'blocked_boundary':'real python-xlib Display.sync response wait',
                    'tracked_input_obligations':dict(backend.held_keycodes),
                }
                temporary = marker.with_suffix('.tmp')
                temporary.write_text(json.dumps(row, sort_keys=True),
                                      encoding='utf-8')
                temporary.replace(marker)
                injected['value'] = True
            if (injected['value'] and display_connection is backend.d
                    and event_type == X.KeyRelease
                    and detail == first_keycode['value'] and not release_queued.exists()):
                row = {'owner_pid':os.getpid(),
                       'resource_base':display_connection.display.info.resource_id_base,
                       'keycode':detail, 'queued_ns':_monotonic_ns(),
                       'server_release_confirmed':False,
                       'scope':'Xlib request call returned; no server acknowledgement'}
                temporary = release_queued.with_suffix('.tmp')
                temporary.write_text(json.dumps(row, sort_keys=True), encoding='utf-8')
                temporary.replace(release_queued)
            return result

        def sync_with_boundary_receipt(*args, **kwargs):
            if injected['value'] and not sync_seen['value']:
                sync_seen['value'] = True
                row = {'owner_pid':os.getpid(),
                       'resource_base':backend.d.display.info.resource_id_base,
                       'entered_ns':time.monotonic_ns(),
                       'call':'python-xlib Display.sync'}
                temporary = sync_entered.with_suffix('.tmp')
                temporary.write_text(json.dumps(row, sort_keys=True), encoding='utf-8')
                temporary.replace(sync_entered)
                result = original_sync(*args, **kwargs)
                returned = dict(row, returned_ns=time.monotonic_ns())
                temporary = sync_returned.with_suffix('.tmp')
                temporary.write_text(json.dumps(returned, sort_keys=True),
                                     encoding='utf-8')
                temporary.replace(sync_returned)
                return result
            return original_sync(*args, **kwargs)

        # The single-key chord queues UP behind the delayed XTEST request.
        # Its final real sync still waits for that earlier server request;
        # queueing UP is not a server-side release acknowledgement.
        xtest.fake_input = fake_input
        backend.d.sync = sync_with_boundary_receipt
        instrumented_backend['value'] = backend
        return session

    owner.get = get_with_delayed_request
    return owner


def _key_down(observer, keycode):
    keymap = observer.query_keymap()
    return bool(keymap[keycode//8] & (1 << (keycode % 8)))


def _effect_count(observer, window_id, atom):
    row = observer.create_resource_object('window', window_id).get_full_property(
        atom, X.AnyPropertyType)
    return list(row.value) if row is not None else None


def _assert_cancel_release_attempt(test_case, cancel, *, prestarted_supervisor,
                                   allow_not_attempted=False):
    """Check the arm's receipt contract without conflating it with task effects."""
    attempt = cancel.get('owner_release_attempt')
    test_case.assertIsInstance(attempt, dict, cancel)
    status = attempt.get('status')
    if prestarted_supervisor:
        test_case.assertEqual(status, 'readback_verified', cancel)
        test_case.assertIsInstance(attempt.get('release'), dict, cancel)
        test_case.assertIs(attempt['release'].get('verified'), True, cancel)
        return status

    if allow_not_attempted and status == 'not_attempted':
        test_case.assertEqual(attempt.get('reason'),
                              'owner_disconnect_not_confirmed', cancel)
        return status

    test_case.assertIn(status, ('readback_verified', 'unknown'), cancel)
    if status == 'readback_verified':
        test_case.assertIsInstance(attempt.get('release'), dict, cancel)
        test_case.assertIs(attempt['release'].get('verified'), True, cancel)
    else:
        test_case.assertFalse(cancel.get('release_confirmed'), cancel)
        test_case.assertEqual(cancel.get('cleanup_status'), 'UNKNOWN', cancel)
    return status


class CancellationReleaseAttemptAssertionTests(unittest.TestCase):
    def test_prestarted_supervisor_requires_verified_release_receipt(self):
        cancel = {'owner_release_attempt':{
            'status':'readback_verified', 'release':{'verified':True}}}
        self.assertEqual(_assert_cancel_release_attempt(
            self, cancel, prestarted_supervisor=True), 'readback_verified')

    def test_prestarted_supervisor_rejects_unknown_release_receipt(self):
        cancel = {'owner_release_attempt':{'status':'unknown'}}
        with self.assertRaises(AssertionError):
            _assert_cancel_release_attempt(
                self, cancel, prestarted_supervisor=True)

    def test_standard_caller_preserves_unknown_without_claiming_release(self):
        cancel = {'owner_release_attempt':{'status':'unknown'},
                  'release_confirmed':False, 'cleanup_status':'UNKNOWN'}
        self.assertEqual(_assert_cancel_release_attempt(
            self, cancel, prestarted_supervisor=False), 'unknown')

    def test_standard_caller_accepts_a_verified_release_receipt(self):
        cancel = {'owner_release_attempt':{
            'status':'readback_verified', 'release':{'verified':True}}}
        self.assertEqual(_assert_cancel_release_attempt(
            self, cancel, prestarted_supervisor=False), 'readback_verified')

    def test_standard_caller_rejects_unknown_upgraded_to_confirmed(self):
        cancel = {'owner_release_attempt':{'status':'unknown'},
                  'release_confirmed':True, 'cleanup_status':'UNKNOWN'}
        with self.assertRaises(AssertionError):
            _assert_cancel_release_attempt(
                self, cancel, prestarted_supervisor=False)


@unittest.skipUnless(
    sys.platform == 'linux' and os.environ.get('DISPLAY') == ':88'
    and os.environ.get('AGENT_INTERFACE_MCP_XVFB_TEST') == '1',
    'requires the explicitly enabled private Linux Xvfb integration job',
)
class StandardCallerBlockedReleaseXvfbTests(unittest.IsolatedAsyncioTestCase):
    async def _wait_for_file(self, path, timeout=3.0):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline and not path.exists():
            await asyncio.sleep(0.005)
        self.assertTrue(path.exists(), f'timed out waiting for {path.name}')
        return json.loads(path.read_text(encoding='utf-8'))

    async def _wait_for_event(self, event, timeout=2.0):
        completed = await asyncio.to_thread(event.wait, timeout)
        self.assertTrue(completed, f'timed out waiting for {event}')

    async def _wait_for_terminal(self, server, call_id, timeout=8.0):
        deadline = time.monotonic() + timeout
        while True:
            row = _metadata(await asyncio.wait_for(server.call_tool(
                'interface_results', {'call_id':call_id, 'include_image':False}),
                timeout=2.0))
            if row.get('status') != 'pending':
                return row
            if time.monotonic() >= deadline:
                return row
            await asyncio.sleep(0.05)

    async def _wait_for_cancellation_terminal(self, server, call_id, timeout=5.0):
        deadline = time.monotonic() + timeout
        latest = None
        while True:
            row = _metadata(await asyncio.wait_for(server.call_tool(
                'interface_results', {'call_id':call_id, 'include_image':False}),
                timeout=2.0))
            latest = row.get('cancellation')
            if (isinstance(latest, dict)
                    and latest.get('status') in ('completed', 'unknown')):
                return latest
            if time.monotonic() >= deadline:
                return latest
            await asyncio.sleep(0.05)

    async def _close_after_work(self, server, timeout=6.0):
        deadline = time.monotonic() + timeout
        while True:
            row = _metadata(await asyncio.wait_for(
                server.call_tool('interface_close', {}), timeout=2.0))
            if row.get('status') != 'busy' or time.monotonic() >= deadline:
                return row
            await asyncio.sleep(0.05)

    async def test_standard_caller_cancels_blocked_sync_and_releases_on_xvfb(self):
        result_path = os.environ.get('AGENT_INTERFACE_MCP_XVFB_BLOCKED_RELEASE_RESULT')
        report = {
            'schema':'agent-interface/standard-mcp-xvfb-blocked-release-v2',
            'status':'RUNNING',
            'scope':('standard MCP caller; private Xvfb; runtime-tracked delayed second press; synthetic app'
                     if _TRACKED_DELAYED_SECOND_PRESS else
                     'standard MCP caller; private Xvfb; fixture-injected delayed request; synthetic app'),
            'conditions':{
                'delayed_keypress_ms':_DELAY_MS,
                'tracked_delayed_second_press':_TRACKED_DELAYED_SECOND_PRESS,
                'socket_delivery_delay':_SOCKET_DELIVERY_DELAY,
                'socket_proxy_display':os.environ.get(
                    'AGENT_INTERFACE_MCP_XVFB_PROXY_DISPLAY')
                    if _SOCKET_DELIVERY_DELAY else None,
                'cancel_return_bound_ms':_CANCEL_BOUND_MS,
                'child_cancel_ack_withheld_s':_CANCEL_ACK_WITHHOLD_S,
                'owner_process_method_trace':_TRACE_OWNER_PROCESS_METHODS,
                'prestarted_cancel_supervisor':_PRESTARTED_CANCEL_SUPERVISOR,
                'continue_after_nonneutral_release':(
                    _CONTINUE_AFTER_NONNEUTRAL_RELEASE),
                'input_obligation_publisher_trace':bool(
                    _OBLIGATION_PUBLISHER_TRACE),
                'terminal_result_bound_ms':_TERMINAL_BOUND_MS,
                'late_keypress_outcome':'record either result; do not assume queue cancellation',
                'fresh_session_same_x_server':True,
                'fresh_target_is_distinct_window':True,
                'fresh_task_key':'c',
                'fresh_task_expected_effect':[3],
                'xvfb_server_pause_ms':_SERVER_PAUSE_MS,
                'cancellation_transaction_timeout_s':_TRANSACTION_TIMEOUT_S,
                'effect_multiplicity_evidence':'per-handler CARDINAL count; separate X-client readback',
            },
            'xvfb':_xvfb_provenance(),
            'source_identity':{
                'python':sys.version,
                'platform':platform.platform(),
                'github_sha':os.environ.get('GITHUB_SHA'),
                'github_run_id':os.environ.get('GITHUB_RUN_ID'),
                'github_job':os.environ.get('GITHUB_JOB'),
            },
            'timing_ns':{},
            'input_before_cancel':None,
            'cancel':None,
            'owner_release_attempt':None,
            'independent_release_readback':None,
            'late_request_horizon_readback':None,
            'synthetic_application_effect':None,
            'independent_task_oracle':None,
            'terminal':None,
            'final_cleanup':None,
        }
        app_display = observer = None
        server = None
        close_resolved = False
        app_thread = None
        fresh_window = None
        app_stop = threading.Event()
        effect_committed = threading.Event()
        a_release_seen = threading.Event()
        late_a_press_seen = threading.Event()
        b_press_seen = threading.Event()
        c_press_seen = threading.Event()
        fresh_a_press_seen = threading.Event()
        fresh_task_started = threading.Event()
        fresh_effect_atom = None
        fresh_server = None
        app_events = []
        app_lock = threading.Lock()
        owner_marker = None
        keycodes = None
        cancelled = False
        pending_call_id = None
        terminal_returned = False
        cleanup_errors = []
        xvfb_pause = None
        xvfb_resume_timer = None
        resume_xvfb = None

        with tempfile.TemporaryDirectory(prefix='mcp-xvfb-blocked-release-') as td:
            root = Path(td)
            try:
                app_display = display.Display()
                screen = app_display.screen()
                x, y, width, height = 40, 40, 240, 180
                window = screen.root.create_window(
                    x, y, width, height, 0, X.CopyFromParent, X.InputOutput,
                    X.CopyFromParent, background_pixel=0,
                    event_mask=(X.KeyPressMask | X.KeyReleaseMask |
                                X.StructureNotifyMask))
                effect_atom = app_display.intern_atom('AI_BLOCKED_RELEASE_EFFECT')
                fresh_effect_atom = app_display.intern_atom(
                    'AI_BLOCKED_RELEASE_FRESH_SESSION_EFFECT')
                count_atom = app_display.intern_atom('AI_BLOCKED_RELEASE_EFFECT_COUNT')
                effect_counts = {window.id:0}
                window.change_property(effect_atom, Xatom.CARDINAL, 32, [0])
                window.change_property(count_atom, Xatom.CARDINAL, 32, [0])
                window.map()
                window.set_input_focus(X.RevertToParent, X.CurrentTime)
                screen.root.warp_pointer(x+48, y+48)
                gc = window.create_gc(foreground=0xFFFFFF)
                for row in range((height+15)//16):
                    for column in range((width+15)//16):
                        if (row+column) % 2 == 0:
                            window.fill_rectangle(gc, column*16, row*16,
                                min(16, width-column*16),
                                min(16, height-row*16))
                fresh_window = screen.root.create_window(
                    x+300, y, width, height, 0, X.CopyFromParent,
                    X.InputOutput, X.CopyFromParent, background_pixel=0,
                    event_mask=(X.KeyPressMask | X.KeyReleaseMask |
                                X.StructureNotifyMask))
                fresh_window.change_property(fresh_effect_atom,
                                             Xatom.CARDINAL, 32, [0])
                effect_counts[fresh_window.id] = 0
                fresh_window.change_property(count_atom, Xatom.CARDINAL, 32, [0])
                fresh_window.map()
                fresh_gc = fresh_window.create_gc(foreground=0xFFFFFF)
                for row in range((height+15)//16):
                    for column in range((width+15)//16):
                        if (row+column) % 2 == 0:
                            fresh_window.fill_rectangle(fresh_gc,
                                column*16, row*16,
                                min(16, width-column*16),
                                min(16, height-row*16))
                app_display.sync()

                observer = display.Display()
                keycodes = {
                    name:observer.keysym_to_keycode(XK.string_to_keysym(name))
                    for name in ('a', 'b', 'c')
                }
                self.assertTrue(all(code > 0 for code in keycodes.values()), keycodes)
                for code in keycodes.values():
                    from Xlib.ext import xtest
                    xtest.fake_input(observer, X.KeyRelease, detail=code)
                observer.sync()
                report['initial_keymap'] = {
                    name:_key_down(observer, code) for name, code in keycodes.items()}
                self.assertFalse(any(report['initial_keymap'].values()), report)

                def run_synthetic_application():
                    while not app_stop.is_set():
                        if not app_display.pending_events():
                            time.sleep(0.002)
                            continue
                        event = app_display.next_event()
                        now = time.monotonic_ns()
                        event_window = getattr(event, 'window', None)
                        event_window_id = getattr(event_window, 'id',
                                                  event_window)
                        with app_lock:
                            row = {'type':event.type,
                                   'detail':getattr(event, 'detail', None),
                                   'window':event_window_id,
                                   'monotonic_ns':now}
                            app_events.append(row)
                        if (event.type == X.KeyPress
                                and event.detail == keycodes['a']
                                and fresh_task_started.is_set()
                                and event_window_id == fresh_window.id):
                            effect_counts[fresh_window.id] += 1
                            fresh_window.change_property(count_atom, Xatom.CARDINAL,
                                32, [effect_counts[fresh_window.id]])
                            fresh_window.change_property(fresh_effect_atom,
                                Xatom.CARDINAL, 32, [4])
                            app_display.sync()
                            with app_lock:
                                app_events[-1]['effect_committed_ns'] = time.monotonic_ns()
                            fresh_a_press_seen.set()
                        elif (event.type == X.KeyPress
                                and event.detail == keycodes['a']
                                and event_window_id == window.id):
                            effect_counts[window.id] += 1
                            if effect_counts[window.id] > 1:
                                late_a_press_seen.set()
                            window.change_property(count_atom, Xatom.CARDINAL,
                                                   32, [effect_counts[window.id]])
                            window.change_property(effect_atom, Xatom.CARDINAL,
                                                   32, [1])
                            app_display.sync()
                            with app_lock:
                                app_events[-1]['effect_committed_ns'] = time.monotonic_ns()
                            effect_committed.set()
                        elif event.type == X.KeyRelease and event.detail == keycodes['a']:
                            a_release_seen.set()
                        elif (event.type == X.KeyPress
                                and event.detail == keycodes['b']):
                            if (fresh_task_started.is_set()
                                    and event_window_id == fresh_window.id):
                                effect_counts[fresh_window.id] += 1
                                fresh_window.change_property(count_atom, Xatom.CARDINAL,
                                    32, [effect_counts[fresh_window.id]])
                                fresh_window.change_property(fresh_effect_atom,
                                    Xatom.CARDINAL, 32, [2])
                            elif event_window_id == window.id:
                                effect_counts[window.id] += 1
                                window.change_property(count_atom, Xatom.CARDINAL,
                                    32, [effect_counts[window.id]])
                                window.change_property(effect_atom,
                                    Xatom.CARDINAL, 32, [2])
                            app_display.sync()
                            b_press_seen.set()
                            with app_lock:
                                app_events[-1]['effect_committed_ns'] = time.monotonic_ns()
                        elif (event.type == X.KeyPress
                                and event.detail == keycodes['c']
                                and event_window_id == fresh_window.id):
                            effect_counts[fresh_window.id] += 1
                            fresh_window.change_property(count_atom, Xatom.CARDINAL,
                                32, [effect_counts[fresh_window.id]])
                            fresh_window.change_property(fresh_effect_atom,
                                Xatom.CARDINAL, 32, [3])
                            app_display.sync()
                            with app_lock:
                                app_events[-1]['effect_committed_ns'] = time.monotonic_ns()
                            c_press_seen.set()

                app_thread = threading.Thread(
                    target=run_synthetic_application,
                    name='xvfb-blocked-release-app', daemon=True)
                app_thread.start()

                owner_output_root = root/'mcp'
                report['owner_marker_directory'] = str(owner_output_root)
                server = create_server(
                    {'app':window.id}, owner_output_root,
                    display_name=(os.environ.get(
                        'AGENT_INTERFACE_MCP_XVFB_PROXY_DISPLAY')
                        if _SOCKET_DELIVERY_DELAY else None),
                    session_mode='guarded-x11',
                    guarded_process_identity=True, guarded_query_worker=True,
                    guarded_window_lifecycle=True, guarded_owned_process=True,
                    guarded_retention_mode=_RETENTION_MODE,
                    guarded_prestarted_cancel_supervisor=(
                        _PRESTARTED_CANCEL_SUPERVISOR),
                    _guarded_cancel_transaction_timeout_s=(
                        _TRANSACTION_TIMEOUT_S),
                    _guarded_owner_factory=_xvfb_blocking_owner_factory)

                report['timing_ns']['observe_started'] = time.monotonic_ns()
                observed = _metadata(await server.call_tool(
                    'interface_guarded_observe', {}))
                report['timing_ns']['observe_returned'] = time.monotonic_ns()
                report['observation'] = {
                    'status':observed.get('status'),
                    'process_generation':observed.get('source', {}).get(
                        'pointer_binding', {}).get('process_generation'),
                    'sequence':observed.get('source', {}).get('sequence'),
                    'xvfb':observer.display.info.vendor,
                }
                self.assertEqual(observed['status'], 'observed', observed)
                source = observed['source']
                binding = source['pointer_binding']
                report['observation']['pointer_binding'] = binding
                self.assertRegex(binding.get('process_generation', ''), r'^[0-9a-f]{64}$')
                self.assertRegex(binding.get('window_generation', ''), r'^[0-9a-f]{64}$')
                image_artifact = observed['observation_report']['observation']['artifact']
                image_path = Path(image_artifact['path'])
                image_bytes = image_path.read_bytes()
                image = Image.open(io.BytesIO(image_bytes)).convert('RGB')
                patch = image.crop((x+36, y+36, x+60, y+60))
                patch_stddev = ImageStat.Stat(patch).stddev
                report['mint_source_patch'] = {
                    'box':[x+36,y+36,x+60,y+60],
                    'stddev':patch_stddev,
                    'capture_sha256':image_artifact['sha256'],
                    'capture_bytes':image_artifact['bytes'],
                }
                self.assertGreaterEqual(max(patch_stddev), 8.0, report)
                if result_path:
                    retained_image = Path(result_path).with_suffix('.observation.png')
                    retained_image.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(image_path, retained_image)
                    report['mint_source_patch']['retained_image'] = str(retained_image)
                    report['mint_source_patch']['retained_image_sha256'] = hashlib.sha256(
                        retained_image.read_bytes()).hexdigest()

                minted = _metadata(await server.call_tool('interface_guarded_mint', {
                    'alias':'field', 'source_sequence':source['sequence'],
                    'point':[x+48,y+48], 'region_size':[24,24]}))
                report['mint'] = minted
                self.assertEqual(minted['status'], 'minted', minted)

                report['timing_ns']['input_started'] = time.monotonic_ns()
                pending = _metadata(await server.call_tool('interface_guarded_input', {
                    'alias':'field', 'offset':minted['offset'],
                    'interaction':'keyboard', 'observe_after':False,
                    'wait_for_result_ms':0,
                    'tail':([
                        {'op':'key_chord', 'keys':['a']},
                        {'op':'key_chord', 'keys':['a']},
                    ] if _TRACKED_DELAYED_SECOND_PRESS else [
                        {'op':'key_chord', 'keys':['a']},
                    ])}))
                report['timing_ns']['pending_returned'] = time.monotonic_ns()
                report['pending'] = {'status':pending.get('status'),
                                     'call_id':pending.get('call_id')}
                self.assertEqual(pending['status'], 'pending', pending)
                pending_call_id = pending['call_id']

                owner_marker = await self._wait_for_file(
                    owner_output_root/'xvfb-delayed-request-queued.json')
                report['owner_delayed_request'] = owner_marker
                self.assertEqual(owner_marker['delay_ms'], _DELAY_MS, owner_marker)
                sync_marker = await self._wait_for_file(
                    owner_output_root/'xvfb-owner-sync-entered.json')
                report['blocked_owner_sync'] = sync_marker
                self.assertEqual(sync_marker['owner_pid'], owner_marker['owner_pid'])
                self.assertEqual(sync_marker['resource_base'], owner_marker['resource_base'])
                if _OBLIGATION_PUBLISHER_TRACE:
                    trace_path = Path(_OBLIGATION_PUBLISHER_TRACE)
                    if trace_path.exists():
                        report['input_obligation_publisher_trace_before_cancel'] = [
                            json.loads(line) for line in
                            trace_path.read_text(encoding='utf-8').splitlines()
                            if line.strip()]
                report['owner_target_release_queued'] = await self._wait_for_file(
                    owner_output_root/'xvfb-target-release-queued.json')
                self.assertLessEqual(report['owner_target_release_queued']['queued_ns'],
                                     sync_marker['entered_ns'])
                await self._wait_for_event(effect_committed)
                before_cancel_effect = observer.create_resource_object(
                    'window', window.id).get_full_property(effect_atom, X.AnyPropertyType)
                before_cancel_value = (
                    list(before_cancel_effect.value) if before_cancel_effect is not None else None)
                before_cancel_count = _effect_count(observer, window.id, count_atom)
                report['effect_before_cancel'] = {
                    'property_value':before_cancel_value,
                    'effect_count':before_cancel_count,
                    'reader':'separate parent X client',
                    'observed_ns':time.monotonic_ns(),
                }
                self.assertEqual(before_cancel_value, [1], report)
                down_before = {
                    name:_key_down(observer, keycodes[name])
                    for name in ('a','b')}
                report['input_before_cancel'] = {
                    'keys_down':down_before,
                    'synthetic_effect_committed':True,
                    'observed_ns':time.monotonic_ns(),
                    'owner_sync_return_receipt_present':(
                        (root/'xvfb-owner-sync-returned.json').exists()),
                }
                expected_down_before = (
                    {'a':False,'b':False} if _TRACKED_DELAYED_SECOND_PRESS
                    else {'a':True,'b':False})
                self.assertEqual(down_before, expected_down_before, report)
                self.assertFalse(
                    report['input_before_cancel']['owner_sync_return_receipt_present'],
                    report)

                cancel_internal_trace = {
                    'cancel_entries':[], 'cancel_returns':[],
                    'retirement_decisions':[], 'retire_calls':[],
                    'owner_process_calls':[]}
                def describe_owner_process(owned):
                    process = getattr(owned, '_process', None)
                    row = {
                        'caller_pid':os.getpid(),
                        'caller_thread':threading.current_thread().name,
                        'owner_object_id':id(owned),
                        'process_present':process is not None,
                        'control_present':getattr(owned, '_control', None) is not None,
                    }
                    if process is None:
                        return row
                    row.update(
                        process_type=type(process).__module__+'.'+type(process).__qualname__,
                        process_pid=getattr(process, 'pid', None),
                        process_parent_pid=getattr(process, '_parent_pid', None),
                        process_popen_present=getattr(process, '_popen', None) is not None,
                        process_kill_callable=callable(getattr(process, 'kill', None)))
                    popen = getattr(process, '_popen', None)
                    row['process_returncode'] = getattr(popen, 'returncode', None)
                    try:
                        row['process_alive'] = process.is_alive()
                    except BaseException as error:
                        row['process_alive_error'] = repr(error)
                    try:
                        row['process_exitcode'] = process.exitcode
                    except BaseException as error:
                        row['process_exitcode_error'] = repr(error)
                    return row

                original_decision_method = (
                    OwnedGuardedSessionOwner._cancel_requires_owner_retirement)
                original_retire = OwnedGuardedSessionOwner._retire
                original_cancel = OwnedGuardedSessionOwner.cancel_guarded

                def traced_cancel(owned, token, *, operation_id=None,
                                  deadline_monotonic_ns=None):
                    entry = describe_owner_process(owned)
                    cancel_internal_trace['cancel_entries'].append(entry)
                    started_ns = time.monotonic_ns()
                    try:
                        result = original_cancel(owned, token,
                            operation_id=operation_id,
                            deadline_monotonic_ns=deadline_monotonic_ns)
                    except BaseException as error:
                        cancel_internal_trace['cancel_returns'].append({
                            'elapsed_ms':(time.monotonic_ns()-started_ns)/1_000_000,
                            'error_type':type(error).__name__,
                            'error':repr(error),
                            'process_after':describe_owner_process(owned),
                        })
                        raise
                    cancel_internal_trace['cancel_returns'].append({
                        'elapsed_ms':(time.monotonic_ns()-started_ns)/1_000_000,
                        'status':result.get('status') if isinstance(result, dict) else None,
                        'owner_process_retired':result.get('owner_process_retired')
                            if isinstance(result, dict) else None,
                        'owner_process_exitcode':result.get('owner_process_exitcode')
                            if isinstance(result, dict) else None,
                        'process_after':describe_owner_process(owned),
                    })
                    return result

                def traced_retirement_decision(owned, result):
                    required = original_decision_method(owned, result)
                    cancel_internal_trace['retirement_decisions'].append({
                        'required':required,
                        'result_status':result.get('status'),
                        'result_owner_process_retired':result.get('owner_process_retired'),
                        'result_late_server_request_possible':result.get(
                            'late_server_request_possible'),
                        'result_obligations':result.get('owner_input_obligations'),
                        'cached_obligations':getattr(
                            owned, '_owner_input_obligations', None),
                        'cached_snapshot_owner_pid':owned._snapshot_cache.get(
                            'owner_process_pid'),
                        'process':describe_owner_process(owned),
                    })
                    return required

                def traced_retire(owned, reason):
                    process = getattr(owned, '_process', None)
                    before_alive = process.is_alive() if process is not None else None
                    started_ns = time.monotonic_ns()
                    original_process_methods = {}
                    if process is not None and _TRACE_OWNER_PROCESS_METHODS:
                        for method_name in ('is_alive', 'terminate', 'join', 'kill'):
                            original_method = getattr(process, method_name, None)
                            if not callable(original_method):
                                continue
                            original_process_methods[method_name] = original_method

                            def traced_process_method(*args, _name=method_name,
                                                     _method=original_method, **kwargs):
                                method_started_ns = time.monotonic_ns()
                                row = {'method':_name, 'args':list(args),
                                       'kwargs':dict(kwargs)}
                                try:
                                    result = _method(*args, **kwargs)
                                except BaseException as error:
                                    row.update(error_type=type(error).__name__,
                                               error=repr(error))
                                    raise
                                else:
                                    if result is None or type(result) in (bool, int, float, str):
                                        row['result'] = result
                                    else:
                                        row['result_type'] = type(result).__name__
                                    return result
                                finally:
                                    row['elapsed_ms'] = (
                                        time.monotonic_ns()-method_started_ns)/1_000_000
                                    cancel_internal_trace['owner_process_calls'].append(row)

                            setattr(process, method_name, traced_process_method)
                    try:
                        result = original_retire(owned, reason)
                    except BaseException as error:
                        for method_name, original_method in original_process_methods.items():
                            setattr(process, method_name, original_method)
                        cancel_internal_trace['retire_calls'].append({
                            'reason':reason,
                            'elapsed_ms':(time.monotonic_ns()-started_ns)/1_000_000,
                            'before_alive':before_alive,
                            'process':describe_owner_process(owned),
                            'error_type':type(error).__name__,
                            'error':repr(error),
                        })
                        raise
                    for method_name, original_method in original_process_methods.items():
                        setattr(process, method_name, original_method)
                    cancel_internal_trace['retire_calls'].append({
                        'reason':reason,
                        'elapsed_ms':(time.monotonic_ns()-started_ns)/1_000_000,
                        'before_alive':before_alive,
                        'retired':result.get('retired'),
                        'exitcode':result.get('exitcode'),
                        'configured_terminate_grace_s':(
                            owned_session_module._RETIRE_TERMINATE_GRACE_S),
                        'configured_kill_grace_s':(
                            owned_session_module._RETIRE_KILL_GRACE_S),
                        'alive_after':process.is_alive() if process is not None else None,
                        'process_after':describe_owner_process(owned),
                    })
                    return result

                report['timing_ns']['cancel_started'] = time.monotonic_ns()
                original_retire_method = OwnedGuardedSessionOwner._retire
                original_cancel_method = OwnedGuardedSessionOwner.cancel_guarded
                cancel_heartbeat_stop = asyncio.Event()
                cancel_heartbeat = {'max_gap_ns':0, 'samples':0}

                async def sample_cancel_event_loop():
                    previous_ns = time.monotonic_ns()
                    while not cancel_heartbeat_stop.is_set():
                        await asyncio.sleep(0.001)
                        current_ns = time.monotonic_ns()
                        cancel_heartbeat['max_gap_ns'] = max(
                            cancel_heartbeat['max_gap_ns'], current_ns-previous_ns)
                        cancel_heartbeat['samples'] += 1
                        previous_ns = current_ns

                OwnedGuardedSessionOwner._cancel_requires_owner_retirement = (
                    traced_retirement_decision)
                OwnedGuardedSessionOwner._retire = traced_retire
                OwnedGuardedSessionOwner.cancel_guarded = traced_cancel
                heartbeat_task = asyncio.create_task(sample_cancel_event_loop())
                try:
                    try:
                        if _SERVER_PAUSE_MS:
                            (xvfb_pause, xvfb_resume_timer,
                             resume_xvfb) = _pause_owned_xvfb_for_test(
                                 _SERVER_PAUSE_MS)
                            report['xvfb_server_pause'] = xvfb_pause
                            # Let the kernel's stopped state settle before the
                            # public caller enters its cancellation path.
                            await asyncio.sleep(0.05)
                        report['timing_ns']['cancel_tool_invoked'] = (
                            time.monotonic_ns())
                        cancel_response = _metadata(await server.call_tool(
                            'interface_guarded_cancel', {'call_id':pending['call_id']}))
                    finally:
                        report['timing_ns']['cancel_returned'] = time.monotonic_ns()
                        cancel_heartbeat_stop.set()
                        await heartbeat_task
                    cancelled = True
                    cancellation = await self._wait_for_cancellation_terminal(
                        server, pending['call_id'], timeout=_TERMINAL_BOUND_MS/1000)
                finally:
                    if xvfb_resume_timer is not None:
                        if xvfb_resume_timer.is_alive() and resume_xvfb is not None:
                            resume_xvfb()
                            xvfb_resume_timer.cancel()
                        xvfb_resume_timer.join(timeout=1.0)
                        report['xvfb_server_pause']['resume_receipt'] = (
                            dict(xvfb_pause['resumed']) if xvfb_pause else None)
                        if xvfb_pause and xvfb_pause['resumed']['monotonic_ns']:
                            report['xvfb_server_pause']['observed_pause_ms'] = (
                                xvfb_pause['resumed']['monotonic_ns']
                                - xvfb_pause['stopped_monotonic_ns'])/1_000_000
                    OwnedGuardedSessionOwner._cancel_requires_owner_retirement = (
                        original_decision_method)
                    OwnedGuardedSessionOwner._retire = original_retire_method
                    OwnedGuardedSessionOwner.cancel_guarded = original_cancel_method
                cancel_elapsed_ms = (
                    report['timing_ns']['cancel_returned']
                    - report['timing_ns']['cancel_started'])/1_000_000
                report['cancel_elapsed_ms'] = cancel_elapsed_ms
                cancel_invocation_elapsed_ms = (
                    report['timing_ns']['cancel_returned']
                    - report['timing_ns']['cancel_tool_invoked'])/1_000_000
                report['cancel_invocation_elapsed_ms'] = (
                    cancel_invocation_elapsed_ms)
                report['cancel_response'] = cancel_response
                report['cancel_event_loop_timing'] = {
                    'heartbeat_period_ms':1,
                    'max_gap_ms':cancel_heartbeat['max_gap_ns']/1_000_000,
                    'samples':cancel_heartbeat['samples'],
                }
                report['cancel_internal_trace'] = cancel_internal_trace
                report['cancellation_terminal'] = cancellation
                self.assertLess(cancel_elapsed_ms, _CANCEL_BOUND_MS, cancel_response)
                self.assertLessEqual(cancel_invocation_elapsed_ms, 300,
                    {'elapsed_ms':cancel_invocation_elapsed_ms,
                     'admission_to_response_ms':(
                         report['timing_ns']['cancel_returned']
                         - cancel_response['cancellation'][
                             'admitted_monotonic_ns'])/1_000_000})
                if cancel_response.get('status') == 'pending':
                    self.assertTrue(cancel_response.get('operation_id'), cancel_response)
                    self.assertFalse(cancel_response.get('release_confirmed'), cancel_response)
                    self.assertEqual(cancel_response.get('cleanup_status'), 'UNKNOWN',
                                     cancel_response)
                    self.assertIsNone(cancel_response.get('task_success'), cancel_response)
                    self.assertFalse(cancel_response.get('replay_allowed'), cancel_response)
                self.assertIsInstance(cancellation, dict, cancel_response)
                self.assertIn(cancellation.get('status'), ('completed', 'unknown'),
                              cancellation)
                cancel = deepcopy(cancellation.get('result') or cancel_response)
                cancel['operation_id'] = cancellation.get(
                    'operation_id', cancel_response.get('operation_id'))
                cancel['cancellation'] = deepcopy(cancellation)
                report['cancel'] = cancel
                expected_cancel_status = (
                    'cancel_unconfirmed' if _CANCEL_ACK_WITHHOLD_S
                    else 'cancel_requested')
                self.assertEqual(cancel.get('status'), expected_cancel_status, cancel)
                if _CANCEL_ACK_WITHHOLD_S:
                    self.assertIsNone(cancel.get('input_dispatched'), cancel)
                else:
                    self.assertFalse(cancel.get('input_dispatched'), cancel)
                ack_marker = owner_output_root/'xvfb-cancel-ack-withheld.json'
                self.assertTrue(ack_marker.exists(), report)
                report['cancel_control_ack_withheld'] = json.loads(
                    ack_marker.read_text(encoding='utf-8'))
                process_calls = cancel_internal_trace['owner_process_calls']
                if _TRACE_OWNER_PROCESS_METHODS:
                    self.assertTrue(process_calls, cancel_internal_trace)
                else:
                    self.assertEqual(process_calls, [], cancel_internal_trace)
                self.assertTrue(cancel.get('owner_process_retired'), cancel)
                owner_disconnect = cancel.get('owner_client_disconnect', {})
                if _SOCKET_DELIVERY_DELAY:
                    # XRes process identity can be ambiguous when the X server
                    # sees the relay as the TCP peer. Keep this UNKNOWN and do
                    # not claim cleanup or release confirmation.
                    self.assertEqual(owner_disconnect.get('status'), 'unknown', cancel)
                    self.assertEqual(owner_disconnect.get('reason'), 'query_failed', cancel)
                    self.assertIn('missing or ambiguous X-Resource process identity',
                                  owner_disconnect.get('error', ''), cancel)
                else:
                    self.assertEqual(owner_disconnect.get('status'),
                                     'disconnected', cancel)
                _assert_cancel_release_attempt(
                    self, cancel,
                    prestarted_supervisor=_PRESTARTED_CANCEL_SUPERVISOR,
                    allow_not_attempted=_SOCKET_DELIVERY_DELAY)
                self.assertFalse(cancel.get('release_confirmed'), cancel)
                self.assertEqual(cancel.get('cleanup_status'), 'UNKNOWN', cancel)
                self.assertIsNone(cancel.get('task_success'), cancel)
                self.assertFalse(cancel.get('replay_allowed'), cancel)
                self.assertTrue(cancel.get('late_server_request_possible'), cancel)

                await self._wait_for_event(a_release_seen)
                release_readback = {
                    name:_key_down(observer, keycodes[name]) for name in ('a','b')}
                report['independent_release_readback'] = {
                    'keys_down':release_readback,
                    'owner_release_attempt':cancel['owner_release_attempt'],
                    'reader':'separate parent X client',
                    'observed_ns':time.monotonic_ns(),
                    'neutral':release_readback == {'a':False,'b':False},
                }
                if (not _CONTINUE_AFTER_NONNEUTRAL_RELEASE
                        or release_readback == {'a':False,'b':False}):
                    self.assertEqual(release_readback,
                                     {'a':False,'b':False}, report)
                elif _OBLIGATION_PUBLISHER_TRACE:
                    trace_path = Path(_OBLIGATION_PUBLISHER_TRACE)
                    if trace_path.exists():
                        report['input_obligation_publisher_trace_after_cancel'] = [
                            json.loads(line) for line in
                            trace_path.read_text(encoding='utf-8').splitlines()
                            if line.strip()]

                # Probe recovery on the same X server while the old call still
                # truthfully carries late_server_request_possible=true.  The
                # delayed old KeyPress is intentionally allowed to produce
                # either result; the independent fresh-task oracle records
                # whether it contaminated the new task after its own effect.
                fresh_output_root = owner_output_root.parent/'fresh-session-mcp'
                fresh_session_started_ns = time.monotonic_ns()
                fresh_task_started.set()
                fresh_window.set_input_focus(X.RevertToParent, X.CurrentTime)
                screen.root.warp_pointer(x+300+48, y+48)
                app_display.sync()
                fresh_server = create_server(
                    {'app':fresh_window.id}, fresh_output_root,
                    session_mode='guarded-x11', guarded_process_identity=True,
                    guarded_query_worker=True, guarded_window_lifecycle=True,
                    guarded_owned_process=True,
                    guarded_retention_mode=_RETENTION_MODE)
                fresh_observed = _metadata(await fresh_server.call_tool(
                    'interface_guarded_observe', {}))
                fresh_minted = _metadata(await fresh_server.call_tool(
                    'interface_guarded_mint', {
                        'alias':'fresh_field',
                        'source_sequence':fresh_observed['source']['sequence'],
                        'point':[x+300+48,y+48], 'region_size':[24,24]}))
                self.assertEqual(fresh_observed['status'], 'observed', fresh_observed)
                self.assertEqual(fresh_minted['status'], 'minted', fresh_minted)
                self.assertNotEqual(fresh_observed['session']['session_id'],
                                    cancellation.get('owner_generation', {}).get(
                                        'session_id'), fresh_observed)
                self.assertNotEqual(fresh_observed['source']['pointer_binding'][
                    'surface'], window.id, fresh_observed)
                self.assertNotEqual(
                    fresh_observed['source']['pointer_binding'].get(
                        'window_generation'),
                    report['observation']['pointer_binding'].get(
                        'window_generation'), fresh_observed)
                fresh_effect_before_input = observer.create_resource_object(
                    'window', fresh_window.id).get_full_property(
                        fresh_effect_atom, X.AnyPropertyType)
                fresh_effect_before_input = (
                    list(fresh_effect_before_input.value)
                    if fresh_effect_before_input is not None else None)
                fresh_count_before_input = _effect_count(observer, fresh_window.id, count_atom)
                fresh_start_ns = time.monotonic_ns()
                fresh_input_started_ns = time.monotonic_ns()
                fresh_input = _metadata(await fresh_server.call_tool(
                    'interface_guarded_input', {
                        'alias':'fresh_field', 'offset':fresh_minted['offset'],
                        'interaction':'keyboard', 'observe_after':False,
                        'wait_for_result_ms':10000,
                        'tail':[{'op':'key_chord','keys':['c']}]}))
                fresh_input_returned_ns = time.monotonic_ns()
                await self._wait_for_event(c_press_seen)
                fresh_event_signal_returned_ns = time.monotonic_ns()
                with app_lock:
                    fresh_effect_events = [dict(row) for row in app_events
                        if row.get('type') == X.KeyPress
                        and row.get('detail') == keycodes['c']
                        and row.get('window') == fresh_window.id
                        and type(row.get('effect_committed_ns')) is int]
                self.assertEqual(len(fresh_effect_events), 1, app_events)
                fresh_app_event = fresh_effect_events[0]
                fresh_event_seen_ns = fresh_app_event['monotonic_ns']
                fresh_effect_committed_ns = fresh_app_event['effect_committed_ns']
                fresh_effect_readback_started_ns = time.monotonic_ns()
                fresh_effect_after_action = observer.create_resource_object(
                    'window', fresh_window.id).get_full_property(
                        fresh_effect_atom, X.AnyPropertyType)
                fresh_effect_after_action = (list(fresh_effect_after_action.value)
                    if fresh_effect_after_action is not None else None)
                fresh_count_after_action = _effect_count(observer, fresh_window.id, count_atom)
                fresh_effect_readback_completed_ns = time.monotonic_ns()
                fresh_effect_timing_ms = {
                    'input_invocation_to_keypress_observed':(
                        fresh_event_seen_ns-fresh_input_started_ns)/1_000_000,
                    'keypress_observed_to_application_effect_commit':(
                        fresh_effect_committed_ns-fresh_event_seen_ns)/1_000_000,
                    'input_invocation_to_application_effect_commit':(
                        fresh_effect_committed_ns-fresh_input_started_ns
                        )/1_000_000,
                    'application_effect_commit_to_independent_readback_completed':(
                        fresh_effect_readback_completed_ns-fresh_effect_committed_ns
                        )/1_000_000,
                    'parent_event_signal_return_to_independent_readback_completed':(
                        fresh_effect_readback_completed_ns
                        -fresh_event_signal_returned_ns)/1_000_000,
                    'input_invocation_to_effect_readback_completed':(
                        fresh_effect_readback_completed_ns-fresh_input_started_ns
                        )/1_000_000,
                    'input_return_to_effect_readback_completed':(
                        fresh_effect_readback_completed_ns-fresh_input_returned_ns
                        )/1_000_000,
                    'effect_readback_duration':(
                        fresh_effect_readback_completed_ns
                        -fresh_effect_readback_started_ns)/1_000_000,
                }
                fresh_release_readback = {
                    name:_key_down(observer, keycodes[name])
                    for name in ('a','b','c')}
                report['fresh_session_recovery'] = {
                    'old_cancellation_fence':{
                        'cleanup_status':cancel.get('cleanup_status'),
                        'late_server_request_possible':cancel.get(
                            'late_server_request_possible'),
                        'release_confirmed':cancel.get('release_confirmed'),
                        'replay_allowed':cancel.get('replay_allowed'),
                    },
                    'new_session_id':fresh_observed['session']['session_id'],
                    'new_target_xid':fresh_window.id,
                    'new_process_generation':fresh_observed.get('source', {}).get(
                        'pointer_binding', {}).get('process_generation'),
                    'input_status':fresh_input.get('status'),
                    'input_call_id':fresh_input.get('call_id'),
                    'effect_before_input':fresh_effect_before_input,
                    'effect_after_input':fresh_effect_after_action,
                    'effect_count_before_input':fresh_count_before_input,
                    'effect_count_after_input':fresh_count_after_action,
                    'input_started_monotonic_ns':fresh_input_started_ns,
                    'input_returned_monotonic_ns':fresh_input_returned_ns,
                    'keypress_event_observed_monotonic_ns':fresh_event_seen_ns,
                    'application_effect_committed_monotonic_ns':(
                        fresh_effect_committed_ns),
                    'parent_event_signal_returned_monotonic_ns':(
                        fresh_event_signal_returned_ns),
                    'effect_readback_started_monotonic_ns':(
                        fresh_effect_readback_started_ns),
                    'effect_readback_completed_monotonic_ns':(
                        fresh_effect_readback_completed_ns),
                    'effect_timing_ms':fresh_effect_timing_ms,
                    'release_readback_after_input':fresh_release_readback,
                    'session_start_monotonic_ns':fresh_session_started_ns,
                    'start_monotonic_ns':fresh_start_ns,
                }
                self.assertEqual(fresh_input.get('status'), 'completed', fresh_input)

                horizon_ns = (report['timing_ns']['cancel_started']
                              + (_DELAY_MS+500)*1_000_000)
                while time.monotonic_ns() < horizon_ns:
                    await asyncio.sleep(min(0.02,
                        (horizon_ns-time.monotonic_ns())/1_000_000_000))
                late = {name:_key_down(observer, code)
                        for name, code in keycodes.items()}
                if late['a'] and _TRACKED_DELAYED_SECOND_PRESS:
                    event_deadline = time.monotonic()+1.0
                    while (not late_a_press_seen.is_set()
                           and not fresh_a_press_seen.is_set()
                           and time.monotonic() < event_deadline):
                        await asyncio.sleep(0.005)
                    self.assertTrue(late_a_press_seen.is_set()
                                    or fresh_a_press_seen.is_set(), report)
                if late['b']:
                    await self._wait_for_event(b_press_seen)
                effect = observer.create_resource_object('window', window.id).get_full_property(
                    effect_atom, X.AnyPropertyType)
                effect_value = list(effect.value) if effect is not None else None
                final_effect_count = _effect_count(observer, window.id, count_atom)
                report['late_request_horizon_readback'] = {
                    'keys_down':late,
                    'late_keypress_b_observed':late['b'],
                    'late_keypress_a_observed':late_a_press_seen.is_set(),
                    'ms_after_cancel_start':(
                        time.monotonic_ns()-report['timing_ns']['cancel_started'])/1_000_000,
                    'reader':'separate parent X client',
                    'observed_ns':time.monotonic_ns(),
                }
                report['synthetic_application_effect'] = {
                    'before_cancel_property_value':before_cancel_value,
                    'property_value':effect_value,
                    'effect_count_before_cancel':before_cancel_count,
                    'effect_count_at_horizon':final_effect_count,
                    'expected_initial_key_effect':[1],
                    'task_success':None,
                    'independent_reader':'separate parent X client',
                    'app_key_events':None,
                    'late_b_press_event_seen':b_press_seen.is_set(),
                }
                with app_lock:
                    report['synthetic_application_effect']['app_key_events'] = list(app_events)
                report['independent_task_oracle'] = {
                    'scope':'synthetic Xvfb task only; runtime task_success remains null',
                    'reader':'synthetic app property plus independent parent keymap',
                    'task_definition':(
                        'one initial a effect; no delayed request effect; both keys '
                        'up after release and at the delayed-request horizon'),
                    'expected_effect':[1],
                    'measurements':{
                        'initial_effect':before_cancel_value,
                        'final_effect':effect_value,
                        'initial_effect_count':before_cancel_count,
                        'final_effect_count':final_effect_count,
                        'release_readback':release_readback,
                        'horizon_readback':late,
                    },
                    **score_counted_synthetic_application_task(
                        initial_effect=before_cancel_value,
                        final_effect=effect_value,
                        initial_effect_count=before_cancel_count,
                        final_effect_count=final_effect_count,
                        release_readback=release_readback,
                        horizon_readback={'a':late['a'], 'b':late['b']}),
                }
                final_fresh_effect = observer.create_resource_object(
                    'window', fresh_window.id).get_full_property(
                        fresh_effect_atom, X.AnyPropertyType)
                final_fresh_effect = (list(final_fresh_effect.value)
                    if final_fresh_effect is not None else None)
                final_fresh_count = _effect_count(observer, fresh_window.id, count_atom)
                fresh_count_oracle = score_synthetic_effect_counts(
                    before_count=fresh_count_before_input, after_count=fresh_count_after_action,
                    horizon_count=final_fresh_count)
                with app_lock:
                    late_b_after_fresh_start = any(
                        row.get('type') == X.KeyPress
                        and row.get('detail') == keycodes['b']
                        and row.get('monotonic_ns', 0) >= fresh_session_started_ns
                        for row in app_events)
                    late_a_after_fresh_start = any(
                        row.get('type') == X.KeyPress
                        and row.get('detail') == keycodes['a']
                        and row.get('window') == fresh_window.id
                        and row.get('monotonic_ns', 0) >= fresh_session_started_ns
                        for row in app_events)
                    old_input_events_before_fresh_action = [
                        {key:row.get(key) for key in
                         ('type','detail','window','monotonic_ns',
                          'effect_committed_ns')}
                        for row in app_events
                        if row.get('type') == X.KeyPress
                        and row.get('detail') in (keycodes['a'], keycodes['b'])
                        and row.get('window') == fresh_window.id
                        and fresh_session_started_ns
                            <= row.get('monotonic_ns', 0)
                            < fresh_input_started_ns]
                fresh_horizon_readback = {
                    name:_key_down(observer, keycodes[name])
                    for name in ('a','b','c')}
                old_after_fresh = _metadata(await server.call_tool(
                    'interface_results', {
                        'call_id':pending['call_id'], 'include_image':False}))
                old_after_fresh_cancel = old_after_fresh.get(
                    'cancellation', {}).get('result', {})
                old_fence = report['fresh_session_recovery'][
                    'old_cancellation_fence']
                fresh_checks = {
                    'non_idempotent_effect_count_exact':fresh_count_oracle['task_success'] is True,
                    'old_unknown_fence_preserved':(
                        old_fence['cleanup_status'] == 'UNKNOWN'
                        and old_fence['late_server_request_possible'] is True
                        and old_fence['release_confirmed'] is False
                        and old_fence['replay_allowed'] is False),
                    'old_fence_unchanged_after_fresh_task':(
                        old_after_fresh_cancel.get('cleanup_status') == 'UNKNOWN'
                        and old_after_fresh_cancel.get(
                            'late_server_request_possible') is True
                        and old_after_fresh_cancel.get('release_confirmed') is False
                        and old_after_fresh_cancel.get('task_success') is None
                        and old_after_fresh_cancel.get('replay_allowed') is False),
                    'new_task_effect_after_input':
                        fresh_effect_after_action == [3],
                    'new_task_precondition_exact':
                        fresh_effect_before_input == [0],
                    'new_task_effect_at_horizon':final_fresh_effect == [3],
                    'no_old_delayed_press_after_new_session':
                        not late_b_after_fresh_start and not late_a_after_fresh_start,
                    'no_old_input_before_fresh_action':
                        not old_input_events_before_fresh_action,
                    'new_task_keys_up_after_input':not any(
                        fresh_release_readback.values()),
                    'all_keys_up_at_horizon':not any(
                        fresh_horizon_readback.values()),
                }
                report['fresh_session_recovery'].update({
                    'effect_at_horizon':final_fresh_effect,
                    'effect_count_at_horizon':final_fresh_count,
                    'effect_count_oracle':fresh_count_oracle,
                    'late_old_keypress_after_new_session':(
                        late_b_after_fresh_start or late_a_after_fresh_start),
                    'late_old_a_keypress_after_new_session':late_a_after_fresh_start,
                    'old_input_events_before_fresh_action':
                        old_input_events_before_fresh_action,
                    'horizon_readback':fresh_horizon_readback,
                    'old_cancellation_after_fresh_task':old_after_fresh_cancel,
                    'task_oracle':{
                        'scope':'same-Xvfb fresh session while old cancel fence remains UNKNOWN',
                        'expected_effect':[3],
                        'checks':fresh_checks,
                        'status':('unknown' if fresh_count_oracle['task_success'] is None
                                  else 'pass' if all(fresh_checks.values()) else 'fail'),
                        'task_success':(None if fresh_count_oracle['task_success'] is None
                                        else all(fresh_checks.values())),
                        'runtime_task_success':None,
                    },
                })
                report['counted_task_outcomes'] = {
                    'old_task':report['independent_task_oracle']['status'],
                    'fresh_task':report['fresh_session_recovery']['task_oracle']['status'],
                    'scope':'Separate from control-path test completion and runtime UNKNOWN receipts',
                }
                # Delayed request outcomes are evidence. Do not convert a live
                # result into an assumed general queue-drain guarantee.
                if not _TRACKED_DELAYED_SECOND_PRESS:
                    self.assertFalse(late['a'], report)
                self.assertIn(effect_value, ([1],[2]), report)

                report['timing_ns']['terminal_started'] = time.monotonic_ns()
                terminal = _metadata(await server.call_tool('interface_results', {
                    'call_id':pending['call_id'], 'include_image':False}))
                report['timing_ns']['terminal_returned'] = time.monotonic_ns()
                terminal_elapsed_ms = (
                    report['timing_ns']['terminal_returned']
                    - report['timing_ns']['terminal_started'])/1_000_000
                report['terminal_elapsed_ms'] = terminal_elapsed_ms
                report['terminal'] = terminal
                terminal_returned = True
                owner_process = terminal.get('owner_process', {})
                owner_process_source = 'terminal.owner_process'
                if not owner_process.get('liveness_observed_monotonic_ns'):
                    owner_process = terminal.get('session', {}).get('owner_process', {})
                    owner_process_source = 'terminal.session.owner_process'
                liveness_observed_ns = owner_process.get(
                    'liveness_observed_monotonic_ns')
                cancel_returned_ns = report['timing_ns']['cancel_returned']
                cancellation = terminal.get('cancellation', {})
                cancel_completed_ns = cancellation.get('completed_monotonic_ns')
                execution = terminal.get('result', {}).get('execution', {})
                execution_ended_ns = execution.get('ended_ns')
                cancel_admitted_ns = cancellation.get('admitted_monotonic_ns')
                cancellation_result = cancellation.get('result', {})
                self.assertIsInstance(liveness_observed_ns, int, terminal)
                self.assertIsInstance(cancel_completed_ns, int, terminal)
                if terminal.get('status') == 'completed':
                    self.assertIsInstance(execution_ended_ns, int, terminal)
                    self.assertIsInstance(cancel_admitted_ns, int, terminal)
                if terminal.get('status') != 'completed':
                    self.assertTrue(cancellation_result.get('owner_process_retired'), terminal)
                    self.assertIsInstance(cancellation_result.get('owner_process_exitcode'),
                                          int, terminal)
                report['terminal_owner_liveness_fence'] = {
                    'liveness_observed_monotonic_ns':liveness_observed_ns,
                    'owner_process_source':owner_process_source,
                    'owner_process_alive_snapshot':owner_process.get('alive'),
                    'cancellation_claimed_retired':cancellation_result.get(
                        'owner_process_retired'),
                    'terminal_status':terminal.get('status'),
                    'operation_ended_monotonic_ns':execution_ended_ns,
                    'cancellation_admitted_monotonic_ns':cancel_admitted_ns,
                    'cancellation_completed_monotonic_ns':cancel_completed_ns,
                    'operation_completed_after_cancel_admission':(
                        execution_ended_ns > cancel_admitted_ns
                        if isinstance(execution_ended_ns, int)
                        and isinstance(cancel_admitted_ns, int) else None),
                    'operation_completed_before_cancel_terminal':(
                        execution_ended_ns < cancel_completed_ns
                        if isinstance(execution_ended_ns, int) else None),
                    'owner_snapshot_conflicts_with_retirement_at_observation':(
                        liveness_observed_ns >= cancel_completed_ns
                        and owner_process.get('alive') is True
                        and cancellation_result.get('owner_process_retired') is True),
                    'cancel_returned_monotonic_ns':cancel_returned_ns,
                    'snapshot_precedes_cancel_terminal':(
                        liveness_observed_ns < cancel_completed_ns),
                    'alive':owner_process.get('alive'),
                }
                # The caller may return pending well before cleanup finishes.
                # A process snapshot taken after that response can still truthfully
                # report alive while the same cancellation retains custody. Only
                # compare the snapshot with the terminal cancellation timestamp.
                if liveness_observed_ns >= cancel_completed_ns:
                    self.assertFalse(owner_process.get('alive'), terminal)
                self.assertLess(terminal_elapsed_ms, _TERMINAL_BOUND_MS, terminal)
                self.assertNotEqual(terminal.get('status'), 'pending', terminal)
                self.assertFalse(terminal.get('release_confirmed'), terminal)
                self.assertFalse(terminal.get('replay_allowed'), terminal)
                if terminal.get('status') == 'completed':
                    report['completion_after_cancel'] = {
                        'completed_ops':execution.get('completed_ops'),
                        'program_emissions':execution.get('program_emissions'),
                        'runtime_release_rows':execution.get('releases'),
                        'terminal_cleanup_status':terminal.get('cleanup_status'),
                        'terminal_task_success':terminal.get('task_success'),
                        'cancellation_cleanup_status':cancellation_result.get(
                            'cleanup_status'),
                        'cancellation_release_confirmed':cancellation_result.get(
                            'release_confirmed'),
                        'cancel_operation_id':cancellation.get('operation_id'),
                    }
                    self.assertEqual(execution.get('completed_ops'), [0, 1, 2, 3], terminal)
                    self.assertTrue(execution.get('releases'), terminal)
                else:
                    self.assertEqual(terminal.get('cleanup_status'), 'UNKNOWN', terminal)
                    self.assertIsNone(terminal.get('task_success'), terminal)

                if _RETENTION_MODE == 'journal':
                    from runtime.guarded_x11_v1.receipt_journal import ReceiptJournal
                    old_session_id = observed['session']['session_id']
                    journal_path = (owner_output_root
                                    / ('guarded-session-' + old_session_id)
                                    / 'retention.jsonl')
                    with ReceiptJournal(journal_path) as journal:
                        refs = journal.references()
                        self.assertTrue(any(ref.startswith('observation-') for ref in refs), refs)
                        self.assertTrue(any(ref.startswith('mint-') for ref in refs), refs)
                        self.assertFalse(any(ref.endswith('-execution') for ref in refs), refs)
                        self.assertNotIn('session-close', refs)
                    report['retired_owner_journal'] = {
                        'status':'reopened_and_verified', 'references':refs,
                        'execution_result_present':False, 'session_close_present':False,
                        'terminal_status':terminal['status'],
                        'cleanup_status':terminal['cleanup_status'],
                        'release_confirmed':terminal['release_confirmed'],
                        'task_success':terminal['task_success'],
                        'replay_allowed':terminal['replay_allowed'],
                    }

                report['status'] = (
                    'OBSERVED_XVFB_OPERATION_COMPLETED_AFTER_CANCEL_ADMISSION'
                    if (isinstance(execution_ended_ns, int)
                        and isinstance(cancel_admitted_ns, int)
                        and execution_ended_ns > cancel_admitted_ns) else
                    'OBSERVED_SCOPED_XVFB_STANDARD_CALLER_CANCEL_CLEANUP_UNKNOWN')
            except BaseException as error:
                report.update(status='FAIL', error_type=type(error).__name__,
                              error=str(error))
                raise
            finally:
                if server is not None and pending_call_id and not cancelled:
                    try:
                        report['final_cleanup_cancel'] = _metadata(await asyncio.wait_for(
                            server.call_tool('interface_guarded_cancel',
                                             {'call_id':pending_call_id}),
                            timeout=6.0))
                    except BaseException as error:
                        report['final_cleanup_cancel_error'] = repr(error)
                        cleanup_errors.append(f'fallback cancel failed: {error!r}')
                if server is not None and pending_call_id and not terminal_returned:
                    try:
                        report['final_cleanup_terminal'] = await self._wait_for_terminal(
                            server, pending_call_id)
                        if report['final_cleanup_terminal'].get('status') == 'pending':
                            cleanup_errors.append('guarded input call remained pending after cleanup wait')
                    except BaseException as error:
                        report['final_cleanup_terminal_error'] = repr(error)
                        cleanup_errors.append(f'terminal result retrieval failed: {error!r}')
                if server is not None and not close_resolved:
                    try:
                        close_row = await self._close_after_work(server)
                        report['close'] = close_row
                        close_resolved = close_row.get('status') == 'closed'
                        if (not close_resolved
                                and close_row.get('status') == 'cleanup_failed'
                                and close_row.get('cleanup_status') == 'UNKNOWN'
                                and close_row.get('release_confirmed') is False
                                and close_row.get('task_success') is None
                                and close_row.get('replay_allowed') is False
                                and close_row.get('owner_process_retired') is True
                                and close_row.get('late_server_request_possible') is True
                                and close_row.get('owner_client_disconnect', {}).get(
                                    'status') == 'disconnected'
                                and close_row.get('owner_release_attempt') ==
                                    report.get('cancel', {}).get('owner_release_attempt')):
                            # Retirement intentionally leaves the contract UNKNOWN.
                            # A repeated close must preserve the already recorded
                            # cleanup attempt, not issue another release.
                            report['close_outcome'] = 'fail_closed_after_owner_retirement'
                            close_resolved = True
                        if not close_resolved:
                            cleanup_errors.append(f'private MCP server did not close cleanly: {close_row!r}')
                    except BaseException as error:
                        report['close_error'] = repr(error)
                        cleanup_errors.append(f'private MCP close failed: {error!r}')
                if fresh_server is not None:
                    try:
                        report['fresh_session_close'] = await self._close_after_work(
                            fresh_server)
                    except BaseException as error:
                        report['fresh_session_close_error'] = repr(error)
                        cleanup_errors.append(f'fresh private MCP close failed: {error!r}')
                app_stop.set()
                if app_thread is not None:
                    app_thread.join(1.0)
                    if app_thread.is_alive():
                        cleanup_errors.append('synthetic application thread did not stop')
                if observer is not None and keycodes is not None:
                    try:
                        from Xlib.ext import xtest
                        for code in keycodes.values():
                            xtest.fake_input(observer, X.KeyRelease, detail=code)
                        observer.sync()
                        report['final_cleanup'] = {
                            'keys_down':{name:_key_down(observer, code)
                                         for name, code in keycodes.items()},
                            'status':'key_release_sync_completed',
                        }
                        if any(report['final_cleanup']['keys_down'].values()):
                            report['final_cleanup']['status'] = 'input_still_down_after_cleanup'
                            cleanup_errors.append(
                                f"input remained down after final release: {report['final_cleanup']['keys_down']!r}")
                    except BaseException as error:
                        report['final_cleanup'] = {'status':'failed',
                                                   'error':repr(error)}
                        cleanup_errors.append(f'final release/readback failed: {error!r}')
                if app_display is not None:
                    try:
                        app_display.close()
                    except Exception:
                        pass
                if observer is not None:
                    try:
                        observer.close()
                    except Exception:
                        pass
                if result_path:
                    output = Path(result_path)
                    output.parent.mkdir(parents=True, exist_ok=True)
                    proxy_events = os.environ.get(
                        'AGENT_INTERFACE_MCP_XVFB_PROXY_EVENTS')
                    if _SOCKET_DELIVERY_DELAY and proxy_events:
                        proxy_path = Path(proxy_events)
                        report['socket_delivery_proxy_events'] = (
                            [json.loads(line) for line in
                             proxy_path.read_text(encoding='utf-8').splitlines()
                             if line.strip()] if proxy_path.exists() else [])
                    if report.get('status') == 'FAIL':
                        with app_lock:
                            report['partial_application_event_trace'] = list(
                                app_events)
                    if cleanup_errors:
                        report['cleanup_errors'] = cleanup_errors
                        if report.get('status') != 'FAIL':
                            report['status'] = 'FAIL_CLEANUP'
                    output.write_text(json.dumps(report, indent=2, sort_keys=True)+'\n',
                                      encoding='utf-8')
                if cleanup_errors and report.get('status') != 'FAIL':
                    self.fail(f'private Xvfb integration cleanup failed: {cleanup_errors}')


if __name__ == '__main__':
    unittest.main()

"""Guarded transport/retention contracts, with an inert bridge fixture."""
import asyncio
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import threading
import sys
import unittest
from unittest.mock import Mock, patch
from runtime.cli_v1.mcp_server import create_server


class FakeBridge:
    def __init__(self, display, targets, target, directory):
        self.sequence=0;self.binding_revision=0;self.review_required=False
        self.target=target
        self.history={}
        self.directory=Path(directory);self.directory.mkdir()
        self.backend=SimpleNamespace(configure_capture_artifacts=self.configure,
            targets={target:SimpleNamespace(id=targets[target])},release_all=Mock(return_value={
                'verified':True,'keys_down':[],'buttons_down':[]}),close=Mock())
        self.session=SimpleNamespace(backend=self.backend,recovery_required=False)
        self.observe=Mock(side_effect=self.capture)
        self.mint=Mock(return_value=[12,7])
        self.click=Mock(side_effect=self.input)
        self.keyboard=Mock(side_effect=self.input)
        self.move=Mock(side_effect=self.input)
        self.review_window=Mock(return_value={'status':'needs_review','input_dispatched':False})
        self.windows_for_process=Mock(return_value=[{
            'xid':91,'process_pid':4321,'mapped':True,
            'input_authority':False,'authenticated_role':False}])

    def mint_reference(self, alias, source_sequence, point, *, region_size, freshness_ms=1500):
        return {'offset':self.mint(alias,source_sequence,point,region_size=region_size),
                'lifetime':{'clock':'time.monotonic_ns','minted_ns':1_000_000_000,
                    'expires_ns':301_000_000_000,'capture_freshness_ms':freshness_ms,
                    'authority_granted':False,'scope':'Same execution host clock; deadline does not grant input authority.'}}

    def configure(self, directory, *, retain_rgb=False):
        self.capture_directory=Path(directory);self.capture_directory.mkdir(parents=True,exist_ok=True)

    def capture(self):
        from PIL import Image
        self.sequence+=1
        image=self.capture_directory/(str(self.sequence)+'.png')
        Image.new('RGB',(32,32),'white').save(image)
        native={'sha256':'raw-fixture', 'capture_started_ns':1,
                'artifact':{'path':str(image),'mime_type':'image/png',
                    'sha256':hashlib.sha256(image.read_bytes()).hexdigest(),
                    'source_raw_sha256':'raw-fixture'}}
        native['native_window_id']=next(iter(self.backend.targets.values())).id
        observation={'sequence':self.sequence,'observation_id':'fixture-'+str(self.sequence),
                'binding_revision':0,'capture_ns':1,'pointer_binding':{},'native':native}
        self.history[self.sequence]=(observation,None)
        return observation

    def input(self,*args,**kwargs):
        # The same worker must retain its request before reaching this boundary.
        request=json.loads((self.capture_directory.parent/'request.json').read_text())
        if request['operation']!='guarded_input':raise RuntimeError('request missing')
        return {'status':'completed','recovery_required':False,
                'execution':{'releases':[{'verified':True,'keys_down':[],'buttons_down':[]}]}}


def metadata(response):
    return json.loads(response.content[0].text)


class GuardedMCPTests(unittest.IsolatedAsyncioTestCase):
    async def test_input_feedback_preserves_receipt_and_delivers_exact_cue_capture(self):
        for verdict in ('matched', 'pending', 'rejected', 'needs_review'):
            with self.subTest(verdict=verdict), tempfile.TemporaryDirectory() as td:
                opened=[]
                def fixture(*args):
                    bridge=FakeBridge(*args)
                    bridge.feedback=Mock(side_effect=lambda **kw: {
                        'status':verdict,'task_success':None,'authority_granted':False,
                        'input_dispatched':False,'samples':[{'title':'saved'}],
                        'observation':bridge.capture()})
                    opened.append(bridge); return bridge
                with patch('runtime.cli_v1.mcp_guarded.open_bridge',side_effect=fixture):
                    server=create_server({'app':123},td,session_mode='guarded-x11')
                    reply=await server.call_tool('interface_guarded_input',dict(
                        alias='save',offset=[12,7],tail=[],feedback={
                            'expected_title':'saved','rejected_titles':['failed'],'timeout_ms':500}))
                    self.assertEqual(reply.isError,verdict!='matched')
                    row=metadata(reply); bridge=opened[0]
                    self.assertEqual(row['result']['status'],'completed')
                    self.assertEqual(row['status'],'completed' if verdict=='matched' else 'needs_review')
                    self.assertEqual(row['feedback']['status'],verdict)
                    self.assertEqual(row['source'],row['feedback']['observation'])
                    self.assertIsNone(row['task_success']); self.assertFalse(row['replay_allowed'])
                    bridge.click.assert_called_once(); bridge.observe.assert_not_called()
                    bridge.feedback.assert_called_once_with(expected_title='saved',rejected_titles=['failed'],timeout_ms=500)
                    bridge.mint.assert_not_called()
                    retained=await server.call_tool('interface_results',{'call_id':row['call_id']})
                    self.assertEqual(metadata(retained)['result'],row['result'])
                    self.assertEqual(retained.content[1].data,reply.content[1].data)
                    bridge.feedback.assert_called_once(); bridge.click.assert_called_once()
                    await server.call_tool('interface_close',{})

    async def test_input_feedback_never_waits_after_uncertain_input_or_release(self):
        cases=[{'status':'refused','input_dispatched':False},
            {'status':'execution_failed'},
            {'status':'completed','execution':{'releases':[]}},
            {'status':'completed','recovery_required':True,'execution':{'releases':[{'verified':True,'keys_down':[],'buttons_down':[]}]}},
            {'status':'completed','execution':{'releases':[{'verified':False,'keys_down':[],'buttons_down':[]}]}},
            {'status':'completed','execution':{'releases':[{'verified':True,'keys_down':['a'],'buttons_down':[]}]}}]
        for receipt in cases:
            with self.subTest(receipt=receipt), tempfile.TemporaryDirectory() as td:
                opened=[]
                def fixture(*args):
                    bridge=FakeBridge(*args); bridge.click=Mock(return_value=receipt)
                    bridge.feedback=Mock(); opened.append(bridge); return bridge
                with patch('runtime.cli_v1.mcp_guarded.open_bridge',side_effect=fixture):
                    server=create_server({'app':123},td,session_mode='guarded-x11')
                    row=metadata(await server.call_tool('interface_guarded_input',dict(alias='save',offset=[12,7],tail=[],feedback={'expected_title':'saved'})))
                    self.assertEqual(row['result'],receipt)
                    self.assertEqual(row['feedback_status'],'cue_not_attempted')
                    self.assertEqual(row['status'],receipt['status'])
                    opened[0].feedback.assert_not_called(); opened[0].click.assert_called_once()
                    await server.call_tool('interface_close',{})

    async def test_feedback_exception_keeps_input_and_requires_review_without_replay(self):
        opened=[]
        def fixture(*args):
            bridge=FakeBridge(*args); bridge.feedback=Mock(side_effect=RuntimeError('cue persistence failed'))
            opened.append(bridge); return bridge
        with tempfile.TemporaryDirectory() as td, patch('runtime.cli_v1.mcp_guarded.open_bridge',side_effect=fixture):
            server=create_server({'app':123},td,session_mode='guarded-x11')
            row=metadata(await server.call_tool('interface_guarded_input',dict(alias='save',offset=[12,7],tail=[],feedback={'expected_title':'saved'})))
            self.assertEqual(row['result']['status'],'completed')
            self.assertEqual(row['status'],'needs_review')
            self.assertEqual(row['feedback_status'],'cue_failed')
            self.assertIn('cue persistence failed',row['feedback_error'])
            self.assertTrue(opened[0].review_required)
            opened[0].click.assert_called_once(); opened[0].observe.assert_not_called()
            await server.call_tool('interface_close',{})

    async def test_feedback_without_capture_refuses_before_open(self):
        from mcp.server.fastmcp.exceptions import ToolError
        with tempfile.TemporaryDirectory() as td, patch('runtime.cli_v1.mcp_guarded.open_bridge') as opened:
            server=create_server({'app':123},td,session_mode='guarded-x11')
            with self.assertRaises(ToolError):
                await server.call_tool('interface_guarded_input',dict(alias='save',offset=[12,7],tail=[],observe_after=False,feedback={'expected_title':'saved'}))
            opened.assert_not_called()

    async def test_invalid_feedback_refuses_before_open_or_input(self):
        for cue in ({'expected_title':''},{'expected_title':'saved','timeout_ms':10001},
                    {'expected_title':'saved','rejected_titles':['saved']},
                    {'expected_title':'saved','unknown':1}):
            with self.subTest(cue=cue), tempfile.TemporaryDirectory() as td, patch('runtime.cli_v1.mcp_guarded.open_bridge') as opened:
                server=create_server({'app':123},td,session_mode='guarded-x11')
                response=await server.call_tool('interface_guarded_input',
                    dict(alias='save',offset=[12,7],tail=[],feedback=cue))
                row=metadata(response)
                self.assertTrue(response.isError)
                self.assertEqual(row['status'],'invalid_request',row)
                self.assertFalse(row['operation_invoked'],row)
                self.assertFalse(row['input_dispatched'],row)
                self.assertFalse(row['replay_allowed'],row)
                opened.assert_not_called()

    async def test_requested_activation_review_returns_exact_image_without_edit(self):
        opened=[]
        def fixture(*args):
            bridge=FakeBridge(*args)
            bridge.activate_window=Mock(return_value={'status':'completed','execution':{'releases':[{'verified':True,'keys_down':[],'buttons_down':[]}]}})
            def reviewed(window_id):
                bridge.binding_revision+=1
                return {'status':'reviewed','observation':bridge.capture()}
            bridge.review_window.side_effect=reviewed
            opened.append(bridge);return bridge
        with tempfile.TemporaryDirectory() as td, patch('runtime.cli_v1.mcp_guarded.open_bridge',side_effect=fixture):
            server=create_server({'app':123},td,session_mode='guarded-x11')
            reply=await server.call_tool('interface_guarded_activate_window',dict(window_id=123,source_sequence=1,current_binding_revision=0,expires_at_ns=5000,timeout_ms=300,review_after_activation=True))
            row=metadata(reply)
            self.assertEqual(row['status'],'reviewed')
            self.assertEqual(row['result']['status'],'completed')
            self.assertEqual(row['source'],row['review']['observation'])
            self.assertEqual(row['session']['binding_revision'],1)
            self.assertEqual(len(reply.content),2)
            lookup=await server.call_tool('interface_results',{'call_id':row['call_id']})
            self.assertEqual(reply.content[1].data,lookup.content[1].data)
            opened[0].activate_window.assert_called_once_with(window_id=123,source_sequence=1,current_binding_revision=0,expires_at_ns=5000,timeout_ms=300)
            opened[0].review_window.assert_called_once_with(123)
            opened[0].click.assert_not_called();opened[0].mint.assert_not_called()
            self.assertIsNone(row['task_success']);self.assertFalse(row['replay_allowed'])
            await server.call_tool('interface_close',{})

    async def test_requested_review_never_follows_failed_or_uncertain_activation(self):
        for result in [
            {'status':'refused','input_dispatched':False},
            {'status':'execution_failed'},
            {'status':'completed','execution':{'releases':[]}},
            {'status':'completed','execution':{'releases':[{'verified':False,'keys_down':[],'buttons_down':[]}]}},
            {'status':'completed','execution':{'releases':[{'verified':True,'keys_down':['a'],'buttons_down':[]}]}},
        ]:
            with self.subTest(result=result), tempfile.TemporaryDirectory() as td:
                opened=[]
                def fixture(*args):
                    bridge=FakeBridge(*args);bridge.activate_window=Mock(return_value=result)
                    opened.append(bridge);return bridge
                with patch('runtime.cli_v1.mcp_guarded.open_bridge',side_effect=fixture):
                    server=create_server({'app':123},td,session_mode='guarded-x11')
                    reply=await server.call_tool('interface_guarded_activate_window',dict(window_id=123,source_sequence=1,current_binding_revision=0,expires_at_ns=5000,timeout_ms=300,review_after_activation=True))
                    row=metadata(reply)
                    self.assertEqual(row['feedback_status'],'review_not_attempted')
                    self.assertEqual(row['result'],result)
                    opened[0].review_window.assert_not_called();opened[0].observe.assert_not_called()
                    await server.call_tool('interface_close',{})

    async def test_failed_requested_review_preserves_completed_activation(self):
        opened=[]
        def fixture(*args):
            bridge=FakeBridge(*args)
            bridge.activate_window=Mock(return_value={'status':'completed','execution':{'releases':[{'verified':True,'keys_down':[],'buttons_down':[]}]}})
            bridge.review_window.return_value={'status':'needs_review','error':'focus changed'}
            opened.append(bridge);return bridge
        with tempfile.TemporaryDirectory() as td, patch('runtime.cli_v1.mcp_guarded.open_bridge',side_effect=fixture):
            server=create_server({'app':123},td,session_mode='guarded-x11')
            row=metadata(await server.call_tool('interface_guarded_activate_window',dict(window_id=123,source_sequence=1,current_binding_revision=0,expires_at_ns=5000,timeout_ms=300,review_after_activation=True)))
            self.assertEqual(row['status'],'needs_review')
            self.assertEqual(row['result']['status'],'completed')
            self.assertNotIn('input_dispatched',row)
            self.assertNotIn('source',row)
            opened[0].activate_window.assert_called_once();opened[0].review_window.assert_called_once()
            await server.call_tool('interface_close',{})

    async def test_review_exception_retains_activation_without_retry_or_no_effect_claim(self):
        opened=[]
        def fixture(*args):
            bridge=FakeBridge(*args)
            bridge.activate_window=Mock(return_value={'status':'completed','execution':{'releases':[{'verified':True,'keys_down':[],'buttons_down':[]}]}})
            bridge.review_window.side_effect=RuntimeError('review persistence failed')
            opened.append(bridge);return bridge
        with tempfile.TemporaryDirectory() as td, patch('runtime.cli_v1.mcp_guarded.open_bridge',side_effect=fixture):
            server=create_server({'app':123},td,session_mode='guarded-x11')
            row=metadata(await server.call_tool('interface_guarded_activate_window',dict(window_id=123,source_sequence=1,current_binding_revision=0,expires_at_ns=5000,timeout_ms=300,review_after_activation=True)))
            self.assertEqual(row['status'],'needs_review')
            self.assertEqual(row['result']['status'],'completed')
            self.assertNotIn('input_dispatched',row)
            self.assertIn('review persistence failed',row['review_error'])
            opened[0].activate_window.assert_called_once();opened[0].review_window.assert_called_once()
            self.assertTrue(opened[0].review_required)
            await server.call_tool('interface_close',{})

    async def test_explicit_activation_uses_retained_worker_without_edit_or_review(self):
        opened=[]
        def fixture(*args):
            bridge=FakeBridge(*args)
            bridge.activate_window=Mock(return_value={'status':'completed','execution':{'releases':[{'verified':True,'keys_down':[],'buttons_down':[]}]}})
            opened.append(bridge);return bridge
        with tempfile.TemporaryDirectory() as td, patch('runtime.cli_v1.mcp_guarded.open_bridge',side_effect=fixture):
            server=create_server({'app':123},td,session_mode='guarded-x11')
            response=await server.call_tool('interface_guarded_activate_window',dict(window_id=123,source_sequence=1,current_binding_revision=0,expires_at_ns=5000,timeout_ms=300))
            row=metadata(response);self.assertEqual(row['status'],'completed')
            opened[0].activate_window.assert_called_once_with(window_id=123,source_sequence=1,current_binding_revision=0,expires_at_ns=5000,timeout_ms=300)
            opened[0].click.assert_not_called();opened[0].review_window.assert_not_called();opened[0].observe.assert_not_called()
            self.assertIsNone(row['task_success']);self.assertFalse(row['replay_allowed'])
            result=metadata(await server.call_tool('interface_results',{'call_id':row['call_id']}))
            self.assertEqual(result['result'],row['result']);self.assertFalse(result['operation_invoked'])
            opened[0].activate_window.assert_called_once()
            await server.call_tool('interface_close',{})

    async def test_minted_reference_deadline_is_retained_without_renewal(self):
        with tempfile.TemporaryDirectory() as td, patch('runtime.cli_v1.mcp_guarded.open_bridge',side_effect=FakeBridge):
            server=create_server({'app':123},td,session_mode='guarded-x11')
            response=await server.call_tool('interface_guarded_mint',{'alias':'field','source_sequence':1,'point':[20,20],'region_size':[24,14]})
            row=metadata(response)
            self.assertIn('lifetime',row,'public response omits finite reference deadline')
            self.assertEqual(row['lifetime']['expires_ns'],301_000_000_000)
            self.assertFalse(row['lifetime']['authority_granted']);self.assertFalse(row['input_dispatched'])
            lookup=metadata(await server.call_tool('interface_results',{'call_id':row['call_id'],'include_image':False}))
            self.assertEqual(lookup['lifetime'],row['lifetime'])
            self.assertFalse(lookup['operation_invoked'])
            many=metadata(await server.call_tool('interface_guarded_mint_many',{'source_sequence':1,'references':[{'alias':'save','point':[20,20],'region_size':[24,14]}]}))
            self.assertEqual(many['minted'][0]['lifetime'],row['lifetime'])
            self.assertEqual(many['minted'][0]['offset'],[12,7])
            await server.call_tool('interface_close',{})

    async def test_minted_reference_accepts_bounded_custom_freshness(self):
        with tempfile.TemporaryDirectory() as td, patch('runtime.cli_v1.mcp_guarded.open_bridge',side_effect=FakeBridge):
            server=create_server({'app':123},td,session_mode='guarded-x11')
            response=await server.call_tool('interface_guarded_mint',{
                'alias':'field','source_sequence':1,'point':[20,20],
                'region_size':[24,14],'freshness_ms':3000})
            row=metadata(response)
            self.assertEqual(row['lifetime']['capture_freshness_ms'],3000)
            self.assertFalse(row['lifetime']['authority_granted'])
            await server.call_tool('interface_close',{})

    async def test_calc_alias_ledger_does_not_promote_stale_mint_receipts(self):
        """A mint receipt for an old frame cannot satisfy current Calc provenance."""
        from mcp.server.fastmcp import FastMCP
        from mcp.types import CallToolResult, TextContent
        from runtime.cli_v1.mcp_guarded import register_guarded_tools
        sequence=0
        calls=[]

        async def submit(operation, arguments, compact, report_refs, **kwargs):
            nonlocal sequence
            calls.append((operation,arguments))
            if operation == 'guarded_observe':
                sequence+=1
                row={'status':'observed','source':{'sequence':sequence,
                    'native':{'artifact':{'sha256':f'{sequence:064x}'}}}}
            elif operation == 'guarded_mint':
                row={'status':'minted','alias':arguments['alias'],'offset':[12,7]}
            elif operation == 'guarded_mint_many':
                row={'status':'minted','source_sequence':arguments['source_sequence'],
                    'minted':[{'alias':reference['alias'],'offset':[12,7]}
                        for reference in arguments['references']]}
            elif operation == 'guarded_calc_compiled':
                row={'status':'completed','operation_invoked':True}
            else:
                row={'status':'unexpected','operation':operation}
            return CallToolResult(content=[TextContent(type='text',
                text=json.dumps(row))])

        server=FastMCP('calc-alias-ledger-test')
        register_guarded_tools(server,submit,compiled_enabled=True,
            window_lifecycle_enabled=True)
        first=metadata(await server.call_tool('interface_guarded_observe',{}))
        old_mint=metadata(await server.call_tool('interface_guarded_mint',{
            'alias':'old_save','source_sequence':first['source']['sequence'],
            'point':[24,24],'region_size':[12,12]}))
        second=metadata(await server.call_tool('interface_guarded_observe',{}))
        fresh_entry=metadata(await server.call_tool('interface_guarded_mint',{
            'alias':'calc_entry','source_sequence':second['source']['sequence'],
            'point':[16,16],'region_size':[12,12]}))
        stale_save=metadata(await server.call_tool('interface_guarded_mint',{
            'alias':'calc_save','source_sequence':first['source']['sequence'],
            'point':[24,24],'region_size':[12,12]}))
        self.assertEqual(old_mint['status'],'minted',old_mint)
        self.assertEqual(stale_save['status'],'minted',stale_save)
        refused=metadata(await server.call_tool('interface_guarded_calc_compiled',{
            'profile_id':'calc-ocr-save-v1',
            'bindings':{
                'entry':{'alias':'calc_entry','offset':fresh_entry['offset']},
                'save':{'alias':'calc_save','offset':stale_save['offset']}},
            'reviewed_sequence':second['source']['sequence'],
            'reviewed_artifact_sha256':second['source']['native']['artifact']['sha256'],
            'blank_reviewed':True,'attempt_id':'calc-stale-mint-receipt-ledger'}))
        self.assertEqual(refused['status'],'invalid_request',refused)
        self.assertEqual(refused['error'],'CALC_BINDING_NOT_MINTED_FOR_REVIEWED_SOURCE',refused)
        self.assertFalse(refused['operation_invoked'],refused)
        self.assertFalse(refused['input_dispatched'],refused)
        self.assertIsNone(refused['release_confirmed'],refused)
        self.assertFalse(refused['replay_allowed'],refused)

        third=metadata(await server.call_tool('interface_guarded_observe',{}))
        fresh_entry=metadata(await server.call_tool('interface_guarded_mint',{
            'alias':'calc_entry','source_sequence':third['source']['sequence'],
            'point':[16,16],'region_size':[12,12]}))
        stale_many=metadata(await server.call_tool('interface_guarded_mint_many',{
            'source_sequence':first['source']['sequence'],'references':[
                {'alias':'calc_save','point':[24,24],'region_size':[12,12]}]}))
        self.assertEqual(stale_many['status'],'minted',stale_many)
        refused_many=metadata(await server.call_tool('interface_guarded_calc_compiled',{
            'profile_id':'calc-ocr-save-v1',
            'bindings':{
                'entry':{'alias':'calc_entry','offset':fresh_entry['offset']},
                'save':{'alias':'calc_save','offset':stale_many['minted'][0]['offset']}},
            'reviewed_sequence':third['source']['sequence'],
            'reviewed_artifact_sha256':third['source']['native']['artifact']['sha256'],
            'blank_reviewed':True,'attempt_id':'calc-stale-mint-many-ledger'}))
        self.assertEqual(refused_many['status'],'invalid_request',refused_many)
        self.assertEqual(refused_many['error'],
            'CALC_BINDING_NOT_MINTED_FOR_REVIEWED_SOURCE',refused_many)
        self.assertFalse(refused_many['operation_invoked'],refused_many)
        self.assertFalse(refused_many['input_dispatched'],refused_many)
        self.assertFalse(any(op=='guarded_calc_compiled' for op,_ in calls),calls)

    async def test_successful_window_review_updates_calc_source_ledger(self):
        """A review's returned frame is current for subsequent Calc mints."""
        from mcp.server.fastmcp import FastMCP
        from mcp.types import CallToolResult, TextContent
        from runtime.cli_v1.mcp_guarded import register_guarded_tools
        calls=[]

        async def submit(operation, arguments, compact, report_refs, **kwargs):
            calls.append((operation,arguments))
            if operation == 'guarded_review_window':
                if arguments['window_id'] == 999:
                    row={'status':'needs_review','review':{}}
                else:
                    row={'status':'reviewed','review':{'source':{'sequence':7,
                        'native':{'artifact':{'sha256':'7'*64}}}}}
            elif operation == 'guarded_mint':
                row={'status':'minted','alias':arguments['alias'],'offset':[12,7]}
            elif operation == 'guarded_calc_compiled':
                row={'status':'completed','operation_invoked':True}
            else:
                row={'status':'unexpected','operation':operation}
            return CallToolResult(content=[TextContent(type='text',
                text=json.dumps(row))])

        server=FastMCP('calc-review-source-ledger-test')
        register_guarded_tools(server,submit,compiled_enabled=True,
            window_lifecycle_enabled=True)
        reviewed=metadata(await server.call_tool('interface_guarded_review_window',
            {'window_id':456}))
        self.assertEqual(reviewed['review']['source']['sequence'],7)
        bindings={}
        for name,point in (('calc_entry',[16,16]),('calc_save',[40,16])):
            minted=metadata(await server.call_tool('interface_guarded_mint',{
                'alias':name,'source_sequence':7,'point':point,
                'region_size':[12,12]}))
            self.assertEqual(minted['status'],'minted',minted)
            bindings['entry' if name=='calc_entry' else 'save']={
                'alias':name,'offset':minted['offset']}
        compiled=metadata(await server.call_tool('interface_guarded_calc_compiled',{
            'profile_id':'calc-ocr-save-v1','bindings':bindings,
            'reviewed_sequence':7,'reviewed_artifact_sha256':'7'*64,
            'blank_reviewed':True,'attempt_id':'calc-review-source-ledger'}))
        self.assertEqual(compiled['status'],'completed',compiled)
        self.assertIn(('guarded_calc_compiled',{
            'profile_id':'calc-ocr-save-v1','bindings':bindings,
            'reviewed_sequence':7,'reviewed_artifact_sha256':'7'*64,
            'blank_reviewed':True,'attempt_id':'calc-review-source-ledger',
            'prepared_call_id':None}),calls)
        failed_review=metadata(await server.call_tool('interface_guarded_review_window',
            {'window_id':999}))
        self.assertEqual(failed_review['status'],'needs_review')
        refused=metadata(await server.call_tool('interface_guarded_calc_compiled',{
            'profile_id':'calc-ocr-save-v1','bindings':bindings,
            'reviewed_sequence':7,'reviewed_artifact_sha256':'7'*64,
            'blank_reviewed':True,'attempt_id':'calc-review-source-ledger'}))
        self.assertEqual(refused['error'],'CALC_REVIEW_SOURCE_STALE',refused)
        compiled_attempts=[args for operation,args in calls
            if operation=='guarded_calc_compiled']
        self.assertEqual([args['attempt_id'] for args in compiled_attempts],
            ['calc-review-source-ledger'])

    async def test_pointer_only_move_returns_fresh_image_without_click_or_keyboard(self):
        from mcp.server.fastmcp.exceptions import ToolError
        opened = []
        def fixture(*args):
            bridge = FakeBridge(*args); opened.append(bridge); return bridge
        with tempfile.TemporaryDirectory() as td, patch('runtime.cli_v1.mcp_guarded.open_bridge', side_effect=fixture):
            server = create_server({'app':123}, td, session_mode='guarded-x11')
            try:
                response = await server.call_tool('interface_guarded_input', {
                    'alias':'save', 'offset':[12,7], 'tail':[], 'interaction':'move'})
            except ToolError as error:
                self.fail('public guarded move must be supported: '+str(error))
            self.assertFalse(response.isError)
            self.assertEqual(metadata(response)['feedback_status'], 'captured')
            self.assertEqual(response.content[1].type, 'image')
            opened[0].move.assert_called_once_with('save', [12,7], tail=[])
            opened[0].click.assert_not_called()
            opened[0].keyboard.assert_not_called()
            request = json.loads(next(Path(td).glob('*/request.json')).read_text())
            self.assertEqual(request['arguments']['interaction'], 'move')
            await server.call_tool('interface_close', {})

    async def test_metadata_only_guarded_lookup_skips_encoding_and_preserves_capture(self):
        import base64
        with tempfile.TemporaryDirectory() as td:
            bridge = FakeBridge(None, {'app': 123}, 'app', Path(td)/'bridge')
            with patch('runtime.cli_v1.mcp_guarded.open_bridge', return_value=bridge):
                server = create_server({'app': 123}, td, session_mode='guarded-x11')
                original = await server.call_tool('interface_guarded_observe', {})
                before = metadata(original)
                call_id = before['call_id']
                raw_path = Path(td, call_id, 'report.json')
                saved_bytes = raw_path.read_bytes()
                with patch('runtime.cli_v1.review.base64.b64encode', wraps=base64.b64encode) as encode:
                    omitted = await server.call_tool('interface_results', {
                        'call_id': call_id, 'include_image': False})
                    self.assertEqual(encode.call_count, 0)
                row = metadata(omitted)
                self.assertEqual(len(omitted.content), 1)
                self.assertEqual(row['image_status'], before['image_status'])
                self.assertEqual(row['image_delivery'], 'omitted_by_request')
                self.assertEqual(row['source'], before['source'])
                self.assertEqual(row['observation_report'], before['observation_report'])
                self.assertIs(row['operation_invoked'], False)
                self.assertEqual(raw_path.read_bytes(), saved_bytes)
                included = await server.call_tool('interface_results', {'call_id': call_id})
                self.assertEqual(included.content[1].data, original.content[1].data)
                image_path = Path(before['source']['native']['artifact']['path'])
                image_path.write_bytes(image_path.read_bytes()+b'corruption')
                with patch('runtime.cli_v1.review.base64.b64encode', wraps=base64.b64encode) as encode:
                    corrupted = await server.call_tool('interface_results', {
                        'call_id': call_id, 'include_image': False})
                    self.assertEqual(encode.call_count, 0)
                self.assertEqual(metadata(corrupted)['image_status'], 'needs_review')
                self.assertIn('image_error', metadata(corrupted))
                self.assertEqual(raw_path.read_bytes(), saved_bytes)
                bridge.observe.assert_called_once()
                bridge.click.assert_not_called()
                bridge.keyboard.assert_not_called()
                await server.call_tool('interface_close', {})

    async def test_public_observation_keeps_current_rgb_across_capture_directory_changes(self):
        # Removing the guarded owner's retain_rgb policy must refuse the real
        # bridge observation, rather than silently pass an inert bridge fake.
        from PIL import Image
        from runtime.backends.x11_v1.backend import X11Backend
        from runtime.guarded_x11_v1.bridge import NativeHandleBridge
        import io
        import base64
        with tempfile.TemporaryDirectory() as td:
            bridge = object.__new__(NativeHandleBridge)
            bridge.out = Path(td)/'bridge'; bridge.out.mkdir()
            bridge.target = 'app'; bridge.sequence = 0
            bridge.binding_revision = 0; bridge.history = {}; bridge.review_required = False
            bridge._binding = lambda: {'focus':123, 'surface':123, 'geometry':[0,0,2,1]}
            backend = object.__new__(X11Backend)
            backend.targets = {'app':SimpleNamespace(id=123)}
            backend.d = SimpleNamespace(screen=lambda:SimpleNamespace(width_in_pixels=2,height_in_pixels=1))
            backend.release_all = lambda: {'verified':True,'keys_down':[],'buttons_down':[]}
            backend.close = lambda: None
            captures = []
            def capture(target, frame, region):
                raw = bytes([3,2,1,0,6,5,4,0])
                artifact = backend.capture_artifacts.write(raw, 2, 1, depth=24,
                    bits_per_pixel=32, scanline_pad=32, byte_order=0,
                    masks=(0xff0000,0xff00,0xff), true_color=True)
                captures.append(artifact)
                return {'artifact':artifact,'sha256':hashlib.sha256(raw).hexdigest(),'capture_started_ns':1}
            backend.observe_read_only = capture
            bridge.backend = backend
            bridge.session = SimpleNamespace(backend=backend,recovery_required=False)
            backend.configure_capture_artifacts(bridge.out/'images', retain_rgb=True)
            with patch('runtime.cli_v1.mcp_guarded.open_bridge',return_value=bridge):
                server = create_server({'app':123},td,session_mode='guarded-x11')
                try:
                    for sequence in (1,2):
                        response = await server.call_tool('interface_guarded_observe',{})
                        row = metadata(response)
                        self.assertEqual(row['status'],'observed',row)
                        self.assertEqual(row['source']['sequence'],sequence)
                        self.assertEqual(row['source']['image_source'],'exact_capture_rgb_handoff')
                        self.assertEqual(len(response.content),2)
                        with Image.open(io.BytesIO(base64.b64decode(response.content[1].data))) as image:
                            self.assertEqual(list(image.convert('RGB').getdata()),[(1,2,3),(4,5,6)])
                        self.assertEqual(list(bridge.history[sequence][1].getdata()),[(1,2,3),(4,5,6)])
                        self.assertEqual(Path(captures[-1]['path']).parent,Path(row['call_directory'])/'images')
                    self.assertNotEqual(Path(captures[0]['path']).parent,Path(captures[1]['path']).parent)
                    before = len(captures)
                    reread = await server.call_tool('interface_results',{'call_id':row['call_id']})
                    self.assertEqual(reread.content[1],response.content[1])
                    self.assertEqual(len(captures),before)
                finally:
                    await server.call_tool('interface_close',{})

    async def test_opt_in_observation_references_preserve_image_and_retained_full_view(self):
        from runtime.cli_v1.receipt_references import expand_guarded_observation
        with tempfile.TemporaryDirectory() as td:
            bridge=FakeBridge(None,{'app':123},'app',Path(td)/'fixture')
            def capture():
                source=bridge.capture();source['native']['extension']='x'*800
                return source
            bridge.observe.side_effect=capture
            with patch('runtime.cli_v1.mcp_guarded.open_bridge',return_value=bridge):
                server=create_server({'app':123},td,session_mode='guarded-x11')
                response=await server.call_tool('interface_guarded_observe',{'observation_refs':True})
                row=metadata(response);self.assertIn('reference_schema',row)
                expanded=expand_guarded_observation(row)
                retained=await server.call_tool('interface_results',{'call_id':row['call_id']})
                full=metadata(retained);self.assertNotIn('reference_schema',full)
                self.assertEqual(full['source'],expanded['source'])
                self.assertEqual(full['observation_report'],expanded['observation_report'])
                self.assertEqual(response.content[1],retained.content[1])
                self.assertEqual(bridge.observe.call_count,1)
                await server.call_tool('interface_close',{})
                reread=metadata(await server.call_tool('interface_results',{'call_id':row['call_id'],'observation_refs':True}))
                self.assertFalse(reread['operation_invoked'])
                self.assertEqual(expand_guarded_observation(reread)['observation_report'],full['observation_report'])
                self.assertEqual(bridge.observe.call_count,1)
                bridge.click.assert_not_called();bridge.keyboard.assert_not_called()

    async def test_batch_mints_same_source_without_observe_or_input_and_retains_result(self):
        with tempfile.TemporaryDirectory() as td:
            bridge=FakeBridge(None,{'app':123},'app',Path(td)/'fixture')
            with patch('runtime.cli_v1.mcp_guarded.open_bridge',return_value=bridge):
                server=create_server({'app':123},td,session_mode='guarded-x11')
                refs=[{'alias':name,'point':[20,30],'region_size':[24,14]} for name in ('field','save')]
                response=await server.call_tool('interface_guarded_mint_many',{'source_sequence':7,'references':refs})
                row=metadata(response)
                self.assertEqual(row['status'],'minted')
                self.assertEqual([{'alias':r['alias'],'offset':r['offset']} for r in row['minted']],
                                 [{'alias':r['alias'],'offset':[12,7]} for r in refs])
                self.assertEqual(bridge.mint.call_args_list,[
                    unittest.mock.call('field',7,[20,30],region_size=(24,14)),
                    unittest.mock.call('save',7,[20,30],region_size=(24,14))])
                retained=metadata(await server.call_tool('interface_results',{'call_id':row['call_id']}))
                self.assertEqual(retained['minted'],row['minted'])
                self.assertFalse(retained['operation_invoked'])
                self.assertEqual(bridge.mint.call_count,2)
                bridge.observe.assert_not_called();bridge.click.assert_not_called();bridge.keyboard.assert_not_called()
                await server.call_tool('interface_close',{})

    async def test_batch_failure_preserves_success_and_stops_before_later_alias(self):
        with tempfile.TemporaryDirectory() as td:
            bridge=FakeBridge(None,{'app':123},'app',Path(td)/'fixture')
            bridge.mint.side_effect=[[12,7],OSError('receipt write failed after possible registration')]
            with patch('runtime.cli_v1.mcp_guarded.open_bridge',return_value=bridge):
                server=create_server({'app':123},td,session_mode='guarded-x11')
                refs=[{'alias':name,'point':[20,30],'region_size':[24,14]} for name in ('field','save','later')]
                reply=await server.call_tool('interface_guarded_mint_many',{'source_sequence':7,'references':refs})
                row=metadata(reply)
                self.assertTrue(reply.isError);self.assertEqual(row['status'],'mint_incomplete')
                self.assertEqual([{'alias':r['alias'],'offset':r['offset']} for r in row['minted']],
                                 [{'alias':'field','offset':[12,7]}])
                self.assertEqual(row['failed_index'],1);self.assertEqual(row['failed_alias'],'save')
                self.assertEqual(row['failed_alias_state'],'unknown')
                self.assertEqual(row['unattempted_aliases'],['later'])
                self.assertFalse(row['input_dispatched']);self.assertFalse(row['replay_allowed'])
                self.assertEqual(bridge.mint.call_count,2)
                bridge.observe.assert_not_called();bridge.click.assert_not_called();bridge.keyboard.assert_not_called()
                await server.call_tool('interface_close',{})

    async def test_batch_duplicate_aliases_refuse_before_opening(self):
        with tempfile.TemporaryDirectory() as td, patch('runtime.cli_v1.mcp_guarded.open_bridge') as factory:
            server=create_server({'app':123},td,session_mode='guarded-x11')
            ref={'alias':'same','point':[20,30],'region_size':[24,14]}
            row=metadata(await server.call_tool('interface_guarded_mint_many',{'source_sequence':7,'references':[ref,ref]}))
            self.assertEqual(row['status'],'refused');self.assertEqual(row['minted'],[])
            factory.assert_not_called()

    async def test_batch_entire_schema_validated_before_any_mint(self):
        from copy import deepcopy
        valid={'alias':'field','point':[20,30],'region_size':[24,14]}
        bad=[]
        for key,value in [('alias','bad alias'),('point',[True,30]),('point',[20]),('region_size',[97,14]),('unknown',False)]:
            ref=deepcopy(valid);ref[key]=value;bad.append([valid,ref])
        bad.extend([[],[dict(valid,alias='x'+str(i)) for i in range(9)]])
        with tempfile.TemporaryDirectory() as td, patch('runtime.cli_v1.mcp_guarded.open_bridge') as factory:
            server=create_server({'app':123},td,session_mode='guarded-x11')
            for refs in bad:
                with self.subTest(refs=refs):
                    response=await server.call_tool('interface_guarded_mint_many',{
                        'source_sequence':7,'references':refs})
                    row=metadata(response)
                    self.assertTrue(response.isError)
                    self.assertIn(row['status'],('invalid_request','refused'),row)
                    if row['status']=='invalid_request':
                        self.assertFalse(row['operation_invoked'],row)
                        self.assertFalse(row['input_dispatched'],row)
                        self.assertFalse(row['replay_allowed'],row)
                        self.assertTrue(row['validation_errors'],row)
                        self.assertTrue(all(item['path'][0]=='references'
                                            for item in row['validation_errors']),row)
                        self.assertNotIn('input_value',json.dumps(row))
            factory.assert_not_called();self.assertEqual(list(Path(td).iterdir()),[])

    async def test_handler_validation_error_is_not_mislabeled_as_argument_refusal(self):
        from mcp.server.fastmcp.exceptions import ToolError
        from pydantic import TypeAdapter, ValidationError
        from runtime.cli_v1.mcp_server import PublicArgumentMCP
        server=PublicArgumentMCP('handler-validation-error-test')
        invoked=[]

        @server.tool()
        async def handler_raises_validation_error(value:int)->dict:
            invoked.append(value)
            TypeAdapter(int).validate_python('not-an-integer')
            return {'status':'unreachable'}

        with self.assertRaises(ToolError) as raised:
            await server.call_tool('handler_raises_validation_error',{'value':7})
        self.assertEqual(invoked,[7])
        self.assertIsInstance(raised.exception.__cause__,ValidationError)

    async def test_unknown_top_level_arguments_never_reach_bridge(self):
        opened=[]
        def open_fixture(*args,**kwargs):
            bridge=FakeBridge(*args,**kwargs);opened.append(bridge);return bridge
        with tempfile.TemporaryDirectory() as td, patch('runtime.cli_v1.mcp_guarded.open_bridge', side_effect=open_fixture) as factory:
            server=create_server({'app':123},td,session_mode='guarded-x11')
            for tool in await server.list_tools():
                self.assertIs(tool.inputSchema['additionalProperties'],False)
            refused=await server.call_tool('interface_guarded_input',{
                'alias':'browser_context','offset':[12,12],'tail':[], 'pointer':False})
            self.assertTrue(refused.isError)
            row=metadata(refused)
            self.assertEqual(row['unknown_arguments'],['pointer'])
            self.assertFalse(row['input_dispatched'])
            self.assertFalse(row['operation_invoked'])
            factory.assert_not_called()
            self.assertEqual(list(Path(td).iterdir()),[])
            await server.call_tool('interface_guarded_input',{
                'alias':'browser_context','offset':[12,12],'tail':[],'interaction':'keyboard'})
            factory.assert_called_once()
            opened[0].keyboard.assert_called_once()
            opened[0].click.assert_not_called()
            await server.call_tool('interface_close',{})

    async def test_public_input_forwards_multikey_chord_once(self):
        opened=[]
        def open_fixture(*args,**kwargs):
            bridge=FakeBridge(*args,**kwargs);opened.append(bridge);return bridge
        tail=[{'op':'key_chord','keys':['Shift_L','a']}]
        with tempfile.TemporaryDirectory() as td, patch(
                'runtime.cli_v1.mcp_guarded.open_bridge',side_effect=open_fixture):
            server=create_server({'app':123},td,session_mode='guarded-x11')
            reply=await server.call_tool('interface_guarded_input',{
                'alias':'browser_context','offset':[12,12],
                'tail':tail,'interaction':'keyboard'})
            row=metadata(reply)
            self.assertEqual(row['status'],'completed')
            self.assertIsNone(row['task_success'])
            self.assertFalse(row['replay_allowed'])
            opened[0].keyboard.assert_called_once_with(
                'browser_context',[12,12],tail=tail)
            opened[0].click.assert_not_called()
            retained=await server.call_tool('interface_results',{'call_id':row['call_id']})
            self.assertEqual(metadata(retained)['result'],row['result'])
            self.assertFalse(metadata(retained)['operation_invoked'])
            opened[0].keyboard.assert_called_once()
            await server.call_tool('interface_close',{})

    async def test_explicit_mode_tools_shared_retention_and_no_replay(self):
        with tempfile.TemporaryDirectory() as td, patch('runtime.cli_v1.mcp_guarded.open_bridge',side_effect=FakeBridge) as factory:
            server=create_server({'app':123},td,session_mode='guarded-x11')
            names={tool.name for tool in await server.list_tools()}
            self.assertIn('interface_guarded_input',names)
            self.assertNotIn('interface_dispatch',names)
            self.assertNotIn('interface_inspect_target',names)
            factory.assert_not_called()
            initial=await server.call_tool('interface_guarded_observe',{})
            self.assertEqual(initial.content[1].type,'image')
            source=metadata(initial)['source']
            mint=metadata(await server.call_tool('interface_guarded_mint',{
                'alias':'save','source_sequence':source['sequence'],'point':[20,20],'region_size':[24,14]}))
            self.assertEqual(mint['offset'],[12,7])
            action=await server.call_tool('interface_guarded_input',{
                'alias':'save','offset':mint['offset'],'tail':[]})
            row=metadata(action);self.assertEqual(row['status'],'completed')
            self.assertIsNone(row['task_success']);self.assertFalse(row['replay_allowed'])
            raw=(Path(row['call_directory'])/'report.json').read_bytes()
            retained=await server.call_tool('interface_results',{'call_id':row['call_id']})
            self.assertEqual(retained.content[1].data,action.content[1].data)
            self.assertFalse(metadata(retained)['operation_invoked'])
            omitted=await server.call_tool('interface_results',{'call_id':row['call_id'],'include_image':False})
            self.assertEqual(len(omitted.content),1)
            self.assertEqual(metadata(omitted)['image_delivery'],'omitted_by_request')
            self.assertEqual((Path(row['call_directory'])/'report.json').read_bytes(),raw)
            factory.assert_called_once()
            closed=metadata(await server.call_tool('interface_close',{}))
            self.assertTrue(closed['release_attempted'])
            self.assertEqual(metadata(await server.call_tool('interface_guarded_observe',{}))['status'],'session_closed')
            after=await server.call_tool('interface_results',{'call_id':row['call_id']})
            self.assertEqual(after.content[1].data,action.content[1].data)

    async def test_capture_failure_keeps_completed_input_and_retained_failure(self):
        with tempfile.TemporaryDirectory() as td:
            bridge=FakeBridge(None,{'app':123},'app',Path(td)/'fixture')
            bridge.observe.side_effect=OSError('capture failed')
            with patch('runtime.cli_v1.mcp_guarded.open_bridge',return_value=bridge):
                server=create_server({'app':123},td,session_mode='guarded-x11')
                reply=await server.call_tool('interface_guarded_input',{'alias':'x','offset':[1,2],'tail':[]})
                row=metadata(reply)
                self.assertTrue(reply.isError)
                self.assertEqual(row['result']['status'],'completed')
                self.assertEqual(row['feedback_status'],'observation_failed')
                self.assertNotIn('source',row);self.assertEqual(len(reply.content),1)
                again=metadata(await server.call_tool('interface_results',{'call_id':row['call_id']}))
                self.assertEqual(again['result'],row['result']);bridge.click.assert_called_once()
                await server.call_tool('interface_close',{})

    async def test_uncertain_input_error_is_retained_without_implicit_observation_or_retry(self):
        with tempfile.TemporaryDirectory() as td:
            bridge=FakeBridge(None,{'app':123},'app',Path(td)/'fixture')
            bridge.click.side_effect=RuntimeError('delivery uncertain')
            with patch('runtime.cli_v1.mcp_guarded.open_bridge',return_value=bridge):
                server=create_server({'app':123},td,session_mode='guarded-x11')
                row=metadata(await server.call_tool('interface_guarded_input',{'alias':'x','offset':[1,2],'tail':[]}))
                self.assertEqual(row['effect_status'],'unknown')
                self.assertNotIn('input_dispatched',row)
                await server.call_tool('interface_results',{'call_id':row['call_id']})
                bridge.click.assert_called_once();bridge.observe.assert_not_called()
                await server.call_tool('interface_close',{})

    async def test_strict_schema_and_failed_initialization_do_not_reopen(self):
        with tempfile.TemporaryDirectory() as td, patch('runtime.cli_v1.mcp_guarded.open_bridge',side_effect=OSError('display failed')) as factory:
            server=create_server({'app':123},td,session_mode='guarded-x11')
            invalid=await server.call_tool('interface_guarded_mint',
                {'alias':'x','source_sequence':True,'point':[1,2],'region_size':[24,14]})
            invalid_row=metadata(invalid)
            self.assertTrue(invalid.isError)
            self.assertEqual(invalid_row['status'],'invalid_request',invalid_row)
            self.assertFalse(invalid_row['operation_invoked'],invalid_row)
            self.assertFalse(invalid_row['input_dispatched'],invalid_row)
            factory.assert_not_called()
            row=metadata(await server.call_tool('interface_guarded_observe',{}))
            self.assertEqual(row['status'],'backend_unavailable')
            self.assertFalse(row['operation_invoked'])
            await server.call_tool('interface_guarded_observe',{})
            factory.assert_called_once()
            await server.call_tool('interface_close',{})
            with self.assertRaises(ValueError):create_server({'a':1,'b':2},td,session_mode='guarded-x11')

    async def test_busy_rejects_close_and_input_without_queueing(self):
        with tempfile.TemporaryDirectory() as td:
            bridge=FakeBridge(None,{'app':123},'app',Path(td)/'fixture')
            entered=threading.Event();release=threading.Event()
            def blocked(*args,**kwargs):
                entered.set();release.wait(5);return bridge.input(*args,**kwargs)
            bridge.click.side_effect=blocked
            with patch('runtime.cli_v1.mcp_guarded.open_bridge',return_value=bridge):
                server=create_server({'app':123},td,session_mode='guarded-x11')
                args={'alias':'x','offset':[1,2],'tail':[],'observe_after':False}
                first=asyncio.create_task(server.call_tool('interface_guarded_input',args))
                try:
                    self.assertTrue(await asyncio.to_thread(entered.wait,3))
                    self.assertEqual(metadata(await server.call_tool('interface_close',{}))['status'],'busy')
                    self.assertEqual(metadata(await server.call_tool('interface_guarded_input',args))['status'],'busy')
                    bridge.backend.close.assert_not_called()
                finally:release.set()
                self.assertEqual(metadata(await first)['feedback_status'],'not_requested')
                bridge.click.assert_called_once()
                await server.call_tool('interface_close',{})
                bridge.backend.close.assert_called_once()

    async def test_real_stdio_discovery_input_image_retention_and_close(self):
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client
        with tempfile.TemporaryDirectory() as td:
            code="""import sys
from unittest.mock import patch
from runtime.cli_v1.test_mcp_guarded import FakeBridge
from runtime.cli_v1.mcp_server import create_server
with patch('runtime.cli_v1.mcp_guarded.open_bridge',side_effect=FakeBridge):
    create_server({'app':123},sys.argv[1],session_mode='guarded-x11').run(transport='stdio')
"""
            params=StdioServerParameters(command=sys.executable,args=['-c',code,td],
                cwd=str(Path(__file__).resolve().parents[2]))
            async with stdio_client(params) as (reader,writer):
                async with ClientSession(reader,writer) as client:
                    await client.initialize()
                    self.assertIn('interface_guarded_input',{t.name for t in (await client.list_tools()).tools})
                    refused=await client.call_tool('interface_guarded_input',{
                        'alias':'x','offset':[1,2],'tail':[],'pointer':False})
                    self.assertTrue(refused.isError)
                    self.assertEqual(metadata(refused)['unknown_arguments'],['pointer'])
                    self.assertEqual(list(Path(td).iterdir()),[])
                    minted=await client.call_tool('interface_guarded_mint_many',{
                        'source_sequence':1,'references':[
                            {'alias':'field','point':[20,30],'region_size':[24,14]},
                            {'alias':'save','point':[40,30],'region_size':[24,14]}]})
                    self.assertEqual([{'alias':r['alias'],'offset':r['offset']} for r in metadata(minted)['minted']],[
                        {'alias':'field','offset':[12,7]},{'alias':'save','offset':[12,7]}])
                    action=await client.call_tool('interface_guarded_input',{'alias':'x','offset':[1,2],'tail':[]})
                    row=metadata(action);self.assertEqual(row['status'],'completed')
                    self.assertEqual(action.content[1].type,'image')
                    retained=await client.call_tool('interface_results',{'call_id':row['call_id']})
                    self.assertEqual(retained.content[1].data,action.content[1].data)
                    closed=metadata(await client.call_tool('interface_close',{}))
                    self.assertEqual(closed['status'],'closed')

    async def test_review_updates_binding_and_retains_the_exact_returned_image(self):
        with tempfile.TemporaryDirectory() as td:
            bridge=FakeBridge(None,{'app':123},'app',Path(td)/'fixture')
            def reviewed(window_id):
                bridge.binding_revision+=1
                bridge.backend.targets['app'].id=window_id
                return {'status':'reviewed','observation':bridge.capture()}
            bridge.review_window.side_effect=reviewed
            with patch('runtime.cli_v1.mcp_guarded.open_bridge',return_value=bridge):
                server=create_server({'app':123},td,session_mode='guarded-x11')
                reply=await server.call_tool('interface_guarded_review_window',{'window_id':456})
                row=metadata(reply)
                self.assertEqual(row['status'],'reviewed')
                self.assertFalse(row['input_dispatched'])
                self.assertEqual(row['session']['targets'],{'app':456})
                self.assertEqual(row['session']['binding_revision'],1)
                self.assertEqual(row['source'],row['review']['observation'])
                again=await server.call_tool('interface_results',{'call_id':row['call_id']})
                self.assertEqual(reply.content[1].data,again.content[1].data)
                bridge.review_window.assert_called_once_with(456)
                bridge.click.assert_not_called();bridge.keyboard.assert_not_called()
                await server.call_tool('interface_close',{})

    async def test_malformed_mint_refuses_without_input_or_minting(self):
        with tempfile.TemporaryDirectory() as td:
            bridge=FakeBridge(None,{'app':123},'app',Path(td)/'fixture')
            with patch('runtime.cli_v1.mcp_guarded.open_bridge',return_value=bridge):
                server=create_server({'app':123},td,session_mode='guarded-x11')
                for point,size in [([1],[24,14]),([1,2],[3,14]),([1,2],[97,14]),([1,2],[24])]:
                    response=await server.call_tool('interface_guarded_mint',{
                        'alias':'x','source_sequence':1,'point':point,'region_size':size})
                    self.assertTrue(response.isError)
                    self.assertFalse(metadata(response)['input_dispatched'])
                bridge.mint.assert_not_called();bridge.click.assert_not_called()
                bridge.keyboard.assert_not_called();bridge.observe.assert_not_called()
                await server.call_tool('interface_close',{})
    async def test_brief_projection_preserves_full_retention_and_image_without_replay(self):
        from runtime.cli_v1.test_guarded_presentation import normal_report
        with tempfile.TemporaryDirectory() as td:
            bridge=FakeBridge(None,{'app':123},'app',Path(td)/'fixture')
            bridge.click.side_effect=lambda *a,**k:normal_report()['result']
            with patch('runtime.cli_v1.mcp_guarded.open_bridge',return_value=bridge):
                server=create_server({'app':123},td,session_mode='guarded-x11')
                response=await server.call_tool('interface_guarded_input',{'alias':'x','offset':[1,2],'tail':[],'detail':'brief'})
                brief=metadata(response);self.assertEqual(brief['presentation']['returned'],'brief')
                raw_path=Path(brief['call_directory'])/'report.json';raw_before=raw_path.read_bytes()
                self.assertIn('guard_checks',json.loads(raw_before)['result'])
                full_reply=await server.call_tool('interface_results',{'call_id':brief['call_id'],'detail':'full'})
                full=metadata(full_reply)
                self.assertNotIn('presentation',full)
                self.assertEqual(full_reply.content[1].data,response.content[1].data)
                self.assertIn('guard_checks',full['result'])
                after=await server.call_tool('interface_results',{'call_id':brief['call_id'],'detail':'brief','include_image':False})
                self.assertEqual(metadata(after)['presentation']['returned'],'brief')
                self.assertEqual(len(after.content),1)
                self.assertEqual(raw_before,raw_path.read_bytes())
                bridge.click.assert_called_once();bridge.observe.assert_called_once()
                await server.call_tool('interface_close',{})

    async def test_brief_does_not_hide_report_persistence_failure(self):
        from runtime.cli_v1.test_guarded_presentation import normal_report
        from runtime.cli_v1.attempt import _write_json
        with tempfile.TemporaryDirectory() as td:
            bridge=FakeBridge(None,{'app':123},'app',Path(td)/'fixture')
            bridge.click.side_effect=lambda *a,**k:normal_report()['result']
            def write(path,value):
                if Path(path).name=='report.json':raise OSError('retained report unavailable')
                return _write_json(path,value)
            with patch('runtime.cli_v1.mcp_guarded.open_bridge',return_value=bridge),patch('runtime.cli_v1.mcp_server._write_json',side_effect=write):
                server=create_server({'app':123},td,session_mode='guarded-x11')
                response=await server.call_tool('interface_guarded_input',{'alias':'x','offset':[1,2],'tail':[],'detail':'brief'})
                row=metadata(response)
                self.assertTrue(response.isError);self.assertIn('persistence_error',row)
                self.assertEqual(row['presentation']['returned'],'full')
                self.assertIn('guard_checks',row['result'])
                self.assertEqual(row['result']['status'],'completed')
                bridge.click.assert_called_once()
            await server.call_tool('interface_close',{})


class PublicCompiledOwnerTests(unittest.TestCase):
    def test_owner_close_retains_real_release_report_in_journal(self):
        from runtime.cli_v1.mcp_guarded import GuardedSessionOwner
        from runtime.guarded_x11_v1.receipt_journal import ReceiptJournal
        with tempfile.TemporaryDirectory() as td:
            owner=GuardedSessionOwner({'app':7},td,retention_mode='journal')
            journal=ReceiptJournal(Path(td)/'retention.jsonl')
            backend=SimpleNamespace(
                release_all=Mock(return_value={'verified':True,'keys_down':[],'buttons_down':[]}),
                close=Mock(return_value={'status':'closed'}))
            owner.bridge=SimpleNamespace(_closed=False,_receipt_journal=journal)
            owner.session=SimpleNamespace(backend=backend)
            owner.dispatch_attempted=True
            report=owner.close()
            retained=ReceiptJournal.read(Path(td)/'retention.jsonl','session-close')
            self.assertEqual(report['release'],{'verified':True,'keys_down':[],'buttons_down':[]})
            self.assertEqual(retained['release'],report['release'])
            self.assertEqual(retained['backend_close'],{'status':'closed'})
            self.assertEqual(report['receipt_journal']['status'],'close_receipt_recorded')

    def test_owner_close_appends_close_report_and_releases_journal(self):
        from runtime.cli_v1.mcp_guarded import GuardedSessionOwner
        with tempfile.TemporaryDirectory() as td:
            owner = GuardedSessionOwner({'app':7}, td, retention_mode='journal')
            owner.bridge = SimpleNamespace(_closed=False, _receipt_journal=None)
            class Journal:
                def __init__(self): self.rows=[]; self.closed=False
                def append(self, reference, kind, payload):
                    self.rows.append((reference,kind,payload)); return reference
                def close(self): self.closed=True
            journal=Journal();owner.bridge._receipt_journal=journal
            report={'status':'closed','release_attempted':True}
            with patch('runtime.cli_v1.mcp_guarded.MCPSessionOwner.close', return_value=report):
                returned=owner.close()
            self.assertEqual(journal.rows[0][:2],('session-close','session-close'))
            self.assertEqual(journal.rows[0][2],report)
            self.assertTrue(journal.closed)
            self.assertEqual(returned['receipt_journal']['status'],'close_receipt_recorded')

    def test_owner_close_after_bridge_close_still_releases_journal(self):
        from runtime.cli_v1.mcp_guarded import GuardedSessionOwner
        with tempfile.TemporaryDirectory() as td:
            owner=GuardedSessionOwner({'app':7},td,retention_mode='journal')
            class Journal:
                closed=False
                def close(self): self.closed=True
            journal=Journal()
            owner.bridge=SimpleNamespace(_closed=True,_receipt_journal=journal)
            with patch('runtime.cli_v1.mcp_guarded.MCPSessionOwner.close',return_value={'status':'closed'}):
                owner.close()
            self.assertTrue(journal.closed)

    def test_retention_mode_is_explicit_and_reported(self):
        from runtime.cli_v1.mcp_guarded import GuardedSessionOwner
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(ValueError):
                GuardedSessionOwner({'app':7}, td, retention_mode='unknown')
            owner = GuardedSessionOwner({'app':7}, td, retention_mode='journal')
            self.assertEqual(owner.snapshot()['retention_mode'], 'journal')
            self.assertEqual(owner.snapshot()['target'], 'app')

    def owner(self, root):
        from runtime.cli_v1.mcp_guarded import GuardedSessionOwner
        owner = GuardedSessionOwner({'app':7}, root, ':fixture')
        with patch('runtime.cli_v1.mcp_guarded.open_bridge', side_effect=FakeBridge):
            owner.get()
        owner.bridge.history = {}
        owner.bridge.configure(root/'previous-call/images', retain_rgb=True)
        return owner

    def callbacks(self):
        return {'perceive':lambda native,rgb:{}, 'verify_effect':lambda req,native,rgb:{}}

    def test_actual_graph_runs_through_owner_and_keeps_action_effect_timing(self):
        self._actual_graph_guard_case(refuse_second=False)

    def test_actual_graph_owner_stops_after_second_guard_refusal(self):
        self._actual_graph_guard_case(refuse_second=True)

    def test_actual_graph_owner_does_not_publish_dispatch_before_first_guard(self):
        self._actual_graph_guard_case(refuse_first=True)

    def _actual_graph_guard_case(self, refuse_second=False, refuse_first=False):
        """Compose the real graph, X11 adapter and public Python owner on Fake X."""
        import hashlib
        import time
        from contextlib import contextmanager
        from PIL import Image
        from runtime.core_v1.test_compiled_gui import interface
        from runtime.cli_v1.mcp_guarded import GuardedSessionOwner

        class Bridge:
            def __init__(self, output):
                self.scope='private'; self.binding_revision=0; self.sequence=0
                self.target='app'; self.active=None; self.review_required=False
                self.session=SimpleNamespace(recovery_required=False)
                self.backend=SimpleNamespace(
                    targets={'app':SimpleNamespace(id=7)},
                    configure_capture_artifacts=self.configure_capture_artifacts)
                self.history={}; self.saved=[]; self.inputs=[]; self.phase=0
                self.store=SimpleNamespace(resolve_point=self.resolve_point)
                self.output=Path(output); self.guard=None

            def configure_capture_artifacts(self, directory, *, retain_rgb=False):
                self.capture_directory=Path(directory)
                self.capture_directory.mkdir(parents=True, exist_ok=True)

            def _save(self, name, value):
                self.saved.append((name, value))

            def resolve_point(self, *args, **kwargs):
                return {'eligible':True,'status':'VALID',
                        'valid_until_ns':time.monotonic_ns()+2_000_000_000}

            def _focus_within_target(self):
                return True

            def observe(self):
                self.sequence += 1
                image=Image.new('RGB',(16,16),(self.phase,20,30))
                path=self.capture_directory/(str(self.sequence)+'.png')
                image.save(path)
                payload=path.read_bytes()
                raw_digest='fixture-'+str(self.sequence)
                captured=time.monotonic_ns()
                source={'sequence':self.sequence,'observation_id':'fixture-'+str(self.sequence),
                    'capture_ns':captured,'capture_started_ns':captured,
                    'binding_revision':self.binding_revision,
                    'pointer_binding':{'surface':7},
                    'native':{'sha256':raw_digest,'capture_started_ns':captured,
                        'native_window_id':7,
                        'artifact':{'path':str(path),'mime_type':'image/png',
                            'sha256':hashlib.sha256(payload).hexdigest(),
                            'source_raw_sha256':raw_digest}}}
                self.history[self.sequence]=(source,image)
                return source

            def resolve(self, stage):
                native,image=self.history[self.sequence]
                return self.guard(stage,native,image)

            @contextmanager
            def input_guard(self, alias, offset, *, tail, verify, interaction='keyboard'):
                self.guard=verify
                try:
                    yield
                finally:
                    self.guard=None

            def click(self, alias, offset, **kwargs):
                if self.guard('fixture_before_input', *self.history[self.sequence]) is not True:
                    return {'status':'refused','input_dispatched':False}
                self.inputs.append((alias,offset,kwargs))
                self.phase += 1
                return {'status':'completed','execution':{'releases':[
                    {'verified':True,'keys_down':[],'buttons_down':[]}]}}

            keyboard=click
            move=click

        with tempfile.TemporaryDirectory() as td:
            root=Path(td); bridge=Bridge(root/'bridge')
            owner=GuardedSessionOwner({'app':7},root,':fixture')
            with patch('runtime.cli_v1.mcp_guarded.open_bridge',return_value=bridge):
                owner.get()
            spec=interface(); spec['surface']='x11-window-7'
            spec['predicates'].append('present')
            spec['symbols']['field'].update(identity_predicate='present',
                                             dependencies=['present'])
            spec['method']['max_runtime_ms']=1000
            bindings={name:{'interaction':'click','offset':[2,2],'tail':[]}
                      for name in ('enter','save')}
            verified=[]; guard_calls=[]; dispatches=[]
            clock=[time.monotonic_ns()]

            def perceive(native, image):
                return {'phase':image.getpixel((0,0))[0], 'present':True}

            def guard_perceive(native, image):
                guard_calls.append(native['sequence'])
                return {'phase':image.getpixel((0,0))[0],
                        'present':not ((refuse_first and len(guard_calls)==1)
                                       or (refuse_second and len(guard_calls)==2))}

            def before_action_dispatch(receipt):
                dispatches.append(receipt)

            def verify_effect(request, native, image):
                if not verified:
                    clock[0]+=10_000_000
                verified.append((request['action'],request['observation']['evidence_ref']))
                return {'status':'succeeded',
                        'evidence_ref':request['observation']['evidence_ref']}

            with (patch('runtime.cli_v1.mcp_guarded.monotonic_ns',
                        side_effect=lambda:clock[0]),
                  patch('time.monotonic_ns',side_effect=lambda:clock[0]),
                  patch('time.perf_counter_ns',side_effect=lambda:clock[0])):
                row=owner.run_compiled(spec,bindings,call_root=root/'method',
                    perceive=perceive,verify_effect=verify_effect,
                    guard_perceive=guard_perceive,
                    before_action_dispatch=before_action_dispatch)
            self.assertEqual(len(guard_calls),1 if refuse_first else 2)
            receipt=row['method_receipt']
            if refuse_first:
                self.assertNotEqual(receipt['outcome'],'TASK_SUCCEEDED')
                self.assertEqual(receipt['completed_transitions'],0)
                self.assertEqual(len(bridge.inputs),0)
                self.assertEqual(dispatches,[])
                self.assertEqual(verified,[])
                return
            if refuse_second:
                self.assertNotEqual(receipt['outcome'],'TASK_SUCCEEDED')
                self.assertEqual(receipt['completed_transitions'],1)
                self.assertEqual(len(bridge.inputs),1)
                self.assertEqual(len(dispatches),1)
                self.assertEqual(dispatches[0]['action'],'enter')
                self.assertEqual([action for action,_ in verified],['enter'])
                return
            transitions=receipt['transitions']
            effects=[event for event in receipt['critical_events']
                     if event['event']=='effect_checked']
            self.assertEqual(receipt['outcome'],'TASK_SUCCEEDED',receipt)
            self.assertEqual([action for action,_ in verified],['enter','save'])
            self.assertEqual([action for action,_ in verified],
                             [transition['action'] for transition in transitions])
            self.assertEqual([event['action_id'] for event in effects],
                             [transition['action_id'] for transition in transitions])
            self.assertEqual(len(receipt['observations']),3)
            self.assertEqual(bridge.sequence,4)
            self.assertEqual(len(bridge.inputs),2)
            self.assertEqual([row['action'] for row in dispatches],['enter','save'])
            self.assertEqual([row['action_id'] for row in dispatches],
                             [transition['action_id'] for transition in transitions])
            self.assertEqual(row['feedback']['image_status'],'image',row)
            self.assertEqual(row['feedback']['image_reference']['observation_id'],'fixture-4')
            timing=row['owner_timing']
            self.assertEqual(timing['clock'],'time.monotonic_ns')
            self.assertEqual(timing['schema'],
                             'agent-interface/compiled-owner-attempt-timing-v1')
            self.assertEqual(timing['status'],'returned')
            self.assertEqual(row['owner_timing_retention'],{'status':'recorded'})
            self.assertLessEqual(timing['started_ns'],
                                 min(observation['captured_ns']
                                     for observation in receipt['observations']))
            self.assertGreaterEqual(timing['completed_ns'],
                                    max(event['effect_verification_accepted_ns']
                                        for event in effects))
            self.assertEqual(timing['elapsed_ns'],
                             timing['completed_ns']-timing['started_ns'])
            self.assertGreaterEqual(timing['elapsed_ns'],10_000_000,timing)
            retained=json.loads((root/'method'/'owner-attempt-timing.json').read_text())
            self.assertEqual(retained,timing)
            for event in effects:
                self.assertLessEqual(event['execution_accepted_ns'],
                                     event['effect_observation_captured_ns'])
                self.assertLessEqual(event['effect_observation_captured_ns'],
                                     event['effect_verification_started_ns'])
                self.assertLessEqual(event['effect_verification_started_ns'],
                                     event['effect_verification_accepted_ns'])
            self.assertIsNone(row['task_success'])
            self.assertFalse(row['replay_allowed'])

    def test_trusted_owner_forwards_guard_and_post_release_settle(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); owner=self.owner(root)
            guard=lambda native,image: {'present':True}
            with patch('runtime.guarded_x11_v1.compiled.run',
                       return_value={'outcome':'SAFE_YIELD','observations':[]}) as run:
                owner.run_compiled({}, {}, call_root=root/'method', **self.callbacks(),
                                   guard_perceive=guard, post_release_settle_ms=25)
            self.assertIs(run.call_args.kwargs['guard_perceive'],guard)
            self.assertEqual(run.call_args.kwargs['post_release_settle_ms'],25)

    def test_invalid_trusted_options_are_rejected_before_dispatch(self):
        invalid=({'guard_perceive':42}, {'post_release_settle_ms':-1},
                 {'post_release_settle_ms':1001}, {'post_release_settle_ms':True})
        for options in invalid:
            with self.subTest(options=options), tempfile.TemporaryDirectory() as td:
                root=Path(td); owner=self.owner(root)
                with patch('runtime.guarded_x11_v1.compiled.run') as run:
                    with self.assertRaises(ValueError):
                        owner.run_compiled({}, {}, call_root=root/'method',
                                           **self.callbacks(), **options)
                run.assert_not_called()
                self.assertFalse(owner.dispatch_attempted)
                self.assertFalse(owner.bridge.review_required)
                self.assertFalse((root/'method').exists())

    def test_unopened_owner_is_not_implicitly_allocated(self):
        from runtime.cli_v1.mcp_guarded import GuardedSessionOwner
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);owner=GuardedSessionOwner({'app':7},root,':fixture')
            with patch('runtime.cli_v1.mcp_guarded.open_bridge') as opened:
                with self.assertRaises(RuntimeError):
                    owner.run_compiled({}, {}, call_root=root/'call', **self.callbacks())
                opened.assert_not_called()

    def test_final_image_uses_owner_feedback_capture_in_new_call_root(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);owner=self.owner(root);bridge=owner.bridge
            receipt={'outcome':'TASK_SUCCEEDED','observations':[{'sequence':1}]}
            def graph(actual,*args,**kwargs):
                self.assertIs(actual,bridge)
                native=bridge.capture();bridge.history[1]=(native,None)
                return receipt
            with patch('runtime.guarded_x11_v1.compiled.run',side_effect=graph) as run:
                row=owner.run_compiled({}, {}, call_root=root/'method', **self.callbacks())
            self.assertEqual(row['method_receipt'],receipt)
            self.assertIsNone(row['task_success']);self.assertFalse(row['replay_allowed'])
            self.assertEqual(row['feedback']['image_status'],'image',row)
            self.assertTrue(Path(row['feedback']['image_reference']['path']).is_relative_to(root/'method'))
            self.assertEqual(bridge.sequence,2);bridge.observe.assert_called_once();run.assert_called_once()

    def test_zero_observation_yield_does_not_present_previous_capture(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);owner=self.owner(root);native=owner.bridge.capture();owner.bridge.history[1]=(native,None)
            with patch('runtime.guarded_x11_v1.compiled.run',return_value={'outcome':'SAFE_YIELD','observations':[]}):
                row=owner.run_compiled({}, {}, call_root=root/'method', **self.callbacks())
            self.assertIsNone(row['feedback']);self.assertEqual(owner.bridge.sequence,1)

    def test_exception_keeps_same_owner_cleanup_duty_and_never_replays(self):
        for error in (RuntimeError('after partial input'),
                      KeyboardInterrupt('after partial input')):
            with self.subTest(error=type(error).__name__), tempfile.TemporaryDirectory() as td:
                root=Path(td);owner=self.owner(root);bridge=owner.bridge
                with patch('runtime.guarded_x11_v1.compiled.run',side_effect=error) as run:
                    with self.assertRaises(type(error)):
                        owner.run_compiled({}, {}, call_root=root/'method', **self.callbacks())
                self.assertTrue(bridge.review_required);run.assert_called_once()
                self.assertEqual(owner.owner_timing_retention,{'status':'recorded'})
                retained=json.loads((root/'method'/'owner-attempt-timing.json').read_text())
                self.assertEqual(retained['status'],'raised')
                self.assertEqual(retained['error_type'],type(error).__name__)
                self.assertEqual(retained['effect_status'],'unknown')
                self.assertFalse(retained['replay_allowed'])
                self.assertGreaterEqual(retained['elapsed_ns'],0)
                close=owner.close();self.assertTrue(close['release']['verified'])
                bridge.backend.release_all.assert_called_once()
                with self.assertRaises(RuntimeError):
                    owner.run_compiled({}, {}, call_root=root/'another', **self.callbacks())

    def test_timing_persistence_failure_does_not_mask_result_or_original_error(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);owner=self.owner(root)
            with (patch('runtime.guarded_x11_v1.compiled.run',
                        return_value={'outcome':'SAFE_YIELD','observations':[]}),
                  patch('runtime.cli_v1.attempt._write_json',
                        side_effect=OSError('timing disk full'))):
                row=owner.run_compiled({}, {}, call_root=root/'success', **self.callbacks())
            self.assertEqual(row['owner_timing_retention']['status'],'unavailable')
            self.assertEqual(row['owner_timing_retention']['error_type'],'OSError')
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);owner=self.owner(root)
            with (patch('runtime.guarded_x11_v1.compiled.run',
                        side_effect=RuntimeError('original input failure')),
                  patch('runtime.cli_v1.attempt._write_json',
                        side_effect=OSError('timing disk full'))):
                with self.assertRaisesRegex(RuntimeError,'original input failure'):
                    owner.run_compiled({}, {}, call_root=root/'failure', **self.callbacks())
            self.assertTrue(owner.bridge.review_required)
            self.assertEqual(owner.owner_timing_retention['status'],'unavailable')
            self.assertEqual(owner.owner_timing_retention['error_type'],'OSError')

    def test_presentation_failure_retains_method_result_and_requires_review(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);owner=self.owner(root);bridge=owner.bridge
            receipt={'outcome':'TASK_SUCCEEDED','observations':[{'sequence':1}]}
            def graph(*args,**kwargs):
                native=bridge.capture();bridge.history[1]=(native,None);return receipt
            with patch('runtime.guarded_x11_v1.compiled.run',side_effect=graph), patch('runtime.cli_v1.review.present_result',side_effect=OSError('presentation unavailable')):
                row=owner.run_compiled({}, {}, call_root=root/'method', **self.callbacks())
            self.assertEqual(row['method_receipt'],receipt);self.assertTrue(bridge.review_required)
            self.assertEqual(row['feedback']['image_status'],'needs_review');self.assertFalse(row['replay_allowed'])

    def test_reused_call_directory_refuses_before_graph_execution(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);owner=self.owner(root);(root/'method').mkdir()
            with patch('runtime.guarded_x11_v1.compiled.run') as run:
                with self.assertRaises(FileExistsError):
                    owner.run_compiled({}, {}, call_root=root/'method', **self.callbacks())
                run.assert_not_called()

    def test_review_or_recovery_requirement_is_not_reset(self):
        for reason in ('review','recovery'):
            with self.subTest(reason=reason), tempfile.TemporaryDirectory() as td:
                root=Path(td);owner=self.owner(root)
                if reason=='review':owner.bridge.review_required=True
                else:owner.session.recovery_required=True
                with patch('runtime.guarded_x11_v1.compiled.run') as run:
                    with self.assertRaises(RuntimeError):
                        owner.run_compiled({}, {}, call_root=root/'method', **self.callbacks())
                    run.assert_not_called();self.assertFalse((root/'method').exists())

    def test_old_graph_sequence_cannot_deliver_unrelated_previous_image(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);owner=self.owner(root);native=owner.bridge.capture();owner.bridge.history[1]=(native,None)
            receipt={'outcome':'SAFE_YIELD','observations':[{'sequence':1}]}
            with patch('runtime.guarded_x11_v1.compiled.run',return_value=receipt):
                row=owner.run_compiled({}, {}, call_root=root/'method', **self.callbacks())
            self.assertEqual(row['method_receipt'],receipt);self.assertTrue(owner.bridge.review_required)
            self.assertEqual(row['feedback']['image_status'],'needs_review');self.assertIsNone(row['feedback']['image'])


class InputDependencyOwnerTests(unittest.TestCase):
    def test_unopened_owner_cannot_register(self):
        from .mcp_guarded import GuardedSessionOwner
        with tempfile.TemporaryDirectory() as d:
            owner=GuardedSessionOwner({'app':1},d)
            with self.assertRaises(RuntimeError):
                with owner.input_guard('save',[0,0],tail=[{'op':'key_chord','keys':['CTRL','s']}],verify=lambda *a:True):pass
            self.assertIsNone(owner.bridge)

    def test_state_is_checked_at_context_entry(self):
        from .mcp_guarded import GuardedSessionOwner
        from contextlib import nullcontext
        owner=object.__new__(GuardedSessionOwner);owner.state='open';owner.session=object()
        owner.bridge=SimpleNamespace(input_guard=Mock(return_value=nullcontext()))
        context=owner.input_guard('save',[0,0],tail=[],verify=lambda *a:True)
        owner.state='closed'
        with self.assertRaises(RuntimeError):
            with context:pass
        owner.bridge.input_guard.assert_not_called()

    def test_open_owner_delegates_context_without_input_or_reopen(self):
        from .mcp_guarded import GuardedSessionOwner
        from contextlib import contextmanager
        entered=[]
        @contextmanager
        def guard(*args,**kwargs):
            entered.append('enter')
            try:yield
            finally:entered.append('exit')
        owner=object.__new__(GuardedSessionOwner);owner.state='open';owner.session=object()
        owner.bridge=SimpleNamespace(input_guard=Mock(side_effect=guard))
        verify=lambda *a:True;tail=[{'op':'key_chord','keys':['CTRL','s']}]
        with owner.input_guard('save',[0,0],tail=tail,verify=verify):self.assertEqual(entered,['enter'])
        self.assertEqual(entered,['enter','exit'])
        owner.bridge.input_guard.assert_called_once_with('save',[0,0],tail=tail,verify=verify)

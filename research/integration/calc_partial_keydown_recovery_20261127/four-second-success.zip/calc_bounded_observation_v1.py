"""Finite fresh-observation gate; never sends input or grants authority."""


def observe_until(read, *, expected, transitional, deadline_ns, clock, pause,
                  max_attempts=8, interval_ns=100_000_000):
    if (not callable(read) or not callable(clock) or not callable(pause)
            or type(expected) is not str or not expected
            or type(transitional) is not tuple or any(type(x) is not str for x in transitional)
            or type(deadline_ns) is not int or type(max_attempts) is not int
            or not 1 <= max_attempts <= 8 or type(interval_ns) is not int or interval_ns < 0):
        raise ValueError('invalid bounded observation parameters')
    records=[]; last_sequence=0; binding=None
    for index in range(1,max_attempts+1):
        started=clock()
        if type(started) is not int or started>=deadline_ns:break
        row=read(index)
        finished=clock()
        if type(row) is not dict or type(finished) is not int or finished<started:
            raise ValueError('invalid observation response')
        sequence=row.get('sequence');capture=row.get('capture_ns');source=row.get('binding');text=row.get('text')
        if (type(sequence) is not int or sequence<=last_sequence or type(capture) is not int
                or not started<=capture<=finished or type(source) is not dict or not source
                or type(text) is not str):
            raise ValueError('stale or malformed observation')
        if binding is not None and binding!=source:raise ValueError('observation binding changed')
        binding=source.copy();last_sequence=sequence
        records.append({'attempt':index,'started_ns':started,'finished_ns':finished,'capture_ns':capture,
                        'sequence':sequence,'binding':source.copy(),'text':text,'deadline_ns':deadline_ns})
        if finished>=deadline_ns:break
        if text==expected:return row,records
        if text not in transitional:raise ValueError('unexpected observed value')
        left=deadline_ns-clock()
        if left<=0:break
        pause(min(interval_ns,left)/1_000_000_000)
    return None,records

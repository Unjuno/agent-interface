import json,traceback
from pathlib import Path
from integrated_efficiency_client_v1 import RuntimeClient
out=Path('/out');r={'passed':False,'scope':'one known-fixture stale reference then fresh acquisition; no model'}
try:
 with RuntimeClient(out/'run',991028) as c:
  a,b=c.ready['goal']['tasks'][0],c.ready['goal']['tasks'][3]
  first=c.navigate(a); old,refusal=c.mint('A',first,{'field_point':[226,401],'submit_point':[376,401]},'old')
  if refusal is not None:raise RuntimeError('old mint refused')
  fresh=c.navigate(b); check,program=c.check(old['field'],[12,19],'stale-check')
  r['old_check']=check;r['old_pointer_admissions']=program['pointer_admissions']
  if check.get('status')!='MISSING' or check.get('eligible') is not False or program['pointer_admissions']:raise RuntimeError('stale reference not refused without pointer input')
  attempted=c.submit('stale-click',[{'op':'pointer_click_target','target_handle':old['field'],'offset':[12,19],'button':1,'duration_ms':80}])
  r['stale_attempt']=attempted
  if attempted['terminal']['status']=='completed' or attempted['pointer_admissions']:raise RuntimeError('stale click was not refused without pointer input')
  new,refusal=c.mint('B',fresh,{'field_point':[650,558],'submit_point':[688,634]},'fresh')
  if refusal is not None:raise RuntimeError('fresh mint refused')
  r['execution']=c.execute_handles(b,new);r['evaluation']=c.finish('finish-stale-repair')
  h=c.runtime/'submission-history.jsonl'; rows=[json.loads(x) for x in h.read_text().splitlines()] if h.exists() else []
  r['history']=rows;r['releases']=[p['terminal']['release'] for p in c.programs]
  r['passed']=(r['execution']['status']=='completed' and len(rows)==1 and rows[0].get('task_id')=='task-4' and rows[0].get('exact') is True and all(x.get('verified') is True and x.get('keys_down')==[] and x.get('buttons_down')==[] for x in r['releases']))
except Exception as e:r.update(error=repr(e),traceback=traceback.format_exc())
(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'passed':r['passed'],'error':r.get('error')}));raise SystemExit(0 if r['passed'] else 1)

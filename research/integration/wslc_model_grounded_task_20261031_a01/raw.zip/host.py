import hashlib,json,time,sys,os,traceback
from pathlib import Path
from integrated_efficiency_app_server_model_v1 import PersistentGroundingModel
root=Path(sys.argv[2]);ex=root/'exchange';deadline=time.monotonic()+120;r={'id':'pilot-01','ok':False};m=None
try:
 while not (ex/'request.json').exists():
  if time.monotonic()>=deadline:raise TimeoutError('container request not observed')
  time.sleep(.05)
 q=json.loads((ex/'request.json').read_text());image=ex/'image.png';digest=hashlib.sha256(image.read_bytes()).hexdigest()
 if q.get('id')!='pilot-01' or q.get('image_sha256')!=digest:raise ValueError('request or image mismatch')
 r['image_sha256']=digest;workspace=root/'workspace';workspace.mkdir(exist_ok=False)
 m=PersistentGroundingModel(root/'model-session',workspace,executable=sys.argv[1],model='gpt-6.1-sol',effort='low')
 r['attempted']=True;result=m.call(root/'model-call','Locate the editable token field and the control that submits this visible form.',image,'compiled',workspace)
 r.update(ok=True,grounding=result['grounding'],usage=result['usage'],call_id=result['call_id'],runner_ns=result['runner_ns'])
except Exception as e:r.update(error=type(e).__name__,detail=str(e)[:800],call_id=getattr(e,'call_id',None),usage=getattr(e,'usage',None))
finally:
 if m is not None:
  try:m.close();r['close_returned']=True
  except Exception as e:r.update(ok=False,close_returned=False,close_error=type(e).__name__)
 tmp=ex/'response.tmp';tmp.write_text(json.dumps(r));os.replace(tmp,ex/'response.json')
print(json.dumps({'ok':r['ok'],'error':r.get('error')}));raise SystemExit(0 if r['ok'] else 1)

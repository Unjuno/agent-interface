import hashlib,json,time,traceback,shutil,os
from pathlib import Path
from integrated_efficiency_client_v1 import RuntimeClient
out=Path('/out');ex=Path('/exchange');r={'passed':False,'scope':'one live checked task with one host model call'}
try:
 with RuntimeClient(out/'run',991028) as c:
  task=c.ready['goal']['tasks'][0];source=c.navigate(task); image=c.runtime/Path(source['image']).name
  shutil.copyfile(image,ex/'image.png');digest=hashlib.sha256((ex/'image.png').read_bytes()).hexdigest()
  request={'id':'pilot-01','image_sha256':digest,'source_sequence':source['sequence']}
  tmp=ex/'request.tmp';tmp.write_text(json.dumps(request));os.replace(tmp,ex/'request.json')
  deadline=time.monotonic()+120
  while not (ex/'response.json').exists():
   if time.monotonic()>=deadline:raise TimeoutError('host response not observed')
   time.sleep(.05)
  response=json.loads((ex/'response.json').read_text());r['model_response']=response
  if response.get('id')!='pilot-01' or response.get('image_sha256')!=digest or response.get('ok') is not True:raise RuntimeError('host response invalid or failed')
  aliases,refusal=c.mint('A',source,response['grounding'],'model')
  if refusal is not None:raise RuntimeError('fresh mint refused')
  r['execution']=c.execute_handles(task,aliases);r['evaluation']=c.finish('finish-model-pilot')
  h=c.runtime/'submission-history.jsonl';rows=[json.loads(x) for x in h.read_text().splitlines()] if h.exists() else []
  r['history']=rows;r['releases']=[p['terminal']['release'] for p in c.programs]
  r['passed']=(r['execution']['status']=='completed' and len(rows)==1 and rows[0].get('exact') is True and all(x.get('verified') is True and x.get('keys_down')==[] and x.get('buttons_down')==[] for x in r['releases']))
except Exception as e:r.update(error=repr(e),traceback=traceback.format_exc())
(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'passed':r['passed'],'error':r.get('error')}));raise SystemExit(0 if r['passed'] else 1)

import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parent
files=[p for p in (root/'src').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']+[root/'trial.py',root/'target.py',root/'run.py',root/'prepare.py']
manifest={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
arms=[('cancel-b01','close_old'),('cancel-b02','withhold_close')]
for ident,mode in arms:
 p=root/ident;p.mkdir(exist_ok=False);(p/'output').mkdir()
 c={'allocation':'idle-owned-'+ident+'-20261101','mode':mode,'order':[f'{i}:{m}' for i,m in arms],
    'base_main':'8e9a4c81f165f2d8e9e72eeec6957b446530f6da','draft_head':'ade6624badddf0eb2d9941bd9918381b67725d9c',
    'image':'sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25',
    'manifest_sha256':hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest(),
    'intervention':'cancel pending old read-only RPC while server stopped; after resume a separate test client holds a; close old owner during hold or withhold old close until after explicit fixture release',
    'criteria':'cancel acknowledged and read returns unavailable while stopped; fresh key down before and 350ms after intervention; explicit fixture key release yields up; target records a; old close verified with no release attempted and release_confirmed null because old owner sent no input',
    'stop':'one try per arm; preserve all failures; stop block on unresolved input or infrastructure failure',
    'limits':'successor to retained a01 failure: corrected impossible release expectation based on MCPSessionOwner.close; single fixed-order sequential pair; old owner holds no key; no general release, hard deadline or MAP01 claim'}
 (p/'conditions.json').write_text(json.dumps(c,indent=2)+'\n')
print('two arms frozen')

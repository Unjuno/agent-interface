import unittest
from aim_policy import choose_nudge

class AimPolicyTests(unittest.TestCase):
    def test_right_and_left_are_bounded_and_signed(self):
        self.assertEqual(choose_nudge('fire',686,530,[320,272,640,480],True),('d',60))
        self.assertEqual(choose_nudge('fire',594,530,[320,272,640,480],True),('a',60))
    def test_centered_and_idle_do_not_turn(self):
        self.assertIsNone(choose_nudge('fire',680,530,[320,272,640,480],True))
        self.assertIsNone(choose_nudge('idle',686,530,[320,272,640,480],True))
    def test_distant_vertical_invalid_or_unverified_do_not_turn(self):
        for x,y,ok in [(737,530,True),(686,573,True),(686,530,False),(True,530,True),(686,530,None)]:
            with self.subTest(x=x,y=y,ok=ok):
                self.assertIsNone(choose_nudge('fire',x,y,[320,272,640,480],ok))
    def test_bad_geometry_does_not_authorize(self):
        for geom in ([320,272,0,480],[320,272,640],None,[320,272,True,480]):
            with self.subTest(geom=geom):
                self.assertIsNone(choose_nudge('fire',686,530,geom,True))

if __name__=='__main__': unittest.main()

"""Research-only one-step horizontal aim proposal; never grants input authority."""

def choose_nudge(action, x, y, geometry, source_valid):
    if (source_valid is not True or action != 'fire' or type(x) is not int or
            type(y) is not int or not isinstance(geometry, (list, tuple)) or
            len(geometry) != 4 or any(type(v) is not int for v in geometry)):
        return None
    left, top, width, height = geometry
    if width <= 0 or height <= 0 or not (left <= x < left + width and top <= y < top + height):
        return None
    dx = x - (left + width // 2)
    dy = y - (top + height // 2)
    if abs(dy) > 60 or not 40 < abs(dx) <= 96:
        return None
    return ('d' if dx > 0 else 'a', 60)

import json,os,signal,subprocess,time,traceback,hashlib,math,threading
from pathlib import Path
from Xlib import X,display,error,XK
import vizdoom as vd
from runtime.cli_v1.mcp_guarded import GuardedSessionOwner

out=Path('/out');route=os.environ['ROUTE'];x=None;d=None;game=None;owner=None
record={'route':route,'status':'running','task_success':None,'samples':[],'model_calls':0,'events':{}}
try:
 deadline=time.monotonic()+100
 while not Path('/exchange/ready.json').exists():
  if Path('/exchange/host-error.json').exists():raise RuntimeError('host failed before ready')
  if time.monotonic()>deadline:raise TimeoutError('host model session not ready')
  time.sleep(.05)
 os.environ['DISPLAY']=':153';os.environ['SDL_VIDEODRIVER']='x11';os.environ['HOME']='/tmp';os.environ['XDG_CACHE_HOME']='/tmp/cache'
 log=(out/'xvfb.log').open('wb');x=subprocess.Popen(['Xvfb',':153','-screen','0','1280x1024x24','-nolisten','tcp'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 for _ in range(100):
  try:d=display.Display(':153');break
  except Exception:time.sleep(.05)
 if d is None:raise RuntimeError('Xvfb unavailable')
 cfg=Path('/tmp/doom-keys.ini');cfg.write_text('[Doom.Bindings]\nw=+forward\ne=+use\nd=+right\na=+left\nf=+attack\n')
 pkg=Path(vd.__file__).resolve().parent;iwad=pkg/'freedoom2.wad';record['iwad_sha256']=hashlib.sha256(iwad.read_bytes()).hexdigest()
 game=vd.DoomGame();game.set_doom_game_path(str(iwad));game.set_doom_scenario_path('');game.set_doom_map('MAP01');game.set_doom_config_path(str(cfg));game.set_mode(vd.Mode.ASYNC_SPECTATOR);game.set_ticrate(35);game.set_seed(991031);game.set_doom_skill(1);game.set_episode_timeout(2100);game.set_window_visible(True);game.set_console_enabled(False);game.set_sound_enabled(False);game.set_render_hud(True);game.set_screen_resolution(vd.ScreenResolution.RES_640X480);game.set_available_buttons([vd.Button.MOVE_FORWARD,vd.Button.USE,vd.Button.TURN_RIGHT,vd.Button.TURN_LEFT,vd.Button.ATTACK]);game.set_labels_buffer_enabled(True);game.set_objects_info_enabled(True);game.set_available_game_variables([vd.GameVariable.POSITION_X,vd.GameVariable.POSITION_Y,vd.GameVariable.HEALTH,vd.GameVariable.KILLCOUNT,vd.GameVariable.ANGLE,vd.GameVariable.SELECTED_WEAPON_AMMO]);game.init()
 windows=[]
 for _ in range(250):
  windows=[]
  for w in d.screen().root.query_tree().children:
   try:
    title=w.get_wm_name()
    if title and 'DOOM' in title.upper() and w.get_attributes().map_state==X.IsViewable:windows.append(w)
   except error.BadWindow:pass
  if len(windows)==1:break
  if len(windows)>1:raise RuntimeError('ambiguous game window')
  time.sleep(.02)
 if len(windows)!=1:raise RuntimeError('game window unavailable')
 w=windows[0];d.set_input_focus(w.id,X.RevertToParent,X.CurrentTime);d.sync();time.sleep(.5)
 owner=GuardedSessionOwner({'app':w.id},out/'owner',':153',process_identity=True,query_worker=True);owner.get();bridge=owner.bridge;obs=bridge.observe();geom=obs['pointer_binding']['geometry'];point=[geom[0]+44,geom[1]+geom[3]-54];mint=bridge.mint_reference('game',obs['sequence'],point,region_size=(24,38));record['observation']=obs;record['mint']=mint
 def sample(label):
  game.advance_action(1,True);state=game.get_state();labels=[] if state is None else [str(x.object_name) for x in state.labels];objects=[] if state is None else [{'name':str(x.name),'id':int(x.id),'x':float(x.position_x),'y':float(x.position_y)} for x in state.objects]
  s={'label':label,'host_ns':time.monotonic_ns(),'tic':game.get_episode_time(),'x':game.get_game_variable(vd.GameVariable.POSITION_X),'y':game.get_game_variable(vd.GameVariable.POSITION_Y),'angle':game.get_game_variable(vd.GameVariable.ANGLE),'ammo':game.get_game_variable(vd.GameVariable.SELECTED_WEAPON_AMMO),'health':game.get_game_variable(vd.GameVariable.HEALTH),'kills':game.get_game_variable(vd.GameVariable.KILLCOUNT),'finished':game.is_episode_finished(),'visible_labels':labels,'objects':objects};record['samples'].append(s);(out/'samples.jsonl').open('a').write(json.dumps(s)+'\n');return s
 def screenshot(label):
  from PIL import Image
  g=w.get_geometry();raw=w.get_image(0,0,g.width,g.height,X.ZPixmap,0xffffffff);Image.frombytes('RGB',(g.width,g.height),raw.data,'raw','BGRX').save(out/('scene-'+label+'.png'))
 def run_action(alias,tail):
  source=bridge.observe();anchor=[geom[0]+geom[2]//2,geom[1]+geom[3]-100] if alias in ('turn','forward3','fire') else point;ref=bridge.mint_reference(alias,source['sequence'],anchor,region_size=(24,38));owner.dispatch_attempted=True
  result=bridge.keyboard(alias,ref['offset'],tail=tail,expires_at_ns=time.monotonic_ns()+4_000_000_000);(out/('action-'+alias+'.json')).write_text(json.dumps(result,indent=2)+'\n');record.setdefault('actions',[]).append(result)
  releases=result.get('execution',{}).get('releases',[])
  if result.get('status')!='completed' or not releases or not all(r.get('verified') and not r.get('keys_down') and not r.get('buttons_down') for r in releases):raise RuntimeError('action or release not confirmed')
 before=sample('before');screenshot('before')
 run_action('forward1',[{'op':'key_state','key':'w','down':True},{'op':'wait_update','timeout_ms':2000},{'op':'key_state','key':'w','down':False}]);sample('forward1');time.sleep(.8);sample('settle1')
 run_action('turn',[{'op':'key_state','key':'a','down':True},{'op':'wait_update','timeout_ms':900},{'op':'key_state','key':'a','down':False}]);sample('turn');screenshot('at-turn')
 def ask_start(i,source):
  artifact=source['native']['artifact'];image=Path(artifact['path']).read_bytes();digest=hashlib.sha256(image).hexdigest()
  if digest!=artifact['sha256']:raise RuntimeError('model image hash mismatch')
  Path(f'/exchange/image-{i}.png').write_bytes(image);q={'id':f'pilot-{i}','image_sha256':digest,'source_sequence':source['sequence'],'binding_geometry':source['pointer_binding']['geometry']};tmp=Path(f'/exchange/request-{i}.tmp');tmp.write_text(json.dumps(q));os.replace(tmp,f'/exchange/request-{i}.json');record['events'][f'request_{i}_ns']=time.monotonic_ns()
  limit=time.monotonic()+15
  while not Path(f'/exchange/started-{i}.json').exists():
   if time.monotonic()>limit:raise TimeoutError('model did not start')
   time.sleep(.01)
  record['events'][f'start_{i}_observed_ns']=time.monotonic_ns()
 def wait_done(i,worker=None):
  deadline=time.monotonic()+25
  while time.monotonic()<deadline and not game.is_episode_finished():
   time.sleep(.2);sample(f'pending-{i}')
   if Path(f'/exchange/done-{i}.json').exists():break
  else:raise TimeoutError('model done not observed')
  record['events'][f'done_{i}_observed_ns']=time.monotonic_ns()
  if worker is not None:
   worker.join(5)
   if worker.is_alive():raise TimeoutError('policy worker did not finish')
  value=json.loads(Path(f'/exchange/done-{i}.json').read_text())
  if value.get('ok') is not True:raise RuntimeError('model response invalid')
  return value
 first_source=bridge.observe();first_rgb=bridge.history[first_source['sequence']][1];ask_start(1,first_source);sample('policy-start');first=wait_done(1);record['model_calls']=1;record['policy_response']=first
 policy=first['grounding'];px,py=policy['target_x'],policy['target_y'];current=bridge.observe();current_rgb=bridge.history[current['sequence']][1];bounds=0<=px-4<px+4<=first_rgb.width and 0<=py-4<py+4<=first_rgb.height
 old=first_rgb.crop((px-4,py-4,px+4,py+4)).tobytes() if bounds else b'';now=current_rgb.crop((px-4,py-4,px+4,py+4)).tobytes() if bounds else b''
 distinct=len(set(tuple(old[i:i+3]) for i in range(0,len(old),3))) if old else 0
 center=abs(px-(geom[0]+geom[2]//2))<=40 and abs(py-(geom[1]+geom[3]//2))<=60
 patch_difference=sum(abs(a-b) for a,b in zip(old,now))/len(old) if old and len(old)==len(now) else 999
 eligible=bounds and center and distinct>=2 and patch_difference<=32 and first_source['pointer_binding']==current['pointer_binding']
 record['policy_gate']={'eligible':eligible,'bounds':bounds,'center':center,'patch_mean_abs_difference':patch_difference,'tolerance':32,'distinct_colors':distinct,'old_patch_sha256':hashlib.sha256(old).hexdigest(),'current_patch_sha256':hashlib.sha256(now).hexdigest(),'binding_equal':first_source['pointer_binding']==current['pointer_binding'],'policy':policy,'source_sequence':first_source['sequence'],'checked_sequence':current['sequence']};(out/'policy-gate.json').write_text(json.dumps(record['policy_gate'],indent=2)+'\n')
 ask_start(2,current);sample('second-pending-start');errs=[];worker=None;overlay=None;guard_events=[]
 if route in ('normal','inject') and policy['action']=='fire' and eligible and not Path('/exchange/done-2.json').exists():
  def fire():
   try:
    record['events']['policy_started_ns']=time.monotonic_ns();source=bridge.observe();anchor=[geom[0]+geom[2]//2,geom[1]+geom[3]-100];ref=bridge.mint_reference('fire',source['sequence'],anchor,region_size=(24,38));record['fire_offset']=ref['offset'];tail=[{'op':'key_state','key':'f','down':True},{'op':'wait_update','timeout_ms':policy['duration_ms']},{'op':'key_state','key':'f','down':False}];owner.dispatch_attempted=True
    def verify(stage,native,image):
     patch=image.crop((px-4,py-4,px+4,py+4)).tobytes();binding=native['pointer_binding']==current['pointer_binding'];difference=sum(abs(a-b) for a,b in zip(patch,now))/len(now) if len(patch)==len(now) and now else 999;valid=difference<=32 and binding and center;guard_events.append({'stage':stage,'sequence':native['sequence'],'patch_sha256':hashlib.sha256(patch).hexdigest(),'mean_abs_difference':difference,'tolerance':32,'binding_equal':binding,'eligible':valid,'observed_ns':time.monotonic_ns()});return valid
    with bridge.cancellation_scope('policy-token'):
     with bridge.input_guard('fire',ref['offset'],tail=tail,verify=verify,interaction='keyboard'):
      outcome=bridge.keyboard('fire',ref['offset'],tail=tail,expires_at_ns=time.monotonic_ns()+3_000_000_000)
    (out/'action-fire.json').write_text(json.dumps(outcome,indent=2)+'\n');record.setdefault('actions',[]).append(outcome);record['events']['policy_finished_ns']=time.monotonic_ns();record['policy_disposition']='completed' if outcome.get('status')=='completed' else 'refused_or_failed'
   except BaseException as exc:errs.append(repr(exc));record['policy_disposition']='worker_error'
   finally:(out/'policy-guard-events.json').write_text(json.dumps(guard_events,indent=2)+'\n')
  record['policy_disposition']='started';worker=threading.Thread(target=fire);worker.start()
  if route=='inject':
   code=d.keysym_to_keycode(XK.string_to_keysym('f'));limit=time.monotonic()+2;held=False
   while time.monotonic()<limit and worker.is_alive():
    keys=d.query_keymap()
    if keys[code//8]&(1<<(code%8)):held=True;break
    time.sleep(.005)
   record['monitor']={'observed_held':held,'keycode':code,'held_observed_ns':time.monotonic_ns()}
   if held:
    time.sleep(.06);overlay=d.screen().root.create_window(px-4,py-4,8,8,0,d.screen().root_depth,X.InputOutput,X.CopyFromParent,override_redirect=1,background_pixel=0xff00ff);overlay.map();overlay.configure(stack_mode=X.Above);d.sync();record['events']['overlay_mapped_ns']=time.monotonic_ns();record['overlay']={'x':px-4,'y':py-4,'width':8,'height':8,'color':'ff00ff'}
    from PIL import Image
    root=d.screen().root;raw=root.get_image(0,0,1280,1024,X.ZPixmap,0xffffffff);monitor_image=Image.frombytes('RGB',(1280,1024),raw.data,'raw','BGRX');monitor_image.save(out/'monitor-after.png');observed=monitor_image.crop((px-4,py-4,px+4,py+4)).tobytes();record['monitor']['observed_patch_sha256']=hashlib.sha256(observed).hexdigest();difference=sum(abs(a-b) for a,b in zip(observed,now))/len(now) if len(observed)==len(now) and now else 999;record['monitor']['mean_abs_difference']=difference;record['monitor']['tolerance']=32;record['monitor']['mismatch']=difference>32
    if difference>32:
     record['events']['cancel_requested_ns']=time.monotonic_ns();record['monitor']['cancel_response']=bridge.request_cancel('policy-token');record['events']['cancel_returned_ns']=time.monotonic_ns()
 elif route in ('normal','inject'):record['policy_disposition']='no_action_policy_or_gate'
 else:raise RuntimeError('unknown route')
 second=wait_done(2,worker);record['model_calls']=2;record['second_response']=second
 if overlay is not None:overlay.destroy();d.sync();record['events']['overlay_removed_ns']=time.monotonic_ns()
 if errs:raise RuntimeError('policy worker failed '+repr(errs))
 if record.get('monitor',{}).get('cancel_response',{}).get('status')!='cancel_requested':raise RuntimeError('recovery_precondition_unmet: cancellation not requested; stop')
 sample('second-model-done')
 review=bridge.review_window(w.id);record['recovery_review']={k:v for k,v in review.items() if k!='observation'};(out/'recovery-review.json').write_text(json.dumps(review,indent=2)+'\n')
 if review.get('status')!='reviewed':raise RuntimeError('fresh review refused')
 if 'fire_offset' in record:
  stale=bridge.keyboard('fire',record['fire_offset'],tail=[{'op':'key_chord','keys':['f']}],expires_at_ns=time.monotonic_ns()+2_000_000_000);record['stale_after_review']=stale;(out/'stale-after-review.json').write_text(json.dumps(stale,indent=2)+'\n')
  if stale.get('status')!='refused' or stale.get('input_dispatched') is not False:raise RuntimeError('old alias unexpectedly admitted')
 sample('after-review');third_source=review['observation'];third_rgb=bridge.history[third_source['sequence']][1];ask_start(3,third_source);sample('third-pending-start');third=wait_done(3);record['model_calls']=3;record['third_response']=third
 fresh_policy=third['grounding'];rx,ry=fresh_policy['target_x'],fresh_policy['target_y'];fresh=bridge.observe();fresh_rgb=bridge.history[fresh['sequence']][1];valid_box=0<=rx-4<rx+4<=third_rgb.width and 0<=ry-4<ry+4<=third_rgb.height
 old3=third_rgb.crop((rx-4,ry-4,rx+4,ry+4)).tobytes() if valid_box else b'';now3=fresh_rgb.crop((rx-4,ry-4,rx+4,ry+4)).tobytes() if valid_box else b'';diff3=sum(abs(a-b) for a,b in zip(old3,now3))/len(old3) if old3 and len(old3)==len(now3) else 999;colors3=len(set(tuple(old3[i:i+3]) for i in range(0,len(old3),3))) if old3 else 0;center3=abs(rx-(geom[0]+geom[2]//2))<=40 and abs(ry-(geom[1]+geom[3]//2))<=60;eligible3=valid_box and center3 and colors3>=2 and diff3<=32 and third_source['pointer_binding']==fresh['pointer_binding']
 record['recovery_gate']={'eligible':eligible3,'bounds':valid_box,'center':center3,'distinct_colors':colors3,'mean_abs_difference':diff3,'tolerance':32,'old_patch_sha256':hashlib.sha256(old3).hexdigest(),'current_patch_sha256':hashlib.sha256(now3).hexdigest(),'binding_equal':third_source['pointer_binding']==fresh['pointer_binding'],'policy':fresh_policy,'source_sequence':third_source['sequence'],'checked_sequence':fresh['sequence']};(out/'recovery-gate.json').write_text(json.dumps(record['recovery_gate'],indent=2)+'\n')
 from aim_policy import choose_nudge
 source_ok=valid_box and colors3>=2 and diff3<=32 and third_source['pointer_binding']==fresh['pointer_binding'];proposal=choose_nudge(fresh_policy['action'],rx,ry,geom,source_ok);record['aim_proposal']={'proposal':proposal,'source_valid':source_ok,'mode':os.environ['AIM_MODE']};(out/'aim-proposal.json').write_text(json.dumps(record['aim_proposal'],indent=2)+'\n')
 sample('before-aim')
 if os.environ['AIM_MODE']=='correct' and proposal is not None:
  key,duration=proposal;anchor=[geom[0]+geom[2]//2,geom[1]+geom[3]-100];aim_ref=bridge.mint_reference('aim',fresh['sequence'],anchor,region_size=(24,38));aim_tail=[{'op':'key_state','key':key,'down':True},{'op':'wait_update','timeout_ms':duration},{'op':'key_state','key':key,'down':False}];aim_checks=[]
  def aim_verify(stage,native,image):
   patch=image.crop((rx-4,ry-4,rx+4,ry+4)).tobytes();binding=native['pointer_binding']==fresh['pointer_binding'];difference=sum(abs(a-b) for a,b in zip(patch,now3))/len(now3) if len(patch)==len(now3) and now3 else 999;valid=difference<=32 and binding and source_ok;aim_checks.append({'stage':stage,'sequence':native['sequence'],'patch_sha256':hashlib.sha256(patch).hexdigest(),'mean_abs_difference':difference,'binding_equal':binding,'eligible':valid,'observed_ns':time.monotonic_ns()});return valid
  with bridge.cancellation_scope('aim-token'):
   with bridge.input_guard('aim',aim_ref['offset'],tail=aim_tail,verify=aim_verify,interaction='keyboard'):
    aim_result=bridge.keyboard('aim',aim_ref['offset'],tail=aim_tail,expires_at_ns=time.monotonic_ns()+3_000_000_000)
  record['aim_action']=aim_result;(out/'aim-action.json').write_text(json.dumps(aim_result,indent=2)+'\n');(out/'aim-guard-events.json').write_text(json.dumps(aim_checks,indent=2)+'\n')
  if aim_result.get('status')!='completed':raise RuntimeError('bounded aim refused or failed; stop')
 elif os.environ['AIM_MODE'] not in ('control','correct'):raise RuntimeError('invalid aim mode')
 sample('after-aim');source4=bridge.observe();rgb4=bridge.history[source4['sequence']][1];ask_start(4,source4);sample('fourth-pending-start');fourth=wait_done(4);record['model_calls']=4;record['fourth_response']=fourth
 p4=fourth['grounding'];x4,y4=p4['target_x'],p4['target_y'];fresh4=bridge.observe();image4=bridge.history[fresh4['sequence']][1];bounds4=0<=x4-4<x4+4<=rgb4.width and 0<=y4-4<y4+4<=rgb4.height;patch4=rgb4.crop((x4-4,y4-4,x4+4,y4+4)).tobytes() if bounds4 else b'';current4=image4.crop((x4-4,y4-4,x4+4,y4+4)).tobytes() if bounds4 else b'';diff4=sum(abs(a-b) for a,b in zip(patch4,current4))/len(patch4) if patch4 and len(patch4)==len(current4) else 999;colors4=len(set(tuple(patch4[i:i+3]) for i in range(0,len(patch4),3))) if patch4 else 0;center4=abs(x4-(geom[0]+geom[2]//2))<=40 and abs(y4-(geom[1]+geom[3]//2))<=60;eligible4=bounds4 and center4 and colors4>=2 and diff4<=32 and source4['pointer_binding']==fresh4['pointer_binding']
 record['final_gate']={'eligible':eligible4,'bounds':bounds4,'center':center4,'distinct_colors':colors4,'mean_abs_difference':diff4,'tolerance':32,'old_patch_sha256':hashlib.sha256(patch4).hexdigest(),'current_patch_sha256':hashlib.sha256(current4).hexdigest(),'binding_equal':source4['pointer_binding']==fresh4['pointer_binding'],'policy':p4,'source_sequence':source4['sequence'],'checked_sequence':fresh4['sequence']};(out/'final-gate.json').write_text(json.dumps(record['final_gate'],indent=2)+'\n')
 if p4['action']=='fire' and eligible4 and os.environ['FIRE_MODE']=='fire':
  anchor=[geom[0]+geom[2]//2,geom[1]+geom[3]-100];ref4=bridge.mint_reference('recovered',fresh4['sequence'],anchor,region_size=(24,38));tail4=[{'op':'key_state','key':'f','down':True},{'op':'wait_update','timeout_ms':p4['duration_ms']},{'op':'key_state','key':'f','down':False}];checks4=[]
  def verify4(stage,native,image):
   patch=image.crop((x4-4,y4-4,x4+4,y4+4)).tobytes();binding=native['pointer_binding']==fresh4['pointer_binding'];difference=sum(abs(a-b) for a,b in zip(patch,current4))/len(current4) if len(patch)==len(current4) and current4 else 999;valid=difference<=32 and binding and center4;checks4.append({'stage':stage,'sequence':native['sequence'],'patch_sha256':hashlib.sha256(patch).hexdigest(),'mean_abs_difference':difference,'binding_equal':binding,'eligible':valid,'observed_ns':time.monotonic_ns()});return valid
  with bridge.cancellation_scope('recovery-token'):
   with bridge.input_guard('recovered',ref4['offset'],tail=tail4,verify=verify4,interaction='keyboard'):
    resumed=bridge.keyboard('recovered',ref4['offset'],tail=tail4,expires_at_ns=time.monotonic_ns()+3_000_000_000)
  record['recovery_action']=resumed;(out/'recovery-action.json').write_text(json.dumps(resumed,indent=2)+'\n');(out/'recovery-guard-events.json').write_text(json.dumps(checks4,indent=2)+'\n');record['recovery_disposition']='completed' if resumed.get('status')=='completed' else 'refused_or_failed'
 elif p4['action']=='fire' and eligible4 and os.environ['FIRE_MODE']=='withhold':
  record['recovery_disposition']='control_withheld';time.sleep(p4['duration_ms']/1000)
 else:record['recovery_disposition']='no_action_policy_or_gate'
 sample('after-recovery')
 fifth_source=bridge.observe();fifth_rgb=bridge.history[fifth_source['sequence']][1];ask_start(5,fifth_source);sample('fifth-pending-start');fifth=wait_done(5);record['model_calls']=5;record['fifth_response']=fifth
 p5=fifth['grounding'];x5,y5=p5['target_x'],p5['target_y'];fresh5=bridge.observe();image5=bridge.history[fresh5['sequence']][1];bounds5=0<=x5-4<x5+4<=fifth_rgb.width and 0<=y5-4<y5+4<=fifth_rgb.height;old5=fifth_rgb.crop((x5-4,y5-4,x5+4,y5+4)).tobytes() if bounds5 else b'';now5=image5.crop((x5-4,y5-4,x5+4,y5+4)).tobytes() if bounds5 else b'';diff5=sum(abs(a-b) for a,b in zip(old5,now5))/len(old5) if old5 and len(old5)==len(now5) else 999;colors5=len(set(tuple(old5[i:i+3]) for i in range(0,len(old5),3))) if old5 else 0;center5=abs(x5-(geom[0]+geom[2]//2))<=40 and abs(y5-(geom[1]+geom[3]//2))<=60;eligible5=bounds5 and center5 and colors5>=2 and diff5<=32 and fifth_source['pointer_binding']==fresh5['pointer_binding']
 record['fifth_gate']={'eligible':eligible5,'policy':p5,'bounds':bounds5,'center':center5,'distinct_colors':colors5,'difference':diff5,'source_sequence':fifth_source['sequence'],'checked_sequence':fresh5['sequence'],'old_patch_sha256':hashlib.sha256(old5).hexdigest(),'current_patch_sha256':hashlib.sha256(now5).hexdigest(),'binding_equal':fifth_source['pointer_binding']==fresh5['pointer_binding']}
 if p5['action']=='fire' and eligible5:
  anchor=[geom[0]+geom[2]//2,geom[1]+geom[3]-100];ref5=bridge.mint_reference('fifth',fresh5['sequence'],anchor,region_size=(24,38));tail5=[{'op':'key_state','key':'f','down':True},{'op':'wait_update','timeout_ms':p5['duration_ms']},{'op':'key_state','key':'f','down':False}];checks5=[]
  def verify5(stage,native,image):
   patch=image.crop((x5-4,y5-4,x5+4,y5+4)).tobytes();binding=native['pointer_binding']==fresh5['pointer_binding'];difference=sum(abs(a-b) for a,b in zip(patch,now5))/len(now5) if now5 and len(patch)==len(now5) else 999;valid=binding and center5 and difference<=32;checks5.append({'stage':stage,'sequence':native['sequence'],'patch_sha256':hashlib.sha256(patch).hexdigest(),'difference':difference,'binding_equal':binding,'eligible':valid,'observed_ns':time.monotonic_ns()});return valid
  with bridge.cancellation_scope('fifth-token'):
   with bridge.input_guard('fifth',ref5['offset'],tail=tail5,verify=verify5,interaction='keyboard'):
    action5=bridge.keyboard('fifth',ref5['offset'],tail=tail5,expires_at_ns=time.monotonic_ns()+3_000_000_000)
  record['fifth_action']=action5;record['fifth_guards']=checks5;record['fifth_disposition']='action_'+str(action5.get('status'))
 else:record['fifth_disposition']='no_action_policy_or_gate'
 sample('after-fifth')
 retry_eligible=p5['action']=='fire' and bounds5 and center5 and colors5>=2 and fifth_source['pointer_binding']==fresh5['pointer_binding'] and diff5>32
 record['retry_eligible']=retry_eligible
 if retry_eligible:
  sixth_source=bridge.observe();sixth_rgb=bridge.history[sixth_source['sequence']][1];ask_start(6,sixth_source);sample('sixth-pending-start');sixth=wait_done(6);record['model_calls']=6;record['sixth_response']=sixth
  p6=sixth['grounding'];x6,y6=p6['target_x'],p6['target_y'];fresh6=bridge.observe();image6=bridge.history[fresh6['sequence']][1];bounds6=0<=x6-4<x6+4<=sixth_rgb.width and 0<=y6-4<y6+4<=sixth_rgb.height;old6=sixth_rgb.crop((x6-4,y6-4,x6+4,y6+4)).tobytes() if bounds6 else b'';now6=image6.crop((x6-4,y6-4,x6+4,y6+4)).tobytes() if bounds6 else b'';diff6=sum(abs(a-b) for a,b in zip(old6,now6))/len(old6) if old6 and len(old6)==len(now6) else 999;colors6=len(set(tuple(old6[i:i+3]) for i in range(0,len(old6),3))) if old6 else 0;center6=abs(x6-(geom[0]+geom[2]//2))<=40 and abs(y6-(geom[1]+geom[3]//2))<=60;eligible6=bounds6 and center6 and colors6>=2 and diff6<=32 and sixth_source['pointer_binding']==fresh6['pointer_binding']
  record['sixth_gate']={'eligible':eligible6,'policy':p6,'bounds':bounds6,'center':center6,'distinct_colors':colors6,'difference':diff6,'source_sequence':sixth_source['sequence'],'checked_sequence':fresh6['sequence'],'old_patch_sha256':hashlib.sha256(old6).hexdigest(),'current_patch_sha256':hashlib.sha256(now6).hexdigest(),'binding_equal':sixth_source['pointer_binding']==fresh6['pointer_binding']}
  if p6['action']=='fire' and eligible6:
   anchor=[geom[0]+geom[2]//2,geom[1]+geom[3]-100];ref6=bridge.mint_reference('sixth',fresh6['sequence'],anchor,region_size=(24,38));tail6=[{'op':'key_state','key':'f','down':True},{'op':'wait_update','timeout_ms':p6['duration_ms']},{'op':'key_state','key':'f','down':False}];checks6=[]
   def verify6(stage,native,image):
    patch=image.crop((x6-4,y6-4,x6+4,y6+4)).tobytes();binding=native['pointer_binding']==fresh6['pointer_binding'];difference=sum(abs(a-b) for a,b in zip(patch,now6))/len(now6) if now6 and len(patch)==len(now6) else 999;valid=binding and center6 and difference<=32;checks6.append({'stage':stage,'sequence':native['sequence'],'patch_sha256':hashlib.sha256(patch).hexdigest(),'difference':difference,'binding_equal':binding,'eligible':valid,'observed_ns':time.monotonic_ns()});return valid
   with bridge.cancellation_scope('sixth-token'):
    with bridge.input_guard('sixth',ref6['offset'],tail=tail6,verify=verify6,interaction='keyboard'):
     action6=bridge.keyboard('sixth',ref6['offset'],tail=tail6,expires_at_ns=time.monotonic_ns()+3_000_000_000)
   record['sixth_action']=action6;record['sixth_guards']=checks6;record['sixth_disposition']='action_'+str(action6.get('status'))
  else:record['sixth_disposition']='no_action_policy_or_gate'
  sample('after-sixth')
 else:
  record['sixth_disposition']='not_attempted';Path('/exchange/stop.json').write_text('{"stop":true}')
 for _ in range(8):
  if game.is_episode_finished():break
  time.sleep(.25);sample('post-model')
 screenshot('end');last=record['samples'][-1];record['displacement']=math.dist([before['x'],before['y']],[last['x'],last['y']]);record['health_delta']=last['health']-before['health'];record['kill_delta']=last['kills']-before['kills'];record['labels_seen']=sorted(set(y for x in record['samples'] for y in x['visible_labels']))
 record['close']=owner.close();owner=None
 keys=d.query_keymap();record['keys_down_after']=[key for key in ('w','e','d','a','f') if (lambda code:code and bool(keys[code//8]&(1<<(code%8))))(d.keysym_to_keycode(XK.string_to_keysym(key)))];record['status']='completed'

except BaseException as e:record['status']='error';record['error']=repr(e);(out/'traceback.txt').write_text(traceback.format_exc())
finally:
 Path('/exchange/stop.json').write_text('{"stop":true}')
 if owner is not None:
  try:record['finally_close']=owner.close()
  except BaseException as e:record['close_error']=repr(e)
 if game is not None:
  try:game.close()
  except BaseException as e:record['game_close_error']=repr(e)
 if d is not None:
  try:
   keys=d.query_keymap();record['finally_keys_down']=[key for key in ('w','e','d','a','f') if (lambda code:code and bool(keys[code//8]&(1<<(code%8))))(d.keysym_to_keycode(XK.string_to_keysym(key)))]
  except BaseException as e:record['finally_keymap_error']=repr(e)
  d.close()
 if x is not None and x.poll() is None:
  try:os.killpg(x.pid,signal.SIGTERM);x.wait(timeout=3)
  except BaseException as e:record['xvfb_close_error']=repr(e)
 (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')

# DRAFT — not opened

Research only: retain child-lifetime/resource exclusion composition c7n4.

Only additions under research/integration/ipc_child_lifetime_c7n4_v1/.
No existing source, workflow, root index or predecessor changes. Attach the
locally frozen complete24-case record, exact inherited/modified sources,
construction accounting correction, raw-only audit and effective controls.
Do not describe this as a current production fix or publicly preregistered run.

The controlled retained-FD cells exclude overlap, while inherited-FD-close
negative controls do not. Production adoption stays HOLD. Unique request IDs
and broker termination cannot establish resource quiescence. Old unresolved
child output remains unresolved; no replay or invented task success.

verify.py must pass from fresh restored bytes without starting scientific
actors. Inspect exact-head CI, path filters (including historical GUI runners)
and review before integration. No remote checks, review, merge or source
reachability is claimed here. No old or foreign branch should be deleted.

"""Raw-only reconstruction. Imports no broker, claim, lock gate or runner.

Checks actual process/byte observations; expected finite schedule is not a
replacement for source, /proc, child journal, or subprocess exit evidence.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent

def digest(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def lines(p):
    b=p.read_bytes()
    if b and not b.endswith(b'\n'):raise ValueError('incomplete raw JSONL')
    return [json.loads(x) for x in b.splitlines() if x]

class Auditor:
    def __init__(self):self.checks=0;self.errors=[]
    def ck(self,ok,msg):
        self.checks+=1
        if not ok:self.errors.append(msg)
    def eq(self,a,b,msg):self.ck(type(a) is type(b) and a==b,msg)
    def proc(self,v,msg):
        self.ck(type(v.get('present')) is bool,msg+':presence type')
        if not v.get('present'):return
        raw=v.get('stat_raw','');parts=raw[raw.rfind(')')+2:].split()
        self.ck(len(parts)>=20,msg+':proc raw')
        if len(parts)<20:return
        self.eq(v.get('state'),parts[0],msg+':state')
        self.eq(v.get('ppid'),int(parts[1]),msg+':ppid')
        self.eq(v.get('start_ticks'),int(parts[19]),msg+':start ticks')
        self.eq(v.get('pid'),int(raw.split(' ',1)[0]),msg+':pid')
        self.ck(parts[0] not in ('Z','X'),msg+':live nonzombie')
    def collect(self,root,rec,label,epoch,expected):
        c=rec['collections'][label];rid=rec[label]['id']
        self.eq(c.get('status'),expected,label+':collector status')
        for key in ['authority_granted','retry_allowed']:self.eq(c.get(key),False,label+':'+key)
        for key in ['task_success','service_success']:self.eq(c.get(key),None,label+':'+key)
        ip=root/'ipc'
        if expected=='PENDING_COMPLETION':
            self.ck(not (ip/(rid+'.settled.json')).exists(),label+':missing terminal evidence remains missing')
            return
        seal=read(ip/(rid+'.settled.json'));broker=read(ip/(rid+'.broker.json'))
        for suffix,key in [('.request.json','request_sha256'),('.response.jsonl','response_sha256'),('.broker.json','broker_receipt_sha256')]:
            self.eq(seal.get(key),digest((ip/(rid+suffix)).read_bytes()),label+':'+key)
        self.eq(seal.get('request_id'),rid,label+':seal id');self.eq(seal.get('broker_epoch'),epoch,label+':seal epoch')
        self.eq(broker.get('returncode'),0,label+':broker child return')
        self.eq(broker.get('authority_granted'),False,label+':broker authority')
        body=(ip/(rid+'.response.jsonl')).read_bytes()
        self.eq(c.get('response_utf8'),body.decode(),label+':exact delivered bytes')
        self.eq(c.get('response_sha256'),digest(body),label+':delivered digest')
        self.eq(c.get('request_id'),rid,label+':delivered id')
        self.eq(c.get('broker_epoch'),epoch,label+':delivered epoch')
    def case(self,root,record=None,spec=None):
        r=read(root/'RECORD.json') if record is None else record
        s=r['spec'];sid=s['id'];mode=s['mode'];scenario=s['scenario'];old=r['old']['id'];new=r['new']['id']
        if spec is not None:self.eq(s,spec,sid+':frozen schedule')
        self.eq(r.get('status'),'COMPLETE',sid+':complete')
        self.eq(r.get('cleanup_incidents'),[],sid+':no cleanup incident')
        journal=lines(root/'supervisor.jsonl')
        self.eq(r['events'],journal,sid+':journal retained exactly')
        for k,e in enumerate(journal):
            self.eq(e['ordinal'],k,sid+':ordinal')
            self.ck(type(e['ns']) is int and e['ns']>=0,sid+':clock type')
            if k:self.ck(e['ns']>=journal[k-1]['ns'],sid+':clock order')
        services=r['services'];stable=scenario=='STABLE'
        self.eq(len(services),1 if stable else 2,sid+':service count')
        allrows=[]
        for i,v in enumerate(services):
            log=lines(root/v['stdout']);allrows+=log
            self.eq((root/v['stderr']).read_bytes(),b'',sid+':broker stderr')
            self.eq(v.get('exit'),-15,sid+':actual broker wait')
            self.proc(v['initial_state'],sid+':broker proc')
            self.eq(v['initial_state']['pid'],v['pid'],sid+':broker pid binding')
            self.ck(any(e['kind']=='WAIT_SERVICE' and e['pid']==v['pid'] and type(e.get('returncode')) is int and e['returncode']==-15 for e in journal),sid+':wait journal')
            for e in log:
                self.eq(e['pid'],v['pid'],sid+':broker log pid');self.eq(e['epoch'],v['epoch'],sid+':broker log epoch')
            cmd='baseline.py' if mode=='REQUEST_ONLY' else 'resource_broker.py'
            self.eq(Path(v['argv'][3]).name,cmd,sid+':correct source selected')
            self.eq(v['env']['LOCK_MODE'],mode,sid+':mode bound')
        self.eq(r['old_claim_before'],r['old_claim_after'],sid+':old claim preserved')
        self.eq((root/'ipc'/(old+'.claim.json')).read_text(),r['old_claim_before'],sid+':claim bytes')
        oldclaim=json.loads(r['old_claim_before'])
        self.eq(oldclaim['epoch'],services[0]['epoch'],sid+':old epoch retained')
        if not stable:
            reuse=[e for e in lines(root/services[1]['stdout']) if e['kind']=='CLAIM_DECISION' and e['request_id']==old]
            self.eq(len(reuse),1,sid+':one old recheck');self.eq(reuse[0]['decision']['may_start'],False,sid+':no duplicate start')
        child={}
        for label,rid in [('old',old),('new',new)]:
            reqbytes=(root/'ipc'/(rid+'.request.json')).read_bytes();req=json.loads(reqbytes);prompt=json.loads(req['prompt'])
            self.eq(r[label]['request_sha256'],digest(reqbytes),sid+':request hash '+label)
            self.eq(req['request_id'],rid,sid+':request id '+label)
            self.eq(req['authority_granted'],False,sid+':request authority')
            self.eq(prompt['id'],rid,sid+':prompt id');self.eq(prompt['resource'],req['resource'],sid+':resource mapping')
            wanted='slot-b' if label=='new' and scenario=='CRASH_OTHER' else 'slot-a'
            self.eq(req['resource'],wanted,sid+':authored slot')
            self.eq(r[label]['resource'],req['resource'],sid+':record slot binding')
            starts=[e for e in allrows if e['kind']=='CHILD_START' and e['request_id']==rid]
            self.eq(len(starts),1,sid+':one actual child call '+label)
            entry=read(root/(rid+'.started.json'));finish=read(root/(rid+'.finished.json'));effect=read(root/(rid+'.effect.json'))
            child[label]=(entry,finish,effect)
            self.eq(entry['stdin'],req['prompt']+'\n',sid+':exact child stdin')
            for part in [entry,finish,effect]:self.eq(part['request_id'],rid,sid+':child identity');self.eq(part['pid'],entry['pid'],sid+':child pid')
            self.eq(effect['resource'],wanted,sid+':effect slot')
            self.eq(effect['kind'],'private_fixture_effect',sid+':scope')
            rel=[e for e in journal if e['kind']=='RELEASE_BARRIER' and e['request_id']==rid]
            self.eq(len(rel),1,sid+':one release command')
            self.ck(entry['entered_ns']<=rel[0]['ns']<=effect['committed_ns']<=finish['finished_ns'],sid+':entry/barrier/effect/finish order')
            exitrec=r['child_exits'][rid]
            self.eq(exitrec['pid'],entry['pid'],sid+':exit pid');self.eq(exitrec['returncode'],0,sid+':actual child exit')
            if label=='old' and not stable:
                self.eq(exitrec['source'],'subreaper_waitpid',sid+':actual orphan wait source')
                self.eq(exitrec.get('wait_status'),0,sid+':raw wait status')
                self.ck(any(e['kind']=='WAIT_ORPHAN' and e['pid']==entry['pid'] and type(e['wait_status']) is int and e['wait_status']==0 for e in journal),sid+':orphan wait event')
                self.eq(finish['stdout_delivered'],False,sid+':lost pipe not repaired')
            else:
                self.eq(exitrec['source'],'broker_subprocess_run',sid+':direct subprocess wait source')
                self.ck(any(e['kind']=='CHILD_FINISHED' and e['request_id']==rid and type(e['returncode']) is int and e['returncode']==0 for e in allrows),sid+':child return event')
                self.eq(finish['stdout_delivered'],True,sid+':live stdout')
            inherited=mode=='INHERITED'
            dropped=label=='old' and scenario=='CRASH_DROP'
            self.eq(len(entry['lock_fds_before']),1 if inherited else 0,sid+':fd inheritance')
            self.eq(len(entry['lock_fds_after']),1 if inherited and not dropped else 0,sid+':fd retained')
            self.eq(entry['drop_lock'],dropped,sid+':declared drop control')
            self.eq(len(finish['lock_fds_final']),1 if inherited and not dropped else 0,sid+':fd lifetime')
        obs=r['observations'];self.proc(obs['old_before'],sid+':old before')
        self.eq(obs['old_before']['ppid'],services[0]['pid'],sid+':real broker parent')
        self.eq(obs['old_before']['pid'],child['old'][0]['pid'],sid+':old proc identity')
        if not stable:
            q=obs['old_after_broker_exit'];self.proc(q,sid+':survivor')
            self.eq(q['pid'],child['old'][0]['pid'],sid+':surviving same child')
            self.eq(q['start_ticks'],obs['old_before']['start_ticks'],sid+':same incarnation')
            self.eq(q['ppid'],r['supervisor_pid'],sid+':subreaper adopted child')
            probe=obs['lock_after_broker_exit'];self.eq(probe['applicable'],mode!='REQUEST_ONLY',sid+':lock probe applicability')
            if mode!='REQUEST_ONLY':
                held=mode=='INHERITED' and scenario!='CRASH_DROP'
                self.eq(probe['acquired'],not held,sid+':independent actual lock probe')
                if held:
                    self.eq(len(q['lock_fds']),1,sid+':survivor holds fd')
                    self.eq(q['lock_fds'][0]['inode'],probe['inode'],sid+':same kernel inode')
                    self.eq(q['lock_fds'][0]['device'],probe['device'],sid+':same device')
        busy=(mode=='INHERITED' and scenario=='CRASH_SAME')
        self.eq(r['initial_new']['kind'],'RESOURCE_BUSY' if busy else 'STARTED',sid+':first new disposition')
        self.proc(obs['decision_old'],sid+':decision old');self.proc(obs['decision_new'],sid+':decision new')
        self.eq(obs['decision_new']['present'],not busy,sid+':new child at decision')
        self.eq(obs['decision_old']['present'],not stable,sid+':old child at decision')
        simultaneous=(obs['decision_old']['present'] is True and obs['decision_new']['present'] is True)
        same_slot=r['old']['resource']==r['new']['resource']
        overlap=simultaneous and same_slot
        expect_overlap=not stable and scenario!='CRASH_OTHER' and not busy
        self.eq(overlap,expect_overlap,sid+':resource overlap gate')
        if busy:
            self.ck(any(e['kind']=='RESOURCE_BUSY' and e['request_id']==new for e in allrows),sid+':actual busy receipt')
            self.ck(child['old'][1]['finished_ns']<=child['new'][0]['entered_ns'],sid+':serialized child work')
        self.collect(root,r,'old',services[0]['epoch'],'RESULT_AVAILABLE' if stable else 'PENDING_COMPLETION')
        self.collect(root,r,'new',services[-1]['epoch'],'RESULT_AVAILABLE')
        for seq in [obs['final_children'],obs['final_services']]:
            for x in seq:self.eq(x['present'],False,sid+':no retained process')
        self.eq(len(obs['final_children']),2,sid+':two child endpoints')
        self.eq(sorted(x['pid'] for x in obs['final_children']),sorted(child[k][0]['pid'] for k in ('old','new')),sid+':cleanup pid identity')
        self.eq(sorted(x['pid'] for x in obs['final_services']),sorted(v['pid'] for v in services),sid+':broker cleanup identity')
        self.eq(len(list((root/'ipc').glob('*.request.json'))),2,sid+':two distinct requests')
        self.eq(len(list(root.glob('*.fifo'))),0,sid+':fifo cleanup')
        return {'id':sid,'mode':mode,'scenario':scenario,'resource_overlap':overlap,
                'concurrent_other_resource':simultaneous and not same_slot,
                'new_initial':r['initial_new']['kind'],'old_result':r['collections']['old']['status'],
                'new_result':r['collections']['new']['status']}


def audit_case(path):
    a=Auditor();row=a.case(path)
    return {'checks':a.checks,'errors':a.errors,'rows':[row]}

def audit_formal(root):
    a=Auditor();freeze=read(ROOT/'FREEZE.json');schedule=read(ROOT/'SCHEDULE.json');rows=[]
    for name,h in freeze['files'].items():a.eq(digest((ROOT/name).read_bytes()),h,'source '+name)
    for bi in range(4):
        meta=read(root/f'batch-{bi}.outer.json');a.eq(meta['returncode'],0,'batch decision')
        invoke=read(root/f'batch-{bi}.invocation.json');a.eq(invoke['returncode'],0,'actual outer wait')
        a.eq(invoke['timed_out'],False,'outer did not time out')
        a.eq((root/f'batch-{bi}.invocation.stderr').read_bytes(),b'','outer stderr')
        batch=read(root/f'batch-{bi}/BATCH.json');a.eq(batch['status'],'COMPLETE','batch complete')
        wanted=[s for s in schedule if s['batch']==bi]
        a.eq(len(batch['cases']),6,'batch size')
        a.eq(sorted(p.name for p in (root/f'batch-{bi}').iterdir() if p.is_dir()),sorted(s['id'] for s in wanted),'no extra or excluded case directories')
        for s,entry in zip(wanted,batch['cases']):
            a.eq(entry['spec'],s,'outer spec');a.eq(entry['returncode'],0,'case exit')
            p=root/f'batch-{bi}'/s['id']
            a.eq(digest((p/'RECORD.json').read_bytes()),entry['record_sha256'],'record byte identity')
            a.eq((root/f'batch-{bi}'/(s['id']+'.stderr')).read_bytes(),b'','case stderr')
            rows.append(a.case(p,spec=s))
    a.eq(len(rows),24,'complete denominator')
    summary={}
    for mode in ('REQUEST_ONLY','PARENT_ONLY','INHERITED'):
        own=[x for x in rows if x['mode']==mode]
        summary[mode]={'cases':len(own),'same_resource_overlap':sum(x['resource_overlap'] for x in own),
                       'different_resource_progress':sum(x['concurrent_other_resource'] for x in own),
                       'new_results':sum(x['new_result']=='RESULT_AVAILABLE' for x in own),
                       'old_pending':sum(x['old_result']=='PENDING_COMPLETION' for x in own)}
    return {'status':'PASS_LOCAL_CHILD_LIFETIME_BOUNDARY' if not a.errors else 'HOLD_OR_FAIL',
            'checks':a.checks,'errors':a.errors,'summary':summary,'rows':rows,
            'production_adoption':'HOLD_CHILD_DESCRIPTOR_CONTRACT_UNVALIDATED','formal_reexecutions':0}


def main():
    p=argparse.ArgumentParser();p.add_argument('path',type=Path);p.add_argument('--case',action='store_true')
    x=p.parse_args()
    try:result=audit_case(x.path) if x.case else audit_formal(x.path)
    except Exception as e:
        result={'status':'HOLD_EVIDENCE_INCOMPLETE','errors':[type(e).__name__+': '+str(e)]}
    print(json.dumps(result,sort_keys=True,indent=2))
    return 1 if result['errors'] else 0
if __name__=='__main__':raise SystemExit(main())

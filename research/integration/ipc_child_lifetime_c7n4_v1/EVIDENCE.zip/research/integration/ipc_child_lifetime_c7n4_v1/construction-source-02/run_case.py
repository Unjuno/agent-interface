"""One foreground lifecycle case. Linux subreaper owns orphan cleanup/waitpid.

No scenario policy sees oracle snapshots. All data, FIFOs and processes are
private to this absent output directory. Deliberate termination targets only
the recorded broker; the child remains gated until the supervisor releases it.
"""
import argparse
import ctypes
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback
from contract import collect, encode

ROOT=Path(__file__).resolve().parent
MODES=('REQUEST_ONLY','PARENT_ONLY','INHERITED')
SCENARIOS=('STABLE','CRASH_SAME','CRASH_OTHER','CRASH_DROP')

def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,v):p.write_bytes(encode(v))
def load(p):return json.loads(p.read_bytes())
def state(pid):
    p=Path('/proc')/str(pid)
    try:
        raw=(p/'stat').read_text();tail=raw[raw.rfind(')')+2:].split()
        fds=[]
        for f in (p/'fd').iterdir():
            try:
                target=os.readlink(f)
                if target.endswith('.lock'):
                    st=os.stat(f);fds.append({'fd':int(f.name),'target':target,'inode':st.st_ino,'device':st.st_dev,
                                             'fdinfo':(p/'fdinfo'/f.name).read_text()})
            except OSError:pass
        return {'pid':pid,'present':True,'stat_raw':raw,'state':tail[0],
                'ppid':int(tail[1]),'start_ticks':int(tail[19]),'lock_fds':fds}
    except FileNotFoundError:return {'pid':pid,'present':False}

def service_rows(path):
    raw=path.read_bytes()
    lines=raw.split(b'\n')[:-1]
    return [json.loads(x) for x in lines if x]

class Case:
    def __init__(self,out,spec):
        self.out=out;out.mkdir(parents=True,exist_ok=False)
        self.spec=spec;self.procs=[];self.handles=[];self.controls={};self.child_pids=[];self.events=[]
        self.raw={'spec':spec,'supervisor_pid':os.getpid(),'observations':{},'services':[],
                  'child_exits':{},'collections':{},'status':'RUNNING'}
        self.journal=(out/'supervisor.jsonl').open('xb')
    def log(self,kind,**extra):
        row={'ordinal':len(self.events),'kind':kind,'ns':time.monotonic_ns(),**extra}
        self.events.append(row);self.journal.write(encode(row));self.journal.flush()
    def wait(self,fn,what,limit=3.0):
        end=time.monotonic()+limit
        while time.monotonic()<end:
            v=fn()
            if v:return v
            time.sleep(.003)
        raise TimeoutError(what)
    def launch(self,epoch):
        i=len(self.procs); stdout=self.out/f'service-{i}.stdout';stderr=self.out/f'service-{i}.stderr'
        f=stdout.open('xb');g=stderr.open('xb');self.handles.extend([f,g])
        env={'PATH':'/usr/bin:/bin','HOME':str(self.out),'CODEX_EXE':str(ROOT/'fake_child.py'),
             'HOST_MODEL_BROKER_TIMEOUT_S':'10','HOST_MODEL_BROKER_EPOCH':epoch,
             'STUDY_DIR':str(self.out),'LOCK_MODE':self.spec['mode'],'PYTHONDONTWRITEBYTECODE':'1'}
        script='baseline.py' if self.spec['mode']=='REQUEST_ONLY' else 'resource_broker.py'
        cmd=[sys.executable,'-S','-B',str(ROOT/script),'--ipc',str(self.out/'ipc'),'--repo',str(self.out)]
        p=subprocess.Popen(cmd,stdout=f,stderr=g,env=env,cwd=ROOT)
        self.procs.append(p)
        record={'pid':p.pid,'epoch':epoch,'argv':cmd,'env':env,'stdout':stdout.name,'stderr':stderr.name,'exit':None}
        self.raw['services'].append(record);self.log('START_SERVICE',pid=p.pid,epoch=epoch)
        self.wait(lambda:any(r['kind']=='SERVICE_READY' for r in service_rows(stdout)),'service ready')
        record['initial_state']=state(p.pid)
        return i,p
    def event(self,i,kind,rid):
        return next((r for r in service_rows(self.out/f'service-{i}.stdout') if r['kind']==kind and r['request_id']==rid),None)
    def stop_service(self,i):
        p=self.procs[i]
        if p.poll() is not None:raise RuntimeError('service already exited')
        self.log('SIGNAL_SERVICE',pid=p.pid,signal=signal.SIGTERM)
        p.terminate();code=p.wait(timeout=2)
        self.raw['services'][i]['exit']=code;self.log('WAIT_SERVICE',pid=p.pid,returncode=code)
        if code!=-signal.SIGTERM:raise RuntimeError('unexpected broker exit')
    def request(self,label,resource,drop):
        rid=hashlib.sha256((self.spec['id']+':'+label).encode()).hexdigest()[:32]
        fifo=self.out/(rid+'.fifo');os.mkfifo(fifo,0o600)
        self.controls[rid]=os.open(fifo,os.O_RDWR|os.O_NONBLOCK)
        item={'request_id':rid,'resource':resource,'authority_granted':False,
              'prompt':json.dumps({'id':rid,'resource':resource,'drop_lock':drop},sort_keys=True),
              'schema':str(self.out/'schema.json'),'working':str(self.out),'image':None}
        raw=encode(item);p=self.out/'ipc'/(rid+'.request.json')
        tmp=p.with_suffix('.tmp');tmp.write_bytes(raw);os.replace(tmp,p)
        self.log('PUBLISH_REQUEST',label=label,request_id=rid,sha256=sha(raw),resource=resource)
        self.raw[label]={'id':rid,'request_sha256':sha(raw),'resource':resource}
        return rid
    def started(self,rid):
        p=self.out/(rid+'.started.json')
        if not p.exists():return None
        row=load(p)
        if row['pid'] not in self.child_pids:self.child_pids.append(row['pid'])
        return row
    def release(self,rid):
        self.log('RELEASE_BARRIER',request_id=rid,bytes_hex='52')
        if os.write(self.controls[rid],b'R')!=1:raise RuntimeError('short barrier write')
    def wait_orphan(self,rid,pid):
        def poll():
            x=os.waitpid(pid,os.WNOHANG)
            return x if x[0] else None
        got,status=self.wait(poll,'orphan exit',3)
        code=os.waitstatus_to_exitcode(status)
        self.raw['child_exits'][rid]={'pid':got,'returncode':code,'wait_status':status,'source':'subreaper_waitpid'}
        self.log('WAIT_ORPHAN',request_id=rid,pid=got,returncode=code,wait_status=status)
        if code!=0:raise RuntimeError('fixture child failed')
    def settled(self,i,rid):
        e=self.wait(lambda:self.event(i,'SETTLED',rid),'settlement')
        ce=self.event(i,'CHILD_FINISHED',rid)
        if ce is None or ce['returncode']!=0:raise RuntimeError('missing child return')
        ch=self.started(rid)
        self.raw['child_exits'][rid]={'pid':ch['pid'],'returncode':ce['returncode'],'source':'broker_subprocess_run'}
        self.log('OBSERVE_SETTLEMENT',request_id=rid,service_pid=self.procs[i].pid)
    def probe_lock(self):
        p=self.out/'ipc/locks/slot-a.lock'
        if not p.exists():return {'applicable':False}
        st=p.stat();fd=os.open(p,os.O_RDWR)
        try:
            try:fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);acquired=True
            except BlockingIOError:acquired=False
            return {'applicable':True,'acquired':acquired,'inode':st.st_ino,'device':st.st_dev}
        finally:os.close(fd)
    def run(self):
        lib=ctypes.CDLL(None,use_errno=True)
        lib.prctl.argtypes=[ctypes.c_int,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_ulong]
        lib.prctl.restype=ctypes.c_int
        if lib.prctl(36,1,0,0,0)!=0:raise OSError(ctypes.get_errno(),'PR_SET_CHILD_SUBREAPER')
        self.log('SUBREAPER_ENABLED',value=1)
        (self.out/'ipc').mkdir();save(self.out/'schema.json',{'type':'object'})
        e1=sha((self.spec['id']+':epoch1').encode())[:32];e2=sha((self.spec['id']+':epoch2').encode())[:32]
        i,p=self.launch(e1)
        old=self.request('old','slot-a',self.spec['scenario']=='CRASH_DROP')
        a=self.wait(lambda:self.started(old),'old entered');oldpid=a['pid']
        self.log('OBSERVE_OLD_ENTERED',request_id=old,pid=oldpid)
        self.raw['observations']['old_before']=state(oldpid)
        claim=self.out/'ipc'/(old+'.claim.json')
        self.raw['old_claim_before']=claim.read_text()
        if self.spec['scenario']=='STABLE':
            self.release(old);self.settled(i,old)
        else:
            self.stop_service(i)
            self.raw['observations']['old_after_broker_exit']=state(oldpid)
            self.raw['observations']['lock_after_broker_exit']=self.probe_lock()
            self.log('OBSERVE_SURVIVOR',state=self.raw['observations']['old_after_broker_exit'],
                     lock=self.raw['observations']['lock_after_broker_exit'])
            i,p=self.launch(e2)
            self.wait(lambda:self.event(i,'CLAIM_DECISION',old),'old-claim recheck')
        newres='slot-b' if self.spec['scenario']=='CRASH_OTHER' else 'slot-a'
        new=self.request('new',newres,False)
        def decision():
            s=self.started(new)
            if s:return {'kind':'STARTED','child':s}
            busy=self.event(i,'RESOURCE_BUSY',new)
            if busy:return {'kind':'RESOURCE_BUSY','broker_event':busy}
            return None
        d=self.wait(decision,'new request start/busy')
        self.raw['initial_new']=d
        self.raw['observations']['decision_old']=state(oldpid)
        b=self.started(new)
        self.raw['observations']['decision_new']=state(b['pid']) if b else {'present':False}
        self.log('OBSERVE_NEW_DECISION',kind_observed=d['kind'],old_state=self.raw['observations']['decision_old'],
                 new_state=self.raw['observations']['decision_new'])
        if d['kind']=='RESOURCE_BUSY':
            self.release(old);self.wait_orphan(old,oldpid)
            b=self.wait(lambda:self.started(new),'new after old exit')
            self.log('OBSERVE_NEW_AFTER_OLD_EXIT',request_id=new,pid=b['pid'])
            self.release(new);self.settled(i,new)
        else:
            self.release(new);self.settled(i,new)
            if self.spec['scenario']!='STABLE':
                self.release(old);self.wait_orphan(old,oldpid)
        for label,rid,epoch in [('old',old,e1),('new',new,e1 if self.spec['scenario']=='STABLE' else e2)]:
            self.raw['collections'][label]=collect(self.out/'ipc',rid,self.raw[label]['request_sha256'],epoch)
        self.raw['old_claim_after']=claim.read_text()
        self.stop_service(i)
        self.raw['observations']['final_children']=[state(pid) for pid in self.child_pids]
        self.raw['observations']['final_services']=[state(p.pid) for p in self.procs]
        if any(x['present'] for x in self.raw['observations']['final_children']):raise RuntimeError('child residual')
        self.raw['status']='COMPLETE'
    def cleanup(self):
        failures=[]
        if self.raw['status'] != 'COMPLETE':
            for rid,fd in self.controls.items():
                try:
                    os.write(fd,b'R');self.log('CLEANUP_RELEASE_BARRIER',request_id=rid,bytes_hex='52')
                except OSError:pass
        for i,p in enumerate(self.procs):
            if p.poll() is None:
                p.terminate()
                try:p.wait(timeout=1)
                except subprocess.TimeoutExpired:p.kill();p.wait(timeout=1)
                if self.raw['services'][i]['exit'] is None:
                    self.raw['services'][i]['cleanup_exit']=p.returncode
        # Only this case's recorded/reparented child processes are considered.
        for pid in self.child_pids:
            try:
                got,status=os.waitpid(pid,os.WNOHANG)
                if not got:
                    os.kill(pid,signal.SIGTERM)
                    self.wait(lambda:os.waitpid(pid,os.WNOHANG)[0],'cleanup wait',1)
                failures.append({'pid':pid,'unexpected_cleanup_wait':True})
            except ChildProcessError:pass
            except (OSError,TimeoutError) as ex:failures.append({'pid':pid,'error':str(ex)})
        for rid,fd in self.controls.items():
            os.close(fd);(self.out/(rid+'.fifo')).unlink(missing_ok=True)
        for h in self.handles:h.close()
        self.raw['cleanup_incidents']=failures
        self.raw['events']=self.events
        self.journal.close();save(self.out/'RECORD.json',self.raw)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);ap.add_argument('--spec',required=True)
    a=ap.parse_args();spec=json.loads(a.spec)
    if spec['mode'] not in MODES or spec['scenario'] not in SCENARIOS:raise ValueError('invalid schedule')
    c=Case(a.out.resolve(),spec)
    try:c.run();code=0
    except BaseException as ex:
        c.raw['status']='STOP';c.raw['exception']=type(ex).__name__+': '+str(ex)
        (c.out/'STOP.traceback').write_text(traceback.format_exc());code=2
    finally:c.cleanup()
    print(json.dumps({'id':spec['id'],'status':c.raw['status'],'exit':code}))
    return code
if __name__=='__main__':raise SystemExit(main())

"""Capture the actual foreground batch process exit, not its self-report."""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
ROOT=Path(__file__).resolve().parent

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--batch',type=int,required=True)
    a=p.parse_args();out=a.out.resolve();out.mkdir(exist_ok=True)
    dest=out/f'batch-{a.batch}.invocation.json'
    if dest.exists() or (out/f'batch-{a.batch}.CONSUMED').exists():raise FileExistsError('consumed allocation')
    cmd=[sys.executable,'-S','-B',str(ROOT/'execute_batch.py'),'--out',str(out),'--batch',str(a.batch)]
    started=time.monotonic_ns();q=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    timed=False
    try:stdout,stderr=q.communicate(timeout=35)
    except subprocess.TimeoutExpired:
        timed=True;os.killpg(q.pid,signal.SIGTERM);stdout,stderr=q.communicate(timeout=3)
    (out/f'batch-{a.batch}.invocation.stdout').write_bytes(stdout)
    (out/f'batch-{a.batch}.invocation.stderr').write_bytes(stderr)
    result={'argv':cmd,'pid':q.pid,'returncode':q.returncode,'timed_out':timed,
            'start_ns':started,'end_ns':time.monotonic_ns()}
    dest.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps(result,sort_keys=True))
    return 2 if timed or q.returncode else 0
if __name__=='__main__':raise SystemExit(main())

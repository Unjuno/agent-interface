"""Excluded deterministic engineering tests; no broker/model/provider starts."""
import ast
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from resource_gate import reserve, close_reservation

class Gates(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.epoch='e'*32;os.environ['HOST_MODEL_BROKER_EPOCH']=self.epoch;os.environ['LOCK_MODE']='INHERITED'
        self.fds=[]
    def tearDown(self):
        for f in self.fds:
            try:os.close(f)
            except OSError:pass
        self.tmp.cleanup()
    def take(self,rid='a'*32,slot='slot-a'):
        b=(json.dumps({'request_id':rid,'authority_granted':False})+'\n').encode()
        with contextlib.redirect_stdout(io.StringIO()):ans,fd=reserve(self.root,rid,b,self.epoch,slot)
        if fd is not None:self.fds.append(fd)
        return ans,fd
    def test_same_slot_waits_without_claiming_next(self):
        a,fd=self.take();b,_=self.take('b'*32)
        self.assertTrue(a['may_start']);self.assertTrue(b['defer']);self.assertFalse((self.root/('b'*32+'.claim.json')).exists())
        os.close(fd);self.fds.remove(fd)
        c,_=self.take('b'*32);self.assertTrue(c['may_start'])
    def test_distinct_slots_progress(self):
        self.assertTrue(self.take()[0]['may_start']);self.assertTrue(self.take('b'*32,'slot-b')[0]['may_start'])
    def test_old_claim_remains_unknown(self):
        a,fd=self.take();p=self.root/('a'*32+'.claim.json');b=p.read_bytes()
        r,other=self.take();self.assertFalse(r['may_start']);self.assertIsNone(other);self.assertEqual(p.read_bytes(),b)
    def test_close_one_reference_not_explicit_unlock(self):
        _,fd=self.take();dup=os.dup(fd);self.fds.append(dup)
        close_reservation(fd);self.fds.remove(fd)
        self.assertTrue(self.take('b'*32)[0]['defer'])
        os.close(dup);self.fds.remove(dup)
        self.assertTrue(self.take('b'*32)[0]['may_start'])
    def test_invalid_slot_has_no_claim(self):
        for slot in (None,True,4,[],{},'../bad','unknown'):
            self.assertEqual(self.take(slot=slot)[0]['status'],'HOLD_RESOURCE_SHAPE')
        self.assertEqual(list(self.root.iterdir()),[])
    def test_claim_not_removed_on_parent_close(self):
        _,fd=self.take();close_reservation(fd);self.fds.remove(fd)
        self.assertFalse(self.take()[0]['may_start'])
    def test_subprocess_call_changes_only_pass_fds(self):
        root=Path(__file__).resolve().parent
        def find(name):
            t=ast.parse((root/name).read_text())
            return next(n for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='subprocess' and n.func.attr=='run')
        a=find('baseline.py');b=find('resource_broker.py')
        self.assertEqual([x.arg for x in b.keywords if x.arg not in [y.arg for y in a.keywords]],['pass_fds'])
        b.keywords=[x for x in b.keywords if x.arg!='pass_fds']
        self.assertEqual(ast.dump(a),ast.dump(b))
    def test_main_source_object_identity(self):
        b=(Path(__file__).resolve().parent/'source/main_broker.py').read_bytes()
        self.assertEqual(hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'f307daafdfd36d1ab4faf39bb36c36350e6e67e4')

if __name__=='__main__':unittest.main(verbosity=2)

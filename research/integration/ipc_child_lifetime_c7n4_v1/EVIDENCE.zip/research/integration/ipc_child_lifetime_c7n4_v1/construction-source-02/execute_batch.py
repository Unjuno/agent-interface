"""Foreground bounded orchestration; transport limits are not research questions."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
ROOT=Path(__file__).resolve().parent

def put(p,v):p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);ap.add_argument('--batch',type=int,required=True)
    x=ap.parse_args();out=x.out.resolve();out.mkdir(exist_ok=True)
    if x.batch not in range(4):raise ValueError('batch range')
    if x.batch:
        old=json.loads((out/f'batch-{x.batch-1}.outer.json').read_text())
        if type(old['returncode']) is not int or old['returncode']!=0:raise ValueError('prior batch not complete')
    freeze=json.loads((ROOT/'FREEZE.json').read_text())
    for n,h in freeze['files'].items():
        if sha(ROOT/n)!=h:raise ValueError('source drift: '+n)
    dest=out/f'batch-{x.batch}';dest.mkdir(exist_ok=False)
    consumed=out/f'batch-{x.batch}.CONSUMED';consumed.write_text('consumed once\n')
    specs=[s for s in json.loads((ROOT/'SCHEDULE.json').read_text()) if s['batch']==x.batch]
    entries=[];code=0;start=time.monotonic_ns()
    for spec in specs:
        cmd=[sys.executable,'-S','-B',str(ROOT/'run_case.py'),'--out',str(dest/spec['id']),'--spec',json.dumps(spec,sort_keys=True)]
        a=time.monotonic_ns();p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        timedout=False
        try:stdout,stderr=p.communicate(timeout=12)
        except subprocess.TimeoutExpired:
            timedout=True;os.killpg(p.pid,signal.SIGTERM)
            try:stdout,stderr=p.communicate(timeout=2)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);stdout,stderr=p.communicate(timeout=2)
        (dest/(spec['id']+'.stdout')).write_bytes(stdout);(dest/(spec['id']+'.stderr')).write_bytes(stderr)
        rec=dest/spec['id']/'RECORD.json'
        entry={'spec':spec,'argv':cmd,'pid':p.pid,'returncode':p.returncode,'timeout':timedout,
               'start_ns':a,'end_ns':time.monotonic_ns(),'record_sha256':sha(rec) if rec.exists() else None}
        entries.append(entry);put(dest/'BATCH.json',{'status':'RUNNING','cases':entries})
        if p.returncode!=0 or timedout:code=2;break
    put(dest/'BATCH.json',{'status':'COMPLETE' if code==0 and len(entries)==6 else 'STOP','cases':entries})
    put(out/f'batch-{x.batch}.outer.json',{'batch':x.batch,'returncode':code,
        'actual_case_exits':[e['returncode'] for e in entries], 'start_ns':start,'end_ns':time.monotonic_ns(),
        'scope':'returncode is batch decision; each case returncode is actual Popen wait; outer invocation additionally recorded by caller'})
    print(json.dumps({'batch':x.batch,'cases':len(entries),'returncode':code}))
    return code
if __name__=='__main__':raise SystemExit(main())

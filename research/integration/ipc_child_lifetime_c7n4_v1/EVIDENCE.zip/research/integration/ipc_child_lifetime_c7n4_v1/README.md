# IPC child-lifetime composition c7n4 — research evidence only

Read REPORT_JA.md and PLAN.md. Prospective local freeze, NOT public GitHub
preregistration. Result:PASS_LOCAL_CHILD_LIFETIME_BOUNDARY; production adoption
HOLD_CHILD_DESCRIPTOR_CONTRACT_UNVALIDATED. All24 cases are present, including
two negative inherited-FD-close overlaps. No model, GUI or production change.

Read-only reproduction, from this directory:
```
python -S -B verify.py
```
verify.py checks every retained byte,20 frozen source identities and reruns only
the raw auditor, effective controls and8 pure gate tests. It starts NO scientific
broker/child. Never rerun launch_batch.py/execute_batch.py/run_case.py with the
consumed allocation. No formal replay is necessary to verify these artifacts.

Directory snapshot only, not a full checkout. Runtime paths/IDs in raw records
are historical data, not instructions to open existing processes or resources.
The separately attached predecessor ZIP is identified in SOURCE_IDENTITY.json;
this package does not claim to include that entire old archive. New data are all
retained as normal files, not regenerated from a compact model.

No remote Issue/PR/commit exists for this study in this session. Drafts are
publication text, not proof of an action. Recheck collisions and applicable PR
workflow triggers before any later upload. Current source implementation is a
finite cooperative fixture proposal, not a drop-in safety wrapper for arbitrary
executables. All referenced old and parallel Issues keep their own statuses.

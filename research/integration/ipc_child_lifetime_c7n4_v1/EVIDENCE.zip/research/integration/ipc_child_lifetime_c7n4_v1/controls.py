"""Effective semantic mutation controls. No study/child is invoked."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
from audit import Auditor

def enc(x):return json.dumps(x,sort_keys=True,separators=(',',':')).encode()
def run(path):
    original=json.loads((path/'RECORD.json').read_bytes());a=Auditor();a.case(path,record=original)
    if a.errors:raise ValueError('control baseline is not passing')
    baseline_checks=a.checks
    rid=original['old']['id']
    variants=[
      ('boolean_child_exit',lambda r:r['child_exits'][rid].update(returncode=False)),
      ('missing_child_exit',lambda r:r['child_exits'][rid].update(returncode=None)),
      ('false_broker_exit',lambda r:r['services'][0].update(exit=0)),
      ('changed_request_digest',lambda r:r['old'].update(request_sha256='0'*64)),
      ('changed_old_claim',lambda r:r.update(old_claim_after=r['old_claim_after']+' ')),
      ('changed_parent_binding',lambda r:r['observations']['old_before'].update(ppid=-1)),
      ('changed_process_lifetime',lambda r:r['observations']['old_before'].update(start_ticks=0)),
      ('changed_new_classification',lambda r:r['initial_new'].update(kind='UNSUPPORTED_SUCCESS')),
      ('invented_task_success',lambda r:r['collections']['old'].update(task_success=True)),
      ('missing_new_result',lambda r:r['collections']['new'].update(status='PENDING_COMPLETION')),
      ('lost_child_cleanup',lambda r:r['observations'].update(final_children=[])),
      ('wrong_resource_binding',lambda r:r['new'].update(resource='not-the-recorded-resource'))]
    results=[]
    for name,mut in variants:
        v=copy.deepcopy(original);mut(v);changed=enc(v)!=enc(original)
        a=Auditor();crash=None
        try:a.case(path,record=v)
        except Exception as e:crash=type(e).__name__+': '+str(e)
        results.append({'name':name,'effective':changed,'rejected':bool(a.errors) and crash is None,
                        'parser_crash':crash,'errors':a.errors,'changed_sha256':hashlib.sha256(enc(v)).hexdigest()})
    return {'case':original['spec']['id'],'baseline_checks':baseline_checks,'controls':results,
            'pass':all(r['effective'] and r['rejected'] and r['parser_crash'] is None for r in results)}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('case',type=Path);a=p.parse_args()
    v=run(a.case);print(json.dumps(v,sort_keys=True,indent=2));raise SystemExit(0 if v['pass'] else 1)

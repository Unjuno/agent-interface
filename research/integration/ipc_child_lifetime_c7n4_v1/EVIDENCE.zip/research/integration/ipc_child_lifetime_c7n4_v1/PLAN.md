# IPC child lifetime and exclusive-resource composition — c7n4

## Scope and chronology

Intake main: `4c701cc51b06296268ad8d9ae3eff1dd6f2d379d`.
Related #3987 / #4372 / #2789. This changes the prior r5k1 restriction that
broker termination occurs only before child start or after child return.
The previous complete study is not rerun, overwritten, or pooled. Its archive
identity and a new read-only verification receipt are retained separately.
This is prospective LOCAL source/gate registration, not GitHub registration.
The current connector exposes no write operations. Another worker owns #4372's
retrospective publication; do not modify or close that Issue from this study.

One question: is request-level deduplication sufficient to preserve exclusive
resource use when a broker dies while its already-started child survives?
The decision concerns whether a distinct queued request may safely start, not
whether an old request should be replayed. No generic queue is added.

## H — hypothesis

A broker-only lifetime is shorter than a surviving child's lifetime. Persistent
request identity blocks duplicate IDs but not two distinct requests using one
exclusive slot. A parent-held flock alone disappears when that parent exits.
Passing the same locked open-file description to the child can retain exclusion
until that child exits, provided it retains the descriptor and never unlocks it.
A child which deliberately closes that descriptor breaks this assumption; that
negative result must be retained, not omitted from candidate evaluation.

## T — fixed finite engineering study

Environment: supplied Linux x86_64 / CPython 3.13.5 container; standard library,
fcntl.flock and local retained files, not NFS/SMB. No Docker/OrbStack image
attestation. No installations, provider/model, GUI/input, network experiment,
credentials, user files, shared production runtime or GitHub Actions runs.

Three modes: exact prior REQUEST_ONLY broker; resource reservation held by
PARENT_ONLY; reservation explicitly passed via subprocess.run(pass_fds=...)
for INHERITED. claim.py, contract.py, probe.py and collect_cli.py are unchanged
copies. Baseline source is byte-identical to the prior durable_claim.py.
resource_broker.py differs only in the pre-claim slot reservation, deferred
busy handling, pass_fds argument and closing the parent's reference after
subprocess completion. All other subprocess arguments/handling are unchanged,
verified by AST comparison. The original main broker is preserved byte-exact.

Four schedules, two balanced-order repetitions per mode:24 fresh private cases.
Each case publishes exactly two distinct requests once, old then new.

* STABLE: old child finishes and settles before new publication, one broker.
* CRASH_SAME: old child records entry while blocked on its FIFO; kill only its
  broker with SIGTERM; start a replacement; publish a distinct same-slot request.
* CRASH_OTHER: same old survival, but the new request uses a different slot.
* CRASH_DROP: as same-slot crash, except the old child closes its own inherited
  lock FD before recording entry. This is a controlled child-contract violation,
  not a malicious executable or an attack.

Children only write private started/effect/finished files and synthetic event
stdout. FIFO `R` barriers control completion. The supervisor independently
records /proc process identity/state/parent/FDs and performs one nonblocking
lock probe after old-broker exit, before replacement. The diagnostic lock probe
closes its FD immediately; it grants no work and is excluded from policy cost.
A local PR_SET_CHILD_SUBREAPER supervisor adopts the orphan and obtains its
actual waitpid status, rather than guessing exit from a file or PID absence.
No broker receives the oracle's snapshots. All actors are owned and reaped.

Four immutable six-case batches, exact SCHEDULE.json, each invoked once.
Per actor evidence waits3s; fixture release wait8s; subprocess timeout10s;
case supervision12s; whole batch supervisor35s. These are infrastructure limits,
not scientific timing thresholds. Stop on any incomplete case/batch; do not
resume/retry/replace it. Construction IDs/source snapshots are excluded.
No p-values, natural-failure probabilities or throughput benchmark is intended.

Exact commands from this study directory:
```
python -S -B launch_batch.py --out formal --batch 0
python -S -B launch_batch.py --out formal --batch 1
python -S -B launch_batch.py --out formal --batch 2
python -S -B launch_batch.py --out formal --batch 3
python -S -B audit.py formal
python -S -B controls.py formal/batch-1/c7n4-1-0-inherited
python -S -B test_gate.py
```
The first four commands are consumed once and must not be invoked during
artifact review. Later audit/test commands do not start scientific brokers.

## D — frozen decision

Require all24 cases,48 distinct requests,48 child starts (no duplicate old start),
42 intentional service SIGTERM exits,24 actual case exits and4 actual batch
invocation exits. Every new request eventually returns RESULT_AVAILABLE without
republication. In the18 crash cases the old child still completes a private
fixture effect, but its original broker cannot publish completion: old result
remains PENDING_COMPLETION, not inferred success. Six stable old results settle.

Expected simultaneous same-slot activity over8 cases per mode:
REQUEST_ONLY4, PARENT_ONLY4, INHERITED2. The INHERITED two overlaps are precisely
the CRASH_DROP controls; its CRASH_SAME two cells wait and then run the same
queued new request after old child exit. Every mode permits the two CRASH_OTHER
new requests while the old child remains alive on the different slot.

An independent kernel lock probe is blocked after old-broker exit only when
INHERITED retained the FD. The dropped-FD and parent-only probes can acquire.
Old claims remain byte-identical and keep the old epoch. No orphan PID is
silently inferred reaped; its actual waitpid status is required. All input and
retry authority flags remain false; service/task success null.

PASS_LOCAL_CHILD_LIFETIME_BOUNDARY requires all expected source/byte/process,
identity, overlap, ordering, collection and cleanup results plus raw-only audit
and12 effective semantic corruption controls without no-ops/parser crashes.
Unexpected complete contrary observations are FAIL/HOLD; missing source,
exit/denominator or audit integrity is STOP/HOLD. This PASS supports a bounded
lifetime/contract boundary, NOT general candidate safety. Production adoption
stays HOLD_CHILD_DESCRIPTOR_CONTRACT_UNVALIDATED even when all gates pass.

## Conditional argument, not a new OS theorem

Assume one retained lock inode per slot, every contender acquires an exclusive
lock via its own open before work, the current child retains the shared locked
open-file description throughout its work, and no participant unlocks it.
First, closing the parent's reference leaves the child's reference open.
Second, under Linux flock semantics that surviving description retains its
exclusive lock. Third, a new independent open cannot acquire an incompatible
exclusive lock. Fourth, the broker's gate cannot spawn the new child without
that acquisition. Therefore same-slot work cannot overlap while those
assumptions hold. Normal child exit closes its final reference and permits
later acquisition. This does not identify the old effect outcome.

If the parent alone owns the reference, its termination closes the last
reference even while the child works, so the second step fails. If the child
closes the inherited reference or explicitly unlocks it, the same premise
fails. Distinct slots use different inodes and are not mutually exclusive.
These facts are documented API properties; the empirical residual is their
composition with the actual prior claim/broker/settlement path and real exec.

## Variable / field table and units

| Symbol/field | 日本語の意味 | SI単位 | 定義 | 範囲・前提 | 型 |
|---|---|---|---|---|---|
| request_id | 一度だけ発行する要求の識別子 | 1（識別子） | case IDとold/newから固定生成 | 32桁hex、要求間で非重複 | 文字列 |
| resource | 排他対象の試験用資源 | 1（識別子） | slot-aまたはslot-b | 協調的な同一inodeへの対応 | 列挙文字列 |
| fd | 継承対象のファイル記述子 | 1 | openが返す番号 | 同一open-file descriptionを参照 | 非負整数スカラー |
| pid | 観測したプロセス識別子 | 1 | Popenまたは/procから取得 | start_ticksと組で照合 | 正整数スカラー |
| entered_ns | 子が試験作業を開始した単調時計時刻 | s（保存値ns） | monotonic_ns取得値 | 同一カーネル時計 | 整数スカラー |
| finished_ns | 子の終了直前の記録時刻 | s（保存値ns） | 待機終了後の記録 | 実process exitの代用ではない | 整数スカラー |
| overlap | 同資源の両子が観測時点で生存・作業中 | 1 | 生存snapshotと資源一致を照合 | zombieは生存扱いしない | 真偽値 |
| returncode | 実際の待機で得た終了状態 | 1 | Popen.waitまたはwaitpid | boolをintとして受理しない | 整数スカラー |

Unit check: time ordering compares only same-domain ns integers. Seconds in
select/timeout are infrastructure budgets, not mixed with raw ns arithmetic.
Counters and identity comparisons are dimensionless. CPU clock/frequency is
uncontrolled, and no calibrated combined uncertainty or coverage factor is
invented for these categorical observations.

## C / U and roadmap

Cooperative child FD retention is a new interface requirement, not a property
established for real Codex/provider executables. Child self-close is deliberately
measured; arbitrary child code could also unlock the OFD. Further descendants,
DB rollback, inode replacement, NFS/SMB, multiple issuers, authentication, remote
effects and physical input safety are not covered. An advisory resource lock
is not a sandbox. Same-author separately implemented auditor is not independent
human review. FIFO waiting/sampling perturbs scheduling; no speed/token/task
benefit or natural race-rate claim follows.

Roadmap: exact source/old-raw verification -> excluded construction -> LOCAL
source/gate freeze -> four first-outcome batches -> raw audit/12 controls ->
complete additive evidence and reviewable patch -> permitted GitHub publication
and applicable review/CI -> qualified main readback. Do not delete any foreign
branch; no remote branch has been created. This finishes only a bounded
engineering question, never #2789 or the global ROADMAP.

Primary references (accessed2026-09-26): Linux flock(2) manual, Python3.13
subprocess pass_fds documentation, Linux PR_SET_CHILD_SUBREAPER manual.
https://man7.org/linux/man-pages/man2/flock.2.html
https://docs.python.org/3.13/library/subprocess.html
https://man7.org/linux/man-pages/man2/PR_SET_CHILD_SUBREAPER.2const.html

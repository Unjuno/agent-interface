# DRAFT — not submitted

Title:Successor #3987/#4372: distinguish request deduplication from surviving-child resource ownership

This is a genuinely different live-child lifetime condition after conversation-local
r5k1. Do not mutate #4372's separately owned publication or rerun prior evidence.
Retrospective upload of the locally pre-frozen24-case c7n4 study is proposed;
never call it public preregistration. Full H/T/D/C/U and scope are in PLAN.md.

The exact prior claim path prevents duplicate old-request start across broker
replacement, yet different-ID work can overlap on a shared exclusive resource
while the old child survives. Parent-only flock does not cover that interval.
A shared locked FD can cover it only if the child retains it; deliberate child
close exposes the limit. The integration decision is to require an explicit
resource-owner lifetime contract, not to infer exclusivity from unique request
IDs or broker death. All old18 crash outcomes remain PENDING despite private
fixture effects. No model, GUI, input authority or production promotion.

Result:24 cases,4 batches,48 single child starts,42 broker SIGTERM exits retained,
all24 new results available, resource overlaps REQUEST_ONLY4/PARENT_ONLY4/
INHERITED2. The inherited2 are negative FD-close controls. Raw-only audit5471
checks/no errors,12 effective controls,8 units,20 pins. Same-author audit is not
external review. Source/raw/archive verification must precede a reviewed PR.

Local tool-write limitation is this study's publication status, not a new
scientific research question or fleet-wide failure. Preserve every record;
complete source/evidence must be available before a qualified main merge.

# Intake and collision review

Read through GitHub MCP at main4c701cc51b06296268ad8d9ae3eff1dd6f2d379d:
README, CURRENT_GOAL active governing section(lines1-81), complete ROADMAP,
recent open Issues(4), closed broker lineage(3), recent open PRs(2), first100
branch names, targeted broker/survivor/lock Issue searches, all-state
broker+child+lock PR search, and child-lifetime branch search. Exact main broker
readback matched f307daafdfd36d1ab4faf39bb36c36350e6e67e4. Main was rechecked
before freeze and at completion with the same ref. Bounded non-atomic search;
unpushed work remains unknown, and only100 branches were inventoried generally.

#4372 is owned by another retrospective publisher of the prior settlement study.
No mutation to that Issue/branch/path, #3987/#4081, #3924/#3926, #4349, or any
foreign allocation occurred. Exact child-lifetime branch search returned empty.
The distinct hypothesis is live child ownership after broker replacement, not
request replay itself, producer publication repair, a supervisor timeout retry,
or general recipient epoch fencing. This publication is local-only and has no
public reservation; a future publisher must recheck ownership.

Prior ZIP ae80575a64ab7f42730291b307b81821d6c04b709b4daba4ab1d87380e978f69,
1193579bytes,727 files. Unchanged verify.py returned0, all727 files and17 pins,
original20-case audit and12-control output byte-identical,13 pure tests pass.
No prior broker/child/formal allocation was rerun. This new package includes
exact reused source and read-only verification outputs, NOT that entire old ZIP.
The original ZIP remains a separate conversation attachment.

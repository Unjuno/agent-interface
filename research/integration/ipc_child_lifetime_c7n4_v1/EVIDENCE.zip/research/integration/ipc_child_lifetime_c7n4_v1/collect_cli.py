"""Read a previously issued request; never creates or republishes requests."""
import argparse
import json
from pathlib import Path
from contract import collect
p=argparse.ArgumentParser()
p.add_argument('--ipc',type=Path,required=True)
p.add_argument('--request',required=True)
p.add_argument('--sha',required=True)
p.add_argument('--epoch',required=True)
a=p.parse_args()
print(json.dumps(collect(a.ipc,a.request,a.sha,a.epoch),sort_keys=True))

#!/opt/pyvenv/bin/python -S
"""Inert child with explicit FIFO barriers and private-file effects only.

It never executes prompt text. Synthetic event output is not a model result.
The negative control closes only this fixture's inherited *.lock descriptor.
"""
import json
import os
from pathlib import Path
import select
import sys
import time


def save(path, value):
    data=(json.dumps(value, sort_keys=True, separators=(',', ':'))+'\n').encode()
    tmp=path.with_suffix(path.suffix+'.tmp')
    with tmp.open('xb') as f:
        f.write(data); f.flush(); os.fsync(f.fileno())
    os.replace(tmp,path)


def lock_fds():
    rows=[]
    for n in os.listdir('/proc/self/fd'):
        try:
            fd=int(n); target=os.readlink('/proc/self/fd/'+n)
            if not target.endswith('.lock'):continue
            st=os.fstat(fd)
            rows.append({'fd':fd,'target':target,'device':st.st_dev,'inode':st.st_ino})
        except (OSError,ValueError):continue
    return sorted(rows,key=lambda r:r['fd'])


def main():
    raw=sys.stdin.read(); item=json.loads(raw)
    if set(item)!={'id','resource','drop_lock'}:raise ValueError('fixture prompt')
    if item['resource'] not in ('slot-a','slot-b') or type(item['drop_lock']) is not bool:
        raise ValueError('fixture type')
    root=Path(os.environ['STUDY_DIR']);rid=item['id']
    before=lock_fds()
    if item['drop_lock']:
        for r in before:os.close(r['fd'])
    after=lock_fds()
    control=os.open(root/(rid+'.fifo'),os.O_RDONLY | os.O_NONBLOCK)
    save(root/(rid+'.started.json'),{'request_id':rid,'pid':os.getpid(),
         'ppid':os.getppid(),'resource':item['resource'],'entered_ns':time.monotonic_ns(),
         'lock_fds_before':before,'lock_fds_after':after,'drop_lock':item['drop_lock'],
         'stdin':raw,'argv':sys.argv})
    ready,_,_=select.select([control],[],[],8.0)
    if not ready:raise TimeoutError('owned fixture release barrier')
    command=os.read(control,1);os.close(control)
    if command!=b'R':raise ValueError('fixture release command')
    save(root/(rid+'.effect.json'),{'request_id':rid,'resource':item['resource'],
         'pid':os.getpid(),'kind':'private_fixture_effect','committed_ns':time.monotonic_ns()})
    rows=[{'type':'thread.started','thread_id':'fixture-'+rid},
          {'type':'item.completed','item':{'type':'agent_message','text':'{"fixture":"done"}'}},
          {'type':'turn.completed','usage':{'input_tokens':7,'cached_input_tokens':0,'output_tokens':2}}]
    body=('\n'.join(json.dumps(x,sort_keys=True) for x in rows)+'\n').encode()
    delivered=True
    try:
        pos=0
        while pos<len(body):pos+=os.write(1,body[pos:])
    except BrokenPipeError:
        delivered=False
    save(root/(rid+'.finished.json'),{'request_id':rid,'pid':os.getpid(),
         'ppid':os.getppid(),'finished_ns':time.monotonic_ns(),
         'stdout_delivered':delivered,'lock_fds_final':lock_fds()})
    return 0

if __name__=='__main__':raise SystemExit(main())

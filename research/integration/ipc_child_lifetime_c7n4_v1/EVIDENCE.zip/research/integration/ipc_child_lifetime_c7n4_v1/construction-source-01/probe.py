"""Identical, explicitly injected checkpoints for both measured services.

These observe child-start/return and select a process-interruption boundary;
they do not change subprocess arguments, return values or publication bytes.
"""
import json
import os
import time


def emit(kind, request_id=None, **extra):
    print(json.dumps({'kind':kind, 'request_id':request_id, 'pid':os.getpid(),
                      'epoch':os.environ['HOST_MODEL_BROKER_EPOCH'],
                      'monotonic_ns':time.monotonic_ns(), **extra},
                     sort_keys=True, separators=(',', ':')), flush=True)


def checkpoint(phase, request_id):
    if os.environ.get('STUDY_CUT') == phase and os.environ.get('STUDY_CUT_ID') == request_id:
        emit('CHECKPOINT', request_id, phase=phase)
        while True:
            time.sleep(.01)

"""Research-only cooperative resource reservation, separate from request identity.

The two allowed slots are fixture resources, not OS/input authority. Never
unlink lock files; all contenders must open the same retained inode. No TTL,
PID-death reclamation, explicit LOCK_UN, or old-request resubmission.
"""
from pathlib import Path
import fcntl
import os
from claim import prepare, out
from probe import emit


def reserve(ipc: Path, request_id: str, raw: bytes, epoch: str, resource: str):
    if type(resource) is not str or resource not in ('slot-a', 'slot-b'):
        return out('HOLD_RESOURCE_SHAPE'), None
    # Old claims preserve their original decision and do not seize another slot.
    if (ipc / (request_id + '.claim.json')).exists():
        return prepare(ipc, request_id, raw, epoch), None
    lock_dir = ipc / 'locks'
    lock_dir.mkdir(exist_ok=True)
    fd = os.open(lock_dir / (resource + '.lock'), os.O_CREAT | os.O_RDWR, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        os.close(fd)
        emit('RESOURCE_BUSY', request_id, resource=resource)
        return out('PENDING_RESOURCE', defer=True), None
    except BaseException:
        os.close(fd)
        raise
    try:
        decision = prepare(ipc, request_id, raw, epoch)
        if decision['may_start'] is not True:
            os.close(fd)
            return decision, None
        st = os.fstat(fd)
        emit('RESOURCE_ACQUIRED', request_id, resource=resource, fd=fd,
             device=st.st_dev, inode=st.st_ino, mode=os.environ['LOCK_MODE'])
        return decision, fd
    except BaseException:
        os.close(fd)
        raise


def close_reservation(fd):
    if fd is not None:
        # Close only this reference. LOCK_UN would also unlock the child's copy.
        os.close(fd)

"""Research-only, per-child settlement. No daemon-exit, task-success or replay authority.

Requires one cooperative publisher, an immutable request per unique ID, a trusted
local IPC directory, stable committed files during collection, and a caller-known
broker epoch. Hashes are integrity bindings, not authentication or a transaction.
"""
from __future__ import annotations
import hashlib
import json
import math
import os
from pathlib import Path
import re
import tempfile
import time

SCHEMA = 'host-model-request-settlement-v1'
MAX_BYTES = 1_048_576
HEX32 = re.compile(r'[a-f0-9]{32}\Z')
HEX64 = re.compile(r'[a-f0-9]{64}\Z')
FIELDS = {'schema','scope','request_id','broker_epoch','broker_pid',
          'request_sha256','response_sha256','broker_receipt_sha256',
          'authority_granted'}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _no_duplicates(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError('duplicate JSON key')
        out[key] = value
    return out


def _constant(value):
    raise ValueError('nonfinite JSON constant')


def decode(data: bytes):
    return json.loads(data.decode('utf-8'), object_pairs_hook=_no_duplicates,
                      parse_constant=_constant)


def encode(value) -> bytes:
    return (json.dumps(value, sort_keys=True, separators=(',', ':'),
                       ensure_ascii=False, allow_nan=False)+'\n').encode('utf-8')


def _bounded_read(path: Path) -> bytes:
    with path.open('rb') as stream:
        data = stream.read(MAX_BYTES + 1)
    if len(data) > MAX_BYTES:
        raise ValueError('artifact too large')
    return data


def atomic_bytes(path: Path, data: bytes) -> None:
    if len(data) > MAX_BYTES:
        raise ValueError('artifact too large')
    fd, name = tempfile.mkstemp(prefix='.'+path.name, suffix='.tmp', dir=path.parent)
    tmp = Path(name)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def publish(ipc: Path, request_id: str, request_bytes: bytes,
            response: str, broker: dict) -> None:
    """Called only AFTER original subprocess.run has returned/raised and reaped.

    The unchanged original broker owns subprocess execution/timeout handling.
    Publication does not assert that its own enclosing service has terminated.
    """
    epoch = os.environ.get('HOST_MODEL_BROKER_EPOCH', '')
    if not HEX32.fullmatch(request_id) or not HEX32.fullmatch(epoch):
        raise ValueError('explicit request ID and broker epoch required')
    response_bytes = response.encode('utf-8')
    broker_bytes = (json.dumps(broker, allow_nan=False)+'\n').encode('utf-8')
    settled = {
        'schema': SCHEMA, 'scope': 'child_invocation', 'request_id': request_id,
        'broker_epoch': epoch, 'broker_pid': os.getpid(),
        'request_sha256': digest(request_bytes),
        'response_sha256': digest(response_bytes),
        'broker_receipt_sha256': digest(broker_bytes),
        'authority_granted': False,
    }
    atomic_bytes(ipc / (request_id+'.response.jsonl'), response_bytes)
    atomic_bytes(ipc / (request_id+'.broker.json'), broker_bytes)
    # Commit indicator is last. Missing indicator never authorizes redispatch.
    atomic_bytes(ipc / (request_id+'.settled.json'), encode(settled))


def _out(status: str, **extra) -> dict:
    return {'status': status, 'scope': 'child_invocation',
            'authority_granted': False, 'retry_allowed': False,
            'task_success': None, 'service_success': None, **extra}


def collect(ipc: Path, request_id: str, expected_request_sha256: str,
            broker_epoch: str) -> dict:
    """Read only. Returned bytes are the very bytes hashed, never reopened."""
    if (not isinstance(request_id, str) or not HEX32.fullmatch(request_id)
        or not isinstance(broker_epoch, str) or not HEX32.fullmatch(broker_epoch)
        or not isinstance(expected_request_sha256, str)
        or not HEX64.fullmatch(expected_request_sha256)):
        return _out('HOLD_CALLER_BINDING')
    try:
        seal_bytes = _bounded_read(ipc / (request_id+'.settled.json'))
    except FileNotFoundError:
        return _out('PENDING_COMPLETION')
    except (OSError, ValueError):
        return _out('HOLD_EVIDENCE')
    try:
        seal = decode(seal_bytes)
        if (type(seal) is not dict or set(seal) != FIELDS
            or seal['schema'] != SCHEMA or seal['scope'] != 'child_invocation'
            or type(seal['broker_pid']) is not int or seal['broker_pid'] <= 0
            or seal['authority_granted'] is not False):
            return _out('HOLD_SETTLEMENT_SCHEMA')
        if seal['request_id'] != request_id or seal['broker_epoch'] != broker_epoch:
            return _out('HOLD_IDENTITY')
        raw_request = _bounded_read(ipc / (request_id+'.request.json'))
        raw_response = _bounded_read(ipc / (request_id+'.response.jsonl'))
        raw_broker = _bounded_read(ipc / (request_id+'.broker.json'))
        if (digest(raw_request) != expected_request_sha256
            or seal['request_sha256'] != expected_request_sha256
            or seal['response_sha256'] != digest(raw_response)
            or seal['broker_receipt_sha256'] != digest(raw_broker)):
            return _out('HOLD_BYTE_BINDING')
        request, broker = decode(raw_request), decode(raw_broker)
        if type(request) is not dict or type(broker) is not dict:
            return _out('HOLD_RECORD_SCHEMA')
        if request.get('request_id') != request_id or broker.get('request_id') != request_id:
            return _out('HOLD_IDENTITY')
        if (request.get('authority_granted') is not False
                or broker.get('authority_granted') is not False
                or broker.get('boundary') != 'host-local-codex-exe'):
            return _out('HOLD_RECORD_SCHEMA')
        if (type(broker.get('started_ns')) is not int
                or type(broker.get('exited_ns')) is not int
                or not 0 <= broker['started_ns'] <= broker['exited_ns']):
            return _out('HOLD_RECORD_SCHEMA')
        code = broker.get('returncode')
        if code is None:
            if broker.get('stop_reason') == 'HOST_BROKER_SUBPROCESS_TIMEOUT':
                return _out('HOLD_CHILD_TIMEOUT')
            if broker.get('stop_reason') == 'HOST_BROKER_EXECUTABLE_UNAVAILABLE':
                return _out('HOLD_EXECUTABLE_UNAVAILABLE')
            return _out('HOLD_CHILD_UNKNOWN')
        if type(code) is not int:
            return _out('HOLD_EXIT_TYPE')
        if code != 0:
            return _out('REFUSE_CHILD_EXIT', child_returncode=code)
        if broker.get('error_class') is not None or broker.get('stop_reason') is not None:
            return _out('HOLD_CHILD_CONTRADICTION')
        # These are bounded transport-envelope checks, not model/task quality.
        if not raw_response.endswith(b'\n'):
            return _out('HOLD_RESPONSE_FRAMING')
        events = [decode(line) for line in raw_response.splitlines() if line.strip()]
        if any(type(e) is not dict for e in events):
            return _out('HOLD_RESPONSE_ENVELOPE')
        if any(e.get('type') in ('error', 'turn.failed') for e in events):
            return _out('HOLD_RESPONSE_ENVELOPE')
        turns = [e for e in events if e.get('type') == 'turn.completed']
        msgs = [e for e in events if e.get('type') == 'item.completed']
        threads = [e for e in events if e.get('type') == 'thread.started']
        if len(turns) != 1 or len(msgs) != 1 or len(threads) != 1:
            return _out('HOLD_RESPONSE_ENVELOPE')
        msg = msgs[0].get('item')
        if (type(msg) is not dict or msg.get('type') != 'agent_message'
                or type(msg.get('text')) is not str
                or type(threads[0].get('thread_id')) is not str
                or not threads[0]['thread_id']):
            return _out('HOLD_RESPONSE_ENVELOPE')
        usage = turns[0].get('usage')
        if (type(usage) is not dict
                or any(type(usage.get(k)) is not int or usage[k] < 0
                       for k in ('input_tokens','cached_input_tokens','output_tokens'))):
            return _out('HOLD_USAGE_SCHEMA')
        return _out('RESULT_AVAILABLE', response_utf8=raw_response.decode('utf-8'),
                    response_sha256=digest(raw_response),
                    request_id=request_id, broker_epoch=broker_epoch,
                    broker_pid=seal['broker_pid'], child_returncode=0)
    except (OSError, ValueError, TypeError, KeyError):
        return _out('HOLD_EVIDENCE')


def wait_for_result(ipc: Path, request_id: str, request_sha: str,
                    epoch: str, timeout_s: float) -> dict:
    if (isinstance(timeout_s, bool) or not isinstance(timeout_s, (int, float))
            or not math.isfinite(timeout_s) or not 0 < timeout_s <= 120):
        return _out('HOLD_CALLER_BUDGET')
    deadline = time.monotonic() + timeout_s
    while True:
        result = collect(ipc, request_id, request_sha, epoch)
        if result['status'] != 'PENDING_COMPLETION':
            return result
        if time.monotonic() >= deadline:
            return _out('PENDING_COMPLETION', caller_wait_expired=True)
        time.sleep(min(.01, max(0, deadline-time.monotonic())))

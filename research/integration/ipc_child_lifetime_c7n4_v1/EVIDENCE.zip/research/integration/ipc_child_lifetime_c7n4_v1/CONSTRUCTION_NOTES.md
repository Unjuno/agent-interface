# Retained construction chronology

Construction01 ran one INHERITED/CRASH_SAME lifecycle case and returned0;
its first raw audit returned0/232checks. Subsequent source inspection found
normal cleanup sent an additional R byte into each already-unused FIFO without
recording it. These bytes occurred after children had ended, did not rerun work,
but prevented claiming complete control-write accounting. The exact first
source snapshot and raw output are preserved. No formal run had started.

The normal cleanup write was removed before construction02. Cleanup writes on
STOP are now explicit events. Construction02 ran six distinct excluded cases,
all completed with retained process exits and raw audits. The frozen final
checker was also applied read-only to those six, without new child executions.
Eight engineering units passed. Twelve effective record mutations were rejected
without checker crashes/no-op changes. The control-output baseline check-count
field was corrected before source freeze; first outputs remain retained.

Total newly executed construction:7 cases,14 inert child invocations. They are
not formal rows. No failed formal case, replacement, selected timing outcome,
or construction pooling exists in the24-case allocation.

"""Read-only manifest/source/raw verification; no scientific processes start."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parent

def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    manifest=json.loads((ROOT/'MANIFEST.json').read_bytes())
    paths={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()}
    if paths!=set(manifest)|{'MANIFEST.json'}:raise ValueError('manifest coverage')
    for n,record in manifest.items():
        b=(ROOT/n).read_bytes()
        if type(record['bytes']) is not int or len(b)!=record['bytes'] or sha(b)!=record['sha256']:
            raise ValueError('retained byte mismatch: '+n)
    freeze=json.loads((ROOT/'FREEZE.json').read_bytes())
    for n,h in freeze['files'].items():
        if sha((ROOT/n).read_bytes())!=h:raise ValueError('freeze changed: '+n)
    results=[]
    for args,expected in [(['audit.py',str(ROOT/'formal')],'AUDIT.json'),
                          (['controls.py',str(ROOT/'formal/batch-1/c7n4-1-0-inherited')],'CONTROLS.json')]:
        c=subprocess.run([sys.executable,'-S','-B',str(ROOT/args[0]),*args[1:]],capture_output=True,timeout=15,cwd=ROOT)
        if c.returncode or c.stderr or c.stdout!=(ROOT/expected).read_bytes():raise ValueError('audit mismatch: '+args[0])
        results.append({'script':args[0],'returncode':c.returncode,'byte_identical':True,'sha256':sha(c.stdout)})
    c=subprocess.run([sys.executable,'-S','-B',str(ROOT/'test_gate.py')],capture_output=True,timeout=10,cwd=ROOT)
    if c.returncode or b'Ran 8 tests' not in c.stderr:raise ValueError('unit failure')
    print(json.dumps({'status':'PASS_READ_ONLY_DELIVERY','files':len(paths),'source_pins':len(freeze['files']),
                      'audits':results,'unit_tests':8,'scientific_broker_starts':0,
                      'production_adoption':'HOLD_CHILD_DESCRIPTOR_CONTRACT_UNVALIDATED'},sort_keys=True,indent=2))
if __name__=='__main__':main()

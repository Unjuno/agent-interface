"""Research-only persistent admission; never expires or reassigns old claims.

Assumptions: trusted retained local directory, immutable unique request IDs,
all invocations use this gate, one cooperative broker at a time in this study.
A claim is NOT evidence that a child started or an application effect occurred.
"""
from __future__ import annotations
import os
import time
from pathlib import Path
from contract import HEX32, HEX64, MAX_BYTES, decode, encode, digest, collect

FIELDS = {'schema', 'request_id', 'request_sha256', 'epoch', 'publisher_pid',
          'created_ns', 'authority_granted'}


def out(status: str, may_start: bool = False, **extra) -> dict:
    return {'status': status, 'may_start': may_start, 'authority_granted': False,
            'retry_allowed': False, 'task_success': None, **extra}


def prepare(ipc: Path, request_id: str, raw: bytes, epoch: str) -> dict:
    if (type(request_id) is not str or not HEX32.fullmatch(request_id)
            or type(epoch) is not str or not HEX32.fullmatch(epoch)
            or type(raw) is not bytes or len(raw) > MAX_BYTES):
        return out('HOLD_REQUEST_SHAPE')
    try:
        request = decode(raw)
        if (type(request) is not dict or request.get('request_id') != request_id
                or request.get('authority_granted') is not False):
            return out('HOLD_REQUEST_SHAPE')
    except (ValueError, UnicodeError, TypeError):
        return out('HOLD_REQUEST_SHAPE')
    path = ipc / (request_id + '.claim.json')
    if not path.exists() and any((ipc / (request_id + suffix)).exists()
                                     for suffix in ['.response.jsonl','.broker.json','.settled.json']):
        return out('HOLD_UNCLAIMED_EVIDENCE')
    record = {'schema':'retained-invocation-claim-r5k1', 'request_id':request_id,
              'request_sha256':digest(raw), 'epoch':epoch,
              'publisher_pid':os.getpid(), 'created_ns':time.monotonic_ns(),
              'authority_granted':False}
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        try:
            with path.open('rb') as stream:
                existing_bytes = stream.read(MAX_BYTES+1)
            if len(existing_bytes) > MAX_BYTES:
                return out('HOLD_CLAIM_EVIDENCE')
            old = decode(existing_bytes)
            if (type(old) is not dict or set(old) != FIELDS
                    or old['schema'] != record['schema']
                    or old['request_id'] != request_id
                    or type(old['publisher_pid']) is not int or old['publisher_pid'] <= 0
                    or type(old['created_ns']) is not int or old['created_ns'] < 0
                    or type(old['epoch']) is not str or not HEX32.fullmatch(old['epoch'])
                    or type(old['request_sha256']) is not str or not HEX64.fullmatch(old['request_sha256'])
                    or old['authority_granted'] is not False):
                return out('HOLD_CLAIM_EVIDENCE')
            if old['request_sha256'] != record['request_sha256']:
                return out('HOLD_REQUEST_CONFLICT')
            result = collect(ipc, request_id, digest(raw), old['epoch'])
            # Preserve original publisher epoch: restart does not mint a new result.
            return out('RETAIN_EXISTING' if result['status'] != 'PENDING_COMPLETION'
                       else 'HOLD_PRIOR_OUTCOME_UNKNOWN', original_epoch=old['epoch'],
                       result=result)
        except (OSError, ValueError, TypeError, KeyError):
            return out('HOLD_CLAIM_EVIDENCE')
    except OSError:
        return out('HOLD_CLAIM_STORE')
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(encode(record))
            stream.flush()
            os.fsync(stream.fileno())
    except OSError:
        # Do not delete/retry an incomplete claim: dispatch provenance is unknown.
        return out('HOLD_CLAIM_STORE')
    return out('START_CLAIMED', True, original_epoch=epoch)

# #2781 narrowed rung: natural save-tail overlap under dynamic focus

## H
For a real application save, the X11 focus/key resource can become releasable after the Ctrl+S chord is independently neutral even while the application file effect is pending. `RESOLVED_BOUND` revalidates focus before input and releases focus after verified key release, permitting an independent xterm effect during the natural save tail without changing the save effect. `STATIC_SUPERSET` waits for the save effect before B. `SURFACE_ID_ONLY` deliberately omits focus currentness and should expose wrong-surface Ctrl+S after directed focus drift.

## T
Provided Linux execution container. Fresh TCP-disabled private Xvfb/Openbox per case; native XTEST only inside owned displays. A applications: Inkscape SVG and LibreOffice Writer ODT. B: xterm child journal. No model/provider, host desktop/user files, package installation, or experiment network.

Formal denominator 16 fresh sessions, case order fixed in SCHEDULE.json:
- STABLE: 2 apps x SHORT/LONG x STATIC_SUPERSET/RESOLVED_BOUND = 8.
- FOCUS_STALE: 2 apps x LONG x STATIC_SUPERSET/RESOLVED_BOUND/SURFACE_ID_ONLY = 6.
- NO_INPUT LONG controls: 2.
Four immutable four-case batches: 0-3, 4-7, 8-11, 12-15. Each batch invoked once. No case retry/replacement/exclusion. File observer polls actual task-file SHA; this is no synthetic tail.

## D
`PASS_DYNAMIC_FOCUS_SAVE_TAIL_RUNG1_SCOPED` only if all 16 rows, process exits, source identities and raw evidence reconcile; all STATIC/RESOLVED task cases have exact A saved effect and exactly one B marker; endpoints and the post-save chord are X-server key/button neutral; both apps' LONG RESOLVED cases show B marker before A file effect; stale STATIC/RESOLVED rows revalidate false focus and successfully repair before save; stale SURFACE_ID_ONLY rows leave A file unchanged and expose at least one non-marker xterm byte plus the marker; NO_INPUT changes neither A file nor B journal. Independent raw audit errors empty; >=8 effective copied-evidence corruptions must reject. Missing/provenance/process evidence => STOP/HOLD; complete semantic contradiction => FAIL. Construction is excluded.

## C
This first rung isolates save-tail overlap. Inkscape/LibreOffice file size, app implementation, X scheduling, focus transfer and polling overhead are part of the fixture. File-hash observation is a bounded interval endpoint, not exact kernel commit time. Surface-only is an authored unsafe comparator, not alleged production behavior.

## U
No selection/clipboard/modal/window-replacement/restart/stale-effect-receipt matrix; therefore it cannot close full #2781. No model, task-token benefit, natural failure probability, calibrated combined uncertainty, cross-platform or production scheduler claim. XQueryKeymap is X-server logical state, not physical HID.

## Construction chronology (excluded)
- construction-01: missing default ~/.Xauthority; stopped before task input.
- construction-02: private empty Xauthority allowed window discovery.
- construction-03: harness failed to apply DISPLAY/XAUTHORITY to its own Xlib connection; stopped before task input.
- tail probes: established natural save tails and independent xterm marker on both apps; an uppercase marker was rejected as ambiguous and changed to literal lowercase `b` before formal source freeze.
- cases-02/cases-03: exposed an Xlib focus-parent integer representation bug in the harness; no formal rows.
- case-surface-debug-04 retained traceback; `belongs()` corrected to normalize integer/window parent IDs.
- construction-05: four excluded discriminator rows (Inkscape/LibreOffice LONG RESOLVED and stale SURFACE_ID_ONLY) passed the source auditor with B-before-A in both candidate cases and wrong-surface Ctrl+S evidence in both unsafe controls.

Formal invocations at this freeze: 0/4 batches, 0/16 cases.

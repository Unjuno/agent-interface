import unittest
import study
class T(unittest.TestCase):
 def test_schedule(self): self.assertEqual(len(study.schedule()),16); self.assertEqual(len({x['index'] for x in study.schedule()}),16)
 def test_sizes(self): self.assertEqual(study.APPS['inkscape']['long'],1000);self.assertEqual(study.APPS['libreoffice']['long'],3000)
 def test_policies(self): self.assertEqual(sum(x['policy']=='NO_INPUT' for x in study.schedule()),2)
 def test_stale_negative(self): self.assertEqual(sum(x['policy']=='SURFACE_ID_ONLY' for x in study.schedule()),2)
if __name__=='__main__':unittest.main()

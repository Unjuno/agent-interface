#!/usr/bin/env python3
import argparse,hashlib,json,os,pathlib,random,signal,subprocess,sys,threading,time,traceback,zipfile
from Xlib import display,X,XK
from Xlib.ext import xtest

ROOT=pathlib.Path(__file__).resolve().parents[1]
SCORER=pathlib.Path(__file__).resolve().with_name('score_file.py')
APPS={'inkscape':{'short':1,'long':1000},'libreoffice':{'short':1,'long':3000}}

def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def jdump(p,o): pathlib.Path(p).write_text(json.dumps(o,sort_keys=True,indent=2)+'\n')
def make_svg(p,n):
 with open(p,'w') as f:
  f.write('<svg xmlns="http://www.w3.org/2000/svg" width="800" height="600">\n')
  for i in range(n):
   x=50+(i*17)%650; y=50+(i*29)%450; c=(i*2654435761)&0xffffff
   f.write(f'<rect id="r{i}" x="{x}" y="{y}" width="10" height="10" fill="#{c:06x}"/>\n')
  f.write('</svg>\n')
def make_odt(p,n):
 rng=random.Random(2781+n)
 pre='<?xml version="1.0" encoding="UTF-8"?><office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" office:version="1.2"><office:body><office:text>'
 pars=[]
 for i in range(n):
  s=''.join(rng.choice('abcdefghijklmnopqrstuvwxyz0123456789') for _ in range(80))
  pars.append(f'<text:p>{i:06d}-{s}</text:p>')
 content=pre+''.join(pars)+'</office:text></office:body></office:document-content>'
 manifest='<?xml version="1.0" encoding="UTF-8"?><manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.2"><manifest:file-entry manifest:full-path="/" manifest:media-type="application/vnd.oasis.opendocument.text"/><manifest:file-entry manifest:full-path="content.xml" manifest:media-type="text/xml"/></manifest:manifest>'
 with zipfile.ZipFile(p,'w') as z:
  z.writestr('mimetype','application/vnd.oasis.opendocument.text',compress_type=zipfile.ZIP_STORED)
  z.writestr('content.xml',content,compress_type=zipfile.ZIP_DEFLATED,compresslevel=1)
  z.writestr('META-INF/manifest.xml',manifest,compress_type=zipfile.ZIP_DEFLATED,compresslevel=1)
def prop(D,w,n):
 try:
  p=w.get_full_property(D.intern_atom(n),X.AnyPropertyType); return p.value if p else None
 except Exception:return None
def sprop(v):
 if isinstance(v,(bytes,bytearray)): return v.decode('latin1','ignore').replace('\x00','|')
 return str(v)
def find_client(D,needle,deadline=8):
 end=time.time()+deadline
 while time.time()<end:
  def rec(w):
   for c in w.query_tree().children:
    nm=prop(D,c,'WM_NAME'); cl=prop(D,c,'WM_CLASS')
    if nm is not None and needle.lower() in (sprop(nm)+' '+sprop(cl)).lower(): return c
    try:
     r=rec(c)
     if r:return r
    except Exception: pass
   return None
  r=rec(D.screen().root)
  if r:return r
  time.sleep(.05)
 raise RuntimeError('WINDOW_NOT_FOUND:'+needle)
def belongs(w,anc):
 for _ in range(32):
  wid=getattr(w,'id',w if isinstance(w,int) else None)
  if wid==anc.id:return True
  try:p=w.query_tree().parent
  except Exception:return False
  pid=getattr(p,'id',p if isinstance(p,int) else None)
  if p is None or pid==wid:return False
  w=p
 return False
def current_focus(D): return D.get_input_focus().focus
def focus_to(D,w):
 w.set_input_focus(X.RevertToParent,X.CurrentTime);D.sync()
 end=time.time()+.5
 while time.time()<end:
  f=current_focus(D)
  if belongs(f,w): return {'focus_id':f.id,'client_id':w.id,'ok':True}
  time.sleep(.01)
 f=current_focus(D);return {'focus_id':getattr(f,'id',None),'client_id':w.id,'ok':False}
def key(D,name,down):
 kc=D.keysym_to_keycode(XK.string_to_keysym(name))
 if not kc: raise RuntimeError('NO_KEYCODE:'+name)
 xtest.fake_input(D,X.KeyPress if down else X.KeyRelease,kc);D.sync();return kc
def tap(D,name):
 t0=time.monotonic_ns();kc=key(D,name,True);t1=time.monotonic_ns();key(D,name,False);t2=time.monotonic_ns();return {'key':name,'keycode':kc,'press_ns':t1,'release_ns':t2,'start_ns':t0}
def chord(D,mod,name):
 t0=time.monotonic_ns();mk=key(D,mod,True);kp=key(D,name,True);t1=time.monotonic_ns();key(D,name,False);key(D,mod,False);t2=time.monotonic_ns();return {'mod':mod,'key':name,'mod_code':mk,'key_code':kp,'press_ns':t1,'release_ns':t2,'start_ns':t0}
def keymap_zero(D):
 raw=bytes(D.query_keymap()); return {'zero':all(x==0 for x in raw),'hex':raw.hex()}
def buttons_zero(D):
 q=D.screen().root.query_pointer(); masks=X.Button1Mask|X.Button2Mask|X.Button3Mask|X.Button4Mask|X.Button5Mask
 return {'zero':(q.mask&masks)==0,'mask':int(q.mask)}
def start_group(cmd,env,out,err): return subprocess.Popen(cmd,env=env,stdout=open(out,'wb'),stderr=open(err,'wb'),start_new_session=True)
def kill_group(p):
 try: os.killpg(p.pid,signal.SIGTERM)
 except ProcessLookupError:return
 except Exception:return
 try:p.wait(2)
 except subprocess.TimeoutExpired:
  try:os.killpg(p.pid,signal.SIGKILL)
  except Exception:pass
  try:p.wait(2)
  except Exception:pass
def tail(p,n=4000):
 try:return pathlib.Path(p).read_text(errors='replace')[-n:]
 except:return ''
def wait_file_change(path,h0,slot,stop):
 polls=0
 while not stop.is_set():
  polls+=1
  try:h=sha(path)
  except Exception as e:
   slot.setdefault('errors',[]).append(type(e).__name__+':'+str(e));time.sleep(.001);continue
  if h!=h0:
   slot.update(observed_ns=time.monotonic_ns(),sha256=h,polls=polls);return
  time.sleep(.001)
 slot['polls']=polls
def score(app,doc):
 cp=subprocess.run([sys.executable,'-B',str(SCORER),app,str(doc)],capture_output=True,text=True,timeout=5)
 return {'exit':cp.returncode,'stderr':cp.stderr,'data':json.loads(cp.stdout) if cp.returncode==0 else None}
def b_script(path):
 path.write_text("""import json,os,sys,termios,time,pathlib\nfd=0;a=termios.tcgetattr(fd);a[0]&=~(termios.IXON|termios.ICRNL);a[3]&=~(termios.ICANON|termios.ECHO);termios.tcsetattr(fd,termios.TCSANOW,a)\np=pathlib.Path(sys.argv[1]); rows=[]\nwhile True:\n c=os.read(0,1)\n if not c: break\n rows.append({'byte':c.hex(),'ns':time.monotonic_ns()});p.write_text(json.dumps(rows,separators=(',',':')))\n if c==b'b': break\n""")
def run_case(case,outdir):
 out=pathlib.Path(outdir);out.mkdir(parents=True,exist_ok=False);(out/'Xauthority').write_bytes(b'');(out/'home').mkdir()
 app=case['app'];size=case['size'];policy=case['policy'];schedule=case['schedule'];idx=case['index'];n=APPS[app][size]
 doc=out/('a.svg' if app=='inkscape' else 'a.odt')
 if app=='inkscape':make_svg(doc,n)
 else:make_odt(doc,n)
 original_sha=sha(doc)
 env=os.environ.copy();env.update(DISPLAY=f":{230+idx}",XAUTHORITY=str(out/'Xauthority'),HOME=str(out/'home'),LANG='C.UTF-8')
 os.environ['DISPLAY']=env['DISPLAY'];os.environ['XAUTHORITY']=env['XAUTHORITY']
 procs=[]; result={'case':case,'original_sha256':original_sha,'events':[],'cleanup':{}}
 try:
  xv=start_group(['Xvfb',env['DISPLAY'],'-screen','0','1280x800x24','-nolisten','tcp'],env,out/'xvfb.out',out/'xvfb.err');procs.append(('xvfb',xv));time.sleep(.2)
  ob=start_group(['openbox'],env,out/'openbox.out',out/'openbox.err');procs.append(('openbox',ob));time.sleep(.3)
  bs=out/'b_child.py';b_script(bs); bj=out/'b_journal.json'
  bx=start_group(['xterm','-geometry','40x8+10+10','-T','BTERM','-e',sys.executable,'-u',str(bs),str(bj)],env,out/'xterm.out',out/'xterm.err');procs.append(('xterm',bx))
  if app=='inkscape': cmd=['inkscape',str(doc)];needle='Inkscape';startup=2.0
  else:
   prof=out/'lo_profile';prof.mkdir();cmd=['libreoffice',f'-env:UserInstallation=file://{prof}','--writer','--nologo','--nofirststartwizard','--nodefault',str(doc)];needle='libreoffice';startup=3.5
  ap=start_group(cmd,env,out/'app.out',out/'app.err');procs.append((app,ap));time.sleep(startup)
  D=display.Display(env['DISPLAY']);aw=find_client(D,needle);bw=find_client(D,'BTERM')
  result['windows']={'a':aw.id,'b':bw.id,'a_name':sprop(prop(D,aw,'WM_NAME')),'a_class':sprop(prop(D,aw,'WM_CLASS'))}
  result['initial_focus']=focus_to(D,aw);assert result['initial_focus']['ok']
  # Establish a real unsaved edit; not part of the measured phase.
  if app=='inkscape': result['setup_input']=[chord(D,'Control_L','a'),tap(D,'Right')]
  else:
   rows=[chord(D,'Control_L','End'),tap(D,'Return')]
   for k in ['z','9','z','9']:rows.append(tap(D,k))
   result['setup_input']=rows
  time.sleep(.2)
  pre_sha=sha(doc);result['pre_save_sha256']=pre_sha;result['unsaved_precondition']=(pre_sha==original_sha)
  fr=current_focus(D); result['focus_receipt']={'ns':time.monotonic_ns(),'focus_id':getattr(fr,'id',fr if isinstance(fr,int) else None),'belongs_a':belongs(fr,aw),'a_client':aw.id}
  if schedule=='FOCUS_STALE': result['fixture_focus_change']=focus_to(D,bw);assert result['fixture_focus_change']['ok']
  if policy=='NO_INPUT':
   time.sleep(.15);result['decision']='NO_INPUT';result['a_effect']=None;result['b_marker_sent']=False
  else:
   cf=current_focus(D); current_ok=belongs(cf,aw); result['preinput_focus']={'id':getattr(cf,'id',cf if isinstance(cf,int) else None),'belongs_a':current_ok}
   if policy in ('STATIC_SUPERSET','RESOLVED_BOUND') and not current_ok:
    result['focus_repair']=focus_to(D,aw);current_ok=result['focus_repair']['ok']
   else:result['focus_repair']=None
   if policy in ('STATIC_SUPERSET','RESOLVED_BOUND') and not current_ok: raise RuntimeError('FOCUS_REPAIR_FAILED')
   # Start independent file observer immediately before save request.
   slot={};stop=threading.Event();th=threading.Thread(target=wait_file_change,args=(doc,pre_sha,slot,stop),daemon=True);th.start()
   result['save_chord']=chord(D,'Control_L','s');result['release_state']=keymap_zero(D);result['release_buttons']=buttons_zero(D)
   result['save_release_ns']=result['save_chord']['release_ns']
   if policy=='STATIC_SUPERSET':
    deadline=time.time()+3.0
    while time.time()<deadline and 'observed_ns' not in slot:time.sleep(.001)
    result['focus_b_after_a']=focus_to(D,bw);result['b_input']=tap(D,'b');result['b_marker_sent']=True
   elif policy=='RESOLVED_BOUND':
    result['focus_b_after_release']=focus_to(D,bw);result['b_input']=tap(D,'b');result['b_marker_sent']=True
   elif policy=='SURFACE_ID_ONLY':
    # Deliberately never revalidate/refocus before Ctrl+S; focus is already B in stale cases.
    result['focus_b_after_release']=focus_to(D,bw);result['b_input']=tap(D,'b');result['b_marker_sent']=True
   deadline=time.time()+3.0
   while time.time()<deadline and ('observed_ns' not in slot or not bj.exists()):time.sleep(.001)
   stop.set();th.join(.2);result['a_effect']=slot
  # Collect B journal and independent final file score.
  if bj.exists():
   try: result['b_journal']=json.loads(bj.read_text())
   except Exception as e: result['b_journal_error']=str(e);result['b_journal']=[]
  else: result['b_journal']=[]
  result['score']=score(app,doc)
  result['final_sha256']=sha(doc);result['final_keymap']=keymap_zero(D);result['final_buttons']=buttons_zero(D)
  result['timing']={}
  ae=(result.get('a_effect') or {}).get('observed_ns'); bjrows=result.get('b_journal') or []; be=next((r['ns'] for r in bjrows if r['byte']=='62'),None)
  if 'save_release_ns' in result:
   result['timing']['a_tail_ns']=None if ae is None else ae-result['save_release_ns']
   result['timing']['b_after_release_ns']=None if be is None else be-result['save_release_ns']
   result['timing']['b_before_a']=bool(ae is not None and be is not None and be<ae)
   end=max(x for x in [ae,be,result['save_release_ns']] if x is not None);result['timing']['completion_from_release_ns']=end-result['save_release_ns']
  D.close()
 except Exception as e:
  result['exception']=type(e).__name__+': '+str(e); result['traceback']=traceback.format_exc()
 finally:
  for name,p in reversed(procs):kill_group(p)
  time.sleep(.1)
  for name,p in procs:result['cleanup'][name]={'pid':p.pid,'returncode':p.poll()}
  result['logs']={n:{'stdout_tail':tail(out/(('app.out' if n in ('inkscape','libreoffice') else n+'.out'))),'stderr_tail':tail(out/(('app.err' if n in ('inkscape','libreoffice') else n+'.err')))} for n,_ in procs}
  jdump(out/'record.json',result)
 return result

def schedule():
 cases=[];idx=0
 for app in ('inkscape','libreoffice'):
  for size in ('short','long'):
   for policy in ('STATIC_SUPERSET','RESOLVED_BOUND'):
    cases.append({'index':idx,'app':app,'size':size,'schedule':'STABLE','policy':policy});idx+=1
 for app in ('inkscape','libreoffice'):
  for policy in ('STATIC_SUPERSET','RESOLVED_BOUND','SURFACE_ID_ONLY'):
   cases.append({'index':idx,'app':app,'size':'long','schedule':'FOCUS_STALE','policy':policy});idx+=1
 for app in ('inkscape','libreoffice'):
  cases.append({'index':idx,'app':app,'size':'long','schedule':'STABLE','policy':'NO_INPUT'});idx+=1
 return cases

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);ap.add_argument('--indices',default='all');a=ap.parse_args();out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=False)
 sch=schedule(); inds=range(len(sch)) if a.indices=='all' else [int(x) for x in a.indices.split(',')]
 rows=[]
 for i in inds: rows.append(run_case(sch[i],out/f'{i:02d}'))
 jdump(out/'rows.json',rows); print(json.dumps({'rows':len(rows),'indices':list(inds),'exceptions':sum('exception' in r for r in rows)},sort_keys=True))
if __name__=='__main__':main()

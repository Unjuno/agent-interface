#!/usr/bin/env python3
import json,sys,zipfile,xml.etree.ElementTree as ET,hashlib,pathlib
p=pathlib.Path(sys.argv[2]); app=sys.argv[1]
out={'app':app,'path':str(p),'exists':p.exists()}
if p.exists():
 b=p.read_bytes(); out.update(size=len(b),sha256=hashlib.sha256(b).hexdigest())
 if app=='inkscape':
  root=ET.fromstring(b)
  rect=None
  for e in root.iter():
   if e.tag.endswith('rect') and e.attrib.get('id')=='r0': rect=e; break
  out['r0_x']=None if rect is None else rect.attrib.get('x')
  out['effect_ok']=out['r0_x']=='52'
 elif app=='libreoffice':
  try:
   with zipfile.ZipFile(p) as z: xml=z.read('content.xml')
   r=ET.fromstring(xml)
   pars=[''.join(e.itertext()) for e in r.iter() if e.tag.endswith('}p') or e.tag=='text:p']
   out['last_paragraph']=pars[-1] if pars else None
   out['effect_ok']=out['last_paragraph']=='z9z9'
  except Exception as e:
   out['parse_error']=type(e).__name__+': '+str(e); out['effect_ok']=False
print(json.dumps(out,sort_keys=True,separators=(',',':')))

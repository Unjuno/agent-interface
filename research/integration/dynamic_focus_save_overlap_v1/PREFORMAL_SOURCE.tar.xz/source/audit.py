#!/usr/bin/env python3
import argparse,json,pathlib,hashlib,statistics,sys

def load(p):return json.loads(pathlib.Path(p).read_text())
def fail(errors,msg):errors.append(msg)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('rows');ap.add_argument('--expected',type=int,default=16);a=ap.parse_args();rows=load(a.rows);errors=[];checks=0
 if len(rows)!=a.expected:fail(errors,f'row_count:{len(rows)}')
 seen=set(); overlap={};
 for r in rows:
  c=r['case']; key=(c['index'],c['app'],c['size'],c['schedule'],c['policy']); checks+=1
  if key in seen: fail(errors,'duplicate:'+str(key))
  seen.add(key)
  if 'exception' in r:fail(errors,f"exception:{c['index']}:{r['exception']}")
  checks+=4
  if not r.get('unsaved_precondition'):fail(errors,f"precondition:{c['index']}")
  if not r.get('final_keymap',{}).get('zero'):fail(errors,f"keymap:{c['index']}")
  if not r.get('final_buttons',{}).get('zero'):fail(errors,f"buttons:{c['index']}")
  for pn,pv in r.get('cleanup',{}).items():
   checks+=1
   if pv.get('returncode') is None:fail(errors,f"cleanup_unobserved:{c['index']}:{pn}")
  score=r.get('score',{}); ok=bool(score.get('data',{}).get('effect_ok'))
  bj=r.get('b_journal',[]); marker=[x for x in bj if x.get('byte')=='62']; other=[x for x in bj if x.get('byte')!='62']
  p=c['policy'];s=c['schedule']
  if p=='NO_INPUT':
   checks+=3
   if ok or r.get('final_sha256')!=r.get('original_sha256'):fail(errors,f'noinput_a:{c["index"]}')
   if bj:fail(errors,f'noinput_b:{c["index"]}')
  elif p in ('STATIC_SUPERSET','RESOLVED_BOUND'):
   checks+=4
   if not ok:fail(errors,f'a_effect:{c["index"]}')
   if len(marker)!=1:fail(errors,f'b_marker:{c["index"]}:{len(marker)}')
   if other:fail(errors,f'b_other:{c["index"]}:{other}')
   if not r.get('release_state',{}).get('zero'):fail(errors,f'release:{c["index"]}')
   if not r.get('release_buttons',{}).get('zero'):fail(errors,f'release_buttons:{c["index"]}')
   if c['size']=='long' and p=='RESOLVED_BOUND': overlap[c['app']]=r.get('timing',{}).get('b_before_a')
  elif p=='SURFACE_ID_ONLY':
   checks+=4
   if s!='FOCUS_STALE':fail(errors,'surface_schedule')
   if ok or r.get('final_sha256')!=r.get('original_sha256'):fail(errors,f'surface_a_changed:{c["index"]}')
   if len(marker)!=1:fail(errors,f'surface_marker:{c["index"]}')
   if not r.get('release_state',{}).get('zero'):fail(errors,f'surface_release:{c["index"]}')
   if not r.get('release_buttons',{}).get('zero'):fail(errors,f'surface_release_buttons:{c["index"]}')
   if not other:fail(errors,f'surface_no_wrong_surface_byte:{c["index"]}')
  if s=='FOCUS_STALE' and p in ('STATIC_SUPERSET','RESOLVED_BOUND'):
   checks+=1
   if not (r.get('preinput_focus',{}).get('belongs_a') is False and r.get('focus_repair',{}).get('ok')):fail(errors,f'focus_repair:{c["index"]}')
 for app in ('inkscape','libreoffice'):
  checks+=1
  if overlap.get(app) is not True:fail(errors,'long_overlap:'+app+':'+str(overlap.get(app)))
 out={'decision':'PASS_DYNAMIC_FOCUS_SAVE_TAIL_RUNG1_SCOPED' if not errors else 'HOLD_OR_FAIL','rows':len(rows),'checks':checks,'errors':errors,'long_overlap':overlap}
 print(json.dumps(out,sort_keys=True,separators=(',',':')));return 0 if not errors else 1
if __name__=='__main__':raise SystemExit(main())

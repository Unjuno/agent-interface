#!/usr/bin/env python3
import copy,json,pathlib,subprocess,sys,tempfile
rows=json.loads(pathlib.Path(sys.argv[1]).read_text()); audit=pathlib.Path(__file__).with_name('audit.py')
mut=[]
def add(name,fn):
 x=copy.deepcopy(rows);fn(x);mut.append((name,x))
add('drop_row',lambda x:x.pop())
add('duplicate_row',lambda x:x.append(copy.deepcopy(x[0])))
add('flip_score',lambda x:x[0]['score']['data'].__setitem__('effect_ok',False))
add('erase_marker',lambda x:x[1].__setitem__('b_journal',[]))
add('claim_overlap_false',lambda x:x[3]['timing'].__setitem__('b_before_a',False))
add('surface_fake_save',lambda x:x[10]['score']['data'].__setitem__('effect_ok',True))
add('nonneutral_keymap',lambda x:x[2]['final_keymap'].__setitem__('zero',False))
add('remove_wrong_surface_byte',lambda x:x[10].__setitem__('b_journal',[r for r in x[10]['b_journal'] if r.get('byte')=='62']))
add('focus_repair_missing',lambda x:x[8].__setitem__('focus_repair',None))
add('exception_injected',lambda x:x[4].__setitem__('exception','Injected'))
results=[]
for name,x in mut:
 with tempfile.TemporaryDirectory() as d:
  p=pathlib.Path(d)/'rows.json';p.write_text(json.dumps(x));cp=subprocess.run([sys.executable,'-B',str(audit),str(p)],capture_output=True,text=True)
  results.append({'name':name,'rejected':cp.returncode!=0,'exit':cp.returncode,'stdout':cp.stdout[-500:]})
out={'controls':results,'rejected':sum(r['rejected'] for r in results),'total':len(results)}
print(json.dumps(out,sort_keys=True,separators=(',',':')));raise SystemExit(0 if out['rejected']==len(results) else 1)

import json, subprocess, time, traceback, os
from pathlib import Path
from integrated_efficiency_client_v1 import RuntimeClient
out=Path('/out'); result={'scope':'single moved Chromium window, known fixture points; no model','passed':False}; client=None
try:
    with RuntimeClient(out/'run',991028) as client:
        task=client.ready['goal']['tasks'][0]
        source=client.navigate(task)
        before=source['pointer_binding']['geometry']; surface=source['pointer_binding']['surface']
        aliases,refusal=client.mint('A',source,{'field_point':[226,401],'submit_point':[376,401]},'move')
        if refusal is not None: raise RuntimeError('mint refused')
        candidates=[]
        for proc in Path('/proc').iterdir():
            if not proc.name.isdigit(): continue
            try: args=(proc/'cmdline').read_bytes().decode().split('\0')
            except (OSError,UnicodeError): continue
            if args and Path(args[0]).name=='Xvfb' and len(args)>1 and args[1]!=':91' and '-auth' in args:
                candidates.append((args[1],args[args.index('-auth')+1]))
        if len(candidates)!=1: raise RuntimeError('expected one private runtime Xvfb, got '+str(len(candidates)))
        env={**os.environ,'DISPLAY':candidates[0][0],'XAUTHORITY':candidates[0][1]}
        result['private_display']=candidates[0][0]
        moved=subprocess.run(['xdotool','windowmove','--sync',str(surface),'140','100'],capture_output=True,text=True,timeout=10,env=env)
        result['move_exit']=moved.returncode; result['move_stderr']=moved.stderr; result['surface']=surface; result['before']=before
        if moved.returncode: raise RuntimeError('window move failed')
        time.sleep(.25)
        check,_=client.check(aliases['field'],[12,19],'check-after-move')
        result.update(before=before,check=check)
        if not check.get('eligible'): raise RuntimeError('field not eligible after move')
        result['execution']=client.execute_handles(task,aliases)
        result['evaluation']=client.finish('finish-window-move')
        history=client.runtime/'submission-history.jsonl'
        rows=[json.loads(x) for x in history.read_text().splitlines()] if history.exists() else []
        result['history']=rows
        result['releases']=[p['terminal']['release'] for p in client.programs]
        result['passed']=(result['execution']['status']=='completed' and len(rows)==1 and rows[0].get('exact') is True and all(x.get('verified') is True and x.get('keys_down')==[] and x.get('buttons_down')==[] for x in result['releases']) and check.get('binding_translation')!=[0,0])
except Exception as error:
    result['error']=repr(error);result['traceback']=traceback.format_exc()
finally:
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':result['passed'],'error':result.get('error'),'move_exit':result.get('move_exit')}))
raise SystemExit(0 if result['passed'] else 1)

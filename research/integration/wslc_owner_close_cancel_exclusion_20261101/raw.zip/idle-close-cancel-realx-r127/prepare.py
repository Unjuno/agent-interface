import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parent
files=[p for p in (root/'src').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']+[root/n for n in ('trial.py','target.py','run.py','prepare.py')]
manifest={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
arms=[('r127-cancel-first','cancel_first'),('r127-close-first','close_first')]
for ident,mode in arms:
 p=root/ident;p.mkdir(exist_ok=False);(p/'output').mkdir()
 c={'allocation':'idle-close-cancel-'+ident,'mode':mode,'order':arms,'main_at_freeze':'6b117bf961675e62e1963377eaddae466bcdada4','predecessor_head':'e6ed07edad270cc4631518bf3b53124e4ada28b6','candidate':'r126 local close/cancel exclusion; exact source in manifest','image':'sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25','manifest_sha256':hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest(),'protocol':'private Xvfb, real owned process; real owned child with prestarted cleanup supervisor; pause ordinary cancellation control poll or close supervisor; test opposite entry refusal or deferral, resume, fresh owner types a','criteria':'cancel-first close deferred before supervisor closes; close-first cancel unconfirmed; expected old close results and fresh target a release/neutral','stop':'one try per arm; preserve failure; stop block on any failure or unknown cleanup','limits':'synthetic child and parent pauses; actual spawned owner and supervisor; no held input, no hard real-time or MAP01 claim'}
 (p/'conditions.json').write_text(json.dumps(c,indent=2)+'\n')
print('two close-cancel arms frozen')

"""Read-only checks of real-owner close/cancel overlap receipts."""
import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parent;errors=[];rows=[]
def check(value,message):
 if not value:errors.append(message)
manifest=json.loads((root/'manifest.json').read_text())
for name,digest in manifest.items():check(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,'source '+name)
for ident,mode in [('r127-cancel-first','cancel_first'),('r127-close-first','close_first')]:
 p=root/ident;c=json.loads((p/'conditions.json').read_text());d=json.loads((p/'output/result.json').read_text());e=json.loads((p/'output/target-events.json').read_text())
 check(c['mode']==mode and d['mode']==mode,ident+' mode')
 check(c['manifest_sha256']==hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest(),ident+' manifest')
 check(json.loads((p/'launcher-result.json').read_text())['returncode']==0 and d['status']=='passed',ident+' launcher')
 if mode=='cancel_first':
  check((p/'output/child-rpc-blocked').exists(),ident+' child boundary')
  check(d['close_during_cancel']['status']=='cleanup_deferred' and d['close_during_cancel']['cleanup_status']=='UNKNOWN' and d['supervisor_close_calls_during']==0,ident+' deferred close')
  check(d['cancel']['cleanup_status']=='UNKNOWN' and d['old_close']['cleanup_status']=='UNKNOWN',ident+' old cleanup')
 else:
  check(d['cancel_during_close']['status']=='cancel_unconfirmed' and d['cancel_during_close']['cleanup_status']=='UNKNOWN' and not d['cancel_during_close']['release_confirmed'],ident+' rejected cancel')
  check(d['old_close']['status']=='closed',ident+' old close')
 check(e==d['target_result'] and e['value']=='a' and [(x['type'],x['key']) for x in e['events']]==[('press','a'),('release','a')],ident+' target')
 check(d['release_verified'] and d['input_neutral'] and d['fresh_close']['release_confirmed'],ident+' fresh release')
 check(d['target_exit']==0 and d['server_exit']==0,ident+' exits')
 rows.append({'id':ident,'old_close':d['old_close']['status'],'old_cleanup':d['old_close'].get('cleanup_status'),'fresh_value':e['value']})
print(json.dumps({'status':'pass' if not errors else 'fail','rows':rows,'errors':errors},indent=2));raise SystemExit(bool(errors))

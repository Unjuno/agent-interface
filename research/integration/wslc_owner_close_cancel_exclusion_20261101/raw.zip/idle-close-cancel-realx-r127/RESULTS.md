# Close and ordinary cancellation: private-Xvfb owner trials

Two new serial WSLc allocations used the isolated r126 candidate based on
draft #10094 head `e6ed07edad270cc4631518bf3b53124e4ada28b6`. Main at
freeze was `6b117bf961675e62e1963377eaddae466bcdada4`. Each private Xvfb
container used one CPU, 1 GiB memory limit, no network, and the image pinned in
the conditions. Source, test harness and target were hashed before execution.

| Arm | Injected boundary and opposing operation | Old owner outcome |
| --- | --- | --- |
| cancel first | Ordinary RPC held in spawned child; parent cancellation control poll paused; close called | close deferred with UNKNOWN and did not close supervisor; after resuming, cancellation and final old cleanup remained UNKNOWN |
| close first | Parent paused while closing prestarted supervisor; cancellation called | cancellation unconfirmed/UNKNOWN; after resuming, old owner closed |

Each arm used a real spawned owner and prestarted supervisor, then a separate
fresh owner produced and released `a` in a synthetic target and neutral input
was observed. No old input was held. The child/parent pauses and the first arm's
control timeout were injected; one run per arm cannot establish general
concurrency safety, physical release, finite recovery or MAP01 behavior.

In the parent-only unit fixture, both ordering checks failed before the local
r126 change and passed after. The candidate passed 99 selected WSLc tests in
both normal and optimized modes; it remains local, not part of #10094. Raw
conditions, source hashes, reports, target events and launcher output remain
in each allocation. `audit.py` checks saved receipt consistency.

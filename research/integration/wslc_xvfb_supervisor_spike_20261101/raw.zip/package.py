import hashlib,json,pathlib,zipfile
root=pathlib.Path(__file__).resolve().parent;manifest=json.loads((root/'manifest.json').read_text())
for n,d in manifest.items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==d
arms=['supervisor-f01','supervisor-f02']
for arm in arms:
    p=root/arm;c=json.loads((p/'conditions.json').read_text());r=json.loads((p/'output/result.json').read_text())
    assert c['manifest_sha256']==hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()
    assert r['status']=='passed' and r['mode']==c['mode'] and json.loads((p/'launcher-result.json').read_text())['returncode']==0
    assert r['old_key_down_before_stop'] and r['fresh_key_down_before_fixture_release']==(r['mode']=='resume')
    assert r['fresh_neutral_before_task'] and r['fresh_neutral_after_task'] and r['fresh_target']['value']=='a'
    events=[e['type'] for e in r['fresh_target']['events'] if e['key']=='a']
    assert events==(['press','release'] if r['mode']=='retire' else ['release','press','release'])
    assert r['action']['result']['execution']['releases'][-1]['verified']
    names=[e['name'] for e in r['events']]
    order=(['old_server_started','old_effect_and_hold','old_server_stopped','old_server_retired','fresh_server_started','fresh_action_returned'] if r['mode']=='retire' else ['old_server_started','old_effect_and_hold','old_server_stopped','old_server_resumed','fixture_release_old_hold','fresh_action_returned'])
    assert names==order and all(r['events'][i]['ns']<=r['events'][i+1]['ns'] for i in range(len(r['events'])-1))
    assert r['server_exitcodes']==([-9,0] if r['mode']=='retire' else [0])
    assert r['target_exitcodes']==([1,0] if r['mode']=='retire' else [0,0])
dest=root.parent/'guarded-motion-deadline-r01/research/integration/wslc_xvfb_supervisor_spike_20261101';dest.mkdir(parents=True,exist_ok=False)
paths=[root/n for n in manifest]+[root/'manifest.json',pathlib.Path(__file__)]
for arm in arms:
    p=root/arm;paths += [p/'conditions.json',p/'launcher-result.json',p/'stdout',p/'stderr']+[x for x in (p/'output').rglob('*') if x.is_file()]
public={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
with zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in paths:z.write(p,p.relative_to(root).as_posix())
    z.writestr('public-manifest.json',json.dumps(public,indent=2,sort_keys=True)+'\n')
with zipfile.ZipFile(dest/'raw.zip') as z:
    for n,d in public.items():assert hashlib.sha256(z.read(n)).hexdigest()==d
print('validated',len(public),'files; sha256',hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest())

"""Experimental private display custody comparison; not production integration."""
import json, os, pathlib, signal, subprocess, sys, time, traceback
from Xlib import X, XK, display
from Xlib.ext import xtest
from runtime.cli_v1.owned_guarded_session import OwnedGuardedSessionOwner

def main():
    out=pathlib.Path('/out'); mode=os.environ['CONTROL_MODE']; r={'status':'started','mode':mode,'events':[]}
    def mark(name,**kw):r['events'].append({'name':name,'ns':time.monotonic_ns(),**kw})
    servers=[]; targets=[]; connections=[]; fresh=None; old=None; pidfd=None; held=False
    def start_server(number):
        p=subprocess.Popen(['Xvfb',f':{number}','-screen','0','640x480x24','-nolisten','tcp'],stdout=(out/f'xvfb-{number}.log').open('wb'),stderr=subprocess.STDOUT); servers.append(p)
        for _ in range(100):
            if p.poll() is not None:raise RuntimeError('server exited')
            try:
                c=display.Display(f':{number}');connections.append(c);return p,c
            except Exception:time.sleep(.05)
        raise RuntimeError('server unavailable')
    def start_target(number,name,conn):
        p=out/name;p.mkdir();t=subprocess.Popen(['python3','-B','/target.py'],env=dict(os.environ,TEST_DISPLAY=f':{number}',TARGET_OUT=str(p)),stdout=(p/'stdout').open('wb'),stderr=(p/'stderr').open('wb'));targets.append((t,p))
        until=time.monotonic()+4
        while not (p/'target-ready.json').exists():
            if t.poll() is not None or time.monotonic()>=until:raise RuntimeError('target unavailable')
            time.sleep(.01)
        ready=json.loads((p/'target-ready.json').read_text()); w=conn.create_resource_object('window',ready['xid']);conn.set_input_focus(w,X.RevertToParent,X.CurrentTime);conn.sync();return w,p
    try:
        if mode not in ('retire','resume'):raise RuntimeError('unknown mode')
        old,oc=start_server(194);pidfd=os.pidfd_open(old.pid);mark('old_server_started',pid=old.pid)
        oldwin,oldout=start_target(194,'old-target',oc)
        code=oc.keysym_to_keycode(XK.string_to_keysym('a'))
        def down(c,k):return bool(bytes(c.query_keymap())[k//8] & (1 << (k%8)))
        assert not down(oc,code);xtest.fake_input(oc,X.KeyPress,code);oc.sync();held=True
        until=time.monotonic()+2
        while time.monotonic()<until:
            try: value=json.loads((oldout/'target-events.json').read_text())['value']
            except (FileNotFoundError,json.JSONDecodeError):time.sleep(.01);continue
            if value=='a':break
            time.sleep(.01)
        else:raise RuntimeError('old target did not receive a')
        r['old_key_down_before_stop']=down(oc,code);assert r['old_key_down_before_stop'];mark('old_effect_and_hold')
        signal.pidfd_send_signal(pidfd,signal.SIGSTOP);until=time.monotonic()+2
        while time.monotonic()<until:
            state=next(x.split()[1] for x in pathlib.Path(f'/proc/{old.pid}/status').read_text().splitlines() if x.startswith('State:'))
            if state=='T':break
            time.sleep(.005)
        else:raise RuntimeError('old server not stopped')
        mark('old_server_stopped')
        if mode=='retire':
            signal.pidfd_send_signal(pidfd,signal.SIGKILL);old.wait(timeout=3);mark('old_server_retired',exitcode=old.returncode);held=False
            server,conn=start_server(195);mark('fresh_server_started',pid=server.pid)
        else:
            signal.pidfd_send_signal(pidfd,signal.SIGCONT);mark('old_server_resumed');conn=oc
        freshwin,freshout=start_target(195 if mode=='retire' else 194,'fresh-target',conn)
        freshcode=conn.keysym_to_keycode(XK.string_to_keysym('a'));r['fresh_key_down_before_fixture_release']=down(conn,freshcode)
        assert r['fresh_key_down_before_fixture_release']==(mode=='resume')
        if mode=='resume':
            xtest.fake_input(conn,X.KeyRelease,freshcode);conn.sync();held=False;mark('fixture_release_old_hold')
            assert not down(conn,freshcode)
        r['fresh_neutral_before_task']=not any(bytes(conn.query_keymap())) and not (conn.screen().root.query_pointer().mask & 0x1f00)
        assert r['fresh_neutral_before_task'];(out/'fresh-owner').mkdir()
        fresh=OwnedGuardedSessionOwner({'app':freshwin.id},out/'fresh-owner',':195' if mode=='retire' else ':194',process_identity=True,query_worker=True,observation_worker=True)
        fresh.get();obs=fresh.observe_idle_until(deadline_ns=time.monotonic_ns()+3_000_000_000,cancel_token='fresh');g=obs['source']['pointer_binding']['geometry'];(out/'mint').mkdir();(out/'action').mkdir()
        minted=fresh.invoke_guarded('guarded_mint',{'alias':'field','source_sequence':obs['source']['sequence'],'point':[g[0]+20,g[1]+20],'region_size':[12,12]},out/'mint')
        action=fresh.invoke_guarded('guarded_input',{'alias':'field','offset':minted['offset'],'interaction':'keyboard','observe_after':False,'tail':[{'op':'key_chord','keys':['a']}]},out/'action');r['mint']=minted;r['action']=action;mark('fresh_action_returned')
        until=time.monotonic()+2
        while time.monotonic()<until:
            try: result=json.loads((freshout/'target-events.json').read_text())
            except (FileNotFoundError,json.JSONDecodeError):time.sleep(.01);continue
            if result['value']=='a' and any(e['type']=='release' and e['key']=='a' for e in result['events']):break
            time.sleep(.01)
        else:raise RuntimeError('fresh target effect/release missing')
        r['fresh_target']=result;r['fresh_close']=fresh.close();fresh=None;conn.sync();r['fresh_neutral_after_task']=not any(bytes(conn.query_keymap())) and not (conn.screen().root.query_pointer().mask & 0x1f00)
        assert minted['status']=='minted' and action['status']=='completed' and action['result']['execution']['releases'][-1]['verified'] and r['fresh_neutral_after_task'];r['status']='passed'
    except BaseException as e:r.update(status='failed',error=repr(e),traceback=traceback.format_exc())
    finally:
        if held and old is not None and old.poll() is None:
            try:signal.pidfd_send_signal(pidfd,signal.SIGCONT);xtest.fake_input(oc,X.KeyRelease,code);oc.sync();r['fallback_release']=True
            except Exception as e:r['fallback_release_error']=repr(e);r['status']='failed'
        if fresh is not None:
            try:r['fresh_cleanup']=fresh.close()
            except Exception as e:r['fresh_cleanup_error']=repr(e);r['status']='failed'
        for t,p in targets:
            (p/'target-stop').write_text('stop')
            try:t.wait(timeout=3)
            except subprocess.TimeoutExpired:t.terminate();t.wait();r['status']='failed'
        r['target_exitcodes']=[t.returncode for t,_ in targets]
        for c in connections:
            try:c.close()
            except Exception:pass
        for p in servers:
            if p.poll() is None:
                p.terminate()
                try:p.wait(timeout=3)
                except subprocess.TimeoutExpired:p.kill();p.wait();r['status']='failed'
        r['server_exitcodes']=[p.returncode for p in servers]
        if pidfd is not None:os.close(pidfd)
        (out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
    return 0 if r['status']=='passed' else 1
if __name__=='__main__':sys.exit(main())

"""WSLc benchmark: same 16x16 RGB search, scalar PIL and vectorized numpy."""
import hashlib,json,platform,statistics,time
from pathlib import Path
from PIL import Image,ImageChops,ImageStat,__version__ as pillow_version
import numpy as np
from numpy.lib.stride_tricks import sliding_window_view
P=Path('/bench');meta=json.loads((P/'input-origin.json').read_text());x,y=meta['origin'];half=8
source=Image.open(P/'source.png').convert('RGB');checked=Image.open(P/'checked.png').convert('RGB');assert source.size==checked.size==(1280,1024)
template=source.crop((x-half,y-half,x+half,y+half));target=np.asarray(template,dtype=np.int16).transpose(2,0,1)
region=checked.crop((x-80-half,y-60-half,x+80+half,y+60+half));array=np.asarray(region,dtype=np.uint8);assert array.shape==(136,176,3)
def scalar():
 vals=[]
 for dy in range(-60,61,2):
  for dx in range(-80,81,2):
   patch=checked.crop((x+dx-half,y+dy-half,x+dx+half,y+dy+half));stat=ImageStat.Stat(ImageChops.difference(template,patch));vals.append(int(sum(stat.sum)))
 return np.array(vals,dtype=np.int64).reshape(61,81)
def vector():
 windows=sliding_window_view(array,(16,16),axis=(0,1))[::2,::2];return np.abs(windows.astype(np.int16)-target).sum(axis=(2,3,4),dtype=np.int64)
def summary(a):
 rows=sorted((int(a[i,j]),-80+2*j,-60+2*i) for i in range(61) for j in range(81));best=rows[0];second=next(v for v in rows[1:] if abs(v[1]-best[1])>16 or abs(v[2]-best[2])>16);return {'candidate':[x+best[1],y+best[2]],'best_sum':best[0],'runner_sum':second[0],'gap_sum':second[0]-best[0]}
s=scalar();v=vector();assert np.array_equal(s,v);assert summary(s)['candidate']==meta['expected_candidate'];runs=[]
for i in range(12):
 row={'iteration':i,'order':['scalar','vector'] if i%2==0 else ['vector','scalar']}
 for name in row['order']:
  start=time.perf_counter_ns();val=scalar() if name=='scalar' else vector();row[name+'_ns']=time.perf_counter_ns()-start;assert np.array_equal(val,s)
 runs.append(row)
result={'status':'completed','image_size':source.size,'candidate_grid':[61,81],'template_size':16,'candidate_count':int(s.size),'scores_sha256':hashlib.sha256(s.astype('<i8').tobytes()).hexdigest(),'score_sums':s.ravel().tolist(),'summary':summary(s),'runs':runs,'python':platform.python_version(),'numpy':np.__version__,'pillow':pillow_version,'scalar_median_ns':statistics.median(q['scalar_ns'] for q in runs),'vector_median_ns':statistics.median(q['vector_ns'] for q in runs),'vector_windows_shape':list(sliding_window_view(array,(16,16),axis=(0,1))[::2,::2].shape),'vector_int16_windows_bytes':int(61*81*3*16*16*2),'notes':'timings include each method computation; loading, source preparation and audit excluded; single process, single CPU, 12 interleaved trials; matcher remains shadow only'}
(P/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='score_sums' and k!='runs'}),flush=True)

import json,os,time
from pathlib import Path
from Xlib import X,display
from Xlib.ext import xtest

def grab_and_stall(request):
 d=display.Display(':163');root=d.screen().root;base=d.display.info.resource_id_base;pid=os.getpid();session=request['session_id'];generation={'session_id':session,'child_pid':pid,'x_resource_base':base,'binding_revision':0};out=Path('/out');prepared={'owner_pid':pid,'resource_base':base,'owner_generation':generation,'buttons':['left'],'keys':{},'target':request['target']}
 with (out/'custody.json').open('x') as f:json.dump(prepared,f);f.flush();os.fsync(f.fileno())
 d.grab_server();d.sync();child=root.translate_coords(root,100,100).child;child_id=getattr(child,'id',child)
 if child_id!=request['target']:d.ungrab_server();d.sync();return {'status':'unknown','reason':'target_changed'}
 xtest.fake_input(d,X.ButtonPress,1);d.sync();down=time.monotonic_ns();(out/'down.json').write_text(json.dumps({'down_ns':down,'scheduled_late_ns':down+2_000_000_000}))
 time.sleep(2.0)
 xtest.fake_input(d,X.ButtonRelease,1);xtest.fake_input(d,X.ButtonPress,1);xtest.fake_input(d,X.ButtonRelease,1);d.ungrab_server();d.sync();(out/'late.json').write_text('late input sent')
 return {'status':'late_sent'}

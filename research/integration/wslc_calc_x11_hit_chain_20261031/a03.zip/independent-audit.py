import hashlib,json,sys
from pathlib import Path
from PIL import Image
p=Path(sys.argv[1]);root=p/'output';o=root/'owner';hit=json.loads((root/'hit-test.json').read_text());v=json.loads((root/'visual-check.json').read_text());neutral=json.loads((root/'final-neutral.json').read_text());images=[]
for n in (1,2):
 f=next(o.rglob(f'observation-{n}.json'));obs=json.loads(f.read_text());a=obs['native']['artifact'];path=root/a['path'].removeprefix('/out/');blob=path.read_bytes();assert hashlib.sha256(blob).hexdigest()==a['sha256'];images.append(Image.open(path).convert('RGB'))
assert images[0].tobytes()==images[1].tobytes() and v['full_rgb_equal'] and v['target_patch_equal'];assert hit['target'] not in hit['chain'] and hit['belongs_to_target'] is False;assert not list(o.rglob('program-*.json')) and not list(o.rglob('mint-*.json'));assert neutral['keys_down']==[] and neutral['buttons']==0 and neutral['close']['release_attempted'] is False;print(json.dumps({'same_full_rgb':True,'target_in_reported_chain':False,'input_programs':0,'keys_down':[],'buttons':0},indent=2))

import json,hashlib,sys,xml.etree.ElementTree as ET
from pathlib import Path
p=Path(sys.argv[1]);blob=(p/'output/saved.fods').read_bytes();e=json.loads((p/'output/method/saved-effect.json').read_text());r=json.loads((p/'output/result.json').read_text());digest=hashlib.sha256(blob).hexdigest();assert digest==e['verdict']['sha256'] and len(blob)==e['verdict']['bytes'];root=ET.fromstring(blob);T='{urn:oasis:names:tc:opendocument:xmlns:table:1.0}';O='{urn:oasis:names:tc:opendocument:xmlns:office:1.0}';sheets=root.findall('.//'+T+'table');assert len(sheets)==1;rows=sheets[0].findall(T+'table-row');assert len(rows)==2 and len(sheets[0].findall('.//'+T+'table-row'))==2;values=[]
for ri,row in enumerate(rows):
 col=0
 for cell in row:
  if cell.tag not in (T+'table-cell',T+'covered-table-cell'):continue
  count=int(cell.get(T+'number-columns-repeated','1'));assert cell.get(T+'formula') is None
  if cell.get(O+'value') is not None or cell.get(O+'value-type') is not None or ''.join(cell.itertext()).strip():
   assert count==1 and int(row.get(T+'number-rows-repeated','1'))==1;values.append((ri,col,cell.get(O+'value-type'),cell.get(O+'value'),''.join(cell.itertext()).strip()))
  col+=count
assert values==[(0,0,'float','731','731'),(1,0,'float','864','864')];m=r['method']['method_receipt'];assert m['outcome']=='TASK_SUCCEEDED' and m['reason']=='method_complete' and m['pending_effect'] is None and m['completed_transitions']==2;assert any(x.get('event')=='effect_checked' and x.get('action')=='save' and x.get('status')=='succeeded' and x.get('evidence_ref')=='saved-effect' for x in m['critical_events']);assert all(x['release_verified'] for x in m['transitions']);assert r['keys_down']==[] and r['buttons']==0 and r['close']['release']['verified'];print(json.dumps({'saved_sha256':digest,'values':values,'graph_outcome':m['outcome'],'all_releases_verified':True,'keys_down':r['keys_down'],'buttons':r['buttons']},indent=2))

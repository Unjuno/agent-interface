import array,asyncio,hashlib,json,os,socket,subprocess,sys,threading,time,uuid
from pathlib import Path
from unittest.mock import patch
from Xlib import X,XK,display
from runtime.cli_v1.mcp_server import create_server
from runtime.cli_v1.owned_guarded_session import OwnedGuardedSessionOwner, _read_owner_input_obligations
from runtime.guarded_x11_v1.private_display_owner import PrivateDisplayOwner

def metadata(result):return json.loads(result.content[0].text)
async def main():
    mode=sys.argv[1];out=Path('/out')/mode;root=Path('/tmp')/('r522-'+mode);root.mkdir()
    display_owner=PrivateDisplayOwner(root/'display');session=display_owner.start(timeout_s=5)
    os.environ['XAUTHORITY']=str(session.authority)
    app=display.Display(session.display)
    win=app.screen().root.create_window(10,10,200,120,0,app.screen().root_depth,
        X.InputOutput,X.CopyFromParent,event_mask=X.KeyPressMask|X.KeyReleaseMask)
    win.map();win.set_input_focus(X.RevertToParent,X.CurrentTime);app.sync()
    gc=win.create_gc(foreground=app.screen().white_pixel);win.fill_rectangle(gc,16,16,8,8);app.sync()
    captured={};entered=threading.Event();block=threading.Event()
    original_start=OwnedGuardedSessionOwner._ensure_started
    original_cancel=OwnedGuardedSessionOwner.cancel_guarded
    def track(self):
        result=original_start(self);captured['owner']=self;return result
    def stalled(self,token,**kwargs):
        captured['cancel_token']=token;captured['cancel_options']=kwargs;entered.set()
        if not block.wait(25):raise TimeoutError('injected cancellation stall')
        return original_cancel(self,token,**kwargs)
    with patch.object(OwnedGuardedSessionOwner,'_ensure_started',track), \
         patch.object(OwnedGuardedSessionOwner,'cancel_guarded',stalled):
        server=create_server({'app':win.id},root/'mcp',session_mode='guarded-x11',
            display_name=session.display,guarded_owned_process=True,guarded_process_identity=True,
            guarded_query_worker=True,guarded_prestarted_cancel_supervisor=True,
            _guarded_display_owner=display_owner,_guarded_xauthority=str(session.authority),
            _guarded_cancel_transaction_timeout_s=7,_guarded_recovery_retirement_reserve_ns=2_000_000_000)
        observed=metadata(await server.call_tool('interface_guarded_observe',{}))
        if observed.get('status')!='observed':raise RuntimeError('observe failed')
        guard=captured['owner'];owner_pid=guard._process.pid;supervisor_pid=guard._cleanup_supervisor._process.pid
        left,right=socket.socketpair();token=uuid.uuid4().hex
        guardian_err=(out/'guardian-stderr.txt').open('wb')
        guardian=subprocess.Popen([sys.executable,'/fixture/guardian.py',str(right.fileno()),str(out),token,mode],
            pass_fds=(right.fileno(),),start_new_session=True,stdout=subprocess.DEVNULL,stderr=guardian_err)
        guardian_err.close()
        right.close();left.settimeout(5)
        fds=[os.pidfd_open(owner_pid),os.pidfd_open(supervisor_pid),os.pidfd_open(os.getpid())]
        left.sendmsg([b'P'],[(socket.SOL_SOCKET,socket.SCM_RIGHTS,array.array('i',fds))])
        if left.recv(1)!=b'R':raise RuntimeError('guardian not ready before action')
        guardian_ready_ns=time.monotonic_ns()
        minted=metadata(await server.call_tool('interface_guarded_mint',{'alias':'field',
            'source_sequence':observed['source']['sequence'],'point':[30,30],'region_size':[12,12]}))
        if minted.get('status')!='minted':raise RuntimeError('mint failed '+repr(minted))
        action_started_ns=time.monotonic_ns()
        action=metadata(await server.call_tool('interface_guarded_input',{'alias':'field',
            'offset':minted['offset'],'interaction':'keyboard','observe_after':False,'wait_for_result_ms':0,
            'tail':[{'op':'key_state','key':'a','down':True},{'op':'wait_update','timeout_ms':5000},
                    {'op':'key_state','key':'a','down':False}]}))
        if action.get('status')!='pending':raise RuntimeError('action not pending '+repr(action))
        code=app.keysym_to_keycode(XK.string_to_keysym('a'));deadline=time.monotonic()+3;pressed=False;down=False
        while time.monotonic()<deadline:
            bits=app.query_keymap();down=bool(bits[code//8] & (1 << (code%8)))
            while app.pending_events():
                ev=app.next_event()
                if ev.type==X.KeyPress and ev.detail==code:pressed=True
            if pressed and down:break
            await asyncio.sleep(.01)
        if not pressed or not down:raise RuntimeError('held key not observed')
        cancel=metadata(await server.call_tool('interface_guarded_cancel',{'call_id':action['call_id']}))
        if cancel.get('status')!='pending' or not entered.is_set():raise RuntimeError('cancel not pending '+repr(cancel))
        result=metadata(await server.call_tool('interface_results',{'call_id':action['call_id']}))
        if result.get('cancellation',{}).get('status')!='pending':raise RuntimeError('cancel custody not pending')
        obligations=_read_owner_input_obligations(guard._owner_input_obligations_state)
        cancellation=result['cancellation']
        request={'schema':'r526-prepared-v1','guardian_token':token,'call_id':action['call_id'],
            'gate_token':captured['cancel_token'],'operation_id':cancel['operation_id'],
            'owner_pid':owner_pid+(1 if mode=='mismatched' else 0),'supervisor_pid':supervisor_pid,'parent_pid':os.getpid(),
            'owner_generation':cancellation['owner_generation'],
            'deadline_ns':cancellation['transaction_deadline_monotonic_ns'],'obligations':obligations}
        (out/'handoff-request.json').write_text(json.dumps(request,indent=2))
        left.sendall(json.dumps(request,sort_keys=True,separators=(',',':')).encode()+b'\n')
        left.settimeout(1 if mode in ('writer_stalled','late_ack') else 5)
        commit_sent=False;commit_attempted=False;commit_error=None;ack_digest=None
        try:
            answer=left.recv(1)
            if answer==b'A':
                digest=b''
                while len(digest)<64:
                    chunk=left.recv(64-len(digest))
                    if not chunk:raise RuntimeError('short ack')
                    digest+=chunk
                ack_digest=digest.decode('ascii')
                expected=hashlib.sha256(json.dumps(request,sort_keys=True,separators=(',',':')).encode()).hexdigest()
                if ack_digest!=expected:raise RuntimeError('prepared digest mismatch')
                commit_attempted=True
                if mode=='error_before':raise OSError('injected failure before send')
                left.sendall(b'C')
                if mode=='error_after':raise OSError('injected failure after send')
                commit_sent=True
                if mode=='ack_failure':
                    left.shutdown(socket.SHUT_RDWR)
                    raise OSError('injected peer shutdown before final ack')
                if left.recv(1)!=b'K':raise RuntimeError('commit acknowledgement missing')
                decision='accepted'
            elif answer==b'N':decision='rejected';ack_digest=None
            else:raise RuntimeError('unexpected ack')
        except socket.timeout:
            decision='commit_unknown' if commit_attempted else 'timeout';commit_error='socket.timeout'
        except OSError as error:
            decision='commit_unknown' if commit_attempted else 'transport_error';commit_error=repr(error)
        if mode in ('late_ack','error_before','error_after','ack_failure'):await asyncio.sleep(.6)
        record={'parent_pid':os.getpid(),'owner_pid':owner_pid,'supervisor_pid':supervisor_pid,'guardian_pid':guardian.pid,
            'display_pid':display_owner._process.pid,'display':session.display,'authority':str(session.authority),
            'token':token,'old_press_observed':pressed,'old_key_down':down,
            'action_pending':result.get('status')=='pending',
            'committed':decision=='accepted','commit_attempted':commit_attempted,'commit_sent':commit_sent,
            'commit_error':commit_error,'decision':decision,'ack_digest':ack_digest,
            'guardian_ready_ns':guardian_ready_ns,'action_started_ns':action_started_ns,
            'parent_preexit_ns':time.monotonic_ns(),
            'action_call_id':action['call_id'],
            'cancel_response':cancel,'cancel_results':result,'cancel_gate':captured['cancel_options']}
        (out/'mcp-observe.json').write_text(json.dumps(observed,indent=2,default=str))
        (out/'mcp-mint.json').write_text(json.dumps(minted,indent=2,default=str))
        (out/'mcp-action.json').write_text(json.dumps(action,indent=2,default=str))
        (out/'mcp-cancel.json').write_text(json.dumps(cancel,indent=2,default=str))
        (out/'mcp-results.json').write_text(json.dumps(result,indent=2,default=str))
        print(json.dumps(record),flush=True)
        if sys.stdin.buffer.read(1)!=b'X':raise RuntimeError('observer failed to pin')
        os._exit(0)
if __name__=='__main__':asyncio.run(main())

import array,hashlib,json,os,select,signal,socket,sys,time
from pathlib import Path

sock=socket.socket(fileno=int(sys.argv[1]));out=Path(sys.argv[2]);token=sys.argv[3];mode=sys.argv[4];fds=[];expected_parent=os.getppid()
def write_sync(path,data):
    temp=path.with_suffix('.tmp')
    fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data);f.flush();os.fsync(f.fileno())
        os.replace(temp,path)
        d=os.open(out,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(d)
        finally:os.close(d)
    except BaseException:
        raise
try:
    sock.settimeout(6);size=array.array('i').itemsize
    data,anc,flags,_=sock.recvmsg(1,socket.CMSG_SPACE(size*3))
    for level,kind,value in anc:
        if (level,kind)==(socket.SOL_SOCKET,socket.SCM_RIGHTS):
            a=array.array('i');a.frombytes(value[:len(value)//size*size]);fds.extend(a)
    if data!=b'P' or flags & (socket.MSG_CTRUNC|socket.MSG_TRUNC) or len(fds)!=3:
        raise RuntimeError('invalid descriptor transfer')
    pids=[]
    for fd in fds:
        info=Path('/proc/self/fdinfo',str(fd)).read_text()
        pid=int(next(x.split(':',1)[1] for x in info.splitlines() if x.startswith('Pid:')))
        if pid<=1:raise RuntimeError('invalid pidfd')
        pids.append(pid)
    if len(set(pids))!=3 or pids[2]!=expected_parent:raise RuntimeError('invalid parent process')
    sock.sendall(b'R')
    buf=b''
    while not buf.endswith(b'\n') and len(buf)<8192:
        chunk=sock.recv(1024)
        if not chunk:raise RuntimeError('handoff missing')
        buf+=chunk
    rec=json.loads(buf)
    gen=rec.get('owner_generation') or {}
    valid=(rec.get('schema')=='r526-prepared-v1' and rec.get('guardian_token')==token
        and type(rec.get('call_id')) is str and len(rec['call_id'])==32
        and type(rec.get('operation_id')) is str and len(rec['operation_id'])==32
        and rec.get('gate_token')==rec['call_id'] and rec.get('owner_pid')==pids[0]
        and rec.get('supervisor_pid')==pids[1] and rec.get('parent_pid')==pids[2] and gen.get('child_pid')==pids[0]
        and type(gen.get('session_id')) is str and len(gen['session_id'])==32
        and type(gen.get('x_resource_base')) is int and gen['x_resource_base']>0
        and type(rec.get('deadline_ns')) is int and rec['deadline_ns']>time.monotonic_ns()
        and rec.get('obligations',{}).get('status')=='snapshot'
        and 'a' in rec['obligations'].get('obligations',{}).get('keys',{}))
    if not valid:
        sock.sendall(b'N');sock.settimeout(10)
        if sock.recv(1)!=b'':raise RuntimeError('unexpected input after reject')
        result={'status':'rejected','signal_sent':False,'token':token,'pids':pids}
    else:
        canonical=json.dumps(rec,sort_keys=True,separators=(',',':')).encode()
        digest=hashlib.sha256(canonical).hexdigest()
        if mode=='writer_stalled':time.sleep(30)
        write_sync(out/'custody-prepared.json',canonical)
        if mode=='late_ack':time.sleep(1.2)
        sock.sendall(b'A'+digest.encode('ascii'));ack_sent_ns=time.monotonic_ns();sock.settimeout(10)
        try:
            decision=sock.recv(1);decision_kind='eof' if decision==b'' else 'message'
        except ConnectionResetError:
            decision=b'';decision_kind='connection_reset'
        decision_ns=time.monotonic_ns()
        if decision==b'':
            result={'status':'uncommitted','ack_sent':True,'signal_sent':False,
                    'token':token,'record_sha256':digest,'ack_sent_ns':ack_sent_ns,
                    'decision_kind':decision_kind,'decision_ns':decision_ns}
        elif decision==b'C':
            if mode=='ack_failure':
                if sock.recv(1)!=b'':raise RuntimeError('expected peer shutdown')
            ack_sent=False;ack_error=None
            try:
                sock.sendall(b'K');ack_sent=True
            except OSError as error:ack_error=repr(error)
            ack_done_ns=time.monotonic_ns()
            parent_poll=select.poll();parent_poll.register(fds[2],select.POLLIN)
            parent_exited=bool(parent_poll.poll(6000));parent_exit_ns=time.monotonic_ns()
            if not parent_exited:raise TimeoutError('parent exit not observed after commit')
            rows=[]
            for role,fd,pid in zip(('owner','supervisor'),fds,pids):
                try:signal.pidfd_send_signal(fd,signal.SIGKILL);sent=True
                except ProcessLookupError:sent=False
                poll=select.poll();poll.register(fd,select.POLLIN);dead=bool(poll.poll(3000))
                rows.append({'role':role,'pid':pid,'signal_sent':sent,'exit_observed':dead})
            result={'status':'retired','token':token,'record_sha256':digest,'rows':rows,
                    'commit_received':True,'ack_sent':ack_sent,'ack_error':ack_error,
                    'ack_done_ns':ack_done_ns,'parent_pid':pids[2],
                    'parent_exit_observed':parent_exited,'parent_exit_ns':parent_exit_ns,
                    'release_confirmed':False,'task_success':None,'replay_allowed':False}
        else:raise RuntimeError('invalid commit')
    temp=out/'guardian-receipt.tmp';temp.write_text(json.dumps(result,indent=2));os.replace(temp,out/'guardian-receipt.json')
finally:
    for fd in fds:os.close(fd)
    sock.close()

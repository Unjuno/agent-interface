import array,json,os,socket,subprocess,sys,time,uuid
from pathlib import Path

mode=sys.argv[1];out=Path(sys.argv[2]);token=uuid.uuid4().hex
child=subprocess.Popen([sys.executable,'-c','import time; time.sleep(30)'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
pidfd=os.pidfd_open(child.pid);left,right=socket.socketpair()
guardian=subprocess.Popen([sys.executable,'/fixture/guardian.py',str(right.fileno()),
    str(out/(mode+'-receipt.json')),token],pass_fds=(right.fileno(),),start_new_session=True,
    stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
right.close();left.settimeout(5)
left.sendmsg([b'P'],[(socket.SOL_SOCKET,socket.SCM_RIGHTS,array.array('i',[pidfd]))])
if left.recv(1)!=b'R':raise RuntimeError('guardian not ready')
committed=False
if mode=='committed':
    left.sendall(b'C')
    if left.recv(1)!=b'A':raise RuntimeError('handoff not acknowledged')
    committed=True
print(json.dumps({'mode':mode,'token':token,'child_pid':child.pid,'guardian_pid':guardian.pid,
    'committed':committed,'handoff_ns':time.monotonic_ns()}),flush=True)
if sys.stdin.buffer.read(1)!=b'X':raise RuntimeError('observer did not pin child')
os._exit(0)

import json,os,select,signal,subprocess,sys,time
from pathlib import Path

out=Path('/out');results=[];owned=[]
sentinel=subprocess.Popen([sys.executable,'-c','import time; time.sleep(30)'])
sentinel_fd=os.pidfd_open(sentinel.pid)
def exited(fd):
    p=select.poll();p.register(fd,select.POLLIN);return bool(p.poll(0))
try:
    for mode in ('committed','uncommitted'):
        start=time.monotonic_ns()
        parent=subprocess.Popen([sys.executable,'/fixture/parent.py',mode,str(out)],
            stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        line=parent.stdout.readline().decode();identity=json.loads(line)
        fd=os.pidfd_open(identity['child_pid']);owned.append(fd)
        parent.stdin.write(b'X');parent.stdin.flush();parent.stdin.close()
        parent.wait(timeout=8)
        elapsed=(time.monotonic_ns()-start)/1e6
        (out/(mode+'-parent-stdout.txt')).write_text(line)
        (out/(mode+'-parent-stderr.txt')).write_bytes(parent.stderr.read())
        if parent.returncode!=0:raise RuntimeError('parent failed '+mode)
        receipt=out/(mode+'-receipt.json');deadline=time.monotonic()+8
        while not receipt.exists() and time.monotonic()<deadline:time.sleep(.01)
        if not receipt.exists():raise TimeoutError('guardian receipt '+mode)
        row=json.loads(receipt.read_text());dead=exited(fd)
        checks={'identity':row['pid']==identity['child_pid'] and row['token']==identity['token'],
                'parent_exit_bounded':elapsed<8000,'sentinel_alive':not exited(sentinel_fd),
                'expected_outcome':(dead and row['status']=='observed_exit') if mode=='committed'
                    else (not dead and row['status']=='uncommitted' and row['signal_sent'] is False)}
        results.append({'mode':mode,'parent':identity,'parent_elapsed_ms':elapsed,
                        'receipt':row,'target_exit_observed':dead,'checks':checks})
        if not all(checks.values()):raise AssertionError(mode+' failed checks')
    status='PASS'
except BaseException as error:
    status='ERROR';results.append({'error':repr(error)})
finally:
    for fd in owned:
        if not exited(fd):
            try:signal.pidfd_send_signal(fd,signal.SIGKILL)
            except ProcessLookupError:pass
        os.close(fd)
    if sentinel.poll() is None:signal.pidfd_send_signal(sentinel_fd,signal.SIGKILL)
    sentinel.wait(timeout=3);os.close(sentinel_fd)
    (out/'result.json').write_text(json.dumps({'status':status,'arms':results,
        'sentinel_exitcode':sentinel.returncode},indent=2)+'\n')
    print(json.dumps({'status':status,'arms':len(results)}),flush=True)
sys.exit(0 if status=='PASS' else 1)

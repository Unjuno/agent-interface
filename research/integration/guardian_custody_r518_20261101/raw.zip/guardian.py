import array,json,os,select,signal,socket,sys,time
from pathlib import Path

sock=socket.socket(fileno=int(sys.argv[1])); receipt=Path(sys.argv[2]); token=sys.argv[3]
sock.settimeout(5); owned_fd=None
try:
    data,anc,flags,_=sock.recvmsg(1,socket.CMSG_SPACE(array.array('i').itemsize))
    fds=[]
    for level,kind,value in anc:
        if (level,kind)==(socket.SOL_SOCKET,socket.SCM_RIGHTS):
            a=array.array('i');a.frombytes(value[:len(value)//a.itemsize*a.itemsize]);fds.extend(a)
    if data!=b'P' or flags & (socket.MSG_CTRUNC|socket.MSG_TRUNC) or len(fds)!=1:
        for fd in fds:os.close(fd)
        raise RuntimeError('invalid descriptor transfer')
    owned_fd=fds[0]
    info=Path('/proc/self/fdinfo',str(owned_fd)).read_text()
    pid=int(next(line.split(':',1)[1] for line in info.splitlines() if line.startswith('Pid:')))
    if pid<=1:raise RuntimeError('invalid pidfd identity')
    sock.sendall(b'R')
    msg=sock.recv(1)
    if msg!=b'C':
        result={'status':'uncommitted','pid':pid,'token':token,'signal_sent':False}
    else:
        sock.sendall(b'A');sock.settimeout(10)
        if sock.recv(1)!=b'':raise RuntimeError('unexpected data after commit')
        started=time.monotonic_ns()
        try:signal.pidfd_send_signal(owned_fd,signal.SIGKILL);sent=True
        except ProcessLookupError:sent=False
        poll=select.poll();poll.register(owned_fd,select.POLLIN)
        dead=bool(poll.poll(3000))
        result={'status':'observed_exit' if dead else 'unknown','pid':pid,'token':token,
                'signal_sent':sent,'release_confirmed':False,'task_success':None,
                'replay_allowed':False,'exit_observation_ms':(time.monotonic_ns()-started)/1e6}
    temp=receipt.with_suffix('.tmp');temp.write_text(json.dumps(result,indent=2));os.replace(temp,receipt)
finally:
    if owned_fd is not None:os.close(owned_fd)
    sock.close()

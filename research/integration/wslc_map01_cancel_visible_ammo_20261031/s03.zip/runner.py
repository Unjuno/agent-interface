import json,os,signal,subprocess,time,traceback,hashlib,math,threading
from pathlib import Path
from Xlib import X,display,error,XK
import vizdoom as vd
from runtime.cli_v1.mcp_guarded import GuardedSessionOwner

out=Path('/out');route=os.environ['ROUTE'];x=None;d=None;game=None;owner=None
record={'route':route,'status':'running','task_success':None,'samples':[],'model_calls':0}
try:
 os.environ['DISPLAY']=':153';os.environ['SDL_VIDEODRIVER']='x11';os.environ['HOME']='/tmp';os.environ['XDG_CACHE_HOME']='/tmp/cache'
 log=(out/'xvfb.log').open('wb');x=subprocess.Popen(['Xvfb',':153','-screen','0','1280x1024x24','-nolisten','tcp'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 for _ in range(100):
  try:d=display.Display(':153');break
  except Exception:time.sleep(.05)
 if d is None:raise RuntimeError('Xvfb unavailable')
 cfg=Path('/tmp/doom-keys.ini');cfg.write_text('[Doom.Bindings]\nw=+forward\nf=+attack\n')
 pkg=Path(vd.__file__).resolve().parent;iwad=pkg/'freedoom2.wad';record['iwad_sha256']=hashlib.sha256(iwad.read_bytes()).hexdigest()
 game=vd.DoomGame();game.set_doom_game_path(str(iwad));game.set_doom_scenario_path('');game.set_doom_map('MAP01');game.set_doom_config_path(str(cfg));game.set_mode(vd.Mode.ASYNC_SPECTATOR);game.set_ticrate(35);game.set_seed(991031);game.set_doom_skill(1);game.set_episode_timeout(2100);game.set_window_visible(True);game.set_console_enabled(False);game.set_sound_enabled(False);game.set_render_hud(True);game.set_screen_resolution(vd.ScreenResolution.RES_640X480);game.set_available_buttons([vd.Button.MOVE_FORWARD,vd.Button.ATTACK]);game.set_available_game_variables([vd.GameVariable.POSITION_X,vd.GameVariable.POSITION_Y,vd.GameVariable.HEALTH,vd.GameVariable.KILLCOUNT,vd.GameVariable.SELECTED_WEAPON_AMMO]);game.init()
 windows=[]
 for _ in range(250):
  windows=[]
  for w in d.screen().root.query_tree().children:
   try:
    title=w.get_wm_name()
    if title and 'DOOM' in title.upper() and w.get_attributes().map_state==X.IsViewable:windows.append(w)
   except error.BadWindow:pass
  if len(windows)==1:break
  if len(windows)>1:raise RuntimeError('ambiguous game window')
  time.sleep(.02)
 if len(windows)!=1:raise RuntimeError('game window unavailable')
 w=windows[0];d.set_input_focus(w.id,X.RevertToParent,X.CurrentTime);d.sync();time.sleep(.5)
 owner=GuardedSessionOwner({'app':w.id},out/'owner',':153',process_identity=True,query_worker=True);owner.get();bridge=owner.bridge;obs=bridge.observe();geom=obs['pointer_binding']['geometry'];point=[geom[0]+44,geom[1]+geom[3]-54];mint=bridge.mint_reference('game',obs['sequence'],point,region_size=(24,38));record['observation']=obs;record['mint']=mint
 def sample(label):
  game.advance_action(1,True)
  from PIL import Image
  g=w.get_geometry();capture_start=time.monotonic_ns();raw=w.get_image(0,0,g.width,g.height,X.ZPixmap,0xffffffff);capture_end=time.monotonic_ns();frame=Image.frombytes('RGB',(g.width,g.height),raw.data,'raw','BGRX');frame_path=out/('frame-%03d.png'%len(record['samples']));frame.save(frame_path)
  s={'frame':frame_path.name,'frame_sha256':hashlib.sha256(frame_path.read_bytes()).hexdigest(),'capture_start_ns':capture_start,'capture_end_ns':capture_end,'label':label,'host_ns':time.monotonic_ns(),'tic':game.get_episode_time(),'x':game.get_game_variable(vd.GameVariable.POSITION_X),'y':game.get_game_variable(vd.GameVariable.POSITION_Y),'ammo':game.get_game_variable(vd.GameVariable.SELECTED_WEAPON_AMMO),'health':game.get_game_variable(vd.GameVariable.HEALTH),'kills':game.get_game_variable(vd.GameVariable.KILLCOUNT),'finished':game.is_episode_finished()};record['samples'].append(s);(out/'samples.jsonl').open('a').write(json.dumps(s)+'\n');return s
 before=sample('before');owner.dispatch_attempted=True
 if route=='cancel':tail=[{'op':'key_state','key':'f','down':True},{'op':'wait_update','timeout_ms':500},{'op':'key_state','key':'f','down':False}]
 elif route=='wait':tail=[]
 else:raise RuntimeError('unknown route')
 if route=='wait':
  time.sleep(.05);action={'status':'withheld','input_dispatched':False}
 else:
  outcome=[];errors=[]
  def fire():
   try:
    with bridge.cancellation_scope('effect-token'):
     outcome.append(bridge.keyboard('game',mint['offset'],tail=tail,expires_at_ns=time.monotonic_ns()+4_000_000_000))
   except BaseException as e:errors.append(repr(e))
  t=threading.Thread(target=fire);t.start();code=d.keysym_to_keycode(XK.string_to_keysym('f'));until=time.monotonic()+2;held=False
  while time.monotonic()<until and t.is_alive():
   keys=d.query_keymap()
   if keys[code//8]&(1<<(code%8)):held=True;break
   time.sleep(.002)
  record['monitor']={'held_observed':held,'held_ns':time.monotonic_ns()}
  if held:
   time.sleep(.05);record['monitor']['cancel_requested_ns']=time.monotonic_ns();record['monitor']['cancel']=bridge.request_cancel('effect-token')
  t.join(4)
  if t.is_alive() or errors or not outcome:raise RuntimeError('cancellation worker failed '+repr(errors))
  action=outcome[0]
 record['action']=action;(out/'action.json').write_text(json.dumps(action,indent=2)+'\n')
 after=sample('after');deadline=time.monotonic()+0.7
 while time.monotonic()<deadline and not game.is_episode_finished():time.sleep(.015);sample('coast')
 record['displacement']=math.dist([before['x'],before['y']],[after['x'],after['y']]);record['health_delta']=record['samples'][-1]['health']-before['health'];record['kill_delta']=record['samples'][-1]['kills']-before['kills']
 record['close']=owner.close();owner=None;keycode=d.keysym_to_keycode(XK.string_to_keysym('f'));keys=d.query_keymap();record['w_down_after']=bool(keys[keycode//8]&(1<<(keycode%8)));record['status']='completed' if action.get('status') in ('execution_failed','withheld') else 'action_not_completed'
except BaseException as e:record['status']='error';record['error']=repr(e);(out/'traceback.txt').write_text(traceback.format_exc())
finally:
 if owner is not None:
  try:record['finally_close']=owner.close()
  except BaseException as e:record['close_error']=repr(e)
 if game is not None:
  try:game.close()
  except BaseException as e:record['game_close_error']=repr(e)
 if d is not None:d.close()
 if x is not None and x.poll() is None:
  try:os.killpg(x.pid,signal.SIGTERM);x.wait(timeout=3)
  except BaseException as e:record['xvfb_close_error']=repr(e)
 (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')

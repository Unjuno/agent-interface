set -u
out=/home/user/chromium-separated-x-20261127-r01
mount -t tmpfs -o mode=1777 tmpfs /tmp || exit 90
mkdir -m 1777 /tmp/.X11-unix
ip link set lo up || exit 91
mkdir -m 700 "$out/home" "$out/xdg"
export HOME="$out/home" XDG_RUNTIME_DIR="$out/xdg" DISPLAY=:88
export LD_LIBRARY_PATH=/home/user/.cache/agent-interface-live-caller-20261021/linux-libs/rootfs/usr/lib/x86_64-linux-gnu
export AGENT_INTERFACE_MCP_XVFB_TRACKED_DELAYED_SECOND_PRESS=1
export AGENT_INTERFACE_MCP_XVFB_SOCKET_DELIVERY_DELAY=1
export AGENT_INTERFACE_MCP_XVFB_DELAY_MS=3000
export AGENT_INTERFACE_MCP_XVFB_PROXY_DISPLAY=127.0.0.1:89
export AGENT_INTERFACE_MCP_XVFB_PROXY_CONTROL=/tmp/ai-chromium-proxy.sock
Xvfb :88 -screen 0 1280x800x24 -ac -listen tcp >"$out/xvfb-old.log" 2>&1 &
old_x=$!
Xvfb :90 -screen 0 1280x800x24 -ac -nolisten tcp >"$out/xvfb-fresh.log" 2>&1 &
fresh_x=$!
proxy_pid=
cleanup() { [ -z "$proxy_pid" ] || kill "$proxy_pid" 2>/dev/null || true; kill "$old_x" "$fresh_x" 2>/dev/null || true; [ -z "$proxy_pid" ] || wait "$proxy_pid" 2>/dev/null || true; wait "$old_x" 2>/dev/null || true; wait "$fresh_x" 2>/dev/null || true; }
trap cleanup EXIT
for i in $(seq 1 100); do [ -S /tmp/.X11-unix/X88 ] && [ -S /tmp/.X11-unix/X90 ] && break; sleep .05; done
[ -S /tmp/.X11-unix/X88 ] && [ -S /tmp/.X11-unix/X90 ] || exit 92
DISPLAY=:88 openbox >"$out/openbox-old.log" 2>&1 &
DISPLAY=:90 openbox >"$out/openbox-fresh.log" 2>&1 &
for i in $(seq 1 100); do DISPLAY=:88 wmctrl -m >/dev/null 2>&1 && DISPLAY=:90 wmctrl -m >/dev/null 2>&1 && break; sleep .05; done
DISPLAY=:88 wmctrl -m >"$out/wm-old.txt" || exit 93
DISPLAY=:90 wmctrl -m >"$out/wm-fresh.txt" || exit 93
/home/user/.venvs/agent-interface-goal/bin/python "$out/proxy.py" --listen-port 6089 --upstream-host 127.0.0.1 --upstream-port 6088 --control-path /tmp/ai-chromium-proxy.sock --ready-path "$out/proxy-ready.json" --events-path "$out/proxy-events.jsonl" >"$out/proxy.log" 2>&1 &
proxy_pid=$!
for i in $(seq 1 100); do [ -s "$out/proxy-ready.json" ] && break; sleep .05; done
[ -s "$out/proxy-ready.json" ] || exit 95
cd /home/user/agent-durable-capacity-20261127 || exit 94
PYTHONPATH=. /home/user/.venvs/agent-interface-goal/bin/python "$out/experiment.py" >"$out/probe.log" 2>&1
rc=$?
printf '%s\n' "$rc" >"$out/experiment-exit-code.txt"
exit "$rc"

import asyncio
import json
import os
from pathlib import Path
import signal
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs

from PIL import Image
from Xlib import X, XK, display
from Xlib.ext import xtest
from runtime.cli_v1.mcp_server import create_server
from runtime.cli_v1.test_mcp_xvfb_blocked_release_integration import _xvfb_blocking_owner_factory

OUT = Path('/home/user/chromium-separated-x-20261127-r01')
BROWSER = '/home/user/.cache/agent-interface-live-caller-20261021/browsers/chromium-1248/chrome-linux64/chrome'
PAGE = '''<!doctype html><title>AGENT TASK {which}</title>
<style>body{{margin:0;background:#e7eef6;font:22px sans-serif}}
.anchor{{position:absolute;left:40px;top:40px;width:80px;height:80px;
background:linear-gradient(90deg,#125783 50%,#fb7a11 50%)}}
form{{position:absolute;left:155px;top:65px}}input{{font:24px sans-serif}}</style>
<div class="anchor"></div><form><label>Value <input id="value" autofocus></label></form>
<script>document.getElementById('value').addEventListener('input', e => fetch('/effect',
{{method:'POST',headers:{{'Content-Type':'application/x-www-form-urlencoded'}},
body:new URLSearchParams({{which:'{which}',value:e.target.value}})}}));</script>'''

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args): pass
    def do_GET(self):
        which = self.path.strip('/')
        if which not in ('old', 'fresh'):
            self.send_error(404); return
        data = PAGE.format(which=which).encode()
        self.send_response(200); self.send_header('Content-Type', 'text/html')
        self.send_header('Content-Length', str(len(data))); self.end_headers(); self.wfile.write(data)
    def do_POST(self):
        body = self.rfile.read(int(self.headers.get('Content-Length', '0'))).decode('ascii')
        row = {'path': self.path, 'body': parse_qs(body), 'monotonic_ns': time.monotonic_ns()}
        with (OUT/'history.jsonl').open('a', encoding='utf8') as stream:
            stream.write(json.dumps(row)+'\n'); stream.flush(); os.fsync(stream.fileno())
        self.send_response(204); self.end_headers()

def save(name, row):
    (OUT/name).write_text(json.dumps(row, indent=2)+'\n', encoding='utf8')

def history():
    path = OUT/'history.jsonl'
    return [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []

async def wait_for(predicate, seconds, label):
    end = time.monotonic()+seconds
    while time.monotonic()<end:
        value=predicate()
        if value: return value
        await asyncio.sleep(.02)
    raise TimeoutError(label)

def launch_browser(which, port):
    error=(OUT/(which+'-chromium.stderr')).open('wb')
    process=subprocess.Popen([BROWSER,'--no-sandbox','--disable-gpu','--disable-dev-shm-usage',
        '--no-first-run','--no-default-browser-check','--user-data-dir='+str(OUT/(which+'-profile')),
        '--window-size=800,600','--window-position=0,0','--app=http://127.0.0.1:%d/%s'%(port,which)],
        stdout=subprocess.DEVNULL,stderr=error,start_new_session=True,
        env={**os.environ,'DISPLAY':':90' if which=='fresh' else ':88'})
    return process,error

def window_id(which, process):
    if process.poll() is not None: raise RuntimeError(which+' browser exited')
    output=subprocess.run(['wmctrl','-lp'], capture_output=True,text=True,check=True,
                          env={**os.environ,'DISPLAY':':90' if which=='fresh' else ':88'}).stdout
    matches=[line for line in output.splitlines() if 'AGENT TASK '+which in line]
    if len(matches)>1: raise RuntimeError('ambiguous '+which+' window')
    return int(matches[0].split()[0],16) if matches else None

def anchor_point(artifact, label):
    image=Image.open(artifact['path']).convert('RGB')
    image.save(OUT/(label+'-observation.png'))
    mask=image.point(lambda p:p)  # Preserve original capture; scan only exact fixture colour.
    pixels=mask.load(); points=[]
    for y in range(image.height):
        for x in range(image.width):
            if pixels[x,y] == (18,87,131): points.append((x,y))
    if len(points)<300: raise RuntimeError(label+' anchor colour not found')
    left=min(x for x,y in points); right=max(x for x,y in points)
    top=min(y for x,y in points); bottom=max(y for x,y in points)
    if not (30<=right-left<=50 and 70<=bottom-top<=90):
        raise RuntimeError(label+' anchor geometry unexpected')
    return [right+1,(top+bottom)//2]

def meta(response): return json.loads(response.content[0].text)

async def call(server, name, args, label):
    result=meta(await asyncio.wait_for(server.call_tool(name,args),15))
    save(label+'.json', result)
    return result

async def mint(server,label):
    observed=await call(server,'interface_guarded_observe',{},label+'-observe')
    if observed.get('status')!='observed': raise RuntimeError(label+' observe failed')
    artifact=observed['observation_report']['observation']['artifact']
    point=anchor_point(artifact,label)
    result=await call(server,'interface_guarded_mint',{'alias':'anchor',
        'source_sequence':observed['source']['sequence'],'point':point,
        'region_size':[24,24]},label+'-mint')
    if result.get('status')!='minted': raise RuntimeError(label+' mint failed')
    return result

def keys_down(observer):
    state=observer.query_keymap(); result={}
    for name in ('a','b','c'):
        code=observer.keysym_to_keycode(XK.string_to_keysym(name))
        result[name]=bool(state[code//8] & (1<<(code%8)))
    return result

async def experiment(port, report):
    browsers=[]; servers=[]; observer=display.Display(':88'); fresh_observer=display.Display(':90'); pending=None; cancelled=False
    try:
        old,err=launch_browser('old',port);browsers.append((old,err))
        old_id=await wait_for(lambda:window_id('old',old),15,'old window')
        subprocess.run(['wmctrl','-ia',hex(old_id)],check=True);await asyncio.sleep(.4)
        old_server=create_server({'app':old_id},OUT/'old-mcp',display_name='127.0.0.1:89',session_mode='guarded-x11',
            guarded_process_identity=True,guarded_query_worker=True,guarded_window_lifecycle=True,
            guarded_owned_process=True,guarded_prestarted_cancel_supervisor=False,
            _guarded_cancel_transaction_timeout_s=4.0,_guarded_owner_factory=_xvfb_blocking_owner_factory)
        servers.append(('old',old_server)); old_mint=await mint(old_server,'old')
        pending=await call(old_server,'interface_guarded_input',{'alias':'anchor','offset':old_mint['offset'],
            'interaction':'keyboard','observe_after':False,'wait_for_result_ms':0,
            'tail':[{'op':'key_chord','keys':['a']},{'op':'key_chord','keys':['a']}]},'old-pending')
        if pending.get('status')!='pending':raise RuntimeError('old input not pending')
        await wait_for(lambda:(OUT/'old-mcp'/'xvfb-owner-sync-entered.json').exists(),5,'blocked owner')
        await wait_for(lambda:len(history())>=1,5,'old input effect')
        report['history_before_cancel']=history();report['keys_before_cancel']=keys_down(observer)
        cancel_start=time.monotonic_ns()
        report['cancel_response']=await call(old_server,'interface_guarded_cancel',{'call_id':pending['call_id']},'cancel')
        cancelled=True
        async def cancellation_terminal():
            row=meta(await old_server.call_tool('interface_results',{'call_id':pending['call_id'],'include_image':False}))
            value=row.get('cancellation')
            return value if isinstance(value,dict) and value.get('status') in ('completed','unknown') else None
        end=time.monotonic()+6;terminal=None
        while time.monotonic()<end:
            terminal=await cancellation_terminal()
            if terminal: break
            await asyncio.sleep(.05)
        report['cancellation_terminal']=terminal;report['keys_after_cancel']=keys_down(observer)
        fresh,err=launch_browser('fresh',port);browsers.append((fresh,err))
        fresh_id=await wait_for(lambda:window_id('fresh',fresh),15,'fresh window')
        subprocess.run(['wmctrl','-ia',hex(fresh_id)],check=True,env={**os.environ,'DISPLAY':':90'});await asyncio.sleep(.4)
        fresh_server=create_server({'app':fresh_id},OUT/'fresh-mcp',display_name=':90',session_mode='guarded-x11',
            guarded_process_identity=True,guarded_query_worker=True,guarded_window_lifecycle=True,
            guarded_owned_process=True)
        servers.append(('fresh',fresh_server));fresh_mint=await mint(fresh_server,'fresh')
        fresh_result=await call(fresh_server,'interface_guarded_input',{'alias':'anchor',
            'offset':fresh_mint['offset'],'interaction':'keyboard','observe_after':False,
            'tail':[{'op':'key_chord','keys':['c']}]},'fresh-input')
        await wait_for(lambda:len(history())>=2,5,'fresh input effect')
        await asyncio.sleep(max(0,(cancel_start+8_500_000_000-time.monotonic_ns())/1e9))
        report['history_at_horizon']=history();report['keys_at_horizon']=keys_down(observer)
        report['fresh_keys_at_horizon']=keys_down(fresh_observer)
        report['horizon_ms']=(time.monotonic_ns()-cancel_start)/1e6
        fresh_effects=[x['body'] for x in report['history_at_horizon'] if x['body'].get('which')==['fresh']]
        old_effects=[x['body'] for x in report['history_at_horizon'] if x['body'].get('which')==['old']]
        report['fresh_isolation_pass']=(fresh_result.get('status')=='completed' and
            fresh_effects==[{'which':['fresh'],'value':['c']}] and
            not any(report['fresh_keys_at_horizon'].values()))
        report['old_task_exact']=(old_effects==[{'which':['old'],'value':['a']}])
        report['scoped_pass']=(terminal is not None and report['fresh_isolation_pass'] and
            all(x['path']=='/effect' for x in report['history_at_horizon']) and
            not any(report['keys_after_cancel'].values()) and
            not any(report['keys_at_horizon'].values()))
    finally:
        if pending is not None and not cancelled:
            try: report['fallback_cancel']=await call(servers[0][1],'interface_guarded_cancel',{'call_id':pending['call_id']},'fallback-cancel')
            except BaseException as error: report['fallback_cancel_error']=repr(error)
        for label,server in reversed(servers):
            try: report[label+'_close']=await call(server,'interface_close',{},label+'-close')
            except BaseException as error: report[label+'_close_error']=repr(error)
        report['keys_before_fixture_cleanup']=keys_down(observer)
        report['fresh_keys_before_fixture_cleanup']=keys_down(fresh_observer)
        for conn in (observer,fresh_observer):
            for name in ('a','b','c'):
                xtest.fake_input(conn,X.KeyRelease,conn.keysym_to_keycode(XK.string_to_keysym(name)))
            conn.sync()
        report['keys_after_fixture_cleanup']=keys_down(observer)
        report['fresh_keys_after_fixture_cleanup']=keys_down(fresh_observer)
        observer.close();fresh_observer.close()
        report['browser_exits']={}
        for process,error in browsers:
            if process.poll() is None and os.getpgid(process.pid)==process.pid:os.killpg(process.pid,signal.SIGTERM)
            try:process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                if os.getpgid(process.pid)==process.pid:os.killpg(process.pid,signal.SIGKILL)
                process.wait(timeout=5)
            report['browser_exits'][str(process.pid)]=process.returncode;error.close()

def main():
    http=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    thread=threading.Thread(target=http.serve_forever,daemon=True);thread.start()
    report={'status':'FAIL','source':'ac21495aa379cbed4eab291f964788b4685ce32d','model_calls':0}
    try:
        asyncio.run(experiment(http.server_port,report))
        report['status']='FRESH_ISOLATION_OBSERVED' if report.get('scoped_pass') else 'FAIL_ORACLE'
    except BaseException as error:
        report.update(error_type=type(error).__name__,error=str(error))
    finally:
        http.shutdown();http.server_close();thread.join(3)
        save('report.json',report);print(json.dumps(report,indent=2))
    if report['status']!='FRESH_ISOLATION_OBSERVED':raise SystemExit(1)

if __name__=='__main__': main()

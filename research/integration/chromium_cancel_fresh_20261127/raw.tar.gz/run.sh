set -u
out=/home/user/chromium-cancel-fresh-20261127-r01
mount -t tmpfs -o mode=1777 tmpfs /tmp || exit 90
mkdir -m 1777 /tmp/.X11-unix
ip link set lo up || exit 91
mkdir -m 700 "$out/home" "$out/xdg"
export HOME="$out/home" XDG_RUNTIME_DIR="$out/xdg" DISPLAY=:88
export LD_LIBRARY_PATH=/home/user/.cache/agent-interface-live-caller-20261021/linux-libs/rootfs/usr/lib/x86_64-linux-gnu
export AGENT_INTERFACE_MCP_XVFB_TRACKED_DELAYED_SECOND_PRESS=1
Xvfb :88 -screen 0 1280x800x24 -ac -nolisten tcp >"$out/xvfb.log" 2>&1 &
xpid=$!
trap 'kill "$xpid" 2>/dev/null || true; wait "$xpid" 2>/dev/null || true' EXIT
for i in $(seq 1 100); do [ -S /tmp/.X11-unix/X88 ] && break; sleep .05; done
[ -S /tmp/.X11-unix/X88 ] || exit 92
openbox >"$out/openbox.log" 2>&1 &
for i in $(seq 1 100); do wmctrl -m >/dev/null 2>&1 && break; sleep .05; done
wmctrl -m >"$out/wm.txt" || exit 93
cd /home/user/agent-durable-capacity-20261127 || exit 94
PYTHONPATH=. /home/user/.venvs/agent-interface-goal/bin/python "$out/experiment.py" >"$out/probe.log" 2>&1
rc=$?
printf '%s\n' "$rc" >"$out/experiment-exit-code.txt"
exit "$rc"

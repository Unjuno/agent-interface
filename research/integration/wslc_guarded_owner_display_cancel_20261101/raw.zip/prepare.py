import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parent
files=[p for p in (root/'src').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']+[root/'trial.py',root/'target.py',root/'run.py',root/'prepare.py']
manifest={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
arms=[('guarded-j01','retire'),('guarded-j02','resume')]
for ident,mode in arms:
 p=root/ident;p.mkdir(exist_ok=False);(p/'output').mkdir()
 c={'allocation':'xvfb-guarded-'+ident+'-20261101','mode':mode,'order':[f'{i}:{m}' for i,m in arms],
    'base_main':'a2577208ef2bda3287aa687becad88d0a71aa149','draft_head':'93ef7f4321b94ef83cdbea472cba7e85f51cfb78',
    'image':'sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25',
    'manifest_sha256':hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest(),
    'intervention':'draft PrivateDisplayOwner launches authenticated server; actual guarded owner presses a and is blocked by fixture; stop and cancel; retire and replace or resume; control fixture releases a; fresh client holds b, old client attempts stale b release, inspect b state, fixture releases if needed; fresh guarded a task',
    'criteria':'guarded old a effect and hold observed; cancellation UNKNOWN without replay; replaced display neutral versus resumed display retains a; stale release cannot clear fresh b on replaced display but does clear b on shared display; fresh guarded a task effect and release verified',
    'stop':'one try per arm; preserve all failures; stop block on unresolved input or infrastructure failure',
    'limits':'test-injected owner pause and stale release; no natural hang, queued old request, production display integration, hard deadline or MAP01 claim'}
 (p/'conditions.json').write_text(json.dumps(c,indent=2)+'\n')
print('two arms frozen')

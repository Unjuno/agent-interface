import hashlib,io,json,subprocess,time
from pathlib import Path
from PIL import Image,ImageOps
from crop_pair_cue import classify
root=Path('/in');out=Path('/out');report=[]
for name in ('valid','wrong','blank'):
 image=Image.open(root/(name+'.png')).convert('RGB');assert image.size==(1280,800);rows=[];texts=[]
 for label,box in [('A1',(95,144,126,159)),('A2',(95,161,126,176))]:
  crop=image.crop(box);crop.putdata([(255,255,255) if b>r+30 and b>g+20 else (r,g,b) for r,g,b in crop.getdata()]);crop=crop.convert('L').resize(((box[2]-box[0])*4,(box[3]-box[1])*4),Image.Resampling.LANCZOS);crop=ImageOps.expand(crop,border=16,fill=255);buf=io.BytesIO();crop.save(buf,format='PNG');payload=buf.getvalue();(out/(name+'-'+label+'.png')).write_bytes(payload)
  command=['tesseract','stdin','stdout','--psm','7','-c','tessedit_char_whitelist=0123456789','tsv'];start=time.monotonic_ns()
  try:
   r=subprocess.run(command,input=payload,capture_output=True,timeout=1,check=False);stdout=r.stdout;stderr=r.stderr;entry={'cell':label,'returncode':r.returncode,'timeout':False,'elapsed_ms':(time.monotonic_ns()-start)/1e6,'crop_sha256':hashlib.sha256(payload).hexdigest()}
  except subprocess.TimeoutExpired as e:
   stdout=e.stdout or b'';stderr=e.stderr or b'';entry={'cell':label,'returncode':None,'timeout':True,'elapsed_ms':(time.monotonic_ns()-start)/1e6,'crop_sha256':hashlib.sha256(payload).hexdigest()}
  (out/(name+'-'+label+'.tsv')).write_bytes(stdout);(out/(name+'-'+label+'.stderr')).write_bytes(stderr);texts.append(stdout.decode('utf-8',errors='replace'));rows.append(entry)
 cue=classify(*texts) if all(x['returncode']==0 and not x['timeout'] for x in rows) else 'unknown';report.append({'case':name,'cue':cue,'attempts':rows})
result={'cases':report,'pass':report[0]['cue']=='filled' and all(x['cue']!='filled' for x in report[1:]),'scope':'offline OCR of retained screenshots; no input authority'};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(0 if result['pass'] else 1)

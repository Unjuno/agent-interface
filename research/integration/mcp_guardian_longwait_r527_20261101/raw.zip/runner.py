import hashlib,json,os,select,signal,subprocess,sys,time
from pathlib import Path

out=Path('/out');owned=[];parents=[];arms=[];status='ERROR'
sentinel=subprocess.Popen([sys.executable,'-c','import time;time.sleep(30)'])
sentinel_fd=os.pidfd_open(sentinel.pid)
def exited(fd,ms=0):
    p=select.poll();p.register(fd,select.POLLIN);return bool(p.poll(ms))
try:
    for mode in ('baseline_timeout','persistent_wait'):
        folder=out/mode;folder.mkdir();started=time.monotonic_ns()
        err=(folder/'parent-stderr.txt').open('wb')
        parent=subprocess.Popen([sys.executable,'/fixture/parent.py',mode],stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,stderr=err);parents.append((parent,err))
        ready,_,_=select.select([parent.stdout],[],[],16)
        if not ready:raise TimeoutError('parent readiness '+mode)
        line=parent.stdout.readline().decode();identity=json.loads(line)
        (folder/'parent-stdout.txt').write_text(line)
        fds={}
        for role in ('owner','supervisor','guardian','display'):
            fd=os.pidfd_open(identity[role+'_pid']);owned.append((mode+'-'+role,fd));fds[role]=fd
        alive_before={'owner':not exited(fds['owner']),'supervisor':not exited(fds['supervisor']),
                      'guardian':not exited(fds['guardian']),'parent':parent.poll() is None}
        parent.stdin.write(b'X');parent.stdin.flush();parent.stdin.close();parent.wait(timeout=8)
        elapsed=(time.monotonic_ns()-started)/1e6
        after_parent_exit={'owner_alive':not exited(fds['owner']),
            'supervisor_alive':not exited(fds['supervisor']),'guardian_alive':not exited(fds['guardian']),
            'observed_ns':time.monotonic_ns()}
        if parent.returncode!=0:raise RuntimeError('parent failed '+mode)
        request=json.loads((folder/'handoff-request.json').read_text())
        checks={'old_press':identity['old_press_observed'] is True,
            'old_key_down':identity['old_key_down'] is True,'old_action_pending':identity['action_pending'] is True,
            'guardian_prestarted':identity['guardian_ready_ns']<identity['action_started_ns'],
            'cancel_pending':identity['cancel_response']['status']=='pending',
            'gate_token':request['gate_token']==identity['action_call_id'],
            'operation_id':request['operation_id']==identity['cancel_response']['operation_id'],
            'owner_alive_before_exit':alive_before['owner'],'supervisor_alive_before_exit':alive_before['supervisor'],
            'display_alive':not exited(fds['display']),'sentinel_alive':not exited(sentinel_fd),
            'parent_bounded':elapsed<16000,'parent_alive_before_exit':alive_before['parent']}
        receipt_path=folder/'guardian-receipt.json';prepared=folder/'custody-prepared.json';receipt=None
        if mode=='baseline_timeout':
            raw=prepared.read_bytes();digest=hashlib.sha256(raw).hexdigest()
            guardian_stderr=(folder/'guardian-stderr.txt').read_text()
            checks.update(decision_accepted=identity['decision']=='accepted',
                prepared_matches=json.loads(raw)==request and digest==identity['ack_digest'],
                guardian_exited_while_parent_alive=not alive_before['guardian'],
                timeout_reported='parent exit not observed after commit' in guardian_stderr,
                receipt_absent=not receipt_path.exists())
        else:
            end=time.monotonic()+8
            while not receipt_path.exists() and time.monotonic()<end:time.sleep(.01)
            if not receipt_path.exists():raise TimeoutError('guardian receipt '+mode)
            receipt=json.loads(receipt_path.read_text())
            if mode=='persistent_wait':
                rows={r['role']:r for r in receipt['rows']};raw=prepared.read_bytes()
                digest=hashlib.sha256(raw).hexdigest()
                checks.update(decision_expected=identity['decision']=='accepted' and identity['commit_sent'] is True,
                    durable_record_matches=json.loads(raw)==request and digest==identity['ack_digest']==receipt['record_sha256'],
                    receipt_identity=receipt['token']==identity['token'] and rows['owner']['pid']==identity['owner_pid'] and rows['supervisor']['pid']==identity['supervisor_pid'],
                    guardian_commit=receipt.get('commit_received') is True,
                    parent_exit_confirmed=receipt.get('parent_exit_observed') is True and receipt.get('parent_pid')==identity['parent_pid']==parent.pid,
                    ack_expected=receipt.get('ack_sent') is True,
                    guardian_alive_before_parent_exit=alive_before['guardian'],
                    observed_hold_over_six_seconds=identity['parent_preexit_ns']-receipt.get('ack_done_ns',0)>=6_500_000_000,
                    owner_exit=rows['owner']['signal_sent'] and rows['owner']['exit_observed'] and exited(fds['owner']),
                    supervisor_exit=rows['supervisor']['signal_sent'] and rows['supervisor']['exit_observed'] and exited(fds['supervisor']))
            else:
                raw=prepared.read_bytes();digest=hashlib.sha256(raw).hexdigest()
                checks.update(decision_unknown=identity['decision']=='commit_unknown' and identity['commit_attempted'] is True
                        and identity['commit_sent'] is False,
                    prepared_matches=json.loads(raw)==request and digest==identity['ack_digest']==receipt.get('record_sha256'),
                    uncommitted=receipt.get('status')=='uncommitted' and receipt.get('token')==identity['token']
                        and receipt.get('signal_sent') is False and receipt.get('decision_kind') in ('eof','connection_reset'))
        arms.append({'mode':mode,'identity':identity,'parent_elapsed_ms':elapsed,'alive_before_exit':alive_before,
                     'after_parent_exit':after_parent_exit,'request':request,'receipt':receipt,'checks':checks})
        if not all(checks.values()):raise AssertionError(mode+' failed checks')
    status='PASS'
except BaseException as error:
    arms.append({'error':repr(error)})
finally:
    for parent,err in parents:
        if parent.poll() is None:parent.kill();parent.wait(timeout=3)
        err.close()
    cleanup=[]
    for role,fd in owned+[('sentinel',sentinel_fd)]:
        if not exited(fd):
            try:signal.pidfd_send_signal(fd,signal.SIGKILL)
            except ProcessLookupError:pass
        dead=exited(fd,3000);cleanup.append({'role':role,'exit_observed':dead});os.close(fd)
    sentinel.wait(timeout=3)
    if not all(x['exit_observed'] for x in cleanup):status='ERROR'
    (out/'result.json').write_text(json.dumps({'status':status,'arms':arms,'cleanup':cleanup},indent=2)+'\n')
    print(json.dumps({'status':status,'arms':len(arms)}),flush=True)
sys.exit(0 if status=='PASS' else 1)

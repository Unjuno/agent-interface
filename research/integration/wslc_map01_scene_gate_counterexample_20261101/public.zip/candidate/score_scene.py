"""Exploratory scene-MAD gate; labels are used only by the base scorer."""
from pathlib import Path
from PIL import Image
import json,subprocess,sys
import numpy as np
root=Path(sys.argv[1]);base=json.loads(subprocess.run([sys.executable,str(Path(__file__).with_name("score.py")),str(root)],capture_output=True,text=True,check=True).stdout)
if base["status"]!="completed":print(json.dumps(base));sys.exit(0)
source=np.asarray(Image.open(root/"frame-00.png").convert("RGB"),dtype=np.int16)[60:380:4,40:600:4]
for row in base["rows"]:
 current=np.asarray(Image.open(root/("frame-%02d.png"%row["index"])).convert("RGB"),dtype=np.int16)[60:380:4,40:600:4]
 mad=float(np.abs(current-source).mean());baseline=row["fixed"];row["scene_mad"]=mad;row["scene_gated"]={"point":baseline["point"] if mad<=18 else None,"outcome":baseline["outcome"] if mad<=18 else "abstained"}
print(json.dumps(base,indent=2,sort_keys=True))

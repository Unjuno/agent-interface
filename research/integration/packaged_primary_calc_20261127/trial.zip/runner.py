"""One isolated, zero-model Calc smoke through the portable zipapp CLI."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time
import traceback
import xml.etree.ElementTree as ET
from Xlib import X, display
from PIL import Image

OUT=Path('/out');INPUT=Path('/input')
FIXTURE='462beebbcb020ccf49af3cc49520f789a816cc3fb97597cefbd6940ffc26aeb1'
ZIP='c6dfe3010a35ea5839baebb21faa487559b99cfc5f840fc15a1434b46bb4d394'
NAMEBOX='2e86f3a0f6d87ee4fb4e5ffeb7cfd159d715cb5f6f8177b0ede83784d49088cf'
result={'schema':'packaged-primary-task-v1','passed':False,'model_calls':0,
        'input_attempted':False,'scope':'scripted packaged primary Calc input and save'}
actors=[];streams=[];connection=None


def save(name,value):
    with (OUT/name).open('x',encoding='utf-8') as f:
        json.dump(value,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())


def spawn(name,args,env):
    stream=(OUT/(name+'.log')).open('xb');streams.append(stream)
    proc=subprocess.Popen(args,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    actors.append(proc);return proc


def cli(name,args,env):
    proc=subprocess.run(['/usr/bin/python3','/input/agent-interface-runtime.pyz',*args],
                        env=env,capture_output=True,text=True,timeout=20)
    (OUT/(name+'.stdout')).write_text(proc.stdout);(OUT/(name+'.stderr')).write_text(proc.stderr)
    save(name+'-process.json',{'exit_code':proc.returncode})
    if proc.returncode!=0:raise RuntimeError(name+' CLI failed')
    return json.loads(proc.stdout)


def neutral():
    bits=connection.query_keymap();mask=connection.screen().root.query_pointer().mask
    return {'keys_down':[i for i in range(256) if bits[i//8] & (1<<(i%8))],
            'buttons_mask':mask & (X.Button1Mask|X.Button2Mask|X.Button3Mask|X.Button4Mask|X.Button5Mask)}


try:
    if hashlib.sha256((INPUT/'blank.fods').read_bytes()).hexdigest()!=FIXTURE:raise ValueError('fixture differs')
    if hashlib.sha256((INPUT/'runtime.pyz').read_bytes()).hexdigest()!=ZIP:raise ValueError('zipapp differs')
    env=dict(os.environ,DISPLAY=':153',HOME='/tmp',SAL_USE_VCLPLUGIN='gen')
    shutil.copyfile(INPUT/'blank.fods','/tmp/blank.fods')
    spawn('xvfb',['Xvfb',':153','-screen','0','1280x800x24','-nolisten','tcp','-ac'],env)
    for _ in range(100):
        try:connection=display.Display(':153');break
        except Exception:time.sleep(.05)
    if connection is None:raise RuntimeError('Xvfb unavailable')
    spawn('openbox',['openbox','--sm-disable'],env)
    calc=spawn('calc',['libreoffice','-env:UserInstallation=file:///tmp/zipapp-profile','--calc','--nologo',
                       '--norestore','--nofirststartwizard','/tmp/blank.fods'],env)
    def walk(window,depth=0):
        if depth>6:return []
        rows=[]
        for child in window.query_tree().children:
            try:
                title=child.get_wm_name();title=title.decode(errors='replace') if isinstance(title,bytes) else str(title or '')
                rows.append((child.id,title,child.get_attributes().map_state));rows.extend(walk(child,depth+1))
            except Exception:pass
        return rows
    deadline=time.monotonic()+25;found=[]
    while time.monotonic()<deadline:
        found=[row for row in walk(connection.screen().root) if 'blank.fods' in row[1].lower() and 'calc' in row[1].lower() and row[2]==X.IsViewable]
        if len(found)==1:break
        if len(found)>1 or calc.poll() is not None:raise RuntimeError('Calc target ambiguous or exited')
        time.sleep(.05)
    if len(found)!=1:raise RuntimeError('Calc target unavailable')
    time.sleep(1);save('target.json',{'id':found[0][0],'title':found[0][1]})
    save('targets.json',{'app':found[0][0]})
    import select
    config={'host':{'command':'/usr/bin/python3','args':['/input/runtime.pyz','relay','--','--targets','/out/targets.json','--output-directory','/out/server','--session-mode','guarded-x11','--display',':153'],'evidenceDirectory':'/out/host-evidence'},'route':'guarded-local','exchangeDirectory':'/out/exchange'}
    save('config.json',config)
    err=(OUT/'primary.stderr').open('xb'); streams.append(err)
    proc=subprocess.Popen(['/usr/local/bin/node','/input/host/primary_stdio.mjs','--config','/out/config.json'],env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,start_new_session=True,bufsize=0)
    actors.append(proc); records=[]
    def receive():
        buf=bytearray(); deadline=time.monotonic()+30
        while not buf.endswith(b'\n'):
            left=deadline-time.monotonic()
            if left<=0 or not select.select([proc.stdout],[],[],left)[0]: raise TimeoutError('primary response timeout')
            b=os.read(proc.stdout.fileno(),1)
            if not b: raise RuntimeError('primary stdout closed')
            buf.extend(b)
            if len(buf)>2_000_000:raise RuntimeError('primary output too large')
        row=json.loads(buf);records.append(row);save('line-%d.json'%len(records),row);return row
    def send(row):
        proc.stdin.write((json.dumps(row,separators=(',',':'))+'\n').encode());proc.stdin.flush()
    if receive().get('status')!='ready':raise ValueError('primary not ready')
    send({'id':1,'method':'observe','args':[]})
    observed=receive()
    if observed.get('status')!='returned':raise ValueError('observe failed')
    img=OUT/'exchange/image-1-1.png'
    with Image.open(img) as im:
        if hashlib.sha256(im.convert('RGB').crop((0,97,42,119)).tobytes()).hexdigest()!=NAMEBOX:raise ValueError('A1 fixture cue mismatch')
    def command(i,method,args):
        send({'id':i,'method':method,'args':args}); row=receive()
        if row.get('status')!='returned':raise ValueError(method+' failed: '+str(row.get('status')))
        if row.get('result',{}).get('caller_state',{}).get('stopped') is not None:raise ValueError(method+' stopped caller')
        return row
    attribution={'task':'calc-271','phase':'initial','reason':'Inspected original image by exact hash of fixture-specific A1 name box and observed selected A1.'}
    command(2,'review',[1,attribution])
    command(3,'mint',['cell',1,[80,150],[24,14]])
    command(4,'acknowledgeText',[2,{'task':'calc-271','phase':'mint','reason':'Read original registration response for cell alias.'}])
    tail=[{'op':'text','text':'271'},{'op':'key_chord','keys':['ENTER']},{'op':'wait_update','timeout_ms':300},{'op':'key_chord','keys':['CTRL','s']}]
    result['input_attempted']=True
    command(5,'input',['cell',[12,7],'keyboard',tail])
    saved=Path('/tmp/blank.fods'); deadline=time.monotonic()+5
    while time.monotonic()<deadline and hashlib.sha256(saved.read_bytes()).hexdigest()==FIXTURE:time.sleep(.05)
    data=saved.read_bytes();(OUT/'saved.fods').write_bytes(data)
    ns={'t':'urn:oasis:names:tc:opendocument:xmlns:table:1.0','o':'urn:oasis:names:tc:opendocument:xmlns:office:1.0'}
    cell=ET.fromstring(data).find('.//t:table/t:table-row/t:table-cell',ns)
    if cell is None or cell.get('{'+ns['o']+'}value')!='271' or cell.get('{'+ns['t']+'}formula') is not None:raise ValueError('saved A1 differs')
    result['saved_sha256']=hashlib.sha256(data).hexdigest()
    command(6,'call',['interface_close',{}])
    proc.stdin.close()
    if receive().get('status')!='terminal':raise ValueError('terminal missing')
    proc.wait(timeout=10)
    if proc.returncode!=0:raise ValueError('primary exit failed')
    state=neutral();save('final-neutral.json',state)
    if state!={'keys_down':[],'buttons_mask':0}:raise ValueError('X input not neutral')
    result.update(passed=True,primary_exit=proc.returncode)
except Exception as error:
    result.update(passed=False,error_type=type(error).__name__,error=str(error))
    (OUT/'traceback.txt').write_text(traceback.format_exc())
finally:
    if connection is not None:
        try:save('final-observed-neutral.json',neutral());connection.close()
        except Exception as error:result.update(passed=False,neutral_error=type(error).__name__)
    for proc in reversed(actors):
        if proc.poll() is None:
            try:os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=3)
            except Exception:
                try:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=3)
                except Exception as error:result.update(passed=False,process_cleanup_error=type(error).__name__)
    for stream in streams:stream.close()
    save('result.json',result)

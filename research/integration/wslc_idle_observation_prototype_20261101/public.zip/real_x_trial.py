"""One isolated Xvfb trial of the local idle-observation prototype."""
import json, os, pathlib, signal, subprocess, sys, time, traceback
from Xlib import X, display
from runtime.guarded_x11_v1.bridge import NativeHandleBridge
from runtime.backends.x11_v1.backend import X11BackendError

out=pathlib.Path('/out'); out.mkdir(exist_ok=True)
result={'status':'started','display':':193','test':'healthy capture then private Xvfb stopped across 300ms idle capture deadline'}
server=None; connection=None; bridge=None
try:
 server=subprocess.Popen(['Xvfb',':193','-screen','0','640x480x24','-nolisten','tcp'],stdout=(out/'xvfb.log').open('wb'),stderr=subprocess.STDOUT)
 for _ in range(100):
  if server.poll() is not None: raise RuntimeError('Xvfb exited before startup')
  try: connection=display.Display(':193'); break
  except Exception: time.sleep(.05)
 if connection is None: raise RuntimeError('Xvfb unavailable')
 root=connection.screen().root
 window=root.create_window(10,10,160,100,0,connection.screen().root_depth,X.InputOutput,X.CopyFromParent,background_pixel=0x224466,event_mask=X.ExposureMask)
 window.map(); connection.set_input_focus(window,X.RevertToParent,X.CurrentTime); connection.sync()
 bridge=NativeHandleBridge(':193',{'app':window.id},'app','/out/bridge',process_identity=True,query_worker=True,observation_worker=True)
 with bridge.cancellation_scope('fresh-healthy',cancel_when_idle=True,single_idle_observation=True):
  first=bridge.observe_idle_until(time.monotonic_ns()+2_000_000_000)
  result['healthy']={'sequence':first['sequence'],'late_cancel':bridge.request_cancel('fresh-healthy')['status']}
 before=bytes(connection.query_keymap());before_pointer=root.query_pointer().mask
 os.kill(server.pid,signal.SIGSTOP)
 deadline=time.monotonic_ns()+300_000_000; started=time.monotonic_ns()
 with bridge.cancellation_scope('fresh-stopped',cancel_when_idle=True,single_idle_observation=True):
  try: bridge.observe_idle_until(deadline);result['stopped_return']='unexpected_source'
  except X11BackendError as e:result['stopped_return']='unavailable';result['error_type']=type(e).__name__
 result['stopped_elapsed_ms']=(time.monotonic_ns()-started)/1e6
 result['sequence_before_resume']=bridge.sequence; result['retired_before_resume']=bridge._observations.snapshot()['retired']
 os.kill(server.pid,signal.SIGCONT)
 end=time.monotonic()+3
 while bridge._observations.snapshot()['thread_alive'] and time.monotonic()<end:time.sleep(.02)
 result['worker_after_resume']=bridge._observations.snapshot()
 connection.sync();after=bytes(connection.query_keymap());after_pointer=root.query_pointer().mask
 result['sequence_after_resume']=bridge.sequence;result['review_required']=bridge.review_required
 result['input_neutral_before_after']=not any(before) and not any(after) and (before_pointer & 0x1f00)==0 and (after_pointer & 0x1f00)==0
 assert result['healthy']=={'sequence':1,'late_cancel':'not_active'}
 assert result['stopped_return']=='unavailable' and result['sequence_before_resume']==result['sequence_after_resume']==1
 assert result['retired_before_resume'] and not result['worker_after_resume']['thread_alive'] and result['review_required'] and result['input_neutral_before_after']
 result['status']='passed'
except BaseException as error:
 result.update(status='failed',error=repr(error),traceback=traceback.format_exc())
finally:
 if server is not None and server.poll() is None:
  try: os.kill(server.pid,signal.SIGCONT)
  except ProcessLookupError: pass
 if bridge is not None:
  try: bridge.close()
  except Exception as error: result['bridge_close_error']=repr(error);result['status']='failed'
 if connection is not None:
  try: connection.close()
  except Exception as error: result['connection_close_error']=repr(error);result['status']='failed'
 if server is not None and server.poll() is None:
  server.terminate()
  try:server.wait(timeout=5)
  except subprocess.TimeoutExpired:server.kill();server.wait();result['status']='failed';result['forced_server_kill']=True
 result['server_exit']=None if server is None else server.poll()
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result),flush=True)
sys.exit(0 if result['status']=='passed' else 1)

import hashlib,json,os,pathlib,subprocess,sys,time
root=pathlib.Path(__file__).resolve().parent
out=root/'real-x-a01'
out.mkdir(exist_ok=False)
(out/'output').mkdir()
files=[p for p in (root/'src').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']+[root/'real_x_trial.py',root/'launch_real_x.py']
manifest={str(p.relative_to(root)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
conditions={'allocation':'idle-real-x-a01-20261101','base_main':'46ff81d345de4b08cd62de1bb4fa4ff1b4f7ec0c',
 'image':'sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25',
 'limits':'one CPU, 1 GiB, network none, pull never, private Xvfb; WSLc memory limit excludes swap',
 'order':'healthy capture, stop private Xvfb, 300ms idle capture deadline, resume private Xvfb, observe worker exit and input neutrality',
 'criteria':'healthy capture sequence 1; stopped capture unavailable with retired reader; no late sequence publication after resume; input neutral before/after',
 'stop':'single attempt; preserve failure; no retry for success',
 'scope':'prototype only; no action/model/task success claim; timing is observational rather than a hard scheduling guarantee',
 'manifest_sha256':hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest()}
(out/'conditions.json').write_text(json.dumps(conditions,indent=2)+'\n')
for name,digest in manifest.items():
 if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('frozen source changed: '+name)
cmd=['wslc','run','--rm','--name',conditions['allocation'],'--network','none','--cpus','1','--memory','1g','--pull','never',
 '--mount',f'type=bind,source={root / "src"},target=/src,readonly',
 '--mount',f'type=bind,source={root / "real_x_trial.py"},target=/trial.py,readonly',
 '--mount',f'type=bind,source={out / "output"},target=/out',
 '--env','PYTHONPATH=/src','--env','PYTHONDONTWRITEBYTECODE=1','--entrypoint','timeout',conditions['image'],
 '--signal=TERM','--kill-after=3s','30s','python3','-B','/trial.py']
(out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
started=time.monotonic()
with (out/'stdout').open('wb') as stdout,(out/'stderr').open('wb') as stderr:
 proc=subprocess.run(cmd,stdout=stdout,stderr=stderr,timeout=50,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
result={'returncode':proc.returncode,'elapsed_seconds':time.monotonic()-started}
(out/'launcher-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
sys.exit(proc.returncode)

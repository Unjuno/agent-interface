from pathlib import Path
from PIL import Image,ImageOps
import io,json,subprocess,hashlib
p=Path('/out');image=Image.open('/in/reference.png').convert('RGB');boxes={'row1':(434,496,454,506),'row2':(434,509,454,519)};rows=[]
for name,box in boxes.items():
 for scale in (4,8):
  crop=image.crop(box).convert('L').resize(((box[2]-box[0])*scale,(box[3]-box[1])*scale),Image.Resampling.LANCZOS);crop=ImageOps.expand(crop,border=16,fill=255);buf=io.BytesIO();crop.save(buf,format='PNG');data=buf.getvalue();cmd=['tesseract','stdin','stdout','--psm','7','-c','tessedit_char_whitelist=0123456789','tsv'];r=subprocess.run(cmd,input=data,capture_output=True,timeout=2,check=False);(p/f'{name}-tight-{scale}.tsv').write_bytes(r.stdout);(p/f'{name}-tight-{scale}.stderr').write_bytes(r.stderr);rows.append({'name':name,'box':box,'scale':scale,'input_sha256':hashlib.sha256(data).hexdigest(),'returncode':r.returncode,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest()})
(p/'tight-results.json').write_text(json.dumps(rows,indent=2)+'\n')

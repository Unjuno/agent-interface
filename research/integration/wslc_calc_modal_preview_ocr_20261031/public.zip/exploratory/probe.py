from pathlib import Path
from PIL import Image,ImageOps
import io,json,subprocess,hashlib
p=Path('/out');image=Image.open('/in/reference.png').convert('RGB');boxes={'row1':(431,494,490,507),'row2':(431,507,490,520),'title':(570,132,710,152),'button':(790,627,875,657)};rows=[]
for name,box in boxes.items():
 for psm in (7,6):
  crop=image.crop(box).convert('L').resize(((box[2]-box[0])*4,(box[3]-box[1])*4),Image.Resampling.LANCZOS);crop=ImageOps.expand(crop,border=16,fill=255);buf=io.BytesIO();crop.save(buf,format='PNG');data=buf.getvalue();cmd=['tesseract','stdin','stdout','--psm',str(psm),'tsv'];r=subprocess.run(cmd,input=data,capture_output=True,timeout=2,check=False);(p/f'{name}-{psm}.tsv').write_bytes(r.stdout);(p/f'{name}-{psm}.stderr').write_bytes(r.stderr);rows.append({'name':name,'box':box,'psm':psm,'input_sha256':hashlib.sha256(data).hexdigest(),'returncode':r.returncode,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest()})
(p/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

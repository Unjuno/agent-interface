import json,os,select,signal,subprocess,sys,time,uuid
from pathlib import Path
mode=sys.argv[1];root=Path(sys.argv[2]);run=sys.argv[3]
def log(event,**kw):
    with (root/'events.jsonl').open('a') as f:
        f.write(json.dumps(dict(run=run,event=event,pid=os.getpid(),ns=time.monotonic_ns(),**kw))+'\n');f.flush()
def waitfile(name,secs=8):
    end=time.monotonic()+secs
    while time.monotonic()<end:
        p=root/name
        if p.exists():return p.read_text().strip()
        time.sleep(.01)
    raise TimeoutError(name)
if mode=='supervisor':
    fd=int(sys.argv[4]);child=None
    try:
        log('supervisor_ready');(root/'ready').write_text(run)
        if waitfile('spawn')!=run:raise ValueError('run mismatch')
        child=subprocess.Popen([sys.executable,'-c','import time; time.sleep(60)'],start_new_session=True)
        log('child_spawned',child=child.pid);(root/'child.pid').write_text(str(child.pid))
        if waitfile('observe')!=run:raise ValueError('observe mismatch')
        if not select.select([fd],[],[],3)[0] or os.read(fd,1)!=b'':raise RuntimeError('EOF absent')
        log('parent_eof');child.terminate();child.wait(timeout=3)
        log('child_reaped',child=child.pid,returncode=child.returncode)
    finally:
        if child is not None and child.poll() is None:child.kill();child.wait(timeout=2)
        os.close(fd)
elif mode=='parent':
    r,w=os.pipe()
    s=subprocess.Popen([sys.executable,__file__,'supervisor',str(root),run,str(r)],pass_fds=(r,),start_new_session=True)
    os.close(r);(root/'supervisor.pid').write_text(str(s.pid));log('supervisor_started',supervisor=s.pid)
    while True:time.sleep(1)
elif mode=='controller':
    root.mkdir(parents=False,exist_ok=False);p=None;sf=None;cf=None
    try:
        p=subprocess.Popen([sys.executable,__file__,'parent',str(root),run],start_new_session=True)
        sp=int(waitfile('supervisor.pid'));sf=os.pidfd_open(sp)
        if waitfile('ready')!=run:raise ValueError('ready mismatch')
        p.kill();p.wait(timeout=3);log('parent_reaped',parent=p.pid,returncode=p.returncode)
        (root/'spawn').write_text(run)
        cp=int(waitfile('child.pid'));cf=os.pidfd_open(cp)
        if select.select([cf],[],[],0)[0]:raise RuntimeError('child exited before observation')
        log('child_pidfd_not_exited',child=cp);(root/'observe').write_text(run)
        if not select.select([sf],[],[],8)[0]:raise TimeoutError('supervisor did not exit')
        events=[json.loads(x) for x in (root/'events.jsonl').read_text().splitlines()]
        def one(name):
            xs=[e for e in events if e['run']==run and e['event']==name]
            if len(xs)!=1:raise RuntimeError('invalid event count '+name)
            return xs[0]
        death,spawn,eof,reap=[one(x) for x in ('parent_reaped','child_spawned','parent_eof','child_reaped')]
        if spawn['child']!=cp or reap['child']!=cp or not death['ns']<spawn['ns']<eof['ns']<reap['ns']:raise RuntimeError('ordering/identity mismatch')
        if not select.select([cf],[],[],1)[0]:raise RuntimeError('child pidfd still active')
        log('child_pidfd_exited');log('supervisor_pidfd_exited');log('result',status='COUNTEREXAMPLE_OBSERVED',child=cp)
    except BaseException as e:
        log('result',status='FAIL',error=repr(e));raise
    finally:
        if p is not None and p.poll() is None:p.kill();p.wait(timeout=2)
        if cf is not None:
            if not select.select([cf],[],[],0)[0]:
                log('fixture_emergency_kill_child');signal.pidfd_send_signal(cf,signal.SIGKILL)
            os.close(cf)
        if sf is not None:
            if not select.select([sf],[],[],0)[0]:
                log('fixture_emergency_kill_supervisor')
                try:signal.pidfd_send_signal(sf,signal.SIGKILL)
                except ProcessLookupError:pass
            os.close(sf)
else:raise SystemExit(64)

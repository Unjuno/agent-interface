import hashlib,json,time,sys,os
from pathlib import Path
from integrated_efficiency_app_server_model_v1 import PersistentGroundingModel
root=Path(sys.argv[2]);ex=root/'exchange';deadline=time.monotonic()+130
for i in (1,2):
 r={'id':f'pilot-{i}','ok':False};m=None
 try:
  while not (ex/f'request-{i}.json').exists():
   if time.monotonic()>=deadline:raise TimeoutError('request not observed')
   time.sleep(.05)
  q=json.loads((ex/f'request-{i}.json').read_text());image=ex/f'image-{i}.png';digest=hashlib.sha256(image.read_bytes()).hexdigest()
  if q.get('id')!=r['id'] or q.get('image_sha256')!=digest:raise ValueError('request/image mismatch')
  r['image_sha256']=digest;workspace=root/f'workspace-{i}';workspace.mkdir(exist_ok=False)
  m=PersistentGroundingModel(root/f'model-session-{i}',workspace,executable=sys.argv[1],contract='plain',model='gpt-6.1-sol',effort='low')
  r['attempted']=True;v=m.call(root/f'model-call-{i}','In this LibreOffice Calc screenshot, identify the center of cell A1 (column A, row 1) as field and the toolbar Save floppy-disk icon as submit. Do not operate anything.',image,'plain',workspace)
  r.update(ok=True,grounding=v['grounding'],usage=v['usage'],call_id=v['call_id'],runner_ns=v['runner_ns'])
 except Exception as e:r.update(error=type(e).__name__,detail=str(e)[:800],call_id=getattr(e,'call_id',None),usage=getattr(e,'usage',None))
 finally:
  if m is not None:
   try:m.close();r['close_returned']=True
   except Exception as e:r.update(ok=False,close_returned=False,close_error=type(e).__name__)
  tmp=ex/f'response-{i}.tmp';tmp.write_text(json.dumps(r));os.replace(tmp,ex/f'response-{i}.json')
 print(json.dumps({'turn':i,'ok':r['ok'],'error':r.get('error')}),flush=True)
 if not r['ok']:raise SystemExit(1)

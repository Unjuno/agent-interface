# Iterator-fallback candidate: bounded Xvfb observation

Main at freeze: `504b013d81324b58b5d890d144b3b0d820cb3b3c`; candidate
derived from draft PR #10074 head `0675ab810f7ee890d0904b8a402678c81f8dbafb`
plus the experimental segmented mapping and the iteration fallback. This is
not main and has not been proposed as a production-ready implementation.

Static inspection of the candidate's `runtime/` found direct `bridge.history`
uses in the bridge, compiled controller, and guarded MCP caller primarily index,
insert, clear, or fork; `RetainedWin32Observation` similarly inserts and
indexes its separate `_history`. Tests and other callers can enumerate the
public mapping. This search is not proof that no indirect or external caller
iterates it.

Before execution, the image, candidate and harness were fixed by the manifest
and each arm's conditions. In a private Xvfb with a dedicated target, the first
arm cancels while detached insertion is paused; the second publishes. Both
inspect visibility and reference minting before publication, then use a fresh
guarded owner to type `a` into the target and check the release and neutral X
input state. `HybridRecords._dict` was instrumented to record each conversion
and a short stack; conversion count is observational, not a pass requirement.

| Arm | Result | Old observation after resuming | Target effect / neutral input | Conversions |
| --- | --- | --- | --- | ---: |
| cancel | passed | not published, sequence 0 | `a` / yes | 0 |
| publish | passed | published, sequence 1 | `a` / yes | 0 |

The fixed input contains only one initial capture per bridge; it does not test
large history performance. The pause is an injected boundary, and the old task
does not hold an input. The experiment is not a model comparison, general
concurrency guarantee, deadline proof, or MAP01 result. Refer to each arm's
`conditions.json`, `output/result.json`, event files and launcher output for
raw evidence. See `../idle-hybrid-iter-cost-r95/RESULTS.md` for the observed
cost of enumeration on a 100,000-record synthetic history.

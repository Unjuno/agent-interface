"""Freeze and run isolated regression tests once per interpreter mode."""
import hashlib,json,pathlib,subprocess,sys,time
root=pathlib.Path(__file__).resolve().parent
mode=sys.argv[1]
if mode not in ('normal','optimized'): raise ValueError(mode)
out=root/('tests-'+mode);out.mkdir(exist_ok=False)
manifest=root/'manifest.json'
checks=json.loads(manifest.read_text())
for name,digest in checks.items():
    if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('source changed '+name)
image='sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25'
modules=['runtime.guarded_x11_v1.test_hybrid_records','runtime.guarded_x11_v1.test_history','runtime.guarded_x11_v1.test_bounded_idle_observation_experiment','runtime.cli_v1.test_bounded_idle_owner_experiment','runtime.cli_v1.test_mcp_owned_process']
conditions={'allocation':'idle-hybrid-iter-r95-tests-'+mode,'image':image,'source_manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'modules':modules,'mode':mode,'resources':'WSLc one CPU, 1GiB, no network, no pull','limit':'regression only, not live GUI or performance'}
(out/'conditions.json').write_text(json.dumps(conditions,indent=2)+'\n')
cmd=['wslc','run','--rm','--name',conditions['allocation'],'--network','none','--cpus','1','--memory','1g','--pull','never','--mount',f'type=bind,source={root / "src"},target=/src,readonly','--env','PYTHONPATH=/src','--env','PYTHONDONTWRITEBYTECODE=1','--entrypoint','timeout',image,'--signal=TERM','--kill-after=3s','110s','python3','-B']
if mode=='optimized':cmd.append('-O')
cmd+=['-m','unittest']+modules
start=time.monotonic()
with (out/'stdout').open('wb') as a,(out/'stderr').open('wb') as b:
    proc=subprocess.run(cmd,stdout=a,stderr=b,timeout=125,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
(out/'result.json').write_text(json.dumps({'returncode':proc.returncode,'elapsed_seconds':time.monotonic()-start},indent=2)+'\n')
print(json.dumps({'returncode':proc.returncode}),flush=True)
sys.exit(proc.returncode)

"""Compare history staging before and after iteration on a fixed synthetic input."""
import json, os, pathlib, statistics, time
from PIL import Image
from history_baseline import ObservationHistory as Baseline
from runtime.guarded_x11_v1.history import ObservationHistory as Hybrid

order = os.environ['SIZE_ORDER']
sizes = [1000, 10000, 100000]
if order == 'descending': sizes.reverse()
elif order != 'ascending': raise ValueError('bad order')
image = Image.new('RGB', (16,16))
obs = {'native': {'width': 16, 'height': 16, 'sha256':'raw', 'artifact': {'path':'unused', 'sha256':'encoded', 'source_raw_sha256':'raw'}}}
value = (obs,image)
record = (obs,('unused','encoded',(16,16)))
rows = []
for size in sizes:
    baseline, hybrid = Baseline(), Hybrid()
    baseline._records = {i:record for i in range(1,size+1)}
    for i in range(1,size+1): hybrid._records[i] = record
    for i in (size-1,size): baseline._decoded[i]=image; hybrid._decoded[i]=image
    after = hybrid.fork()
    assert len(list(after._records)) == size and after._records._fallback is not None
    assert hybrid._records._fallback is None
    histories = {'baseline_stage':baseline,'hybrid_before_stage':hybrid,'hybrid_after_stage':after}
    samples = {key:[] for key in histories}
    for trial in range(41):
        names = list(histories)
        if trial % 2: names.reverse()
        for name in names:
            start = time.perf_counter_ns()
            staged = histories[name].fork(); staged[size+1] = value; del staged
            samples[name].append(time.perf_counter_ns()-start)
    iteration = {'baseline':[],'hybrid':[]}
    for trial in range(9):
        names = ['baseline','hybrid']
        if trial % 2: names.reverse()
        for name in names:
            probe = (baseline if name == 'baseline' else hybrid).fork()
            start = time.perf_counter_ns(); keys = list(probe._records); elapsed = time.perf_counter_ns()-start
            assert len(keys)==size and keys[-1]==size
            iteration[name].append(elapsed)
            del probe,keys
    rows.append({'size':size,'staging_ns':samples,'staging_medians_ns':{k:statistics.median(v) for k,v in samples.items()},'iteration_ns':iteration,'iteration_medians_ns':{k:statistics.median(v) for k,v in iteration.items()}})
result={'status':'completed','order':order,'staging_repetitions':41,'iteration_repetitions':9,'rows':rows}
pathlib.Path('/out/result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)

import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parent
files=[p for p in (root/'src').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']+[root/n for n in ('history_baseline.py','bench.py','prepare.py','run.py')]
manifest={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
arms=[('hybrid-iter-r95-a01','ascending'),('hybrid-iter-r95-a02','descending')]
for ident,order in arms:
    p=root/ident;p.mkdir(exist_ok=False);(p/'output').mkdir()
    c={'allocation':'idle-hybrid-'+ident,'order':order,'arm_order':arms,
       'manifest_sha256':hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest(),
       'main_at_freeze':'504b013d81324b58b5d890d144b3b0d820cb3b3c','baseline_pr_head':'0675ab810f7ee890d0904b8a402678c81f8dbafb',
       'image':'sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25',
       'protocol':'41 alternating staging trials before and after iteration; 9 paired full iteration conversion trials; staging includes disposal',
       'limits':'synthetic metadata and 16x16 image, two decoded cache entries; no GUI capture, disk reload, IPC, model or real-time guarantee',
       'resources':'WSLc one CPU, 1GiB memory, no network, no pull; swap may not be limited'}
    (p/'conditions.json').write_text(json.dumps(c,indent=2)+'\n')
print('two iteration comparison allocations frozen')

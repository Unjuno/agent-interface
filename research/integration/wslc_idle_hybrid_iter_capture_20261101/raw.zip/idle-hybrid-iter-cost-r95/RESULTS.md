# Experimental iterator fallback: 2026-11-01

This is an isolated modification of the hybrid history candidate based on PR
#10074 head `0675ab810f7ee890d0904b8a402678c81f8dbafb`. Main at freeze was
`504b013d81324b58b5d890d144b3b0d820cb3b3c`. It is not integrated into main.

The previous segmented iterator failed to raise `RuntimeError` when a record
was added during iteration, unlike the baseline dict; the failing test is in
`../idle-hybrid-iter-r93/iterator-red.txt`. The experiment converts the mapping
to a dict when iteration starts. That test and a value-overwrite iteration test
pass, as do 90 selected regression tests in each of normal and optimized Python
under WSLc (`tests-normal/` and `tests-optimized/`). These tests do not prove
full dictionary compatibility or thread safety; the candidate retains its
existing serialized-caller assumption.

Two separately frozen WSLc allocations measured synthetic history metadata with
one CPU, 1 GiB memory limit, no network, the pinned image in conditions.json,
41 alternating staging samples and nine alternating iteration samples per
size. Source and harness hashes are in `manifest.json`. Timing uses
`perf_counter_ns`, staging includes disposal, and histories contain shared
synthetic 16x16 images and two cached decoded images. No GUI capture, model,
IPC, artifact reload, or hard real-time behavior was measured.

At 100,000 records, the ascending/descending runs respectively measured:

| Median | Ascending | Descending |
| --- | ---: | ---: |
| baseline fork + insertion + disposal | 0.434 ms | 0.454 ms |
| hybrid before iteration, same operation | 0.013 ms | 0.014 ms |
| hybrid after iteration, same operation | 0.437 ms | 0.458 ms |
| baseline list of records | 0.286 ms | 0.298 ms |
| hybrid first list including conversion | 2.161 ms | 2.271 ms |

The correctness repair gives up the fast fork path for the iterated instance
until it is cleared. It does not establish that this cost is acceptable in the
live observation path. Full sample arrays, conditions, launch outcomes and
source are preserved in this directory; Windows-only red/green evidence remains
in the adjacent r93 directory. This result is not a live task-speed comparison.

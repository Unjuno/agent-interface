import os,time,json,subprocess,signal,shutil,hashlib
from pathlib import Path
from Xlib import X,display
from runtime.cli_v1.mcp_guarded import GuardedSessionOwner
from composition import CalcComposition
from pair_saved_oracle import score_saved
from crop_pixel_cue import create_reference
from PIL import Image
out=Path('/out');env=dict(os.environ,DISPLAY=':153',HOME='/tmp',SAL_USE_VCLPLUGIN='gen');actors=[];handles=[];b=None;d=None;owner=None
try:
 def spawn(name,args):
  f=(out/(name+'.log')).open('wb');handles.append(f);p=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);actors.append(p);return p
 x=spawn('xvfb',['Xvfb',':153','-screen','0','1280x800x24','-nolisten','tcp','-ac'])
 for _ in range(100):
  try:d=display.Display(':153');break
  except Exception:time.sleep(.05)
 if d is None:raise RuntimeError('Xvfb unavailable')
 if hashlib.sha256(Path('/in/blank.fods').read_bytes()).hexdigest()!='462beebbcb020ccf49af3cc49520f789a816cc3fb97597cefbd6940ffc26aeb1':raise RuntimeError('blank fixture digest mismatch')
 shutil.copyfile('/in/blank.fods','/tmp/blank.fods');spawn('openbox',['openbox','--sm-disable']);lo=spawn('calc',['libreoffice','-env:UserInstallation=file:///tmp/observe-profile','--calc','--nologo','--norestore','--nofirststartwizard','/tmp/blank.fods'])
 def walk(w,depth=0):
  if depth>6:return []
  out=[]
  for child in w.query_tree().children:
   try:
    title=child.get_wm_name();title=title.decode(errors='replace') if isinstance(title,bytes) else str(title or '')
    out.append((child.id,title,child.get_attributes().map_state));out+=walk(child,depth+1)
   except Exception:pass
  return out
 end=time.monotonic()+20;found=[]
 while time.monotonic()<end:
  found=[r for r in walk(d.screen().root) if 'blank.fods' in r[1].lower() and 'calc' in r[1].lower() and r[2]==X.IsViewable]
  if len(found)==1:break
  if len(found)>1:raise RuntimeError('ambiguous target')
  if lo.poll() is not None:raise RuntimeError('calc exited')
  time.sleep(.05)
 if len(found)!=1:
  (out/'window-inventory.json').write_text(json.dumps(walk(d.screen().root),indent=2)+'\n')
  raise RuntimeError('target unavailable')
 time.sleep(1);owner=GuardedSessionOwner({'app':found[0][0]},out/'owner',':153');owner.get();b=owner.bridge;obs=b.observe();rgb=b.history[obs['sequence']][1]
 if hashlib.sha256(rgb.crop((0,97,42,119)).tobytes()).hexdigest()!='2e86f3a0f6d87ee4fb4e5ffeb7cfd159d715cb5f6f8177b0ede83784d49088cf':raise RuntimeError('initial A1 name-box differs from reviewed source')
 # Each model turn consumes a distinct freshly captured image and request ID.
 import io
 def ask_model(i,current,current_rgb):
  artifact=current['native']['artifact'];data=Path(artifact['path']).read_bytes()
  if hashlib.sha256(data).hexdigest()!=artifact['sha256'] or artifact['source_raw_sha256']!=current['native']['sha256'] or Image.open(io.BytesIO(data)).convert('RGB').tobytes()!=current_rgb.tobytes():raise RuntimeError('image association mismatch')
  digest=hashlib.sha256(data).hexdigest();Path(f'/exchange/image-{i}.png').write_bytes(data)
  q={'id':f'pilot-{i}','image_sha256':digest,'source_sequence':current['sequence']};tmp=Path(f'/exchange/request-{i}.tmp');tmp.write_text(json.dumps(q));os.replace(tmp,f'/exchange/request-{i}.json')
  end=time.monotonic()+120
  while not Path(f'/exchange/response-{i}.json').exists():
   if time.monotonic()>=end:raise TimeoutError('model response not observed')
   time.sleep(.05)
  response=json.loads(Path(f'/exchange/response-{i}.json').read_text())
  if response.get('id')!=q['id'] or response.get('image_sha256')!=digest or response.get('ok') is not True:raise RuntimeError('model response invalid')
  field=response['grounding']['field_point'];save=response['grounding']['submit_point']
  if not (50<=field[0]<=115 and 145<=field[1]<=157 and 73<=save[0]<=94 and 42<=save[1]<=62):raise RuntimeError('model points outside reviewed targets')
  return response,field
 task_start_ns=time.monotonic_ns()
 first,first_point=ask_model(1,obs,rgb);original=rgb;binding=obs['pointer_binding'];x,y=first_point
 overlay=d.screen().root.create_window(x-4,y-4,8,8,0,d.screen().root_depth,X.InputOutput,X.CopyFromParent,override_redirect=1,background_pixel=0)
 overlay.map();overlay.configure(stack_mode=X.Above);d.sync();time.sleep(.1)
 stale=b.observe();stale_rgb=b.history[stale['sequence']][1]
 before=original.crop((x-4,y-4,x+4,y+4)).tobytes();after=stale_rgb.crop((x-4,y-4,x+4,y+4)).tobytes()
 prior=[p.name for p in (out/'owner').rglob('*.json') if p.name.startswith(('program-','mint-'))]
 (out/'stale-gate.json').write_text(json.dumps({'first_point':first_point,'sequence':stale['sequence'],'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest(),'binding_unchanged':stale['pointer_binding']==binding,'prior_programs_or_mints':prior},indent=2)+'\n')
 if stale['pointer_binding']!=binding or before==after or prior:raise RuntimeError('stale precondition failed; no input')
 overlay.destroy();d.sync();time.sleep(.1);obs=b.observe();rgb=b.history[obs['sequence']][1]
 response,field=ask_model(2,obs,rgb);original=rgb;binding=obs['pointer_binding'];obs=b.observe();rgb=b.history[obs['sequence']][1];x0,y0=field
 if obs['pointer_binding']!=binding or original.crop((x0-4,y0-4,x0+4,y0+4)).tobytes()!=rgb.crop((x0-4,y0-4,x0+4,y0+4)).tobytes():raise RuntimeError('recovery target changed after model call')
 click_ref=b.mint_reference('click_cell',obs['sequence'],field,region_size=(30,20))
 owner.dispatch_attempted=True
 click=b.click('click_cell',click_ref['offset'],tail=[],expires_at_ns=time.monotonic_ns()+2_000_000_000)
 (out/'click-result.json').write_text(json.dumps(click,indent=2)+'\n')
 releases=click.get('execution',{}).get('releases',[])
 if click.get('status')!='completed' or not releases or not all(r.get('verified') is True and r.get('keys_down')==[] and r.get('buttons_down')==[] for r in releases):raise RuntimeError('click failed or release unverified')
 obs=b.observe();rgb=b.history[obs['sequence']][1]
 if hashlib.sha256(rgb.crop((0,97,42,119)).tobytes()).hexdigest()!='2e86f3a0f6d87ee4fb4e5ffeb7cfd159d715cb5f6f8177b0ede83784d49088cf':raise RuntimeError('A1 selection not verified after click')
 entry=b.mint_reference('entry',obs['sequence'],[440,28],region_size=(30,14));save=b.mint_reference('sheet',obs['sequence'],[440,28],region_size=(30,14))
 binding=obs['pointer_binding'];approved={'geometry_reviewed':True,'image_size':[1280,800],'scope':b.scope,'revision':b.binding_revision,'binding':binding,'titles':[found[0][1]],'pixel_reference_reviewed':True}
 refs={'entry_alias':'entry','entry_offset':entry['offset'],'save_alias':'sheet','save_offset':save['offset'],'cell_regions':[[37,143,126,159],[37,159,126,176]],'context_region':[350,20,370,35]}
 reference=create_reference(Image.open('/in/reference.png').convert('RGB'))
 route=os.environ['ROUTE'];method_start=time.monotonic_ns()
 if route=='compiled':
  comp=CalcComposition(owner,out/'method',refs=refs,approved=approved,reviewed_native=obs,reviewed_rgb=rgb,pixel_reference=reference)
  # Inject a context change only after the completed entry program returned.
  original_keyboard=b.keyboard;injected=[];overlay_after=None
  def instrumented_keyboard(alias,*args,**kwargs):
   global overlay_after
   result=original_keyboard(alias,*args,**kwargs)
   if alias=='entry' and result.get('status')=='completed':
    overlay_after=d.screen().root.create_window(350,20,20,15,0,d.screen().root_depth,X.InputOutput,X.CopyFromParent,override_redirect=1,background_pixel=0)
    overlay_after.map();overlay_after.configure(stack_mode=X.Above);d.sync();time.sleep(.1)
    injected.append({'alias':alias,'status':result['status'],'release':result.get('execution',{}).get('releases',[])})
   return result
  b.keyboard=instrumented_keyboard
  try:method=comp.run('compiled')
  finally:b.keyboard=original_keyboard
  from crop_pixel_cue import classify
  post=b.observe();post_rgb=b.history[post['sequence']][1]
  (out/'post-entry-invalidation.json').write_text(json.dumps({'injected':injected,'post_observation':post,'cell_cue':classify(post_rgb,reference),'context_changed':post_rgb.crop((350,20,370,35)).tobytes()!=rgb.crop((350,20,370,35)).tobytes()},indent=2)+'\n')
  if overlay_after is not None:overlay_after.destroy();d.sync()
  receipt=method['method_receipt']
  if not (receipt['outcome']=='SAFE_YIELD' and receipt['reason']=='effect_unavailable' and receipt['completed_transitions']==1 and receipt['pending_effect']['action']=='enter' and len(injected)==1 and classify(post_rgb,reference)=='filled'):
   raise RuntimeError('retained entry state not eligible for fresh recovery')
  prior_close=owner.close();owner=None;b=None
  if prior_close['status']!='closed' or prior_close['release']['verified'] is not True or prior_close['release']['keys_down'] or prior_close['release']['buttons_down']:
   raise RuntimeError('prior owner release unverified')
  (out/'prior-close.json').write_text(json.dumps(prior_close,indent=2)+'\n')
  # Deliberate persistent obstruction over the reviewed first-cell crop.
  cell_overlay=d.screen().root.create_window(105,146,8,8,0,d.screen().root_depth,X.InputOutput,X.CopyFromParent,override_redirect=1,background_pixel=0)
  cell_overlay.map();cell_overlay.configure(stack_mode=X.Above);d.sync();time.sleep(.1)
  owner=GuardedSessionOwner({'app':found[0][0]},out/'recovery-owner',':153');owner.get();b=owner.bridge
  if owner.session_id==prior_close['session_id']:raise RuntimeError('recovery requires new owner')
  # Repaint can lag overlay removal. Observe only; never replay entry.
  reobservations=[];until_ns=time.monotonic_ns()+2_000_000_000;until=until_ns/1e9;race_cleared=False
  while True:
   if not race_cleared and len(reobservations)>=2 and time.monotonic_ns()>=until_ns-250_000_000:
    remaining=(until_ns+50_000_000-time.monotonic_ns())/1e9
    if remaining>0:time.sleep(remaining)
    cell_overlay.destroy();d.sync();clear_ns=time.monotonic_ns();race_cleared=True;time.sleep(.1);(out/'race-event.json').write_text(json.dumps({'deadline_ns':until_ns,'clear_ns':clear_ns,'observations_before':len(reobservations)},indent=2)+'\n')
   fresh=b.observe();fresh_rgb=b.history[fresh['sequence']][1]
   filled=classify(fresh_rgb,reference)=='filled';context_ok=fresh_rgb.crop((350,20,370,35)).tobytes()==rgb.crop((350,20,370,35)).tobytes()
   reobservations.append({'sequence':fresh['sequence'],'filled':filled,'context_ok':context_ok})
   (out/'reobservations.json').write_text(json.dumps(reobservations,indent=2)+'\n')
   if filled and context_ok:break
   if time.monotonic()>=until:raise RuntimeError('fresh recovered state unavailable after bounded reobservation')
   time.sleep(.1)
  from save_guard import SemanticSaveGuard
  ref=b.mint_reference('recovery_save',fresh['sequence'],[440,28],region_size=(30,14));deadline=time.monotonic_ns()+3_000_000_000
  semantic=SemanticSaveGuard(b,alias='recovery_save',offset=ref['offset'],regions=refs['cell_regions'],deadline_ns=deadline)
  cue_record={'cue':'filled','sequence':fresh['sequence'],'artifact_sha256':fresh['native']['artifact']['sha256']};semantic.arm(fresh,fresh_rgb,cue_record=cue_record);context=fresh_rgb.crop((350,20,370,35)).tobytes()
  tail=[{'op':'key_chord','keys':['CTRL','s']},{'op':'wait_update','timeout_ms':200}]
  def recovery_guard(stage,native,image):return semantic.validate_capture(native,image) and image.crop((350,20,370,35)).tobytes()==context
  owner.dispatch_attempted=True
  with b.input_guard('recovery_save',ref['offset'],tail=tail,verify=recovery_guard,interaction='keyboard'):
   recovery_save=b.keyboard('recovery_save',ref['offset'],tail=tail,expires_at_ns=deadline)
  (out/'recovery-save.json').write_text(json.dumps(recovery_save,indent=2)+'\n');(out/'recovery-guard.json').write_text(json.dumps({'events':semantic.events,'cue':cue_record},indent=2)+'\n')
  (out/'recovery.json').write_text(json.dumps({'prior_close':prior_close,'fresh_observation':fresh,'fresh_session_id':owner.session_id,'entry_replayed':False,'save_effect':'unverified'},indent=2)+'\n')
  releases=recovery_save.get('execution',{}).get('releases',[])
  if recovery_save.get('status')!='completed' or recovery_save.get('recovery_required') is not False or not releases or not all(x.get('verified') is True and x.get('keys_down')==[] and x.get('buttons_down')==[] for x in releases):raise RuntimeError('fresh guarded Save uncertain')
 elif route=='fresh':
  from crop_pixel_cue import classify
  tail=[{'op':'text','text':'731','gap_ms':1},{'op':'key_chord','keys':['Return']},{'op':'wait_update','timeout_ms':100},{'op':'text','text':'864','gap_ms':1},{'op':'key_chord','keys':['Return']},{'op':'wait_update','timeout_ms':100}]
  first=b.keyboard('entry',entry['offset'],tail=tail,expires_at_ns=time.monotonic_ns()+3_000_000_000);(out/'fresh-entry.json').write_text(json.dumps(first,indent=2)+'\n')
  if first.get('status')!='completed' or not all(r.get('verified') and not r.get('keys_down') and not r.get('buttons_down') for r in first.get('execution',{}).get('releases',[])):raise RuntimeError('fresh entry failed')
  filled=b.observe();filled_rgb=b.history[filled['sequence']][1]
  if classify(filled_rgb,reference)!='filled':raise RuntimeError('filled cue unavailable')
  second,second_field=ask_model(3,filled,filled_rgb)
  now=b.observe();now_rgb=b.history[now['sequence']][1];save_xy=second['grounding']['submit_point'];x,y=save_xy
  if now['pointer_binding']!=filled['pointer_binding'] or now_rgb.crop((x-4,y-4,x+4,y+4)).tobytes()!=filled_rgb.crop((x-4,y-4,x+4,y+4)).tobytes() or classify(now_rgb,reference)!='filled':raise RuntimeError('fresh save dependency changed')
  ref=b.mint_reference('fresh_save',now['sequence'],[440,28],region_size=(30,14));save_tail=[{'op':'key_chord','keys':['CTRL','s']},{'op':'wait_update','timeout_ms':100}]
  from save_guard import SemanticSaveGuard
  deadline=time.monotonic_ns()+3_000_000_000
  semantic=SemanticSaveGuard(b,alias='fresh_save',offset=ref['offset'],regions=refs['cell_regions'],deadline_ns=deadline)
  cue_record={'cue':'filled','sequence':now['sequence'],'artifact_sha256':now['native']['artifact']['sha256']}
  semantic.arm(now,now_rgb,cue_record=cue_record);context=now_rgb.crop(refs['context_region']).tobytes()
  def guard(stage,native,image):return semantic.validate_capture(native,image) and image.crop(refs['context_region']).tobytes()==context
  with b.input_guard('fresh_save',ref['offset'],tail=save_tail,verify=guard,interaction='keyboard'):
   save_result=b.keyboard('fresh_save',ref['offset'],tail=save_tail,expires_at_ns=deadline)
  (out/'fresh-semantic-guard.json').write_text(json.dumps({'events':semantic.events,'cue':cue_record},indent=2)+'\n')
  (out/'fresh-save.json').write_text(json.dumps(save_result,indent=2)+'\n')
  if save_result.get('status')!='completed' or not all(r.get('verified') and not r.get('keys_down') and not r.get('buttons_down') for r in save_result.get('execution',{}).get('releases',[])):raise RuntimeError('fresh save failed')
  method={'status':'completed','second_model_response':second}
 else:raise RuntimeError('invalid route')
 result={'window':found[0],'initial_observation':obs,'model_response':response,'method':method,'route':route,'method_start_ns':method_start,'method_end_ns':time.monotonic_ns()}
 close=owner.close();owner=None;b=None;result['close']=close
 keys=d.query_keymap();result['keys_down']=[i for i in range(256) if keys[i//8]&(1<<(i%8))];result['buttons']=int(d.screen().root.query_pointer().mask)&(X.Button1Mask|X.Button2Mask|X.Button3Mask)
 doc=Path('/tmp/blank.fods');blob=doc.read_bytes();(out/'saved.fods').write_bytes(blob);result['saved_score']=score_saved(blob);result['task_start_ns']=task_start_ns;result['task_end_ns']=time.monotonic_ns()
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
finally:
 if Path('/tmp/blank.fods').exists(): (out/'finally-saved.fods').write_bytes(Path('/tmp/blank.fods').read_bytes())
 if owner is not None:
  closed=owner.close();keys=d.query_keymap() if d is not None else None
  (out/'final-neutral.json').write_text(json.dumps({'close':closed,'keys_down':[i for i in range(256) if keys[i//8]&(1<<(i%8))] if keys is not None else None,'buttons':int(d.screen().root.query_pointer().mask)&(X.Button1Mask|X.Button2Mask|X.Button3Mask) if d is not None else None},indent=2)+'\n')
 elif b is not None:b.close()
 if d is not None:d.close()
 for p in reversed(actors):
  if p.poll() is None:
   try:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=3)
   except ProcessLookupError:pass
 for f in handles:f.close()

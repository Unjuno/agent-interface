"""Simulate close racing with in-progress retirement after early wake."""
import json,tempfile,threading,time
from runtime.cli_v1.owned_guarded_session import OwnedGuardedSessionOwner

class Process:
 def __init__(self):self.alive=True;self.exitcode=None;self.calls=0;self.lock=threading.Lock();self.first=threading.Event();self.second=threading.Event();self.release=threading.Event()
 def is_alive(self):return self.alive
 def terminate(self):
  with self.lock:
   self.calls+=1
   if self.calls==1:self.first.set()
   if self.calls==2:self.second.set()
  if not self.release.wait(2):raise RuntimeError('fixture timeout')
  self.alive=False;self.exitcode=-15
 def join(self,timeout):pass
class Rpc:
 def __init__(self):self.entered=threading.Event();self.release=threading.Event()
 def send(self,request):pass
 def recv(self):
  self.entered.set();self.release.wait(3)
  return {'ok':True,'snapshot':{'state':'open','review_required':False},'result':{'status':'observed'}}

with tempfile.TemporaryDirectory() as td:
 owner=OwnedGuardedSessionOwner({'app':20},td,':fake',process_identity=True,query_worker=True,observation_worker=True)
 process=Process();rpc=Rpc();owner._process=process;owner._rpc=rpc;owner.state='open';result={}
 def observe():
  try:result['observe']=owner.observe_idle_until(deadline_ns=time.monotonic_ns()+2_000_000_000,cancel_token='idle')
  except Exception as error:result['observe_error']=repr(error)
 def retire():result['retire']=owner.retire('probe retirement')
 def close():result['close']=owner.close()
 reader=threading.Thread(target=observe);retirer=threading.Thread(target=retire);closer=threading.Thread(target=close)
 try:
  reader.start();assert rpc.entered.wait(1);retirer.start();assert process.first.wait(1);reader.join(.5)
  result['waiter_returned_while_retirement_blocked']=not reader.is_alive()
  closer.start();result['second_terminate_before_first_finished']=process.second.wait(.5)
 finally:
  process.release.set();rpc.release.set()
  for worker in (reader,retirer,closer):
   if worker.ident is not None:worker.join(3)
 result['terminate_calls']=process.calls;result['threads_alive']=[worker.is_alive() for worker in (reader,retirer,closer)]
 print(json.dumps(result,indent=2))
 assert result['waiter_returned_while_retirement_blocked'] and result['second_terminate_before_first_finished'] and result['terminate_calls']==2 and not any(result['threads_alive'])

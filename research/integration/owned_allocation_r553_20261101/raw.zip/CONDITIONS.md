# Partial startup allocation cleanup r553

Run `OwnedStartCloseTests` once normally and once under Python `-O` in separate
fresh isolated Linux containers. Eleven direct cases should pass in each mode;
they include failure of the second pipe, RawArray and Process construction,
and a failure while closing an already allocated pipe. Injected close failure
must remain UNKNOWN and cannot be a verified close. The Fake X child tests and
their fixture cleanup do not exercise real input. Any unexpected exception or
fixture cleanup failure is an error. The independent MCP shutdown custody
regression remains failing and is not included in this direct-test result.

Use image sha256:bd191d30ea94871a1d3ca717252cd07a276e8ef7d1bcb4a130b63935ce075425,
Docker `--network none --cpus 1 --memory 1g --pull never`, source mounted
read-only, no GUI/physical input and bytecode disabled. Save source base/diff,
logs and exits. A failure inside a single `Pipe()` before it returns handles,
unhandled BaseException in cleanup, unregistered child resolution, event queues
and actual OS allocation-failure frequency remain unproven.

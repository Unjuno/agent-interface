# Parent RPC overlap: real owner and private Xvfb

Source is the isolated r100 exclusivity candidate based on draft PR #10074 at
`0675ab810f7ee890d0904b8a402678c81f8dbafb`. Main at freeze was
`21c3333cbe71fb582842fdd29b8b0385853824ce`. The candidate is not merged.
Each arm used a new WSLc container with one CPU, 1 GiB memory limit, network
disabled, and the pinned image recorded in `conditions.json`. The source,
target, runner and trial were hashed before either arm.

| Arm | Controlled parent pause | Conflicting entry | Result after resume |
| --- | --- | --- | --- |
| ordinary | ordinary RPC holds parent lock before send | idle observation refused | same owner typed `a`, release verified, input neutral, close confirmed |
| idle | idle response received but parent return held | ordinary guarded RPC refused; close deferred without release | same owner typed `a`, release verified, input neutral, close confirmed |

Both arms passed their fixed checks; target and Xvfb exited with status zero.
Raw result, target events, logs, conditions and launcher status are preserved
inside each allocation directory. The rejection is exercised against a real
spawned owner and Xvfb target, but the pause is injected in the parent and no
input was held during the overlap. There was no actual cancellation during the
pause, no finite-recovery proof, no stressed simultaneous-start schedule, and
no MAP01 or model claim. See `../idle-rpc-overlap-r100/RESULTS.md` for the
original mock routing counterexample, local candidate, and regression tests.

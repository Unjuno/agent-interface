import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parent
files=[p for p in (root/'src').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']+[root/n for n in ('trial.py','target.py','run.py','prepare.py')]
manifest={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
arms=[('r101-ordinary','ordinary'),('r101-idle','idle')]
for ident,mode in arms:
 p=root/ident;p.mkdir(exist_ok=False);(p/'output').mkdir()
 c={'allocation':'idle-rpc-realx-'+ident,'mode':mode,'order':arms,'main_at_freeze':'21c3333cbe71fb582842fdd29b8b0385853824ce','draft_head':'0675ab810f7ee890d0904b8a402678c81f8dbafb','image':'sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25','manifest_sha256':hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest(),'protocol':'private Xvfb, real owned process; controlled parent pause before ordinary RPC send or after idle response recv; conflicting entry refused, after resume same owner performs target a with release','criteria':'correct refusal; idle close deferred while response paused; target a and release confirmed, neutral input, normal cleanup','stop':'one try per arm; preserve failure; stop block on any failure or unknown cleanup','limits':'synthetic parent pause, no held input during overlap, no actual cancellation, no hard real-time or MAP01 claim'}
 (p/'conditions.json').write_text(json.dumps(c,indent=2)+'\n')
print('two real-owner boundary arms frozen')

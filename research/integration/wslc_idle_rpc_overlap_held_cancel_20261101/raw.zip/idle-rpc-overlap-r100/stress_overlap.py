"""Stress simultaneous entry for the isolated candidate, no GUI or input."""
import collections,json,threading,time
from test_overlap import make_owner

outcomes=collections.Counter();errors=[]
for iteration in range(200):
 owner=make_owner();gate=threading.Barrier(3);release=threading.Event();entered=threading.Event();results=[];lock=threading.Lock()
 def held(kind):
  with lock:results.append((kind,'entered'))
  entered.set()
  if not release.wait(2):raise RuntimeError('fixture timeout')
  return kind
 owner._request_locked=lambda method,args:held('ordinary')
 owner._observe_idle_until_registered=lambda **kwargs:held('idle')
 def attempt(kind):
  gate.wait()
  try:
   value=owner._call('invoke_guarded') if kind=='ordinary' else owner.observe_idle_until(deadline_ns=time.monotonic_ns()+2_000_000_000,cancel_token='idle')
   with lock:results.append((kind,'returned'))
  except RuntimeError as error:
   with lock:results.append((kind,'rejected',str(error)))
 a=threading.Thread(target=attempt,args=('ordinary',));b=threading.Thread(target=attempt,args=('idle',));a.start();b.start();gate.wait()
 if not entered.wait(1):errors.append({'iteration':iteration,'error':'neither entered'})
 end=time.monotonic()+1
 while time.monotonic()<end:
  with lock:
   if any(row[1]=='rejected' for row in results):break
  time.sleep(.001)
 release.set();a.join(2);b.join(2)
 with lock:snapshot=list(results)
 entries=[row[0] for row in snapshot if row[1]=='entered'];rejects=[row[0] for row in snapshot if row[1]=='rejected'];returned=[row[0] for row in snapshot if row[1]=='returned']
 if len(entries)!=1 or len(rejects)!=1 or returned!=entries or entries[0]==rejects[0] or a.is_alive() or b.is_alive():errors.append({'iteration':iteration,'results':snapshot,'alive':[a.is_alive(),b.is_alive()]})
 else:outcomes[entries[0]+'_entered']+=1
result={'status':'pass' if not errors else 'fail','iterations':200,'outcomes':dict(outcomes),'errors':errors}
print(json.dumps(result,indent=2));raise SystemExit(bool(errors))

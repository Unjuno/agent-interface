"""Deterministic in-process routing probe, no real input or GUI."""
import json,threading,time
from unittest.mock import Mock
from runtime.cli_v1.owned_guarded_session import OwnedGuardedSessionOwner

owner=OwnedGuardedSessionOwner.__new__(OwnedGuardedSessionOwner)
owner._idle_quarantine_lock=threading.RLock();owner._rpc_lock=threading.Lock()
owner._idle_rpc_quarantined=False;owner._idle_rpc_inflight=False;owner._idle_observation_used=False
owner._idle_cancel_calls_inflight=0;owner._cancel_calls_inflight=0;owner._idle_closing=False
owner._process=object();owner.state='open';owner._execution_unknown=False;owner.review_required=False
entered=threading.Event();resume=threading.Event();idle_done=threading.Event();results={}
class Rpc:
 def send(self,request):results['idle_sent']=request['operation']
 def recv(self):return {'ok':True,'result':{'status':'observed'}}
owner._rpc=Rpc()
def blocking_request(method,arguments):
 entered.set()
 if not resume.wait(3):raise RuntimeError('fixture timed out')
 return {'status':'ordinary-finished'}
owner._request_locked=blocking_request
owner._cancel_idle_without_cleanup=Mock(return_value={'route':'idle'})
owner._cancel_guarded_normal=Mock(return_value={'route':'ordinary'})
def ordinary():results['ordinary']=owner._call('invoke_guarded')
def idle():
 try:results['idle']=owner.observe_idle_until(deadline_ns=time.monotonic_ns()+2_000_000_000,cancel_token='idle-token')
 except Exception as e:results['idle_error']=repr(e)
 finally:idle_done.set()
t1=threading.Thread(target=ordinary);t2=threading.Thread(target=idle)
t1.start();assert entered.wait(1);t2.start()
end=time.monotonic()+1
while not owner._idle_rpc_inflight and time.monotonic()<end:time.sleep(.001)
assert owner._idle_rpc_inflight and t1.is_alive() and 'idle_sent' not in results
results['cancel_route']=owner.cancel_guarded('ordinary-token')
results['idle_route_calls']=owner._cancel_idle_without_cleanup.call_count
results['ordinary_route_calls']=owner._cancel_guarded_normal.call_count
resume.set();t1.join(2);t2.join(2)
results['threads_finished']=not t1.is_alive() and not t2.is_alive()
print(json.dumps(results,indent=2))
assert results['cancel_route']['route']=='idle' and results['ordinary_route_calls']==0 and results['threads_finished']

# Idle reservation versus ordinary RPC: isolated prototype

Base: draft PR #10074 head `0675ab810f7ee890d0904b8a402678c81f8dbafb`;
main at start `21c3333cbe71fb582842fdd29b8b0385853824ce`. Neither the draft
nor this local candidate has been merged. Source is an isolated copy.

`reproduce.py` holds an ordinary `_call` in a fake `_request_locked` while
another thread registers an idle observation. Before the idle RPC can acquire
the shared RPC lock, `cancel_guarded` for the ordinary token takes the idle
cancel branch. `result.json` records that branch selection. Both branches are
mocked: no actual input, process termination, release failure or task effect is
demonstrated. The relevant cause is that `_idle_rpc_inflight` was set before
obtaining the RPC lock, while ordinary calls did not reject this reservation;
the cancel dispatcher uses that flag to select its cleanup policy.

The local candidate rejects idle reservation if the ordinary RPC lock is busy
and rejects ordinary calls while idle is reserved, checking again after the
ordinary call acquires the lock. The nonblocking acquisition under the idle
state lock avoids waiting while holding locks in the reverse order. The two
targeted tests failed before the change (`red.txt`) and passed after
(`green.txt`). They use controlled threads and mocked request/cancel methods;
they do not establish behavior of a real blocked child or GUI.

The selected existing WSLc regression suite ran 90 tests normally and 90 under
Python `-O`, both passing (`tests-normal/`, `tests-optimized/`). The source hash
manifest and per-run conditions are saved. Remaining work includes independent
review of lock ordering and all alternate operation entry points, real-X tests
with actual held input and cancellation, bounded cleanup, and integration with
the draft author's changes. No safety or finite recovery claim follows from
these unit tests alone.

The independent `stress_overlap.py` probe subsequently synchronized 200 pairs
of ordinary and idle entry attempts against the candidate in one Windows Python
process. Exactly one entered per iteration: ordinary 51 times, idle 149 times;
no thread was left alive (`stress-results.json`). It uses stubbed operations and
bounded waits, is not a proof over all thread schedules, and does not exercise
child processes or held input. The `get()`, `snapshot()` and `retire()` public
methods do not enter the normal RPC helper: the first two have distinct
startup/read semantics, and explicit retirement is a separate termination path.
Those paths and startup/retirement races remain outside this exclusivity claim.

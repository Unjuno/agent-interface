"""Synthetic local-history insertion cost; no capture, input, model or disk read."""
import gc,hashlib,json,os,pathlib,resource,statistics,time,tracemalloc
from PIL import Image
from runtime.guarded_x11_v1.history import ObservationHistory
out=pathlib.Path('/out');image=Image.new('RGB',(16,16),(25,50,75));raw=hashlib.sha256(image.tobytes()).hexdigest()
sizes=[0,1000,10000,100000]
if os.environ['ORDER']=='descending':sizes.reverse()
def row(n):
 return ({'sequence':n,'native':{'width':16,'height':16,'sha256':raw,
          'artifact':{'path':f'/synthetic/{n}.png','sha256':'0'*64,'source_raw_sha256':raw}}},image)
results=[];gc.collect();gc.disable()
try:
 for n in sizes:
  history=ObservationHistory(2)
  for i in range(n):history[i]=row(i)
  candidate=row(n+1);samples=[]
  for i in range(41):
   order=('baseline','fork') if i%2==0 else ('fork','baseline')
   sample={'index':i,'order':list(order)}
   for op in order:
    start=time.perf_counter_ns()
    if op=='baseline':
     history[n+1]=candidate;elapsed=time.perf_counter_ns()-start
     del history[n+1]
    else:
     staged=history.fork();staged[n+1]=candidate;elapsed=time.perf_counter_ns()-start
     del staged
    sample[op+'_ns']=elapsed
   samples.append(sample)
  tracemalloc.start();staged=history.fork();staged[n+1]=candidate
  current,peak=tracemalloc.get_traced_memory();tracemalloc.stop();del staged
  assert len(history)==n and (n+1) not in history
  results.append({'size':n,'samples':samples,'fork_traced_current_bytes':current,'fork_traced_peak_bytes':peak,
                  'baseline_median_ns':statistics.median(x['baseline_ns'] for x in samples),
                  'fork_median_ns':statistics.median(x['fork_ns'] for x in samples),
                  'process_maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})
  del history
finally:gc.enable()
r={'status':'completed','order':os.environ['ORDER'],'sizes':sizes,'sample_count':41,'cache_capacity':2,
   'results':results,'clock':'perf_counter_ns','gc_disabled_during_measurement':True,
   'limits':'synthetic metadata and shared 16x16 image; no screenshot, disk reload, persistence, IPC, model, input, cleanup or task time'}
(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)

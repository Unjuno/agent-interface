import hashlib,json,os,sys,time
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'adapter'))
import integrated_efficiency_app_server_model_v1 as adapter
current_size=None
def validate(v):
 if type(v) is not dict or set(v)!={'action','target_x','target_y','duration_ms'}:raise ValueError('invalid fields')
 if v['action'] not in ('fire','idle') or any(type(v[k]) is not int for k in ('target_x','target_y','duration_ms')):raise ValueError('invalid values')
 if not 0<=v['target_x']<current_size[0] or not 0<=v['target_y']<current_size[1]:raise ValueError('point outside submitted image')
 if v['duration_ms'] not in (0,500,1000,1500,2000) or (v['action']=='idle')!=(v['duration_ms']==0):raise ValueError('invalid duration')
 return v
adapter.CONTRACTS['policy']=(root/'policy-schema.json',root/'policy-instructions.txt',validate)
prompt=('In this Doom screenshot, choose fire only if a hostile character is visibly near the center, otherwise idle. For fire return the center of that hostile as integer target_x and target_y in pixels of the supplied image and duration_ms 500. For idle return target_x=0, target_y=0, duration_ms=0. Do not operate anything.')
plan=json.loads((root/'freeze.json').read_text());assert hashlib.sha256(prompt.encode()).hexdigest()==plan['prompt_sha256']
for case in plan['order']:
 run=root/case['id'];run.mkdir(exist_ok=False);workspace=run/'workspace';workspace.mkdir();image=root/'inputs'/case['image'];current_size=tuple(case['size']);result={'id':case['id'],'scene':case['scene'],'arm':case['arm'],'status':'started','image_sha256':hashlib.sha256(image.read_bytes()).hexdigest()};model=None
 try:
  assert result['image_sha256']==plan['inputs_sha256'][case['image']]
  model=adapter.PersistentGroundingModel(run/'model-session',workspace,executable=sys.argv[1],contract='policy',model='gpt-6.1-sol',effort='low',path_converter=lambda p:str(Path(p).resolve()))
  value=model.call(run/'model-call',prompt,image,'policy',workspace);result.update(status='completed',grounding=value['grounding'],usage=value['usage'],call_id=value['call_id'],runner_ns=value['runner_ns'])
 except BaseException as e:result.update(status='error',error=type(e).__name__,detail=str(e)[:500],call_id=getattr(e,'call_id',None),usage=getattr(e,'usage',None))
 finally:
  if model is not None:
   try:model.close();result['session_closed']=True
   except BaseException as e:result.update(status='error',session_closed=False,close_error=type(e).__name__)
  (run/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'id':case['id'],'status':result['status'],'action':result.get('grounding',{}).get('action')}),flush=True)
 if result['status']!='completed':break

# Diagnostic attempts retained

These are intermediate failing and passing test logs from development of the provider-wait experiment. They are retained for provenance. Only `calc-provider-wait-evidence-20261103-r16` and `r17` are the final raw runs; the overview README records the earlier artifact-injection limitation and later correction.

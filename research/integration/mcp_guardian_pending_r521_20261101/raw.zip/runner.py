import json,os,select,signal,subprocess,sys,time
from pathlib import Path

out=Path('/out');owned=[];result={'status':'ERROR'};parent=None
sentinel=subprocess.Popen([sys.executable,'-c','import time;time.sleep(30)'])
sentinel_fd=os.pidfd_open(sentinel.pid)
def exited(fd,ms=0):
    p=select.poll();p.register(fd,select.POLLIN);return bool(p.poll(ms))
try:
    started=time.monotonic_ns()
    with (out/'parent-stderr.txt').open('wb') as err:
        parent=subprocess.Popen([sys.executable,'/fixture/parent.py'],stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,stderr=err)
        ready,_,_=select.select([parent.stdout],[],[],10)
        if not ready:raise TimeoutError('parent readiness')
        line=parent.stdout.readline().decode();identity=json.loads(line)
        (out/'parent-stdout.txt').write_text(line)
        for role in ('owner','supervisor','guardian','display'):
            fd=os.pidfd_open(identity[role+'_pid']);owned.append((role,fd))
        fds=dict(owned)
        parent.stdin.write(b'X');parent.stdin.flush();parent.stdin.close();parent.wait(timeout=8)
        elapsed=(time.monotonic_ns()-started)/1e6
        if parent.returncode!=0:raise RuntimeError('parent failed')
        receipt_path=out/'guardian-receipt.json';end=time.monotonic()+8
        while not receipt_path.exists() and time.monotonic()<end:time.sleep(.01)
        if not receipt_path.exists():raise TimeoutError('no guardian receipt')
        receipt=json.loads(receipt_path.read_text());rows={r['role']:r for r in receipt['rows']}
        checks={'old_press':identity['old_press_observed'] is True,
            'old_key_down':identity['old_key_down'] is True,'old_action_active':identity['action_pending'] is True,
            'guardian_prestarted':identity['guardian_ready_ns']<identity['action_started_ns'],
            'cancel_pending':identity['cancel_response']['status']=='pending',
            'cancel_id_bound':identity['cancel_response']['operation_id']==identity['cancel_gate']['operation_id'],
            'commit':identity['committed'] is True,'token':receipt['token']==identity['token'],
            'owner_identity':rows['owner']['pid']==identity['owner_pid'],
            'supervisor_identity':rows['supervisor']['pid']==identity['supervisor_pid'],
            'owner_exit':rows['owner']['signal_sent'] and rows['owner']['exit_observed'] and exited(fds['owner']),
            'supervisor_exit':rows['supervisor']['signal_sent'] and rows['supervisor']['exit_observed'] and exited(fds['supervisor']),
            'display_alive':not exited(fds['display']),'sentinel_alive':not exited(sentinel_fd),
            'parent_bounded':elapsed<8000}
        result={'status':'PASS' if all(checks.values()) else 'FAIL','identity':identity,
            'parent_elapsed_ms':elapsed,'guardian_receipt':receipt,'checks':checks}
        if checks['display_alive']:
            try:
                from Xlib import XK,display
                os.environ['XAUTHORITY']=identity['authority']
                app=display.Display(identity['display']);code=app.keysym_to_keycode(XK.string_to_keysym('a'))
                bits=app.query_keymap();result['post_retirement_key_down']=bool(bits[code//8] & (1 << (code%8)))
                app.close()
            except Exception as error:result['post_retirement_keymap_error']=repr(error)
except BaseException as error:
    result['error']=repr(error)
finally:
    if parent is not None and parent.poll() is None:parent.kill();parent.wait(timeout=3)
    cleanup=[]
    for role,fd in owned+[('sentinel',sentinel_fd)]:
        if not exited(fd):
            try:signal.pidfd_send_signal(fd,signal.SIGKILL)
            except ProcessLookupError:pass
        dead=exited(fd,3000);cleanup.append({'role':role,'exit_observed':dead});os.close(fd)
    sentinel.wait(timeout=3);result['cleanup']=cleanup
    if not all(x['exit_observed'] for x in cleanup):result['status']='ERROR'
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'error':result.get('error')}),flush=True)
sys.exit(0 if result['status']=='PASS' else 1)

import array,json,os,select,signal,socket,sys,time
from pathlib import Path

sock=socket.socket(fileno=int(sys.argv[1]));out=Path(sys.argv[2]);token=sys.argv[3];fds=[]
try:
    sock.settimeout(5);size=array.array('i').itemsize
    data,anc,flags,_=sock.recvmsg(1,socket.CMSG_SPACE(size*2))
    for level,kind,value in anc:
        if (level,kind)==(socket.SOL_SOCKET,socket.SCM_RIGHTS):
            a=array.array('i');a.frombytes(value[:len(value)//size*size]);fds.extend(a)
    if data!=b'P' or flags & (socket.MSG_CTRUNC|socket.MSG_TRUNC) or len(fds)!=2:
        raise RuntimeError('invalid descriptor transfer')
    pids=[]
    for fd in fds:
        info=Path('/proc/self/fdinfo',str(fd)).read_text()
        pid=int(next(x.split(':',1)[1] for x in info.splitlines() if x.startswith('Pid:')))
        if pid<=1:raise RuntimeError('invalid pidfd')
        pids.append(pid)
    if len(set(pids))!=2:raise RuntimeError('duplicate process')
    sock.sendall(b'R')
    if sock.recv(1)!=b'C':raise RuntimeError('uncommitted')
    sock.sendall(b'A');sock.settimeout(10)
    if sock.recv(1)!=b'':raise RuntimeError('unexpected message')
    rows=[]
    for role,fd,pid in zip(('owner','supervisor'),fds,pids):
        try:signal.pidfd_send_signal(fd,signal.SIGKILL);sent=True
        except ProcessLookupError:sent=False
        poll=select.poll();poll.register(fd,select.POLLIN);dead=bool(poll.poll(3000))
        rows.append({'role':role,'pid':pid,'signal_sent':sent,'exit_observed':dead})
    result={'token':token,'rows':rows,'release_confirmed':False,'task_success':None,
            'replay_allowed':False,'finished_ns':time.monotonic_ns()}
    temp=out/'guardian-receipt.tmp';temp.write_text(json.dumps(result,indent=2));os.replace(temp,out/'guardian-receipt.json')
finally:
    for fd in fds:os.close(fd)
    sock.close()

import hashlib,json,subprocess,sys,time
from pathlib import Path
root=Path(sys.argv[1]);r={'source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ('win_job_spawn.py','test_win_job_stdio.py','run.py')},'runs':[]}
for name,extra in [('normal',[]),('optimized',['-O'])]:
 start=time.monotonic_ns()
 try:
  p=subprocess.run([sys.executable,*extra,'-m','unittest','-v','test_win_job_stdio'],cwd=root,capture_output=True,timeout=30,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
  (root/(name+'.stdout')).write_bytes(p.stdout);(root/(name+'.stderr')).write_bytes(p.stderr);r['runs'].append({'name':name,'exit':p.returncode,'started_ns':start,'ended_ns':time.monotonic_ns()})
 except subprocess.TimeoutExpired as e:
  (root/(name+'.stdout')).write_bytes(e.stdout or b'');(root/(name+'.stderr')).write_bytes(e.stderr or b'');r['runs'].append({'name':name,'status':'timeout','started_ns':start,'ended_ns':time.monotonic_ns()})
(root/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'exits':[x.get('exit') for x in r['runs']]}))

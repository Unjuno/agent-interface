# Owned lifecycle busy receipts r551

Before this run, execute exactly three scoped tests in order: direct startup/
close busy handling, manual MCP busy result with old canonical receipt preserved
and per-call report retained, then shutdown busy with an independently signalled
pending write, old canonical retained and a separate UNKNOWN pending receipt.
All three should pass as receipt tests; the third does not assert post-shutdown
owner retirement and its fixture kills any remaining child. The separate custody
regression remains known failing and is not converted to a pass by this run.

One normal Python run in pre-existing image
sha256:bd191d30ea94871a1d3ca717252cd07a276e8ef7d1bcb4a130b63935ce075425,
Docker `--network none --cpus 1 --memory 1g --pull never`, read-only source and
dedicated writable evidence mount. Fake X, direct private owner startup and
fixture gates; no real GUI or user input. Save source base/diff, output, exit and
raw synthetic receipts. Pending write failure, process interruption, conflicting
closes, stable ordering/consumer interpretation and retained-child custody remain
outside the success claim.

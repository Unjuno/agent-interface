"""One-arm lifecycle timer. No cross-machine clock subtraction."""
from pathlib import Path
import json,os,subprocess,sys,time
from jsonschema import Draft202012Validator
root=Path(__file__).resolve().parent;arm=sys.argv[1];allocation=sys.argv[2]
if arm not in ('plain','persistent','ephemeral'):raise SystemExit('invalid arm')
p=root/allocation;source=root.parent/'wslc-three-arm-main-configured-20261031'/'source';hostsource=source/'research'/'live_control';exchange=p/'exchange';out=p/'out';codex=Path(os.environ['LOCALAPPDATA'])/'OpenAI/Codex/bin/22cfb1d302613eae/codex.exe';hostpython=Path(os.environ['USERPROFILE'])/'.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
clock=time.perf_counter_ns;events={};host=None;container=None;failure=None
flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
def mark(name):
 events[name]=clock();(p/'launcher-progress.json').write_text(json.dumps(events,indent=2)+'\n')
def persist(result):
 (p/'launcher-result.json').write_text(json.dumps(result,indent=2)+'\n')
try:
 env=os.environ.copy();env['PYTHONPATH']=str(hostsource);env['PYTHONDONTWRITEBYTECODE']='1'
 mark('start_ns')
 with (p/'host.stdout').open('wb') as ho,(p/'host.stderr').open('wb') as he:
  host=subprocess.Popen([str(hostpython),str(root/'host.py'),str(codex),str(p),arm],cwd=root,env=env,stdout=ho,stderr=he,creationflags=flags);mark('host_started_ns')
  deadline=time.monotonic()+120
  while not (p/'preflight.json').exists():
   if host.poll() is not None:raise RuntimeError('host exited before preflight')
   if time.monotonic()>deadline:raise TimeoutError('preflight deadline')
   time.sleep(.05)
  mark('preflight_ready_ns');pre=json.loads((p/'preflight.json').read_text());rows=json.loads((p/'preflight-summary.json').read_text())
  if not pre.get('accepted') or len(rows)!=1 or rows[0]['arm']!=arm or not rows[0]['completed'] or rows[0]['usage'] is None:raise RuntimeError('preflight not eligible')
  schema=json.loads((hostsource/('plain_form_points_schema_v1.json' if arm=='plain' else 'compiled_form_grounding_schema_v1.json')).read_text());errors=[e.message for e in Draft202012Validator(schema).iter_errors(rows[0]['answer'])];(p/'schema-audit.json').write_text(json.dumps({'arm':arm,'valid':not errors,'errors':errors},indent=2)+'\n')
  if errors:raise RuntimeError('schema validation failed')
  mark('schema_checked_ns')
  cmd=['wslc','run','--rm','--name','three-arm-lifecycle-'+allocation+'-20261031','--network','none','--cpus','1','--memory','1g','--pull','never','--entrypoint','/bin/sh','--mount',f'type=bind,source={source},target=/source,readonly','--mount',f'type=bind,source={root},target=/in,readonly','--mount',f'type=bind,source={out},target=/out','--mount',f'type=bind,source={exchange},target=/exchange','--env','ARM='+arm,'--env','AGENT_INTERFACE_CHROMIUM=/usr/bin/chromium','sha256:9841e60e91b1c037a8e7de6a7cb9737558352b15f052912d92af819487fe02ba','/in/start.sh']
  with (p/'container.stdout').open('wb') as co,(p/'container.stderr').open('wb') as ce:
   mark('container_invoked_ns');container=subprocess.Popen(cmd,stdout=co,stderr=ce,creationflags=flags);container_exit=container.wait(timeout=240);mark('container_exited_ns')
  host_exit=host.wait(timeout=30);mark('host_exited_ns')
  outcome=json.loads((out/'result.json').read_text());independent=outcome['independent'][arm];rows=outcome['arms'][arm]
  if container_exit or host_exit or not outcome['passed'] or len(rows)!=6 or not independent['success']:raise RuntimeError('arm did not complete successfully')
  result={'status':'completed','arm':arm,'allocation':allocation,'events':events,'lifecycle_ns':events['host_exited_ns']-events['start_ns'],'container_exit':container_exit,'host_exit':host_exit,'task_count':len(rows),'model_calls':outcome['calls']}
except BaseException as e:
 failure={'type':type(e).__name__,'detail':str(e)};result={'status':'error','arm':arm,'allocation':allocation,'events':events,'error':failure,'container_running':container is not None and container.poll() is None,'host_running':host is not None and host.poll() is None}
finally:
 persist(result)
print(json.dumps({'status':result['status'],'arm':arm,'lifecycle_ns':result.get('lifecycle_ns'),'error':failure}),flush=True)
raise SystemExit(0 if result['status']=='completed' else 1)

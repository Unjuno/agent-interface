"""Controlled parent-side retirement/response race; no real process or input."""
import json,tempfile,threading,time
from runtime.cli_v1.owned_guarded_session import OwnedGuardedSessionOwner

class Process:
 def __init__(self):self.alive=True;self.exitcode=None
 def is_alive(self):return self.alive
 def terminate(self):self.alive=False;self.exitcode=-15
 def join(self,timeout):pass
class Rpc:
 def __init__(self):self.entered=threading.Event();self.resume=threading.Event()
 def send(self,request):pass
 def recv(self):
  self.entered.set()
  if not self.resume.wait(2):raise RuntimeError('fixture timed out')
  return {'ok':True,'snapshot':{'state':'open','review_required':False},'result':{'status':'observed'}}

with tempfile.TemporaryDirectory() as td:
 owner=OwnedGuardedSessionOwner({'app':20},td,':fake',process_identity=True,query_worker=True,observation_worker=True)
 owner._process=Process();owner._rpc=Rpc();owner.state='open';results={}
 def invoke():
  try:results['response']=owner.observe_idle_until(deadline_ns=time.monotonic_ns()+1_000_000_000,cancel_token='idle')
  except Exception as e:results['error']=repr(e)
 worker=threading.Thread(target=invoke);worker.start();assert owner._rpc.entered.wait(1)
 results['retire']=owner.retire('fixture retirement');results['state_after_retire']=owner.state
 owner._rpc.resume.set();worker.join(2)
 results.update(state_after_late_response=owner.state,review_required=owner.review_required,process_alive=owner._process.is_alive(),worker_alive=worker.is_alive())
 print(json.dumps(results,indent=2))
 assert results['retire']['retired'] and results['state_after_retire']=='failed' and results['state_after_late_response']=='open' and results.get('response',{}).get('status')=='observed'

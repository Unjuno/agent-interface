# Retired owner and late idle response: controlled parent race

Starting from draft #10094 at `3e9d295e3ff1602bec844ea3610c0ec5a9cfee44`,
`probe.py` pauses a simulated idle RPC response, retires a simulated process,
then releases the old response. The original candidate accepted `observed`
and applied a stale `state=open` snapshot after retirement, despite the process
being dead (`probe-result.json`). This demonstrates a parent-side ordering
defect, not a real GUI, physical input, or task-effect outcome.

The isolated fix sets idle quarantine before process retirement and serializes
that decision with response validation and publication under the idle lock.
The targeted regression failed before the fix (`red.txt`) and passed after
(`green.txt`), discarding the old response and retaining failed/review-required
state. It waits until the existing idle deadline for the blocked caller; it does
not claim immediate cancellation, physical release, or general finite recovery.

On WSLc, 94 selected tests passed normally and 94 with Python `-O`; each run's
conditions, source hashes, stdout and stderr are retained in `tests-normal/`
and `tests-optimized/`. This includes the new simulated-retirement test and the
real spawned-owner Fake X exclusion test. The retirement-specific probe itself
does not kill a real child; real-owner retirement and X-server behavior remain
to be tested. Main and the parent draft are not changed by this local copy.

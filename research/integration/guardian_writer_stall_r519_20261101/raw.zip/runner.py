import json,os,select,signal,subprocess,sys,time
from pathlib import Path

out=Path('/out');results=[];owned=[];parents=[];status='ERROR'
sentinel=subprocess.Popen([sys.executable,'-c','import time; time.sleep(30)'])
sentinel_fd=os.pidfd_open(sentinel.pid)
def exited(fd, timeout_ms=0):
    p=select.poll();p.register(fd,select.POLLIN);return bool(p.poll(timeout_ms))
try:
    for mode in ('committed','uncommitted','writer_stalled'):
        start=time.monotonic_ns()
        parent=subprocess.Popen([sys.executable,'/fixture/parent.py',mode,str(out)],
            stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        parents.append(parent)
        ready,_,_=select.select([parent.stdout],[],[],5)
        if not ready:raise TimeoutError('parent readiness '+mode)
        line=parent.stdout.readline().decode();identity=json.loads(line)
        target_fd=os.pidfd_open(identity['child_pid']);owned.append((mode+'-target',target_fd))
        guardian_fd=os.pidfd_open(identity['guardian_pid']);owned.append((mode+'-guardian',guardian_fd))
        parent.stdin.write(b'X');parent.stdin.flush();parent.stdin.close();parent.wait(timeout=8)
        elapsed=(time.monotonic_ns()-start)/1e6
        (out/(mode+'-parent-stdout.txt')).write_text(line)
        (out/(mode+'-parent-stderr.txt')).write_bytes(parent.stderr.read())
        if parent.returncode!=0:raise RuntimeError('parent failed '+mode)
        receipt_path=out/(mode+'-receipt.json');receipt=None
        if mode=='writer_stalled':
            dead=exited(target_fd,3000);time.sleep(.2)
            guardian_alive=not exited(guardian_fd)
            checks={'target_exited':dead,'guardian_alive':guardian_alive,
                    'receipt_absent':not receipt_path.exists()}
        else:
            deadline=time.monotonic()+8
            while not receipt_path.exists() and time.monotonic()<deadline:time.sleep(.01)
            if not receipt_path.exists():raise TimeoutError('guardian receipt '+mode)
            receipt=json.loads(receipt_path.read_text());dead=exited(target_fd)
            checks={'identity':receipt['pid']==identity['child_pid'] and receipt['token']==identity['token'],
                'expected_outcome':(dead and receipt['status']=='observed_exit' and receipt['signal_sent'] is True)
                    if mode=='committed' else (not dead and receipt['status']=='uncommitted'
                                               and receipt['signal_sent'] is False)}
        checks.update(parent_exit_bounded=elapsed<8000,sentinel_alive=not exited(sentinel_fd))
        results.append({'mode':mode,'parent':identity,'parent_elapsed_ms':elapsed,'receipt':receipt,
                        'target_exit_observed':dead,'checks':checks})
        if not all(checks.values()):raise AssertionError(mode+' failed checks')
    status='PASS'
except BaseException as error:
    results.append({'error':repr(error)})
finally:
    for parent in parents:
        if parent.poll() is None:parent.kill();parent.wait(timeout=3)
    cleanup=[]
    for name,fd in owned+[('sentinel',sentinel_fd)]:
        if not exited(fd):
            try:signal.pidfd_send_signal(fd,signal.SIGKILL)
            except ProcessLookupError:pass
        dead=exited(fd,3000);cleanup.append({'name':name,'exit_observed':dead});os.close(fd)
    sentinel.wait(timeout=3)
    if not all(item['exit_observed'] for item in cleanup):status='ERROR'
    (out/'result.json').write_text(json.dumps({'status':status,'arms':results,'cleanup':cleanup,
        'sentinel_exitcode':sentinel.returncode},indent=2)+'\n')
    print(json.dumps({'status':status,'arms':len(results)}),flush=True)
sys.exit(0 if status=='PASS' else 1)

from Xlib import display
d=display.Display(':163')
d.grab_server();d.sync();print('GRABBED',flush=True)
import time
time.sleep(30)

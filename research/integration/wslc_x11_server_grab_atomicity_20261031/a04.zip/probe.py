from Xlib import display
d=display.Display(':163');d.screen().root.get_geometry();print('RESPONSIVE',flush=True);d.close()

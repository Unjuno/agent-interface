import os,time,json,signal,subprocess,sys
from pathlib import Path
from Xlib import X,display
from Xlib.ext import xtest
out=Path('/out');env=dict(os.environ,DISPLAY=':163');actors=[];d=None;other=None
try:
 x=subprocess.Popen(['Xvfb',':163','-screen','0','640x480x24','-nolisten','tcp','-ac'],env=env,stdout=subprocess.DEVNULL,stderr=(out/'xvfb.log').open('wb'),start_new_session=True);actors.append(x)
 for _ in range(100):
  try:d=display.Display(':163');break
  except Exception:time.sleep(.05)
 if d is None:raise RuntimeError('X server unavailable')
 if os.environ['MODE']=='atomic':
  root=d.screen().root;target=root.create_window(50,50,200,200,0,d.screen().root_depth,X.InputOutput,X.CopyFromParent,override_redirect=1,background_pixel=d.screen().white_pixel,event_mask=X.ButtonPressMask|X.ButtonReleaseMask);target.map();d.sync()
  other=display.Display(':163');r2=other.screen().root;overlay=r2.create_window(95,95,10,10,0,0,X.InputOnly,X.CopyFromParent,override_redirect=1,event_mask=X.ButtonPressMask|X.ButtonReleaseMask);other.sync()
  xtest.fake_input(d,X.MotionNotify,x=100,y=100);d.sync();before=root.translate_coords(root,100,100).child;before_id=getattr(before,'id',before)
  if before_id!=target.id:raise RuntimeError('target not initially at point')
  start=time.monotonic_ns();d.sync();acquired=time.monotonic_ns();overlay.map();other.sync();queued=time.monotonic_ns()
  inside=root.translate_coords(root,100,100).child;inside_id=getattr(inside,'id',inside)
  xtest.fake_input(d,X.ButtonPress,1);xtest.fake_input(d,X.ButtonRelease,1);d.sync();sent=time.monotonic_ns();d.sync();released=time.monotonic_ns();other.sync();d.sync()
  def events(conn):
   result=[]
   while conn.pending_events():
    e=conn.next_event();result.append({'type':e.type,'window':getattr(getattr(e,'window',None),'id',None),'detail':getattr(e,'detail',None)})
   return result
  te=events(d);oe=events(other);after=root.translate_coords(root,100,100).child;after_id=getattr(after,'id',after);mask=int(root.query_pointer().mask)&(X.Button1Mask|X.Button2Mask|X.Button3Mask)
  result={'mode':'atomic','target':target.id,'overlay':overlay.id,'before':before_id,'inside_grab':inside_id,'after_ungrab':after_id,'target_events':te,'overlay_events':oe,'buttons':mask,'grab_acquired_ns':acquired,'map_request_queued_ns':queued,'pair_completed_ns':sent,'ungrab_completed_ns':released,'held_ns':released-acquired}
  (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 elif os.environ['MODE']=='crash':
  holder=subprocess.Popen([sys.executable,'-u','/in/holder.py'],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);actors.append(holder)
  line=holder.stdout.readline().decode().strip()
  if line!='GRABBED':raise RuntimeError('holder did not confirm grab')
  probe=subprocess.Popen([sys.executable,'-u','/in/probe.py'],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);actors.append(probe);time.sleep(.5)
  blocked=probe.poll() is None
  if not blocked:raise RuntimeError('probe did not block')
  killed_at=time.monotonic_ns();holder.kill();holder.wait(timeout=3);stdout,stderr=probe.communicate(timeout=5);responsive_at=time.monotonic_ns()
  result={'mode':'crash','holder_confirmed_grab':True,'probe_blocked_before_kill':blocked,'holder_exit':holder.returncode,'probe_exit':probe.returncode,'probe_stdout':stdout.decode().strip(),'probe_stderr':stderr.decode()[-500:],'post_kill_wait_ns':responsive_at-killed_at}
  (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
 else:raise ValueError('mode')
finally:
 if other is not None:other.close()
 if d is not None:d.close()
 for p in reversed(actors):
  if p.poll() is None:
   try:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=3)
   except ProcessLookupError:pass

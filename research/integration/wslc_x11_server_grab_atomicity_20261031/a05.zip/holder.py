from Xlib import display,X
from Xlib.ext import xtest
d=display.Display(':163')
d.grab_server();d.sync();xtest.fake_input(d,X.ButtonPress,1);d.sync();print('GRABBED_DOWN',flush=True)
import time
time.sleep(30)

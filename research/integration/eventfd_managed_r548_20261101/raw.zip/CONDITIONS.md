# Managed eventfd close prototype r548

Before this run: six explicitly ordered tests in normal Python: successful
notification/readback, managed close followed by integer reuse, close error
injected before the syscall, close error injected after the syscall with number
reuse, parent close after descriptor transfer to a
spawned child, and unmanaged close plus `dup2` of an empty pipe. The first four
and the fifth should pass; the last is intentionally expected to fail because direct external
descriptor replacement circumvents the instance's lock and close state. A
failure in another case or fixture cleanup is an error, not success.

Run once in the pinned Linux Docker image
sha256:bd191d30ea94871a1d3ca717252cd07a276e8ef7d1bcb4a130b63935ce075425,
`--network none --cpus 1 --memory 1g --pull never`, source read-only and bytecode
disabled. Retain source base/diff, output and exit. The test does not run the
actual MCP owner, X input, cancellation or physical user interaction. It does not
prove fd lifecycle wiring, cross-process revocation, natural close errors,
hard syscall bounds, arbitrary external close safety or input release.

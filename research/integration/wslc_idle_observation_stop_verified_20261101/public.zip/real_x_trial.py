"""Private Xvfb cell: independently observe server stop and pending capture."""
import json,os,pathlib,signal,subprocess,sys,threading,time,traceback
from Xlib import X,display
from runtime.guarded_x11_v1.bridge import NativeHandleBridge
from runtime.backends.x11_v1.backend import X11BackendError

out=pathlib.Path('/out');out.mkdir(exist_ok=True)
result={'status':'started','display':':194','events':[]}
events=result['events']
def mark(name,**detail):events.append({'name':name,'monotonic_ns':time.monotonic_ns(),**detail})
def state(pid):
 for line in pathlib.Path(f'/proc/{pid}/status').read_text().splitlines():
  if line.startswith('State:'):return line.split()[1]
 raise RuntimeError('server state missing')
server=connection=bridge=capture=None
try:
 server=subprocess.Popen(['Xvfb',':194','-screen','0','640x480x24','-nolisten','tcp'],stdout=(out/'xvfb.log').open('wb'),stderr=subprocess.STDOUT)
 for _ in range(100):
  if server.poll() is not None:raise RuntimeError('Xvfb exited')
  try:connection=display.Display(':194');break
  except Exception:time.sleep(.05)
 if connection is None:raise RuntimeError('Xvfb unavailable')
 root=connection.screen().root
 window=root.create_window(10,10,160,100,0,connection.screen().root_depth,X.InputOutput,X.CopyFromParent,background_pixel=0x224466,event_mask=X.ExposureMask)
 window.map();connection.set_input_focus(window,X.RevertToParent,X.CurrentTime);connection.sync()
 bridge=NativeHandleBridge(':194',{'app':window.id},'app','/out/bridge',process_identity=True,query_worker=True,observation_worker=True)
 with bridge.cancellation_scope('healthy',cancel_when_idle=True,single_idle_observation=True):
  first=bridge.observe_idle_until(time.monotonic_ns()+2_000_000_000)
  result['healthy']={'sequence':first['sequence'],'late_cancel':bridge.request_cancel('healthy')['status']}
 before=bytes(connection.query_keymap());before_pointer=root.query_pointer().mask
 os.kill(server.pid,signal.SIGSTOP);mark('stop_sent')
 until=time.monotonic()+2
 while state(server.pid)!='T':
  if time.monotonic()>=until:raise RuntimeError('private Xvfb stop not observed')
  time.sleep(.002)
 mark('server_stop_observed',state=state(server.pid))
 deadline=time.monotonic_ns()+500_000_000;result['deadline_ns']=deadline
 capture_result={}
 def invoke():
  mark('capture_started')
  try:
   with bridge.cancellation_scope('stopped',cancel_when_idle=True,single_idle_observation=True):
    bridge.observe_idle_until(deadline)
   capture_result['status']='unexpected_source'
  except X11BackendError:capture_result['status']='unavailable'
  except BaseException as error:capture_result.update(status='error',error=repr(error))
  finally:mark('capture_returned',**capture_result)
 capture=threading.Thread(target=invoke);capture.start()
 observed=False
 while time.monotonic_ns()<deadline and capture.is_alive():
  snapshot=bridge._observations.snapshot()
  if snapshot['pending'] and snapshot['thread_alive'] and state(server.pid)=='T':
   worker=bridge._observations.thread
   try:wchan=pathlib.Path(f'/proc/self/task/{worker.native_id}/wchan').read_text().strip()
   except OSError as e:wchan='unavailable:'+type(e).__name__
   mark('pending_while_stopped',state='T',wchan=wchan);observed=True;break
  time.sleep(.002)
 if not observed:raise RuntimeError('pending capture before deadline not observed')
 capture.join(2)
 if capture.is_alive():raise RuntimeError('capture did not return')
 result['capture']=capture_result;result['server_state_after_return']=state(server.pid)
 result['sequence_before_resume']=bridge.sequence;result['worker_before_resume']=bridge._observations.snapshot()
 mark('before_resume');os.kill(server.pid,signal.SIGCONT);mark('resume_sent')
 until=time.monotonic()+3
 while bridge._observations.snapshot()['thread_alive'] and time.monotonic()<until:time.sleep(.02)
 result['worker_after_resume']=bridge._observations.snapshot();mark('worker_observed_after_resume')
 connection.sync();after=bytes(connection.query_keymap());after_pointer=root.query_pointer().mask
 result['sequence_after_resume']=bridge.sequence;result['review_required']=bridge.review_required
 result['input_neutral_before_after']=not any(before) and not any(after) and (before_pointer&0x1f00)==0 and (after_pointer&0x1f00)==0
 assert result['healthy']=={'sequence':1,'late_cancel':'not_active'}
 assert capture_result['status']=='unavailable' and result['server_state_after_return']=='T'
 assert result['sequence_before_resume']==result['sequence_after_resume']==1
 assert result['worker_before_resume']['retired'] and not result['worker_after_resume']['thread_alive']
 assert result['review_required'] and result['input_neutral_before_after']
 result['status']='passed'
except BaseException as error:result.update(status='failed',error=repr(error),traceback=traceback.format_exc())
finally:
 if server is not None and server.poll() is None:
  try:os.kill(server.pid,signal.SIGCONT)
  except ProcessLookupError:pass
 if capture is not None and capture.is_alive():capture.join(3)
 if bridge is not None:
  try:bridge.close()
  except Exception as e:result['bridge_close_error']=repr(e);result['status']='failed'
 if connection is not None:
  try:connection.close()
  except Exception as e:result['connection_close_error']=repr(e);result['status']='failed'
 if server is not None and server.poll() is None:
  server.terminate()
  try:server.wait(timeout=5)
  except subprocess.TimeoutExpired:server.kill();server.wait();result['status']='failed';result['forced_server_kill']=True
 result['server_exit']=None if server is None else server.poll()
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
sys.exit(0 if result['status']=='passed' else 1)

#!/bin/sh
set -eu
Xvfb :88 -screen 0 1024x768x24 -ac > /out/xvfb.log 2>&1 &
pid=$!
trap 'kill -CONT "$pid" 2>/dev/null || true; kill "$pid" 2>/dev/null || true; wait "$pid" 2>/dev/null || true' EXIT
sleep 1
export DISPLAY=:88 AGENT_INTERFACE_XVFB_PID="$pid" AGENT_INTERFACE_MCP_XVFB_TEST=1 AGENT_INTERFACE_MCP_XVFB_SERVER_STOP_TEST=1 AGENT_INTERFACE_MCP_XVFB_WAIT_CANCEL_WHILE_STOPPED=1 AGENT_INTERFACE_MCP_XVFB_SERVER_STOP_RESULT=/out/receipt.json PYTHONDONTWRITEBYTECODE=1
cd /workspace
python3 -m unittest -v runtime.cli_v1.test_mcp_xvfb_server_stop_integration
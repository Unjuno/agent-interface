import json, os, subprocess, time, traceback
from types import SimpleNamespace
from Xlib import X, display
from Xlib.ext import xtest
from runtime.guarded_x11_v1.bridge import _GuardedBackend
from runtime.backends.x11_v1.backend import X11Backend, X11BackendError

out = {'scenario': 'private_xvfb_guarded_motion_expiry_v1', 'steps': []}
proc = subprocess.Popen(['Xvfb', ':93', '-screen', '0', '640x480x24', '-nolisten', 'tcp'],
                        stdout=subprocess.DEVNULL, stderr=open('/out/xvfb.stderr', 'w'))
backend = observer = None
try:
    for attempt in range(100):
        try:
            observer = display.Display(':93'); break
        except Exception:
            if proc.poll() is not None: raise RuntimeError('Xvfb exited')
            time.sleep(.05)
    if observer is None: raise RuntimeError('Xvfb did not become ready')
    root = observer.screen().root
    backend = _GuardedBackend(':93', {})
    owner = SimpleNamespace(active=('fixture', [0, 0]), deadline=0, moved_point=None,
                            _check_cancelled=lambda: None)
    backend.owner = owner
    def point():
        p = root.query_pointer()
        return [p.root_x, p.root_y]
    def seed(x, y):
        xtest.fake_input(observer, X.MotionNotify, x=x, y=y)
        observer.sync()
    seed(10, 10)
    owner.deadline = time.monotonic_ns() + 2_000_000_000
    owner.check = lambda stage: {'point': [100, 100]}
    backend.pointer_move('fixture', 'screen_physical_px', 100, 100)
    positive = point()
    out['steps'].append({'name': 'valid_motion', 'position': positive})
    seed(10, 10)
    owner.deadline = time.monotonic_ns() + 50_000_000
    def delayed_check(stage):
        while time.monotonic_ns() < owner.deadline + 10_000_000:
            time.sleep(.002)
        return {'point': [200, 200]}
    owner.check = delayed_check
    emissions_before = backend.emissions
    try:
        backend.pointer_move('fixture', 'screen_physical_px', 200, 200)
        refused = False; error = None
    except X11BackendError as exc:
        refused = True; error = str(exc)
    late = point()
    late_emissions = backend.emissions - emissions_before
    out['steps'].append({'name': 'expired_motion', 'refused': refused, 'error': error,
                         'position': late, 'program_emissions': late_emissions,
                         'lateness_ns': time.monotonic_ns() - owner.deadline})
    # Separate release control on this private server, with a recorded real DOWN.
    X11Backend.pointer_button(backend, 'left', True)
    down = bool(root.query_pointer().mask & X.Button1Mask)
    release = backend.release_all()
    up = not bool(root.query_pointer().mask & X.Button1Mask)
    out['steps'].append({'name': 'independent_release_control', 'down': down,
                         'release': release, 'up': up})
    out['pass'] = (positive == [100, 100] and refused and late == [10, 10]
                   and late_emissions == 0 and down
                   and release['verified'] and up)
except BaseException as exc:
    out.update(pass_=False, error=repr(exc), traceback=traceback.format_exc())
finally:
    if backend:
        try: out['final_release'] = backend.release_all()
        except Exception as exc: out['final_release_error'] = repr(exc)
        backend.close()
    if observer: observer.close()
    proc.terminate()
    try: proc.wait(timeout=3)
    except subprocess.TimeoutExpired: proc.kill(); proc.wait()
    out['xvfb_exit'] = proc.returncode
    with open('/out/result.json', 'w') as f: json.dump(out, f, indent=2)
if not out.get('pass'): raise SystemExit(1)

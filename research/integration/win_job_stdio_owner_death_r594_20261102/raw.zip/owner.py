import json,os,sys,time,msvcrt
from pathlib import Path
from win_job_spawn import AtomicJobProcess
from identity import k,creation,member
root=Path(sys.argv[1]);nonce=sys.argv[2];p=AtomicJobProcess([sys.executable,str(root/'worker.py'),str(root),nonce,str(os.getpid())],stdio=True);grand=None
try:
 p.start();worker_pid=p.pid;worker_creation=creation(p.process)
 if not p.in_job():raise RuntimeError('worker not in job')
 p.resume();deadline=time.monotonic()+12
 while not (root/'worker.ready').exists():
  if time.monotonic()>=deadline:raise TimeoutError('worker ready')
  time.sleep(.05)
 q=json.loads((root/'worker.ready').read_text())
 if q.get('nonce')!=nonce or q.get('owner_pid')!=os.getpid() or q.get('worker_pid')!=worker_pid or q.get('worker_creation')!=worker_creation:raise RuntimeError('worker identity mismatch')
 grand=k.OpenProcess(0x1000,False,q['grandchild_pid'])
 if not grand or creation(grand)!=q['grandchild_creation'] or not member(grand,p.job):raise RuntimeError('grandchild membership/identity mismatch')
 ready={'nonce':nonce,'owner_pid':os.getpid(),'worker_pid':worker_pid,'worker_creation':worker_creation,'worker_member':p.in_job(),'grandchild_pid':q['grandchild_pid'],'grandchild_creation':q['grandchild_creation'],'grandchild_member':True,'stdout_read_handle':msvcrt.get_osfhandle(p.stdout.fileno()),'time_ns':time.monotonic_ns()}
 with (root/'owner.tmp').open('x',encoding='utf-8') as f:json.dump(ready,f)
 os.replace(root/'owner.tmp',root/'owner.ready');time.sleep(30)
finally:
 if grand:k.CloseHandle(grand)
 p.close();p.close_streams()

import base64,ctypes,hashlib,json,msvcrt,os,subprocess,sys,threading,time,uuid
from pathlib import Path
from ctypes import wintypes
from identity import k,creation
root=Path(sys.argv[1]);nonce=uuid.uuid4().hex;owner=None;handles={};verified={};duplicate=None;fd=None;stream=None;reader=None
seen=[];raw_lines=[];read_errors=[];reader_done=threading.Event();both=threading.Event();state={'eof':False}
files=('audit.py','identity.py','owner.py','worker.py','grandchild.py','win_job_spawn.py')
result={'status':'UNKNOWN','nonce':nonce,'started_ns':time.monotonic_ns(),'source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}}
def read_output():
 try:
  for line in stream:
   raw_lines.append(line);seen.append(line.decode('ascii',errors='replace').strip())
   if 'worker' in seen and 'grandchild' in seen:both.set()
  state['eof']=True
 except BaseException as e:read_errors.append(type(e).__name__)
 finally:reader_done.set()
try:
 for name in ('owner.ready','owner.tmp','worker.ready','worker.tmp','grandchild.ready','grandchild.tmp','result.json','owner.stdout','owner.stderr'):
  if (root/name).exists():raise FileExistsError('existing attempt file')
 with (root/'owner.stdout').open('xb') as stdout,(root/'owner.stderr').open('xb') as stderr:
  owner=subprocess.Popen([sys.executable,str(root/'owner.py'),str(root),nonce],stdout=stdout,stderr=stderr,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));result['owner_pid']=owner.pid
  until=time.monotonic()+15
  while not (root/'owner.ready').exists():
   if owner.poll() is not None:raise RuntimeError('owner exited before ready')
   if time.monotonic()>=until:raise TimeoutError('owner ready')
   time.sleep(.05)
  ready=json.loads((root/'owner.ready').read_text());result['ready']=ready
  if ready.get('nonce')!=nonce or ready.get('owner_pid')!=owner.pid or ready.get('worker_member') is not True or ready.get('grandchild_member') is not True:raise RuntimeError('owner marker mismatch')
  for name in ('worker','grandchild'):
   handle=k.OpenProcess(0x00101001,False,ready[name+'_pid'])
   if not handle:raise OSError('OpenProcess '+name)
   handles[name]=handle;observed=creation(handle);result[name+'_observed_creation']=observed
   if observed!=ready[name+'_creation']:raise RuntimeError('creation mismatch '+name)
   verified[name]=True;result[name+'_pre_wait']=k.WaitForSingleObject(handle,0)
   if result[name+'_pre_wait']!=258:raise RuntimeError('process not live '+name)
  duplicate=wintypes.HANDLE()
  if not k.DuplicateHandle(int(owner._handle),ready['stdout_read_handle'],k.GetCurrentProcess(),ctypes.byref(duplicate),0,False,2):raise OSError(ctypes.get_last_error(),'DuplicateHandle')
  if k.GetFileType(duplicate)!=3:raise RuntimeError('duplicated handle is not pipe')
  fd=msvcrt.open_osfhandle(duplicate.value,os.O_RDONLY|os.O_BINARY);duplicate=None
  stream=os.fdopen(fd,'rb',buffering=0);fd=None
  reader=threading.Thread(target=read_output,daemon=True);reader.start()
  if not both.wait(5) or reader_done.is_set():raise RuntimeError('markers absent or reader ended before owner death')
  result['pre_seen']=list(seen);result['reader_alive_before']=reader.is_alive()
  result['owner_terminate_ns']=time.monotonic_ns();owner.terminate();result['owner_exit']=owner.wait(timeout=5)
  for name in ('worker','grandchild'):
   result[name+'_post_wait']=k.WaitForSingleObject(handles[name],5000);result[name+'_post_ns']=time.monotonic_ns()
  result['reader_done']=reader_done.wait(5);reader.join(timeout=1);result['reader_joined']=not reader.is_alive();result['reader_eof']=state['eof'];result['reader_errors']=list(read_errors);result['stdout_lines']=list(seen);result['stdout_b64']=base64.b64encode(b''.join(raw_lines)).decode('ascii')
  if all(result.get(n+'_post_wait')==0 for n in ('worker','grandchild')) and result['reader_joined'] and result['reader_eof'] and not result['reader_errors']:result['status']='observed_exit_and_eof_after_owner_death'
except BaseException as e:result.update(error_type=type(e).__name__,error=str(e))
finally:
 try:
  if owner is not None and owner.poll() is None:
   owner.terminate()
   try:owner.wait(timeout=5)
   except subprocess.TimeoutExpired:result['owner_cleanup']='unconfirmed'
 except BaseException as e:result['owner_cleanup_error']=type(e).__name__
 for name,handle in handles.items():
  try:
   if verified.get(name) and k.WaitForSingleObject(handle,0)!=0:
    result[name+'_fallback_terminate_called']=True;result[name+'_fallback_terminate_ok']=bool(k.TerminateProcess(handle,1));result[name+'_fallback_wait']=k.WaitForSingleObject(handle,5000)
  except BaseException as e:result[name+'_cleanup_error']=type(e).__name__
  try:result[name+'_handle_closed']=bool(k.CloseHandle(handle))
  except BaseException as e:result[name+'_close_error']=type(e).__name__
 try:
  if duplicate:result['duplicate_handle_closed']=bool(k.CloseHandle(duplicate))
  if fd is not None:os.close(fd);result['unwrapped_fd_closed']=True
  if reader is not None and reader.is_alive():reader_done.wait(3);reader.join(timeout=1)
  result['reader_alive_at_cleanup']=bool(reader is not None and reader.is_alive())
  if stream is not None and not result['reader_alive_at_cleanup']:stream.close();result['stream_closed']=stream.closed
 except BaseException as e:result['stream_cleanup_error']=type(e).__name__
 result['ended_ns']=time.monotonic_ns()
 try:
  with (root/'result.json').open('x',encoding='utf-8') as output:output.write(json.dumps(result,indent=2)+'\n')
 except BaseException as e:print(json.dumps({'result_write_error':type(e).__name__}),file=sys.stderr)
 print(json.dumps({'status':result['status'],'error':result.get('error_type'),'eof':result.get('reader_eof'),'fallback':any(result.get(n+'_fallback_terminate_called',False) for n in ('worker','grandchild'))}))

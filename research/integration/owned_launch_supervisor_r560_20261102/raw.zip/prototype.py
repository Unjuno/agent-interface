import json, os, select, signal, subprocess, sys, time
from pathlib import Path
root=Path(sys.argv[2]); root.mkdir(exist_ok=True)
def log(event, **data):
    with (root/'events.jsonl').open('a') as f:
        f.write(json.dumps(dict(event=event,ns=time.monotonic_ns(),pid=os.getpid(),**data))+'\n'); f.flush()
def wait_file(name, timeout=8):
    end=time.monotonic()+timeout
    while time.monotonic()<end:
        p=root/name
        if p.exists():return p.read_text().strip()
        time.sleep(.01)
    raise TimeoutError(name)
mode=sys.argv[1]
if mode=='supervisor':
    fd=int(sys.argv[3]); child=None
    try:
        log('supervisor_ready')
        child=subprocess.Popen([sys.executable,'-c','import time; time.sleep(60)'],start_new_session=True)
        (root/'child.pid').write_text(str(child.pid));log('child_spawned',child=child.pid)
        wait_file('release')
        ready=select.select([fd],[],[],4)[0]
        if not ready: raise TimeoutError('parent liveness')
        eof=os.read(fd,1)==b''; log('parent_eof',eof=eof)
        if not eof: raise RuntimeError('unexpected control data')
        child.terminate()
        try: child.wait(timeout=2)
        except subprocess.TimeoutExpired: child.kill(); child.wait(timeout=2)
        log('child_reaped',child=child.pid,returncode=child.returncode)
    finally:
        if child is not None and child.poll() is None: child.kill(); child.wait(timeout=2)
        os.close(fd)
elif mode=='parent':
    r,w=os.pipe()
    proc=subprocess.Popen([sys.executable,__file__,'supervisor',str(root),str(r)],pass_fds=(r,),start_new_session=True)
    os.close(r);(root/'supervisor.pid').write_text(str(proc.pid));log('parent_started_supervisor',supervisor=proc.pid)
    while True: time.sleep(1)
elif mode=='controller':
    p=None; supervisor_pid=None; child_pid=None; supervisor_fd=None; child_fd=None
    try:
        p=subprocess.Popen([sys.executable,__file__,'parent',str(root)],start_new_session=True)
        supervisor_pid=int(wait_file('supervisor.pid'));child_pid=int(wait_file('child.pid'))
        supervisor_fd=os.pidfd_open(supervisor_pid);child_fd=os.pidfd_open(child_pid)
        log('controller_observed_spawn',parent=p.pid,supervisor=supervisor_pid,child=child_pid)
        p.kill();p.wait(timeout=3);log('parent_killed',returncode=p.returncode)
        os.kill(child_pid,0);log('child_alive_while_supervisor_gated',child=child_pid)
        (root/'release').write_text('go')
        deadline=time.monotonic()+5
        while time.monotonic()<deadline:
            if (root/'events.jsonl').exists() and 'child_reaped' in (root/'events.jsonl').read_text():break
            time.sleep(.01)
        else:raise TimeoutError('child not reaped')
        try:os.kill(child_pid,0)
        except ProcessLookupError: log('child_absent',child=child_pid)
        else: raise RuntimeError('child still exists after reap')
        log('result',status='PASS_SCOPED')
    except BaseException as exc:
        log('result',status='FAIL',error=repr(exc)); raise
    finally:
        if p is not None and p.poll() is None:p.kill();p.wait(timeout=2)
        for fd in (child_fd,supervisor_fd):
            if fd is not None:
                try:signal.pidfd_send_signal(fd,signal.SIGKILL)
                except ProcessLookupError:pass
                os.close(fd)
else: raise SystemExit(64)

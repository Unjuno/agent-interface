"""Join sealed live MAP01 images, private scorer and owner release timing."""
import hashlib,json,pathlib,statistics
P=pathlib.Path(__file__).resolve().parent
CASES=['issue59-os-east-return-6289b5c7e14b5254','issue59-os-east-return-46eefb3fb8ce727b','issue59-os-east-return-8be74fd22a808bb6','issue59-os-east-return-63126e0771551402']
def require(condition,message):
 if not condition:raise ValueError(message)
results=[]
for name in CASES:
 p=P/name;seal=json.loads((p/'seal.json').read_text());paths=['visual-guard.json','runtime.stdout','runtime/door-sector-private.jsonl','runtime/owner-events.json']
 for path in paths:
  b=(p/path).read_bytes();row=seal['files'][path];require(len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],'seal mismatch '+name+' '+path)
 gate=json.loads((p/'visual-guard.json').read_text());samples=[json.loads(x) for x in (p/'runtime/door-sector-private.jsonl').read_text().splitlines()]
 candidates=[x for x in samples if x['stage']=='reverse-turn-3'];require(len(candidates)==1,'ambiguous scorer')
 sample=candidates[0];require(sample['status']=='observed' and sample['physical_neutral_before_after'] is True and sample['getter_before_state']==sample['getter_after_state']==sample['state_tic'],'scorer validity differs')
 events=[]
 for line in (p/'runtime.stdout').read_text().splitlines():
  try:events.append(json.loads(line))
  except json.JSONDecodeError:pass
 owners=json.loads((p/'runtime/owner-events.json').read_text());turns=[]
 for i in (1,2,3):
  records=[x for x in events if x.get('event')=='input_admission' and x.get('id')==f'reverse-turn-{i}'];require(len(records)==1,'admission missing')
  admission=records[0];matches=[x for x in owners if x.get('event')=='owner_explicit_keyup' and x.get('intent_token')==admission['intent_token']];require(len(matches)==1,'release missing')
  release=matches[0];require(release['key']=='Left' and release.get('server_keyup_verified') is True,'release unverified')
  turns.append({'id':f'reverse-turn-{i}','ack_to_release_ms':(release['owner_keyrelease_started_ns']-admission['input_ack_ns'])/1e6,'release_minus_deadline_ms':(release['owner_keyrelease_started_ns']-admission['timed_deadline_ns'])/1e6})
 results.append({'trial':name,'gate_mean':gate['difference_sum']/gate['component_count'],'gate_passed':gate['passed'],'frame_sequence':gate['sequence'],
  'scorer_x':sample['position_x'],'scorer_y':sample['position_y'],'scorer_angle_deg':sample['angle'],'scorer_tic':sample['state_tic'],
  'scorer_started_after_image_ms':(sample['started_ns']-gate['capture_ns'])/1e6,'physical_neutral':True,'turns':turns})
report={'schema':'map01-state-alignment-audit-v1','scope':'retrospective sealed live inputs and private scorer; image and scorer sampled at distinct times; association is not causation','trials':results}
print(json.dumps(report,indent=2,sort_keys=True))

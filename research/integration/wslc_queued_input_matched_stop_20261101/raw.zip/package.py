import hashlib,json,pathlib,zipfile
root=pathlib.Path(__file__).resolve().parent;manifest=json.loads((root/'manifest.json').read_text())
for n,h in manifest.items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==h
arms=['matched-u01','matched-u02']
for arm in arms:
    p=root/arm;c=json.loads((p/'conditions.json').read_text());r=json.loads((p/'output/result.json').read_text())
    assert c['manifest_sha256']==hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()
    assert r['status']=='passed' and r['mode']==c['mode'] and json.loads((p/'launcher-result.json').read_text())['returncode']==0
    assert r['repeat_global']==0 and r['old_key_down_before_stop'] and r['input_marker']['delay_ms']==8000
    ev={e['name']:e['ns'] for e in r['events']};assert ev['old_effect_and_hold']<ev['old_server_stopped']<ev['old_server_resumed']<ev['horizon_readback']<ev['fresh_action_returned']
    assert 1_000_000_000<=ev['old_server_resumed']-ev['old_server_stopped']<1_500_000_000
    assert ev['horizon_readback']>=r['input_marker']['ns']+9_000_000_000
    presses=[e for e in r['old_target_at_horizon']['events'] if e['type']=='press' and e['key']=='b']
    if r['mode']=='retire':
        assert not presses and not r['b_down_at_horizon'] and not r['a_down_after_cancel']
        assert r['old_cancel']['cleanup_status']=='UNKNOWN' and not r['old_cancel']['release_confirmed'] and not r['old_cancel']['replay_allowed']
        assert r['old_cancel']['owner_release_attempt']['status']=='readback_verified' and not r['old_thread_alive']
    else:
        assert len(presses)==1 and presses[0]['host_ns']>=r['input_marker']['ns']+7_500_000_000 and r['b_down_at_horizon']
        assert r['old_thread_alive_after_resume'] and not r['old_thread_alive_after_close']
        assert r['old_owner_close_before_fresh']['cleanup_status']=='UNKNOWN' and 'fixture_release_old_hold' in ev and 'fixture_release_delayed_b' in ev
    assert r['fresh_target']['value']=='a' and r['action']['result']['execution']['releases'][-1]['verified'] and r['fresh_neutral_after_task']
    assert r['target_exitcodes']==[0,0] and r['server_exitcodes']==[-9]
dest=root.parent/'guarded-motion-deadline-r01/research/integration/wslc_queued_input_matched_stop_20261101';dest.mkdir(parents=True,exist_ok=False)
paths=[root/n for n in manifest]+[root/'manifest.json',pathlib.Path(__file__)]
for arm in arms:
    p=root/arm;paths += [p/'conditions.json',p/'launcher-result.json',p/'stdout',p/'stderr']+[x for x in (p/'output').rglob('*') if x.is_file() and x.name!='authority' and 'display-owner-' not in '/'.join(x.parts)]
public={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
with zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in paths:z.write(p,p.relative_to(root).as_posix())
    z.writestr('public-manifest.json',json.dumps(public,indent=2,sort_keys=True)+'\n')
with zipfile.ZipFile(dest/'raw.zip') as z:
    for n,h in public.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
print('validated',len(public),'files; sha256',hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest())

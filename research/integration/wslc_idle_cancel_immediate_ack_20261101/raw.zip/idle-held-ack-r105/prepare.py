import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parent
files=[p for p in (root/'src').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']+[root/n for n in ('trial.py','prepare.py','run.py')]
manifest={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files};(root/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
arms=[('r105-control','control'),('r105-overlap','overlap')]
for ident,mode in arms:
 p=root/ident;p.mkdir(exist_ok=False);(p/'output').mkdir()
 c={'allocation':'idle-held-ack-r105-'+ident,'mode':mode,'order':arms,'main_at_freeze':'2c2b7114532f5f1434ccc34fca8ef48223314a72','candidate_pr_head':'477d54be7cd4e78df1de9601f62617a67558aea5','image':'sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25','manifest_sha256':hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest(),'protocol':'existing standard MCP private Xvfb blocked-sync cancellation test; child cancel ack withholding changed from 1s to 0s versus r103; control no idle call, intervention idle attempt after independent a-down readback; retain complete test directory','criteria':'existing unmodified cancellation/release/fresh-task assertions plus intervention refusal with no idle reservation; preserve task oracle separately, no forced PASS','stop':'one try per arm; stop remaining block on test failure or unknown final input','limits':'deliberately injected blocked X sync and delayed X request, one control and one intervention, lifecycle guard enabled, not production guarantee or MAP01'}
 (p/'conditions.json').write_text(json.dumps(c,indent=2)+'\n')
print('two immediate-ack held-input cancellation arms frozen')

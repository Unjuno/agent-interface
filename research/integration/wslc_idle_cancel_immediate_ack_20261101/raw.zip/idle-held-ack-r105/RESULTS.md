# Immediate cancellation acknowledgement with held input

The parent experiment r103 deliberately withheld the child cancellation
acknowledgement for 1 s; the owner waits 0.25 s for a control response. Both
r103 arms returned `cancel_unconfirmed` and cleanup `UNKNOWN`. This new fixed
experiment changes the withholding to 0 s; the simulated delayed X request,
blocked sync, lifecycle guard, target and control/overlap structure remain.
It uses the candidate from draft PR #10094 at
`477d54be7cd4e78df1de9601f62617a67558aea5`; main at freeze was
`2c2b7114532f5f1434ccc34fca8ef48223314a72`. Source and trial were hashed
before two new serial WSLc allocations (1 CPU, 1 GiB, no network, pinned image).

| Arm | Idle request while `a` held | Runtime cancellation | Runtime cleanup | Independent release and task oracles |
| --- | --- | --- | --- | --- |
| control | none | `cancel_requested` | `UNKNOWN` | keys up; initial and fresh task pass |
| overlap | refused; no idle reservation | `cancel_requested` | `UNKNOWN` | keys up; initial and fresh task pass |

The test confirmed no intentional child acknowledgement withholding in both
arms. The runtime still records `late_server_request_possible=true`, refuses
replay and does not claim release confirmed, even though independent readback
found keys up after cleanup and at the delayed-request horizon. This separates
acknowledgement uncertainty from the residual late-request/cleanup uncertainty;
it does not prove every cause of UNKNOWN or that an arbitrary request cannot
arrive later. Both tests completed; `audit.py` checks saved source hashes,
conditions and reports. Raw logs, complete report, retained synthetic artifacts
and test output are in each allocation directory. One trial per arm is not a
general safety or latency estimate, and no MAP01 claim follows.

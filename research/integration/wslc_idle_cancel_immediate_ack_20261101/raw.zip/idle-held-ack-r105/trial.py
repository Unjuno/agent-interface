import json,os,pathlib,subprocess,sys,time
from Xlib import display
out=pathlib.Path('/out');xlog=(out/'xvfb.log').open('wb')
server=subprocess.Popen(['Xvfb',':88','-screen','0','1024x768x24','-nolisten','tcp'],stdout=xlog,stderr=subprocess.STDOUT)
result={'status':'started','mode':os.environ['CONTROL_MODE']}
try:
 conn=None
 for _ in range(100):
  if server.poll() is not None:raise RuntimeError('Xvfb exited')
  try:conn=display.Display(':88');break
  except Exception:time.sleep(.05)
 if conn is None:raise RuntimeError('Xvfb unavailable')
 conn.close()
 env=dict(os.environ,DISPLAY=':88',AGENT_INTERFACE_MCP_XVFB_TEST='1',AGENT_INTERFACE_MCP_XVFB_CANCEL_ACK_WITHHOLD_S='0',AGENT_INTERFACE_XVFB_PID=str(server.pid),AGENT_INTERFACE_MCP_XVFB_BLOCKED_RELEASE_RESULT='/out/report.json',OVERLAP_ENABLED='1' if os.environ['CONTROL_MODE']=='overlap' else '0')
 cmd=[sys.executable,'-B','-m','unittest','runtime.cli_v1.test_mcp_xvfb_blocked_release_integration.StandardCallerBlockedReleaseXvfbTests.test_standard_caller_cancels_blocked_sync_and_releases_on_xvfb']
 with (out/'test.stdout').open('wb') as a,(out/'test.stderr').open('wb') as b:
  run=subprocess.run(cmd,env=env,stdout=a,stderr=b,timeout=50)
 result['test_returncode']=run.returncode
 report=json.loads((out/'report.json').read_text()) if (out/'report.json').exists() else {}
 result['reported_status']=report.get('status');result['overlap']=report.get('held_input_idle_overlap')
 result['status']='completed' if run.returncode==0 and report.get('status')=='OBSERVED_SCOPED_XVFB_STANDARD_CALLER_CANCEL_CLEANUP_UNKNOWN' else 'failed'
except BaseException as e:result.update(status='failed',error=repr(e))
finally:
 if server.poll() is None:
  server.terminate()
  try:server.wait(timeout=5)
  except subprocess.TimeoutExpired:server.kill();server.wait();result['status']='failed'
 result['xvfb_exit']=server.returncode;xlog.close()
 (out/'wrapper-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
sys.exit(0 if result['status']=='completed' else 1)

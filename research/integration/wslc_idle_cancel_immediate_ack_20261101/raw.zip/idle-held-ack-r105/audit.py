"""Check the saved control and held-input overlap receipts, without re-execution."""
import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parent
errors=[];rows=[]
def check(value,message):
 if not value:errors.append(message)
manifest=json.loads((root/'manifest.json').read_text())
for name,digest in manifest.items():check(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,'source '+name)
for ident,mode in [('r105-control','control'),('r105-overlap','overlap')]:
 p=root/ident;c=json.loads((p/'conditions.json').read_text());out=p/'output';w=json.loads((out/'wrapper-result.json').read_text());r=json.loads((out/'report.json').read_text())
 check(c['mode']==mode and w['mode']==mode,ident+' mode')
 check(c['manifest_sha256']==hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest(),ident+' manifest')
 check(json.loads((p/'launcher-result.json').read_text())['returncode']==0 and w['test_returncode']==0,ident+' test')
 check(r['status']=='OBSERVED_SCOPED_XVFB_STANDARD_CALLER_CANCEL_CLEANUP_UNKNOWN',ident+' report')
 check(r['input_before_cancel']['keys_down']=={'a':True,'b':False},ident+' held input')
 overlap=r['held_input_idle_overlap']
 if mode=='overlap':check(overlap['result']=='refused' and 'RPC in flight' in overlap['error'] and overlap['idle_reserved'] is False,ident+' refusal')
 else:check(overlap['result']=='control_not_requested',ident+' control')
 check(r['cancel']['status']=='cancel_requested' and r['cancel']['cleanup_status']=='UNKNOWN' and r['cancel']['late_server_request_possible'] is True,ident+' uncertainty')
 check(r['cancel_control_ack_withheld']['withheld_ack_s']==0.0,ident+' immediate ack')
 check(r['independent_release_readback']['keys_down']=={'a':False,'b':False},ident+' independent release')
 check(r['independent_task_oracle']['status']=='pass',ident+' initial effect')
 fresh=r['fresh_session_recovery'];check(fresh['effect_count_oracle']['status']=='pass' and fresh['effect_at_horizon']==[3],ident+' fresh effect')
 check(not any(r['late_request_horizon_readback']['keys_down'].values()),ident+' horizon')
 check(not any(r['final_cleanup']['keys_down'].values()) and w['xvfb_exit']==0,ident+' cleanup')
 check((out/'preserved').is_dir(),ident+' raw')
 rows.append({'id':ident,'refusal':overlap,'cancel':r['cancel']['status'],'runtime_cleanup':r['cancel']['cleanup_status'],'initial_oracle':r['independent_task_oracle']['status'],'fresh_oracle':fresh['effect_count_oracle']['status']})
print(json.dumps({'status':'pass' if not errors else 'fail','rows':rows,'errors':errors},indent=2));raise SystemExit(bool(errors))

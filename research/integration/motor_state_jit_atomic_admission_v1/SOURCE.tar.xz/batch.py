import argparse,json,subprocess,sys,tempfile
from pathlib import Path
POLICIES=('JIT_THEN_SEND','ORDERED_ADMISSION')
SCENARIOS=('STABLE','TRANSFER_BEFORE_CHECK','TRANSFER_AFTER_CHECK_BEFORE_INPUT','OBSERVER_UNAVAILABLE')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--scenario',required=True,choices=SCENARIOS);ap.add_argument('--out',required=True);ap.add_argument('--reps',default='0,1');a=ap.parse_args()
 out=Path(a.out); out.parent.mkdir(parents=True,exist_ok=False) if not out.parent.exists() else None
 if out.exists(): raise SystemExit('refuse existing output')
 rows=[]
 for rep in [int(x) for x in a.reps.split(',')]:
  for pol in POLICIES:
   with tempfile.TemporaryDirectory() as td:
    p=Path(td)/'case.json'; cp=subprocess.run([sys.executable,'-B',str(Path(__file__).with_name('case_runner.py')),'--policy',pol,'--scenario',a.scenario,'--rep',str(rep),'--out',str(p)],text=True,capture_output=True,timeout=18)
    row=json.loads(p.read_text()) if p.exists() else {'ok':False,'error':'NO_CASE_JSON','policy':pol,'scenario':a.scenario,'rep':rep}
    row['outer_exit']=cp.returncode; row['outer_stdout']=cp.stdout[-2000:]; row['outer_stderr']=cp.stderr[-2000:]; rows.append(row)
 with out.open('w') as f:
  for r in rows:f.write(json.dumps(r,sort_keys=True)+'\n')
 print(json.dumps({'scenario':a.scenario,'rows':len(rows),'ok':sum(bool(r.get('ok')) for r in rows)},sort_keys=True))
 return 0 if len(rows)==4 and all(r.get('ok') and r.get('outer_exit')==0 for r in rows) else 2
if __name__=='__main__':raise SystemExit(main())

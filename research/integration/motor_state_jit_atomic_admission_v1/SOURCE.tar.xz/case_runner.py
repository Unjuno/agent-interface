from __future__ import annotations
import argparse, json, os, shutil, subprocess, sys, tempfile, time
from pathlib import Path
sys.path.append('/usr/lib/python3/dist-packages')
import uno
from Xlib import X, XK, display
from Xlib.ext import xtest

POLICIES=('JIT_THEN_SEND','ORDERED_ADMISSION')
SCENARIOS=('STABLE','TRANSFER_BEFORE_CHECK','TRANSFER_AFTER_CHECK_BEFORE_INPUT','OBSERVER_UNAVAILABLE')

HELPER = r'''
import os,sys,time,tkinter as tk
from Xlib import X,display
root=tk.Tk(); root.title('MotorState Wrong Surface'); e=tk.Entry(root); e.pack(); e.focus_set(); root.update()
d=display.Display(os.environ['DISPLAY']); atom=d.intern_atom('_NET_CLIENT_LIST'); win=None
for _ in range(150):
    pr=d.screen().root.get_full_property(atom,X.AnyPropertyType)
    for wid in ([] if pr is None else list(pr.value)):
        try:
            c=d.create_resource_object('window',int(wid))
            if (c.get_wm_name() or '')=='MotorState Wrong Surface': win=c; break
        except Exception: pass
    if win: break
    root.update(); time.sleep(.01)
print('READY '+str(win.id if win else 0),flush=True)
for line in sys.stdin:
    cmd=line.strip()
    if cmd=='FOCUS':
        print('ABOUT_TO_FOCUS',flush=True)
        win.set_input_focus(X.RevertToParent,X.CurrentTime); d.sync()
        print('FOCUS_DONE',flush=True)
    elif cmd=='POLL':
        root.update(); print('TEXT '+e.get(),flush=True)
    elif cmd=='QUIT': break
    root.update()
'''

def read_ready(p):
    lines=[]
    for _ in range(20):
        line=p.stdout.readline().strip(); lines.append(line)
        if line.startswith('READY '): return int(line.split()[1]), lines
    raise RuntimeError('HELPER_NOT_READY:'+repr(lines))

def key(d,sym,down):
    code=d.keysym_to_keycode(XK.string_to_keysym(sym))
    xtest.fake_input(d, X.KeyPress if down else X.KeyRelease, code); d.sync(); return code

def type7(d):
    for sym in ('7','Return'):
        key(d,sym,True); key(d,sym,False)

def key_down(d, code):
    km=d.query_keymap(); b=km[code//8]; return bool(b & (1 << (code%8)))

def focus(d,w):
    w.set_input_focus(X.RevertToParent,X.CurrentTime); d.sync(); time.sleep(.04)

def curfocus(d): return int(d.get_input_focus().focus.id)

def wait_display(name, xa):
    old=os.environ.get('XAUTHORITY'); os.environ['XAUTHORITY']=str(xa)
    try:
        for _ in range(120):
            try:
                x=display.Display(name); x.close(); return
            except Exception: time.sleep(.025)
    finally:
        if old is None: os.environ.pop('XAUTHORITY',None)
        else: os.environ['XAUTHORITY']=old
    raise RuntimeError('XVFB_NOT_READY')

def uno_connect(port):
    local=uno.getComponentContext(); resolver=local.ServiceManager.createInstanceWithContext('com.sun.star.bridge.UnoUrlResolver',local)
    for _ in range(240):
        try: return resolver.resolve(f'uno:socket,host=127.0.0.1,port={port};urp;StarOffice.ComponentContext')
        except Exception: time.sleep(.025)
    raise RuntimeError('UNO_NOT_READY')

def calc_window(d):
    atom=d.intern_atom('_NET_CLIENT_LIST'); root=d.screen().root
    for _ in range(200):
        pr=root.get_full_property(atom,X.AnyPropertyType)
        candidates=[]
        for wid in ([] if pr is None else list(pr.value)):
            w=d.create_resource_object('window',int(wid)); cls=w.get_wm_class() or ()
            if 'libreoffice-calc' in cls: candidates.append(w)
        if len(candidates)==1: return candidates[0]
        time.sleep(.025)
    raise RuntimeError('CALC_WINDOW_AMBIGUOUS')

def run_case(policy, scenario, rep):
    assert policy in POLICIES and scenario in SCENARIOS
    work=Path(tempfile.mkdtemp(prefix=f'ms4266-{rep}-{policy[:3]}-'))
    xa=work/'Xauthority'; xa.touch()
    env=os.environ.copy(); env['XAUTHORITY']=str(xa)
    procs=[]; out=dict(schema='agent-interface/motor-state-jit-admission-case-v1',policy=policy,scenario=scenario,rep=rep,authority='none')
    def spawn(cmd,**kw):
        p=subprocess.Popen(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,**kw);procs.append(p);return p
    try:
        xv=subprocess.Popen(['Xvfb','-displayfd','1','-screen','0','1024x768x24','-ac','-nolisten','tcp'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True);procs.append(xv)
        num=xv.stdout.readline().strip(); D=':'+num; env['DISPLAY']=D; wait_display(D,xa)
        ob=spawn(['openbox']); time.sleep(.12)
        profile=work/'lo';profile.mkdir(); port=22000+(os.getpid()%1000)
        lo=spawn(['libreoffice','--norestore','--nofirststartwizard',f'-env:UserInstallation=file://{profile}',f'--accept=socket,host=127.0.0.1,port={port};urp;StarOffice.ComponentContext'])
        ctx=uno_connect(port); smgr=ctx.ServiceManager; desktop=smgr.createInstanceWithContext('com.sun.star.frame.Desktop',ctx); doc=desktop.loadComponentFromURL('private:factory/scalc','_blank',0,())
        cell=doc.Sheets.getByIndex(0).getCellRangeByName('A1'); cell.String=''; doc.CurrentController.select(cell)
        oldxa=os.environ.get('XAUTHORITY'); os.environ['XAUTHORITY']=str(xa)
        try: d=display.Display(D)
        finally:
            if oldxa is None: os.environ.pop('XAUTHORITY',None)
            else: os.environ['XAUTHORITY']=oldxa
        calc=calc_window(d); focus(d,calc)
        hp=subprocess.Popen([sys.executable,'-c',HELPER],env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1);procs.append(hp)
        helper_id, helper_boot=read_ready(hp); out['helper_boot']=helper_boot; out['calc_window']=calc.id; out['helper_window']=helper_id
        # held-state exposure, then release before admission
        shift=d.keysym_to_keycode(XK.string_to_keysym('Shift_L')); xtest.fake_input(d,X.KeyPress,shift); d.sync(); out['shift_held_observed']=key_down(d,shift)
        xtest.fake_input(d,X.KeyRelease,shift); d.sync(); out['shift_released_observed']=not key_down(d,shift)
        # restore known A1/focus after the exposure
        cell.String=''; doc.CurrentController.select(cell); focus(d,calc)
        out.update(input_dispatched=False,decision=None,focus_checked=None,focus_after_transfer=None,grab_ns=None)
        helper_lines=[]
        def helper_focus(wait_done=True):
            hp.stdin.write('FOCUS\n');hp.stdin.flush(); a=hp.stdout.readline().strip();helper_lines.append(a)
            if wait_done:
                b=hp.stdout.readline().strip();helper_lines.append(b);return a,b
            return a,None
        if scenario=='TRANSFER_BEFORE_CHECK': helper_focus(True); time.sleep(.02)
        if scenario=='OBSERVER_UNAVAILABLE':
            out['decision']='REFUSE_OBSERVER_UNAVAILABLE'
        elif policy=='JIT_THEN_SEND':
            checked=curfocus(d); out['focus_checked']=checked
            if checked!=calc.id:
                out['decision']='REFUSE_FOCUS_MISMATCH'
            else:
                if scenario=='TRANSFER_AFTER_CHECK_BEFORE_INPUT': helper_focus(True); time.sleep(.01)
                out['focus_after_transfer']=curfocus(d)
                type7(d); out['input_dispatched']=True; out['decision']='ACT'
        else:
            t0=time.monotonic_ns(); d.grab_server(); d.sync(); out['grab_ns']=time.monotonic_ns()-t0
            checked=curfocus(d); out['focus_checked']=checked
            if checked!=calc.id:
                out['decision']='REFUSE_FOCUS_MISMATCH'; d.ungrab_server(); d.sync()
            else:
                if scenario=='TRANSFER_AFTER_CHECK_BEFORE_INPUT':
                    a,_=helper_focus(False); out['helper_focus_pending']=a
                out['focus_after_transfer']=curfocus(d)
                type7(d); out['input_dispatched']=True; out['decision']='ACT'
                d.ungrab_server(); d.sync()
                if scenario=='TRANSFER_AFTER_CHECK_BEFORE_INPUT': helper_lines.append(hp.stdout.readline().strip())
        time.sleep(.15)
        hp.stdin.write('POLL\n');hp.stdin.flush(); helper_poll=hp.stdout.readline().strip(); helper_lines.append(helper_poll)
        out['helper_lines']=helper_lines; out['helper_text']=helper_poll[5:] if helper_poll.startswith('TEXT ') else ''
        out['calc_value']=str(cell.String)
        out['focus_final']=curfocus(d)
        # neutral input evidence for relevant keycodes
        out['neutral_shift']=not key_down(d,shift)
        out['neutral_7']=not key_down(d,d.keysym_to_keycode(XK.string_to_keysym('7')))
        out['neutral_return']=not key_down(d,d.keysym_to_keycode(XK.string_to_keysym('Return')))
        hp.stdin.write('QUIT\n');hp.stdin.flush(); time.sleep(.03)
        try: doc.close(True)
        except Exception: pass
        out['ok']=True
    except Exception as e:
        out['ok']=False; out['error']=type(e).__name__+':'+str(e)
    finally:
        exits={}
        for i,p in reversed(list(enumerate(procs))):
            try:
                if p.poll() is None: p.terminate()
            except Exception: pass
        for i,p in reversed(list(enumerate(procs))):
            try: rc=p.wait(timeout=1.5)
            except Exception:
                try:p.kill();rc=p.wait(timeout=.5)
                except Exception:rc=None
            exits[str(i)]=rc
        out['process_exits']=exits
        shutil.rmtree(work,ignore_errors=True)
    return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--policy',required=True,choices=POLICIES);ap.add_argument('--scenario',required=True,choices=SCENARIOS);ap.add_argument('--rep',required=True,type=int);ap.add_argument('--out',required=True);a=ap.parse_args()
    r=run_case(a.policy,a.scenario,a.rep); Path(a.out).write_text(json.dumps(r,sort_keys=True)+'\n'); print(json.dumps(r,sort_keys=True)); return 0 if r.get('ok') else 2
if __name__=='__main__': raise SystemExit(main())

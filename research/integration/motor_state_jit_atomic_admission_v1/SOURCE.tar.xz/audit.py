import argparse,json,sys
from pathlib import Path
POLS=('JIT_THEN_SEND','ORDERED_ADMISSION'); SCENS=('STABLE','TRANSFER_BEFORE_CHECK','TRANSFER_AFTER_CHECK_BEFORE_INPUT','OBSERVER_UNAVAILABLE')
def expected(r):
 p,s=r['policy'],r['scenario']; e=[]
 if not r.get('ok'): e.append('case_not_ok')
 if not r.get('shift_held_observed') or not r.get('shift_released_observed'): e.append('shift_exposure')
 if not all(r.get(k) for k in ('neutral_shift','neutral_7','neutral_return')): e.append('neutral')
 if r.get('authority')!='none': e.append('authority')
 if set((r.get('process_exits') or {}).keys())!={'0','1','2','3'} or any(v is None for v in (r.get('process_exits') or {}).values()): e.append('process_receipts')
 if s=='STABLE':
  if r.get('decision')!='ACT' or not r.get('input_dispatched') or r.get('calc_value')!='7' or r.get('helper_text')!='': e.append('stable_effect')
 elif s=='TRANSFER_BEFORE_CHECK':
  if r.get('decision')!='REFUSE_FOCUS_MISMATCH' or r.get('input_dispatched') or r.get('calc_value')!='' or r.get('helper_text')!='': e.append('precheck_refusal')
 elif s=='TRANSFER_AFTER_CHECK_BEFORE_INPUT':
  if p=='JIT_THEN_SEND':
   if r.get('decision')!='ACT' or not r.get('input_dispatched') or r.get('calc_value')!='' or '7' not in r.get('helper_text',''): e.append('weak_race_not_exposed')
   if r.get('focus_after_transfer')!=r.get('helper_window'): e.append('weak_focus_order')
  else:
   if r.get('decision')!='ACT' or not r.get('input_dispatched') or r.get('calc_value')!='7' or r.get('helper_text')!='': e.append('candidate_race_failure')
   if r.get('grab_ns') is None: e.append('missing_grab_timing')
   if r.get('focus_after_transfer')!=r.get('calc_window'): e.append('candidate_focus_order')
   if r.get('helper_focus_pending')!='ABOUT_TO_FOCUS' or (r.get('helper_lines') or [])[:2]!=['ABOUT_TO_FOCUS','FOCUS_DONE']: e.append('candidate_helper_order')
 elif s=='OBSERVER_UNAVAILABLE':
  if r.get('decision')!='REFUSE_OBSERVER_UNAVAILABLE' or r.get('input_dispatched') or r.get('calc_value')!='' or r.get('helper_text')!='': e.append('unknown_refusal')
 return e
def audit(paths):
 rows=[]; errs=[]
 for p in paths:
  for line in Path(p).read_text().splitlines():
   if line.strip(): rows.append(json.loads(line))
 ids=[(r.get('scenario'),r.get('policy'),r.get('rep')) for r in rows]
 exp={(s,p,r) for s in SCENS for p in POLS for r in (0,1)}
 if set(ids)!=exp or len(ids)!=16: errs.append('denominator')
 for i,r in enumerate(rows):
  if r.get('outer_exit')!=0: errs.append(f'outer_exit:{i}')
  for e in expected(r): errs.append(f'{i}:{e}')
 return rows,errs
def main():
 ap=argparse.ArgumentParser();ap.add_argument('paths',nargs='+');ap.add_argument('--out');a=ap.parse_args();rows,errs=audit(a.paths)
 out={'schema':'agent-interface/motor-state-jit-admission-audit-v1','cases':len(rows),'errors':errs,'decision':'PASS_MOTOR_STATE_JIT_ADMISSION_RACE_SCOPED' if not errs else 'FAIL_OR_HOLD'}
 txt=json.dumps(out,indent=2,sort_keys=True)+'\n'; print(txt,end='');
 if a.out:Path(a.out).write_text(txt)
 return 0 if not errs else 1
if __name__=='__main__':raise SystemExit(main())

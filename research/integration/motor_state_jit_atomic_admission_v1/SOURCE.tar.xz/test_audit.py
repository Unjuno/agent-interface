import copy,json,sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent));import audit

def base_rows():
 rows=[]
 for s in audit.SCENS:
  for p in audit.POLS:
   for rep in (0,1):
    r={'ok':True,'scenario':s,'policy':p,'rep':rep,'outer_exit':0,'authority':'none','shift_held_observed':True,'shift_released_observed':True,'neutral_shift':True,'neutral_7':True,'neutral_return':True,'calc_value':'','helper_text':'','input_dispatched':False,'decision':None,'grab_ns':100 if p=='ORDERED_ADMISSION' else None,'process_exits':{'0':0,'1':1,'2':255,'3':-15},'calc_window':100,'helper_window':200,'focus_after_transfer':None,'helper_lines':[],'helper_focus_pending':None}
    if s=='STABLE':r.update(decision='ACT',input_dispatched=True,calc_value='7')
    elif s=='TRANSFER_BEFORE_CHECK':r['decision']='REFUSE_FOCUS_MISMATCH'
    elif s=='TRANSFER_AFTER_CHECK_BEFORE_INPUT':
     if p=='JIT_THEN_SEND':r.update(decision='ACT',input_dispatched=True,helper_text='7',focus_after_transfer=200)
     else:r.update(decision='ACT',input_dispatched=True,calc_value='7',focus_after_transfer=100,helper_focus_pending='ABOUT_TO_FOCUS',helper_lines=['ABOUT_TO_FOCUS','FOCUS_DONE','TEXT'])
    else:r['decision']='REFUSE_OBSERVER_UNAVAILABLE'
    rows.append(r)
 return rows

def errors(rows):
 es=[]; ids=[(r.get('scenario'),r.get('policy'),r.get('rep')) for r in rows]
 exp={(s,p,r) for s in audit.SCENS for p in audit.POLS for r in (0,1)}
 if set(ids)!=exp or len(ids)!=16:es.append('denominator')
 for i,r in enumerate(rows):
  if r.get('outer_exit')!=0:es.append('outer')
  es+=['x' for _ in audit.expected(r)]
 return es
rows=base_rows(); assert not errors(rows)
mut=[]
def c(name,fn):
 z=copy.deepcopy(rows);fn(z);mut.append((name,bool(errors(z))))
c('drop',lambda z:z.pop())
c('duplicate',lambda z:z.append(copy.deepcopy(z[0])))
c('outer',lambda z:z[0].__setitem__('outer_exit',2))
c('held',lambda z:z[0].__setitem__('shift_held_observed',False))
c('neutral',lambda z:z[0].__setitem__('neutral_7',False))
c('authority',lambda z:z[0].__setitem__('authority','input'))
c('stable',lambda z:z[0].__setitem__('calc_value',''))
c('precheck',lambda z:next(r for r in z if r['scenario']=='TRANSFER_BEFORE_CHECK').__setitem__('decision','ACT'))
c('weak',lambda z:next(r for r in z if r['scenario']=='TRANSFER_AFTER_CHECK_BEFORE_INPUT' and r['policy']=='JIT_THEN_SEND').__setitem__('helper_text',''))
c('candidate',lambda z:next(r for r in z if r['scenario']=='TRANSFER_AFTER_CHECK_BEFORE_INPUT' and r['policy']=='ORDERED_ADMISSION').__setitem__('calc_value',''))
c('unknown',lambda z:next(r for r in z if r['scenario']=='OBSERVER_UNAVAILABLE').__setitem__('input_dispatched',True))
c('grab',lambda z:next(r for r in z if r['scenario']=='TRANSFER_AFTER_CHECK_BEFORE_INPUT' and r['policy']=='ORDERED_ADMISSION').__setitem__('grab_ns',None))
print(json.dumps(mut)); assert all(v for _,v in mut); print('PASS_CONTROLS',len(mut))

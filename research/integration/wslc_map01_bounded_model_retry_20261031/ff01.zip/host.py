import hashlib,json,time,sys,os
from pathlib import Path
import integrated_efficiency_app_server_model_v1 as adapter
root=Path(sys.argv[2]);ex=root/'exchange';m=None;result={'id':'pilot-1','ok':False}
def put(name,data):
 tmp=ex/(name+'.tmp');tmp.write_text(json.dumps(data));os.replace(tmp,ex/(name+'.json'))
def read_with_retry(path, *, binary=False):
 deadline=time.monotonic()+2;attempts=0
 while True:
  try:
   data=path.read_bytes() if binary else path.read_text()
   with (root/'host-file-reads.jsonl').open('a',encoding='utf-8') as log:log.write(json.dumps({'name':path.name,'attempts':attempts+1})+'\n')
   return data
  except PermissionError:
   attempts+=1
   if time.monotonic()>=deadline:raise
   time.sleep(.02)
def validate(value):
 if type(value) is not dict or set(value)!={'action','target_x','target_y','duration_ms'}:raise ValueError('invalid policy shape')
 if value['action'] not in ('fire','idle') or any(type(value[k]) is not int for k in ('target_x','target_y','duration_ms')):raise ValueError('invalid policy fields')
 if not 0<=value['target_x']<1280 or not 0<=value['target_y']<1024 or value['duration_ms'] not in (0,500,1000,1500,2000):raise ValueError('policy out of bounds')
 if (value['action']=='idle') != (value['duration_ms']==0):raise ValueError('duration/action mismatch')
 return value
try:
 workspace=root/'workspace';workspace.mkdir(exist_ok=False);adapter.CONTRACTS['policy']=(root/'policy-schema.json',root/'policy-instructions.txt',validate)
 m=adapter.PersistentGroundingModel(root/'model-session',workspace,executable=sys.argv[1],contract='policy',model='gpt-6.1-sol',effort='low',path_converter=lambda p:str(Path(p).resolve()));put('ready',{'ready':True})
 for i in (1,2,3,4,5,6):
  result={'id':f'pilot-{i}','ok':False};deadline=time.monotonic()+100
  while not (ex/f'request-{i}.json').exists():
   if (ex/'stop.json').exists():break
   if time.monotonic()>deadline:raise TimeoutError('request not observed')
   time.sleep(.02)
  if (ex/'stop.json').exists() and not (ex/f'request-{i}.json').exists():break
  request=json.loads(read_with_retry(ex/f'request-{i}.json'));image=ex/f'image-{i}.png';digest=hashlib.sha256(read_with_retry(image,binary=True)).hexdigest()
  if request['id']!=result['id'] or request['image_sha256']!=digest:raise ValueError('image mismatch')
  put(f'started-{i}',{'started':True});result['attempted']=True
  prompt=('Choose a bounded action for this Doom game image. If a hostile character is visible near the center and firing is appropriate, choose fire with its center as target; otherwise idle. Use at most 2000 ms. A runtime will revalidate before executing once.' if i>=3 else 'Choose the bounded next policy for this Doom game image. If a hostile character is visible near the center and firing is appropriate, choose fire with its center as target; otherwise idle. Use at most 2000 ms. The policy may run only during the next pending model call, after visual revalidation.')
  if i==5:prompt='The prior attack was interrupted; its effect may still be unknown. Review this fresh Doom screenshot. If a hostile character is visible near the center and firing is appropriate, select fire at its center; otherwise select idle. Do not assume the earlier attack was undone. The runtime will revalidate any action.'
  if i==6:prompt='The previous proposed shot was not executed because the scene changed. An earlier interrupted attack may still have had an effect. Review this new Doom screenshot; choose fire only if a hostile character is visible near the center and firing is appropriate, otherwise choose idle. A runtime will revalidate once; no further retry is planned.'
  value=m.call(root/f'model-call-{i}',prompt,image,'policy',workspace)
  result.update(ok=True,image_sha256=digest,grounding=value['grounding'],usage=value['usage'],call_id=value['call_id'],runner_ns=value['runner_ns']);put(f'done-{i}',result)
except BaseException as e:
 result.update(error=type(e).__name__,detail=str(e)[:500],call_id=getattr(e,'call_id',None),usage=getattr(e,'usage',None));put('host-error',result)
finally:
 if m is not None:
  try:m.close();put('closed',{'closed':True})
  except BaseException as e:put('closed',{'closed':False,'error':repr(e)})
print(json.dumps({'ok':result.get('ok'),'error':result.get('error')}),flush=True)

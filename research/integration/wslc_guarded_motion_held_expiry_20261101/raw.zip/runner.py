import json, subprocess, time, traceback
from types import SimpleNamespace
from unittest.mock import patch
from Xlib import X, display
from Xlib.ext import xtest
from runtime.guarded_x11_v1.bridge import _GuardedBackend
from runtime.backends.x11_v1.backend import X11Backend
from runtime.backends.x11_v1.session import X11RuntimeSession

out = {'scenario': 'private_xvfb_held_button_during_motion_expiry_v1'}
proc = subprocess.Popen(['Xvfb', ':94', '-screen', '0', '640x480x24', '-nolisten', 'tcp'],
                        stdout=subprocess.DEVNULL, stderr=open('/out/xvfb.stderr', 'w'))
backend = observer = None
try:
    for attempt in range(100):
        try:
            observer = display.Display(':94'); break
        except Exception:
            if proc.poll() is not None: raise RuntimeError('Xvfb exited')
            time.sleep(.05)
    if observer is None: raise RuntimeError('Xvfb did not become ready')
    root = observer.screen().root
    backend = _GuardedBackend(':94', {})
    owner = SimpleNamespace(active=('fixture', [0, 0]), deadline=time.monotonic_ns()+2_000_000_000,
                            _check_cancelled=lambda: None)
    backend.owner = owner
    owner._prearm_button_press = lambda button: backend.held_buttons.add(button)
    xtest.fake_input(observer, X.MotionNotify, x=10, y=10); observer.sync()
    X11Backend.pointer_button(backend, 'left', True)
    out['before_down'] = bool(root.query_pointer().mask & X.Button1Mask)
    owner.deadline = time.monotonic_ns()+50_000_000
    def delayed_check(stage):
        while time.monotonic_ns() < owner.deadline+10_000_000: time.sleep(.002)
        return {'point': [200, 200]}
    owner.check = delayed_check
    backend.preflight = lambda program: None
    backend.manifest = lambda: {}
    backend.focus = lambda target: None
    session = X11RuntimeSession(backend)
    program = {'ops': [{'op': 'focus', 'target': 'fixture'},
                       {'op': 'pointer_move', 'frame': 'screen_physical_px', 'x': 200, 'y': 200},
                       {'op': 'pointer_button', 'button': 'right', 'down': True},
                       {'op': 'release_all'}]}
    accepted = SimpleNamespace(accepted=True, required_capabilities=[])
    with patch('runtime.backends.x11_v1.session.admit_program', return_value=accepted):
        result = session.dispatch(program, current_observation_seq=1,
                                  current_binding_revision=1, now_ns=time.monotonic_ns())
    pointer = root.query_pointer()
    out['result'] = result
    out['after_position'] = [pointer.root_x, pointer.root_y]
    out['after_buttons'] = {'left': bool(pointer.mask & X.Button1Mask),
                            'right': bool(pointer.mask & X.Button3Mask)}
    out['lateness_ns'] = time.monotonic_ns()-owner.deadline
    execution = result.get('execution', {})
    out['pass'] = (out['before_down'] and result['status']=='execution_failed'
                   and execution.get('failed_op')==1 and execution.get('completed_ops')==[0]
                   and execution.get('program_emissions')==1
                   and execution.get('releases', [{}])[0].get('verified') is True
                   and not result['recovery_required'] and out['after_position']==[10,10]
                   and not any(out['after_buttons'].values()))
except BaseException as exc:
    out.update(error=repr(exc), traceback=traceback.format_exc())
finally:
    if backend:
        try: out['final_release'] = backend.release_all()
        except Exception as exc: out['final_release_error'] = repr(exc)
        backend.close()
    if observer: observer.close()
    proc.terminate()
    try: proc.wait(timeout=3)
    except subprocess.TimeoutExpired: proc.kill(); proc.wait()
    out['xvfb_exit'] = proc.returncode
    with open('/out/result.json', 'w') as f: json.dump(out, f, indent=2)
if not out.get('pass'): raise SystemExit(1)

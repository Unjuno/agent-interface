import json,traceback
from pathlib import Path
import run_integrated_efficiency_live_v1 as live
out=Path('/out');live.OUT=out;result={'passed':False,'scope':'one controlled wrong target; no model'}
def fake(root,prompt,image,contract,workspace):
 return {'grounding':{'field_point':[216,391],'submit_point':[366,391],'method':{'engineering':'wrong-fixed'}},'usage':{'input_tokens':1000,'cached_input_tokens':0,'cache_write_input_tokens':0,'output_tokens':10,'reasoning_output_tokens':0},'call_id':'synthetic-1','requested_model':'synthetic-no-model','requested_effort':'none','cost':None}
try:
 (out/'workspaces/persistent').mkdir(parents=True)
 rows,evaluation=live.run_arm('persistent',991028,out/'workspaces/persistent',model_call=fake)
 result.update(rows=rows,evaluation=evaluation)
 result['passed']=(len(rows)==1 and rows[0]['task_id']=='task-1' and rows[0]['typed_outcome']=='failed' and rows[0]['releases_verified'] is True and evaluation.get('success') is False and evaluation.get('record_count')==0)
except Exception as e:result.update(error=repr(e),traceback=traceback.format_exc())
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':result['passed'],'error':result.get('error')}))
raise SystemExit(0 if result['passed'] else 1)

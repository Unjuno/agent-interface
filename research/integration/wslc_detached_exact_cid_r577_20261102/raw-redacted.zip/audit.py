import json,re,sys
from pathlib import Path
p=Path(sys.argv[1]);result=json.loads((p/'result.json').read_text());events=json.loads((p/'events.json').read_text());cid=(p/'container.cid').read_text().strip();run=result['run_id'];key='agent-interface.r577'
def require(value,why):
 if not value:raise ValueError(why)
def event(name):
 rows=[e for e in events if e['event']==name];require(len(rows)==1,'event '+name);return rows[0]
def rows(tag):
 require((p/(tag+'.stderr')).read_bytes()==b'',tag+' stderr')
 return [json.loads(line) for line in (p/(tag+'.stdout')).read_text(encoding='utf-8-sig').splitlines() if line.strip()]
require(re.fullmatch('[0-9a-f]{64}',cid) is not None,'cid format')
require(result['cid']==cid and result['owned_identity_confirmed'] is True,'cid/identity')
inspect=json.loads((p/'inspect.stdout').read_text(encoding='utf-8-sig'));require(isinstance(inspect,list) and len(inspect)==1,'inspect count')
row=inspect[0];require(row['Id']==cid and row['Config']['Labels'][key]==run,'inspect identity');require(row['State']['Running'] is True,'not running')
pos=rows('positive_list');require(len(pos)==1 and pos[0]['ID']==cid and key+'='+run in pos[0]['Labels'],'positive list')
require(rows('negative_list')==[],'negative filter')
require((p/'stop.stdout').read_text(encoding='utf-8-sig').strip()==cid,'stop returned different CID')
require(rows('after_list')==[],'post-stop list')
for n in ('launch_end','inspect_end','positive_list_end','negative_list_end','stop_end','after_list_end'):require(event(n)['exit']==0,n+' status')
ordered=['launch_client_exited','inspect_end','positive_list_end','negative_list_end','stop_end','after_list_end']
ns=[event(x)['ns'] for x in ordered];require(ns==sorted(ns) and len(set(ns))==len(ns),'event order')
require(not any(e['event'].startswith('cleanup_') for e in events),'unexpected fallback cleanup')
print(json.dumps({'status':'AUDITED_SCOPED','cid':cid,'run_id':run,'client_exited_before_running_inspect':True,'matching_filter_count':1,'altered_filter_count':0,'stop_returned_same_cid':True,'after_stop_count':0,'limits':'single normal detached case; no GUI/input/release; no timeout or client crash'}))

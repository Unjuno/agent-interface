import json, os, re, subprocess, sys, time, uuid
from pathlib import Path
root=Path(sys.argv[1]);root.mkdir(parents=False,exist_ok=False)
run=uuid.uuid4().hex;name='ai-r577-'+run[:16];key='agent-interface.r577';label=key+'='+run
image='sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25'
cidfile=root/'container.cid'; events=[]; cid=None;owned=False; stopped=False; result={'status':'UNKNOWN','run_id':run,'name':name}
flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
def mark(name,**kw):
 events.append(dict(event=name,ns=time.monotonic_ns(),**kw));(root/'events.json').write_text(json.dumps(events,indent=2)+'\n',encoding='utf-8')
def invoke(tag,args,timeout=8):
 (root/(tag+'.command.json')).write_text(json.dumps(args,indent=2)+'\n',encoding='utf-8');mark(tag+'_begin')
 try:
  r=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout,creationflags=flags)
  (root/(tag+'.stdout')).write_bytes(r.stdout);(root/(tag+'.stderr')).write_bytes(r.stderr);mark(tag+'_end',exit=r.returncode);return r
 except subprocess.TimeoutExpired as exc:
  (root/(tag+'.stdout')).write_bytes(exc.stdout or b'');(root/(tag+'.stderr')).write_bytes(exc.stderr or b'');mark(tag+'_timeout');raise
def inspect(cid):
 r=invoke('inspect',['wslc','container','inspect',cid,'--format','json'])
 if r.returncode!=0:raise RuntimeError('inspect failed')
 rows=json.loads(r.stdout.decode('utf-8-sig'))
 if not isinstance(rows,list) or len(rows)!=1:raise RuntimeError('inspect count')
 row=rows[0]; labels=row.get('Config',{}).get('Labels',{})
 if row.get('Id')!=cid or labels.get(key)!=run:raise RuntimeError('identity mismatch')
 return row
def list_id(tag,cid):
 r=invoke(tag,['wslc','container','list','--all','--filter','id='+cid,'--format','json','--no-trunc'])
 if r.returncode!=0 or r.stderr:raise RuntimeError(tag+' command failure')
 return [json.loads(line) for line in r.stdout.decode('utf-8-sig').splitlines() if line.strip()]
try:
 r=invoke('launch',['wslc','run','--detach','--rm','--name',name,'--label',label,'--cidfile',str(cidfile),'--network','none','--cpus','1','--memory','1g','--pull','never','--entrypoint','python3',image,'-c','import time; time.sleep(60)'],timeout=12)
 if r.returncode!=0:raise RuntimeError('launch client failed')
 mark('launch_client_exited',exit=r.returncode)
 deadline=time.monotonic()+5
 while time.monotonic()<deadline:
  if cidfile.exists():
   candidate=cidfile.read_text().strip()
   if re.fullmatch('[0-9a-f]{64}',candidate):cid=candidate;break
  time.sleep(.05)
 if cid is None:raise TimeoutError('valid CID unavailable')
 result['cid']=cid;row=inspect(cid);owned=True;mark('identity_confirmed')
 if not row.get('State',{}).get('Running'):raise RuntimeError('target not running')
 positive=list_id('positive_list',cid)
 if len(positive)!=1 or positive[0].get('ID')!=cid or (key+'='+run) not in positive[0].get('Labels',''):raise RuntimeError('positive list mismatch')
 wrong=('0' if cid[0]!='0' else '1')+cid[1:]
 negative=list_id('negative_list',wrong)
 if negative:raise RuntimeError('nonmatching filter returned rows')
 mark('selectivity_observed')
 r=invoke('stop',['wslc','container','stop','--time','2',cid])
 if r.returncode!=0:raise RuntimeError('stop failed')
 stopped=True;mark('stop_returned')
 after=list_id('after_list',cid)
 if after:raise RuntimeError('target still listed')
 mark('post_list_empty');result['status']='OBSERVED_SCOPED'
except BaseException as exc:result.update(status='UNKNOWN',error_type=type(exc).__name__,error=str(exc))
finally:
 if owned and not stopped and cid:
  try:
   r=invoke('cleanup_stop',['wslc','container','stop','--time','2',cid]);mark('cleanup_stop_result',exit=r.returncode)
  except BaseException as exc:mark('cleanup_exception',type=type(exc).__name__)
 result.update(cid=cid,owned_identity_confirmed=owned,stop_confirmed=stopped)
 (root/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result))
 sys.exit(0 if result['status']=='OBSERVED_SCOPED' else 1)

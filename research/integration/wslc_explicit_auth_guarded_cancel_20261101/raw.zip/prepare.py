import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parent
files=[p for p in (root/'src').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']+[root/'trial.py',root/'target.py',root/'run.py',root/'prepare.py']
manifest={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
arms=[('authcancel-n01','retire'),('authcancel-n02','resume')]
for ident,mode in arms:
 p=root/ident;p.mkdir(exist_ok=False);(p/'output').mkdir()
 c={'allocation':'xvfb-authcancel-'+ident+'-20261101','mode':mode,'order':[f'{i}:{m}' for i,m in arms],
    'base_main':'e5925b6bd99fd4ff3f8e0bda5ed4d7cc02d92c4d','draft_head':'926ba07214b5ab53ff38f66af5c0947606850118',
    'image':'sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25',
    'manifest_sha256':hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest(),
    'intervention':'draft explicit child authority with invalid parent authority; actual guarded owner presses a and is blocked by fixture; stop and cancel; retire and replace or resume; control fixture releases a; fresh client holds b, old client attempts stale b release, inspect b state, fixture releases if needed; fresh guarded a task',
    'criteria':'parent authority stays sentinel across owner starts; guarded old a effect and hold observed; cancellation UNKNOWN without replay; replaced display neutral versus resumed display retains a; stale release cannot clear fresh b on replaced display but does clear b on shared display; fresh guarded a task effect and release verified',
    'stop':'one try per arm; preserve all failures; stop block on unresolved input or infrastructure failure',
    'limits':'test-injected owner pause and stale release; parent temporarily sets authority only to open harness Xlib connections; no natural hang, queued old request, production display integration, hard deadline or MAP01 claim'}
 (p/'conditions.json').write_text(json.dumps(c,indent=2)+'\n')
print('two arms frozen')

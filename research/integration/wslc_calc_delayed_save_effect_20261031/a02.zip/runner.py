import os,time,json,signal,subprocess,shutil,hashlib,io
from pathlib import Path
from Xlib import X,XK,display
from Xlib.ext import xtest
from PIL import Image
from runtime.cli_v1.mcp_guarded import GuardedSessionOwner
from runtime.guarded_x11_v1.cancel_supervisor import PrestartedCancellationSupervisor,x11_cancel_worker
from worker_module import guarded_calc_click
from crop_pixel_cue import create_reference,classify
from pair_saved_oracle import score_saved

def main():
 out=Path('/out');env=dict(os.environ,DISPLAY=':153',HOME='/tmp',SAL_USE_VCLPLUGIN='gen');actors=[];handles=[];d=None;owner=None;owner_sup=None;cleanup_sup=None;target_stopped=False;calc_pid=None
 try:
  def spawn(name,args):
   f=(out/(name+'.log')).open('wb');handles.append(f);p=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);actors.append(p);return p
  spawn('xvfb',['Xvfb',':153','-screen','0','1280x800x24','-nolisten','tcp','-ac'])
  for _ in range(100):
   try:d=display.Display(':153');break
   except Exception:time.sleep(.05)
  if d is None:raise RuntimeError('X unavailable')
  if hashlib.sha256(Path('/in/blank.fods').read_bytes()).hexdigest()!='462beebbcb020ccf49af3cc49520f789a816cc3fb97597cefbd6940ffc26aeb1':raise RuntimeError('fixture differs')
  shutil.copyfile('/in/blank.fods','/tmp/blank.fods');spawn('openbox',['openbox','--sm-disable']);lo=spawn('calc',['libreoffice','-env:UserInstallation=file:///tmp/observe-profile','--calc','--nologo','--norestore','--nofirststartwizard','/tmp/blank.fods'])
  def walk(w,depth=0):
   if depth>6:return []
   result=[]
   for child in w.query_tree().children:
    try:
     title=child.get_wm_name();title=title.decode(errors='replace') if isinstance(title,bytes) else str(title or '');result.append((child.id,title,child.get_attributes().map_state));result+=walk(child,depth+1)
    except Exception:pass
   return result
  end=time.monotonic()+20;found=[]
  while time.monotonic()<end:
   found=[r for r in walk(d.screen().root) if 'blank.fods' in r[1].lower() and 'calc' in r[1].lower() and r[2]==X.IsViewable]
   if len(found)==1:break
   if len(found)>1 or lo.poll() is not None:raise RuntimeError('target ambiguous or exited')
   time.sleep(.05)
  if len(found)!=1:raise RuntimeError('target unavailable')
  time.sleep(1);owner=GuardedSessionOwner({'app':found[0][0]},out/'owner',':153');owner.get();b=owner.bridge;before=b.observe();before_image=b.history[before['sequence']][1]
  if hashlib.sha256(before_image.crop((0,97,42,119)).tobytes()).hexdigest()!='2e86f3a0f6d87ee4fb4e5ffeb7cfd159d715cb5f6f8177b0ede83784d49088cf':raise RuntimeError('initial A1 namebox differs')
  entry=b.mint_reference('entry',before['sequence'],[440,28],region_size=(30,14));tail=[{'op':'text','text':'731','gap_ms':1},{'op':'key_chord','keys':['Return']},{'op':'wait_update','timeout_ms':100},{'op':'text','text':'864','gap_ms':1},{'op':'key_chord','keys':['Return']},{'op':'wait_update','timeout_ms':100}]
  entry_result=b.keyboard('entry',entry['offset'],tail=tail,expires_at_ns=time.monotonic_ns()+3_000_000_000);(out/'entry-result.json').write_text(json.dumps(entry_result,indent=2)+'\n');releases=entry_result.get('execution',{}).get('releases',[])
  if entry_result.get('status')!='completed' or not releases or not all(x.get('verified') is True and not x.get('keys_down') and not x.get('buttons_down') for x in releases):raise RuntimeError('entry failed or release unknown')
  filled=b.observe();filled_img=b.history[filled['sequence']][1];reference=create_reference(Image.open('/in/reference.png').convert('RGB'));cue=classify(filled_img,reference);(out/'filled-cue.json').write_text(json.dumps({'sequence':filled['sequence'],'cue':cue},indent=2)+'\n')
  if cue!='filled':raise RuntimeError('known reviewed filled pixels unavailable')
  initial=Path('/tmp/blank.fods').read_bytes();baseline=hashlib.sha256(initial).hexdigest()
  if baseline!='462beebbcb020ccf49af3cc49520f789a816cc3fb97597cefbd6940ffc26aeb1':raise RuntimeError('file changed before save')
  window=d.create_resource_object('window',found[0][0]);prop=window.get_full_property(d.intern_atom('_NET_WM_PID'),X.AnyPropertyType)
  if prop is None or len(prop.value)!=1:raise RuntimeError('target pid unavailable')
  calc_pid=int(prop.value[0]);cmd=Path('/proc/'+str(calc_pid)+'/cmdline').read_bytes()
  if b'soffice.bin' not in cmd or os.getpgid(calc_pid)!=lo.pid:raise RuntimeError('target not owned Calc process')
  session='calc-save-fixture';owner_sup=PrestartedCancellationSupervisor(guarded_calc_click,expected_session_id=session,startup_timeout_s=5);(out/'ready.json').write_text(json.dumps({'owner_pid':owner_sup.pid,'calc_pid':calc_pid,'target':found[0][0],'calc_pgid':os.getpgid(calc_pid)},indent=2)+'\n')
  mode=os.environ['MODE']
  if mode=='stopped':
   os.kill(calc_pid,signal.SIGSTOP);target_stopped=True;limit=time.monotonic()+1
   while time.monotonic()<limit:
    if '\nState:\tT' in Path('/proc/'+str(calc_pid)+'/status').read_text():break
    time.sleep(.005)
   else:raise RuntimeError('Calc not observed stopped')
   (out/'target-stopped.json').write_text(json.dumps({'pid':calc_pid,'stopped_ns':time.monotonic_ns(),'state':'T'}))
  request={'operation_id':'save','session_id':session,'target':found[0][0]};start=time.monotonic_ns();deadline=start+800_000_000;outcome=owner_sup.run(request,deadline_monotonic_ns=deadline);returned=time.monotonic_ns();(out/'owner-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
  if outcome.get('reason')!='transaction_deadline' or not outcome.get('worker_retired'):raise RuntimeError('expected owner retirement absent')
  pair=json.loads((out/'save-synced.json').read_text());mid=Path('/tmp/blank.fods').read_bytes();mid_ns=time.monotonic_ns();(out/'mid.fods').write_bytes(mid)
  if target_stopped:os.kill(calc_pid,signal.SIGCONT);target_stopped=False;(out/'target-resumed.json').write_text(json.dumps({'pid':calc_pid,'resumed_ns':time.monotonic_ns()}))
  until=time.monotonic()+3
  while time.monotonic()<until:
   after=Path('/tmp/blank.fods').read_bytes()
   if score_saved(after).get('pass_effect') is True:break
   time.sleep(.05)
  after_ns=time.monotonic_ns();(out/'after.fods').write_bytes(after)
  check=pair['scheduled_late_ns']+300_000_000
  while time.monotonic_ns()<check:time.sleep(min(.05,(check-time.monotonic_ns())/1e9))
  keys=d.query_keymap();codes=pair['keycodes'];pressed=[name for name,code in codes.items() if keys[code//8]&(1<<(code%8))];mask=int(d.screen().root.query_pointer().mask)&(X.Button1Mask|X.Button2Mask|X.Button3Mask)
  record={'mode':mode,'target':found[0][0],'calc_pid':calc_pid,'baseline_sha256':baseline,'filled_sequence':filled['sequence'],'start_ns':start,'deadline_ns':deadline,'owner_returned_ns':returned,'mid_observed_ns':mid_ns,'after_observed_ns':after_ns,'final_observed_ns':time.monotonic_ns(),'scheduled_late_ns':pair['scheduled_late_ns'],'late_artifact_present':(out/'late.json').exists(),'mid_sha256':hashlib.sha256(mid).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest(),'mid_score':score_saved(mid),'after_score':score_saved(after),'keys_down':pressed,'buttons_after':mask};(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
 finally:
  if target_stopped and calc_pid is not None:os.kill(calc_pid,signal.SIGCONT);target_stopped=False
  if owner_sup is not None:owner_sup.close()
  if cleanup_sup is not None:cleanup_sup.close()
  if owner is not None:(out/'owner-close.json').write_text(json.dumps(owner.close(),indent=2)+'\n')
  if d is not None:
   try:
    keymap=d.query_keymap();codes=[d.keysym_to_keycode(XK.string_to_keysym(name)) for name in ('Control_L','s')];held=[code for code in codes if code and keymap[code//8]&(1<<(code%8))]
    if held:
     for code in held:xtest.fake_input(d,X.KeyRelease,code)
     d.sync();(out/'fallback-keys.txt').write_text('fallback key release required')
    if int(d.screen().root.query_pointer().mask)&X.Button1Mask:xtest.fake_input(d,X.ButtonRelease,1);d.sync();(out/'fallback-release.txt').write_text('fallback required')
   finally:d.close()
  for p in reversed(actors):
   if p.poll() is None:
    try:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=3)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=3)
    except ProcessLookupError:pass
  for f in handles:f.close()

if __name__=='__main__':main()

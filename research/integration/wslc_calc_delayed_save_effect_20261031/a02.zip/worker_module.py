import json,os,time
from pathlib import Path
from Xlib import X,XK,display
from Xlib.ext import xtest
def guarded_calc_click(request):
 d=display.Display(':153');pid=os.getpid();base=d.display.info.resource_id_base;session=request['session_id'];out=Path('/out');ctrl=d.keysym_to_keycode(XK.string_to_keysym('Control_L'));key=d.keysym_to_keycode(XK.string_to_keysym('s'))
 if not ctrl or not key:raise RuntimeError('keycodes unavailable')
 with (out/'custody.json').open('x') as f:json.dump({'owner_pid':pid,'resource_base':base,'session_id':session,'target':request['target'],'keycodes':{'Control_L':ctrl,'s':key}},f);f.flush();os.fsync(f.fileno())
 d.grab_server();d.sync();focus=d.get_input_focus().focus;chain=[]
 for _ in range(64):
  ident=getattr(focus,'id',focus)
  if not isinstance(ident,int) or ident in (0,1) or ident in chain:break
  chain.append(ident)
  if ident==request['target']:break
  focus=d.create_resource_object('window',ident).query_tree().parent
 if request['target'] not in chain:d.ungrab_server();d.sync();return {'status':'unknown','reason':'focus_not_target','operation_id':request['operation_id'],'session_id':session}
 for t,code in ((X.KeyPress,ctrl),(X.KeyPress,key),(X.KeyRelease,key),(X.KeyRelease,ctrl)):xtest.fake_input(d,t,code)
 d.sync();sent=time.monotonic_ns();d.ungrab_server();d.sync();(out/'save-synced.json').write_text(json.dumps({'sent_ns':sent,'scheduled_late_ns':sent+2_000_000_000,'focus_chain':chain,'keycodes':{'Control_L':ctrl,'s':key}}));time.sleep(2);(out/'late.json').write_text('worker continued after delay');return {'status':'completed','operation_id':request['operation_id'],'session_id':session}

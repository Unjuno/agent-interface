import json, subprocess, time, traceback
from types import SimpleNamespace
from Xlib import X, display
from Xlib.ext import xtest
from runtime.guarded_x11_v1.bridge import _GuardedBackend
from runtime.backends.x11_v1.backend import X11Backend, X11BackendError

out={'scenario':'custody_publication_expiry_private_xvfb_v1', 'cases':[]}
proc=subprocess.Popen(['Xvfb',':95','-screen','0','640x480x24','-nolisten','tcp'],
                      stdout=subprocess.DEVNULL,stderr=open('/out/xvfb.stderr','w'))
observer=backend=None
try:
    for i in range(100):
        try: observer=display.Display(':95'); break
        except Exception:
            if proc.poll() is not None: raise RuntimeError('Xvfb exited')
            time.sleep(.05)
    if observer is None: raise RuntimeError('Xvfb did not start')
    root=observer.screen().root
    window=root.create_window(0,0,300,300,0,observer.screen().root_depth,
        X.InputOutput,X.CopyFromParent,event_mask=X.ButtonPressMask|X.ButtonReleaseMask|X.KeyPressMask|X.KeyReleaseMask)
    window.map(); window.set_input_focus(X.RevertToParent,X.CurrentTime); observer.sync()
    xtest.fake_input(observer,X.MotionNotify,x=100,y=100); observer.sync()
    backend=_GuardedBackend(':95',{})
    owner=SimpleNamespace(active=('fixture',[0,0]), deadline=0, _check_cancelled=lambda:None,
                          _process_identity_guard=False)
    owner._prearm_button_press=lambda button:backend.held_buttons.add(button)
    owner._prearm_key_press=lambda key,code:backend.held_keycodes.update({key:code})
    backend.owner=owner
    def events():
        observer.sync(); rows=[]
        while observer.pending_events():
            e=observer.next_event()
            if e.type in (X.ButtonPress,X.ButtonRelease,X.KeyPress,X.KeyRelease):
                rows.append({'type':e.type,'detail':e.detail})
        return rows
    events()
    for kind in ('button','key'):
        owner.deadline=time.monotonic_ns()+2_000_000_000
        backend._input_obligation_publisher=None
        if kind=='button': X11Backend.pointer_button(backend,'left',True)
        else: X11Backend.key_state(backend,'a',True)
        backend.release_all(); positive=events()
        positive_type=X.ButtonPress if kind=='button' else X.KeyPress
        owner.deadline=time.monotonic_ns()+50_000_000
        def delay(keys,buttons):
            while time.monotonic_ns()<owner.deadline+10_000_000: time.sleep(.002)
        backend._input_obligation_publisher=delay
        before=backend.emissions
        try:
            if kind=='button': X11Backend.pointer_button(backend,'left',True)
            else: X11Backend.key_state(backend,'a',True)
            refused=False; error=None
        except X11BackendError as e: refused=True; error=str(e)
        tracked={'keys':dict(backend.held_keycodes),'buttons':sorted(backend.held_buttons)}
        sent=backend.emissions-before
        pre_cleanup=events()
        backend._input_obligation_publisher=None
        release=backend.release_all()
        post_cleanup=events()
        out['cases'].append({'kind':kind,'positive_events':positive,'refused':refused,
            'error':error,'press_emissions':sent,'pre_cleanup_events':pre_cleanup,
            'tracked_before_cleanup':tracked,'release':release,'post_cleanup_events':post_cleanup,
            'positive_seen':any(e['type']==positive_type for e in positive),
            'late_press_seen':any(e['type']==positive_type for e in pre_cleanup+post_cleanup)})
    p=root.query_pointer()
    out['buttons_up']=not bool(p.mask & (X.Button1Mask|X.Button2Mask|X.Button3Mask))
    out['pass']=out['buttons_up'] and all(c['positive_seen'] and c['refused'] and
        c['press_emissions']==0 and not c['late_press_seen'] and c['release']['verified'] and
        bool(c['tracked_before_cleanup']['keys'] or c['tracked_before_cleanup']['buttons']) for c in out['cases'])
except BaseException as e:
    out.update(error=repr(e),traceback=traceback.format_exc())
finally:
    if backend:
        try: out['final_release']=backend.release_all()
        except Exception as e: out['final_release_error']=repr(e)
        backend.close()
    if observer: observer.close()
    proc.terminate()
    try: proc.wait(timeout=3)
    except subprocess.TimeoutExpired: proc.kill(); proc.wait()
    out['xvfb_exit']=proc.returncode
    with open('/out/result.json','w') as f: json.dump(out,f,indent=2)
if not out.get('pass'): raise SystemExit(1)

"""Private X11 held-key isolation after quarantined read-only owner."""
import json,os,pathlib,signal,subprocess,sys,threading,time,traceback
from Xlib import X,XK,display
from Xlib.ext import xtest
from runtime.cli_v1.owned_guarded_session import OwnedGuardedSessionOwner
OUT=pathlib.Path('/out')
def main():
 mode=os.environ['CONTROL_MODE'];r={'status':'started','mode':mode,'events':[]};events=r['events']
 def mark(name,**kw):events.append({'name':name,'ns':time.monotonic_ns(),**kw})
 def state(pid):return next(x.split()[1] for x in pathlib.Path(f'/proc/{pid}/status').read_text().splitlines() if x.startswith('State:'))
 server=target=conn=old=thread=None;code=None;held=False
 try:
  server=subprocess.Popen(['Xvfb',':196','-screen','0','640x480x24','-nolisten','tcp'],stdout=(OUT/'xvfb.log').open('wb'),stderr=subprocess.STDOUT)
  for _ in range(100):
   if server.poll() is not None:raise RuntimeError('Xvfb exited')
   try:conn=display.Display(':196');break
   except Exception:time.sleep(.05)
  if conn is None:raise RuntimeError('Xvfb unavailable')
  target=subprocess.Popen(['python3','-B','/target.py'],stdout=(OUT/'target.stdout').open('wb'),stderr=(OUT/'target.stderr').open('wb'),env=dict(os.environ,TEST_DISPLAY=':196'))
  until=time.monotonic()+4
  while not (OUT/'target-ready.json').exists():
   if target.poll() is not None or time.monotonic()>=until:raise RuntimeError('target unavailable')
   time.sleep(.01)
  ready=json.loads((OUT/'target-ready.json').read_text());window=conn.create_resource_object('window',ready['xid']);conn.set_input_focus(window,X.RevertToParent,X.CurrentTime);conn.sync()
  code=conn.keysym_to_keycode(XK.string_to_keysym('a'))
  def down():
   bits=bytes(conn.query_keymap());return bool(bits[code//8]&(1<<(code%8)))
  assert not down();(OUT/'old').mkdir()
  old=OwnedGuardedSessionOwner({'app':window.id},OUT/'old',':196',process_identity=True,query_worker=True,observation_worker=True)
  old.get();r['old_pid']=old._process.pid
  r['initial_sequence']=old.observe_idle_until(deadline_ns=time.monotonic_ns()+3_000_000_000,cancel_token='healthy')['source']['sequence']
  os.kill(server.pid,signal.SIGSTOP);mark('stop_sent');until=time.monotonic()+2
  while state(server.pid)!='T':
   if time.monotonic()>=until:raise RuntimeError('server did not stop')
   time.sleep(.002)
  mark('stop_observed',state=state(server.pid));deadline=time.monotonic_ns()+500_000_000;r['deadline_ns']=deadline;capture={}
  def invoke():
   mark('capture_started')
   try:old.observe_idle_until(deadline_ns=deadline,cancel_token='stopped');capture['status']='unexpected_source'
   except RuntimeError as e:capture.update(status='unavailable',error=str(e))
   finally:mark('capture_returned',**capture)
  thread=threading.Thread(target=invoke);thread.start();pending=False
  while time.monotonic_ns()<deadline and thread.is_alive():
   if old._rpc_lock.locked() and state(server.pid)=='T':mark('rpc_pending');pending=True;break
   time.sleep(.002)
  if not pending:raise RuntimeError('pending RPC not observed')
  thread.join(3)
  if thread.is_alive():raise RuntimeError('capture did not return')
  r['capture']=capture;r['state_before_resume']=state(server.pid);r['owner_after_timeout']=old.state
  os.kill(server.pid,signal.SIGCONT);mark('resumed')
  until=time.monotonic()+3
  while old._rpc_lock.locked() and time.monotonic()<until:time.sleep(.01)
  if old._rpc_lock.locked():raise RuntimeError('late RPC did not finish')
  r['owner_after_late_reply']=old.state;r['review_after_late_reply']=old.review_required
  xtest.fake_input(conn,X.KeyPress,code);conn.sync();held=True;mark('fresh_press')
  r['down_before']=down()
  if mode=='close_old':r['old_close']=old.close();old=None;mark('old_close')
  elif mode!='withhold_close':raise RuntimeError('unknown mode')
  time.sleep(.35);r['down_after']=down();mark('hold_observed')
  xtest.fake_input(conn,X.KeyRelease,code);conn.sync();held=False;mark('fixture_release')
  r['down_after_release']=down()
  if old is not None:r['old_close']=old.close();old=None;mark('old_close')
  until=time.monotonic()+2
  while time.monotonic()<until:
   if (OUT/'target-events.json').exists():
    try:target_result=json.loads((OUT/'target-events.json').read_text())
    except json.JSONDecodeError:time.sleep(.01);continue
    if any(e['type']=='release' and e['key']=='a' for e in target_result['events']):break
   time.sleep(.01)
  else:raise RuntimeError('target did not record release')
  r['target_result']=target_result
  assert capture['status']=='unavailable' and r['state_before_resume']=='T' and r['owner_after_timeout']==r['owner_after_late_reply']=='failed' and r['review_after_late_reply']
  assert r['down_before'] and r['down_after'] and not r['down_after_release']
  assert r['old_close']['owner_process_retired'] and r['old_close']['cleanup_status']=='UNKNOWN' and not r['old_close']['release_attempted']
  assert target_result['value']=='a'
  r['status']='passed'
 except BaseException as e:r.update(status='failed',error=repr(e),traceback=traceback.format_exc())
 finally:
  if server is not None and server.poll() is None:
   try:os.kill(server.pid,signal.SIGCONT)
   except ProcessLookupError:pass
  if thread is not None and thread.is_alive():thread.join(3)
  if conn is not None and held and code is not None:
   try:xtest.fake_input(conn,X.KeyRelease,code);conn.sync();r['fallback_release_attempted']=True
   except Exception as e:r['fallback_error']=repr(e);r['status']='failed'
  if old is not None:
   try:r['old_cleanup']=old.close()
   except Exception as e:r['old_close_error']=repr(e);r['status']='failed'
  if target is not None:
   (OUT/'target-stop').write_text('stop')
   try:target.wait(timeout=3)
   except subprocess.TimeoutExpired:target.terminate();target.wait();r['status']='failed'
   r['target_exit']=target.returncode
  if conn is not None:conn.close()
  if server is not None and server.poll() is None:
   server.terminate()
   try:server.wait(timeout=5)
   except subprocess.TimeoutExpired:server.kill();server.wait();r['status']='failed'
  r['server_exit']=None if server is None else server.poll()
  (OUT/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
 return 0 if r['status']=='passed' else 1
if __name__=='__main__':sys.exit(main())

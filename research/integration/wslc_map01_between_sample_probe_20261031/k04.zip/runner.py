import json,os,signal,subprocess,time,traceback,hashlib,math,threading
from pathlib import Path
from Xlib import X,display,error,XK
import vizdoom as vd
from runtime.cli_v1.mcp_guarded import GuardedSessionOwner

out=Path('/out');route=os.environ['ROUTE'];x=None;d=None;game=None;owner=None
record={'route':route,'status':'running','task_success':None,'samples':[],'model_calls':0,'events':{}}
try:
 os.environ['DISPLAY']=':153';os.environ['SDL_VIDEODRIVER']='x11';os.environ['HOME']='/tmp';os.environ['XDG_CACHE_HOME']='/tmp/cache'
 log=(out/'xvfb.log').open('wb');x=subprocess.Popen(['Xvfb',':153','-screen','0','1280x1024x24','-nolisten','tcp'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 for _ in range(100):
  try:d=display.Display(':153');break
  except Exception:time.sleep(.05)
 if d is None:raise RuntimeError('Xvfb unavailable')
 cfg=Path('/tmp/doom-keys.ini');cfg.write_text('[Doom.Bindings]\nw=+forward\ne=+use\nd=+right\na=+left\nf=+attack\n')
 pkg=Path(vd.__file__).resolve().parent;iwad=pkg/'freedoom2.wad';record['iwad_sha256']=hashlib.sha256(iwad.read_bytes()).hexdigest()
 game=vd.DoomGame();game.set_doom_game_path(str(iwad));game.set_doom_scenario_path('');game.set_doom_map('MAP01');game.set_doom_config_path(str(cfg));game.set_mode(vd.Mode.ASYNC_SPECTATOR);game.set_ticrate(35);game.set_seed(991031);game.set_doom_skill(1);game.set_episode_timeout(2100);game.set_window_visible(True);game.set_console_enabled(False);game.set_sound_enabled(False);game.set_screen_resolution(vd.ScreenResolution.RES_640X480);game.set_available_buttons([vd.Button.MOVE_FORWARD,vd.Button.USE,vd.Button.TURN_RIGHT,vd.Button.TURN_LEFT,vd.Button.ATTACK]);game.set_labels_buffer_enabled(True);game.set_objects_info_enabled(True);game.set_available_game_variables([vd.GameVariable.POSITION_X,vd.GameVariable.POSITION_Y,vd.GameVariable.HEALTH,vd.GameVariable.KILLCOUNT,vd.GameVariable.ANGLE]);game.init()
 windows=[]
 for _ in range(250):
  windows=[]
  for w in d.screen().root.query_tree().children:
   try:
    title=w.get_wm_name()
    if title and 'DOOM' in title.upper() and w.get_attributes().map_state==X.IsViewable:windows.append(w)
   except error.BadWindow:pass
  if len(windows)==1:break
  if len(windows)>1:raise RuntimeError('ambiguous game window')
  time.sleep(.02)
 if len(windows)!=1:raise RuntimeError('game window unavailable')
 w=windows[0];d.set_input_focus(w.id,X.RevertToParent,X.CurrentTime);d.sync();time.sleep(.5)
 owner=GuardedSessionOwner({'app':w.id},out/'owner',':153');owner.get();bridge=owner.bridge;obs=bridge.observe();geom=obs['pointer_binding']['geometry'];point=[geom[0]+44,geom[1]+geom[3]-54];mint=bridge.mint_reference('game',obs['sequence'],point,region_size=(24,38));record['observation']=obs;record['mint']=mint
 def sample(label):
  game.advance_action(1,True);state=game.get_state();labels=[] if state is None else [str(x.object_name) for x in state.labels];objects=[] if state is None else [{'name':str(x.name),'id':int(x.id),'x':float(x.position_x),'y':float(x.position_y)} for x in state.objects]
  s={'label':label,'host_ns':time.monotonic_ns(),'tic':game.get_episode_time(),'x':game.get_game_variable(vd.GameVariable.POSITION_X),'y':game.get_game_variable(vd.GameVariable.POSITION_Y),'angle':game.get_game_variable(vd.GameVariable.ANGLE),'health':game.get_game_variable(vd.GameVariable.HEALTH),'kills':game.get_game_variable(vd.GameVariable.KILLCOUNT),'finished':game.is_episode_finished(),'visible_labels':labels,'objects':objects};record['samples'].append(s);(out/'samples.jsonl').open('a').write(json.dumps(s)+'\n');return s
 def screenshot(label):
  from PIL import Image
  g=w.get_geometry();raw=w.get_image(0,0,g.width,g.height,X.ZPixmap,0xffffffff);Image.frombytes('RGB',(g.width,g.height),raw.data,'raw','BGRX').save(out/('scene-'+label+'.png'))
 def run_action(alias,tail):
  source=bridge.observe();anchor=[geom[0]+geom[2]//2,geom[1]+geom[3]-100] if alias in ('turn','forward3','fire') else point;ref=bridge.mint_reference(alias,source['sequence'],anchor,region_size=(24,38));owner.dispatch_attempted=True
  result=bridge.keyboard(alias,ref['offset'],tail=tail,expires_at_ns=time.monotonic_ns()+4_000_000_000);(out/('action-'+alias+'.json')).write_text(json.dumps(result,indent=2)+'\n');record.setdefault('actions',[]).append(result)
  releases=result.get('execution',{}).get('releases',[])
  if result.get('status')!='completed' or not releases or not all(r.get('verified') and not r.get('keys_down') and not r.get('buttons_down') for r in releases):raise RuntimeError('action or release not confirmed')
 before=sample('before');screenshot('before')
 run_action('forward1',[{'op':'key_state','key':'w','down':True},{'op':'wait_update','timeout_ms':2000},{'op':'key_state','key':'w','down':False}]);sample('forward1');time.sleep(.8);sample('settle1')
 run_action('turn',[{'op':'key_state','key':'a','down':True},{'op':'wait_update','timeout_ms':900},{'op':'key_state','key':'a','down':False}]);sample('turn');screenshot('at-turn')


 first=bridge.observe();geom=first['pointer_binding']['geometry'];point=[geom[0]+geom[2]//2,geom[1]+geom[3]//2];box=(point[0]-4,point[1]-4,point[0]+4,point[1]+4);initial=bridge.history[first['sequence']][1].crop(box).tobytes();record['source_sequence']=first['sequence'];record['point']=point;record['checks']=[];record['latched']=False;overlay=None;start=time.monotonic()
 def wait_until(seconds):
  remain=start+seconds-time.monotonic()
  if remain>0:time.sleep(remain)
 def check(label):
  obs=bridge.observe();patch=bridge.history[obs['sequence']][1].crop(box).tobytes();diff=sum(abs(a-b) for a,b in zip(initial,patch))/len(initial);equal=first['pointer_binding']==obs['pointer_binding'];bad=diff>32 or not equal
  if bad:record['latched']=True
  row={'label':label,'sequence':obs['sequence'],'difference':diff,'binding_equal':equal,'bad':bad,'latched':record['latched'],'t_ns':time.monotonic_ns()};record['checks'].append(row);return row
 wait_until(.15)
 if route=='inject':
  overlay=d.screen().root.create_window(point[0]-4,point[1]-4,8,8,0,d.screen().root_depth,X.InputOutput,X.CopyFromParent,override_redirect=1,background_pixel=0xff00ff);overlay.map();overlay.configure(stack_mode=X.Above);d.sync();record['overlay_mapped_ns']=time.monotonic_ns()
 wait_until(.18)
 from PIL import Image
 raw=d.screen().root.get_image(point[0]-4,point[1]-4,8,8,X.ZPixmap,0xffffffff);Image.frombytes('RGB',(8,8),raw.data,'raw','BGRX').save(out/'witness-overlay.png');record['witness_capture_ns']=time.monotonic_ns()
 wait_until(.20)
 if overlay is not None:overlay.destroy();d.sync();record['overlay_removed_ns']=time.monotonic_ns();sample('after-overlay-removal')
 wait_until(.30);check('during-1');wait_until(.45);check('during-2')
 wait_until(1.20);last=check('endpoint');record['endpoint_only_eligible']=not last['bad'];record['latched_eligible']=not record['latched'];record['before_action']=sample('before-action');record['dispatch']='withheld'
 if record['latched_eligible']:
  ob=bridge.observe();anchor=[geom[0]+geom[2]//2,geom[1]+geom[3]-100];ref=bridge.mint_reference('fire',ob['sequence'],anchor,region_size=(24,38));tail=[{'op':'key_state','key':'f','down':True},{'op':'wait_update','timeout_ms':100},{'op':'key_state','key':'f','down':False}];owner.dispatch_attempted=True
  def verify(stage,native,image):
   patch=image.crop(box).tobytes();diff=sum(abs(a-b) for a,b in zip(initial,patch))/len(initial);return not record['latched'] and diff<=32 and native['pointer_binding']==first['pointer_binding']
  with bridge.input_guard('fire',ref['offset'],tail=tail,verify=verify,interaction='keyboard'):
   action=bridge.keyboard('fire',ref['offset'],tail=tail,expires_at_ns=time.monotonic_ns()+3_000_000_000)
  record['guarded_action']=action;record['dispatch']='completed' if action.get('status')=='completed' else 'refused_or_failed'
 sample('after-action');time.sleep(.3);final=sample('final');record['health_delta']=final['health']-before['health'];record['kill_delta']=final['kills']-before['kills'];record['close']=owner.close();owner=None
 keys=d.query_keymap();record['keys_down_after']=[key for key in ('w','e','d','a','f') if (lambda code:code and bool(keys[code//8]&(1<<(code%8))))(d.keysym_to_keycode(XK.string_to_keysym(key)))];record['status']='completed'

except BaseException as e:record['status']='error';record['error']=repr(e);(out/'traceback.txt').write_text(traceback.format_exc())
finally:
 if owner is not None:
  try:record['finally_close']=owner.close()
  except BaseException as e:record['close_error']=repr(e)
 if game is not None:
  try:game.close()
  except BaseException as e:record['game_close_error']=repr(e)
 if d is not None:d.close()
 if x is not None and x.poll() is None:
  try:os.killpg(x.pid,signal.SIGTERM);x.wait(timeout=3)
  except BaseException as e:record['xvfb_close_error']=repr(e)
 (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')

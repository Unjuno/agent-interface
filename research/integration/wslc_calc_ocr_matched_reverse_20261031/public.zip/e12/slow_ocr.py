import json,os,time
from pathlib import Path
p=Path('/out');(p/'slow-started.json').write_text(json.dumps({'pid':os.getpid(),'monotonic_ns':time.monotonic_ns()}))
time.sleep(3)
(p/'late-marker').write_text('late effect')

import ctypes,json,os,sys,time
from pathlib import Path
from ctypes import wintypes
from win_job_spawn import AtomicJobProcess
root=Path(sys.argv[1]);nonce=sys.argv[2];k=ctypes.WinDLL('kernel32',use_last_error=True)
k.GetProcessTimes.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.FILETIME),ctypes.POINTER(wintypes.FILETIME),ctypes.POINTER(wintypes.FILETIME),ctypes.POINTER(wintypes.FILETIME)];k.GetProcessTimes.restype=wintypes.BOOL
p=AtomicJobProcess([sys.executable,'-c','import time;time.sleep(30)'])
try:
 p.start();a=wintypes.FILETIME();b=wintypes.FILETIME();c=wintypes.FILETIME();d=wintypes.FILETIME()
 if not k.GetProcessTimes(p.process,ctypes.byref(a),ctypes.byref(b),ctypes.byref(c),ctypes.byref(d)):raise OSError(ctypes.get_last_error(),'GetProcessTimes')
 ready={'nonce':nonce,'owner_pid':os.getpid(),'pid':p.pid,'creation_filetime':(a.dwHighDateTime<<32)|a.dwLowDateTime,'member':p.in_job(),'suspended':p.suspended,'time_ns':time.monotonic_ns()}
 t=root/'ready.tmp';t.write_text(json.dumps(ready));os.replace(t,root/'ready.json');time.sleep(30)
finally:p.close()

import ctypes,hashlib,json,subprocess,sys,time,uuid
from pathlib import Path
from ctypes import wintypes
root=Path(sys.argv[1]);k=ctypes.WinDLL('kernel32',use_last_error=True)
k.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];k.OpenProcess.restype=wintypes.HANDLE
k.GetProcessTimes.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.FILETIME),ctypes.POINTER(wintypes.FILETIME),ctypes.POINTER(wintypes.FILETIME),ctypes.POINTER(wintypes.FILETIME)];k.GetProcessTimes.restype=wintypes.BOOL
k.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];k.WaitForSingleObject.restype=wintypes.DWORD
k.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)];k.GetExitCodeProcess.restype=wintypes.BOOL
k.TerminateProcess.argtypes=[wintypes.HANDLE,wintypes.UINT];k.TerminateProcess.restype=wintypes.BOOL
k.CloseHandle.argtypes=[wintypes.HANDLE];k.CloseHandle.restype=wintypes.BOOL
nonce=uuid.uuid4().hex
result={'status':'UNKNOWN','nonce':nonce,'started_ns':time.monotonic_ns(),'source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ('owner.py','audit.py','win_job_spawn.py')}};owner=None;child=None;verified=False
try:
 for name in ('ready.json','ready.tmp','result.json','owner.stdout','owner.stderr'):
  if (root/name).exists():raise FileExistsError('attempt output already exists')
 with (root/'owner.stdout').open('xb') as stdout,(root/'owner.stderr').open('xb') as stderr:
  owner=subprocess.Popen([sys.executable,str(root/'owner.py'),str(root),nonce],stdout=stdout,stderr=stderr,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));result['owner_pid']=owner.pid
  deadline=time.monotonic()+10
  while not (root/'ready.json').exists():
   if owner.poll() is not None:raise RuntimeError('owner exited before ready')
   if time.monotonic()>=deadline:raise TimeoutError('owner ready timeout')
   time.sleep(.05)
  ready=json.loads((root/'ready.json').read_text());result['ready']=ready
  if ready.get('nonce')!=nonce or ready.get('owner_pid')!=owner.pid or ready.get('member') is not True or ready.get('suspended') is not True:raise RuntimeError('not ready or identity mismatch')
  child=k.OpenProcess(0x00101001,False,ready['pid'])
  if not child:raise OSError(ctypes.get_last_error(),'OpenProcess')
  a=wintypes.FILETIME();b=wintypes.FILETIME();c=wintypes.FILETIME();d=wintypes.FILETIME()
  if not k.GetProcessTimes(child,ctypes.byref(a),ctypes.byref(b),ctypes.byref(c),ctypes.byref(d)):raise OSError(ctypes.get_last_error(),'GetProcessTimes')
  observed=(a.dwHighDateTime<<32)|a.dwLowDateTime
  if observed!=ready['creation_filetime']:raise RuntimeError('creation time mismatch')
  verified=True;result['child_handle_verified']=True;result['pre_wait']=k.WaitForSingleObject(child,0)
  if result['pre_wait']!=258:raise RuntimeError('child already exited')
  result['owner_terminate_ns']=time.monotonic_ns();owner.terminate();result['owner_exit']=owner.wait(timeout=5)
  result['child_post_wait']=k.WaitForSingleObject(child,5000);result['child_post_ns']=time.monotonic_ns()
  code=wintypes.DWORD()
  if k.GetExitCodeProcess(child,ctypes.byref(code)):result['child_exit_code']=code.value
  if result['child_post_wait']==0:result['status']='observed_child_exit_after_owner_death'
except BaseException as e:result.update(error_type=type(e).__name__,error=str(e))
finally:
 try:
  if owner is not None and owner.poll() is None:
   owner.terminate()
   try:owner.wait(timeout=5)
   except subprocess.TimeoutExpired:result['owner_cleanup']='unconfirmed'
 except BaseException as e:result['owner_cleanup_error']=type(e).__name__
 try:
  if child and verified and k.WaitForSingleObject(child,0)!=0:
   result['fallback_terminate_called']=True;result['fallback_terminate_ok']=bool(k.TerminateProcess(child,1));result['fallback_wait']=k.WaitForSingleObject(child,5000)
 except BaseException as e:result['child_cleanup_error']=type(e).__name__
 try:
  if child:result['child_handle_closed']=bool(k.CloseHandle(child))
 except BaseException as e:result['child_handle_close_error']=type(e).__name__
 result['ended_ns']=time.monotonic_ns()
 try:
  with (root/'result.json').open('x',encoding='utf-8') as output:output.write(json.dumps(result,indent=2)+'\n')
 except BaseException as e:print(json.dumps({'result_write_error':type(e).__name__}),file=sys.stderr)
 print(json.dumps({'status':result['status'],'error':result.get('error_type'),'fallback':result.get('fallback_terminate_called',False)}))

import json, os, select, subprocess, time
from pathlib import Path

ROOT = Path("/home/user/.cache/agent-interface-map01-20261120-r281")
SOURCE = ROOT / "source"
OUT = ROOT / "trial"
RUNNER = SOURCE / "research/doom/session_map01_v12.py"
PYTHON = Path("/home/user/.cache/agent-interface-map01-20261103/bin/python")
SEED = 281
ATTEMPT_ID = "R281-one-shot"
DRIVER_LOG = ROOT / "driver.jsonl"
DRIVER_LOG.unlink(missing_ok=True)

def record(obj):
    with DRIVER_LOG.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, sort_keys=True) + "\n")

def ammo_signal(obs):
    if not isinstance(obs, dict) or obs.get("event") != "typed_observation":
        return None
    if obs.get("schema") != "doom-typed-observation-v1":
        return None
    if obs.get("artifact_published") is not False or obs.get("grants_input_authority") is not False:
        return None
    sigs = obs.get("signals")
    if not isinstance(sigs, dict):
        return None
    row = sigs.get("ammo")
    if not isinstance(row, dict) or row.get("status") != "observed":
        return None
    value = row.get("value")
    if type(value) is not int or type(obs.get("sequence")) is not int:
        return None
    if row.get("sequence") != obs.get("sequence"):
        return None
    return value

verification = json.loads((ROOT / "SOURCE_VERIFY.json").read_text(encoding="utf-8"))
if verification.get("all_match") is not True or verification.get("count") != 41:
    raise SystemExit("source verification failed; no game launch")
if OUT.exists():
    raise SystemExit("trial output path already exists; no game launch")
with open(ROOT / "stderr.log", "w", encoding="utf-8") as stderr_file:
    env = os.environ.copy()
    env["PYTHONPATH"] = str(SOURCE) + ":" + str(SOURCE / "research/observation_tiles")
    cmd = [str(PYTHON), str(RUNNER), "--out", str(OUT), "--seed", str(SEED),
           "--timeout-seconds", "60", "--skill", "1"]
    record({"event":"driver_start","monotonic_ns":time.perf_counter_ns(),
            "command":cmd,"allocation":"R281","attempt":ATTEMPT_ID})
    proc = subprocess.Popen(cmd, cwd=RUNNER.parent, env=env, stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE, stderr=stderr_file, bufsize=0)
    latest = None
    baseline = None
    after = None
    ready = False
    ready_ops = None
    submitted = False
    terminal = None
    release_events = []
    finish_sent = False
    recovery_submitted = False
    terminal_count = 0
    cancel_sent = False
    stdin_closed = False
    start = time.monotonic()
    submit_at = None
    finish_at = None
    buffer = bytearray()

    def send(payload):
        record({"event":"driver_send","monotonic_ns":time.perf_counter_ns(),
                "payload":payload})
        proc.stdin.write((json.dumps(payload,separators=(",",":"))+"\n").encode())
        proc.stdin.flush()

    def gate_baseline(obs, ops):
        global baseline, submitted, submit_at, finish_sent, finish_at
        if baseline is not None or submitted or not ready:
            return
        baseline = obs
        initial_ammo = ammo_signal(baseline)
        eligible = (initial_ammo == 50 and isinstance(baseline, dict)
                    and type(baseline.get("sequence")) is int
                    and "submit" in (ops or []) and "finish" in (ops or []))
        record({"event":"baseline_gate","sequence":(baseline or {}).get("sequence"),
                "ammo":initial_ammo,"eligible":eligible,"ready_operations":ops,
                "observation_grants_authority":(baseline or {}).get("grants_input_authority")})
        if eligible:
            payload={"op":"submit","id":ATTEMPT_ID,
                     "expected_sequence":baseline["sequence"],
                     "valid_until_ns":time.perf_counter_ns()+250_000_000,
                     "steps":[{"op":"hold","keys":["Right"],"duration_ms":1200},
                              {"op":"hold","keys":["space"],"duration_ms":100}]}
            submitted=True
            submit_at=time.monotonic()
            send(payload)
        else:
            send({"op":"finish"})
            finish_sent=True
            finish_at=time.monotonic()

    while True:
        if proc.poll() is not None:
            break
        readable, _, _ = select.select([proc.stdout], [], [], 0.25)
        if readable:
            chunk = os.read(proc.stdout.fileno(), 65536)
            if not chunk:
                break
            buffer.extend(chunk)
            while b"\n" in buffer:
                raw, _, rest = buffer.partition(b"\n")
                buffer[:] = rest
                line = raw.decode("utf-8", errors="replace")
                try:
                    row = json.loads(line)
                except Exception:
                    record({"event":"runner_stdout_non_json","raw":line})
                    continue
                record({"event":"runner_stdout","row":row})
                kind = row.get("event")
                if kind == "typed_observation":
                    latest = row
                    if submitted and baseline is not None and row.get("sequence",0) > baseline.get("sequence",0):
                        after = row
                    if ready and baseline is None:
                        gate_baseline(row, ready_ops)
                if kind == "input_released":
                    release_events.append(row)
                if kind == "ready" and not ready:
                    ready = True
                    ready_ops = row.get("operations", [])
                    record({"event":"ready_observed","operations":ready_ops})
                    if latest is not None and baseline is None:
                        gate_baseline(latest, ready_ops)
                if kind == "terminal":
                    terminal = row
                    terminal_count += 1
                    if terminal_count == 1:
                        release = row.get("release")
                        cause = row.get("interruption", {}).get("record", {})
                        eligible_recovery = (row.get("status") == "expired"
                            and isinstance(release, dict) and release.get("verified") is True
                            and release.get("keys_down") == [] and release.get("buttons_down") == []
                            and cause.get("reason") == "expired" and cause.get("verified") is True
                            and isinstance(latest, dict) and type(latest.get("sequence")) is int)
                        record({"event":"recovery_gate","eligible":eligible_recovery,
                                "latest_sequence":(latest or {}).get("sequence"),
                                "first_terminal_status":row.get("status"),
                                "release_verified":(release or {}).get("verified"),
                                "cause_reason":cause.get("reason")})
                        if eligible_recovery:
                            recovery={"op":"submit","id":"R281-recovery",
                                "expected_sequence":latest["sequence"],
                                "valid_until_ns":time.perf_counter_ns()+5_000_000_000,
                                "steps":[{"op":"observe"}]}
                            recovery_submitted=True
                            submitted=True
                            submit_at=time.monotonic()
                            send(recovery)
                        else:
                            send({"op":"finish"})
                            finish_sent=True
                            finish_at=time.monotonic()
                    elif terminal_count == 2 and not finish_sent:
                        release = row.get("release")
                        eligible_attack = (row.get("id") == "R281-recovery"
                            and row.get("status") == "completed"
                            and isinstance(release, dict) and release.get("verified") is True
                            and isinstance(latest, dict) and latest.get("id") == "R281-recovery"
                            and ammo_signal(latest) == 50
                            and latest.get("sequence", 0) > (baseline or {}).get("sequence", 0))
                        record({"event":"post_expiry_action_gate","eligible":eligible_attack,
                                "recovery_sequence":(latest or {}).get("sequence"),
                                "recovery_ammo":ammo_signal(latest),
                                "recovery_terminal_status":row.get("status"),
                                "recovery_release_verified":(release or {}).get("verified")})
                        if eligible_attack:
                            attack={"op":"submit","id":"R281-live-effect",
                                "expected_sequence":latest["sequence"],
                                "valid_until_ns":time.perf_counter_ns()+5_000_000_000,
                                "steps":[{"op":"hold","keys":["space"],"duration_ms":100},
                                         {"op":"observe"}]}
                            submitted=True
                            submit_at=time.monotonic()
                            send(attack)
                        else:
                            send({"op":"finish"})
                            finish_sent=True
                            finish_at=time.monotonic()
                    elif not finish_sent:
                        send({"op":"finish"})
                        finish_sent=True
                        finish_at=time.monotonic()
                if kind == "post_control_score":
                    record({"event":"driver_saw_score","row":row})
        elapsed=time.monotonic()-start
        if not ready and elapsed>25:
            record({"event":"driver_setup_deadline","elapsed_s":elapsed})
            proc.stdin.close()
            stdin_closed=True
            break
        if submitted and not finish_sent and not cancel_sent and submit_at is not None and time.monotonic()-submit_at>10:
            record({"event":"driver_cancel_deadline","elapsed_s":time.monotonic()-submit_at})
            send({"op":"cancel","id":ATTEMPT_ID})
            cancel_sent=True
        if cancel_sent and not finish_sent and submit_at is not None and time.monotonic()-submit_at>20:
            record({"event":"driver_close_stdin_for_owned_cleanup","elapsed_s":time.monotonic()-submit_at})
            proc.stdin.close()
            stdin_closed=True
            break
        if finish_sent and finish_at is not None and time.monotonic()-finish_at>25:
            record({"event":"driver_finish_wait_deadline","elapsed_s":time.monotonic()-finish_at})
            proc.stdin.close()
            stdin_closed=True
            break

    if buffer:
        try:
            row=json.loads(buffer.decode("utf-8"))
            record({"event":"runner_stdout","row":row})
        except Exception:
            record({"event":"runner_stdout_tail","raw":buffer.decode("utf-8",errors="replace")})
    if not stdin_closed and proc.stdin and not proc.stdin.closed:
        proc.stdin.close()
    try:
        proc.wait(timeout=15)
        process_state={"returncode":proc.returncode,"alive":False}
    except subprocess.TimeoutExpired:
        process_state={"returncode":None,"alive":True}
    release_verified = isinstance(terminal,dict) and isinstance(terminal.get("release"),dict) and terminal["release"].get("verified") is True
    before = ammo_signal(baseline)
    after_value = ammo_signal(after)
    disposition={
       "schema":"wslc-map01-one-shot-disposition-v1",
       "allocation":"R281","attempt":ATTEMPT_ID,
       "launched":True,"submitted":submitted,
       "baseline_sequence":(baseline or {}).get("sequence"),
       "baseline_ammo":before,
       "post_sequence":(after or {}).get("sequence"),
       "post_ammo":after_value,
       "ammo_delta":None if before is None or after_value is None else after_value-before,
       "terminal_status":terminal.get("status") if isinstance(terminal,dict) else None,
       "terminal_release_verified":release_verified,
       "input_released_events":release_events,
       "process":process_state,
       "task_effect":"PENDING_RAW_AUDIT",
       "scope":"one shot only; not MAP01 exit or efficiency comparison"
    }
    (ROOT/"provisional-disposition.json").write_text(json.dumps(disposition,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    record({"event":"driver_end","monotonic_ns":time.perf_counter_ns(),"disposition":disposition})

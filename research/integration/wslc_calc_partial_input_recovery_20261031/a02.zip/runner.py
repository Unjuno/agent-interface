import os,time,json,subprocess,signal,shutil,hashlib
from pathlib import Path
from Xlib import X,display
from runtime.cli_v1.mcp_guarded import GuardedSessionOwner
from composition import CalcComposition
from pair_saved_oracle import score_saved
from crop_pixel_cue import create_reference
from PIL import Image
out=Path('/out');env=dict(os.environ,DISPLAY=':153',HOME='/tmp',SAL_USE_VCLPLUGIN='gen');actors=[];handles=[];b=None;d=None;owner=None
try:
 def spawn(name,args):
  f=(out/(name+'.log')).open('wb');handles.append(f);p=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);actors.append(p);return p
 x=spawn('xvfb',['Xvfb',':153','-screen','0','1280x800x24','-nolisten','tcp','-ac'])
 for _ in range(100):
  try:d=display.Display(':153');break
  except Exception:time.sleep(.05)
 if d is None:raise RuntimeError('Xvfb unavailable')
 shutil.copyfile('/in/blank.fods','/tmp/blank.fods');spawn('openbox',['openbox','--sm-disable']);lo=spawn('calc',['libreoffice','-env:UserInstallation=file:///tmp/observe-profile','--calc','--nologo','--norestore','--nofirststartwizard','/tmp/blank.fods'])
 def walk(w,depth=0):
  if depth>6:return []
  out=[]
  for child in w.query_tree().children:
   try:
    title=child.get_wm_name();title=title.decode(errors='replace') if isinstance(title,bytes) else str(title or '')
    out.append((child.id,title,child.get_attributes().map_state));out+=walk(child,depth+1)
   except Exception:pass
  return out
 end=time.monotonic()+20;found=[]
 while time.monotonic()<end:
  found=[r for r in walk(d.screen().root) if 'blank.fods' in r[1].lower() and 'calc' in r[1].lower() and r[2]==X.IsViewable]
  if len(found)==1:break
  if len(found)>1:raise RuntimeError('ambiguous target')
  if lo.poll() is not None:raise RuntimeError('calc exited')
  time.sleep(.05)
 if len(found)!=1:
  (out/'window-inventory.json').write_text(json.dumps(walk(d.screen().root),indent=2)+'\n')
  raise RuntimeError('target unavailable')
 time.sleep(1);owner=GuardedSessionOwner({'app':found[0][0]},out/'owner',':153');owner.get();b=owner.bridge;obs=b.observe();rgb=b.history[obs['sequence']][1]
 if hashlib.sha256(rgb.crop((0,97,42,119)).tobytes()).hexdigest()!='2e86f3a0f6d87ee4fb4e5ffeb7cfd159d715cb5f6f8177b0ede83784d49088cf':raise RuntimeError('initial A1 name-box differs from reviewed source')
 # Fixed, previously reviewed A1 point. No model call in this trial.
 field=[81,151];initial_binding=obs['pointer_binding'];initial_rgb=rgb.copy()
 entry=b.mint_reference('entry',obs['sequence'],field,region_size=(30,20));save=b.mint_reference('sheet',obs['sequence'],[440,28],region_size=(30,14))
 approved={'geometry_reviewed':True,'image_size':[1280,800],'scope':b.scope,'revision':b.binding_revision,'binding':initial_binding,'titles':[found[0][1]],'pixel_reference_reviewed':True}
 refs={'entry_alias':'entry','entry_offset':entry['offset'],'save_alias':'sheet','save_offset':save['offset'],'cell_regions':[[37,143,126,159],[37,159,126,176]],'context_region':[350,20,370,35]}
 reference=create_reference(Image.open('/in/reference.png').convert('RGB'))
 comp=CalcComposition(owner,out/'first-method',refs=refs,approved=approved,reviewed_native=obs,reviewed_rgb=rgb,pixel_reference=reference)
 first=comp.run('compiled');(out/'first-result.json').write_text(json.dumps(first,indent=2)+'\n');receipt=first['method_receipt']
 failures=[]
 for path in (out/'owner').rglob('*execution.json'):
  record=json.loads(path.read_text());v=record.get('result',{});execution=v.get('execution',{})
  if v.get('status')=='execution_failed':failures.append({'record':str(path),'status':v.get('status'),'error':execution.get('error'),'emissions':execution.get('emissions'),'failed_op':execution.get('failed_op'),'releases':execution.get('releases',[])})
 if receipt['reason']!='execution_failed' or receipt['completed_transitions']!=0 or len(failures)!=1:raise RuntimeError('expected partial failure absent')
 f=failures[0];releases=f['releases']
 if not (f['emissions']>0 and 'MISSING' in str(f['error']) and releases and all(r.get('verified') is True and r.get('keys_down')==[] and r.get('buttons_down')==[] for r in releases) and not b.session.recovery_required):raise RuntimeError('partial failure or neutral custody unverified')
 (out/'partial-failure.json').write_text(json.dumps(f,indent=2)+'\n')
 # Re-observe before explicit review if required; review never sends input.
 if b.review_required:
  pre=b.observe()
  if pre['pointer_binding']!=initial_binding:raise RuntimeError('binding changed before explicit review')
  review=b.review_window(found[0][0]);(out/'window-review.json').write_text(json.dumps(review,indent=2)+'\n')
  if review.get('status')!='reviewed' or review.get('input_dispatched') is not False:raise RuntimeError('window review failed')
 # Re-observe before the distinct, bounded Escape action. No replay of first program.
 obs=b.observe();rgb=b.history[obs['sequence']][1]
 approved.update(scope=b.scope,revision=b.binding_revision,binding=obs['pointer_binding'])
 if obs['pointer_binding']!=initial_binding:raise RuntimeError('binding changed before cancel')
 cancel=b.mint_reference('cancel_edit',obs['sequence'],[440,28],region_size=(30,14))
 cancellation=b.keyboard('cancel_edit',cancel['offset'],tail=[{'op':'key_chord','keys':['Escape']}],expires_at_ns=time.monotonic_ns()+2_000_000_000)
 (out/'cancel-result.json').write_text(json.dumps(cancellation,indent=2)+'\n')
 rel=cancellation.get('execution',{}).get('releases',[])
 if cancellation.get('status')!='completed' or not rel or not all(r.get('verified') is True and r.get('keys_down')==[] and r.get('buttons_down')==[] for r in rel):raise RuntimeError('cancel or release not verified')
 obs=b.observe();rgb=b.history[obs['sequence']][1]
 inner_boxes=[[42,146,120,157],[42,163,120,173]]
 gate={'fresh_sequence':obs['sequence'],'same_binding':obs['pointer_binding']==initial_binding,'interior_equal_original_blank':[rgb.crop(box).tobytes()==initial_rgb.crop(box).tobytes() for box in inner_boxes],'full_cell_equal_original':[rgb.crop(box).tobytes()==initial_rgb.crop(box).tobytes() for box in refs['cell_regions']],'interior_boxes':inner_boxes,'namebox_a1':hashlib.sha256(rgb.crop((0,97,42,119)).tobytes()).hexdigest()=='2e86f3a0f6d87ee4fb4e5ffeb7cfd159d715cb5f6f8177b0ede83784d49088cf','recovery_actions':1,'max_recovery_actions':1,'original_program_replayed':False}
 (out/'recovery-gate.json').write_text(json.dumps(gate,indent=2)+'\n')
 if gate['same_binding'] is not True or gate['namebox_a1'] is not True or gate['interior_equal_original_blank']!=[True,True]:raise RuntimeError('known-layout blank interior or A1 selection not verified')
 # New references and method execution only after blank-state revalidation.
 entry2=b.mint_reference('entry_after',obs['sequence'],[440,28],region_size=(30,14));save2=b.mint_reference('save_after',obs['sequence'],[440,28],region_size=(30,14))
 refs2=dict(refs,entry_alias='entry_after',entry_offset=entry2['offset'],save_alias='save_after',save_offset=save2['offset'])
 comp2=CalcComposition(owner,out/'second-method',refs=refs2,approved=approved,reviewed_native=obs,reviewed_rgb=rgb,pixel_reference=reference)
 result={'window':found[0],'first_method':first,'cancel':cancellation,'method':comp2.run('compiled')}
 close=owner.close();owner=None;b=None;result['close']=close
 keys=d.query_keymap();result['keys_down']=[i for i in range(256) if keys[i//8]&(1<<(i%8))];result['buttons']=int(d.screen().root.query_pointer().mask)&(X.Button1Mask|X.Button2Mask|X.Button3Mask)
 doc=Path('/tmp/blank.fods');blob=doc.read_bytes();(out/'saved.fods').write_bytes(blob);result['saved_score']=score_saved(blob)
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
finally:
 if owner is not None:owner.close()
 elif b is not None:b.close()
 if d is not None:d.close()
 for p in reversed(actors):
  if p.poll() is None:
   try:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=3)
   except ProcessLookupError:pass
 for f in handles:f.close()

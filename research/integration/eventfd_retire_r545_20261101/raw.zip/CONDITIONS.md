# Notification failure retirement probe r545

Before execution: one fixed-order run of four existing Fake X cases: known
positive effect, successful notification during gated send, injected notification
OSError during gated send, and UNKNOWN after child admission. The third must
observe parent UNKNOWN, owner exit, no synthetic target effect and no replay;
the fourth is expected to fail because child admission already passed. Any
unrelated exception, missing observation or failed fixture cleanup is an error.
Fixture injection, not a naturally failing kernel call or actual cancellation.

Use the pinned Linux image sha256:bd191d30ea94871a1d3ca717252cd07a276e8ef7d1bcb4a130b63935ce075425,
Docker `--network none --cpus 1 --memory 1g --pull never`; read-only source and
dedicated writable output mounts, Python normal mode,
`AGENT_INTERFACE_EXPERIMENTAL_EVENTFD=1`. Save source base/diff before running,
all output, exit status and synthetic artifacts. No real X, physical input or
user GUI is used. Forced owner retirement does not prove queued X requests were
drained, key-up, task outcome, bounded OS calls or that a replacement is safe.
The prototype is not ready for integration.

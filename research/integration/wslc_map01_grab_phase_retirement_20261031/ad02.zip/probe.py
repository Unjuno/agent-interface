import json,time
from pathlib import Path
from Xlib import display
out=Path('/out');d=display.Display(':163')
(out/'probe-ready.json').write_text(json.dumps({'ready_ns':time.monotonic_ns()}))
limit=time.monotonic()+5
while not (out/'down.json').exists():
 if time.monotonic()>limit:raise RuntimeError('down receipt missing')
 time.sleep(.002)
(out/'probe-start.json').write_text(json.dumps({'started_ns':time.monotonic_ns()}))
d.get_input_focus()
(out/'probe-done.json').write_text(json.dumps({'done_ns':time.monotonic_ns()}))
d.close()

import hashlib, json, pathlib, statistics, zipfile

root = pathlib.Path(__file__).resolve().parent
manifest = json.loads((root / 'manifest.json').read_text())
for name, digest in manifest.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
arms = ('disposal-b01', 'disposal-b02')
for arm in arms:
    p = root / arm
    c = json.loads((p / 'conditions.json').read_text())
    assert c['manifest_sha256'] == hashlib.sha256((root / 'manifest.json').read_bytes()).hexdigest()
    assert json.loads((p / 'launcher-result.json').read_text())['returncode'] == 0
    d = json.loads((p / 'output/result.json').read_text())
    assert json.loads((p / 'stdout').read_text()) == d
    assert d['status'] == 'completed' and d['order'] == c['order'] and d['sample_count'] == 41
    sizes = [0, 1000, 10000, 100000]
    if c['order'] == 'descending': sizes.reverse()
    assert d['sizes'] == sizes and [x['size'] for x in d['results']] == sizes
    for x in d['results']:
        assert len(x['samples']) == 41
        for i, sample in enumerate(x['samples']):
            assert sample['index'] == i and sample['order'] == (['excluding_disposal', 'including_disposal'] if i % 2 == 0 else ['including_disposal', 'excluding_disposal'])
            assert sample['excluding_disposal_ns'] > 0 and sample['including_disposal_ns'] > 0
        for op in ('excluding_disposal', 'including_disposal'):
            assert x[op + '_median_ns'] == statistics.median(s[op + '_ns'] for s in x['samples'])

dest = root.parent / 'guarded-motion-deadline-r01/research/integration/wslc_idle_history_disposal_cost_20261101'
dest.mkdir(parents=True, exist_ok=False)
paths = [root / n for n in manifest] + [root / 'manifest.json', pathlib.Path(__file__)]
for arm in arms:
    p = root / arm
    paths += [p / 'conditions.json', p / 'launcher-result.json', p / 'stdout', p / 'stderr', p / 'output/result.json']
public = {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
with zipfile.ZipFile(dest / 'raw.zip', 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for p in paths: z.write(p, p.relative_to(root).as_posix())
    z.writestr('public-manifest.json', json.dumps(public, indent=2, sort_keys=True) + '\n')
with zipfile.ZipFile(dest / 'raw.zip') as z:
    for name, digest in public.items(): assert hashlib.sha256(z.read(name)).hexdigest() == digest
print('validated; archive sha256', hashlib.sha256((dest / 'raw.zip').read_bytes()).hexdigest())

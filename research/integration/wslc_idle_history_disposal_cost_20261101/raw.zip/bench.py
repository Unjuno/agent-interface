"""Measure fork insertion with and without disposal, using identical histories."""
import gc, hashlib, json, os, pathlib, statistics, time
from PIL import Image
from runtime.guarded_x11_v1.history import ObservationHistory

image = Image.new('RGB', (16, 16), (25, 50, 75))
raw = hashlib.sha256(image.tobytes()).hexdigest()
def row(n):
    return ({'sequence': n, 'native': {'width': 16, 'height': 16, 'sha256': raw,
        'artifact': {'path': f'/synthetic/{n}.png', 'sha256': '0'*64, 'source_raw_sha256': raw}}}, image)
sizes = [0, 1000, 10000, 100000]
if os.environ['ORDER'] == 'descending': sizes.reverse()
results = []
gc.collect(); gc.disable()
try:
    for n in sizes:
        history = ObservationHistory(2)
        for i in range(n): history[i] = row(i)
        candidate = row(n+1); samples = []
        for i in range(41):
            order = ('excluding_disposal', 'including_disposal') if i % 2 == 0 else ('including_disposal', 'excluding_disposal')
            sample = {'index': i, 'order': list(order)}
            for op in order:
                start = time.perf_counter_ns()
                staged = history.fork(); staged[n+1] = candidate
                if op == 'including_disposal': del staged
                sample[op+'_ns'] = time.perf_counter_ns() - start
                if op == 'excluding_disposal': del staged
            samples.append(sample)
        assert len(history) == n and n+1 not in history
        results.append({'size': n, 'samples': samples, **{op+'_median_ns': statistics.median(s[op+'_ns'] for s in samples) for op in ('excluding_disposal', 'including_disposal')}})
        del history
finally: gc.enable()
result = {'status': 'completed', 'order': os.environ['ORDER'], 'sizes': sizes, 'sample_count': 41, 'results': results,
          'limits': 'synthetic metadata, shared image, no capture, IPC, input, model, concurrent readers, or GUI task; disposal of staged copy while original remains live'}
(pathlib.Path('/out')/'result.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result), flush=True)

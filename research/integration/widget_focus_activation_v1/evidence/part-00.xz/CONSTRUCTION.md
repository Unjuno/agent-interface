# Construction log

Construction-01: STOP, app ready response exceeded 3 seconds before any native input. The server was closed afterward and app stderr retained XIO. The constructor failed before returning its process owner to the caller; the first code did not retain an actual app wait status. `/proc` process scan afterward found no live study-owned process. Do not infer a missing exit code. Sources and output remain in construction-01.

Preformal engineering correction: startup-only response bound is 12 seconds; subsequent RPC bound remains 3 seconds. Constructor now terminates/waits/records its child if ready fails. This change does not tune an effect/recipe gate. Formal cases remain zero.

Construction-02: STOP_TARGET_ANCESTRY before input, actual app exit0 retained. The wrapper-identity check incorrectly equated Tk `frame()` with the X parent of the client. Corrected to independent client-parent-root ancestry plus natural X focus, matching the inherited actual target-registration rule. Source/output retained; no backend change.

Construction-03:3/3 complete; native-child activation matched A XID but internal B received digit3; click restored A. Construction-04:9/9 complete and zero row-audit errors.13 preformal unittest methods pass, including12 semantic corruption variants.

Environment-record attempt01 raised PackageNotFoundError for importlib.metadata python-xlib because the installed module has no distribution metadata. No scientific run. The authoritative module reports version via Xlib.__version__; corrected before freeze. Execution sources and effect gates unchanged.

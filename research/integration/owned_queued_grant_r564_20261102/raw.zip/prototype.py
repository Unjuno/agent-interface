import json,os,select,signal,subprocess,sys,time
from pathlib import Path
mode=sys.argv[1];root=Path(sys.argv[2]);run=sys.argv[3]
def log(event,**kw):
    with (root/'events.jsonl').open('a') as f:
        f.write(json.dumps(dict(run=run,event=event,pid=os.getpid(),ns=time.monotonic_ns(),**kw))+'\n');f.flush()
def waitfile(name,secs=8):
    end=time.monotonic()+secs
    while time.monotonic()<end:
        p=root/name
        if p.exists():return p.read_text().strip()
        time.sleep(.01)
    raise TimeoutError(name)
if mode=='child':
    fd=int(sys.argv[4]);token=os.read(fd,1);os.close(fd)
    if token==b'G':
        (root/'effect').write_text(run);log('fake_effect')
    elif token==b'':log('grant_refused_eof')
    else:raise RuntimeError('invalid grant')
elif mode=='supervisor':
    parentfd=int(sys.argv[4]);child=None;grant_write=None
    try:
        (root/'ready').write_text(run);log('supervisor_ready')
        if waitfile('spawn')!=run:raise ValueError('run mismatch')
        gr,grant_write=os.pipe()
        child=subprocess.Popen([sys.executable,__file__,'child',str(root),run,str(gr)],pass_fds=(gr,),start_new_session=True)
        os.close(gr);log('child_spawned',child=child.pid);(root/'child.pid').write_text(str(child.pid))
        if waitfile('observe')!=run:raise ValueError('observe mismatch')
        if not select.select([parentfd],[],[],4)[0]:raise TimeoutError('parent decision')
        token=os.read(parentfd,1)
        if token==b'G':
            log('grant_received');(root/'received').write_text(run)
            if waitfile('forward')!=run:raise ValueError('forward mismatch')
            log('grant_forwarded');os.write(grant_write,b'G')
        elif token==b'':log('parent_eof_no_grant')
        else:raise RuntimeError('bad parent decision')
        os.close(grant_write);grant_write=None
        rc=child.wait(timeout=4);log('child_reaped',child=child.pid,returncode=rc)
    finally:
        if grant_write is not None:os.close(grant_write)
        if child is not None and child.poll() is None:child.kill();child.wait(timeout=2)
        os.close(parentfd)
elif mode=='parent':
    r,w=os.pipe()
    s=subprocess.Popen([sys.executable,__file__,'supervisor',str(root),run,str(r)],pass_fds=(r,),start_new_session=True)
    os.close(r);(root/'supervisor.pid').write_text(str(s.pid));log('supervisor_started',supervisor=s.pid)
    if waitfile('grant')!=run:raise ValueError('grant mismatch')
    log('parent_grant_intent');os.write(w,b'G');waitfile('finish');os.close(w)
elif mode=='controller':
    arm=sys.argv[4];root.mkdir(parents=False,exist_ok=False);p=None;sf=None;cf=None
    try:
        p=subprocess.Popen([sys.executable,__file__,'parent',str(root),run],start_new_session=True)
        sp=int(waitfile('supervisor.pid'));sf=os.pidfd_open(sp)
        if waitfile('ready')!=run:raise ValueError('ready mismatch')
        if arm=='death':p.kill();p.wait(timeout=3);log('parent_reaped',returncode=p.returncode)
        elif arm!='queued':raise ValueError('bad arm')
        (root/'spawn').write_text(run);cp=int(waitfile('child.pid'));cf=os.pidfd_open(cp)
        if select.select([cf],[],[],0)[0]:raise RuntimeError('child exited before decision')
        log('child_pidfd_not_exited',child=cp)
        if arm=='queued':(root/'grant').write_text(run)
        (root/'observe').write_text(run)
        if arm=='queued':
            if waitfile('received')!=run:raise ValueError('received mismatch')
            p.kill();p.wait(timeout=3);log('parent_reaped',returncode=p.returncode)
            (root/'forward').write_text(run)
        if not select.select([sf],[],[],8)[0]:raise TimeoutError('supervisor exit')
        if not select.select([cf],[],[],1)[0]:raise RuntimeError('child exit')
        rows=[json.loads(x) for x in (root/'events.jsonl').read_text().splitlines()]
        def one(name):
            xs=[e for e in rows if e['run']==run and e['event']==name]
            if len(xs)!=1:raise RuntimeError('invalid event '+name)
            return xs[0]
        spawn=one('child_spawned');reap=one('child_reaped')
        if spawn['child']!=cp or reap['child']!=cp or reap['returncode']!=0:raise RuntimeError('child identity/exit')
        if arm=='death':
            death=one('parent_reaped');eof=one('parent_eof_no_grant');refusal=one('grant_refused_eof')
            if not death['ns']<spawn['ns']<eof['ns']<refusal['ns']<reap['ns'] or (root/'effect').exists():raise RuntimeError('death arm violation')
        else:
            grant=one('parent_grant_intent');received=one('grant_received');death=one('parent_reaped');forward=one('grant_forwarded');effect=one('fake_effect')
            if not spawn['ns']<grant['ns']<received['ns']<death['ns']<forward['ns']<effect['ns']<reap['ns'] or (root/'effect').read_text()!=run:raise RuntimeError('ordering violation')
        log('result',status='COUNTEREXAMPLE_OBSERVED',arm=arm)
    except BaseException as e:log('result',status='FAIL',error=repr(e));raise
    finally:
        if p is not None and p.poll() is None:p.kill();p.wait(timeout=2);log('fixture_parent_kill')
        for fd,label in ((cf,'child'),(sf,'supervisor')):
            if fd is not None:
                if not select.select([fd],[],[],0)[0]:
                    log('fixture_emergency_kill',target=label)
                    try:signal.pidfd_send_signal(fd,signal.SIGKILL)
                    except ProcessLookupError:pass
                os.close(fd)
else:raise SystemExit(64)

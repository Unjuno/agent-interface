import hashlib,io,json,pathlib,zipfile
from PIL import Image
root=pathlib.Path(__file__).resolve().parent
old=root.parent/'map01-hud-watch-recovery-20261101'
manifest=json.loads((old/'frozen-manifest.json').read_text())
for name,digest in manifest.items():
    data=(old/name).read_bytes();assert hashlib.sha256(data).hexdigest()==digest
    target=root/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
archive=root.parent/'guarded-motion-deadline-r01/research/integration/wslc_map01_hud_watch_continuation_20261101/public.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='5911b2af27406e4e83f5594b68a2f530b54bf6a7740681574ac703f257056f54'
with zipfile.ZipFile(archive) as z: frame=Image.open(io.BytesIO(z.read('eu02/output/scene-end.png'))).convert('RGB')
frame.crop((32,408,90,450)).save(root/'48.png')
manifest['48.png']=hashlib.sha256((root/'48.png').read_bytes()).hexdigest()
runner=root/'runner.py'; text=runner.read_text(encoding='utf8')
old_text=" sample('after-post-watch')\n for _ in range(8):"
new_text=""" sample('after-post-watch')
 # Passive, bounded visual follow-up; no input and no simulator counters feed it.
 from PIL import Image
 expected48=hashlib.sha256(Image.open('/candidate/48.png').convert('RGB').tobytes()).hexdigest()
 expected49=hashlib.sha256(Image.open('/candidate/49.png').convert('RGB').tobytes()).hexdigest()
 started=time.monotonic_ns();visual_deadline=started+600_000_000;visual={'status':'not_eligible','started_ns':started,'deadline_ns':visual_deadline,'observations':[],'input_dispatched':False}
 if expected48==expected49:raise RuntimeError('visual templates ambiguous')
 if post.get('status') in ('completed','control_withheld'):
  visual['status']='timeout_unknown'
  while time.monotonic_ns()<visual_deadline:
   v=bridge.observe();pixels=bridge.history[v['sequence']][1];digest=hashlib.sha256(pixels.crop(box).tobytes()).hexdigest();checked=time.monotonic_ns()
   row={'sequence':v['sequence'],'crop_sha256':digest,'checked_ns':checked,'binding_equal':v['pointer_binding']==post['source']['binding']};visual['observations'].append(row)
   if checked>=visual_deadline:break
   if not row['binding_equal']:visual['status']='binding_unknown';break
   if digest==expected48:visual['status']='visual_48';break
   if digest!=expected49:visual['status']='unrecognized_unknown';break
   time.sleep(.015)
 visual['ended_ns']=time.monotonic_ns();visual['template48_sha256']=expected48;visual['template49_sha256']=expected49
 record['post_effect_visual']=visual;(out/'post-effect-visual.json').write_text(json.dumps(visual,indent=2)+'\\n')
 sample('after-effect-review')
 for _ in range(8):"""
assert old_text in text
runner.write_text(text.replace(old_text,new_text),encoding='utf8',newline='\n')
manifest['runner.py']=hashlib.sha256(runner.read_bytes()).hexdigest()
(root/'frozen-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf8')
launch=(old/'launch.py').read_text(encoding='utf8').replace("'map01-postwatch-'","'map01-visibleeffect-'")
(root/'launch.py').write_text(launch,encoding='utf8',newline='\n')
for ident,mode in [('ev01','fire'),('ev02','withhold')]:
    p=root/ident;p.mkdir();(p/'output').mkdir();(p/'exchange').mkdir()
    c={'allocation':ident,'route':'watch','seed':991040,'hud':'on','post_mode':mode,
       'order':['ev01:fire','ev02:withhold'],'freeze_main':'b516aefb20ed69ab66bcd272ed9849bc985e90f0',
       'image':'sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25',
       'manifest_sha256':hashlib.sha256((root/'frozen-manifest.json').read_bytes()).hexdigest(),
       'launcher_sha256':hashlib.sha256((root/'launch.py').read_bytes()).hexdigest(),
       'template48_source':'prior eu02 end screenshot, crop (32,408,90,450), visual 48; new seed is held out',
       'scenario':'after watch interruption and reviewed 49 HUD, execute preplanned 85ms attack or withhold; observe screen only up to 600ms for exact 48',
       'criterion':'fire: independently verified release, fresh binding and visual 48 within cooperative deadline; withhold: no followup input and no visual 48 before timeout; final release neutral',
       'stop':'one attempt per arm; no success retry; unexpected cue is unknown; stop block on unresolved input or infrastructure error',
       'limits':'two independent fixed-order games, fixed exact templates and layout, evaluator counters excluded from controller, no model or MAP01 completion'}
    (p/'conditions.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf8')
print('visual follow-up pair frozen')

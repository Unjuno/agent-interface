import hashlib,json,os,pathlib,subprocess,sys,time
root=pathlib.Path(__file__).resolve().parent
p=root/sys.argv[1]
c=json.loads((p/'conditions.json').read_text())
manifest=json.loads((root/'frozen-manifest.json').read_text())
if hashlib.sha256((root/'frozen-manifest.json').read_bytes()).hexdigest()!=c['manifest_sha256']: raise RuntimeError('manifest changed')
if hashlib.sha256((root/'launch.py').read_bytes()).hexdigest()!=c['launcher_sha256']: raise RuntimeError('launcher changed')
for name,digest in manifest.items():
    if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest: raise RuntimeError('candidate changed '+name)
name='map01-visibleeffect-'+c['allocation']+'-20261101'
cmd=['wslc','run','--rm','--name',name,'--network','none','--cpus','1','--memory','1g','--pull','never',
     '--mount',f'type=bind,source={root},target=/candidate,readonly',
     '--mount',f'type=bind,source={root / "snapshot"},target=/src,readonly',
     '--mount',f'type=bind,source={p / "exchange"},target=/exchange',
     '--mount',f'type=bind,source={p / "output"},target=/out',
     '-w','/tmp','--env','PYTHONPATH=/src','--env','PYTHONDONTWRITEBYTECODE=1',
     '--env','ROUTE='+c['route'],'--env','GAME_SEED='+str(c['seed']),'--env','HUD_MODE='+c['hud'],'--env','POST_MODE='+c['post_mode'],
     '--entrypoint','timeout',c['image'],'--signal=TERM','--kill-after=3s','180s','python3','-B','/candidate/runner.py']
(p/'private-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
flags=getattr(subprocess,'CREATE_NO_WINDOW',0); start=time.monotonic();host=container=None
result={'allocation':c['allocation']}
try:
    with (p/'host.stdout').open('wb') as ho,(p/'host.stderr').open('wb') as he, \
         (p/'container.stdout').open('wb') as co,(p/'container.stderr').open('wb') as ce:
        host=subprocess.Popen([sys.executable,str(root/'host.py'),'fixture',str(p)],stdout=ho,stderr=he,creationflags=flags)
        container=subprocess.Popen(cmd,stdout=co,stderr=ce,creationflags=flags)
        result['container_exit']=container.wait(timeout=200)
        if result['container_exit']!=0:(p/'exchange/stop.json').write_text('{}')
        result['host_exit']=host.wait(timeout=20)
    result['elapsed_seconds']=time.monotonic()-start
except BaseException as e:
    result['error']=repr(e)
    if host is not None and host.poll() is None: host.terminate()
    result['container_running']=container is not None and container.poll() is None
finally:
    (p/'launcher-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
if result.get('container_exit')!=0 or result.get('host_exit')!=0: raise SystemExit(1)

import json,os,signal,subprocess,time,traceback,hashlib,math,threading
from pathlib import Path
from Xlib import X,display,error,XK
import vizdoom as vd
import numpy as np
from PIL import Image
from runtime.cli_v1.mcp_guarded import GuardedSessionOwner

out=Path('/out');route='no_model_observation';x=None;d=None;game=None;owner=None
record={'route':route,'status':'running','task_success':None,'samples':[],'model_calls':0,'events':{}}
try:
 os.environ['DISPLAY']=':153';os.environ['SDL_VIDEODRIVER']='x11';os.environ['HOME']='/tmp';os.environ['XDG_CACHE_HOME']='/tmp/cache'
 log=(out/'xvfb.log').open('wb');x=subprocess.Popen(['Xvfb',':153','-screen','0','1280x1024x24','-nolisten','tcp'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 for _ in range(100):
  try:d=display.Display(':153');break
  except Exception:time.sleep(.05)
 if d is None:raise RuntimeError('Xvfb unavailable')
 cfg=Path('/tmp/doom-keys.ini');cfg.write_text('[Doom.Bindings]\nw=+forward\ne=+use\nd=+right\na=+left\nf=+attack\n')
 pkg=Path(vd.__file__).resolve().parent;iwad=pkg/'freedoom2.wad';record['iwad_sha256']=hashlib.sha256(iwad.read_bytes()).hexdigest()
 game=vd.DoomGame();game.set_doom_game_path(str(iwad));game.set_doom_scenario_path('');game.set_doom_map('MAP01');game.set_doom_config_path(str(cfg));game.set_mode(vd.Mode.ASYNC_SPECTATOR);game.set_ticrate(35);game.set_seed(991031);game.set_doom_skill(1);game.set_episode_timeout(2100);game.set_window_visible(True);game.set_console_enabled(False);game.set_sound_enabled(False);game.set_screen_resolution(vd.ScreenResolution.RES_640X480);game.set_screen_format(vd.ScreenFormat.RGB24);game.set_available_buttons([vd.Button.MOVE_FORWARD,vd.Button.USE,vd.Button.TURN_RIGHT,vd.Button.TURN_LEFT,vd.Button.ATTACK]);game.set_labels_buffer_enabled(True);game.set_objects_info_enabled(True);game.set_available_game_variables([vd.GameVariable.POSITION_X,vd.GameVariable.POSITION_Y,vd.GameVariable.HEALTH,vd.GameVariable.KILLCOUNT,vd.GameVariable.ANGLE]);game.init()
 windows=[]
 for _ in range(250):
  windows=[]
  for w in d.screen().root.query_tree().children:
   try:
    title=w.get_wm_name()
    if title and 'DOOM' in title.upper() and w.get_attributes().map_state==X.IsViewable:windows.append(w)
   except error.BadWindow:pass
  if len(windows)==1:break
  if len(windows)>1:raise RuntimeError('ambiguous game window')
  time.sleep(.02)
 if len(windows)!=1:raise RuntimeError('game window unavailable')
 w=windows[0];d.set_input_focus(w.id,X.RevertToParent,X.CurrentTime);d.sync();time.sleep(.5)
 owner=GuardedSessionOwner({'app':w.id},out/'owner',':153',process_identity=True,query_worker=True);owner.get();bridge=owner.bridge;obs=bridge.observe();geom=obs['pointer_binding']['geometry'];point=[geom[0]+44,geom[1]+geom[3]-54];mint=bridge.mint_reference('game',obs['sequence'],point,region_size=(24,38));record['observation']=obs;record['mint']=mint
 def sample(label):
  game.advance_action(1,True);state=game.get_state();labels=[] if state is None else [str(x.object_name) for x in state.labels];objects=[] if state is None else [{'name':str(x.name),'id':int(x.id),'x':float(x.position_x),'y':float(x.position_y)} for x in state.objects]
  s={'label':label,'host_ns':time.monotonic_ns(),'tic':game.get_episode_time(),'x':game.get_game_variable(vd.GameVariable.POSITION_X),'y':game.get_game_variable(vd.GameVariable.POSITION_Y),'angle':game.get_game_variable(vd.GameVariable.ANGLE),'health':game.get_game_variable(vd.GameVariable.HEALTH),'kills':game.get_game_variable(vd.GameVariable.KILLCOUNT),'finished':game.is_episode_finished(),'visible_labels':labels,'objects':objects};record['samples'].append(s);(out/'samples.jsonl').open('a').write(json.dumps(s)+'\n');return s
 def screenshot(label):
  from PIL import Image
  g=w.get_geometry();raw=w.get_image(0,0,g.width,g.height,X.ZPixmap,0xffffffff);Image.frombytes('RGB',(g.width,g.height),raw.data,'raw','BGRX').save(out/('scene-'+label+'.png'))
 def run_action(alias,tail):
  source=bridge.observe();anchor=[geom[0]+geom[2]//2,geom[1]+geom[3]-100] if alias in ('turn','forward3','fire') else point;ref=bridge.mint_reference(alias,source['sequence'],anchor,region_size=(24,38));owner.dispatch_attempted=True
  result=bridge.keyboard(alias,ref['offset'],tail=tail,expires_at_ns=time.monotonic_ns()+4_000_000_000);(out/('action-'+alias+'.json')).write_text(json.dumps(result,indent=2)+'\n');record.setdefault('actions',[]).append(result)
  releases=result.get('execution',{}).get('releases',[])
  if result.get('status')!='completed' or not releases or not all(r.get('verified') and not r.get('keys_down') and not r.get('buttons_down') for r in releases):raise RuntimeError('action or release not confirmed')
 before=sample('before');screenshot('before')
 run_action('forward1',[{'op':'key_state','key':'w','down':True},{'op':'wait_update','timeout_ms':2000},{'op':'key_state','key':'w','down':False}]);sample('forward1');time.sleep(.8);sample('settle1')
 run_action('turn',[{'op':'key_state','key':'a','down':True},{'op':'wait_update','timeout_ms':900},{'op':'key_state','key':'a','down':False}]);sample('turn');screenshot('at-turn')
 sample('before_cancel')
 source=bridge.observe();oldref=bridge.mint_reference('cancel_target',source['sequence'],point,region_size=(24,38));record['cancel_reference']=oldref
 outcomes=[];errors=[]
 def cancelled_action():
  try:
   with bridge.cancellation_scope('recovery_token'):
    outcomes.append(bridge.keyboard('cancel_target',oldref['offset'],tail=[{'op':'key_state','key':'a','down':True},{'op':'wait_update','timeout_ms':500},{'op':'key_state','key':'a','down':False}],expires_at_ns=time.monotonic_ns()+4_000_000_000))
  except BaseException as e:errors.append(repr(e))
 owner.dispatch_attempted=True;worker=threading.Thread(target=cancelled_action);worker.start();code=d.keysym_to_keycode(XK.string_to_keysym('a'));until=time.monotonic()+2;held=False
 while time.monotonic()<until and worker.is_alive():
  keys=d.query_keymap()
  if keys[code//8]&(1<<(code%8)):held=True;break
  time.sleep(.002)
 record['cancel_monitor']={'held_observed':held,'held_ns':time.monotonic_ns()}
 if not held:
  record['cancel_monitor']['cancel_on_stop']=bridge.request_cancel('recovery_token');worker.join(4)
  record['cancel_monitor']['worker_alive']=worker.is_alive();record['cancel_monitor']['errors']=errors;record['cancel_monitor']['outcomes']=outcomes
  raise RuntimeError('held input not observed; no recovery trial')
 time.sleep(.05);record['cancel_monitor']['request_ns']=time.monotonic_ns();record['cancel_monitor']['response']=bridge.request_cancel('recovery_token');worker.join(4)
 if worker.is_alive() or errors or len(outcomes)!=1:raise RuntimeError('cancel worker unfinished '+repr(errors))
 result=outcomes[0];record['cancel_result']=result;(out/'cancel-action.json').write_text(json.dumps(result,indent=2)+'\n')
 releases=result.get('execution',{}).get('releases',[])
 if result.get('status')!='execution_failed' or not releases or not all(r.get('verified') and not r.get('keys_down') and not r.get('buttons_down') for r in releases):raise RuntimeError('cancel release not verified')
 if record['cancel_monitor']['response'].get('status')!='cancel_requested':raise RuntimeError('cancel request not accepted')
 sample('after_cancel');review=bridge.review_window(w.id);record['recovery_review']={k:v for k,v in review.items() if k!='observation'};(out/'review.json').write_text(json.dumps(review,indent=2)+'\n')
 if review.get('status')!='reviewed':raise RuntimeError('review refused')
 stale=bridge.keyboard('cancel_target',oldref['offset'],tail=[{'op':'key_chord','keys':['a']}],expires_at_ns=time.monotonic_ns()+2_000_000_000);record['stale_after_review']=stale;(out/'stale.json').write_text(json.dumps(stale,indent=2)+'\n')
 if stale.get('status')!='refused' or stale.get('input_dispatched') is not False:raise RuntimeError('stale reference admitted')
 sample('after_review')


 bench=out/'benchmark';bench.mkdir();frames=[]
 for i in range(20):
  if i == 5:
   sample('before_benchmark_fire')
   run_action('benchmark_fire',[{'op':'key_state','key':'f','down':True},{'op':'wait_update','timeout_ms':1000},{'op':'key_state','key':'f','down':False}])
   sample('after_benchmark_fire')
  time.sleep(.08);game.advance_action(1,True);state=game.get_state()
  if state is None or state.screen_buffer is None:raise RuntimeError('frame unavailable')
  arr=np.asarray(state.screen_buffer)
  if arr.shape==(3,480,640):arr=np.moveaxis(arr,0,-1)
  if arr.shape!=(480,640,3) or arr.dtype!=np.uint8:raise RuntimeError('unexpected RGB frame shape or dtype '+repr((arr.shape,str(arr.dtype))))
  target=bench/('frame-%02d.png'%i);Image.fromarray(arr,'RGB').save(target);labels=[{'name':str(v.object_name),'id':int(v.object_id),'x':int(v.x),'y':int(v.y),'width':int(v.width),'height':int(v.height)} for v in state.labels];frames.append({'index':i,'tic':int(state.tic),'number':int(state.number),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'labels':labels,'captured_ns':time.monotonic_ns()})
 (bench/'frames.json').write_text(json.dumps(frames,indent=2)+'\n');record['benchmark_frames']=len(frames);record['first_frame_labels']=len(frames[0]['labels']);final=sample('after-frames');record['health_delta']=final['health']-before['health'];record['kill_delta']=final['kills']-before['kills'];record['close']=owner.close();owner=None
 keys=d.query_keymap();record['keys_down_after']=[key for key in ('w','e','d','a','f') if (lambda code:code and bool(keys[code//8]&(1<<(code%8))))(d.keysym_to_keycode(XK.string_to_keysym(key)))];record['status']='completed'

except BaseException as e:record['status']='error';record['error']=repr(e);(out/'traceback.txt').write_text(traceback.format_exc())
finally:
 if owner is not None:
  try:record['finally_close']=owner.close()
  except BaseException as e:record['close_error']=repr(e)
 if game is not None:
  try:game.close()
  except BaseException as e:record['game_close_error']=repr(e)
 if d is not None:d.close()
 if x is not None and x.poll() is None:
  try:os.killpg(x.pid,signal.SIGTERM);x.wait(timeout=3)
  except BaseException as e:record['xvfb_close_error']=repr(e)
 (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')

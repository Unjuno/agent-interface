import os,time,json,subprocess,signal,shutil,hashlib
from pathlib import Path
from Xlib import X,display
from runtime.cli_v1.mcp_guarded import GuardedSessionOwner
from composition import CalcComposition
from pair_saved_oracle import score_saved
from crop_pixel_cue import create_reference
from PIL import Image
out=Path('/out');env=dict(os.environ,DISPLAY=':153',HOME='/tmp',SAL_USE_VCLPLUGIN='gen');actors=[];handles=[];b=None;d=None;owner=None
try:
 def spawn(name,args):
  f=(out/(name+'.log')).open('wb');handles.append(f);p=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);actors.append(p);return p
 x=spawn('xvfb',['Xvfb',':153','-screen','0','1280x800x24','-nolisten','tcp','-ac'])
 for _ in range(100):
  try:d=display.Display(':153');break
  except Exception:time.sleep(.05)
 if d is None:raise RuntimeError('Xvfb unavailable')
 shutil.copyfile('/in/blank.fods','/tmp/blank.fods');spawn('openbox',['openbox','--sm-disable']);lo=spawn('calc',['libreoffice','-env:UserInstallation=file:///tmp/observe-profile','--calc','--nologo','--norestore','--nofirststartwizard','/tmp/blank.fods'])
 def walk(w,depth=0):
  if depth>6:return []
  out=[]
  for child in w.query_tree().children:
   try:
    title=child.get_wm_name();title=title.decode(errors='replace') if isinstance(title,bytes) else str(title or '')
    out.append((child.id,title,child.get_attributes().map_state));out+=walk(child,depth+1)
   except Exception:pass
  return out
 end=time.monotonic()+20;found=[]
 while time.monotonic()<end:
  found=[r for r in walk(d.screen().root) if 'blank.fods' in r[1].lower() and 'calc' in r[1].lower() and r[2]==X.IsViewable]
  if len(found)==1:break
  if len(found)>1:raise RuntimeError('ambiguous target')
  if lo.poll() is not None:raise RuntimeError('calc exited')
  time.sleep(.05)
 if len(found)!=1:
  (out/'window-inventory.json').write_text(json.dumps(walk(d.screen().root),indent=2)+'\n')
  raise RuntimeError('target unavailable')
 time.sleep(1);owner=GuardedSessionOwner({'app':found[0][0]},out/'owner',':153');owner.get();b=owner.bridge;obs=b.observe();rgb=b.history[obs['sequence']][1]
 if hashlib.sha256(rgb.crop((0,97,42,119)).tobytes()).hexdigest()!='2e86f3a0f6d87ee4fb4e5ffeb7cfd159d715cb5f6f8177b0ede83784d49088cf':raise RuntimeError('initial A1 name-box differs from reviewed source')
 # Send only the owned, synthetic observation to the host model.
 artifact=obs['native']['artifact'];data=Path(artifact['path']).read_bytes()
 if hashlib.sha256(data).hexdigest()!=artifact['sha256'] or artifact['source_raw_sha256']!=obs['native']['sha256']:raise RuntimeError('observation artifact mismatch')
 import io
 if Image.open(io.BytesIO(data)).convert('RGB').tobytes()!=rgb.tobytes():raise RuntimeError('decoded observation mismatch')
 image_path=Path('/exchange/image.png');image_path.write_bytes(data);digest=hashlib.sha256(data).hexdigest()
 request={'id':'pilot-01','image_sha256':digest,'source_sequence':obs['sequence']};tmp=Path('/exchange/request.tmp');tmp.write_text(json.dumps(request));os.replace(tmp,'/exchange/request.json')
 deadline=time.monotonic()+120
 while not Path('/exchange/response.json').exists():
  if time.monotonic()>=deadline:raise TimeoutError('host response not observed')
  time.sleep(.05)
 response=json.loads(Path('/exchange/response.json').read_text())
 if response.get('id')!='pilot-01' or response.get('image_sha256')!=digest or response.get('ok') is not True:raise RuntimeError('model response invalid')
 field=response['grounding']['field_point'];save_point=response['grounding']['submit_point']
 if not (50<=field[0]<=115 and 145<=field[1]<=157 and 73<=save_point[0]<=94 and 42<=save_point[1]<=62):raise RuntimeError('model points outside reviewed targets')
 original=rgb;old_binding=obs['pointer_binding'];x0,y0=field
 # Inject a visible 8x8 foreign overlay after the model saw the original image.
 overlay=d.screen().root.create_window(x0-4,y0-4,8,8,0,d.screen().root_depth,X.InputOutput,X.CopyFromParent,override_redirect=1,background_pixel=0)
 overlay.map();overlay.configure(stack_mode=X.Above);d.sync();time.sleep(.1)
 obs=b.observe();rgb=b.history[obs['sequence']][1]
 before=original.crop((x0-4,y0-4,x0+4,y0+4)).tobytes();after=rgb.crop((x0-4,y0-4,x0+4,y0+4)).tobytes()
 gate={'field':field,'binding_unchanged':obs['pointer_binding']==old_binding,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest(),'changed':before!=after,'observation_sequence':obs['sequence'],'injection':'8x8 black overlay after model response'}
 (out/'stale-gate.json').write_text(json.dumps(gate,indent=2)+'\n')
 if obs['pointer_binding']!=old_binding or before!=after:raise RuntimeError('target changed after model call')
 raise RuntimeError('injected overlay was not detected; no dispatch permitted')
 click_ref=b.mint_reference('click_cell',obs['sequence'],field,region_size=(30,20))
 click=b.click('click_cell',click_ref['offset'],tail=[],expires_at_ns=time.monotonic_ns()+2_000_000_000)
 (out/'click-result.json').write_text(json.dumps(click,indent=2)+'\n')
 releases=click.get('execution',{}).get('releases',[])
 if click.get('status')!='completed' or not releases or not all(r.get('verified') is True and r.get('keys_down')==[] and r.get('buttons_down')==[] for r in releases):raise RuntimeError('click failed or release unverified')
 obs=b.observe();rgb=b.history[obs['sequence']][1]
 if hashlib.sha256(rgb.crop((0,97,42,119)).tobytes()).hexdigest()!='2e86f3a0f6d87ee4fb4e5ffeb7cfd159d715cb5f6f8177b0ede83784d49088cf':raise RuntimeError('A1 selection not verified after click')
 entry=b.mint_reference('entry',obs['sequence'],[440,28],region_size=(30,14));save=b.mint_reference('sheet',obs['sequence'],[440,28],region_size=(30,14))
 binding=obs['pointer_binding'];approved={'geometry_reviewed':True,'image_size':[1280,800],'scope':b.scope,'revision':b.binding_revision,'binding':binding,'titles':[found[0][1]],'pixel_reference_reviewed':True}
 refs={'entry_alias':'entry','entry_offset':entry['offset'],'save_alias':'sheet','save_offset':save['offset'],'cell_regions':[[37,143,126,159],[37,159,126,176]],'context_region':[350,20,370,35]}
 reference=create_reference(Image.open('/in/reference.png').convert('RGB'))
 comp=CalcComposition(owner,out/'method',refs=refs,approved=approved,reviewed_native=obs,reviewed_rgb=rgb,pixel_reference=reference)
 result={'window':found[0],'initial_observation':obs,'model_response':response,'method':comp.run('compiled')}
 close=owner.close();owner=None;b=None;result['close']=close
 keys=d.query_keymap();result['keys_down']=[i for i in range(256) if keys[i//8]&(1<<(i%8))];result['buttons']=int(d.screen().root.query_pointer().mask)&(X.Button1Mask|X.Button2Mask|X.Button3Mask)
 doc=Path('/tmp/blank.fods');blob=doc.read_bytes();(out/'saved.fods').write_bytes(blob);result['saved_score']=score_saved(blob)
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
finally:
 if owner is not None:
  close_record=owner.close()
  keys=d.query_keymap() if d is not None else []
  (out/'final-neutral.json').write_text(json.dumps({'close':close_record,'keys_down':[i for i in range(256) if keys[i//8]&(1<<(i%8))] if keys else None,'buttons':int(d.screen().root.query_pointer().mask)&(X.Button1Mask|X.Button2Mask|X.Button3Mask) if d is not None else None},indent=2)+'\n')
 elif b is not None:b.close()
 if d is not None:d.close()
 for p in reversed(actors):
  if p.poll() is None:
   try:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=3)
   except ProcessLookupError:pass
 for f in handles:f.close()

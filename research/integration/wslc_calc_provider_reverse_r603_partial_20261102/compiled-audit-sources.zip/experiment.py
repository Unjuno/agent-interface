import hashlib,importlib.util,json,os,sys,time,uuid
from pathlib import Path
root=Path(sys.argv[1]);codex=Path(sys.argv[2]).resolve();sys.path[:0]=[str(root/'driver'),str(root/'job-source')]
from wslc_driver import ContainerDriver
from job_host import JobHost
run=uuid.uuid4().hex;result={'status':'UNKNOWN','run_id':run,'grounding':'actual_provider','started_ns':time.monotonic_ns(),
 'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'codex_sha256':hashlib.sha256(codex.read_bytes()).hexdigest()};host=None;driver=None
try:
 if any(any((root/name).iterdir()) for name in ('output','exchange','host-allocation','container-allocation')):raise RuntimeError('attempt directories not empty')
 manifest=json.loads((root/'source-manifest.json').read_text(encoding='utf-8'))
 if not all(hashlib.sha256((root/name).read_bytes()).hexdigest()==expected for name,expected in manifest['files'].items()):raise RuntimeError('source hash mismatch')
 if result['codex_sha256']!='3097c909fb6d5cd63510d44aceb1d42df9f6e85722a3e447e477def1ecf60e16':raise RuntimeError('codex executable differs from direct cell')
 env=dict(os.environ);env['PYTHONPATH']=str(root/'runtime-source/research/live_control');env['PYTHONDONTWRITEBYTECODE']='1'
 host=JobHost([sys.executable,str(root/'inputs/host.py'),str(codex),str(root),'2'],root/'host-allocation',cwd=str(root),environment=env)
 host.start();result['host_started']=True
 mounts={'/src':(root/'runtime-source',True),'/in':(root/'inputs',True),'/out':(root/'output',False),'/exchange':(root/'exchange',False)}
 container_env={'PYTHONPATH':'/in/study:/src','PYTHONDONTWRITEBYTECODE':'1','ROUTE':'compiled','RECOVERY_CASE':'clear'}
 driver=ContainerDriver(root/'container-allocation',run,'sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25',['python3','-B','/in/runner.py'],mounts=mounts,environment=container_env)
 result['container_start']=driver.start(timeout_s=25)
 if result['container_start'].get('status') in ('running','exited'):result['container_wait']=driver.wait(timeout_s=150)
 if result.get('container_wait',{}).get('status')!='exited' or result.get('container_wait',{}).get('exit_code')!=0:
  (root/'exchange/stop.json').write_text('{}',encoding='utf-8')
 result['host_wait']=host.wait(timeout_s=25)
 if result.get('container_wait',{}).get('status')=='exited':
  logs=driver._call(['wslc','container','logs',driver.cid],time.monotonic()+8,allow_stderr=True)
  if logs is not None:(root/'container.stdout').write_bytes(logs)
  result['logs_observed']=logs is not None
  out=root/'output';result['producer_result_exists']=(out/'result.json').exists()
  if (out/'saved.fods').exists():
   spec=importlib.util.spec_from_file_location('archived_oracle',root/'inputs/study/pair_saved_oracle.py');scorer=importlib.util.module_from_spec(spec);spec.loader.exec_module(scorer)
   data=(out/'saved.fods').read_bytes();result['host_rescore']=scorer.score_saved(data);result['saved_sha256']=hashlib.sha256(data).hexdigest()
  result['source_hashes_unchanged']=all(hashlib.sha256((root/name).read_bytes()).hexdigest()==expected for name,expected in manifest['files'].items())
  if result['producer_result_exists']:
   producer=json.loads((out/'result.json').read_text(encoding='utf-8'))
   def neutral(receipt):return isinstance(receipt,dict) and receipt.get('verified') is True and receipt.get('keys_down')==[] and receipt.get('buttons_down')==[]
   checks={}
   for name in ('click-result.json','recovery-save.json'):
    try:
     action=json.loads((out/name).read_text(encoding='utf-8'));releases=action.get('execution',{}).get('releases')
     checks[name]=action.get('status')=='completed' and isinstance(releases,list) and bool(releases) and all(neutral(x) for x in releases)
    except (OSError,ValueError,AttributeError):checks[name]=False
   method=producer.get('method',{});receipt=method.get('method_receipt',{});transitions=receipt.get('transitions',[])
   try:
    if len(transitions)!=1 or transitions[0].get('action')!='enter':raise ValueError('unexpected transition')
    ref=transitions[0]['effect_ref'];matches=list((out/'owner').rglob(ref+'.json'))
    if len(matches)!=1:raise ValueError('execution evidence not unique')
    execution=json.loads(matches[0].read_text(encoding='utf-8'));entry=execution['result'];releases=entry.get('execution',{}).get('releases')
    checks['compiled-enter']=execution.get('action_id')==transitions[0].get('action_id') and entry.get('status')=='completed' and isinstance(releases,list) and bool(releases) and all(neutral(x) for x in releases)
   except (KeyError,TypeError,OSError,ValueError,AttributeError):checks['compiled-enter']=False
   try:
    recovery=json.loads((out/'recovery.json').read_text(encoding='utf-8'))
    result['compiled_recovery_verified']=(receipt.get('outcome')=='SAFE_YIELD' and receipt.get('reason')=='effect_unavailable' and method.get('replay_allowed') is False and receipt.get('completed_transitions')==1 and (receipt.get('pending_effect') or {}).get('action')=='enter' and len(transitions)==1 and transitions[0].get('release_verified') is True and recovery.get('max_attempts')==1 and recovery.get('cue')=='filled' and recovery.get('save_attempted') is True and recovery.get('save_completed') is True and recovery.get('entry_replayed') is False and recovery.get('recovery_ended_ns',0)<recovery.get('recovery_deadline_ns',0))
   except (OSError,ValueError,TypeError,AttributeError):result['compiled_recovery_verified']=False
   close=producer.get('close',{});result['action_release_checks']=checks;result['owner_close_verified']=close.get('status')=='closed' and neutral(close.get('release'))
   result['final_neutral_readback']=producer.get('keys_down')==[] and type(producer.get('buttons')) is int and producer['buttons']==0
   try:
    gate=json.loads((out/'stale-gate.json').read_text(encoding='utf-8'));result['stale_gate_verified']=gate.get('binding_unchanged') is True and gate.get('prior_programs_or_mints')==[] and bool(gate.get('before_sha256')) and bool(gate.get('after_sha256')) and gate['before_sha256']!=gate['after_sha256']
   except (OSError,ValueError,AttributeError):result['stale_gate_verified']=False
 result['turns']=[]
 for i in (1,2):
  request=root/'exchange'/f'request-{i}.json';response=root/'exchange'/f'response-{i}.json';image=root/'exchange'/f'image-{i}.png'
  if not (request.exists() and response.exists() and image.exists()):continue
  q=json.loads(request.read_text());r=json.loads(response.read_text());digest=hashlib.sha256(image.read_bytes()).hexdigest()
  result['turns'].append({'id':r.get('id'),'ok':r.get('ok'),'attempted':r.get('attempted'),'image_binding_ok':q.get('id')==r.get('id')==f'pilot-{i}' and q.get('image_sha256')==r.get('image_sha256')==digest,'sequence':q.get('source_sequence'),'usage':r.get('usage'),'call_id':r.get('call_id'),'close_returned':r.get('close_returned')})
except BaseException as e:result['error_type']=type(e).__name__
finally:
 if host is not None:
  try:result['host_cleanup']=host.close(timeout_s=10)
  except BaseException as e:result['host_cleanup_error_type']=type(e).__name__
 if driver is not None:
  try:result['container_cleanup']=driver.reconcile(timeout_s=20)
  except BaseException as e:result['container_cleanup_error_type']=type(e).__name__
 result['ended_ns']=time.monotonic_ns()
 turns=result.get('turns',[])
 usage_fields=('input_tokens','cached_input_tokens','cache_write_input_tokens','output_tokens','reasoning_output_tokens')
 usage_ok=len(turns)==2 and all(isinstance(x.get('usage'),dict) and all(type(x['usage'].get(k)) is int and x['usage'][k]>=0 for k in usage_fields) for x in turns)
 if (result.get('host_wait',{}).get('exit_code')==0 and result.get('container_wait',{}).get('exit_code')==0
     and result.get('host_cleanup',{}).get('status')=='closed_scoped' and result.get('container_cleanup',{}).get('remove',{}).get('status')=='observed_absent'
     and result.get('source_hashes_unchanged') is True and result.get('host_rescore',{}).get('pass_effect') is True
     and all(result.get('action_release_checks',{}).get(n) is True for n in ('click-result.json','compiled-enter','recovery-save.json'))
     and result.get('compiled_recovery_verified') is True and result.get('owner_close_verified') is True and result.get('final_neutral_readback') is True and result.get('stale_gate_verified') is True
     and usage_ok and all(x.get('ok') is True and x.get('attempted') is True and x.get('image_binding_ok') is True and x.get('call_id') for x in turns)
     and turns[-1].get('close_returned') is True and type(turns[0].get('sequence')) is int and type(turns[1].get('sequence')) is int and turns[1]['sequence']>turns[0]['sequence']):result['status']='scoped_provider_compiled_pass'
 (root/'integration-result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'status':result['status'],'container_exit':result.get('container_wait',{}).get('exit_code'),'host_exit':result.get('host_wait',{}).get('exit_code'),'turn_count':len(turns),'score':result.get('host_rescore',{}).get('pass_effect'),'host_cleanup':result.get('host_cleanup',{}).get('status'),'container_cleanup':result.get('container_cleanup',{}).get('remove',{}).get('status'),'error_type':result.get('error_type')}))

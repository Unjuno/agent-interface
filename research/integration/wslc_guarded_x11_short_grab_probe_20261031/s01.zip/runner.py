import hashlib,json,os,signal,subprocess,time,traceback
from pathlib import Path
from Xlib import X,display,error,XK
from Xlib.ext import damage
from PIL import Image
from runtime.cli_v1.mcp_guarded import GuardedSessionOwner
out=Path('/out');mode=os.environ['MODE'];md=None;record={'mode':mode,'status':'running','checks':[],'model_calls':0};x=None;d=None;owner=None;overlay=None
try:
 os.environ['DISPLAY']=':154';os.environ['HOME']='/tmp';os.environ['XDG_CACHE_HOME']='/tmp/cache'
 log=(out/'xvfb.log').open('wb');x=subprocess.Popen(['Xvfb',':154','-screen','0','800x600x24','-nolisten','tcp'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 for _ in range(100):
  try:d=display.Display(':154');break
  except Exception:time.sleep(.05)
 if d is None:raise RuntimeError('Xvfb unavailable')
 root=d.screen().root;w=root.create_window(100,80,500,400,0,d.screen().root_depth,X.InputOutput,X.CopyFromParent,background_pixel=0x202020,event_mask=X.KeyPressMask|X.KeyReleaseMask|X.ExposureMask)
 w.set_wm_name('stable guard fixture');w.map();d.sync()
 gc=w.create_gc(foreground=0xe0e0e0)
 def paint():
  w.fill_rectangle(gc,242,192,8,16);d.sync()
 paint();d.set_input_focus(w.id,X.RevertToParent,X.CurrentTime);d.sync();time.sleep(.1)
 while d.pending_events():d.next_event()
 owner=GuardedSessionOwner({'app':w.id},out/'owner',':154');owner.get();bridge=owner.bridge;source=bridge.observe();geometry=source['pointer_binding']['geometry'];point=[geometry[0]+geometry[2]//2,geometry[1]+geometry[3]//2];box=(point[0]-4,point[1]-4,point[0]+4,point[1]+4);reference=bridge.history[source['sequence']][1].crop(box).tobytes();record['source_sequence']=source['sequence'];record['point']=point;record['latched']=False
 def check(label):
  obs=bridge.observe();patch=bridge.history[obs['sequence']][1].crop(box).tobytes();diff=sum(abs(a-b) for a,b in zip(reference,patch))/len(reference);binding=source['pointer_binding']==obs['pointer_binding'];bad=diff>32 or not binding
  if bad:record['latched']=True
  record['checks'].append({'label':label,'sequence':obs['sequence'],'difference':diff,'binding_equal':binding,'bad':bad,'latched':record['latched'],'observed_ns':time.monotonic_ns()})

 md=bridge.backend.d;assert md.has_extension('DAMAGE');extension=md.query_extension('DAMAGE');record['damage_first_event']=extension.first_event;record['damage_version']=str(md.damage_query_version());mr=md.screen().root;mw=md.create_resource_object('window',w.id);rd=mr.damage_create(damage.DamageReportRawRectangles);wd=mw.damage_create(damage.DamageReportRawRectangles);md.sync();record['damage_ids']={'root':rd,'target':wd};record['damage_events']=[]
 def collect(label):
  md.sync()
  while md.pending_events():
   ev=md.next_event()
   if ev.type==extension.first_event:
    area=ev.area;record['damage_events'].append({'stage':label,'damage':ev.damage,'drawable':getattr(ev.drawable,'id',ev.drawable),'area':[area.x,area.y,area.width,area.height],'observed_ns':time.monotonic_ns()})
 collect('setup');record['damage_events']=[];check('before')
 if mode=='overlay':
  overlay=root.create_window(point[0]-4,point[1]-4,8,8,0,d.screen().root_depth,X.InputOutput,X.CopyFromParent,override_redirect=1,background_pixel=0xff00ff);overlay.map();overlay.configure(stack_mode=X.Above);d.sync()
 elif mode in ('draw','unrelated'):
  pink=w.create_gc(foreground=0xff00ff);w.fill_rectangle(pink,20 if mode=='unrelated' else 246,20 if mode=='unrelated' else 196,8,8);d.sync()
 elif mode not in ('clean','queued','preexisting'):raise ValueError('unknown mode')
 record['change_started_ns']=time.monotonic_ns();raw=root.get_image(geometry[0]+20 if mode=='unrelated' else point[0]-4,geometry[1]+20 if mode=='unrelated' else point[1]-4,8,8,X.ZPixmap,0xffffffff);Image.frombytes('RGB',(8,8),raw.data,'raw','BGRX').save(out/'witness.png');record['witness_ns']=time.monotonic_ns();collect('change')
 if overlay is not None:overlay.destroy();overlay=None;d.sync()
 if mode=='unrelated':w.clear_area(20,20,8,8);d.sync()
 elif mode not in ('clean','queued','preexisting'):w.clear_area(246,196,8,8);d.sync();paint()
 record['change_ended_ns']=time.monotonic_ns();collect('restored');check('middle')
 check('endpoint')
 def relevant(e):
  ex,ey,ew,eh=e['area'];return e['damage']==rd and ex<box[2] and ex+ew>box[0] and ey<box[3] and ey+eh>box[1]
 record['relevant_damage']=[e for e in record['damage_events'] if relevant(e)];record['damage_latched']=bool(record['relevant_damage']);record['eligible']=not record['latched'] and not record['damage_latched'];record['dispatch']='withheld'
 while d.pending_events():d.next_event()
 if record['eligible']:
  ob=bridge.observe();ref=bridge.mint_reference('action',ob['sequence'],point,region_size=(24,24));tail=[{'op':'key_state','key':'f','down':True},{'op':'wait_update','timeout_ms':100},{'op':'key_state','key':'f','down':False}];owner.dispatch_attempted=True
  def verify(stage,native,image):
   global overlay
   patch=image.crop(box).tobytes();diff=sum(abs(a-b) for a,b in zip(reference,patch))/len(reference);collect('callback-'+stage);current=[e for e in record['damage_events'] if relevant(e)];record.setdefault('callback_drains',[]).append({'stage':stage,'relevant_count':len(current),'drained_ns':time.monotonic_ns()});valid=not record['latched'] and not current and diff<=32 and native['pointer_binding']==source['pointer_binding']
   if valid and mode=='queued' and stage.startswith('before_key_press:'):
    overlay=root.create_window(point[0]-4,point[1]-4,8,8,0,d.screen().root_depth,X.InputOutput,X.CopyFromParent,override_redirect=1,background_pixel=0xff00ff);overlay.map();overlay.configure(stack_mode=X.Above);d.flush();record['queued_ns']=time.monotonic_ns();br=bridge.backend.d.screen().root;raw=br.get_image(point[0]-4,point[1]-4,8,8,X.ZPixmap,0xffffffff);Image.frombytes('RGB',(8,8),raw.data,'raw','BGRX').save(out/'inside-grab.png');record['inside_grab_ns']=time.monotonic_ns()
   return valid
  if mode=='preexisting':
   overlay=root.create_window(point[0]-4,point[1]-4,8,8,0,d.screen().root_depth,X.InputOutput,X.CopyFromParent,override_redirect=1,background_pixel=0xff00ff);overlay.map();overlay.configure(stack_mode=X.Above);d.sync();record['preexisting_ns']=time.monotonic_ns()
  original_key_state=bridge.backend.key_state
  def grabbed_key_state(key,down):
   if not down:return original_key_state(key,down)
   bd=bridge.backend.d;bd.grab_server();bd.sync();record['grab_started_ns']=time.monotonic_ns()
   try:
    value=original_key_state(key,down);bd.sync();record['press_synced_ns']=time.monotonic_ns();return value
   finally:
    bd.ungrab_server();bd.sync();record['grab_ended_ns']=time.monotonic_ns()
  bridge.backend.key_state=grabbed_key_state
  with bridge.input_guard('action',ref['offset'],tail=tail,verify=verify,interaction='keyboard'):
   action=bridge.keyboard('action',ref['offset'],tail=tail,expires_at_ns=time.monotonic_ns()+3_000_000_000)
  record['action']=action;record['dispatch']='completed' if action.get('status')=='completed' else 'refused_or_failed'
 d.sync()
 if mode in ('queued','preexisting'):
  raw=root.get_image(point[0]-4,point[1]-4,8,8,X.ZPixmap,0xffffffff);Image.frombytes('RGB',(8,8),raw.data,'raw','BGRX').save(out/'after-grab.png');record['after_grab_witness_ns']=time.monotonic_ns()
 time.sleep(.05);d.sync();events=[];code=d.keysym_to_keycode(XK.string_to_keysym('f'))
 while d.pending_events():
  event=d.next_event()
  if event.type in (X.KeyPress,X.KeyRelease):events.append({'type':'press' if event.type==X.KeyPress else 'release','keycode':event.detail})
 collect('after_action');record['events']=events;record['target_keycode']=code;record['close']=owner.close();owner=None;keys=d.query_keymap();record['f_down_after']=bool(keys[code//8]&(1<<(code%8)));record['status']='completed'
except BaseException as exc:record['status']='error';record['error']=repr(exc);(out/'traceback.txt').write_text(traceback.format_exc())
finally:
 if overlay is not None:
  try:overlay.destroy();d.sync()
  except BaseException as exc:record['overlay_error']=repr(exc)
 if owner is not None:
  try:record['finally_close']=owner.close()
  except BaseException as exc:record['close_error']=repr(exc)
 if d is not None:d.close()
 if x is not None and x.poll() is None:
  try:os.killpg(x.pid,signal.SIGTERM);x.wait(timeout=3)
  except BaseException as exc:record['xvfb_close_error']=repr(exc)
 (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')

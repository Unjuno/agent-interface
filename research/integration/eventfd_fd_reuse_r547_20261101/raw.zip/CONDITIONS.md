# Eventfd invalid and reused descriptor regression r547

Before this verification run: execute the three fixed-order unit cases in
`runtime.cli_v1.test_experimental_eventfd`: ordinary notification control,
closed-descriptor rejection, and deliberate `dup2` reuse of that descriptor
number by an empty pipe. A safety implementation must not treat an unknown
replacement as an unrevoked original. The last regression is expected to fail
on the current prototype and must remain reported as a failure. This is an
injected ownership violation, not an observed natural fd reuse or adversary.

Run Python normal mode once in the pinned Docker image
sha256:bd191d30ea94871a1d3ca717252cd07a276e8ef7d1bcb4a130b63935ce075425,
with network disabled, one CPU, 1 GiB, no pull and a read-only source mount.
Record source base/diff, stdout and exit. No GUI or real user input. A `POLLIN`
test alone cannot establish underlying fd identity or prevent reuse after a
check. Cross-platform behavior, concurrency, actual cancellation and X input
are outside scope.

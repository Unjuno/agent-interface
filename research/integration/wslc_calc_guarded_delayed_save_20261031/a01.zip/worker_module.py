import json,os,time
from pathlib import Path
from Xlib import XK
from runtime.cli_v1.mcp_guarded import GuardedSessionOwner

def guarded_calc_click(request):
 out=Path('/out');owner=GuardedSessionOwner({'app':request['target']},out/'worker-owner',':153');owner.get();bridge=owner.bridge;display=bridge.backend.d;pid=os.getpid();base=display.display.info.resource_id_base;ctrl=display.keysym_to_keycode(XK.string_to_keysym('Control_L'));key=display.keysym_to_keycode(XK.string_to_keysym('s'))
 info={'owner_pid':pid,'resource_base':base,'session_id':request['session_id'],'target':request['target'],'keycodes':{'Control_L':ctrl,'s':key}}
 with (out/'custody.json').open('x') as f:json.dump(info,f);f.flush();os.fsync(f.fileno())
 obs=owner.invoke_guarded('guarded_observe',{},out/'worker-call-observe');(out/'worker-observe.json').write_text(json.dumps(obs,indent=2)+'\n')
 if obs.get('status')!='observed':raise RuntimeError('observe failed')
 minted=owner.invoke_guarded('guarded_mint',{'alias':'save','source_sequence':obs['source']['sequence'],'point':[440,28],'region_size':[30,14]},out/'worker-call-mint');(out/'worker-mint.json').write_text(json.dumps(minted,indent=2)+'\n')
 if minted.get('status')!='minted':raise RuntimeError('mint failed')
 args={'alias':'save','offset':minted['offset'],'interaction':'keyboard','tail':[{'op':'key_chord','keys':['CTRL','s']},{'op':'wait_update','timeout_ms':100}],'observe_after':False,'feedback':None}
 result=owner.invoke_guarded('guarded_input',args,out/'worker-call-input');(out/'worker-input.json').write_text(json.dumps(result,indent=2)+'\n');releases=result.get('result',{}).get('execution',{}).get('releases',[])
 if result.get('status')!='completed' or not releases or not all(r.get('verified') is True and not r.get('keys_down') and not r.get('buttons_down') for r in releases):raise RuntimeError('guarded save or release unverified')
 focus=display.get_input_focus().focus;chain=[]
 for _ in range(64):
  ident=getattr(focus,'id',focus)
  if not isinstance(ident,int) or ident in (0,1) or ident in chain:break
  chain.append(ident)
  if ident==request['target']:break
  focus=display.create_resource_object('window',ident).query_tree().parent
 sent=time.monotonic_ns();(out/'save-synced.json').write_text(json.dumps({'sent_ns':sent,'scheduled_late_ns':sent+2_000_000_000,'focus_chain':chain,'keycodes':{'Control_L':ctrl,'s':key}}));time.sleep(2);(out/'late.json').write_text('worker continued after delay');return {'status':'completed','operation_id':request['operation_id'],'session_id':request['session_id']}

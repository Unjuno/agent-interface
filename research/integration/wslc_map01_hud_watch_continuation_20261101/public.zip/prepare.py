import hashlib,json,pathlib,zipfile
root=pathlib.Path(__file__).resolve().parent
old=root.parent/'map01-hud-toggle-20261101'
source=json.loads((old/'frozen-manifest.json').read_text())
for name,digest in source.items():
    data=(old/name).read_bytes();assert hashlib.sha256(data).hexdigest()==digest
    dest=root/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
archive=root.parent/'hud-transfer-replay-20261101'/'v03.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='ab3cb73e220d5f4733d3f4bf85c9524edd8f7553bea6c86ef8246d2014b7b5b5'
with zipfile.ZipFile(archive) as z:(root/'49.png').write_bytes(z.read('49.png'))
source['49.png']=hashlib.sha256((root/'49.png').read_bytes()).hexdigest()
runner=root/'runner.py'; text=runner.read_text(encoding='utf8')
old_text=" sample('second-model-done')\n for _ in range(8):"
new_text=""" sample('second-model-done')
 # A new preplanned continuation, never a replay of the interrupted action.
 prior=record['actions'][-1] if record.get('actions') else {}
 rel=prior.get('execution',{}).get('releases',[])
 post={'mode':os.environ['POST_MODE'],'status':'not_eligible','original_effect':'unknown','replay':False}
 record['post_watch']=post
 if record.get('monitor',{}).get('status')=='change_detected' and prior.get('status')=='execution_failed' and rel and all(x.get('verified') and not x.get('keys_down') and not x.get('buttons_down') for x in rel):
  review=bridge.review_window(w.id);post['review']=review
  if review.get('status')!='reviewed':raise RuntimeError('fresh review failed')
  stale=bridge.keyboard('game',mint['offset'],tail=[{'op':'key_chord','keys':['f']}],expires_at_ns=time.monotonic_ns()+2_000_000_000)
  post['old_alias']=stale
  if stale.get('status')!='refused' or stale.get('input_dispatched') is not False:raise RuntimeError('old alias admitted')
  source=bridge.observe();rgb=bridge.history[source['sequence']][1]
  box=(geom[0]+32,geom[1]+408,geom[0]+90,geom[1]+450)
  from PIL import Image
  expected=hashlib.sha256(Image.open('/candidate/49.png').convert('RGB').tobytes()).hexdigest()
  actual=hashlib.sha256(rgb.crop(box).tobytes()).hexdigest()
  post['source']={'sequence':source['sequence'],'crop_sha256':actual,'expected_sha256':expected,'binding':source['pointer_binding']}
  if actual!=expected:post['status']='unrecognized_withheld'
  elif post['mode']=='withhold':post['status']='control_withheld'
  elif post['mode']=='fire':
   anchor=[geom[0]+44,geom[1]+geom[3]-54];ref=bridge.mint_reference('post_watch',source['sequence'],anchor,region_size=(24,38));checks=[]
   tail2=[{'op':'key_state','key':'f','down':True},{'op':'wait_update','timeout_ms':85},{'op':'key_state','key':'f','down':False}]
   def check_post(stage,native,image):
    digest=hashlib.sha256(image.crop(box).tobytes()).hexdigest();same=native['pointer_binding']==source['pointer_binding'];valid=digest==expected and same
    checks.append({'stage':stage,'sequence':native['sequence'],'crop_sha256':digest,'binding_equal':same,'eligible':valid,'observed_ns':time.monotonic_ns()});return valid
   with bridge.cancellation_scope('post-watch-token'):
    with bridge.input_guard('post_watch',ref['offset'],tail=tail2,verify=check_post,interaction='keyboard'):
     resumed=bridge.keyboard('post_watch',ref['offset'],tail=tail2,expires_at_ns=time.monotonic_ns()+2_000_000_000)
   post['status']=resumed.get('status');post['action']=resumed;post['checks']=checks
  else:raise RuntimeError('invalid post mode')
 (out/'post-watch.json').write_text(json.dumps(post,indent=2)+'\\n')
 sample('after-post-watch')
 for _ in range(8):"""
assert old_text in text
runner.write_text(text.replace(old_text,new_text),encoding='utf8',newline='\n')
source['runner.py']=hashlib.sha256(runner.read_bytes()).hexdigest()
(root/'frozen-manifest.json').write_text(json.dumps(source,indent=2,sort_keys=True)+'\n',encoding='utf8')
launch=(old/'launch.py').read_text(encoding='utf8')
launch=launch.replace("'--env','HUD_MODE='+c['hud'],","'--env','HUD_MODE='+c['hud'],'--env','POST_MODE='+c['post_mode'],")
assert "'POST_MODE='+c['post_mode']" in launch
launch=launch.replace("'map01-hudtoggle-'", "'map01-postwatch-'")
(root/'launch.py').write_text(launch,encoding='utf8',newline='\n')
for ident,mode in [('eu01','withhold'),('eu02','fire')]:
    p=root/ident;p.mkdir();(p/'output').mkdir();(p/'exchange').mkdir()
    c={'allocation':ident,'route':'watch','seed':991039,'hud':'on','post_mode':mode,
       'order':['eu01:withhold','eu02:fire'],'freeze_main':'83dae082a934b979114d3af2a7027e87caedeb9e',
       'image':'sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25',
       'manifest_sha256':hashlib.sha256((root/'frozen-manifest.json').read_bytes()).hexdigest(),
       'launcher_sha256':hashlib.sha256((root/'launch.py').read_bytes()).hexdigest(),
       'scenario':'after navigation and natural watch cancellation, verify release, review new binding, refuse old alias, inspect exact prior 49 HUD template; then withhold or one separately preplanned guarded 85ms fire',
       'criterion':'only proceed on verified original release, successful review, old alias refused, fresh exact 49 and binding; no original action replay; verify followup release and final input state; independent simulator samples are scoring only',
       'stop':'one attempt per arm, no success retry; hold on unrecognized cue or any gate failure; stop block on unresolved ownership',
       'limits':'two separate fixed-order games, fixed exact template, scripted actions and fixture pending window; not model-directed or MAP01 completion'}
    (p/'conditions.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf8')
print('post-watch continuation pair frozen')

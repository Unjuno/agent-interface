"""Private X fixture preflight: textured target and independently recorded input."""
import json,pathlib,subprocess,sys,time,traceback
from Xlib import X,display
from runtime.guarded_x11_v1.bridge import NativeHandleBridge
out=pathlib.Path('/out');result={'status':'started'};server=target=connection=bridge=None
try:
 server=subprocess.Popen(['Xvfb',':195','-screen','0','640x480x24','-nolisten','tcp'],stdout=(out/'xvfb.log').open('wb'),stderr=subprocess.STDOUT)
 for _ in range(100):
  if server.poll() is not None:raise RuntimeError('Xvfb exited')
  try:connection=display.Display(':195');break
  except Exception:time.sleep(.05)
 if connection is None:raise RuntimeError('Xvfb unavailable')
 target=subprocess.Popen(['python3','-B','/target.py'],stdout=(out/'target.stdout').open('wb'),stderr=(out/'target.stderr').open('wb'))
 until=time.monotonic()+4
 while not (out/'target-ready.json').exists():
  if target.poll() is not None or time.monotonic()>=until:raise RuntimeError('target unavailable')
  time.sleep(.01)
 ready=json.loads((out/'target-ready.json').read_text());window=connection.create_resource_object('window',ready['xid'])
 connection.set_input_focus(window,X.RevertToParent,X.CurrentTime);connection.sync()
 before=bytes(connection.query_keymap());pointer_before=connection.screen().root.query_pointer().mask
 bridge=NativeHandleBridge(':195',{'app':window.id},'app','/out/bridge',process_identity=True,query_worker=True,observation_worker=True)
 with bridge.cancellation_scope('preflight-capture',cancel_when_idle=True,single_idle_observation=True):
  obs=bridge.observe_idle_until(time.monotonic_ns()+2_000_000_000)
 g=obs['pointer_binding']['geometry']; point=[g[0]+20,g[1]+20]
 image=bridge.history[obs['sequence']][1]; crop=image.crop((point[0]-6,point[1]-6,point[0]+6,point[1]+6))
 result['crop_colors']=len(set(crop.getdata()));crop.save(out/'target-crop.png')
 offset=bridge.mint('fresh_field',obs['sequence'],point,region_size=[12,12])
 with bridge.cancellation_scope('preflight-keyboard'):
  action=bridge.keyboard('fresh_field',offset,tail=[{'op':'key_chord','keys':['a']}])
 result['action']=action
 until=time.monotonic()+2
 while time.monotonic()<until:
  if (out/'target-events.json').exists():
   target_result=json.loads((out/'target-events.json').read_text())
   if target_result['value']=='a' and any(e['type']=='release' and e['key']=='a' for e in target_result['events']):break
  time.sleep(.01)
 else:raise RuntimeError('target did not record expected press and release')
 result['target_result']=target_result
 bridge.close();bridge=None
 connection.sync();after=bytes(connection.query_keymap());pointer_after=connection.screen().root.query_pointer().mask
 result['input_neutral_before_after']=not any(before) and not any(after) and (pointer_before&0x1f00)==0 and (pointer_after&0x1f00)==0
 assert result['crop_colors']>1 and action['status']=='completed' and action['execution']['releases'][-1]['verified']
 assert result['input_neutral_before_after'] and target_result['value']=='a'
 result['status']='passed'
except BaseException as e:result.update(status='failed',error=repr(e),traceback=traceback.format_exc())
finally:
 if bridge is not None:
  try:bridge.close()
  except Exception as e:result['bridge_close_error']=repr(e);result['status']='failed'
 if target is not None:
  (out/'target-stop').write_text('stop')
  try:target.wait(timeout=3)
  except subprocess.TimeoutExpired:target.terminate();target.wait();result['status']='failed'
  result['target_exit']=target.returncode
 if connection is not None:connection.close()
 if server is not None and server.poll() is None:
  server.terminate()
  try:server.wait(timeout=5)
  except subprocess.TimeoutExpired:server.kill();server.wait();result['status']='failed'
 result['server_exit']=None if server is None else server.poll()
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
sys.exit(0 if result['status']=='passed' else 1)

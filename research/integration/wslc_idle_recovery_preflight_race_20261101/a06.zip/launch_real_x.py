import hashlib,json,os,pathlib,subprocess,sys,time
root=pathlib.Path(__file__).resolve().parent
out=root/'real-x-a06'
out.mkdir(exist_ok=False)
(out/'output').mkdir()
files=[p for p in (root/'src').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']+[root/'real_x_trial.py',root/'target.py',root/'launch_real_x.py']
manifest={str(p.relative_to(root)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
preflight=root.parent/'bounded-idle-observation-preflight-r01'/'real-x-preflight01'
prior=json.loads((preflight/'manifest.json').read_text())
assert json.loads((preflight/'output/result.json').read_text())['status']=='passed'
assert all(manifest[n]==prior[n] for n in manifest if n.startswith('src/') or n=='target.py')
conditions={'allocation':'idle-real-x-a06-20261101','base_main':'1c5ee7881675a51ea4237895ff53e53514eacf62',
 'image':'sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25',
 'limits':'one CPU, 1 GiB, network none, pull never, private Xvfb; WSLc memory limit excludes swap',
 'order':'separate preflight passed with byte-identical target and runtime; healthy capture, server stopped and observed, 500ms idle capture and observed pending, resume, retire old session, create fresh session and enter a into target',
 'criteria':'stopped and pending observed; timeout with no late old source; fresh guarded keyboard succeeds and releases, target records press, release and value a, neutral input before/after',
 'stop':'single attempt; preserve failure; no retry for success',
 'scope':'successor to a03-a05 fixture failures; identical preflighted target and runtime; unmerged prototype and synthetic target only; no model, held-input recovery or MAP01 claim',
 'preflight_manifest_sha256':hashlib.sha256((preflight/'manifest.json').read_bytes()).hexdigest(),
 'preflight_result_sha256':hashlib.sha256((preflight/'output/result.json').read_bytes()).hexdigest(),
 'manifest_sha256':hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest()}
(out/'conditions.json').write_text(json.dumps(conditions,indent=2)+'\n')
for name,digest in manifest.items():
 if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('frozen source changed: '+name)
cmd=['wslc','run','--rm','--name',conditions['allocation'],'--network','none','--cpus','1','--memory','1g','--pull','never',
 '--mount',f'type=bind,source={root / "src"},target=/src,readonly',
 '--mount',f'type=bind,source={root / "real_x_trial.py"},target=/trial.py,readonly',
 '--mount',f'type=bind,source={root / "target.py"},target=/target.py,readonly',
 '--mount',f'type=bind,source={out / "output"},target=/out',
 '--env','PYTHONPATH=/src','--env','PYTHONDONTWRITEBYTECODE=1','--entrypoint','timeout',conditions['image'],
 '--signal=TERM','--kill-after=3s','30s','python3','-B','/trial.py']
(out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
started=time.monotonic()
with (out/'stdout').open('wb') as stdout,(out/'stderr').open('wb') as stderr:
 proc=subprocess.run(cmd,stdout=stdout,stderr=stderr,timeout=50,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
result={'returncode':proc.returncode,'elapsed_seconds':time.monotonic()-started}
(out/'launcher-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
sys.exit(proc.returncode)

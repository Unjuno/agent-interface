# Experimental eventfd + owned Fake X caller r543

Before execution: compare four fixed-order tests against the working-tree
prototype based on commit 0abc69460c1 plus the uncommitted diff saved separately:
known control; UNKNOWN before parent check; UNKNOWN while pipe send is gated;
UNKNOWN after child check. Expected observations respectively: effect present,
refusal/no effect, refusal/no effect, and effect present (the last test is
intentionally written to fail for that counterexample). UNKNOWN is injected by
the fixture, not an actual cancellation. The fake target effects are not real
X server, physical input, or task completion.

One run, Python normal mode, network disabled, 1 CPU, 1 GiB, no pull, pinned image
sha256:bd191d30ea94871a1d3ca717252cd07a276e8ef7d1bcb4a130b63935ce075425.
Mount checkout read-only and unique evidence directory read-write; bytecode
writes disabled. `AGENT_INTERFACE_EXPERIMENTAL_EVENTFD=1`. Retain diff, stdout,
case data and exit code. Fixture failures unrelated to expected last effect are
errors, not positive results. No user GUI, network or physical input.

This is explicitly unsafe research code: descriptor lifecycle is not managed,
UNKNOWN notification can fail, repeated writes/draining/close/reuse are not
characterized, and eventfd cannot fence operations already admitted by child or
queued at a display server. The draft remains non-mergeable. Timeouts and process
cleanup are fixture bounds, not a hard real-time claim.

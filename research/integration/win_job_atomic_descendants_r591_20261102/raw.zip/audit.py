import hashlib,json,subprocess,sys,time,uuid
from pathlib import Path
from identity import k,creation
root=Path(sys.argv[1]);nonce=uuid.uuid4().hex;owner=None;handles={};verified={}
files=('audit.py','identity.py','owner.py','worker.py','grandchild.py','win_job_spawn.py')
result={'status':'UNKNOWN','nonce':nonce,'started_ns':time.monotonic_ns(),'source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}}
try:
 for name in ('owner.ready','owner.tmp','worker.ready','worker.tmp','grandchild.ready','grandchild.tmp','result.json','owner.stdout','owner.stderr'):
  if (root/name).exists():raise FileExistsError('existing attempt file')
 with (root/'owner.stdout').open('xb') as stdout,(root/'owner.stderr').open('xb') as stderr:
  owner=subprocess.Popen([sys.executable,str(root/'owner.py'),str(root),nonce],stdout=stdout,stderr=stderr,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));result['owner_pid']=owner.pid
  until=time.monotonic()+15
  while not (root/'owner.ready').exists():
   if owner.poll() is not None:raise RuntimeError('owner exited before ready')
   if time.monotonic()>=until:raise TimeoutError('owner ready')
   time.sleep(.05)
  ready=json.loads((root/'owner.ready').read_text());result['ready']=ready
  if ready.get('nonce')!=nonce or ready.get('owner_pid')!=owner.pid or ready.get('worker_member') is not True or ready.get('grandchild_member') is not True:raise RuntimeError('owner marker mismatch')
  for name in ('worker','grandchild'):
   pid=ready[name+'_pid'];handle=k.OpenProcess(0x00101001,False,pid)
   if not handle:raise OSError('OpenProcess '+name)
   handles[name]=handle;observed=creation(handle);result[name+'_observed_creation']=observed
   if observed!=ready[name+'_creation']:raise RuntimeError('creation mismatch '+name)
   verified[name]=True;result[name+'_pre_wait']=k.WaitForSingleObject(handle,0)
   if result[name+'_pre_wait']!=258:raise RuntimeError('process not live '+name)
  result['owner_terminate_ns']=time.monotonic_ns();owner.terminate();result['owner_exit']=owner.wait(timeout=5)
  for name in ('worker','grandchild'):
   result[name+'_post_wait']=k.WaitForSingleObject(handles[name],5000);result[name+'_post_ns']=time.monotonic_ns()
  if all(result.get(name+'_post_wait')==0 for name in ('worker','grandchild')):result['status']='observed_descendants_exited_after_owner_death'
except BaseException as e:result.update(error_type=type(e).__name__,error=str(e))
finally:
 try:
  if owner is not None and owner.poll() is None:
   owner.terminate()
   try:owner.wait(timeout=5)
   except subprocess.TimeoutExpired:result['owner_cleanup']='unconfirmed'
 except BaseException as e:result['owner_cleanup_error']=type(e).__name__
 for name,handle in handles.items():
  try:
   if verified.get(name) and k.WaitForSingleObject(handle,0)!=0:
    result[name+'_fallback_terminate_called']=True;result[name+'_fallback_terminate_ok']=bool(k.TerminateProcess(handle,1));result[name+'_fallback_wait']=k.WaitForSingleObject(handle,5000)
  except BaseException as e:result[name+'_cleanup_error']=type(e).__name__
  try:result[name+'_handle_closed']=bool(k.CloseHandle(handle))
  except BaseException as e:result[name+'_close_error']=type(e).__name__
 result['ended_ns']=time.monotonic_ns()
 try:
  with (root/'result.json').open('x',encoding='utf-8') as output:output.write(json.dumps(result,indent=2)+'\n')
 except BaseException as e:print(json.dumps({'result_write_error':type(e).__name__}),file=sys.stderr)
 print(json.dumps({'status':result['status'],'error':result.get('error_type'),'fallback':any(result.get(n+'_fallback_terminate_called',False) for n in ('worker','grandchild'))}))

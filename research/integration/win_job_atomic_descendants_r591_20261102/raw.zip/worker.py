import json,os,subprocess,sys,time
from pathlib import Path
from identity import k,creation
root=Path(sys.argv[1]);nonce=sys.argv[2];owner_pid=int(sys.argv[3])
child=subprocess.Popen([sys.executable,str(root/'grandchild.py'),str(root),nonce],close_fds=True,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
try:
 deadline=time.monotonic()+10
 while not (root/'grandchild.ready').exists():
  if child.poll() is not None:raise RuntimeError('grandchild exited')
  if time.monotonic()>=deadline:raise TimeoutError('grandchild ready')
  time.sleep(.05)
 q=json.loads((root/'grandchild.ready').read_text())
 if q.get('nonce')!=nonce or q.get('pid')!=child.pid:raise RuntimeError('grandchild marker mismatch')
 record={'nonce':nonce,'owner_pid':owner_pid,'worker_pid':os.getpid(),'worker_creation':creation(k.GetCurrentProcess()),'grandchild_pid':child.pid,'grandchild_creation':creation(int(child._handle)),'time_ns':time.monotonic_ns()}
 with (root/'worker.tmp').open('x',encoding='utf-8') as f:json.dump(record,f)
 os.replace(root/'worker.tmp',root/'worker.ready');time.sleep(30)
finally:
 if child.poll() is None:
  child.terminate()
  try:child.wait(timeout=5)
  except subprocess.TimeoutExpired:pass

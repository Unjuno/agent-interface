import json,os,sys,time
from pathlib import Path
root=Path(sys.argv[1]);nonce=sys.argv[2];tmp=root/'grandchild.tmp'
with tmp.open('x',encoding='utf-8') as f:json.dump({'nonce':nonce,'pid':os.getpid(),'time_ns':time.monotonic_ns()},f)
os.replace(tmp,root/'grandchild.ready');time.sleep(30)

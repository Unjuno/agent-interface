import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parent
files=[p for p in (root/'src').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']+[root/'bench.py',root/'run.py',root/'prepare.py']
manifest={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
arms=[('history-b01','ascending'),('history-b02','descending')]
for ident,order in arms:
 p=root/ident;p.mkdir(exist_ok=False);(p/'output').mkdir()
 c={'allocation':'idle-'+ident+'-20261101','order':order,'block_order':[f'{i}:{o}' for i,o in arms],
    'base_main':'df30c4bddb24e1f46fbfba78c742348d9318b3cc','draft_head':'0675ab810f7ee890d0904b8a402678c81f8dbafb',
    'image':'sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25',
    'manifest_sha256':hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest(),
    'design':'0/1000/10000/100000 retained synthetic records; 41 paired alternating-order trials per size; in-place insertion vs detached fork plus insertion; tracemalloc fork allocation separately',
    'stop':'one attempt per arm, retain failures; no retries for favorable result',
    'limits':'synthetic in-memory microbenchmark on one CPU/1 GiB; no GUI task, input, IPC, models, physical recovery or general speed claim'}
 (p/'conditions.json').write_text(json.dumps(c,indent=2)+'\n')
print('two benchmark arms frozen')

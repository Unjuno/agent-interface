import unittest
from PIL import Image
from modal_identity import BOXES,matches
class ModalIdentityTests(unittest.TestCase):
 def test_exact_and_each_region_difference(self):
  reference=Image.new('RGB',(1280,800),'white');self.assertTrue(matches(reference,reference.copy()))
  for left,top,right,bottom in BOXES:
   changed=reference.copy();changed.putpixel((left,top),(0,0,0));self.assertFalse(matches(reference,changed))
 def test_invalid_size_or_mode_is_rejected(self):
  reference=Image.new('RGB',(1280,800),'white')
  self.assertFalse(matches(reference,Image.new('RGB',(800,600))))
  self.assertFalse(matches(reference,reference.convert('L')))
if __name__=='__main__':unittest.main()

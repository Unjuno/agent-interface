import os,time,json,subprocess,signal,shutil,hashlib
from pathlib import Path
from Xlib import X,display
from runtime.cli_v1.mcp_guarded import GuardedSessionOwner
from pair_saved_oracle import score_saved
from PIL import Image
out=Path('/out');env=dict(os.environ,DISPLAY=':153',HOME='/tmp',SAL_USE_VCLPLUGIN='gen');actors=[];handles=[];b=None;d=None;owner=None;overlay=None
try:
 def spawn(name,args):
  f=(out/(name+'.log')).open('wb');handles.append(f);p=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);actors.append(p);return p
 x=spawn('xvfb',['Xvfb',':153','-screen','0','1280x800x24','-nolisten','tcp','-ac'])
 for _ in range(100):
  try:d=display.Display(':153');break
  except Exception:time.sleep(.05)
 if d is None:raise RuntimeError('Xvfb unavailable')
 if hashlib.sha256(Path('/in/blank.fods').read_bytes()).hexdigest()!='462beebbcb020ccf49af3cc49520f789a816cc3fb97597cefbd6940ffc26aeb1':raise RuntimeError('blank fixture digest mismatch')
 shutil.copyfile('/in/blank.fods','/tmp/blank.fods');spawn('openbox',['openbox','--sm-disable']);lo=spawn('calc',['libreoffice','-env:UserInstallation=file:///tmp/observe-profile','--calc','--nologo','--norestore','--nofirststartwizard','/tmp/blank.fods'])
 def walk(w,depth=0):
  if depth>6:return []
  out=[]
  for child in w.query_tree().children:
   try:
    title=child.get_wm_name();title=title.decode(errors='replace') if isinstance(title,bytes) else str(title or '')
    out.append((child.id,title,child.get_attributes().map_state));out+=walk(child,depth+1)
   except Exception:pass
  return out
 end=time.monotonic()+20;found=[]
 while time.monotonic()<end:
  found=[r for r in walk(d.screen().root) if 'blank.fods' in r[1].lower() and 'calc' in r[1].lower() and r[2]==X.IsViewable]
  if len(found)==1:break
  if len(found)>1:raise RuntimeError('ambiguous target')
  if lo.poll() is not None:raise RuntimeError('calc exited')
  time.sleep(.05)
 if len(found)!=1:
  (out/'window-inventory.json').write_text(json.dumps(walk(d.screen().root),indent=2)+'\n')
  raise RuntimeError('target unavailable')
 time.sleep(1);owner=GuardedSessionOwner({'app':found[0][0]},out/'owner',':153');owner.get();b=owner.bridge;obs=b.observe();rgb=b.history[obs['sequence']][1]
 if hashlib.sha256(rgb.crop((0,97,42,119)).tobytes()).hexdigest()!='2e86f3a0f6d87ee4fb4e5ffeb7cfd159d715cb5f6f8177b0ede83784d49088cf':raise RuntimeError('initial A1 name-box differs from reviewed source')

 spawn('clipboard',['python3','-B','/candidate/clipboard.py'])
 clipboard_deadline=time.monotonic()+5
 while not (out/'clipboard-ready.json').exists():
  if time.monotonic()>=clipboard_deadline:raise RuntimeError('clipboard owner unavailable')
  time.sleep(.02)
 from research.live_control.calc_ocr_graph_perception_v1 import make_ocr_calc_method,make_perception
 from runtime.guarded_x11_v1.compiled import run
 from PIL import ImageOps
 import io
 blank_doc=score_saved(Path('/tmp/blank.fods').read_bytes());assert blank_doc['populated']==[]
 regions=((37,143,126,159),(37,159,126,176));baseline=[rgb.crop(box).tobytes() for box in regions];binding=obs['pointer_binding'];title=b._window_title();trace=[];ocr_rows=[]
 refs={alias:b.mint_reference(alias,obs['sequence'],[440,28],region_size=(30,14)) for alias in ('sheet','save','confirm')}
 graph=make_ocr_calc_method(interface_id='calclive',session_scope=b.scope,surface='x11-window-'+str(found[0][0]),sheet_handle='sheet',save_handle='save',confirm_handle='confirm')
 entry=[{'op':'key_chord','keys':['CTRL','v']},{'op':'wait_update','timeout_ms':500}]
 bindings={'enter':{'interaction':'keyboard','offset':refs['sheet']['offset'],'tail':entry},'save':{'interaction':'keyboard','offset':refs['save']['offset'],'tail':[{'op':'key_chord','keys':['CTRL','s']},{'op':'wait_update','timeout_ms':100}]},'confirm':{'interaction':'keyboard','offset':refs['confirm']['offset'],'tail':[{'op':'key_chord','keys':['Return']}]}}
 def context(native,image):
  valid=(native['sequence']==b.sequence and native['binding_revision']==b.binding_revision and native['pointer_binding']==binding and b._focus_within_target() and not b.review_required and not b.session.recovery_required and b._window_title()==title)
  blank=all(image.crop(box).tobytes()==data for box,data in zip(regions,baseline)) if valid else None
  row={'sequence':native['sequence'],'artifact_sha256':native['native']['artifact']['sha256'],'valid':bool(valid),'blank':blank};trace.append(row)
  return ({'sheet_target_present':bool(valid),'save_target_present':bool(valid),'dialog_present':False,'dialog_absent':bool(valid),'confirm_target_present':False,'saved_indication':'unknown'},blank)
 def read_ocr(native,image):
  if all(image.crop(box).tobytes()==data for box,data in zip(regions,baseline)):
   ocr_rows.append({'sequence':native['sequence'],'skipped':'visually_blank'});return ('','')
  texts=[]
  for name,box in [('A1',(95,144,126,159)),('A2',(95,161,126,176))]:
   crop=image.crop(box);crop.putdata([(255,255,255) if b>r+30 and b>g+20 else (r,g,b) for r,g,b in crop.getdata()]);crop=crop.convert('L').resize(((box[2]-box[0])*4,(box[3]-box[1])*4),Image.Resampling.LANCZOS);crop=ImageOps.expand(crop,border=16,fill=255);buf=io.BytesIO();crop.save(buf,format='PNG');payload=buf.getvalue();cmd=['tesseract','stdin','stdout','--psm','7','-c','tessedit_char_whitelist=0123456789','tsv'];n=len(ocr_rows);start=time.monotonic_ns()
   try:
    result=subprocess.run(cmd,input=payload,capture_output=True,timeout=1.0,check=False);row={'sequence':native['sequence'],'cell':name,'input_sha256':hashlib.sha256(payload).hexdigest(),'start_ns':start,'end_ns':time.monotonic_ns(),'returncode':result.returncode,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest()};(out/f'ocr-{n:03d}.tsv').write_bytes(result.stdout);(out/f'ocr-{n:03d}.stderr').write_bytes(result.stderr);ocr_rows.append(row)
    if result.returncode!=0:raise RuntimeError('OCR failed')
    texts.append(result.stdout.decode('utf-8'))
   except Exception as error:
    ocr_rows.append({'sequence':native['sequence'],'cell':name,'error':type(error).__name__});raise
  return tuple(texts)
 def verify(payload,native,image):
  return {'status':'succeeded' if payload['action']=='enter' else 'unavailable','evidence_ref':payload['observation']['evidence_ref']}
 perceive=make_perception(context,read_ocr,expected=('641','283'));owner.dispatch_attempted=True
 result=run(b,graph,bindings,perceive=perceive,verify_effect=verify);(out/'original-graph.json').write_text(json.dumps(result,indent=2)+'\n')
 if result['outcome']!='SAFE_YIELD' or result['reason']!='effect_unavailable' or result['pending_effect']['action']!='enter':raise RuntimeError('unexpected original graph state')
 original_close=owner.close();owner=None;b=None
 if not original_close['release']['verified']:raise RuntimeError('original input release not verified')
 recovery={'case':os.environ['CASE'],'original_replayed':False,'modal_attempted':False,'save_attempted':False};(out/'recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 dialogs=[x for x in walk(d.screen().root) if x[1].strip()=='Text Import' and x[2]==X.IsViewable]
 if len(dialogs)!=1:raise RuntimeError('unique import dialog unavailable')
 from modal_identity import matches,BOXES
 modal_reference=Image.open('/in/modal-reference.png').convert('RGB')
 if os.environ['CASE']=='blocked':
  modal_reference=modal_reference.copy();x,y=BOXES[1][:2];red,green,blue=modal_reference.getpixel((x,y));modal_reference.putpixel((x,y),(red^255,green,blue))
 modal_id=dialogs[0][0];owner=GuardedSessionOwner({'app':modal_id},out/'modal-owner',':153');owner.get();b=owner.bridge;owner.dispatch_attempted=True;modal_obs=b.observe();modal_rgb=b.history[modal_obs['sequence']][1];modal_binding=modal_obs['pointer_binding']
 modal_ok=(b._window_title().strip()=='Text Import' and b._focus_within_target() and matches(modal_reference,modal_rgb))
 recovery.update(modal_id=modal_id,modal_observation=modal_obs,modal_reference_match=bool(modal_ok),modal_title=b._window_title())
 if modal_ok:
  ref=b.mint_reference('import_ok',modal_obs['sequence'],[832,640],region_size=(70,20));deadline=time.monotonic_ns()+3_000_000_000
  def modal_guard(stage,native,image):
   return native['binding_revision']==b.binding_revision and native['pointer_binding']==modal_binding and b._focus_within_target() and b._window_title().strip()=='Text Import' and matches(modal_reference,image)
  recovery['modal_attempted']=True;(out/'recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
  with b.input_guard('import_ok',ref['offset'],tail=[],verify=modal_guard,interaction='click'):
   clicked=b.click('import_ok',ref['offset'],tail=[],expires_at_ns=deadline)
  (out/'modal-click.json').write_text(json.dumps(clicked,indent=2)+'\n');rel=clicked.get('execution',{}).get('releases',[])
  recovery['modal_completed']=clicked.get('status')=='completed' and bool(rel) and all(x.get('verified') and not x.get('keys_down') and not x.get('buttons_down') for x in rel)
 else:recovery['modal_completed']=False
 modal_close=owner.close();owner=None;b=None;recovery['modal_close']=modal_close
 if not modal_close['release']['verified']:raise RuntimeError('modal release unverified')
 if recovery['modal_completed']:
  deadline=time.monotonic()+3
  while time.monotonic()<deadline:
   if not [x for x in walk(d.screen().root) if x[1].strip()=='Text Import' and x[2]==X.IsViewable]:break
   time.sleep(.05)
  if [x for x in walk(d.screen().root) if x[1].strip()=='Text Import' and x[2]==X.IsViewable]:raise RuntimeError('dialog persisted after confirmation')
  owner=GuardedSessionOwner({'app':found[0][0]},out/'fresh-owner',':153');owner.get();b=owner.bridge;owner.dispatch_attempted=True;fresh=b.observe();fresh_rgb=b.history[fresh['sequence']][1]
  cue=perceive(fresh,fresh_rgb);recovery['fresh_observation']=fresh;recovery['fresh_predicates']=cue
  if cue.get('cells_match') is True:
   from save_guard import SemanticSaveGuard
   ref=b.mint_reference('recovery_save',fresh['sequence'],[440,28],region_size=(30,14));deadline=time.monotonic_ns()+3_000_000_000;guard=SemanticSaveGuard(b,alias='recovery_save',offset=ref['offset'],regions=regions,deadline_ns=deadline)
   cue_record={'cue':'filled','sequence':fresh['sequence'],'artifact_sha256':fresh['native']['artifact']['sha256']};guard.arm(fresh,fresh_rgb,cue_record=cue_record);tail=[{'op':'key_chord','keys':['CTRL','s']},{'op':'wait_update','timeout_ms':200}]
   def save_guard(stage,native,image):return guard.validate_capture(native,image)
   recovery['save_attempted']=True;(out/'recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
   with b.input_guard('recovery_save',ref['offset'],tail=tail,verify=save_guard,interaction='keyboard'):
    save=b.keyboard('recovery_save',ref['offset'],tail=tail,expires_at_ns=deadline)
   (out/'recovery-save.json').write_text(json.dumps(save,indent=2)+'\n');(out/'save-guard.json').write_text(json.dumps({'events':guard.events,'cue':cue_record},indent=2)+'\n');recovery['save_completed']=save.get('status')=='completed'
  else:recovery['save_completed']=False
  fresh_close=owner.close();owner=None;b=None;recovery['fresh_close']=fresh_close
  if not fresh_close['release']['verified']:raise RuntimeError('fresh release unverified')
 else:recovery['save_completed']=False
 (out/'trace.json').write_text(json.dumps(trace,indent=2)+'\n');(out/'ocr.json').write_text(json.dumps(ocr_rows,indent=2)+'\n');(out/'recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 keys=d.query_keymap();held=[i for i in range(256) if keys[i//8]&(1<<(i%8))];buttons=int(d.screen().root.query_pointer().mask)&(X.Button1Mask|X.Button2Mask|X.Button3Mask);blob=Path('/tmp/blank.fods').read_bytes();(out/'saved.fods').write_bytes(blob)
 (out/'result.json').write_text(json.dumps({'method':result,'original_close':original_close,'recovery':recovery,'keys_down':held,'buttons':buttons,'saved_score':score_saved(blob)},indent=2)+'\n')
 assert not held and not buttons

finally:
 if owner is not None:owner.close()
 elif b is not None:b.close()
 if d is not None:d.close()
 for proc in reversed(actors):
  if proc.poll() is None:
   try:os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=3)
 for f in handles:f.close()

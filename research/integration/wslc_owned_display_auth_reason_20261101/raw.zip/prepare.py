import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parent
files=[p for p in (root/'src').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']+[root/'trial.py',root/'target.py',root/'run.py',root/'prepare.py']
manifest={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
arms=[('auth-m01','retire'),('auth-m02','resume')]
for ident,mode in arms:
 p=root/ident;p.mkdir(exist_ok=False);(p/'output').mkdir()
 c={'allocation':'xvfb-auth-reason-'+ident+'-20261101','mode':mode,'order':[f'{i}:{m}' for i,m in arms],
    'base_main':'e5925b6bd99fd4ff3f8e0bda5ed4d7cc02d92c4d','draft_head':'93ef7f4321b94ef83cdbea472cba7e85f51cfb78',
    'image':'sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25',
    'manifest_sha256':hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest(),
    'intervention':'draft PrivateDisplayOwner launches authenticated server; fixture holds a; retire and replace or resume; record actual display numbers; probe old, current and missing authorities and retain redacted stdout/stderr; control fixture releases a; fresh client holds b, old client attempts stale b release, inspect b state, fixture releases if needed; fresh guarded a task',
    'criteria':'old a held; old authority probe nonzero after replacement and zero on resumed server; current succeeds and missing fails in both; retain redacted failure reason and actual display numbers; replaced display neutral versus resumed display retains a; stale release cannot clear fresh b on replaced display but does clear b on shared display; fresh guarded a task effect and release verified',
    'stop':'one try per arm; preserve all failures; stop block on unresolved input or infrastructure failure',
    'limits':'fixed-order pair; synthetic fixture-held old input and stale release; same-number behavior only if observed; no actual guarded old cancellation, hard deadline or MAP01 claim'}
 (p/'conditions.json').write_text(json.dumps(c,indent=2)+'\n')
print('two arms frozen')

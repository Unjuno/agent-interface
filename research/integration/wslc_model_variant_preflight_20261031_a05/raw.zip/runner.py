import hashlib,json,time,traceback,shutil,os
from pathlib import Path
import run_integrated_efficiency_live_v1 as live
out=Path('/out');ex=Path('/exchange');live.OUT=out;counter=0;current_arm=None;results={};independent={};final={'passed':False,'scope':'fixed-order exploratory 3-arm, no schema preflight'}
class RemoteError(RuntimeError):pass
def call(root,prompt,image,contract,workspace):
 global counter
 counter+=1
 if counter>14:raise RuntimeError('model call cap exceeded')
 ident=f'{counter:03d}'; dest=ex/(ident+'.png');shutil.copyfile(image,dest);digest=hashlib.sha256(dest.read_bytes()).hexdigest()
 req={'id':ident,'arm':current_arm,'contract':contract,'image_sha256':digest};tmp=ex/(ident+'.tmp');tmp.write_text(json.dumps(req));os.replace(tmp,ex/(ident+'.request.json'))
 deadline=time.monotonic()+120;response=ex/(ident+'.response.json')
 while not response.exists():
  if time.monotonic()>=deadline:raise TimeoutError('host response not observed for '+ident)
  time.sleep(.05)
 r=json.loads(response.read_text())
 if r.get('id')!=ident or r.get('image_sha256')!=digest:raise RuntimeError('response custody mismatch')
 if not r.get('ok'):
  e=RemoteError(r.get('error','host failure'));e.call_id=r.get('call_id');e.usage=r.get('usage');raise e
 return {'grounding':r['grounding'],'usage':r['usage'],'call_id':r['call_id'],'requested_model':'gpt-6.1-sol','requested_effort':'low','cost':None}
try:
 for arm in ('plain','persistent','ephemeral'):
  current_arm=arm;workspace=out/'workspaces'/arm;workspace.mkdir(parents=True)
  rows,ev=live.run_arm(arm,771903,workspace,model_call=call);results[arm]=rows;independent[arm]=ev
  (out/'partial.json').write_text(json.dumps({'arms':results,'independent':independent,'calls':counter},indent=2)+'\n')
  if len(rows)!=6 or any(row['typed_outcome']!='completed' for row in rows) or ev.get('success') is not True:raise RuntimeError('incomplete arm '+arm)
 final.update(passed=True,arms=results,independent=independent,calls=counter)
except Exception as e:final.update(error=repr(e),traceback=traceback.format_exc(),arms=results,independent=independent,calls=counter)
finally:
 (out/'result.json').write_text(json.dumps(final,indent=2)+'\n');tmp=ex/'done.tmp';tmp.write_text(json.dumps({'calls':counter}));os.replace(tmp,ex/'done.json')
print(json.dumps({'passed':final['passed'],'calls':counter,'error':final.get('error')}));raise SystemExit(0 if final['passed'] else 1)

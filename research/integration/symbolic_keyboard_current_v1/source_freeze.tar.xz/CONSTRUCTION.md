# Excluded construction

- c0 STOP before science: runner opened Python-Xlib observer with inherited `~/.Xauthority`; private Xvfb/app were established but policy/input had not run.
- runner was corrected before freeze to set its own DISPLAY/XAUTHORITY explicitly.
- c1-c3: CURRENT German UNDO exact; CURRENT no-modal CONFIRM refused; SNAPSHOT US->DE layout change refused.
- c4 exposed preformal assumption failure: RAW on US->DE did not produce UNDO.
- c5/c6: RAW unsupported/no-longer-modal Return produced STRAY_RETURN.
- app instrumentation was extended before freeze to distinguish Ctrl+Y REDO from no effect; no scientific gate was consumed.
- c7: RAW US->DE emitted stale keycode and produced REDO.
- c8: CURRENT fresh current-map resolution produced UNDO.
- 8 policy unit tests passed before freeze.

All construction is excluded from the formal denominator.

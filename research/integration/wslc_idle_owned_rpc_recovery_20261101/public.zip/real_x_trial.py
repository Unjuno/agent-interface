"""Spawned owned RPC through Xvfb stop, quarantine and fresh target task."""
import json,os,pathlib,signal,subprocess,sys,threading,time,traceback
from Xlib import X,display
from runtime.cli_v1.owned_guarded_session import OwnedGuardedSessionOwner
OUT=pathlib.Path('/out')
def main():
 result={'status':'started','events':[]};events=result['events']
 def mark(name,**kw):events.append({'name':name,'ns':time.monotonic_ns(),**kw})
 def state(pid):return next(x.split()[1] for x in pathlib.Path(f'/proc/{pid}/status').read_text().splitlines() if x.startswith('State:'))
 server=target=connection=old=fresh=thread=None
 try:
  server=subprocess.Popen(['Xvfb',':195','-screen','0','640x480x24','-nolisten','tcp'],stdout=(OUT/'xvfb.log').open('wb'),stderr=subprocess.STDOUT)
  for _ in range(100):
   if server.poll() is not None:raise RuntimeError('Xvfb exited')
   try:connection=display.Display(':195');break
   except Exception:time.sleep(.05)
  if connection is None:raise RuntimeError('Xvfb unavailable')
  target=subprocess.Popen(['python3','-B','/target.py'],stdout=(OUT/'target.stdout').open('wb'),stderr=(OUT/'target.stderr').open('wb'))
  until=time.monotonic()+4
  while not (OUT/'target-ready.json').exists():
   if target.poll() is not None or time.monotonic()>=until:raise RuntimeError('target unavailable')
   time.sleep(.01)
  ready=json.loads((OUT/'target-ready.json').read_text());window=connection.create_resource_object('window',ready['xid'])
  connection.set_input_focus(window,X.RevertToParent,X.CurrentTime);connection.sync()
  before=bytes(connection.query_keymap());pointer_before=connection.screen().root.query_pointer().mask
  (OUT/'old').mkdir();old=OwnedGuardedSessionOwner({'app':window.id},OUT/'old',':195',process_identity=True,query_worker=True,observation_worker=True)
  old.get();result['old_pid']=old._process.pid
  first=old.observe_idle_until(deadline_ns=time.monotonic_ns()+3_000_000_000,cancel_token='old-healthy')
  result['initial_sequence']=first['source']['sequence']
  os.kill(server.pid,signal.SIGSTOP);mark('stop_sent');until=time.monotonic()+2
  while state(server.pid)!='T':
   if time.monotonic()>=until:raise RuntimeError('server did not stop')
   time.sleep(.002)
  mark('stop_observed',state=state(server.pid));deadline=time.monotonic_ns()+500_000_000;result['deadline_ns']=deadline;capture={}
  def invoke():
   mark('capture_started')
   try:old.observe_idle_until(deadline_ns=deadline,cancel_token='old-stopped');capture['status']='unexpected_source'
   except RuntimeError as e:capture.update(status='unavailable',error=str(e))
   except BaseException as e:capture.update(status='error',error=repr(e))
   finally:mark('capture_returned',**capture)
  thread=threading.Thread(target=invoke);thread.start();pending=False
  while time.monotonic_ns()<deadline and thread.is_alive():
   if old._rpc_lock.locked() and state(server.pid)=='T':mark('rpc_pending_while_stopped');pending=True;break
   time.sleep(.002)
  if not pending:raise RuntimeError('pending RPC while stopped not observed')
  thread.join(3)
  if thread.is_alive():raise RuntimeError('parent call did not return')
  result['capture']=capture;result['state_before_close']=state(server.pid);result['owner_state_after_timeout']=old.state
  result['owner_review_after_timeout']=old.review_required;result['old_close']=old.close();mark('old_close_returned')
  old=None;os.kill(server.pid,signal.SIGCONT);mark('resumed')
  (OUT/'fresh').mkdir();fresh=OwnedGuardedSessionOwner({'app':window.id},OUT/'fresh',':195',process_identity=True,query_worker=True,observation_worker=True)
  fresh.get();result['fresh_pid']=fresh._process.pid
  obs=fresh.observe_idle_until(deadline_ns=time.monotonic_ns()+3_000_000_000,cancel_token='fresh-capture')
  g=obs['source']['pointer_binding']['geometry'];mintdir=OUT/'mint';mintdir.mkdir()
  minted=fresh.invoke_guarded('guarded_mint',{'alias':'fresh_field','source_sequence':obs['source']['sequence'],'point':[g[0]+20,g[1]+20],'region_size':[12,12]},mintdir)
  result['mint']=minted
  actiondir=OUT/'action';actiondir.mkdir()
  action=fresh.invoke_guarded('guarded_input',{'alias':'fresh_field','offset':minted['offset'],'interaction':'keyboard','observe_after':False,'tail':[{'op':'key_chord','keys':['a']}]},actiondir)
  result['action']=action;mark('action_returned')
  until=time.monotonic()+2
  while time.monotonic()<until:
   if (OUT/'target-events.json').exists():
    try:target_result=json.loads((OUT/'target-events.json').read_text())
    except json.JSONDecodeError:time.sleep(.01);continue
    if target_result['value']=='a' and any(e['type']=='release' and e['key']=='a' for e in target_result['events']):break
   time.sleep(.01)
  else:raise RuntimeError('target did not record input and release')
  result['target_result']=target_result;result['fresh_close']=fresh.close();fresh=None;mark('fresh_closed')
  connection.sync();after=bytes(connection.query_keymap());pointer_after=connection.screen().root.query_pointer().mask
  result['input_neutral_before_after']=not any(before) and not any(after) and (pointer_before&0x1f00)==0 and (pointer_after&0x1f00)==0
  assert result['initial_sequence']==1 and capture['status']=='unavailable' and result['state_before_close']=='T'
  assert result['owner_state_after_timeout']=='failed' and result['owner_review_after_timeout']
  assert result['old_close']['owner_process_retired'] and result['old_close']['cleanup_status']=='UNKNOWN' and not result['old_close']['release_attempted']
  assert result['fresh_pid']!=result['old_pid'] and minted['status']=='minted' and action['status']=='completed'
  assert action['result']['execution']['releases'][-1]['verified'] and target_result['value']=='a' and result['input_neutral_before_after']
  result['status']='passed'
 except BaseException as e:result.update(status='failed',error=repr(e),traceback=traceback.format_exc())
 finally:
  if server is not None and server.poll() is None:
   try:os.kill(server.pid,signal.SIGCONT)
   except ProcessLookupError:pass
  if thread is not None and thread.is_alive():thread.join(3)
  for name,owner in [('old',old),('fresh',fresh)]:
   if owner is not None:
    try:result[name+'_cleanup']=owner.close()
    except Exception as e:result[name+'_close_error']=repr(e);result['status']='failed'
  if target is not None:
   (OUT/'target-stop').write_text('stop')
   try:target.wait(timeout=3)
   except subprocess.TimeoutExpired:target.terminate();target.wait();result['status']='failed'
   result['target_exit']=target.returncode
  if connection is not None:connection.close()
  if server is not None and server.poll() is None:
   server.terminate()
   try:server.wait(timeout=5)
   except subprocess.TimeoutExpired:server.kill();server.wait();result['status']='failed'
  result['server_exit']=None if server is None else server.poll()
  (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
 return 0 if result['status']=='passed' else 1
if __name__=='__main__':sys.exit(main())

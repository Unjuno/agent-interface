import json,os,subprocess,sys,time
from pathlib import Path
p=Path(__file__).resolve().parent;c=json.loads((p/'conditions.json').read_text());out=p/'output';source=p.parent/'source'
for n,h in c['input_sha256'].items():
 if __import__('hashlib').sha256((p/n).read_bytes()).hexdigest()!=h:raise RuntimeError('input mismatch '+n)
codex=Path(os.environ['LOCALAPPDATA'])/'OpenAI/Codex/bin/22cfb1d302613eae/codex.exe';py=Path(os.environ['USERPROFILE'])/'.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe';env=os.environ.copy();env['PYTHONPATH']=str(source/'research/live_control');env['PYTHONDONTWRITEBYTECODE']='1';flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
name='calc-varied-'+c['allocation']+'-20261101';cmd=['wslc','run','--rm','--name',name,'--network','none','--cpus','1','--memory','1g','--pull','never','--entrypoint','timeout','--mount',f'type=bind,source={source},target=/src,readonly','--mount',f'type=bind,source={p},target=/in,readonly','--mount',f'type=bind,source={out},target=/out','--mount',f'type=bind,source={p / "exchange"},target=/exchange','-w','/src','--env','PYTHONPATH=/in/study:/src','--env','PYTHONDONTWRITEBYTECODE=1','--env','ROUTE='+c['route'],'--env','RECOVERY_CASE='+c['mode'],'sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25','--signal=TERM','--kill-after=3s','120s','python3','-B','/in/runner.py']
t=time.monotonic();host=None;container=None;result={}
try:
 with (p/'host.stdout').open('wb') as ho,(p/'host.stderr').open('wb') as he,(p/'container.stdout').open('wb') as co,(p/'container.stderr').open('wb') as ce:
  host=subprocess.Popen([str(py),str(p/'host.py'),str(codex),str(p),str(2 if c['route']=='fresh' else 1)],cwd=p,env=env,stdout=ho,stderr=he,creationflags=flags)
  container=subprocess.Popen(cmd,stdout=co,stderr=ce,creationflags=flags);container_exit=container.wait(timeout=140)
  if container_exit!=0:(p/'exchange/stop.json').write_text('{}')
  host_exit=host.wait(timeout=20)
  result={'container_exit':container_exit,'host_exit':host_exit,'elapsed_seconds':round(time.monotonic()-t,3),'timeout':False,'container_name':name}
except BaseException as e:
 if host is not None and host.poll() is None:host.terminate()
 result={'error_type':type(e).__name__,'elapsed_seconds':round(time.monotonic()-t,3),'container_running':container is not None and container.poll() is None,'host_running':host is not None and host.poll() is None,'container_name':name}
finally:
 (p/'launcher-result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result));raise SystemExit(0 if result.get('container_exit')==0 and result.get('host_exit')==0 else 1)

import json,subprocess
from pathlib import Path
from PIL import Image,ImageOps
out=Path('/out');r={}
for name in ('a01','a02'):
 im=Image.open('/in/'+name+'.png').convert('RGB');cropped=im.crop((25,4,118,82));cropped=ImageOps.expand(cropped,border=12,fill='white');path=out/(name+'-crop.png');cropped.save(path)
 result=subprocess.run(['tesseract',str(path),'stdout','--psm','7','-c','tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'],capture_output=True,text=True,timeout=3);r[name]={'text':result.stdout.strip(),'exit':result.returncode,'stderr':result.stderr}
(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')

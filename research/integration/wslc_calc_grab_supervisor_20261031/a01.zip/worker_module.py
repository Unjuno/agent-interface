import json,os,time
from pathlib import Path
from Xlib import X,display
from Xlib.ext import xtest

def guarded_calc_click(request):
 d=display.Display(':153');root=d.screen().root;pid=os.getpid();base=d.display.info.resource_id_base;session=request['session_id'];generation={'session_id':session,'child_pid':pid,'x_resource_base':base,'binding_revision':0};out=Path('/out');prepared={'owner_pid':pid,'resource_base':base,'owner_generation':generation,'buttons':['left'],'keys':{},'target':request['target'],'point':request['point']}
 with (out/'custody.json').open('x') as f:json.dump(prepared,f);f.flush();os.fsync(f.fileno())
 x,y=request['point'];xtest.fake_input(d,X.MotionNotify,x=x,y=y);d.sync();d.grab_server();d.sync();start=time.monotonic_ns();window=root;chain=[root.id]
 for _ in range(64):
  child=window.translate_coords(root,x,y).child
  if child in (None,X.NONE,0):break
  ident=getattr(child,'id',child)
  if ident in chain:raise RuntimeError('cyclic child chain')
  chain.append(ident);window=d.create_resource_object('window',ident)
 else:raise RuntimeError('excessive child chain')
 if request['target'] not in chain:d.ungrab_server();d.sync();return {'status':'unknown','reason':'target_excluded','operation_id':request['operation_id'],'session_id':session}
 xtest.fake_input(d,X.ButtonPress,1);d.sync();down=time.monotonic_ns();(out/'down.json').write_text(json.dumps({'down_ns':down,'scheduled_late_ns':down+2_000_000_000,'chain':chain}))
 if request['mode']=='stall':
  time.sleep(2);xtest.fake_input(d,X.ButtonRelease,1);xtest.fake_input(d,X.ButtonPress,1);xtest.fake_input(d,X.ButtonRelease,1);(out/'late.json').write_text('late events requested')
 else:xtest.fake_input(d,X.ButtonRelease,1)
 d.sync();d.ungrab_server();d.sync();end=time.monotonic_ns();d.close();return {'status':'completed','operation_id':request['operation_id'],'session_id':session,'chain':chain,'grab_held_ns':end-start}

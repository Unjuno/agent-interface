import os,time,json,signal,subprocess,shutil,hashlib,io
from pathlib import Path
from Xlib import X,display
from Xlib.ext import xtest
from PIL import Image
from runtime.cli_v1.mcp_guarded import GuardedSessionOwner
from runtime.guarded_x11_v1.cancel_supervisor import PrestartedCancellationSupervisor,x11_cancel_worker
from worker_module import guarded_calc_click

def main():
 out=Path('/out');env=dict(os.environ,DISPLAY=':153',HOME='/tmp',SAL_USE_VCLPLUGIN='gen');actors=[];handles=[];d=None;owner=None;owner_sup=None;cleanup_sup=None
 try:
  def spawn(name,args):
   f=(out/(name+'.log')).open('wb');handles.append(f);p=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);actors.append(p);return p
  spawn('xvfb',['Xvfb',':153','-screen','0','1280x800x24','-nolisten','tcp','-ac'])
  for _ in range(100):
   try:d=display.Display(':153');break
   except Exception:time.sleep(.05)
  if d is None:raise RuntimeError('X unavailable')
  if hashlib.sha256(Path('/in/blank.fods').read_bytes()).hexdigest()!='462beebbcb020ccf49af3cc49520f789a816cc3fb97597cefbd6940ffc26aeb1':raise RuntimeError('fixture differs')
  shutil.copyfile('/in/blank.fods','/tmp/blank.fods');spawn('openbox',['openbox','--sm-disable']);lo=spawn('calc',['libreoffice','-env:UserInstallation=file:///tmp/observe-profile','--calc','--nologo','--norestore','--nofirststartwizard','/tmp/blank.fods'])
  def walk(w,depth=0):
   if depth>6:return []
   result=[]
   for child in w.query_tree().children:
    try:
     title=child.get_wm_name();title=title.decode(errors='replace') if isinstance(title,bytes) else str(title or '');result.append((child.id,title,child.get_attributes().map_state));result+=walk(child,depth+1)
    except Exception:pass
   return result
  end=time.monotonic()+20;found=[]
  while time.monotonic()<end:
   found=[r for r in walk(d.screen().root) if 'blank.fods' in r[1].lower() and 'calc' in r[1].lower() and r[2]==X.IsViewable]
   if len(found)==1:break
   if len(found)>1 or lo.poll() is not None:raise RuntimeError('target ambiguous or exited')
   time.sleep(.05)
  if len(found)!=1:raise RuntimeError('target unavailable')
  time.sleep(1);owner=GuardedSessionOwner({'app':found[0][0]},out/'owner',':153');owner.get();b=owner.bridge;before=b.observe();before_image=b.history[before['sequence']][1]
  if hashlib.sha256(before_image.crop((0,97,42,119)).tobytes()).hexdigest()!='2e86f3a0f6d87ee4fb4e5ffeb7cfd159d715cb5f6f8177b0ede83784d49088cf':raise RuntimeError('initial A1 namebox differs')
  session='calc-grab-fixture';cleanup_sup=PrestartedCancellationSupervisor(x11_cancel_worker,expected_session_id=session,startup_timeout_s=5);owner_sup=PrestartedCancellationSupervisor(guarded_calc_click,expected_session_id=session,startup_timeout_s=5);(out/'ready.json').write_text(json.dumps({'owner_pid':owner_sup.pid,'cleanup_pid':cleanup_sup.pid,'target':found[0][0]},indent=2)+'\n')
  mode=os.environ['MODE'];request={'operation_id':'click-a2','session_id':session,'target':found[0][0],'point':[81,168],'mode':mode};start=time.monotonic_ns();outcome=owner_sup.run(request,deadline_monotonic_ns=start+(800_000_000 if mode=='stall' else 3_000_000_000));(out/'owner-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
  if not outcome.get('worker_retired'):raise RuntimeError('owner not retired')
  root=d.screen().root;before_cleanup=bool(int(root.query_pointer().mask)&X.Button1Mask);cleanup=None
  if mode=='stall':
   if outcome.get('reason')!='transaction_deadline' or not before_cleanup:raise RuntimeError('expected stalled held button absent')
   custody=json.loads((out/'custody.json').read_text());down=json.loads((out/'down.json').read_text());q={'operation_id':'cleanup-1','session_id':session,'x_resource_base':custody['resource_base'],'owner_pid':custody['owner_pid'],'owner_process_retired':True,'owner_process_exitcode':outcome['worker_exitcode'],'display_name':':153','keys':{},'buttons':['left'],'binding_revision':0,'owner_generation':custody['owner_generation']}
   cleanup=cleanup_sup.run(q,deadline_monotonic_ns=time.monotonic_ns()+2_000_000_000);(out/'cleanup-outcome.json').write_text(json.dumps(cleanup,indent=2)+'\n');check_at=down['scheduled_late_ns']+300_000_000
   while time.monotonic_ns()<check_at:time.sleep(min(.05,(check_at-time.monotonic_ns())/1e9))
  else:
   if outcome.get('status')!='completed':raise RuntimeError('normal worker not completed')
   time.sleep(.3)
  after=b.observe();after_image=b.history[after['sequence']][1];crop=after_image.crop((0,97,42,119));crop.resize((168,88)).save(out/'namebox-after.png');ocr=subprocess.run(['tesseract',str(out/'namebox-after.png'),'stdout','--psm','7'],capture_output=True,text=True,timeout=3)
  final_buttons=int(root.query_pointer().mask)&(X.Button1Mask|X.Button2Mask|X.Button3Mask);record={'mode':mode,'target':found[0][0],'before_sequence':before['sequence'],'after_sequence':after['sequence'],'before_namebox_sha256':hashlib.sha256(before_image.crop((0,97,42,119)).tobytes()).hexdigest(),'after_namebox_sha256':hashlib.sha256(crop.tobytes()).hexdigest(),'ocr_text':ocr.stdout.strip(),'ocr_exit':ocr.returncode,'ocr_stderr':ocr.stderr,'button_down_before_cleanup':before_cleanup,'buttons_after':final_buttons,'late_artifact_present':(out/'late.json').exists(),'after_observed_ns':time.monotonic_ns(),'document_sha256':hashlib.sha256(Path('/tmp/blank.fods').read_bytes()).hexdigest()};(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
 finally:
  if owner_sup is not None:owner_sup.close()
  if cleanup_sup is not None:cleanup_sup.close()
  if owner is not None:(out/'owner-close.json').write_text(json.dumps(owner.close(),indent=2)+'\n')
  if d is not None:
   try:
    if int(d.screen().root.query_pointer().mask)&X.Button1Mask:xtest.fake_input(d,X.ButtonRelease,1);d.sync();(out/'fallback-release.txt').write_text('fallback required')
   finally:d.close()
  for p in reversed(actors):
   if p.poll() is None:
    try:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=3)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=3)
    except ProcessLookupError:pass
  for f in handles:f.close()

if __name__=='__main__':main()

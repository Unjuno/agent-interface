#!/bin/sh
# Foreground only. Record the actual supervise.py exit in the waiting shell.
set -u
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT" || exit 1
OUT=$1
INDEX=$2
python -S -B supervise.py "$OUT" "$INDEX"
STATUS=$?
python -S -B - "$OUT" "$INDEX" "$STATUS" <<'PY'
import json,sys,time
from pathlib import Path
root=Path(sys.argv[1]); index=int(sys.argv[2]); code=int(sys.argv[3])
p=root/('batch-%02d'%index)/'SUPERVISOR_EXIT.json'
with p.open('x') as f:
 json.dump({'exit':code,'observed_by':'waiting foreground shell','observed_ns':time.monotonic_ns()},f,sort_keys=True)
 f.write('\n')
PY
exit "$STATUS"

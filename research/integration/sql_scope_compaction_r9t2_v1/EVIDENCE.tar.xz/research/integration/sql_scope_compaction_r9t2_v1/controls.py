"""Well-formed copied-evidence mutations; hashes are refreshed before each audit."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
from audit import audit, snapshot


def load(p):
    return json.loads(Path(p).read_text())


def save(p, x):
    Path(p).write_text(json.dumps(x, sort_keys=True, indent=2) + '\n')


def rehash(folder):
    target = folder / 'RAW_MANIFEST.json'
    values = {str(p.relative_to(folder)): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in sorted(folder.rglob('*')) if p.is_file() and p != target}
    save(target, values)
    return hashlib.sha256(target.read_bytes()).hexdigest()


def sync_wire(d, x):
    for role in ('reader', 'writer'):
        path = d / (role + '.ipc.json')
        rows = load(path)
        values = ([x['boots'][role], {'op': 'prepare', 'tenant': 'A'}, x['prepare'], x['commit_request'], x['commit'], {'op': 'stop'}, {'stopped': True}]
                  if role == 'reader' else [x['boots'][role], x['write_request'], x['write'], {'op': 'stop'}, {'stopped': True}])
        for row, value in zip(rows, values):
            row['wire'] = json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n'
        save(path, rows)


def run(root, data, construction=False):
    baseline = audit(root, data, construction)
    if baseline['errors']:
        raise ValueError('ORIGINAL_BASELINE_MUST_PASS')
    changes = ('lost_batch_member', 'duplicate_identity', 'accepted_flip', 'writer_profile',
               'scope_counter', 'stored_payload', 'boolean_exit', 'authority_grant')
    results = []
    for kind in changes:
        with tempfile.TemporaryDirectory(prefix='r9t2-control-') as td:
            copied = Path(td) / 'raw'
            shutil.copytree(data, copied)
            before = rehash(copied)
            # Every intact relocated control must pass before mutation.
            intact = audit(root, copied, construction)
            if intact['errors']:
                raise ValueError('RELOCATED_BASELINE_MUST_PASS')
            paths = sorted(copied.glob('batch-*/*/ROW.json'))
            picked = next(p for p in paths if load(p)['case']['scenario'] == 'REPLACE_MOVE'
                          and load(p)['case']['policy'] == 'SCOPE_ONLY' and load(p)['case']['recursive'] == 0)
            d = picked.parent
            x = load(picked)
            if kind == 'lost_batch_member':
                ending = d.parent / 'END.json'
                obj = load(ending)
                obj['case_ids'].pop()
                save(ending, obj)
            elif kind == 'duplicate_identity':
                x['case']['case_id'] = 'duplicate-case'
            elif kind == 'accepted_flip':
                x['commit']['result']['accepted'] = False
            elif kind == 'writer_profile':
                x['boots']['writer']['recursive'] = 1
                x['write']['result']['recursive_before'] = 1
                x['write']['result']['recursive_after'] = 1
            elif kind in ('scope_counter', 'stored_payload'):
                import sqlite3
                stages = ('mutated', 'final') if kind == 'scope_counter' else ('final',)
                for stage in stages:
                    db = sqlite3.connect(d / (stage + '.sqlite'))
                    if kind == 'scope_counter':
                        db.execute("UPDATE scopes SET epoch=epoch+1 WHERE tenant='A'")
                    else:
                        db.execute("UPDATE effects SET payload='[]'")
                    db.commit()
                    db.close()
                    observed = snapshot(d / (stage + '.sqlite'))
                    x['observations'][stage] = {k: v for k, v in observed.items() if k != 'db_id'}
            elif kind == 'boolean_exit':
                x['processes']['reader']['exit'] = False
            elif kind == 'authority_grant':
                x['commit']['result']['authority'] = 'input'
            save(picked, x)
            sync_wire(d, x)
            after = rehash(copied)
            answer = audit(root, copied, construction)
            effective = before != after
            rejected = bool(answer['errors'])
            results.append({'name': kind, 'changed_bytes': effective, 'intact_passed': True,
                            'rejected': rejected, 'before_manifest': before, 'after_manifest': after,
                            'errors': answer['errors']})
    return {'baseline_pass': True, 'controls': results,
            'pass': all(c['changed_bytes'] and c['rejected'] for c in results)}


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('data')
    p.add_argument('--root', default=str(Path(__file__).resolve().parent))
    p.add_argument('--out', required=True)
    p.add_argument('--construction', action='store_true')
    a = p.parse_args()
    result = run(Path(a.root), Path(a.data), a.construction)
    save(a.out, result)
    print(json.dumps({'pass': result['pass'], 'rejected': sum(c['rejected'] for c in result['controls']), 'count': len(result['controls'])}))
    raise SystemExit(0 if result['pass'] else 1)

import hashlib,json,os,subprocess,sys,time
from pathlib import Path
p=Path('/bench'); env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'; results=[]
for opt in (False,True):
 cmd=[sys.executable]+(['-O'] if opt else [])+['-B','-m','unittest','discover','-s','/bench/research/live_control','-p','test_shadow_patch_match_v1.py'];v=subprocess.run(cmd,capture_output=True,text=True,env=env);results.append({'optimized':opt,'exit':v.returncode,'stdout':v.stdout,'stderr':v.stderr})
 if v.returncode:raise RuntimeError('unit checks failed')
sys.path.insert(0,'/bench/research/live_control');from shadow_patch_match_v1 import search
from PIL import Image
import numpy as np
source=np.asarray(Image.open(p/'source.png').convert('RGB'));checked=np.asarray(Image.open(p/'checked.png').convert('RGB'));start=time.perf_counter_ns();result=search(source,checked,(658,542));elapsed=time.perf_counter_ns()-start
if result['candidate']!=(672,586) or result['best_sum']!=8388 or result['runner_sum']!=8748 or result['candidate_count']!=4941 or result['authority_granted'] or not result['requires_revalidation']:raise RuntimeError('archived image result mismatch')
output={'status':'completed','unit_results':results,'candidate':result,'elapsed_ns':elapsed,'numpy':np.__version__,'source_sha256':hashlib.sha256((p/'source.png').read_bytes()).hexdigest(),'checked_sha256':hashlib.sha256((p/'checked.png').read_bytes()).hexdigest()};(p/'wslc-result.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps(output),flush=True)

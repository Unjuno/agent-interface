# Owned startup error and custody checks r552

Before execution, run `OwnedStartCloseTests` once normally and once under
Python `-O` in fresh isolated containers. These are eight direct tests, including
failure before spawn, a live child followed by injected start exception, child
exit before that exception, injected retirement error, injected pipe-close
error, unconfirmed retirement snapshot, unregistered failed-owner snapshot and
close/start gate with later verified normal close. All eight must pass in each
mode; an unrelated exception or fixture cleanup failure is an error. They use a
spawned Fake X owner and injected failures, not a natural failure rate or actual
X input. The separate MCP shutdown custody regression remains failing and is
not included in this scoped success claim.

Use pinned Docker image
sha256:bd191d30ea94871a1d3ca717252cd07a276e8ef7d1bcb4a130b63935ce075425,
network disabled, 1 CPU, 1 GiB, no pull, source read-only, bytecode disabled.
Save base, exact diff, output and exit for both modes. Parent exception retention
and process identity are only tested for the fixtures represented; partial
spawn without pid, identity mismatch, BaseException in cleanup, process death
between checks, real X queues, input release and MAP01 are not established.

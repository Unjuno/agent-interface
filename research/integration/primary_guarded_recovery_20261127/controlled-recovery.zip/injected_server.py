"""Test-only stdio server with the existing one-shot X11 fault factory."""
import json
from pathlib import Path
from runtime.cli_v1.mcp_server import create_server
from runtime.cli_v1.test_mcp_xvfb_generation_integration import _xvfb_recovery_fault_owner_factory

def main():
    create_server(json.loads(Path('/out/targets.json').read_text()),Path('/out/server'),
        display_name=':155',session_mode='guarded-x11',guarded_process_identity=True,
        guarded_query_worker=True,guarded_window_lifecycle=True,guarded_owned_process=True,
        _guarded_owner_factory=_xvfb_recovery_fault_owner_factory).run(transport='stdio')
if __name__=='__main__':
    main()

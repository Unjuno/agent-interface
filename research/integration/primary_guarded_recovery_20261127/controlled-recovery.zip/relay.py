"""Use the real relay implementation with only its child command redirected to the test server."""
import asyncio
from mcp import StdioServerParameters as Original
from runtime.cli_v1 import mcp_relay

def injected_parameters(*,command,args,env):
    return Original(command=command,args=['/input/injected_server.py'],env=env)
mcp_relay.StdioServerParameters=injected_parameters
asyncio.run(mcp_relay.serve(['test-only-server']))

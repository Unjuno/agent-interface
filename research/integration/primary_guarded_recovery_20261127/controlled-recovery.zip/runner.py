"""One test-only post-keydown and failed release through real primary/MCP/X11."""
import hashlib,json,os,select,signal,subprocess,threading,time,traceback
from pathlib import Path
from Xlib import X,XK,display
from PIL import Image
OUT=Path('/out'); env=dict(os.environ,DISPLAY=':155',HOME='/tmp',PYTHONPATH='/src')
actors=[]; logs=[]; d=None; observer=None; events=[]; app_stop=threading.Event()
result={'schema':'primary-xvfb-recovery-v1','passed':False,'model_calls':0,'input_attempted':False,
        'scope':'one controlled synthetic X11 fault through Node primary, relay and MCP'}
def save(name,obj):
    with (OUT/name).open('x',encoding='utf8') as f:json.dump(obj,f,sort_keys=True,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def spawn(name,args):
    f=(OUT/(name+'.log')).open('xb');logs.append(f);p=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);actors.append(p);return p
def key_down(conn,keycode):
    keys=conn.query_keymap();return bool(keys[keycode//8] & (1 << (keycode%8)))
try:
    spawn('xvfb',['Xvfb',':155','-screen','0','800x600x24','-nolisten','tcp','-ac'])
    for i in range(100):
        try:d=display.Display(':155');break
        except Exception:time.sleep(.05)
    if d is None:raise RuntimeError('Xvfb unavailable')
    root=d.screen().root;win=root.create_window(40,40,240,180,0,X.CopyFromParent,X.InputOutput,X.CopyFromParent,
        background_pixel=0,event_mask=X.KeyPressMask|X.KeyReleaseMask|X.StructureNotifyMask)
    win.map();win.set_input_focus(X.RevertToParent,X.CurrentTime);root.warp_pointer(88,88)
    gc=win.create_gc(foreground=0xffffff)
    for row in range(12):
        for col in range(15):
            if (row+col)%2==0:win.fill_rectangle(gc,col*16,row*16,16,16)
    d.sync();observer=display.Display(':155');keycode=observer.keysym_to_keycode(XK.string_to_keysym('b'))
    def app_loop():
        while not app_stop.is_set():
            if d.pending_events():
                ev=d.next_event()
                if ev.type in (X.KeyPress,X.KeyRelease):events.append({'type':ev.type,'detail':ev.detail,'ns':time.monotonic_ns()})
            else:time.sleep(.002)
    thread=threading.Thread(target=app_loop,daemon=True);thread.start()
    save('targets.json',{'app':win.id})
    config={'host':{'command':'/usr/bin/python3','args':['/input/relay.py'],'evidenceDirectory':'/out/host'},'route':'guarded-local','exchangeDirectory':'/out/exchange'}
    save('config.json',config)
    err=(OUT/'primary.stderr').open('xb');logs.append(err)
    p=subprocess.Popen(['/usr/local/bin/node','/input/host/primary_stdio.mjs','--config','/out/config.json'],env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,start_new_session=True,bufsize=0);actors.append(p)
    lines=[]
    def receive():
        buf=bytearray();deadline=time.monotonic()+30
        while not buf.endswith(b'\n'):
            remain=deadline-time.monotonic()
            if remain<=0 or not select.select([p.stdout],[],[],remain)[0]:raise TimeoutError('primary response timeout')
            b=os.read(p.stdout.fileno(),1)
            if not b:raise RuntimeError('primary stdout closed')
            buf.extend(b)
            if len(buf)>2000000:raise RuntimeError('oversized primary line')
        row=json.loads(buf);lines.append(row);save('line-%02d.json'%len(lines),row);return row
    def send(i,method,args):
        req={'id':i,'method':method,'args':args};p.stdin.write((json.dumps(req,separators=(',',':'))+'\n').encode());p.stdin.flush();return receive()
    if receive()['status']!='ready':raise ValueError('not ready')
    if send(1,'observe',[])['status']!='returned':raise ValueError('observe failed')
    with Image.open(OUT/'exchange/image-1-1.png') as im:
        im=im.convert('RGB')
        if im.getpixel((48,48))!=(255,255,255) or im.getpixel((64,48))!=(0,0,0):raise ValueError('synthetic checkerboard observation differs')
    review={'task':'synthetic-recovery','phase':'initial','reason':'Inspected exact generated checkerboard pixels and target position.'}
    if send(2,'review',[1,review])['status']!='returned':raise ValueError('review failed')
    if send(3,'mint',['cell',1,[88,88],[24,24]])['status']!='returned':raise ValueError('mint failed')
    if send(4,'acknowledgeText',[2,{'task':'synthetic-recovery','phase':'mint','reason':'Read original cell registration.'}])['status']!='returned':raise ValueError('ack failed')
    (OUT/'server/arm-recovery-fault').write_text('arm once',encoding='ascii')
    result['input_attempted']=True
    response=send(5,'input',['cell',[12,12],'keyboard',[{'op':'key_chord','keys':['b']}]])
    if response['status']!='returned':raise ValueError('input response not retained')
    reply=json.loads((OUT/'exchange/original-reply-5.json').read_text());meta=json.loads(reply['result']['content'][0]['text'])
    save('failure-summary.json',{'relay_status':reply.get('status'),'mcp_is_error':reply['result']['isError'],'metadata':meta})
    if meta.get('status')!='execution_failed' or meta['session']['recovery_required'] is not True:raise ValueError('expected injected failure absent')
    if not response['result']['caller_state']['stopped']:raise ValueError('caller failed to stop')
    before=key_down(observer,keycode);save('before.json',{'keycode':keycode,'down':before,'events':events.copy()})
    if not before:raise ValueError('fault did not leave key held')
    revision=meta['session']['binding_revision']
    response=send(6,'call',['interface_guarded_recover_input',{'current_binding_revision':revision}])
    if response['status']!='returned':raise ValueError('recovery call failed: '+str(response))
    recovered=json.loads((OUT/'exchange/original-reply-6.json').read_text());rec=json.loads(recovered['result']['content'][0]['text'])
    if recovered['result']['isError'] or rec['status']!='input_recovered' or rec['release']['verified'] is not True:raise ValueError('recovery not verified')
    after=key_down(observer,keycode);save('after.json',{'keycode':keycode,'down':after,'events':events.copy()})
    if after:raise ValueError('key still held after recovery')
    refused=send(7,'input',['cell',[12,12],'keyboard',[{'op':'key_chord','keys':['b']}]])
    if refused['status']!='command_error' or refused['replay_allowed'] is not False:raise ValueError('stopped caller accepted prior input')
    if send(8,'call',['interface_close',{}])['status']!='returned':raise ValueError('close failed')
    p.stdin.close()
    if receive()['status']!='terminal':raise ValueError('terminal missing')
    p.wait(timeout=10)
    if p.returncode!=0:raise ValueError('primary exited nonzero')
    result.update(passed=True,before_down=before,after_down=after,recovery_revision=revision,primary_exit=p.returncode)
except Exception as error:
    result.update(error_type=type(error).__name__,error=str(error));(OUT/'traceback.txt').write_text(traceback.format_exc())
finally:
    app_stop.set()
    if observer is not None:
        try:save('final-keymap.json',{'keycode':keycode,'down':key_down(observer,keycode)});observer.close()
        except Exception as error:result.update(passed=False,neutral_error=str(error))
    if d is not None:d.close()
    for proc in reversed(actors):
        if proc.poll() is None:
            try:os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=3)
            except Exception:
                try:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=3)
                except Exception as error:result.update(passed=False,cleanup_error=str(error))
    for f in logs:f.close()
    save('result.json',result)

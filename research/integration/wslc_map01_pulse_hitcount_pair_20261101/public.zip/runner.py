import json,os,signal,subprocess,time,traceback,hashlib,math,threading
from pathlib import Path
from Xlib import X,display,error,XK
import vizdoom as vd
import numpy as np
from PIL import Image
from runtime.cli_v1.mcp_guarded import GuardedSessionOwner

out=Path('/out');route='stale_overlay_replan';x=None;d=None;game=None;owner=None;overlay=None
record={'route':route,'status':'running','task_success':None,'samples':[],'model_calls':0,'events':{}}
try:
 os.environ['DISPLAY']=':153';os.environ['SDL_VIDEODRIVER']='x11';os.environ['HOME']='/tmp';os.environ['XDG_CACHE_HOME']='/tmp/cache'
 log=(out/'xvfb.log').open('wb');x=subprocess.Popen(['Xvfb',':153','-screen','0','1280x1024x24','-nolisten','tcp'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 for _ in range(100):
  try:d=display.Display(':153');break
  except Exception:time.sleep(.05)
 if d is None:raise RuntimeError('Xvfb unavailable')
 cfg=Path('/tmp/doom-keys.ini');cfg.write_text('[Doom.Bindings]\nw=+forward\ne=+use\nd=+right\na=+left\nf=+attack\n')
 pkg=Path(vd.__file__).resolve().parent;iwad=pkg/'freedoom2.wad';record['iwad_sha256']=hashlib.sha256(iwad.read_bytes()).hexdigest()
 game=vd.DoomGame();game.set_doom_game_path(str(iwad));game.set_doom_scenario_path('');game.set_doom_map('MAP01');game.set_doom_config_path(str(cfg));game.set_mode(vd.Mode.ASYNC_SPECTATOR);game.set_ticrate(35);game.set_seed(991037);game.set_doom_skill(1);game.set_episode_timeout(2100);game.set_window_visible(True);game.set_console_enabled(False);game.set_sound_enabled(False);game.set_screen_resolution(vd.ScreenResolution.RES_640X480);game.set_screen_format(vd.ScreenFormat.RGB24);game.set_available_buttons([vd.Button.MOVE_FORWARD,vd.Button.USE,vd.Button.TURN_RIGHT,vd.Button.TURN_LEFT,vd.Button.ATTACK]);game.set_labels_buffer_enabled(True);game.set_objects_info_enabled(True);game.set_available_game_variables([vd.GameVariable.POSITION_X,vd.GameVariable.POSITION_Y,vd.GameVariable.HEALTH,vd.GameVariable.KILLCOUNT,vd.GameVariable.ANGLE,vd.GameVariable.SELECTED_WEAPON_AMMO,vd.GameVariable.HITCOUNT,vd.GameVariable.DAMAGECOUNT,vd.GameVariable.HITS_TAKEN,vd.GameVariable.DAMAGE_TAKEN]);game.init()
 windows=[]
 for _ in range(250):
  windows=[]
  for w in d.screen().root.query_tree().children:
   try:
    title=w.get_wm_name()
    if title and 'DOOM' in title.upper() and w.get_attributes().map_state==X.IsViewable:windows.append(w)
   except error.BadWindow:pass
  if len(windows)==1:break
  if len(windows)>1:raise RuntimeError('ambiguous game window')
  time.sleep(.02)
 if len(windows)!=1:raise RuntimeError('game window unavailable')
 w=windows[0];d.set_input_focus(w.id,X.RevertToParent,X.CurrentTime);d.sync();time.sleep(.5)
 owner=GuardedSessionOwner({'app':w.id},out/'owner',':153',process_identity=True,query_worker=True);owner.get();bridge=owner.bridge;obs=bridge.observe();geom=obs['pointer_binding']['geometry'];point=[geom[0]+44,geom[1]+geom[3]-54];mint=bridge.mint_reference('game',obs['sequence'],point,region_size=(24,38));record['observation']=obs;record['mint']=mint
 def sample(label):
  game.advance_action(1,True);state=game.get_state();labels=[] if state is None else [str(x.object_name) for x in state.labels];objects=[] if state is None else [{'name':str(x.name),'id':int(x.id),'x':float(x.position_x),'y':float(x.position_y)} for x in state.objects]
  s={'label':label,'host_ns':time.monotonic_ns(),'tic':game.get_episode_time(),'x':game.get_game_variable(vd.GameVariable.POSITION_X),'y':game.get_game_variable(vd.GameVariable.POSITION_Y),'angle':game.get_game_variable(vd.GameVariable.ANGLE),'health':game.get_game_variable(vd.GameVariable.HEALTH),'kills':game.get_game_variable(vd.GameVariable.KILLCOUNT),'ammo':game.get_game_variable(vd.GameVariable.SELECTED_WEAPON_AMMO),'hits':game.get_game_variable(vd.GameVariable.HITCOUNT),'damage':game.get_game_variable(vd.GameVariable.DAMAGECOUNT),'hits_taken':game.get_game_variable(vd.GameVariable.HITS_TAKEN),'damage_taken':game.get_game_variable(vd.GameVariable.DAMAGE_TAKEN),'finished':game.is_episode_finished(),'visible_labels':labels,'objects':objects};record['samples'].append(s);(out/'samples.jsonl').open('a').write(json.dumps(s)+'\n');return s
 def screenshot(label):
  from PIL import Image
  g=w.get_geometry();raw=w.get_image(0,0,g.width,g.height,X.ZPixmap,0xffffffff);Image.frombytes('RGB',(g.width,g.height),raw.data,'raw','BGRX').save(out/('scene-'+label+'.png'))
 def run_action(alias,tail):
  source=bridge.observe();anchor=[geom[0]+geom[2]//2,geom[1]+geom[3]-100] if alias in ('turn','forward3','fire') else point;ref=bridge.mint_reference(alias,source['sequence'],anchor,region_size=(24,38));owner.dispatch_attempted=True
  result=bridge.keyboard(alias,ref['offset'],tail=tail,expires_at_ns=time.monotonic_ns()+4_000_000_000);(out/('action-'+alias+'.json')).write_text(json.dumps(result,indent=2)+'\n');record.setdefault('actions',[]).append(result)
  releases=result.get('execution',{}).get('releases',[])
  if result.get('status')!='completed' or not releases or not all(r.get('verified') and not r.get('keys_down') and not r.get('buttons_down') for r in releases):raise RuntimeError('action or release not confirmed')
 before=sample('before');screenshot('before')
 run_action('forward1',[{'op':'key_state','key':'w','down':True},{'op':'wait_update','timeout_ms':2000},{'op':'key_state','key':'w','down':False}]);sample('forward1');time.sleep(.8);sample('settle1')
 run_action('turn',[{'op':'key_state','key':'a','down':True},{'op':'wait_update','timeout_ms':900},{'op':'key_state','key':'a','down':False}]);sample('turn');screenshot('at-turn')
 sample('before_cancel')
 source=bridge.observe();oldref=bridge.mint_reference('cancel_target',source['sequence'],point,region_size=(24,38));record['cancel_reference']=oldref
 outcomes=[];errors=[]
 def cancelled_action():
  try:
   with bridge.cancellation_scope('recovery_token'):
    outcomes.append(bridge.keyboard('cancel_target',oldref['offset'],tail=[{'op':'key_state','key':'a','down':True},{'op':'wait_update','timeout_ms':500},{'op':'key_state','key':'a','down':False}],expires_at_ns=time.monotonic_ns()+4_000_000_000))
  except BaseException as e:errors.append(repr(e))
 owner.dispatch_attempted=True;worker=threading.Thread(target=cancelled_action);worker.start();code=d.keysym_to_keycode(XK.string_to_keysym('a'));until=time.monotonic()+2;held=False
 while time.monotonic()<until and worker.is_alive():
  keys=d.query_keymap()
  if keys[code//8]&(1<<(code%8)):held=True;break
  time.sleep(.002)
 record['cancel_monitor']={'held_observed':held,'held_ns':time.monotonic_ns()}
 if not held:
  record['cancel_monitor']['cancel_on_stop']=bridge.request_cancel('recovery_token');worker.join(4)
  record['cancel_monitor']['worker_alive']=worker.is_alive();record['cancel_monitor']['errors']=errors;record['cancel_monitor']['outcomes']=outcomes
  raise RuntimeError('held input not observed; no recovery trial')
 time.sleep(.05);record['cancel_monitor']['request_ns']=time.monotonic_ns();record['cancel_monitor']['response']=bridge.request_cancel('recovery_token');worker.join(4)
 if worker.is_alive() or errors or len(outcomes)!=1:raise RuntimeError('cancel worker unfinished '+repr(errors))
 result=outcomes[0];record['cancel_result']=result;(out/'cancel-action.json').write_text(json.dumps(result,indent=2)+'\n')
 releases=result.get('execution',{}).get('releases',[])
 if result.get('status')!='execution_failed' or not releases or not all(r.get('verified') and not r.get('keys_down') and not r.get('buttons_down') for r in releases):raise RuntimeError('cancel release not verified')
 if record['cancel_monitor']['response'].get('status')!='cancel_requested':raise RuntimeError('cancel request not accepted')
 sample('after_cancel');review=bridge.review_window(w.id);record['recovery_review']={k:v for k,v in review.items() if k!='observation'};(out/'review.json').write_text(json.dumps(review,indent=2)+'\n')
 if review.get('status')!='reviewed':raise RuntimeError('review refused')
 stale=bridge.keyboard('cancel_target',oldref['offset'],tail=[{'op':'key_chord','keys':['a']}],expires_at_ns=time.monotonic_ns()+2_000_000_000);record['stale_after_review']=stale;(out/'stale.json').write_text(json.dumps(stale,indent=2)+'\n')
 if stale.get('status')!='refused' or stale.get('input_dispatched') is not False:raise RuntimeError('stale reference admitted')
 sample('after_review')


 # Freeze source image, request model 1, then change an overlapping visible region.
 ex=Path('/exchange')
 def begin_call(i,source):
  img=ex/('image-%d.png'%i);bridge.history[source['sequence']][1].save(img);digest=hashlib.sha256(img.read_bytes()).hexdigest();g=source['pointer_binding']['geometry']
  if g!=[320,272,640,480]:raise RuntimeError('unexpected geometry')
  req={'id':'pilot-%d'%i,'image_sha256':digest,'binding_geometry':g};tmp=ex/('request-%d.tmp'%i);tmp.write_text(json.dumps(req));os.replace(tmp,ex/('request-%d.json'%i));return digest
 def finish_call(i):
  end=time.monotonic()+100;path=ex/('done-%d.json'%i)
  while not path.exists():
   if (ex/'host-error.json').exists():raise RuntimeError('model host error')
   if time.monotonic()>end:raise TimeoutError('model deadline')
   time.sleep(.02)
  answer=json.loads(path.read_text())
  if not answer.get('ok'):raise RuntimeError('invalid model result')
  record['model_calls']=i;record.setdefault('model_responses',[]).append(answer);return answer
 def evaluate(source,policy):
  oldim=bridge.history[source['sequence']][1];current=bridge.observe();newim=bridge.history[current['sequence']][1];px,py=policy['target_x'],policy['target_y'];bounds=0<=px-4<px+4<=oldim.width and 0<=py-4<py+4<=oldim.height
  old=oldim.crop((px-4,py-4,px+4,py+4)).tobytes() if bounds else b'';new=newim.crop((px-4,py-4,px+4,py+4)).tobytes() if bounds else b'';colors=len(set(tuple(old[i:i+3]) for i in range(0,len(old),3))) if old else 0;diff=sum(abs(a-b) for a,b in zip(old,new))/len(old) if old and len(old)==len(new) else 999;center=abs(px-(geom[0]+geom[2]//2))<=40 and abs(py-(geom[1]+geom[3]//2))<=60;binding=source['pointer_binding']==current['pointer_binding'];eligible=policy['action']=='fire' and bounds and center and colors>=2 and diff<=32 and binding
  return {'eligible':eligible,'bounds':bounds,'center':center,'colors':colors,'difference':diff,'binding_equal':binding,'threshold':32,'source_sequence':source['sequence'],'current_sequence':current['sequence']},current,new
 mode="steer"
 if mode not in ("wait","steer"):raise ValueError("invalid steering mode")
 record["steer_mode"]=mode;source=bridge.observe();record["source1_digest"]=begin_call(1,source);limit=time.monotonic()+100
 while not (ex/"accepted-1.json").exists():
  if (ex/"host-error.json").exists():raise RuntimeError("host failed")
  if time.monotonic()>limit:raise TimeoutError("turn acceptance missing")
  time.sleep(.01)
 record["turn_accepted"]=json.loads((ex/"accepted-1.json").read_text());tmp=ex/"overlay-ready.tmp";tmp.write_text(json.dumps({"mapped":False}));os.replace(tmp,ex/"overlay-ready.json")
 first=finish_call(1);record["pending_check"]=json.loads((ex/"pending-check-1.json").read_text())
 if not record["pending_check"].get("no_completion_observed") or record["pending_check"].get("turn_id")!=first.get("call_id"):raise RuntimeError("turn precondition failed")
 gate,now,reference=evaluate(source,first["grounding"]);record["gate"]=gate
 def score(label):
  sample(label);state=game.get_state();items=[] if state is None else [{"name":str(q.object_name),"x":int(q.x),"y":int(q.y),"width":int(q.width),"height":int(q.height)} for q in state.labels];record.setdefault("scorer_labels",{})[label]=items;screenshot(label)
 score("steer_before");offset=first["grounding"]["target_x"]-(geom[0]+geom[2]//2);record["model_offset_px"]=offset
 if not gate["eligible"] or abs(offset)<=5:raise RuntimeError("precondition: eligible off-center model target required")
 if mode=="wait":
  record["wait_started_ns"]=time.monotonic_ns();time.sleep(.05);record["wait_ended_ns"]=time.monotonic_ns();record["steering"]={"status":"withheld_control","input_dispatched":False}
 else:
  key="d" if offset>0 else "a";record["steer_key"]=key;anchor=[geom[0]+geom[2]//2,geom[1]+geom[3]-100];ref=bridge.mint_reference("steer",now["sequence"],anchor,region_size=(24,38));tail=[{"op":"key_state","key":key,"down":True},{"op":"wait_update","timeout_ms":50},{"op":"key_state","key":key,"down":False}];px,py=first["grounding"]["target_x"],first["grounding"]["target_y"];checks=[]
  def verify(stage,native,im):
   patch=im.crop((px-4,py-4,px+4,py+4)).tobytes();difference=sum(abs(a-b) for a,b in zip(patch,reference))/len(reference) if len(patch)==len(reference) and reference else 999;valid=difference<=32 and native["pointer_binding"]==now["pointer_binding"];checks.append({"stage":stage,"sequence":native["sequence"],"difference":difference,"eligible":valid});return valid
  owner.dispatch_attempted=True
  with bridge.cancellation_scope("steer_token"):
   with bridge.input_guard("steer",ref["offset"],tail=tail,verify=verify,interaction="keyboard"):
    action=bridge.keyboard("steer",ref["offset"],tail=tail,expires_at_ns=time.monotonic_ns()+4_000_000_000)
  record["steering"]=action;record["steering_guard_checks"]=checks;(out/"steer-action.json").write_text(json.dumps(action,indent=2)+"\n")
  rel=action.get("execution",{}).get("releases",[])
  if action.get("status")!="completed" or not rel or not all(v.get("verified") and not v.get("keys_down") and not v.get("buttons_down") for v in rel):raise RuntimeError("steering release not confirmed")
 score("steer_after");time.sleep(.5);score("steer_coast")
 # New observation and second model decision after steering and release.
 source2=bridge.observe();record["source2_digest"]=begin_call(2,source2);second=finish_call(2);gate2,now2,reference2=evaluate(source2,second["grounding"]);record["second_gate"]=gate2;score("before_final")
 mode2=os.environ["FINAL_MODE"]
 if mode2 not in ("wait","attack"):raise ValueError("unknown final mode")
 record["final_mode"]=mode2
 if not gate2["eligible"]:raise RuntimeError("second fresh target not eligible")
 if mode2=="wait":
  record["wait_started_ns"]=time.monotonic_ns();time.sleep(.2);record["wait_ended_ns"]=time.monotonic_ns();record["final_action"]={"status":"withheld_control","input_dispatched":False}
 else:
  policy=second["grounding"];px,py=policy["target_x"],policy["target_y"];anchor=[geom[0]+geom[2]//2,geom[1]+geom[3]-100];ref=bridge.mint_reference("model_fire",now2["sequence"],anchor,region_size=(24,38));tail=[{"op":"key_state","key":"f","down":True},{"op":"wait_update","timeout_ms":200},{"op":"key_state","key":"f","down":False}];checks2=[]
  def verify2(stage,native,im):
   patch=im.crop((px-4,py-4,px+4,py+4)).tobytes();difference=sum(abs(a-b) for a,b in zip(patch,reference2))/len(reference2) if len(patch)==len(reference2) and reference2 else 999;valid=difference<=32 and native["pointer_binding"]==now2["pointer_binding"];checks2.append({"stage":stage,"sequence":native["sequence"],"difference":difference,"eligible":valid});return valid
  owner.dispatch_attempted=True
  with bridge.cancellation_scope("final_fire_token"):
   with bridge.input_guard("model_fire",ref["offset"],tail=tail,verify=verify2,interaction="keyboard"):
    action2=bridge.keyboard("model_fire",ref["offset"],tail=tail,expires_at_ns=time.monotonic_ns()+4_000_000_000)
  record["final_action"]=action2;record["final_guard_checks"]=checks2;(out/"final-action.json").write_text(json.dumps(action2,indent=2)+"\n")
  releases=action2.get("execution",{}).get("releases",[])
  if action2.get("status")!="completed" or not releases or not all(v.get("verified") and not v.get("keys_down") and not v.get("buttons_down") for v in releases):raise RuntimeError("attack release not confirmed")
 score("after_final")
 for i in range(8):
  if game.is_episode_finished():break
  time.sleep(.15);score("final_coast_%d"%i)
 record["close"]=owner.close();owner=None
 keys=d.query_keymap();record["keys_down_after"]=[key for key in ("w","e","d","a","f") if (lambda code:code and bool(keys[code//8]&(1<<(code%8))))(d.keysym_to_keycode(XK.string_to_keysym(key)))];record["status"]="completed"

except BaseException as e:record['status']='error';record['error']=repr(e);(out/'traceback.txt').write_text(traceback.format_exc())
finally:
 if overlay is not None and d is not None:
  try:overlay.destroy();d.sync()
  except BaseException as e:record['overlay_cleanup_error']=repr(e)
 try:Path('/exchange/stop.json').write_text('{}')
 except BaseException as e:record['host_stop_error']=repr(e)
 if owner is not None:
  try:record['finally_close']=owner.close()
  except BaseException as e:record['close_error']=repr(e)
 if game is not None:
  try:game.close()
  except BaseException as e:record['game_close_error']=repr(e)
 if d is not None:d.close()
 if x is not None and x.poll() is None:
  try:os.killpg(x.pid,signal.SIGTERM);x.wait(timeout=3)
  except BaseException as e:record['xvfb_close_error']=repr(e)
 (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')

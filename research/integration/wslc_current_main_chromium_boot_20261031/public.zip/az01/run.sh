#!/bin/sh
set -eu
Xvfb :91 -screen 0 1280x800x24 -nolisten tcp -ac >/out/xvfb.log 2>&1 &
xpid=$!
trap 'kill "$xpid" 2>/dev/null || true' EXIT
export DISPLAY=:91 PYTHONDONTWRITEBYTECODE=1 AGENT_INTERFACE_CHROMIUM=/usr/bin/chromium
export PYTHONPATH=/source/research/live_control:/source/research/observation_gating:/source/research/observation_tiles:/source/research/real_apps_v1:/source
sleep 1
openbox --sm-disable >/out/openbox.log 2>&1 &
python3 - <<'PY'
import json
from pathlib import Path
from integrated_efficiency_client_v1 import RuntimeClient
c=RuntimeClient(Path('/out')/'client',991035)
try:
 c.start()
 Path('/out/receipt.json').write_text(json.dumps({'status':'ready','ready_event':c.ready.get('event'),'app':c.ready.get('app'),'configured_chromium':c.chromium})+'\n')
finally:
 c.close()
PY
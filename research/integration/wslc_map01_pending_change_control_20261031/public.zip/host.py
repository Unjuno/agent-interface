import hashlib,json,time,sys,os,io
from pathlib import Path
from PIL import Image
sys.path.insert(0,str(Path(sys.argv[2]).resolve().parent/'adapter'))
import integrated_efficiency_app_server_model_v1 as adapter
root=Path(sys.argv[2]).resolve();ex=root/'exchange';arm=sys.argv[3];size=(1280,1024) if arm=='full' else (640,480);m=None;result={'id':'pilot-1','ok':False}
def put(name,data):
 tmp=ex/(name+'.tmp');tmp.write_text(json.dumps(data));os.replace(tmp,ex/(name+'.json'))
def read_with_retry(path, *, binary=False):
 deadline=time.monotonic()+2;attempts=0
 while True:
  try:
   data=path.read_bytes() if binary else path.read_text()
   with (root/'host-file-reads.jsonl').open('a',encoding='utf-8') as log:log.write(json.dumps({'name':path.name,'attempts':attempts+1})+'\n')
   return data
  except PermissionError:
   attempts+=1
   if time.monotonic()>=deadline:raise
   time.sleep(.02)
def validate(value):
 if type(value) is not dict or set(value)!={'action','target_x','target_y','duration_ms'}:raise ValueError('invalid policy shape')
 if value['action'] not in ('fire','idle') or any(type(value[k]) is not int for k in ('target_x','target_y','duration_ms')):raise ValueError('invalid policy fields')
 if not 0<=value['target_x']<size[0] or not 0<=value['target_y']<size[1] or value['duration_ms'] not in (0,500,1000,1500,2000):raise ValueError('policy out of bounds')
 if (value['action']=='idle') != (value['duration_ms']==0):raise ValueError('duration/action mismatch')
 return value
try:
 if arm not in ('full','crop'):raise ValueError('invalid arm')
 workspace=root/'workspace';workspace.mkdir(exist_ok=False);adapter.CONTRACTS['policy']=(root.parent/'policy-schema.json',root.parent/'policy-instructions.txt',validate)
 m=adapter.PersistentGroundingModel(root/'model-session',workspace,executable=sys.argv[1],contract='policy',model='gpt-6.1-sol',effort='low',path_converter=lambda p:str(Path(p).resolve()));put('ready',{'ready':True})
 for i in (1,2):
  result={'id':f'pilot-{i}','ok':False};deadline=time.monotonic()+100
  while not (ex/f'request-{i}.json').exists():
   if (ex/'stop.json').exists():break
   if time.monotonic()>deadline:raise TimeoutError('request not observed')
   time.sleep(.02)
  if (ex/'stop.json').exists() and not (ex/f'request-{i}.json').exists():break
  request=json.loads(read_with_retry(ex/f'request-{i}.json'));image=ex/f'image-{i}.png';digest=hashlib.sha256(read_with_retry(image,binary=True)).hexdigest()
  if request['id']!=result['id'] or request['image_sha256']!=digest:raise ValueError('image mismatch')
  if request['binding_geometry']!=[320,272,640,480]:raise ValueError('unexpected target geometry')
  submitted=image
  if arm=='crop':
   submitted=ex/f'model-image-{i}.png'
   with Image.open(io.BytesIO(read_with_retry(image,binary=True))) as im:
    if im.size!=(1280,1024):raise ValueError('unexpected screenshot size')
    im.convert('RGB').crop((320,272,960,752)).save(submitted)
  submitted_digest=hashlib.sha256(read_with_retry(submitted,binary=True)).hexdigest();put(f'started-{i}',{'started':True});result['attempted']=True
  prompt=('Choose a bounded action for this Doom game image. If a hostile character is visible near the center and firing is appropriate, choose fire with its center as target; otherwise idle. Use at most 2000 ms. A runtime will revalidate before executing once.' if i>=3 else 'Choose the bounded next policy for this Doom game image. If a hostile character is visible near the center and firing is appropriate, choose fire with its center as target; otherwise idle. Use at most 2000 ms. The policy may run only during the next pending model call, after visual revalidation.')
  if i==5:prompt='The prior attack was interrupted; its effect may still be unknown. Review this fresh Doom screenshot. If a hostile character is visible near the center and firing is appropriate, select fire at its center; otherwise select idle. Do not assume the earlier attack was undone. The runtime will revalidate any action.'
  if i==6:prompt='The previous proposed shot was not executed because the scene changed. An earlier interrupted attack may still have had an effect. Review this new Doom screenshot; choose fire only if a hostile character is visible near the center and firing is appropriate, otherwise choose idle. A runtime will revalidate once; no further retry is planned.'
  if i==2:prompt='The earlier proposed action was not executed because the image changed. Review this fresh Doom screenshot. If a hostile character is visible near the center and firing is appropriate, choose fire at its center; otherwise idle. The runtime revalidates before input.'
  prompt+=' Give target coordinates in pixels of the supplied image.'
  if i==1:
   original_begin=m.planner.begin_turn
   def observed_begin(*args,**kwargs):
    handle=original_begin(*args,**kwargs);put('accepted-1',{'accepted':True,'turn_id':handle.turn_id});limit=time.monotonic()+10
    while not (ex/'overlay-ready.json').exists():
     if (ex/'stop.json').exists():raise RuntimeError('runner stopped before overlay')
     if time.monotonic()>limit:raise TimeoutError('overlay acknowledgement missing')
     time.sleep(.01)
    with m.client._condition:
     completed=any(row.get('method')=='turn/completed' and row.get('params',{}).get('threadId')==handle.thread_id and row.get('params',{}).get('turn',{}).get('id')==handle.turn_id for row in m.client._notifications)
    put('pending-check-1',{'turn_id':handle.turn_id,'no_completion_observed':not completed});return handle
   m.planner.begin_turn=observed_begin
  value=m.call(root/f'model-call-{i}',prompt,submitted,'policy',workspace)
  if i==1:m.planner.begin_turn=original_begin
  raw=value['grounding'];mapped=dict(raw)
  if arm=='crop':mapped['target_x']+=320;mapped['target_y']+=272
  result.update(ok=True,image_sha256=digest,submitted_image_sha256=submitted_digest,submitted_arm=arm,model_grounding=raw,grounding=mapped,usage=value['usage'],call_id=value['call_id'],runner_ns=value['runner_ns']);put(f'done-{i}',result)
except BaseException as e:
 result.update(error=type(e).__name__,detail=str(e)[:500],call_id=getattr(e,'call_id',None),usage=getattr(e,'usage',None));put('host-error',result)
finally:
 if m is not None:
  try:m.close();put('closed',{'closed':True})
  except BaseException as e:put('closed',{'closed':False,'error':repr(e)})
print(json.dumps({'ok':result.get('ok'),'error':result.get('error')}),flush=True)

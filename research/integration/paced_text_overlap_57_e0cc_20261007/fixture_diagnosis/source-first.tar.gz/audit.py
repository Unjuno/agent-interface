"""Independent saved-data checks for the two target-layer regression records."""
import hashlib
import json
from pathlib import Path


def audit(package, result):
    failures, checks = [], []

    def check(name, good):
        checks.append(name)
        if not good:
            failures.append(name)

    def read(path):
        return json.loads(path.read_text())

    try:
        protocol = read(package / 'protocol.json')
        for item in read(package / 'source-lock.json')['paths']:
            check('source:' + item['path'], hashlib.sha256((package / 'source' / item['path']).read_bytes()).hexdigest() == item['sha256'])
        invocations = read(result / 'invocations.json')
        check('two first ordered cases', [r['case'] for r in invocations] == [c['id'] for c in protocol['cases']])
        check('independent drivers', len({r['pid'] for r in invocations}) == 2)
        for row in invocations:
            check(row['case'] + ': driver', row['returncode'] == 0 and row['rescued'] is False
                  and 0 < row['end_ns'] - row['start_ns'] < 15_000_000_000)
        environment = read(result / 'environment.json')
        quota, period = environment['limits']['cpu.max'].split()
        check('resource limits', quota != 'max' and int(quota) == int(period)
              and environment['limits']['memory.max'] == '536870912'
              and environment['limits']['memory.swap.max'] == '0'
              and environment['limits']['pids.max'] == '128' and environment['uid'] == 501)
        check('source not writable', environment['source_writable'] is False)
        check('private network', not environment['route'].strip().splitlines()[1:] and all(
              r['ifname'] == 'lo' or ('UP' not in r['flags'] and not r['addr_info']) for r in environment['links']))
        for case in protocol['cases']:
            name = case['id']
            row = read(result / name / 'record.json')
            effect = read(result / name / 'effect.json')
            check(name + ': identity', row['case'] == case and row['core_accepted'] is True)
            check(name + ': receipt', not row.get('infrastructure_error') and row['status'] == 'completed'
                  and row['execution']['completed_ops'] == [0, 1, 2, 3])
            check(name + ': equal delay', row['program']['ops'][1] == {'op': 'wait_update', 'timeout_ms': 100})
            check(name + ': initial neutral', row['initial_keymap'] == [0] * 32 and row['initial_buttons'] == 0 and row['autorepeat'] == 0)
            check(name + ': final neutral', row['final_keymap'] == row['post_settle_keymap'] == [0] * 32
                  and row['final_buttons'] == 0 and row['final_held'] == {} and row['execution']['releases'][-1]['verified'] is True)
            target = row['target']
            check(name + ': target layer', target['xid'] == target[case['target_kind']] and target['widget'] != target['wrapper'])
            boundaries = row['text_boundaries']
            check(name + ': one text operation', len(boundaries) == 1 and boundaries[0]['value'] == 'q')
            boundary = boundaries[0]
            check(name + ': native focus before input', boundary['native_focus_before'] == target['xid'])
            check(name + ': recipient focus before input', boundary['receiver_before']['focused'] == case['expected_focus'])
            check(name + ': text effect', row['app_effect']['text'] == effect['text'] == case['expected_text'])
            check(name + ': final recipient focus', row['app_effect']['focused'] == case['expected_focus'])
            chars = ''.join(e['char'] for e in effect['events'] if e['type'] == '2')
            check(name + ': events', chars == case['expected_text'])
            requests = row['requests']
            check(name + ': native q requests', len(requests) == 2 and [r['kind'] for r in requests] == [2, 3]
                  and all(r['detail'] == row['keycodes']['q'] and r['returned'] for r in requests))
            check(name + ': post-execution heartbeat', row['app_effect']['monotonic_ns'] > row['execution_end_ns'])
            check(name + ': display removed', row['display_removed'] is True)
            for kind in ['app_exit', 'xvfb_exit']:
                check(name + ': ' + kind, row[kind]['returncode'] == 0 and row[kind]['forced_kill'] is False)
    except Exception as error:
        failures.append(type(error).__name__ + ': ' + str(error))
    return dict(decision='HOLD' if failures else 'SUPPORT_FIXTURE_TARGET_LAYER', checks=len(checks), failures=failures,
                scope='Two ordinary q regressions; original six-cell application-prefix result remains FAIL_OR_HOLD.')


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('package', type=Path)
    parser.add_argument('result', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    report = audit(args.package, args.result)
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps(report))
    raise SystemExit(bool(report['failures']))

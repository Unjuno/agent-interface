"""Independent synthetic Tk receiver; never imports the backend or runner."""
import json
import signal
import sys
import time
import tkinter as tk
from pathlib import Path

out = Path(sys.argv[1])
root = tk.Tk()
root.title('Paced text construction')
root.geometry('400x160+20+20')
entry = tk.Entry(root)
entry.pack(padx=20, pady=30)
events = []


def write_state():
    row = dict(text=entry.get(), events=events, monotonic_ns=time.monotonic_ns(),
               focused=str(root.focus_get()))
    tmp = out / 'effect.tmp'
    tmp.write_text(json.dumps(row) + '\n')
    tmp.replace(out / 'effect.json')


def event_seen(event):
    events.append(dict(type=str(event.type), keysym=event.keysym, char=event.char,
                       keycode=event.keycode, state=event.state, monotonic_ns=time.monotonic_ns()))
    root.after_idle(write_state)


entry.bind('<KeyPress>', event_seen, add='+')
entry.bind('<KeyRelease>', event_seen, add='+')


def tick():
    write_state()
    root.after(10, tick)


def stop(_signum, _frame):
    write_state()
    root.after_idle(root.destroy)


signal.signal(signal.SIGTERM, stop)
root.update()
entry.focus_set()
root.update()
(out / 'meta.json').write_text(json.dumps(dict(window_id=entry.winfo_id(),
    root_id=root.winfo_id(), pid=__import__('os').getpid())) + '\n')
tick()
root.mainloop()

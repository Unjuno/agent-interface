"""Bounded six-cell native construction. Does not choose or modify expectations."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import secrets
import signal
import subprocess
import sys
import tempfile
import time
import traceback

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'source'))
from Xlib import X, display
from runtime.backends.x11_v1 import backend as native
from runtime.core_v1.contract import SCHEMA_PROGRAM, validate_program
from runtime.core_v1.sequence import expand_text_gaps


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def wait_for(check, seconds=3):
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        found = check()
        if found:
            return found
        time.sleep(.01)
    raise TimeoutError('bounded readiness wait')


def read_json(path):
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError):
        return None


def stop(proc):
    if proc is None:
        return None
    if proc.poll() is None:
        proc.terminate()
    forced = False
    try:
        code = proc.wait(timeout=2)
    except subprocess.TimeoutExpired:
        forced = True
        proc.kill()
        code = proc.wait(timeout=2)
    return dict(pid=proc.pid, returncode=code, forced_kill=forced)


def cell(case, out):
    out.mkdir()
    row = dict(case=case, start_ns=time.monotonic_ns(), requests=[], text_boundaries=[])
    xvfb = app = backend = observer = None
    files = []
    try:
        with tempfile.TemporaryDirectory(prefix='paced-auth-') as temporary:
            auth = Path(temporary) / 'authority'
            auth.touch(mode=0o600)
            # Cookie is ephemeral, local to this cell, and never written to retained logs.
            subprocess.run(['xauth', '-f', str(auth), 'add', ':91',
                            'MIT-MAGIC-COOKIE-1', secrets.token_hex(16)],
                           check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=2)
            env = dict(os.environ, DISPLAY=':91', XAUTHORITY=str(auth))
            os.environ.update(DISPLAY=':91', XAUTHORITY=str(auth))
            if Path('/tmp/.X11-unix/X91').exists() or Path('/tmp/.X91-lock').exists():
                raise RuntimeError('display namespace is not fresh')
            files = [(out / name).open('xb') for name in ['xvfb.stdout', 'xvfb.stderr', 'app.stdout', 'app.stderr']]
            xvfb = subprocess.Popen(['Xvfb', ':91', '-screen', '0', '640x480x24',
                '-nolisten', 'tcp', '-auth', str(auth), '-r'], env=env, stdout=files[0], stderr=files[1])
            wait_for(lambda: Path('/tmp/.X11-unix/X91').exists())
            observer = display.Display(':91')
            row['autorepeat'] = observer.get_keyboard_control().global_auto_repeat
            row['initial_keymap'] = list(observer.query_keymap())
            row['initial_buttons'] = observer.screen().root.query_pointer().mask
            if any(row['initial_keymap']) or row['initial_buttons'] or row['autorepeat'] != 0:
                raise RuntimeError('non-neutral fresh display')
            app = subprocess.Popen([sys.executable, str(HERE / 'recipient.py'), str(out)],
                                   env=env, stdout=files[2], stderr=files[3])
            meta = wait_for(lambda: read_json(out / 'meta.json'))
            row['recipient_meta'] = meta
            backend = native.X11Backend(':91', {'fixture': meta['window_id']})
            row['keycodes'] = {key: backend._keycode(key) for key in ['a', 'b', 'SHIFT']}
            row['keyboard_map'] = backend._keyboard_mapping_snapshot()
            original_emit, original_text = native.xtest.fake_input, backend.text

            def emit(*args, **kwargs):
                journal = dict(kind=int(args[1]), detail=int(args[2]) if len(args) > 2 else None,
                               start_ns=time.monotonic_ns(), returned=False)
                row['requests'].append(journal)
                value = original_emit(*args, **kwargs)
                journal.update(returned=True, end_ns=time.monotonic_ns())
                return value

            def text(value):
                before = dict(value=value, held_before=dict(backend.held_keycodes),
                              keymap_before=list(observer.query_keymap()), request_start=len(row['requests']))
                row['text_boundaries'].append(before)
                try:
                    return original_text(value)
                finally:
                    before.update(held_after=dict(backend.held_keycodes),
                                  keymap_after=list(observer.query_keymap()), request_end=len(row['requests']))

            native.xtest.fake_input = emit
            backend.text = text
            operations = [{'op': 'focus', 'target': 'fixture'}]
            if case['held']:
                operations += [{'op': 'key_state', 'key': case['held'], 'down': True}]
            operations += [{'op': 'text', 'text': case['text'], 'gap_ms': case['gap_ms']}]
            if case['held']:
                operations += [{'op': 'key_state', 'key': case['held'], 'down': False}]
            operations += [{'op': 'release_all'}]
            ops, sources = expand_text_gaps(operations)
            program = dict(schema=SCHEMA_PROGRAM, program_id=case['id'],
                source=dict(observation_seq=0, binding_revision=0),
                authority=dict(lease_id='owned-synthetic-display', expires_at_ns=time.monotonic_ns()+5_000_000_000),
                terminal=dict(release_all_required=True), ops=ops)
            validate_program(program)
            row.update(program=program, source_operations=operations, expanded_sources=sources, core_accepted=True)
            try:
                row['execution'] = backend.execute(program)
                row['status'] = 'completed'
            except native.X11ExecutionError as error:
                row.update(status='execution_failed', execution=error.execution)
            row['execution_end_ns'] = time.monotonic_ns()
            row['final_keymap'] = list(observer.query_keymap())
            row['final_buttons'] = observer.screen().root.query_pointer().mask
            row['final_held'] = dict(backend.held_keycodes)
            # Independent app heartbeat must advance beyond execution; then allow its event queue to settle.
            wait_for(lambda: (read_json(out / 'effect.json') or {}).get('monotonic_ns', 0) > row['execution_end_ns'])
            time.sleep(.15)
            row['app_effect'] = read_json(out / 'effect.json')
            row['post_settle_keymap'] = list(observer.query_keymap())
            native.xtest.fake_input = original_emit
            backend.close(); backend = None
            observer.close(); observer = None
            row['app_exit'] = stop(app); app = None
            row['xvfb_exit'] = stop(xvfb); xvfb = None
            row['display_removed'] = not Path('/tmp/.X11-unix/X91').exists() and not Path('/tmp/.X91-lock').exists()
    except BaseException:
        row['infrastructure_error'] = traceback.format_exc()
    finally:
        if backend is not None:
            try:
                row['rescue_release'] = backend.release_all()
                backend.close()
            except BaseException:
                row['rescue_error'] = traceback.format_exc()
        if observer is not None:
            observer.close()
        if app is not None:
            row['app_exit'] = stop(app)
        if xvfb is not None:
            row['xvfb_exit'] = stop(xvfb)
        for stream in files:
            stream.close()
        row['end_ns'] = time.monotonic_ns()
        save(out / 'record.json', row)
    return 1 if row.get('infrastructure_error') else 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--case')
    parser.add_argument('--preflight', action='store_true')
    args = parser.parse_args()
    protocol = read_json(HERE / 'protocol.json')
    if args.case:
        case = next(c for c in protocol['cases'] if c['id'] == args.case)
        return cell(case, args.out / case['id'])
    args.out.mkdir(exist_ok=False)
    lock = read_json(HERE / 'source-lock.json')
    for item in lock['paths']:
        if hashlib.sha256((HERE / 'source' / item['path']).read_bytes()).hexdigest() != item['sha256']:
            raise RuntimeError('source mismatch')
    cgroup_relative = next(line.split('::', 1)[1] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
    cgroup = Path('/sys/fs/cgroup') / cgroup_relative.lstrip('/')
    limits = {name: (cgroup / name).read_text().strip()
              for name in ['cpu.max', 'memory.max', 'memory.swap.max', 'pids.max']}
    links = json.loads(subprocess.check_output(['ip', '-j', 'address']))
    source_writable = os.access(HERE / 'run.py', os.W_OK) or os.access(HERE / 'source', os.W_OK)
    environment = dict(source_writable=source_writable, limits=limits, cgroup=cgroup_relative, uid=os.getuid(), links=links,
                       route=Path('/proc/net/route').read_text(), python=sys.version,
                       packages=subprocess.check_output(['dpkg-query', '-W', '-f=${Package}=${Version}\n',
                           'python3', 'python3-xlib', 'python3-tk', 'xvfb', 'xauth'], text=True))
    save(args.out / 'environment.json', environment)
    quota, period = limits['cpu.max'].split()
    network_ok = all(link['ifname'] == 'lo' or ('UP' not in link.get('flags', []) and not link.get('addr_info')) for link in links)
    routes_empty = not environment['route'].strip().splitlines()[1:]
    if (quota == 'max' or int(quota) != int(period) or limits['memory.max'] != '536870912'
            or limits['memory.swap.max'] != '0' or limits['pids.max'] != '128'
            or source_writable or environment['uid'] != 501 or not network_ok or not routes_empty):
        raise RuntimeError('effective resource/isolation gate mismatch before input')
    if args.preflight:
        print(json.dumps(dict(preflight='PASS', environment=environment, input_started=False)))
        return 0
    receipts = []
    for case in protocol['cases']:
        argv = [sys.executable, '-B', str(HERE / 'run.py'), '--out', str(args.out), '--case', case['id']]
        start = time.monotonic_ns()
        with (args.out / (case['id']+'.stdout')).open('xb') as out, (args.out / (case['id']+'.stderr')).open('xb') as err:
            proc = subprocess.Popen(argv, stdout=out, stderr=err, start_new_session=True)
            rescued = False
            try:
                code = proc.wait(timeout=15)
            except subprocess.TimeoutExpired:
                rescued = True
                os.killpg(proc.pid, signal.SIGKILL)
                code = proc.wait(timeout=3)
        receipts.append(dict(case=case['id'], argv=argv, pid=proc.pid, returncode=code,
                             rescued=rescued, start_ns=start, end_ns=time.monotonic_ns()))
        if code or rescued:
            break
    save(args.out / 'invocations.json', receipts)
    print(json.dumps(dict(cells=len(receipts), returncodes=[r['returncode'] for r in receipts])))
    return int(len(receipts)!=len(protocol['cases']) or any(r['returncode'] for r in receipts))


if __name__ == '__main__':
    raise SystemExit(main())

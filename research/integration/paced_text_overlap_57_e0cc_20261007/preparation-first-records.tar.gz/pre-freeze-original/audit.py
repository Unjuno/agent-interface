"""Saved-data auditor. Imports no runner, backend, Xlib or Tk module."""
import argparse
import hashlib
import json
from pathlib import Path


def audit(package, result):
    checks, failures = [], []

    def check(name, condition):
        checks.append(name)
        if not condition:
            failures.append(name)

    def read(path):
        return json.loads(path.read_text())

    try:
        protocol = read(package / 'protocol.json')
        lock = read(package / 'source-lock.json')
        for item in lock['paths']:
            check('source:'+item['path'], hashlib.sha256((package/'source'/item['path']).read_bytes()).hexdigest()==item['sha256'])
        invocations = read(result/'invocations.json')
        check('exact six ordered invocations', [r['case'] for r in invocations] == [c['id'] for c in protocol['cases']])
        check('six independent drivers', len({r['pid'] for r in invocations}) == 6)
        for invocation in invocations:
            check('driver:'+invocation['case'], invocation['returncode']==0 and invocation['rescued'] is False
                  and 0 < invocation['end_ns']-invocation['start_ns'] < 15_000_000_000)
        environment = read(result/'environment.json')
        limits = environment['limits']
        quota, period = limits['cpu.max'].split()
        check('effective limits', quota!='max' and int(quota)==int(period) and limits['memory.max']=='536870912'
              and limits['memory.swap.max']=='0' and limits['pids.max']=='128' and environment['uid']==1000)
        check('private network', not environment['route'].strip().splitlines()[1:] and
              all(link['ifname']=='lo' or ('UP' not in link.get('flags', []) and not link.get('addr_info')) for link in environment['links']))
        for case in protocol['cases']:
            name = case['id']
            row = read(result/name/'record.json')
            check(name+': identity/source declaration', row['case']==case and row['core_accepted'] is True)
            check(name+': no infrastructure error', not row.get('infrastructure_error'))
            check(name+': expected receipt status', row['status']==case['expected_status'])
            check(name+': initial neutral/no autorepeat', row['initial_keymap']==[0]*32 and row['initial_buttons']==0 and row['autorepeat']==0)
            check(name+': independent final neutral', row['final_keymap']==row['post_settle_keymap']==[0]*32 and row['final_buttons']==0 and row['final_held']=={})
            check(name+': verified release', row['execution']['releases'][-1]['verified'] is True)
            effect = read(result/name/'effect.json')
            check(name+': independent application effect', row['app_effect']['text']==effect['text']==case['expected_text'])
            events = row['app_effect']['events']
            chars = ''.join(e['char'] for e in events if e['type']=='2' and e['char'])
            check(name+': observed character sequence', chars==case['expected_text'])
            check(name+': app heartbeat after execution', row['app_effect']['monotonic_ns']>row['execution_end_ns'])
            check(name+': native requests returned', all(r['returned'] is True and r['end_ns']>=r['start_ns'] for r in row['requests']))
            for kind in ['app_exit', 'xvfb_exit']:
                check(name+': '+kind, row[kind]['returncode']==0 and row[kind]['forced_kill'] is False)
            check(name+': display removed', row['display_removed'] is True)
            if name=='held_a_unpaced':
                check(name+': known constraint before text prefix', row['execution']['completed_ops']==[0,1] and row['execution']['failed_op']==2
                      and row['text_boundaries'][0]['request_start']==row['text_boundaries'][0]['request_end'])
            if name=='held_a_paced':
                check(name+': partial text prefix before failure', row['execution']['completed_ops']==[0,1,2,3] and row['execution']['failed_op']==4
                      and row['text_boundaries'][0]['request_end']-row['text_boundaries'][0]['request_start']==2)
            if case['held']=='SHIFT':
                check(name+': prior modifier custody preserved', all(b['held_before']==b['held_after']=={'SHIFT':row['keycodes']['SHIFT']} for b in row['text_boundaries']))
        decision = 'SUPPORT_NATIVE_PREFIX_COUNTEREXAMPLE' if not failures else 'FAIL_OR_HOLD'
    except Exception as exc:
        failures.append(type(exc).__name__+': '+str(exc))
        decision = 'FAIL_OR_HOLD'
    return dict(decision=decision, checks=len(checks), failures=failures, scope='Six first synthetic Tk cases, not general desktop/model/game/task success.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('package', type=Path)
    parser.add_argument('result', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    report = audit(args.package, args.result)
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps(report))
    raise SystemExit(bool(report['failures']))

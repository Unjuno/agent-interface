import hashlib, json, pathlib, zipfile
root=pathlib.Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text())
for name,digest in manifest.items(): assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
arms=['expiry-e01','expiry-e02']
for arm in arms:
    p=root/arm; c=json.loads((p/'conditions.json').read_text()); r=json.loads((p/'output/result.json').read_text())
    assert hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()==c['manifest_sha256']
    assert json.loads((p/'launcher-result.json').read_text())['returncode']==0 and r['status']=='passed' and c['mode']==r['mode']
    assert r['sequence_while_staged']==0 and not r['visible_while_staged'] and r['mint_while_staged']=='rejected'
    assert (r['release_pause_ns']>=r['deadline_ns'])==(r['mode']=='expire')
    assert r['sequence_after']==(0 if r['mode']=='expire' else 1) and r['visible_after']==(r['mode']=='publish')
    assert r['target_result']['value']=='a' and [e['type'] for e in r['target_result']['events'] if e['key']=='a']==['press','release']
    assert r['action']['result']['execution']['releases'][-1]['verified'] and r['input_neutral'] and r['target_exit']==0 and r['server_exit']==0
    events=r['events']; names=[e['name'] for e in events]
    order=['staged','pause_release_requested','stage_resumed','capture_returned','bridge_closed','fresh_action_returned']
    assert [names.index(n) for n in order]==sorted(names.index(n) for n in order)
    assert all(events[i]['ns']<=events[i+1]['ns'] for i in range(len(events)-1))
dest=root.parent/'guarded-motion-deadline-r01/research/integration/wslc_realx_idle_expiry_20261101';dest.mkdir(parents=True,exist_ok=False)
paths=[root/n for n in manifest]+[root/'manifest.json',pathlib.Path(__file__)]
for arm in arms:
    p=root/arm; paths += [p/'conditions.json',p/'launcher-result.json',p/'stdout',p/'stderr']
    paths += [x for x in (p/'output').rglob('*') if x.is_file()]
public={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
with zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in paths:z.write(p,p.relative_to(root).as_posix())
    z.writestr('public-manifest.json',json.dumps(public,indent=2,sort_keys=True)+'\n')
with zipfile.ZipFile(dest/'raw.zip') as z:
    for name,digest in public.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print('validated',len(public),'files; sha256',hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest())

import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parent
files=[p for p in (root/'src').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']+[root/'trial.py',root/'target.py',root/'run.py',root/'prepare.py']
manifest={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
arms=[('expiry-e01','expire'),('expiry-e02','publish')]
for ident,mode in arms:
 p=root/ident;p.mkdir(exist_ok=False);(p/'output').mkdir()
 c={'allocation':'idle-expiry-'+ident+'-20261101','mode':mode,'order':[f'{i}:{m}' for i,m in arms],
    'base_main':'fdd651167b6e8646dc5ad1de2f793af3549a2a63','draft_head':'0675ab810f7ee890d0904b8a402678c81f8dbafb',
    'image':'sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25',
    'manifest_sha256':hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest(),
    'intervention':'real Xvfb capture; pause detached insertion until 1.2 seconds after start; deadline 1 second vs 5 seconds control; inspect visibility and mint, resume, then fresh owner sends a',
    'criteria':'uncommitted sequence absent and mint rejected; expired observation not published vs within-deadline control publishes; fresh guarded action yields target a, release verified and neutral X input',
    'stop':'one try per arm; preserve all failures; stop block on unresolved input or infrastructure failure',
    'limits':'direct bridge concurrency deliberately instrumented beyond serialized contract; pause is synthetic; no held old input, hard deadline or MAP01 claim'}
 (p/'conditions.json').write_text(json.dumps(c,indent=2)+'\n')
print('two arms frozen')

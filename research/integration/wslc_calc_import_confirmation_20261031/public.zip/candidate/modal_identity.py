"""Exact reviewed private-fixture modal pixels, no authority or input."""
BOXES=((575,132,705,153),(411,478,491,515),(408,285,719,432),(791,628,875,655))
def matches(reference,current):
    if reference.mode!='RGB' or current.mode!='RGB' or reference.size!=(1280,800) or current.size!=reference.size:
        return False
    return all(reference.crop(box).tobytes()==current.crop(box).tobytes() for box in BOXES)

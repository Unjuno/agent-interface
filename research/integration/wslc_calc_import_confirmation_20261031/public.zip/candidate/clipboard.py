import json,time
from pathlib import Path
from Xlib import X,Xatom,display,protocol

d=display.Display();root=d.screen().root;w=root.create_window(0,0,1,1,0,d.screen().root_depth,X.InputOutput,X.CopyFromParent)
selection=d.intern_atom('CLIPBOARD');targets=d.intern_atom('TARGETS');utf8=d.intern_atom('UTF8_STRING');text=d.intern_atom('TEXT');plain=d.intern_atom('text/plain;charset=utf-8');w.set_selection_owner(selection,X.CurrentTime);d.sync()
if d.get_selection_owner(selection).id!=w.id:raise RuntimeError('clipboard ownership unavailable')
Path('/out/clipboard-ready.json').write_text(json.dumps({'owned':True,'window_id':w.id}))
while True:
 event=d.next_event()
 if event.type==X.SelectionClear:break
 if event.type!=X.SelectionRequest:continue
 prop=event.property or event.target;target=event.target;accepted=False
 if target==targets:
  event.requestor.change_property(prop,Xatom.ATOM,32,[targets,utf8,text,plain,Xatom.STRING]);accepted=True
 elif target in (utf8,text,plain,Xatom.STRING):
  event.requestor.change_property(prop,utf8 if target==text else target,8,b'329\n517\n');accepted=True
 reply=protocol.event.SelectionNotify(time=event.time,requestor=event.requestor,selection=event.selection,target=target,property=prop if accepted else X.NONE)
 event.requestor.send_event(reply,propagate=False);d.flush()

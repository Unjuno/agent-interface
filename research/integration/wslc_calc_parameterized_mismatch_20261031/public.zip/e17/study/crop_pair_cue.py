"""Experimental adapter from frozen expected values to reusable cue."""
import json
from pathlib import Path
from calc_ocr_pair_cue_v1 import classify_pair

def classify(a1_tsv, a2_tsv):
    expected = json.loads(Path('/in/expected-values.json').read_text())
    return classify_pair(a1_tsv, a2_tsv, expected=tuple(expected))

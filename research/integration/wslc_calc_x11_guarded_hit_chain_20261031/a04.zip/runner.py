import os,time,json,subprocess,signal,shutil,hashlib
from pathlib import Path
from Xlib import X,display
from runtime.cli_v1.mcp_guarded import GuardedSessionOwner
from composition import CalcComposition
from pair_saved_oracle import score_saved
from crop_pixel_cue import create_reference
from PIL import Image
out=Path('/out');env=dict(os.environ,DISPLAY=':153',HOME='/tmp',SAL_USE_VCLPLUGIN='gen');actors=[];handles=[];b=None;d=None;owner=None
try:
 def spawn(name,args):
  f=(out/(name+'.log')).open('wb');handles.append(f);p=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);actors.append(p);return p
 x=spawn('xvfb',['Xvfb',':153','-screen','0','1280x800x24','-nolisten','tcp','-ac'])
 for _ in range(100):
  try:d=display.Display(':153');break
  except Exception:time.sleep(.05)
 if d is None:raise RuntimeError('Xvfb unavailable')
 if hashlib.sha256(Path('/in/blank.fods').read_bytes()).hexdigest()!='462beebbcb020ccf49af3cc49520f789a816cc3fb97597cefbd6940ffc26aeb1':raise RuntimeError('blank fixture digest mismatch')
 shutil.copyfile('/in/blank.fods','/tmp/blank.fods');spawn('openbox',['openbox','--sm-disable']);lo=spawn('calc',['libreoffice','-env:UserInstallation=file:///tmp/observe-profile','--calc','--nologo','--norestore','--nofirststartwizard','/tmp/blank.fods'])
 def walk(w,depth=0):
  if depth>6:return []
  out=[]
  for child in w.query_tree().children:
   try:
    title=child.get_wm_name();title=title.decode(errors='replace') if isinstance(title,bytes) else str(title or '')
    out.append((child.id,title,child.get_attributes().map_state));out+=walk(child,depth+1)
   except Exception:pass
  return out
 end=time.monotonic()+20;found=[]
 while time.monotonic()<end:
  found=[r for r in walk(d.screen().root) if 'blank.fods' in r[1].lower() and 'calc' in r[1].lower() and r[2]==X.IsViewable]
  if len(found)==1:break
  if len(found)>1:raise RuntimeError('ambiguous target')
  if lo.poll() is not None:raise RuntimeError('calc exited')
  time.sleep(.05)
 if len(found)!=1:
  (out/'window-inventory.json').write_text(json.dumps(walk(d.screen().root),indent=2)+'\n')
  raise RuntimeError('target unavailable')
 time.sleep(1);owner=GuardedSessionOwner({'app':found[0][0]},out/'owner',':153');owner.get();b=owner.bridge;obs=b.observe();rgb=b.history[obs['sequence']][1]
 if hashlib.sha256(rgb.crop((0,97,42,119)).tobytes()).hexdigest()!='2e86f3a0f6d87ee4fb4e5ffeb7cfd159d715cb5f6f8177b0ede83784d49088cf':raise RuntimeError('initial A1 name-box differs from reviewed source')
 # Fixed point from earlier model-assisted attempt; this run has no model call.
 field=[81,151]
 alias=b.mint_reference('click_cell',obs['sequence'],field,region_size=(30,20))
 guard_events=[];injected=[]
 def hit_check(stage,native,image):
  if True and stage=='before_press' and not injected:
   overlay=d.screen().root.create_window(field[0]-4,field[1]-4,8,8,0,0,X.InputOnly,X.CopyFromParent,override_redirect=1,event_mask=X.ButtonPressMask|X.ButtonReleaseMask);overlay.map();overlay.configure(stack_mode=X.Above);d.sync();injected.append(overlay.id)
  root=d.screen().root;window=root;chain=[root.id]
  for _ in range(64):
   child=window.translate_coords(root,field[0],field[1]).child
   if child in (None,X.NONE,0):break
   child_id=child.id if hasattr(child,'id') else int(child)
   if child_id in chain:return False
   chain.append(child_id);window=d.create_resource_object('window',child_id)
  else:return False
  ok=found[0][0] in chain;guard_events.append({'stage':stage,'sequence':native['sequence'],'chain':chain,'eligible':ok,'injected':bool(injected)})
  (out/'hit-guard-events.json').write_text(json.dumps(guard_events,indent=2)+'\n')
  return True  # deliberate positive control: observe delivery to test overlay
 with b.input_guard('click_cell',alias['offset'],tail=[],verify=hit_check,interaction='click'):
  click=b.click('click_cell',alias['offset'],tail=[],expires_at_ns=time.monotonic_ns()+2_000_000_000)
 d.sync();received=[]
 while d.pending_events():
  event=d.next_event();received.append({'type':event.type,'window':getattr(getattr(event,'window',None),'id',None),'detail':getattr(event,'detail',None)})
 (out/'overlay-events.json').write_text(json.dumps(received,indent=2)+'\n')
 (out/'click-result.json').write_text(json.dumps(click,indent=2)+'\n')
 raise RuntimeError('positive delivery control finished; no further action')
 releases=click.get('execution',{}).get('releases',[])
 if click.get('status')!='completed' or not releases or not all(r.get('verified') is True and r.get('keys_down')==[] and r.get('buttons_down')==[] for r in releases):raise RuntimeError('click failed or release unverified')
 obs=b.observe();rgb=b.history[obs['sequence']][1]
 if hashlib.sha256(rgb.crop((0,97,42,119)).tobytes()).hexdigest()!='2e86f3a0f6d87ee4fb4e5ffeb7cfd159d715cb5f6f8177b0ede83784d49088cf':raise RuntimeError('A1 selection not independently verified after click')
 response={'fixed_point':field,'model_called':False}
 entry=b.mint_reference('entry',obs['sequence'],[440,28],region_size=(30,14));save=b.mint_reference('sheet',obs['sequence'],[440,28],region_size=(30,14))
 binding=obs['pointer_binding'];approved={'geometry_reviewed':True,'image_size':[1280,800],'scope':b.scope,'revision':b.binding_revision,'binding':binding,'titles':[found[0][1]],'pixel_reference_reviewed':True}
 refs={'entry_alias':'entry','entry_offset':entry['offset'],'save_alias':'sheet','save_offset':save['offset'],'cell_regions':[[37,143,126,159],[37,159,126,176]],'context_region':[350,20,370,35]}
 reference=create_reference(Image.open('/in/reference.png').convert('RGB'))
 comp=CalcComposition(owner,out/'method',refs=refs,approved=approved,reviewed_native=obs,reviewed_rgb=rgb,pixel_reference=reference)
 result={'window':found[0],'initial_observation':obs,'model_response':response,'method':comp.run('compiled')}
 close=owner.close();owner=None;b=None;result['close']=close
 keys=d.query_keymap();result['keys_down']=[i for i in range(256) if keys[i//8]&(1<<(i%8))];result['buttons']=int(d.screen().root.query_pointer().mask)&(X.Button1Mask|X.Button2Mask|X.Button3Mask)
 doc=Path('/tmp/blank.fods');blob=doc.read_bytes();(out/'saved.fods').write_bytes(blob);result['saved_score']=score_saved(blob)
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
finally:
 if owner is not None:
  close_record=owner.close();keys=d.query_keymap() if d is not None else []
  (out/'final-neutral.json').write_text(json.dumps({'close':close_record,'keys_down':[i for i in range(256) if keys[i//8]&(1<<(i%8))] if keys else None,'buttons':int(d.screen().root.query_pointer().mask)&(X.Button1Mask|X.Button2Mask|X.Button3Mask) if d is not None else None},indent=2)+'\n')
 elif b is not None:b.close()
 if d is not None:d.close()
 for p in reversed(actors):
  if p.poll() is None:
   try:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=3)
   except ProcessLookupError:pass
 for f in handles:f.close()

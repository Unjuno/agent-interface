import hashlib,json,pathlib,zipfile
root=pathlib.Path(__file__).resolve().parent;manifest=json.loads((root/'manifest.json').read_text())
for n,d in manifest.items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==d
arms=['repeat-k01','repeat-k02']
for arm in arms:
    p=root/arm;c=json.loads((p/'conditions.json').read_text());r=json.loads((p/'output/result.json').read_text())
    assert c['manifest_sha256']==hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()
    assert r['status']=='passed' and r['repeat']==c['mode'] and json.loads((p/'launcher-result.json').read_text())['returncode']==0
    assert r['repeat_global']==(1 if r['repeat']=='on' else 0) and r['repeat_key_enabled']
    assert r['old_key_down_before_stop'] and r['old_cancel']['cleanup_status']=='UNKNOWN' and not r['old_cancel']['replay_allowed'] and not r['old_cancel']['release_confirmed']
    assert r['old_cancel']['owner_input_obligations']['keys'].get('a') and not r['old_thread_alive']
    ev={e['name']:e['ns'] for e in r['events']};assert ev['old_effect_and_hold']<ev['old_server_stopped']<ev['old_cancel_returned']<ev['old_server_resumed']<ev['repeat_window_end']<ev['fixture_release_old_hold']
    presses=[e for e in r['old_events_before_fixture_release']['events'] if e['type']=='press' and e['key']=='a']
    assert len(presses)==(14 if r['repeat']=='on' else 1) and presses[0]['host_ns']<ev['old_server_stopped']
    assert all(ev['old_server_resumed']<=e['host_ns']<=ev['repeat_window_end'] for e in presses[1:])
    assert r['fresh_target']['value']=='a' and r['action']['result']['execution']['releases'][-1]['verified'] and r['fresh_neutral_after_task']
    assert r['server_exitcodes']==[-9] and r['target_exitcodes']==[0,0]
dest=root.parent/'guarded-motion-deadline-r01/research/integration/wslc_guarded_autorepeat_control_20261101';dest.mkdir(parents=True,exist_ok=False)
paths=[root/n for n in manifest]+[root/'manifest.json',pathlib.Path(__file__)]
for arm in arms:
    p=root/arm;paths += [p/'conditions.json',p/'launcher-result.json',p/'stdout',p/'stderr']+[x for x in (p/'output').rglob('*') if x.is_file() and x.name!='authority' and 'display-owner-' not in '/'.join(x.parts)]
public={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
with zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in paths:z.write(p,p.relative_to(root).as_posix())
    z.writestr('public-manifest.json',json.dumps(public,indent=2,sort_keys=True)+'\n')
with zipfile.ZipFile(dest/'raw.zip') as z:
    for n,d in public.items():assert hashlib.sha256(z.read(n)).hexdigest()==d
print('validated',len(public),'files; sha256',hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest())

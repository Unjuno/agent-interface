import json,os,time
from pathlib import Path
from Xlib import X,display
out=Path('/out');d=display.Display(':163');root=d.screen().root;w=root.create_window(50,50,200,200,0,d.screen().root_depth,X.InputOutput,X.CopyFromParent,override_redirect=1,background_pixel=d.screen().white_pixel,event_mask=X.ButtonPressMask|X.ButtonReleaseMask);w.map();d.sync();(out/'target-ready.json').write_text(json.dumps({'pid':os.getpid(),'window':w.id,'ready_ns':time.monotonic_ns()}));events=[];deadline=time.monotonic()+10
while time.monotonic()<deadline:
 while d.pending_events():
  e=d.next_event()
  if e.type in (X.ButtonPress,X.ButtonRelease):
   events.append({'type':e.type,'window':getattr(e.window,'id',None),'detail':e.detail,'handled_ns':time.monotonic_ns()})
   (out/'target-events.json').write_text(json.dumps(events,indent=2)+'\n')
   if e.type==X.ButtonRelease:
    (out/'target-effect.json').write_text(json.dumps({'effect':'button_pair_handled','effect_ns':time.monotonic_ns(),'events':len(events)},indent=2)+'\n');d.close();raise SystemExit(0)
 time.sleep(.01)
raise TimeoutError('target did not receive release')

import os,time,json,signal,subprocess,sys
from pathlib import Path
from Xlib import X,display
from Xlib.ext import xtest
from runtime.guarded_x11_v1.cancel_supervisor import PrestartedCancellationSupervisor
from worker_module import send_then_stall

def main():
 out=Path('/out');env=dict(os.environ,DISPLAY=':163');x=None;target=None;sup=None;d=None;stopped=False
 try:
  x=subprocess.Popen(['Xvfb',':163','-screen','0','640x480x24','-nolisten','tcp','-ac'],env=env,stdout=subprocess.DEVNULL,stderr=(out/'xvfb.log').open('wb'),start_new_session=True)
  for _ in range(100):
   try:d=display.Display(':163');break
   except Exception:time.sleep(.05)
  if d is None:raise RuntimeError('X server unavailable')
  target=subprocess.Popen([sys.executable,'-B','/in/target.py'],env=env,stdout=subprocess.DEVNULL,stderr=(out/'target.log').open('wb'),start_new_session=True);end=time.monotonic()+5
  while not (out/'target-ready.json').exists():
   if target.poll() is not None or time.monotonic()>=end:raise RuntimeError('target not ready')
   time.sleep(.01)
  ready=json.loads((out/'target-ready.json').read_text());sup=PrestartedCancellationSupervisor(send_then_stall,expected_session_id='queued-app-fixture',startup_timeout_s=5)
  (out/'supervisor-ready.json').write_text(json.dumps({'pid':sup.pid,'target_pid':target.pid,'target_window':ready['window']}))
  if os.environ['MODE']=='stopped':
   os.kill(target.pid,signal.SIGSTOP);stopped=True;end=time.monotonic()+1
   while time.monotonic()<end:
    if '\nState:\tT' in Path('/proc/'+str(target.pid)+'/status').read_text():break
    time.sleep(.005)
   else:raise RuntimeError('target not observed stopped')
   (out/'target-stopped.json').write_text(json.dumps({'stopped_ns':time.monotonic_ns(),'state':'T'}))
  started=time.monotonic_ns();deadline=started+600_000_000;result=sup.run({'operation_id':'pair-1','session_id':'queued-app-fixture','target':ready['window']},deadline_monotonic_ns=deadline);returned=time.monotonic_ns();(out/'owner-outcome.json').write_text(json.dumps(result,indent=2)+'\n');(out/'timing.json').write_text(json.dumps({'start_ns':started,'deadline_ns':deadline,'returned_ns':returned,'effect_existed_at_return':(out/'target-effect.json').exists()},indent=2)+'\n')
  if stopped:os.kill(target.pid,signal.SIGCONT);stopped=False;(out/'target-resumed.json').write_text(json.dumps({'resumed_ns':time.monotonic_ns()}))
  target.wait(timeout=4);end=time.monotonic()+4
  while not (out/'pair-synced.json').exists():
   if time.monotonic()>=end:raise RuntimeError('worker did not record pair')
   time.sleep(.01)
  sent=json.loads((out/'pair-synced.json').read_text());check=sent['scheduled_late_ns']+300_000_000
  while time.monotonic_ns()<check:time.sleep(min(.05,(check-time.monotonic_ns())/1e9))
  mask=int(d.screen().root.query_pointer().mask)&(X.Button1Mask|X.Button2Mask|X.Button3Mask);(out/'result.json').write_text(json.dumps({'target_exit':target.returncode,'buttons':mask,'observed_ns':time.monotonic_ns(),'scheduled_late_ns':sent['scheduled_late_ns'],'late_artifact_present':(out/'late.json').exists()},indent=2)+'\n')
 finally:
  if stopped and target is not None:os.kill(target.pid,signal.SIGCONT)
  if sup is not None:sup.close()
  if d is not None:
   try:
    if int(d.screen().root.query_pointer().mask)&X.Button1Mask:xtest.fake_input(d,X.ButtonRelease,1);d.sync();(out/'fallback.txt').write_text('release sent')
   finally:d.close()
  for p in (target,x):
   if p is not None and p.poll() is None:
    try:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=3)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=3)

if __name__=='__main__':main()

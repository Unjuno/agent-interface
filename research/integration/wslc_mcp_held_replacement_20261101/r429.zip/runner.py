import asyncio,json,os,select,signal,subprocess,sys,tempfile,time,traceback
from pathlib import Path
from Xlib import X,XK,display
from Xlib.ext import xtest
from runtime.cli_v1.mcp_server import create_server
from runtime.cli_v1.test_mcp_xvfb_blocked_release_integration import _metadata
from runtime.guarded_x11_v1.private_display_owner import PrivateDisplayOwner
OUT=Path('/out')
async def call(s,n,a): return _metadata(await asyncio.wait_for(s.call_tool(n,a),8))
async def ready(path,proc):
    end=time.monotonic()+5
    while time.monotonic()<end:
        if path.exists(): return json.loads(path.read_text())
        if proc.poll() is not None: raise RuntimeError('target exited before ready')
        await asyncio.sleep(.02)
    raise RuntimeError('target startup timeout')
async def main():
    r={'status':'ERROR','cleanup':[]}; owner=server=replacement=None; targets=[]; d=None
    try:
      with tempfile.TemporaryDirectory(prefix='r417-') as tmp:
        owner=PrivateDisplayOwner(Path(tmp)/'display'); sess=owner.start(timeout_s=5)
        os.environ['XAUTHORITY']=str(sess.authority)
        def target(name):
            path=OUT/name; path.mkdir(); env=dict(os.environ,DISPLAY=sess.display,TARGET_OUT=str(path))
            p=subprocess.Popen([sys.executable,'-B','/fixture/target.py'],env=env,stdout=subprocess.DEVNULL,stderr=(OUT/(name+'-stderr.txt')).open('w'))
            targets.append((name,p,os.pidfd_open(p.pid))); return path,p
        oldpath,old=target('old'); info=await ready(oldpath/'target-ready.json',old)
        d=display.Display(sess.display); d.create_resource_object('window',info['xid']).set_input_focus(X.RevertToParent,X.CurrentTime); d.sync(); d.close(); d=None
        server=create_server({'app':info['xid']},OUT/'mcp',display_name=sess.display,session_mode='guarded-x11',guarded_process_identity=True,guarded_query_worker=True,guarded_owned_process=True,guarded_prestarted_cancel_supervisor=True,_guarded_xauthority=str(sess.authority),_guarded_display_owner=owner)
        r['observe']=await call(server,'interface_guarded_observe',{})
        if r['observe'].get('status')!='observed': raise RuntimeError('old observation failed')
        r['mint']=await call(server,'interface_guarded_mint',{'alias':'field','source_sequence':r['observe']['source']['sequence'],'point':[30,30],'region_size':[12,12]})
        if r['mint'].get('status')!='minted': raise RuntimeError('old alias mint failed')
        r['pending']=await call(server,'interface_guarded_input',{'alias':'field','offset':r['mint']['offset'],'interaction':'keyboard','observe_after':False,'tail':[{'op':'key_state','key':'a','down':True},{'op':'wait_update','timeout_ms':5000},{'op':'key_state','key':'a','down':False}],'wait_for_result_ms':0})
        if r['pending'].get('status')!='pending': raise RuntimeError('input not pending')
        d=display.Display(sess.display); code=d.keysym_to_keycode(XK.string_to_keysym('a'))
        end=time.monotonic()+3; observed=False
        while time.monotonic()<end:
            ep=oldpath/'target-events.json'; events=json.loads(ep.read_text()) if ep.exists() else []
            bits=d.query_keymap(); down=bool(bits[code//8] & (1 << (code%8)))
            if down and any(e['type']=='press' and e['key']=='a' for e in events): observed=True; break
            await asyncio.sleep(.01)
        r['old_press_observed']=observed; r['old_events_before_retire']=events
        d.close(); d=None
        if not observed: r['status']='INCONCLUSIVE'; raise RuntimeError('old hold not observed')
        r['old_retire']=owner.retire(timeout_s=3)
        if r['old_retire'].get('status')!='retired': raise RuntimeError('old server not retired')
        rd,wr=os.pipe()
        try:
            replacement=subprocess.Popen(['Xvfb',sess.display,'-displayfd',str(wr),'-screen','0','640x480x24','-nolisten','tcp','-auth',str(sess.authority)],pass_fds=(wr,),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            os.close(wr); wr=None
            if not select.select([rd],[],[],5)[0]: raise RuntimeError('replacement timeout')
            number=os.read(rd,32).decode().strip()
        finally:
            os.close(rd)
            if wr is not None: os.close(wr)
        if number!=sess.display[1:] or replacement.poll() is not None: raise RuntimeError('replacement not live')
        newpath,new=target('new'); fresh=await ready(newpath/'target-ready.json',new)
        r['old_xid']=info['xid'];r['new_xid']=fresh['xid'];r['same_xid']=info['xid']==fresh['xid']
        d=display.Display(sess.display); w=d.create_resource_object('window',fresh['xid']); w.set_input_focus(X.RevertToParent,X.CurrentTime); d.sync(); r['fresh_focus']=getattr(d.get_input_focus().focus,'id',None)==fresh['xid']; d.close(); d=None
        if not r['same_xid'] or not r['fresh_focus']: r['status']='INCONCLUSIVE'; raise RuntimeError('pre-input target control failed')
        repeat_off=subprocess.run(['xset','-r'],env=dict(os.environ,DISPLAY=sess.display),capture_output=True,text=True,timeout=3)
        repeat_query=subprocess.run(['xset','q'],env=dict(os.environ,DISPLAY=sess.display),capture_output=True,text=True,timeout=3)
        r['repeat_control']={'set_exit':repeat_off.returncode,'query_exit':repeat_query.returncode,'query':repeat_query.stdout,'stderr':repeat_off.stderr+repeat_query.stderr}
        if repeat_off.returncode or repeat_query.returncode or 'auto repeat:  off' not in repeat_query.stdout: r['status']='INCONCLUSIVE'; raise RuntimeError('auto-repeat off not confirmed')
        d=display.Display(sess.display); code=d.keysym_to_keycode(XK.string_to_keysym('a'))
        xtest.fake_input(d,X.KeyPress,code); d.sync()
        def key_down():
            bits=d.query_keymap(); return bool(bits[code//8] & (1 << (code%8)))
        r['fresh_down_before_cancel']=key_down()
        if not r['fresh_down_before_cancel']: r['status']='INCONCLUSIVE'; raise RuntimeError('fresh hold not observed')
        if os.environ['TRIAL_CANCEL']=='1':
            try: r['cancel']=await call(server,'interface_guarded_cancel',{'call_id':r['pending']['call_id']})
            except BaseException as e: r['cancel_error']=type(e).__name__+': '+str(e)
        else: r['cancel']={'status':'not_requested_control'}
        await asyncio.sleep(2); r['fresh_down_after_cancel']=key_down()
        ep=newpath/'target-events.json'; r['fresh_events_before_fixture_release']=json.loads(ep.read_text()) if ep.exists() else []
        xtest.fake_input(d,X.KeyRelease,code); d.sync(); r['fresh_down_after_fixture_release']=key_down()
        await asyncio.sleep(.2); r['fresh_events_after_fixture_release']=json.loads(ep.read_text()) if ep.exists() else []
        r['fresh_state']=json.loads((newpath/'target-state.json').read_text())
        d.close(); d=None
        before=r['fresh_events_before_fixture_release']; after=r['fresh_events_after_fixture_release']
        r['status']='PASS' if (r['fresh_down_after_cancel'] and not r['fresh_down_after_fixture_release'] and any(e['type']=='press' and e['key']=='a' for e in before) and not any(e['type']=='release' and e['key']=='a' for e in before) and any(e['type']=='release' and e['key']=='a' for e in after)) else 'FAIL'
    except BaseException as e:
      if r['status']!='INCONCLUSIVE': r['status']='ERROR'
      r['error']=type(e).__name__+': '+str(e); r['traceback']=traceback.format_exc()
    finally:
      if server:
        try:r['close']=await call(server,'interface_close',{})
        except BaseException as e:r['close_error']=type(e).__name__+': '+str(e)
      if d:
        try:d.close()
        except Exception as e:r['cleanup'].append(['display_client_error',repr(e)])
      for name,p,fd in reversed(targets):
        try:
          if p.poll() is None: signal.pidfd_send_signal(fd,signal.SIGKILL)
          p.wait(timeout=3);r['cleanup'].append([name,p.returncode])
        except Exception as e:r['cleanup'].append([name+'_error',repr(e)])
        finally:os.close(fd)
      if replacement:
        try:
          if replacement.poll() is None: replacement.terminate()
          replacement.wait(timeout=3);r['cleanup'].append(['replacement',replacement.returncode])
        except Exception as e:r['cleanup'].append(['replacement_error',repr(e)])
      if owner:
        try:r['cleanup'].append(['old_display',owner.close(timeout_s=3)])
        except Exception as e:r['cleanup'].append(['old_display_error',repr(e)])
      if any('error' in x[0] for x in r['cleanup']):r['status']='ERROR'
      (OUT/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'error':r.get('error')}),flush=True)
    return 0 if r['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(asyncio.run(main()))

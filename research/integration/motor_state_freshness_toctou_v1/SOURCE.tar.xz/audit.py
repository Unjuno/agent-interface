import argparse,json
from pathlib import Path

MAX_AGE_NS=250_000_000
EXPECTED_SCENARIOS={'stable','change_within_250ms','change_after_250ms'}
EXPECTED_POLICIES={'snapshot_only','age_guard','jit_reobserve'}

def evaluate(rows):
 errors=[]; ids=set(); counts={
  'stable_correct':0,'snapshot_wrong_surface':0,'age_wrong_surface_within':0,
  'age_stale_refusal':0,'jit_mismatch_refusal':0,'jit_wrong_surface':0
 }
 for r in rows:
  cid=r.get('case_id')
  if cid in ids: errors.append('duplicate:'+str(cid))
  ids.add(cid)
  if r.get('status')!='ok': errors.append('status:'+str(cid)); continue
  if r.get('scenario') not in EXPECTED_SCENARIOS or r.get('policy') not in EXPECTED_POLICIES: errors.append('vocab:'+str(cid)); continue
  if not r.get('held_observed') or not r.get('release_observed') or not r.get('neutral_final'): errors.append('release:'+str(cid))
  if r.get('authority')!='none': errors.append('authority:'+str(cid))
  age=r.get('decision_age_ns');
  if type(age) is not int or age<0: errors.append('age:'+str(cid)); continue
  s,p,d=r['scenario'],r['policy'],r.get('decision'); app=r.get('app_effect',{}).get('string',''); helper=r.get('helper_effect','')
  if s=='stable':
   if age>=MAX_AGE_NS: errors.append('stable_age:'+cid)
   if d!='ACT' or app!='7' or helper!='' or not r.get('task_input_dispatched'): errors.append('stable:'+cid)
   else: counts['stable_correct']+=1
  elif s=='change_within_250ms':
   if age>=MAX_AGE_NS: errors.append('within_age:'+cid)
   if p=='snapshot_only':
    if d!='ACT' or app!='' or helper!='7' or not r.get('task_input_dispatched'): errors.append('within_snapshot:'+cid)
    else: counts['snapshot_wrong_surface']+=1
   elif p=='age_guard':
    if d!='ACT' or app!='' or helper!='7' or not r.get('task_input_dispatched'): errors.append('within_age_guard:'+cid)
    else: counts['age_wrong_surface_within']+=1
   else:
    if d!='REFUSE_MISMATCH' or r.get('task_input_dispatched') or app!='' or helper!='': errors.append('within_jit:'+cid)
    else: counts['jit_mismatch_refusal']+=1
  else:
   if age<=MAX_AGE_NS: errors.append('after_age:'+cid)
   if p=='snapshot_only':
    if d!='ACT' or app!='' or helper!='7' or not r.get('task_input_dispatched'): errors.append('after_snapshot:'+cid)
    else: counts['snapshot_wrong_surface']+=1
   elif p=='age_guard':
    if d!='REFUSE_STALE' or r.get('task_input_dispatched') or app!='' or helper!='': errors.append('after_age_guard:'+cid)
    else: counts['age_stale_refusal']+=1
   else:
    if d!='REFUSE_MISMATCH' or r.get('task_input_dispatched') or app!='' or helper!='': errors.append('after_jit:'+cid)
    else: counts['jit_mismatch_refusal']+=1
  if p=='jit_reobserve' and helper=='7': counts['jit_wrong_surface']+=1
 exp={'stable_correct':6,'snapshot_wrong_surface':4,'age_wrong_surface_within':2,'age_stale_refusal':2,'jit_mismatch_refusal':4,'jit_wrong_surface':0}
 if len(rows)!=18: errors.append('row_count:'+str(len(rows)))
 if len(ids)!=18: errors.append('id_count:'+str(len(ids)))
 if counts!=exp: errors.append('counts:'+json.dumps(counts,sort_keys=True))
 return {'rows':len(rows),'counts':counts,'errors':errors,'decision':'PASS_MOTOR_STATE_FRESHNESS_TOCTOU_SCOPED' if not errors else 'FAIL_OR_HOLD'}

def load(dirs):
 rows=[]
 for d in dirs:
  x=json.loads((Path(d)/'RAW.json').read_text())
  rows.extend(x['rows'])
 return rows

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('dirs',nargs='+'); a=ap.parse_args()
 out=evaluate(load(a.dirs)); print(json.dumps(out,sort_keys=True)); return 0 if not out['errors'] else 2
if __name__=='__main__': raise SystemExit(main())

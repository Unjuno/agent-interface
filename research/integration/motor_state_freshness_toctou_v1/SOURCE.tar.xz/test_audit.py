import copy,json,sys
from pathlib import Path
import audit

def load(paths): return audit.load(paths)
def rejected(rows,mut):
 x=copy.deepcopy(rows); mut(x); return bool(audit.evaluate(x)['errors'])
def main():
 paths=sys.argv[1:]
 rows=load(paths)
 base=audit.evaluate(rows)
 if base['errors']: raise SystemExit('base invalid:'+json.dumps(base))
 controls=[
  ('drop',lambda x:x.pop()),
  ('duplicate',lambda x:x.append(copy.deepcopy(x[0]))),
  ('status',lambda x:x[0].__setitem__('status','error')),
  ('held',lambda x:x[0].__setitem__('held_observed',False)),
  ('age_within',lambda x:next(r for r in x if r['scenario']=='change_within_250ms').__setitem__('decision_age_ns',300_000_000)),
  ('age_after',lambda x:next(r for r in x if r['scenario']=='change_after_250ms').__setitem__('decision_age_ns',20_000_000)),
  ('wrong_effect',lambda x:next(r for r in x if r['policy']=='jit_reobserve' and r['scenario']=='change_within_250ms').__setitem__('helper_effect','7')),
  ('decision',lambda x:next(r for r in x if r['policy']=='age_guard' and r['scenario']=='change_within_250ms').__setitem__('decision','REFUSE_STALE')),
  ('dispatch',lambda x:next(r for r in x if r['policy']=='jit_reobserve' and r['scenario']!='stable').__setitem__('task_input_dispatched',True)),
  ('authority',lambda x:x[0].__setitem__('authority','input')),
  ('scenario',lambda x:x[0].__setitem__('scenario','other')),
  ('app',lambda x:next(r for r in x if r['scenario']=='stable').__setitem__('app_effect',{'string':''}))
 ]
 results=[{'name':n,'rejected':rejected(rows,m)} for n,m in controls]
 out={'base_decision':base['decision'],'controls':results,'rejected':sum(r['rejected'] for r in results),'total':len(results)}
 print(json.dumps(out,sort_keys=True)); return 0 if all(r['rejected'] for r in results) else 2
if __name__=='__main__': raise SystemExit(main())

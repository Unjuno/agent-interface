import argparse,json,os,signal,subprocess,sys,time
from pathlib import Path
from Xlib import X,XK,display
from Xlib.ext import xtest
from openpyxl import Workbook

SCHEMA='agent-interface/motor-state-freshness-v1'
SCENARIOS=('stable','change_within_250ms','change_after_250ms')
POLICIES=('snapshot_only','age_guard','jit_reobserve')
MAX_AGE_NS=250_000_000

def descendants(root):
 out=[]; stack=[root]
 while stack:
  w=stack.pop()
  try: cs=w.query_tree().children
  except Exception: cs=[]
  out.extend(cs); stack.extend(cs)
 return out

def win_name(w):
 try:return str(w.get_wm_name() or '')
 except Exception:return ''

def find_window(d,needles,timeout=8):
 end=time.monotonic()+timeout
 while time.monotonic()<end:
  for w in descendants(d.screen().root):
   n=win_name(w).lower()
   try:c=' '.join(w.get_wm_class() or ()).lower()
   except Exception:c=''
   if any(x in n or x in c for x in needles):
    try:
     if w.get_attributes().map_state==X.IsViewable:return w
    except Exception:pass
  time.sleep(.04)
 raise RuntimeError('WINDOW_NOT_FOUND:'+','.join(needles))

def start_xvfb(n,root):
 xa=root/'empty.Xauthority'; xa.write_bytes(b'')
 env=os.environ.copy(); env['DISPLAY']=f':{n}'; env['XAUTHORITY']=str(xa); os.environ['XAUTHORITY']=str(xa)
 p=subprocess.Popen(['Xvfb',f':{n}','-ac','-screen','0','1280x800x24','-nolisten','tcp'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,start_new_session=True)
 for _ in range(160):
  if p.poll() is not None: raise RuntimeError('XVFB_EXIT')
  try:
   d=display.Display(env['DISPLAY']); d.close(); return p,env
  except Exception: time.sleep(.025)
 raise RuntimeError('XVFB_NOT_READY')

def stop(p):
 if not p:return None
 try: os.killpg(p.pid,signal.SIGTERM); return p.wait(timeout=2)
 except Exception:
  try: os.killpg(p.pid,signal.SIGKILL); return p.wait(timeout=1)
  except Exception:return None

def center(w):
 g=w.get_geometry(); t=w.translate_coords(w.query_tree().root,0,0)
 return int(t.x+max(20,g.width//2)),int(t.y+max(20,g.height//2))

def motion(d,x,y):xtest.fake_input(d,X.MotionNotify,x=x,y=y); d.sync()
def button(d,down):xtest.fake_input(d,X.ButtonPress if down else X.ButtonRelease,1); d.sync()
def click(d,w):
 x,y=center(w); motion(d,x,y); button(d,True); button(d,False); time.sleep(.08)

def keycode(d,name):
 k=d.keysym_to_keycode(XK.string_to_keysym(name))
 if not k: raise RuntimeError('NO_KEY:'+name)
 return k

def key(d,name,mods=()):
 ms=[keycode(d,m) for m in mods]
 for m in ms:xtest.fake_input(d,X.KeyPress,m)
 k=keycode(d,name); xtest.fake_input(d,X.KeyPress,k); xtest.fake_input(d,X.KeyRelease,k)
 for m in reversed(ms):xtest.fake_input(d,X.KeyRelease,m)
 d.sync(); time.sleep(.05)

def focus_id(d):
 f=d.get_input_focus().focus; return int(getattr(f,'id',0) or 0)

def keydown(d,k):
 raw=d.query_keymap(); return bool(raw[k//8]&(1<<(k%8)))

def helper_source():
 return """import tkinter as tk,sys\nfrom pathlib import Path\nout=Path(sys.argv[1]); r=tk.Tk(); r.title('FreshnessHelper'); e=tk.Entry(r,width=30); e.pack(padx=20,pady=20)\ndef dump(ev=None):\n s=out.read_text() if out.exists() else ''\n ch=(getattr(ev,'char','') or getattr(ev,'keysym','')) if ev else ''\n if ch not in ('Return','KP_Enter','Shift_L','Shift_R'): out.write_text(s+ch)\ne.bind('<KeyRelease>',dump)\nr.bind('<KeyRelease>',dump)\nr.after(200,lambda:r.focus_force())\nr.mainloop()\n"""

def uno_read(port,script):
 p=subprocess.run(['/usr/bin/python3',str(script),str(port)],capture_output=True,text=True,timeout=4)
 if p.returncode: raise RuntimeError('UNO_READ:'+p.stderr.strip())
 return json.loads(p.stdout)

def run_case(scenario,policy,rep,display_num,outroot,uno_script):
 cid=f'{scenario}-{policy}-r{rep}'; root=outroot/cid; root.mkdir(parents=True)
 xv=calc=helper=None; controller=observer=scorer=None
 r={'schema':SCHEMA,'case_id':cid,'scenario':scenario,'policy':policy,'rep':rep,'authority':'none','max_age_ns':MAX_AGE_NS}
 try:
  xv,env=start_xvfb(display_num,root)
  book=root/'book.xlsx'; wb=Workbook(); wb.active['A1']=''; wb.save(book)
  profile=(root/'lo-profile').resolve(); profile.mkdir(); port=23000+(display_num%1000)
  calc=subprocess.Popen(['libreoffice',f'--accept=socket,host=127.0.0.1,port={port};urp;StarOffice.ServiceManager',f'-env:UserInstallation=file://{profile}','--calc','--norestore','--nolockcheck','--nofirststartwizard',str(book)],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,start_new_session=True)
  controller=display.Display(env['DISPLAY']); observer=display.Display(env['DISPLAY']); scorer=display.Display(env['DISPLAY'])
  cw=find_window(controller,['libreoffice calc','calc']); click(controller,cw); key(controller,'Home',mods=('Control_L',)); time.sleep(.08)
  commanded=focus_id(scorer); r['commanded_focus']=commanded
  sh=keycode(controller,'Shift_L'); xtest.fake_input(controller,X.KeyPress,sh); controller.sync(); time.sleep(.02); r['held_observed']=keydown(scorer,sh)
  xtest.fake_input(controller,X.KeyRelease,sh); controller.sync(); time.sleep(.02); r['release_observed']=not keydown(scorer,sh)
  helper_file=root/'helper.txt'; hw=None
  if scenario!='stable':
   hp=root/'helper.py'; hp.write_text(helper_source())
   helper=subprocess.Popen([sys.executable,str(hp),str(helper_file)],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,start_new_session=True)
   hw=find_window(controller,['freshnesshelper']); time.sleep(.28); click(controller,cw); time.sleep(.08)
  observed_ns=time.monotonic_ns(); observed_focus=focus_id(observer); r['snapshot_focus']=observed_focus; r['snapshot_ns']=observed_ns
  if scenario!='stable':
   hw.set_input_focus(X.RevertToParent,X.CurrentTime); controller.sync(); time.sleep(.02)
   if scenario=='change_after_250ms': time.sleep(.28)
  else:
   time.sleep(.06)
  decision_ns=time.monotonic_ns(); age_ns=decision_ns-observed_ns; r['decision_age_ns']=age_ns
  if policy=='snapshot_only':
   r['decision']='ACT' if observed_focus==commanded else 'REFUSE_SNAPSHOT_MISMATCH'
  elif policy=='age_guard':
   if observed_focus!=commanded:r['decision']='REFUSE_SNAPSHOT_MISMATCH'
   elif age_ns>MAX_AGE_NS:r['decision']='REFUSE_STALE'
   else:r['decision']='ACT'
  else:
   current=focus_id(observer); r['jit_focus']=current
   if current!=commanded:r['decision']='REFUSE_MISMATCH'
   elif age_ns>MAX_AGE_NS:r['decision']='ACT'  # current observation supersedes old age
   else:r['decision']='ACT'
  r['pre_action_focus']=focus_id(scorer)
  if r['decision']=='ACT': key(controller,'7'); key(controller,'Return'); r['task_input_dispatched']=True
  else:r['task_input_dispatched']=False
  time.sleep(.12); r['post_action_focus']=focus_id(scorer)
  r['app_effect']=uno_read(port,uno_script); r['helper_effect']=helper_file.read_text() if helper_file.exists() else ''
  r['neutral_final']=not keydown(scorer,sh); r['status']='ok'
 except Exception as e:
  r['status']='error'; r['error']=f'{type(e).__name__}: {e}'
 finally:
  for d in (observer,scorer,controller):
   try:
    if d:d.close()
   except Exception:pass
  r['helper_exit']=stop(helper); r['calc_exit']=stop(calc); r['xvfb_exit']=stop(xv)
 return r

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--rep',type=int,required=True); ap.add_argument('--scenario',choices=SCENARIOS,required=True); ap.add_argument('--out',required=True); ap.add_argument('--display-base',type=int,required=True); a=ap.parse_args()
 out=Path(a.out)
 if out.exists(): raise SystemExit('output exists')
 out.mkdir(parents=True); uno=Path(__file__).with_name('uno_read.py')
 rows=[]
 for i,p in enumerate(POLICIES):
  row=run_case(a.scenario,p,a.rep,a.display_base+i,out,uno); rows.append(row)
  (out/'PARTIAL.json').write_text(json.dumps({'schema':SCHEMA,'rep':a.rep,'scenario':a.scenario,'rows':rows},sort_keys=True,indent=2)+'\n')
 raw={'schema':SCHEMA,'rep':a.rep,'scenario':a.scenario,'rows':rows}; (out/'RAW.json').write_text(json.dumps(raw,sort_keys=True,indent=2)+'\n')
 ok=len(rows)==3 and all(x.get('status')=='ok' and x.get('held_observed') and x.get('release_observed') and x.get('neutral_final') for x in rows)
 print(json.dumps({'rows':len(rows),'scenario':a.scenario,'integrity':ok,'statuses':[x.get('status') for x in rows]},sort_keys=True)); return 0 if ok else 2
if __name__=='__main__':raise SystemExit(main())

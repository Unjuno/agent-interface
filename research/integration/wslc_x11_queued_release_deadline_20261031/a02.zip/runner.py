import os,time,json,signal,subprocess,sys
from pathlib import Path
from Xlib import X,display
from Xlib.ext import xtest
from runtime.guarded_x11_v1.cancel_supervisor import PrestartedCancellationSupervisor,x11_cancel_worker
from worker_module import grab_and_stall
from cleanup_worker import queued_release

def main():
 out=Path('/out');env=dict(os.environ,DISPLAY=':163');x=None;d=None;owner_sup=None;cleanup_sup=None
 try:
  x=subprocess.Popen(['Xvfb',':163','-screen','0','640x480x24','-nolisten','tcp','-ac'],env=env,stdout=subprocess.DEVNULL,stderr=(out/'xvfb.log').open('wb'),start_new_session=True)
  for _ in range(100):
   try:d=display.Display(':163');break
   except Exception:time.sleep(.05)
  if d is None:raise RuntimeError('X server unavailable')
  root=d.screen().root;target=root.create_window(50,50,200,200,0,d.screen().root_depth,X.InputOutput,X.CopyFromParent,override_redirect=1,background_pixel=d.screen().white_pixel,event_mask=X.ButtonPressMask|X.ButtonReleaseMask);target.map();d.sync();xtest.fake_input(d,X.MotionNotify,x=100,y=100);d.sync()
  session='grab-supervisor-fixture';cleanup_sup=PrestartedCancellationSupervisor(queued_release,expected_session_id=session,startup_timeout_s=5.0);owner_sup=PrestartedCancellationSupervisor(grab_and_stall,expected_session_id=session,startup_timeout_s=5.0)
  (out/'ready.json').write_text(json.dumps({'owner_supervisor_pid':owner_sup.pid,'cleanup_supervisor_pid':cleanup_sup.pid,'session_id':session,'target':target.id},indent=2)+'\n')
  request={'operation_id':'click-1','session_id':session,'target':target.id};start=time.monotonic_ns();outcome=owner_sup.run(request,deadline_monotonic_ns=start+800_000_000);(out/'owner-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
  if outcome.get('reason')!='transaction_deadline' or outcome.get('worker_retired') is not True:raise RuntimeError('owner not deadline-retired')
  custody=json.loads((out/'custody.json').read_text());down=json.loads((out/'down.json').read_text());mask_before=int(root.query_pointer().mask);(out/'before-cleanup.json').write_text(json.dumps({'button_down':bool(mask_before&X.Button1Mask),'observed_ns':time.monotonic_ns()},indent=2)+'\n')
  if not mask_before&X.Button1Mask:raise RuntimeError('expected held button absent')
  clean_request={'operation_id':'cleanup-1','session_id':session,'x_resource_base':custody['resource_base'],'owner_pid':custody['owner_pid'],'owner_process_retired':True,'owner_process_exitcode':outcome['worker_exitcode'],'display_name':':163','keys':{},'buttons':['left'],'binding_revision':0,'owner_generation':custody['owner_generation']}
  pauser=subprocess.Popen([sys.executable,'-B','/in/pauser.py',str(x.pid)],env=env,stdout=subprocess.DEVNULL,stderr=(out/'pauser.log').open('wb'),start_new_session=True)
  cleanup_start=time.monotonic_ns()
  try:cleanup=cleanup_sup.run(clean_request,deadline_monotonic_ns=cleanup_start+500000000)
  finally:
   try:pauser.wait(timeout=4)
   except subprocess.TimeoutExpired:os.kill(x.pid,signal.SIGCONT);pauser.kill();pauser.wait(timeout=2)
  (out/'cleanup-outcome.json').write_text(json.dumps(cleanup,indent=2)+'\n');(out/'cleanup-timing.json').write_text(json.dumps({'start_ns':cleanup_start,'deadline_ns':cleanup_start+500000000,'returned_ns':time.monotonic_ns(),'pauser_exit':pauser.returncode},indent=2)+'\n')
  mask_after=int(root.query_pointer().mask);check_at=down['scheduled_late_ns']+300_000_000
  while time.monotonic_ns()<check_at:time.sleep(min(.05,(check_at-time.monotonic_ns())/1e9))
  d.sync();events=[]
  while d.pending_events():
   e=d.next_event();events.append({'type':e.type,'window':getattr(getattr(e,'window',None),'id',None),'detail':getattr(e,'detail',None)})
  final=int(root.query_pointer().mask);record={'target':target.id,'button_down_before_cleanup':bool(mask_before&X.Button1Mask),'button_down_after_cleanup':bool(mask_after&X.Button1Mask),'button_down_final':bool(final&X.Button1Mask),'observed_after_scheduled_late_ns':time.monotonic_ns(),'scheduled_late_ns':down['scheduled_late_ns'],'late_artifact_present':(out/'late.json').exists(),'target_events':events};(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
 finally:
  if owner_sup is not None:owner_sup.close()
  if cleanup_sup is not None:cleanup_sup.close()
  if d is not None:
   try:
    if int(d.screen().root.query_pointer().mask)&X.Button1Mask:
     xtest.fake_input(d,X.ButtonRelease,1);d.sync();(out/'fallback-release.json').write_text(json.dumps({'performed':True,'button_down_after':bool(int(d.screen().root.query_pointer().mask)&X.Button1Mask)},indent=2)+'\n')
   finally:d.close()
  if x is not None and x.poll() is None:
   try:os.killpg(x.pid,signal.SIGTERM);x.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(x.pid,signal.SIGKILL);x.wait(timeout=3)

if __name__=='__main__':main()

import json,os,time
from pathlib import Path
from Xlib import X,display
from Xlib.ext import xtest

def queued_release(request):
 out=Path('/out');d=display.Display(':163');ready={'pid':os.getpid(),'ready_ns':time.monotonic_ns()};(out/'cleanup-ready.json').write_text(json.dumps(ready));deadline=time.monotonic()+3
 while not (out/'server-stopped.json').exists():
  if time.monotonic()>=deadline:raise TimeoutError('server stop not observed')
  time.sleep(.005)
 xtest.fake_input(d,X.ButtonRelease,1);d.flush();(out/'release-queued.json').write_text(json.dumps({'pid':os.getpid(),'flushed_ns':time.monotonic_ns()}))
 d.sync();mask=int(d.screen().root.query_pointer().mask);end=time.monotonic_ns();d.close();return {'status':'completed','operation_id':request['operation_id'],'session_id':request['session_id'],'button_down_after':bool(mask&X.Button1Mask),'synced_ns':end}

import json,os,signal,sys,time
from pathlib import Path
out=Path('/out');pid=int(sys.argv[1]);end=time.monotonic()+4
while not (out/'cleanup-ready.json').exists():
 if time.monotonic()>=end:raise TimeoutError('cleanup not ready')
 time.sleep(.005)
paused=False
try:
 os.kill(pid,signal.SIGSTOP);paused=True;end=time.monotonic()+1
 while time.monotonic()<end:
  state=Path('/proc/'+str(pid)+'/status').read_text()
  if '\nState:\tT' in state:break
  time.sleep(.005)
 else:raise RuntimeError('X server not observed stopped')
 (out/'server-stopped.json').write_text(json.dumps({'pid':pid,'stopped_ns':time.monotonic_ns(),'state':'T'}));time.sleep(1.0)
finally:
 if paused:os.kill(pid,signal.SIGCONT);(out/'server-resumed.json').write_text(json.dumps({'pid':pid,'resumed_ns':time.monotonic_ns()}))

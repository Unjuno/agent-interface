import os,sys,time,json,subprocess
from pathlib import Path
name=sys.argv[1];mode={'bb01':'wait','bb02':'attack'}[name];stage=Path('work/map01-short-pulse-20261101').resolve();root=stage/name;src=stage/'snapshot';cli=os.environ['CODEX_APP_RUNTIME_CLI_PATH'];env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONPATH']=str(stage/'adapter')
cmd=['wslc','run','--rm','--name','map01-shortpulse-'+name+'-20261101','--network','none','--cpus','1','--memory','1g','--pull','never','--mount',f'type=bind,source={stage},target=/candidate,readonly','--mount',f'type=bind,source={src},target=/src,readonly','--mount',f'type=bind,source={root / "exchange"},target=/exchange','--mount',f'type=bind,source={root / "output"},target=/out','-w','/tmp','--env','PYTHONPATH=/src','--env','PYTHONDONTWRITEBYTECODE=1','--env','FINAL_MODE='+mode,'--entrypoint','timeout','sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25','--signal=TERM','--kill-after=3s','180s','python3','-B','/candidate/runner.py']
(root/'private-command.json').write_text(json.dumps(cmd,indent=2)+'\n');start=time.monotonic()
with (root/'host.stdout').open('wb') as ho,(root/'host.stderr').open('wb') as he,(root/'container.stdout').open('wb') as co,(root/'container.stderr').open('wb') as ce:
 host=subprocess.Popen([sys.executable,'-B',str(stage/'host.py'),cli,str(root),'full'],env=env,stdout=ho,stderr=he);deadline=time.monotonic()+30
 while not (root/'exchange/ready.json').exists() and host.poll() is None and time.monotonic()<deadline:time.sleep(.05)
 ready=(root/'exchange/ready.json').exists();container=None;rc=None
 if ready:
  container=subprocess.Popen(cmd,stdout=co,stderr=ce)
  try:rc=container.wait(timeout=190)
  except subprocess.TimeoutExpired:rc=None
 if host.poll() is None and (not ready or rc is not None):(root/'exchange/stop.json').write_text('{}')
 try:hc=host.wait(timeout=15)
 except subprocess.TimeoutExpired:hc=None
 result={'host_ready':ready,'container_started':container is not None,'container_exit':rc,'host_exit':hc,'elapsed_seconds':time.monotonic()-start,'host_pid':host.pid,'container_pid':container.pid if container else None,'live_handle_unresolved':hc is None or (container is not None and rc is None)}
 (root/'launcher-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)

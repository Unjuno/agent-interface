import hashlib,json,time,sys,os
from pathlib import Path
from PIL import Image
root=Path(sys.argv[2]).resolve();ex=root/'exchange';sys.path.insert(0,str(root.parent/'adapter'))
import integrated_efficiency_app_server_model_v1 as adapter
arm=sys.argv[3];m=None;result={'id':'pilot-1','ok':False};size=(1280,1024) if arm=='full' else (640,480)
def put(name,data):
 tmp=ex/(name+'.tmp');tmp.write_text(json.dumps(data));os.replace(tmp,ex/(name+'.json'))
def validate(v):
 if type(v) is not dict or set(v)!={'action','target_x','target_y','duration_ms'}:raise ValueError('invalid policy shape')
 if v['action'] not in ('fire','idle') or any(type(v[k]) is not int for k in ('target_x','target_y','duration_ms')):raise ValueError('invalid policy values')
 if not 0<=v['target_x']<size[0] or not 0<=v['target_y']<size[1] or v['duration_ms'] not in (0,500,1000,1500,2000):raise ValueError('policy outside submitted image or duration')
 if (v['action']=='idle')!=(v['duration_ms']==0):raise ValueError('duration/action mismatch')
 return v
prompt='Choose the bounded next policy for this Doom game image. If a hostile character is visible near the center and firing is appropriate, choose fire with its center as target; otherwise idle. Give target coordinates in pixels of the supplied image. Use at most 2000 ms. The policy may run only during the next pending model call, after visual revalidation.'
try:
 if arm not in ('full','crop'):raise ValueError('invalid arm')
 workspace=root/'workspace';workspace.mkdir(exist_ok=False);adapter.CONTRACTS['policy']=(root.parent/'policy-schema.json',root.parent/'policy-instructions.txt',validate)
 m=adapter.PersistentGroundingModel(root/'model-session',workspace,executable=sys.argv[1],contract='policy',model='gpt-6.1-sol',effort='low',path_converter=lambda p:str(Path(p).resolve()));put('ready',{'ready':True})
 for i in (1,2):
  result={'id':f'pilot-{i}','ok':False};deadline=time.monotonic()+100
  while not (ex/f'request-{i}.json').exists():
   if (ex/'stop.json').exists():raise RuntimeError('container stopped before request')
   if time.monotonic()>deadline:raise TimeoutError('request not observed')
   time.sleep(.02)
  request=json.loads((ex/f'request-{i}.json').read_text());image=ex/f'image-{i}.png';digest=hashlib.sha256(image.read_bytes()).hexdigest()
  if request['id']!=result['id'] or request['image_sha256']!=digest:raise ValueError('image mismatch')
  if request['binding_geometry']!=[320,272,640,480]:raise ValueError('unexpected target geometry')
  submitted=image
  if arm=='crop':
   submitted=ex/f'model-image-{i}.png'
   with Image.open(image) as im:
    if im.size!=(1280,1024):raise ValueError('unexpected screenshot size')
    im.convert('RGB').crop((320,272,960,752)).save(submitted)
  submitted_digest=hashlib.sha256(submitted.read_bytes()).hexdigest();put(f'started-{i}',{'started':True});result['attempted']=True
  value=m.call(root/f'model-call-{i}',prompt,submitted,'policy',workspace);raw=value['grounding'];mapped=dict(raw)
  if arm=='crop':mapped['target_x']+=320;mapped['target_y']+=272
  result.update(ok=True,image_sha256=digest,submitted_image_sha256=submitted_digest,submitted_arm=arm,model_grounding=raw,grounding=mapped,usage=value['usage'],call_id=value['call_id'],runner_ns=value['runner_ns']);put(f'done-{i}',result)
except BaseException as e:
 result.update(error=type(e).__name__,detail=str(e)[:500],call_id=getattr(e,'call_id',None),usage=getattr(e,'usage',None));put('host-error',result)
finally:
 if m is not None:
  try:m.close();put('closed',{'closed':True})
  except BaseException as e:put('closed',{'closed':False,'error':repr(e)})
print(json.dumps({'ok':result.get('ok'),'error':result.get('error')}),flush=True)

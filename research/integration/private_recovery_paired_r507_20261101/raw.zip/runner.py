import json,os,signal,subprocess,sys,tempfile,threading,time,traceback
from pathlib import Path
from Xlib import X,XK,display
from Xlib.error import ConnectionClosedError
from runtime.cli_v1.owned_guarded_session import OwnedGuardedSessionOwner
from runtime.guarded_x11_v1.private_display_owner import PrivateDisplayOwner
from runtime.guarded_x11_v1.private_display_recovery import PrivateDisplayRecovery
OUT=Path('/out')
def wait_file(path, process, timeout=5):
    end=time.monotonic()+timeout
    while time.monotonic()<end:
        if path.exists(): return json.loads(path.read_text())
        if process.poll() is not None: raise RuntimeError('target exited before ready')
        time.sleep(.02)
    raise TimeoutError('target readiness')
def down(conn,code):
    bits=conn.query_keymap();return bool(bits[code//8] & (1 << (code%8)))
def main():
    r={'status':'ERROR','cleanup':[]}; displays=[]; targets=[]; guards=[]; observers=[]; old_thread=None
    try:
      with tempfile.TemporaryDirectory(prefix='r503-') as tmp:
        def setup(name):
            owner=PrivateDisplayOwner(Path(tmp)/name);displays.append((name,owner));sess=owner.start(timeout_s=5);r[name+'_display_pid']=owner._process.pid;r[name+'_display_name']=sess.display
            folder=OUT/name;folder.mkdir(); env=dict(os.environ,DISPLAY=sess.display,XAUTHORITY=str(sess.authority),TARGET_OUT=str(folder))
            with (OUT/(name+'-stderr.txt')).open('w') as err:
                proc=subprocess.Popen([sys.executable,'-B','/fixture/target.py'],env=env,stdout=subprocess.DEVNULL,stderr=err)
            targets.append((name,proc,None));fd=os.pidfd_open(proc.pid);targets[-1]=(name,proc,fd);r[name+'_target_pid']=proc.pid;info=wait_file(folder/'target-ready.json',proc)
            prior=os.environ.get('XAUTHORITY');os.environ['XAUTHORITY']=str(sess.authority)
            try: conn=display.Display(sess.display)
            finally:
                if prior is None:os.environ.pop('XAUTHORITY',None)
                else:os.environ['XAUTHORITY']=prior
            observers.append((name,conn));win=conn.create_resource_object('window',info['xid']);win.set_input_focus(X.RevertToParent,X.CurrentTime);conn.sync()
            guard=OwnedGuardedSessionOwner({'app':info['xid']},OUT/(name+'-guard'),sess.display,process_identity=True,query_worker=True,prestarted_cancel_supervisor=True,xauthority=str(sess.authority),_owned_display_owner=owner)
            guards.append((name,guard));guard._ensure_started();return owner,guard,conn,proc,folder,sess
        def invoke(guard,name,op,args):
            path=OUT/name;path.mkdir();return guard.invoke_guarded(op,args,path)
        old,old_guard,old_conn,old_proc,old_path,old_session=setup('old')
        r['old_observe']=invoke(old_guard,'old-observe','guarded_observe',{})
        if r['old_observe'].get('status')!='observed':raise RuntimeError('old observation failed')
        r['old_mint']=invoke(old_guard,'old-mint','guarded_mint',{'alias':'field','source_sequence':r['old_observe']['source']['sequence'],'point':[30,30],'region_size':[12,12]})
        if r['old_mint'].get('status')!='minted':raise RuntimeError('old mint failed')
        reserve_ns=int(os.environ['RETIREMENT_RESERVE_NS']);r['retirement_reserve_ns']=reserve_ns
        recovery=PrivateDisplayRecovery(old,old_guard,retirement_reserve_ns=reserve_ns)
        input_args={'alias':'field','offset':r['old_mint']['offset'],'interaction':'keyboard','observe_after':False,'tail':[{'op':'key_state','key':'a','down':True},{'op':'wait_update','timeout_ms':5000},{'op':'key_state','key':'a','down':False}]}
        def old_action():
            try:r['old_action']=invoke(old_guard,'old-action','guarded_input',input_args)
            except BaseException as e:r['old_action_error']=type(e).__name__+': '+str(e)
        old_thread=threading.Thread(target=old_action);old_thread.start();code=old_conn.keysym_to_keycode(XK.string_to_keysym('a'))
        end=time.monotonic()+3; observed=False
        while time.monotonic()<end:
            event_path=old_path/'target-events.json';events=json.loads(event_path.read_text()) if event_path.exists() else []
            if down(old_conn,code) and any(e['type']=='press' and e['key']=='a' for e in events): observed=True;break
            if not old_thread.is_alive():break
            time.sleep(.01)
        r['old_press_observed']=observed;r['old_events_before_cancel']=events
        if not observed:r['status']='INCONCLUSIVE';raise RuntimeError('old held press not confirmed')
        signal.pidfd_send_signal(old._pidfd,signal.SIGSTOP)
        stop_deadline=time.monotonic()+2; stopped=False; status_text='';state=''
        while time.monotonic()<stop_deadline:
            status_text=Path('/proc',str(old._process.pid),'status').read_text()
            state=next((line for line in status_text.splitlines() if line.startswith('State:')), '')
            if state.split()[1:2] in (['T'],['t']): stopped=True; break
            time.sleep(.01)
        r['old_display_stopped']=stopped;r['old_display_state']=state
        if not stopped:r['status']='INCONCLUSIVE';raise RuntimeError('old display stop not confirmed')
        before=time.monotonic_ns();r['recovery']=recovery.cancel_guarded('old-action',deadline_monotonic_ns=before+7_000_000_000);r['recovery_elapsed_ms']=(time.monotonic_ns()-before)/1e6
        old_thread.join(5);r['old_thread_alive_after_cancel']=old_thread.is_alive()
        if old_thread.is_alive():raise RuntimeError('old call thread did not retire')
        if r['recovery'].get('fresh_display_allowed') is not True or r['recovery_elapsed_ms']>7000:
            r['status']='INCONCLUSIVE';raise RuntimeError('fresh display not authorized by wrapper')
        if r['recovery'].get('display_retirement',{}).get('status')!='retired' or r['recovery'].get('cancellation',{}).get('owner_process_retired') is not True:
            raise RuntimeError('fresh authority lacks matching retirement receipt')
        fresh,fresh_guard,fresh_conn,fresh_proc,fresh_path,fresh_session=setup('fresh')
        r['fresh_initial']=json.loads((fresh_path/'target-state.json').read_text())
        r['fresh_observe']=invoke(fresh_guard,'fresh-observe','guarded_observe',{})
        r['fresh_mint']=invoke(fresh_guard,'fresh-mint','guarded_mint',{'alias':'field','source_sequence':r['fresh_observe']['source']['sequence'],'point':[30,30],'region_size':[12,12]})
        r['fresh_action']=invoke(fresh_guard,'fresh-action','guarded_input',{'alias':'field','offset':r['fresh_mint']['offset'],'interaction':'keyboard','observe_after':False,'tail':[{'op':'key_chord','keys':['a']}]})
        end=time.monotonic()+3;ep=fresh_path/'target-events.json';events=[]
        while time.monotonic()<end:
            events=json.loads(ep.read_text()) if ep.exists() else []
            if any(e['type']=='release' and e['key']=='a' for e in events):break
            time.sleep(.02)
        r['fresh_events']=events;r['fresh_final']=json.loads((fresh_path/'target-state.json').read_text());fresh_code=fresh_conn.keysym_to_keycode(XK.string_to_keysym('a'));r['fresh_key_up']=not down(fresh_conn,fresh_code)
        r['fresh_close']=fresh_guard.close();pairs=[(x['type'],x['key']) for x in events]
        checks={'old_press':observed,'old_display_stopped':r['old_display_stopped'],'within_7s':r['recovery_elapsed_ms']<=7000,'retire_authorized':r['recovery']['fresh_display_allowed'] is True,'replay_receipt_false':r['recovery']['replay_allowed'] is False,'old_release_unknown':r['recovery']['release_confirmed'] is False,'fresh_count':r['fresh_initial']=={'count':0} and r['fresh_final']=={'count':1},'fresh_action':r['fresh_action'].get('status')=='completed','fresh_events':('press','a') in pairs and ('release','a') in pairs,'fresh_key_up':r['fresh_key_up'],'fresh_close_verified':r['fresh_close'].get('verified') is True}
        r['checks']=checks;r['status']='PASS' if all(checks.values()) else 'FAIL'
    except BaseException as e:
      if r['status']!='INCONCLUSIVE':r['status']='ERROR'
      r['error']=type(e).__name__+': '+str(e);r['traceback']=traceback.format_exc()
    finally:
      for name,owner in displays:
        if name=='old':
          try:r['cleanup'].append([name+'-display-first',owner.close(timeout_s=3)])
          except BaseException as e:r['cleanup'].append([name+'-display-first-error',repr(e)])
      for name,guard in reversed(guards):
        try:r['cleanup'].append([name+'-guard',guard.close()])
        except BaseException as e:r['cleanup'].append([name+'-guard-error',repr(e)])
      if old_thread is not None:
        old_thread.join(3);r['old_thread_alive_final']=old_thread.is_alive()
      for name,conn in reversed(observers):
        try:conn.close();r['cleanup'].append([name+'-observer','closed'])
        except ConnectionClosedError:r['cleanup'].append([name+'-observer','server_closed'])
        except BaseException as e:r['cleanup'].append([name+'-observer-error',repr(e)])
      for name,p,fd in reversed(targets):
        try:
            if p.poll() is None:
                if fd is None:p.kill()
                else:signal.pidfd_send_signal(fd,signal.SIGKILL)
            p.wait(timeout=3);r['cleanup'].append([name+'-target',p.returncode])
        except BaseException as e:r['cleanup'].append([name+'-target-error',repr(e)])
        finally:
            if fd is not None:os.close(fd)
      for name,owner in reversed(displays):
        try:r['cleanup'].append([name+'-display',owner.close(timeout_s=3)])
        except BaseException as e:r['cleanup'].append([name+'-display-error',repr(e)])
      entries=dict(r['cleanup'])
      cleanup_checks={'no_errors':not any('error' in item[0] for item in r['cleanup']),
        'old_thread_stopped':not r.get('old_thread_alive_final',True),
        'old_display_retired':entries.get('old-display',{}).get('status')=='retired',
        'old_target_exited':isinstance(entries.get('old-target'),int),
        'old_guard_retired':entries.get('old-guard',{}).get('owner_process_retired') is True}
      if any(name=='fresh' for name,_ in displays):
        cleanup_checks.update({'fresh_display_retired':entries.get('fresh-display',{}).get('status')=='retired',
          'fresh_target_exited':isinstance(entries.get('fresh-target'),int),
          'fresh_guard_verified':entries.get('fresh-guard',{}).get('verified') is True})
      r['cleanup_checks']=cleanup_checks
      if not all(cleanup_checks.values()):r['status']='ERROR'
      (OUT/'result.json').write_text(json.dumps(r,indent=2,default=str)+'\n');print(json.dumps({'status':r['status'],'error':r.get('error')}),flush=True)
    return 0 if r['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())

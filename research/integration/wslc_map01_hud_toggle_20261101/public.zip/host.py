import json,time,sys,os,hashlib
from pathlib import Path
root=Path(sys.argv[2]);ex=root/'exchange'
def put(n,x):
 p=ex/(n+'.tmp');p.write_text(json.dumps(x));os.replace(p,ex/(n+'.json'))
put('ready',{'ready':True,'fixture':True})
try:
 for i in (1,2):
  end=time.monotonic()+90
  while not (ex/f'request-{i}.json').exists():
   if (ex/'stop.json').exists() or time.monotonic()>end:raise TimeoutError('request')
   time.sleep(.01)
  req=json.loads((ex/f'request-{i}.json').read_text());image=(ex/f'image-{i}.png').read_bytes();digest=hashlib.sha256(image).hexdigest();assert req['image_sha256']==digest
  put(f'started-{i}',{'started':True,'fixture':True});time.sleep(2.0 if i==2 else .15)
  put(f'done-{i}',{'id':req['id'],'ok':True,'image_sha256':digest,'grounding':{'action':'fire','target_x':636,'target_y':526,'duration_ms':500},'fixture':True})
finally:put('closed',{'closed':True,'fixture':True})

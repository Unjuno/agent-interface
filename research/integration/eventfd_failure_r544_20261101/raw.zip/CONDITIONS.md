# Eventfd notification failure under gated MCP send: r544

Before the run, execute three fixed-order cases once each: known parent and
Fake X positive effect control; the same gated pipe send with successful
eventfd notification (expect refusal/no synthetic effect); and gated pipe send
with injected parent notification `OSError` (require parent UNKNOWN + recorded
notification failure; the final no-effect regression may fail). The injected
failure replaces the parent's notification method; it is not a real kernel I/O
failure. The third case is deliberately retained as a failing safety test if
the target effect occurs. Missing expected observations, fixture or cleanup
errors are not successes.

Run the pinned image sha256:bd191d30ea94871a1d3ca717252cd07a276e8ef7d1bcb4a130b63935ce075425
in Docker with `--network none --cpus 1 --memory 1g --pull never`, read-only
source mount and dedicated evidence output, Python normal mode and
`AGENT_INTERFACE_EXPERIMENTAL_EVENTFD=1`. Save exact source diff and base before
execution, output and exit, and synthetic case data. The fake owner generates
no real X or user input. This does not test a naturally failing eventfd write,
physical release, actual cancellation, child-check-after-admission or MAP01.

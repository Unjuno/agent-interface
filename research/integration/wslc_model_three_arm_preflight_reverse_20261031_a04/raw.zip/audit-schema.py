import json,sys
from pathlib import Path
from jsonschema import Draft202012Validator
p=Path(sys.argv[1]);source=Path(sys.argv[2]);rows=json.loads((p/'preflight-summary.json').read_text());results=[]
for r in rows:
 schema=json.loads((source/('plain_form_points_schema_v1.json' if r['arm']=='plain' else 'compiled_form_grounding_schema_v1.json')).read_text());errors=list(Draft202012Validator(schema).iter_errors(r['answer']));results.append({'arm':r['arm'],'valid':not errors,'errors':[e.message for e in errors]})
(p/'schema-audit.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results));raise SystemExit(0 if all(x['valid'] for x in results) else 1)

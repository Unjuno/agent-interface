import hashlib, json, pathlib
root = pathlib.Path(__file__).resolve().parent
old = root.parent / 'map01-visual-refresh-control-20261101'
manifest = json.loads((old / 'frozen-manifest.json').read_text())
for name, digest in manifest.items():
    data = (old / name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == digest
    target = root / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
runner = root / 'runner.py'
source = runner.read_text(encoding='utf8')
needle = 't0=time.monotonic_ns();game.advance_action(1,True);t1=time.monotonic_ns()'
assert source.count(needle) == 1
runner.write_text(source.replace(needle, "t0=time.monotonic_ns();game.advance_action(1,os.environ['UPDATE_STATE']=='yes');t1=time.monotonic_ns()"), encoding='utf8', newline='\n')
manifest['runner.py'] = hashlib.sha256(runner.read_bytes()).hexdigest()
(root / 'frozen-manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n', encoding='utf8')
launch = (old / 'launch.py').read_text(encoding='utf8')
needle = "'--env','REFRESH_MODE='+c['refresh_mode'],"
assert launch.count(needle) == 1
launch = launch.replace(needle, needle + "'--env','UPDATE_STATE='+c['update_state'],")
launch = launch.replace('map01-refreshcontrol-', 'map01-updateflag-')
(root / 'launch.py').write_text(launch, encoding='utf8', newline='\n')
arms = [('ey01','fire','no'),('ey02','fire','yes'),('ey03','withhold','yes'),('ey04','withhold','no')]
for ident, mode, flag in arms:
    p = root / ident
    p.mkdir(); (p / 'output').mkdir(); (p / 'exchange').mkdir()
    c = {'allocation':ident, 'route':'watch', 'seed':991040, 'hud':'on', 'post_mode':mode, 'refresh_mode':'advance', 'update_state':flag,
         'order':[f'{i}:{m}:{f}' for i,m,f in arms], 'freeze_main':'d012bdd093a821bcf16396489faa6db0a2932138',
         'image':'sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25',
         'manifest_sha256':hashlib.sha256((root/'frozen-manifest.json').read_bytes()).hexdigest(),
         'launcher_sha256':hashlib.sha256((root/'launch.py').read_bytes()).hexdigest(),
         'intervention':'Before each visual capture call advance_action(1, update_state), with only the boolean varied; fire and withhold controls. No hidden score supplied to recognizer.',
         'criterion':'Record screenshots, 48 recognition or timeout/unknown within cooperative 600 ms; retain watch cancellation, releases, old alias refusal, and simulator samples.',
         'stop':'One attempt per arm, no retry for success; stop block on infrastructure error or unresolved input.',
         'limits':'Four sequential games with fixed seed and exact HUD templates; advance_action is a privileged simulator call and can change game timeline.'}
    (p/'conditions.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf8')
print('four arms frozen')

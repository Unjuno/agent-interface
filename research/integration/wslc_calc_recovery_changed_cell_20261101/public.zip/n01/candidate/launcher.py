import os,sys,time,json,subprocess
from pathlib import Path
name=sys.argv[1];route={'n01':'compiled'}[name];root=Path('work/wslc-calc-matched-recovery-20261031-'+name).resolve();stage=Path('work/calc-post-entry-changed-cell-20261101').resolve();src=Path('work/wslc-calc-ocr-trace-source-20261031/source').resolve();cli=os.environ['CODEX_APP_RUNTIME_CLI_PATH'];env=os.environ.copy();env['PYTHONPATH']=str(src/'research/live_control');env['PYTHONDONTWRITEBYTECODE']='1'
cmd=['wslc','run','--rm','--name','calc-match-recovery-'+name+'-20261031','--network','none','--cpus','1','--memory','1g','--pull','never','--mount',f'type=bind,source={stage},target=/in,readonly','--mount',f'type=bind,source={stage},target=/candidate,readonly','--mount',f'type=bind,source={src},target=/src,readonly','--mount',f'type=bind,source={root / "exchange"},target=/exchange','--mount',f'type=bind,source={root / "output"},target=/out','-w','/src','--env','PYTHONPATH=/candidate/study:/src','--env','PYTHONDONTWRITEBYTECODE=1','--env','ROUTE='+route,'--entrypoint','timeout','sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25','--signal=TERM','--kill-after=3s','150s','python3','-B','/candidate/runner.py']
(root/'private-launch-command.json').write_text(json.dumps(cmd,indent=2)+'\n');start=time.monotonic()
with (root/'host.stdout').open('wb') as ho,(root/'host.stderr').open('wb') as he,(root/'container.stdout').open('wb') as co,(root/'container.stderr').open('wb') as ce:
 host=subprocess.Popen([sys.executable,'-B',str(stage/'host.py'),cli,str(root),str(3 if route=='fresh' else 2)],env=env,stdout=ho,stderr=he)
 container=subprocess.Popen(cmd,stdout=co,stderr=ce)
 try:rc=container.wait(timeout=165)
 except subprocess.TimeoutExpired:rc=None
 if rc is not None and host.poll() is None:(root/'exchange/stop.json').write_text('{}')
 try:hc=host.wait(timeout=15)
 except subprocess.TimeoutExpired:hc=None
 result={'container_exit':rc,'host_exit':hc,'elapsed_seconds':time.monotonic()-start,'container_pid':container.pid,'host_pid':host.pid,'live_handle_unresolved':rc is None or hc is None}
 (root/'launcher-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)

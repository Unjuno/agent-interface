from PIL import Image,ImageOps
from pathlib import Path
import subprocess,json
out=[]
for f in sorted(Path('/work').glob('*.png')):
 im=Image.open(f).convert('RGB').crop((32,408,90,450)); im=im.resize((348,252))
 for variant in ('gray','red'):
  if variant=='gray':bw=ImageOps.grayscale(im).point(lambda x: 255 if x>80 else 0)
  else:bw=im.convert('RGB').point(lambda x:x)
  if variant=='red':
   bw=Image.new('L',im.size);bw.putdata([0 if r>70 and r>g*1.5 and r>b*1.5 else 255 for r,g,b in im.getdata()])
  else:bw=ImageOps.invert(bw)
  p=Path('/tmp')/(f.stem+'-'+variant+'.png');bw.save(p)
  cp=subprocess.run(['tesseract',str(p),'stdout','--psm','7','-c','tessedit_char_whitelist=0123456789'],capture_output=True,text=True)
  out.append({'file':f.name,'variant':variant,'ocr':cp.stdout.strip(),'returncode':cp.returncode})
print(json.dumps(out,indent=2))

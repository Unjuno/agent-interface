import hashlib,json,time,sys,os,traceback
from pathlib import Path
from integrated_efficiency_app_server_model_v1 import PersistentGroundingModel
root=Path(sys.argv[2]);ex=root/'exchange';m=None;result={'id':'pilot-1','ok':False}
def put(name,data):
 tmp=ex/(name+'.tmp');tmp.write_text(json.dumps(data));os.replace(tmp,ex/(name+'.json'))
try:
 workspace=root/'workspace-1';workspace.mkdir(exist_ok=False)
 m=PersistentGroundingModel(root/'model-session-1',workspace,executable=sys.argv[1],contract='plain',model='gpt-6.1-sol',effort='low',path_converter=lambda p:str(Path(p).resolve()))
 put('ready',{'ready':True});deadline=time.monotonic()+100
 while not (ex/'request-1.json').exists():
  if time.monotonic()>deadline:raise TimeoutError('request not observed')
  time.sleep(.02)
 request=json.loads((ex/'request-1.json').read_text());image=ex/'image-1.png';digest=hashlib.sha256(image.read_bytes()).hexdigest()
 if request['id']!='pilot-1' or request['image_sha256']!=digest:raise ValueError('image mismatch')
 put('started-1',{'started':True});result['attempted']=True
 value=m.call(root/'model-call-1','In this game screenshot, identify the center of the visible enemy as field and the screen center as submit. If no enemy is visible, use the center for field. Do not operate anything.',image,'plain',workspace)
 result.update(ok=True,image_sha256=digest,grounding=value['grounding'],usage=value['usage'],call_id=value['call_id'],runner_ns=value['runner_ns']);put('done-1',result)
except BaseException as e:
 result.update(error=type(e).__name__,detail=str(e)[:500],call_id=getattr(e,'call_id',None),usage=getattr(e,'usage',None));put('done-1',result)
finally:
 if m is not None:
  try:m.close();result['close_returned']=True
  except BaseException as e:result.update(close_returned=False,close_error=repr(e))
 put('response-1',result)
print(json.dumps({'ok':result['ok'],'error':result.get('error')}),flush=True)

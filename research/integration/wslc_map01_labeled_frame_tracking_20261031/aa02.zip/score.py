from pathlib import Path
from PIL import Image
import hashlib,json,sys
import numpy as np
root=Path(sys.argv[1]);meta=json.loads((root/'frames.json').read_text());assert len(meta)==20
images=[]
for row in meta:
 p=root/('frame-%02d.png'%row['index']);assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];im=np.asarray(Image.open(p).convert('RGB'),dtype=np.int16);assert im.shape==(480,640,3);images.append(im)
initial=[x for x in meta[0]['labels'] if x['name']=='Zombieman' and x['width']>0 and x['height']>0]
if not initial:print(json.dumps({'status':'HOLD','reason':'no initial visible Zombieman'}));sys.exit(0)
seed=sorted(initial,key=lambda q:(-q['width']*q['height'],q['id']))[0];target_id=seed['id'];x=seed['x']+seed['width']//2;y=seed['y']+seed['height']//2
# Candidate functions receive only the initial and current RGB arrays plus the one initial point.
def patch(im,cx,cy):
 if cx<4 or cy<4 or cx+4>640 or cy+4>480:return None
 return im[cy-4:cy+4,cx-4:cx+4]
def fixed(old,new,x,y):
 a=patch(old,x,y);b=patch(new,x,y)
 if a is None or b is None:return None
 return [x,y] if float(np.abs(a-b).mean())<=32 else None
def wide(old,new,x,y):
 if x-24-48<0 or x+24+48>640 or y-60-32<0 or y+36+32>480:return None
 ref=old[y-60:y+36:3,x-24:x+24:3];rows=[]
 for dy in range(-32,33,2):
  for dx in range(-48,49,2):rows.append((float(np.abs(new[y+dy-60:y+dy+36:3,x+dx-24:x+dx+24:3]-ref).mean()),dx,dy))
 rows.sort();v,dx,dy=rows[0];second=next(q for q in rows if max(abs(q[1]-dx),abs(q[2]-dy))>12)
 if abs(dx)==48 or abs(dy)==32 or v>32 or second[0]-v<4:return None
 a=patch(old,x,y);b=patch(new,x+dx,y+dy)
 if a is None or b is None or float(np.abs(a-b).mean())>32:return None
 return [x+dx,y+dy]
def outcome(point,labels):
 if point is None:return 'abstained'
 contains=lambda q:q['x']<=point[0]<q['x']+q['width'] and q['y']<=point[1]<q['y']+q['height']
 all_enemies=[q for q in labels if q['name']=='Zombieman'];targets=[q for q in all_enemies if q['id']==target_id];others=[q for q in all_enemies if q['id']!=target_id and contains(q)]
 if not targets:return 'target_not_labeled'
 if contains(targets[0]) and others:return 'ambiguous_overlap'
 if contains(targets[0]):return 'inside_target_box'
 return 'inside_other_enemy_box' if others else 'outside_target_box'
rows=[]
for row,image in zip(meta,images):
 result={'index':row['index'],'tic':row['tic']}
 for name,fn in [('fixed',fixed),('wide',wide)]:
  point=fn(images[0],image,x,y);result[name]={'point':point,'outcome':outcome(point,row['labels'])}
 rows.append(result)
print(json.dumps({'status':'completed','seed':{'id':target_id,'point':[x,y],'box':[seed['x'],seed['y'],seed['width'],seed['height']]},'rows':rows},indent=2,sort_keys=True))

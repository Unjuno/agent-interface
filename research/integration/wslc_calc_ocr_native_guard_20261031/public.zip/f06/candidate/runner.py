import json,os,signal,subprocess,time
from pathlib import Path
from Xlib import X,display,XK
from runtime.cli_v1.mcp_guarded import GuardedSessionOwner
from runtime.guarded_x11_v1.compiled import run
from research.live_control.calc_ocr_graph_perception_v1 import make_ocr_calc_method,make_perception
out=Path('/out'); mode=os.environ['CASE']; actors=[]; owner=None; d=None
try:
 log=(out/'xvfb.log').open('wb'); x=subprocess.Popen(['Xvfb',':177','-screen','0','640x480x24','-nolisten','tcp','-ac'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True);actors.append(x)
 for i in range(100):
  try:d=display.Display(':177');break
  except Exception:time.sleep(.05)
 if d is None:raise RuntimeError('private Xvfb unavailable')
 screen=d.screen();w=screen.root.create_window(20,20,240,140,0,screen.root_depth,X.InputOutput,X.CopyFromParent,background_pixel=screen.white_pixel,event_mask=X.KeyPressMask|X.KeyReleaseMask|X.StructureNotifyMask)
 w.set_wm_name('Guard regression owned fixture');w.map();d.sync();gc=w.create_gc(foreground=screen.black_pixel);w.fill_rectangle(gc,78,68,8,8);d.sync();gc.free();w.set_input_focus(X.RevertToParent,X.CurrentTime);d.sync();time.sleep(.1)
 owner=GuardedSessionOwner({'app':w.id},out/'owner',':177');owner.get();b=owner.bridge;obs=b.observe();rgb=b.history[obs['sequence']][1];sample=(24,24,36,36);blank_bytes=rgb.crop(sample).tobytes();refs={}
 for alias in ('sheet','save','confirm'):
  refs[alias]=b.mint_reference(alias,obs['sequence'],[100,90],region_size=(20,20))
 graph=make_ocr_calc_method(interface_id='calcguard',session_scope=b.scope,surface='x11-window-'+str(w.id),sheet_handle='sheet',save_handle='save',confirm_handle='confirm')
 bindings={n:{'interaction':'keyboard','offset':refs[a]['offset'],'tail':([{'op':'text','text':'641','gap_ms':1}] if n=='enter' else [])} for n,a in [('enter','sheet'),('save','save'),('confirm','confirm')]}
 seen=[];injected=[]
 def context(native,image):
  blank=image.crop(sample).tobytes()==blank_bytes;seen.append({'sequence':native['sequence'],'blank':blank,'image_sha256':native['native']['artifact']['sha256']})
  return ({'sheet_target_present':True,'save_target_present':True,'dialog_present':False,'dialog_absent':True,'confirm_target_present':True,'saved_indication':False},blank)
 def ocr(native,image):
  if mode=='changed' and not injected:
   gc=w.create_gc(foreground=screen.black_pixel);w.fill_rectangle(gc,4,4,12,12);d.sync();gc.free();injected.append(native['sequence'])
  return ('','')
 perception=make_perception(context,ocr,expected=('641','283'))
 owner.dispatch_attempted=True
 result=run(b,graph,bindings,perceive=perception,verify_effect=lambda payload,native,image:{'status':'unavailable','evidence_ref':payload['observation']['evidence_ref']})
 close=owner.close();owner=None;d.sync();events=[]
 while d.pending_events():
  event=d.next_event()
  if event.type in (X.KeyPress,X.KeyRelease):events.append({'type':'press' if event.type==X.KeyPress else 'release','keycode':event.detail})
 keys=d.query_keymap();held=[i for i in range(256) if keys[i//8]&(1<<(i%8))];buttons=int(screen.root.query_pointer().mask)&(X.Button1Mask|X.Button2Mask|X.Button3Mask)
 record={'case':mode,'result':result,'close':close,'seen':seen,'change_injected_after_sequence':injected,'key_events':events,'keys_down':held,'buttons':buttons}
 (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
 if mode=='changed':
  assert injected and seen[0]['blank'] and any(not row['blank'] for row in seen[1:]) and result['completed_transitions']==0 and not any(e['type']=='press' for e in events)
 else:
  assert not injected and result['completed_transitions']==1 and any(e['type']=='press' for e in events)
 assert result['outcome']=='SAFE_YIELD' and close['release']['verified'] and not held and not buttons
finally:
 if owner is not None:owner.close()
 if d is not None:d.close()
 for proc in reversed(actors):
  if proc.poll() is None:
   os.killpg(proc.pid,signal.SIGTERM)
   try:proc.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=3)

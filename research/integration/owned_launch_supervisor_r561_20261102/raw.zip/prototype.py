import json, os, select, signal, subprocess, sys, time
from pathlib import Path
root=Path(sys.argv[2]);root.mkdir(exist_ok=True)
def log(event, **data):
    with (root/'events.jsonl').open('a') as f:
        f.write(json.dumps(dict(event=event,ns=time.monotonic_ns(),pid=os.getpid(),**data))+'\n');f.flush()
def wait_file(name,timeout=10):
    deadline=time.monotonic()+timeout
    while time.monotonic()<deadline:
        p=root/name
        if p.exists():return p.read_text().strip()
        time.sleep(.01)
    raise TimeoutError(name)
if sys.argv[1]=='supervisor':
    r,w=int(sys.argv[3]),int(sys.argv[4]);child=None
    try:
        child=subprocess.Popen([sys.executable,'-c','import time; time.sleep(60)'],start_new_session=True)
        (root/'child.pid').write_text(str(child.pid));log('child_spawned',child=child.pid)
        wait_file('release')
        if select.select([r],[],[],.25)[0]:raise RuntimeError('unexpected EOF with write descriptor retained')
        log('no_eof_with_leaked_write_end')
        os.close(w);w=None
        if not select.select([r],[],[],3)[0] or os.read(r,1)!=b'':raise RuntimeError('EOF absent after closing write end')
        log('eof_after_write_end_closed')
        child.terminate();child.wait(timeout=3);log('child_reaped',child=child.pid,returncode=child.returncode)
    finally:
        if child is not None and child.poll() is None:child.kill();child.wait(timeout=2)
        os.close(r)
        if w is not None:os.close(w)
elif sys.argv[1]=='parent':
    r,w=os.pipe()
    s=subprocess.Popen([sys.executable,__file__,'supervisor',str(root),str(r),str(w)],pass_fds=(r,w),start_new_session=True)
    os.close(r);(root/'supervisor.pid').write_text(str(s.pid));log('supervisor_started',supervisor=s.pid)
    while True:time.sleep(1)
elif sys.argv[1]=='controller':
    p=None;sf=None;cf=None
    try:
        p=subprocess.Popen([sys.executable,__file__,'parent',str(root)],start_new_session=True)
        sp=int(wait_file('supervisor.pid'));cp=int(wait_file('child.pid'))
        sf=os.pidfd_open(sp);cf=os.pidfd_open(cp);log('observed_spawn',parent=p.pid,supervisor=sp,child=cp)
        p.kill();p.wait(timeout=3);log('parent_killed',returncode=p.returncode)
        (root/'release').write_text('go')
        if not select.select([sf],[],[],8)[0]:raise TimeoutError('supervisor did not exit')
        log('supervisor_pidfd_exited')
        events=(root/'events.jsonl').read_text()
        for marker in ('no_eof_with_leaked_write_end','eof_after_write_end_closed','child_reaped'):
            if marker not in events:raise RuntimeError('missing '+marker)
        if not select.select([cf],[],[],1)[0]:raise RuntimeError('child still alive')
        log('child_pidfd_exited');log('result',status='PASS_SCOPED')
    except BaseException as e:
        log('result',status='FAIL',error=repr(e));raise
    finally:
        if p is not None and p.poll() is None:p.kill();p.wait(timeout=2)
        for fd in (cf,sf):
            if fd is not None:
                if not select.select([fd],[],[],0)[0]:
                    log('fixture_emergency_kill',fd=fd)
                    try:signal.pidfd_send_signal(fd,signal.SIGKILL)
                    except ProcessLookupError:pass
                os.close(fd)
else:raise SystemExit(64)

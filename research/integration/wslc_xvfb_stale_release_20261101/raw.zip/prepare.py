import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parent
files=[p for p in (root/'src').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']+[root/'trial.py',root/'target.py',root/'run.py',root/'prepare.py']
manifest={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
arms=[('stale-g01','retire'),('stale-g02','resume')]
for ident,mode in arms:
 p=root/ident;p.mkdir(exist_ok=False);(p/'output').mkdir()
 c={'allocation':'xvfb-stale-'+ident+'-20261101','mode':mode,'order':[f'{i}:{m}' for i,m in arms],
    'base_main':'5ecf445db9916dd2534ef9dc212e265d5b03eee1','draft_head':'0675ab810f7ee890d0904b8a402678c81f8dbafb',
    'image':'sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25',
    'manifest_sha256':hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest(),
    'intervention':'fixture holds a on old display; retire and replace or resume; control fixture releases a; fresh client holds b, old client attempts stale b release, inspect b state, fixture releases if needed; fresh guarded a task',
    'criteria':'old a held; replaced display neutral versus resumed display retains a; stale release cannot clear fresh b on replaced display but does clear b on shared display; fresh guarded a task effect and release verified',
    'stop':'one try per arm; preserve all failures; stop block on unresolved input or infrastructure failure',
    'limits':'direct bridge concurrency deliberately instrumented beyond serialized contract; pause is synthetic; no held old input, hard deadline or MAP01 claim'}
 (p/'conditions.json').write_text(json.dumps(c,indent=2)+'\n')
print('two arms frozen')

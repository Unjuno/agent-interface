import hashlib,json,time,sys,os,traceback
from pathlib import Path
from integrated_efficiency_app_server_model_v1 import PersistentGroundingModel
root=Path(sys.argv[2]);ex=root/'exchange';m=None;arm=None;count=0;records=[];error=None;end=time.monotonic()+570
try:
 while time.monotonic()<end:
  ident=f'{count+1:03d}';request=ex/(ident+'.request.json')
  if not request.exists():
   if (ex/'done.json').exists():break
   time.sleep(.05);continue
  if count>=14:raise RuntimeError('call cap exceeded')
  q=json.loads(request.read_text());r={'id':ident,'ok':False};image=ex/(ident+'.png');digest=hashlib.sha256(image.read_bytes()).hexdigest();r['image_sha256']=digest
  try:
   if q.get('id')!=ident or q.get('image_sha256')!=digest or q.get('arm') not in ('plain','ephemeral','persistent'):raise ValueError('request mismatch')
   expected='plain' if q['arm']=='plain' else 'compiled'
   if q.get('contract')!=expected:raise ValueError('contract mismatch')
   if arm!=q['arm']:
    if m is not None:m.close()
    arm=q['arm'];workspace=root/('workspace-'+arm);workspace.mkdir(exist_ok=False)
    m=PersistentGroundingModel(root/('session-'+arm),workspace,executable=sys.argv[1],contract=expected,model='gpt-6.1-sol',effort='low')
   r['attempted']=True;value=m.call(root/('call-'+ident),'Locate the editable token field and the control that submits this visible form.',image,expected,workspace)
   r.update(ok=True,grounding=value['grounding'],usage=value['usage'],call_id=value['call_id'],runner_ns=value['runner_ns'])
  except Exception as e:r.update(error=type(e).__name__,detail=str(e)[:800],call_id=getattr(e,'call_id',None),usage=getattr(e,'usage',None),runner_ns=getattr(e,'wait_ns',None))
  count+=1;records.append(r);tmp=ex/(ident+'.response.tmp');tmp.write_text(json.dumps(r));os.replace(tmp,ex/(ident+'.response.json'))
  if not r['ok']:break
 else:raise TimeoutError('broker deadline')
except Exception as e:error=repr(e)
finally:
 if m is not None:
  try:m.close()
  except Exception as e:error='close failed: '+repr(e)
 (root/'host-summary.json').write_text(json.dumps({'calls':count,'records':records,'error':error},indent=2)+'\n')
print(json.dumps({'calls':count,'error':error}));raise SystemExit(0 if error is None else 1)

import json,os,signal,subprocess,time,traceback,hashlib,math,threading
from pathlib import Path
from Xlib import X,display,error,XK
import vizdoom as vd
from runtime.cli_v1.mcp_guarded import GuardedSessionOwner

out=Path('/out');route=os.environ['ROUTE'];x=None;d=None;game=None;owner=None;monitor_worker=None
record={'route':route,'status':'running','task_success':None,'samples':[],'model_calls':0,'events':{}}
try:
 deadline=time.monotonic()+100
 while not Path('/exchange/ready.json').exists():
  if time.monotonic()>deadline:raise TimeoutError('host model session not ready')
  time.sleep(.05)
 os.environ['DISPLAY']=':153';os.environ['SDL_VIDEODRIVER']='x11';os.environ['HOME']='/tmp';os.environ['XDG_CACHE_HOME']='/tmp/cache'
 log=(out/'xvfb.log').open('wb');x=subprocess.Popen(['Xvfb',':153','-screen','0','1280x1024x24','-nolisten','tcp'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 for _ in range(100):
  try:d=display.Display(':153');break
  except Exception:time.sleep(.05)
 if d is None:raise RuntimeError('Xvfb unavailable')
 cfg=Path('/tmp/doom-keys.ini');cfg.write_text('[Doom.Bindings]\nw=+forward\ne=+use\nd=+right\na=+left\nf=+attack\n')
 pkg=Path(vd.__file__).resolve().parent;iwad=pkg/'freedoom2.wad';record['iwad_sha256']=hashlib.sha256(iwad.read_bytes()).hexdigest()
 game=vd.DoomGame();game.set_doom_game_path(str(iwad));game.set_doom_scenario_path('');game.set_doom_map('MAP01');game.set_doom_config_path(str(cfg));game.set_mode(vd.Mode.ASYNC_SPECTATOR);game.set_ticrate(35);game.set_seed(int(os.environ['GAME_SEED']));game.set_doom_skill(1);game.set_render_hud(os.environ['HUD_MODE']=='on');game.set_episode_timeout(2100);game.set_window_visible(True);game.set_console_enabled(False);game.set_sound_enabled(False);game.set_screen_resolution(vd.ScreenResolution.RES_640X480);game.set_available_buttons([vd.Button.MOVE_FORWARD,vd.Button.USE,vd.Button.TURN_RIGHT,vd.Button.TURN_LEFT,vd.Button.ATTACK]);game.set_labels_buffer_enabled(True);game.set_objects_info_enabled(True);game.set_available_game_variables([vd.GameVariable.POSITION_X,vd.GameVariable.POSITION_Y,vd.GameVariable.HEALTH,vd.GameVariable.KILLCOUNT,vd.GameVariable.ANGLE,vd.GameVariable.SELECTED_WEAPON_AMMO,vd.GameVariable.HITCOUNT,vd.GameVariable.DAMAGECOUNT,vd.GameVariable.HITS_TAKEN,vd.GameVariable.DAMAGE_TAKEN]);game.init()
 windows=[]
 for _ in range(250):
  windows=[]
  for w in d.screen().root.query_tree().children:
   try:
    title=w.get_wm_name()
    if title and 'DOOM' in title.upper() and w.get_attributes().map_state==X.IsViewable:windows.append(w)
   except error.BadWindow:pass
  if len(windows)==1:break
  if len(windows)>1:raise RuntimeError('ambiguous game window')
  time.sleep(.02)
 if len(windows)!=1:raise RuntimeError('game window unavailable')
 w=windows[0];d.set_input_focus(w.id,X.RevertToParent,X.CurrentTime);d.sync();time.sleep(.5)
 owner=GuardedSessionOwner({'app':w.id},out/'owner',':153',process_identity=True,query_worker=True);owner.get();bridge=owner.bridge;obs=bridge.observe();geom=obs['pointer_binding']['geometry'];point=[geom[0]+44,geom[1]+geom[3]-54];mint=bridge.mint_reference('game',obs['sequence'],point,region_size=(24,38));record['observation']=obs;record['mint']=mint
 def sample(label):
  game.advance_action(1,True);state=game.get_state();labels=[] if state is None else [str(x.object_name) for x in state.labels];objects=[] if state is None else [{'name':str(x.name),'id':int(x.id),'x':float(x.position_x),'y':float(x.position_y)} for x in state.objects]
  s={'label':label,'host_ns':time.monotonic_ns(),'tic':game.get_episode_time(),'x':game.get_game_variable(vd.GameVariable.POSITION_X),'y':game.get_game_variable(vd.GameVariable.POSITION_Y),'angle':game.get_game_variable(vd.GameVariable.ANGLE),'health':game.get_game_variable(vd.GameVariable.HEALTH),'kills':game.get_game_variable(vd.GameVariable.KILLCOUNT),'ammo':game.get_game_variable(vd.GameVariable.SELECTED_WEAPON_AMMO),'hits':game.get_game_variable(vd.GameVariable.HITCOUNT),'damage':game.get_game_variable(vd.GameVariable.DAMAGECOUNT),'hits_taken':game.get_game_variable(vd.GameVariable.HITS_TAKEN),'damage_taken':game.get_game_variable(vd.GameVariable.DAMAGE_TAKEN),'finished':game.is_episode_finished(),'visible_labels':labels,'objects':objects};record['samples'].append(s);(out/'samples.jsonl').open('a').write(json.dumps(s)+'\n');return s
 def screenshot(label):
  from PIL import Image
  g=w.get_geometry();raw=w.get_image(0,0,g.width,g.height,X.ZPixmap,0xffffffff);Image.frombytes('RGB',(g.width,g.height),raw.data,'raw','BGRX').save(out/('scene-'+label+'.png'))
 def run_action(alias,tail):
  source=bridge.observe();anchor=[geom[0]+geom[2]//2,geom[1]+geom[3]-100] if alias in ('turn','forward3','fire') else point;ref=bridge.mint_reference(alias,source['sequence'],anchor,region_size=(24,38));owner.dispatch_attempted=True
  result=bridge.keyboard(alias,ref['offset'],tail=tail,expires_at_ns=time.monotonic_ns()+4_000_000_000);(out/('action-'+alias+'.json')).write_text(json.dumps(result,indent=2)+'\n');record.setdefault('actions',[]).append(result)
  releases=result.get('execution',{}).get('releases',[])
  if result.get('status')!='completed' or not releases or not all(r.get('verified') and not r.get('keys_down') and not r.get('buttons_down') for r in releases):raise RuntimeError('action or release not confirmed')
 before=sample('before');screenshot('before')
 run_action('forward1',[{'op':'key_state','key':'w','down':True},{'op':'wait_update','timeout_ms':2000},{'op':'key_state','key':'w','down':False}]);sample('forward1');time.sleep(.8);sample('settle1')
 run_action('turn',[{'op':'key_state','key':'a','down':True},{'op':'wait_update','timeout_ms':900},{'op':'key_state','key':'a','down':False}]);sample('turn');screenshot('at-turn')
 def ask_start(i,source):
  artifact=source['native']['artifact'];image=Path(artifact['path']).read_bytes();digest=hashlib.sha256(image).hexdigest()
  if digest!=artifact['sha256']:raise RuntimeError('model image hash mismatch')
  Path(f'/exchange/image-{i}.png').write_bytes(image);q={'id':f'pilot-{i}','image_sha256':digest,'source_sequence':source['sequence']};tmp=Path(f'/exchange/request-{i}.tmp');tmp.write_text(json.dumps(q));os.replace(tmp,f'/exchange/request-{i}.json');record['events'][f'request_{i}_ns']=time.monotonic_ns()
  limit=time.monotonic()+15
  while not Path(f'/exchange/started-{i}.json').exists():
   if time.monotonic()>limit:raise TimeoutError('model did not start')
   time.sleep(.01)
  record['events'][f'start_{i}_observed_ns']=time.monotonic_ns()
 def wait_done(i,worker=None):
  deadline=time.monotonic()+25
  while time.monotonic()<deadline and not game.is_episode_finished():
   time.sleep(.2);sample(f'pending-{i}')
   if Path(f'/exchange/done-{i}.json').exists():break
  else:raise TimeoutError('model done not observed')
  record['events'][f'done_{i}_observed_ns']=time.monotonic_ns()
  if worker is not None:
   worker.join(5)
   if worker.is_alive():raise TimeoutError('policy worker did not finish')
  value=json.loads(Path(f'/exchange/done-{i}.json').read_text())
  if value.get('ok') is not True:raise RuntimeError('model response invalid')
  return value
 first_source=bridge.observe();first_rgb=bridge.history[first_source['sequence']][1];ask_start(1,first_source);sample('policy-start');first=wait_done(1);record['model_calls']=1;record['policy_response']=first
 policy=dict(first['grounding']);record['original_policy']=dict(policy)
 if policy['action']=='fire':policy['duration_ms']=500
 px,py=policy['target_x'],policy['target_y'];current=bridge.observe();current_rgb=bridge.history[current['sequence']][1];bounds=0<=px-4<px+4<=first_rgb.width and 0<=py-4<py+4<=first_rgb.height
 old=first_rgb.crop((px-4,py-4,px+4,py+4)).tobytes() if bounds else b'';now=current_rgb.crop((px-4,py-4,px+4,py+4)).tobytes() if bounds else b''
 distinct=len(set(tuple(old[i:i+3]) for i in range(0,len(old),3))) if old else 0
 center=abs(px-(geom[0]+geom[2]//2))<=40 and abs(py-(geom[1]+geom[3]//2))<=60
 patch_difference=sum(abs(a-b) for a,b in zip(old,now))/len(old) if old and len(old)==len(now) else 999
 eligible=bounds and center and distinct>=2 and patch_difference<=32 and first_source['pointer_binding']==current['pointer_binding']
 record['policy_gate']={'eligible':eligible,'bounds':bounds,'center':center,'patch_mean_abs_difference':patch_difference,'tolerance':32,'distinct_colors':distinct,'old_patch_sha256':hashlib.sha256(old).hexdigest(),'current_patch_sha256':hashlib.sha256(now).hexdigest(),'binding_equal':first_source['pointer_binding']==current['pointer_binding'],'policy':policy,'source_sequence':first_source['sequence'],'checked_sequence':current['sequence']};(out/'policy-gate.json').write_text(json.dumps(record['policy_gate'],indent=2)+'\n')
 ask_start(2,current);sample('second-pending-start');errs=[];worker=None;overlay=None;guard_events=[]
 if route in ('watch','inject','baseline') and policy['action']=='fire' and eligible and not Path('/exchange/done-2.json').exists():
  def fire():
   try:
    record['events']['policy_started_ns']=time.monotonic_ns();source=bridge.observe();anchor=[geom[0]+geom[2]//2,geom[1]+geom[3]-100];ref=bridge.mint_reference('fire',source['sequence'],anchor,region_size=(24,38));tail=[{'op':'key_state','key':'f','down':True},{'op':'wait_update','timeout_ms':policy['duration_ms']},{'op':'key_state','key':'f','down':False}];owner.dispatch_attempted=True
    def verify(stage,native,image):
     patch=image.crop((px-4,py-4,px+4,py+4)).tobytes();binding=native['pointer_binding']==current['pointer_binding'];difference=sum(abs(a-b) for a,b in zip(patch,now))/len(now) if len(patch)==len(now) and now else 999;valid=difference<=32 and binding and center;guard_events.append({'stage':stage,'sequence':native['sequence'],'patch_sha256':hashlib.sha256(patch).hexdigest(),'mean_abs_difference':difference,'tolerance':32,'binding_equal':binding,'eligible':valid,'observed_ns':time.monotonic_ns()});return valid
    with bridge.cancellation_scope('policy-token'):
     with bridge.input_guard('fire',ref['offset'],tail=tail,verify=verify,interaction='keyboard'):
      outcome=bridge.keyboard('fire',ref['offset'],tail=tail,expires_at_ns=time.monotonic_ns()+3_000_000_000)
    (out/'action-fire.json').write_text(json.dumps(outcome,indent=2)+'\n');record.setdefault('actions',[]).append(outcome);record['events']['policy_finished_ns']=time.monotonic_ns();record['policy_disposition']='completed' if outcome.get('status')=='completed' else 'refused_or_failed'
   except BaseException as exc:errs.append(repr(exc));record['policy_disposition']='worker_error'
   finally:(out/'policy-guard-events.json').write_text(json.dumps(guard_events,indent=2)+'\n')
  record['policy_disposition']='started';worker=threading.Thread(target=fire);worker.start()
  if route in ('watch','inject'):
   from bounded_patch_watch_v1 import BoundedPatchWatch
   class XProbe:
    def __init__(self):
     self.display=display.Display(':153');self.code=self.display.keysym_to_keycode(XK.string_to_keysym('f'));self.index=0;self.overlay=None
    def held(self):
     keys=self.display.query_keymap();return bool(self.code and keys[self.code//8]&(1<<(self.code%8)))
    def capture(self):
     if route=='inject' and self.index==1:
      self.overlay=self.display.screen().root.create_window(px-4,py-4,8,8,0,self.display.screen().root_depth,X.InputOutput,X.CopyFromParent,override_redirect=1,background_pixel=0xff00ff)
      self.overlay.map();self.overlay.configure(stack_mode=X.Above);self.display.sync();record['events']['overlay_mapped_ns']=time.monotonic_ns()
     raw=self.display.screen().root.get_image(px-4,py-4,8,8,X.ZPixmap,0xffffffff)
     from PIL import Image
     im=Image.frombytes('RGB',(8,8),raw.data,'raw','BGRX');data=im.tobytes();file='monitor-%03d.png'%self.index;im.save(out/file);self.index+=1
     return data,{'image':file,'patch_sha256':hashlib.sha256(data).hexdigest()}
    def close(self):
     if self.overlay is not None:self.overlay.destroy();self.display.sync()
     self.display.close()
   watch=BoundedPatchWatch(open_probe=XProbe,reference=now,token='policy-token',cancel=bridge.request_cancel,interval_s=.025,deadline_s=2,max_samples=100,threshold=32)
   watch.start();monitor_worker=watch
 elif route in ('watch','inject','baseline'):record['policy_disposition']='no_action_policy_or_gate'
 else:raise RuntimeError('unknown route')
 second=wait_done(2,worker);record['model_calls']=2;record['second_response']=second
 if monitor_worker is not None:
  record['monitor']=monitor_worker.join(3)
  if record['monitor']['status']=='running':raise TimeoutError('monitor worker still running; custody unresolved')
  if record['monitor']['status']=='monitor_error':raise RuntimeError('monitor error; see retained record')
 if overlay is not None:overlay.destroy();d.sync();record['events']['overlay_removed_ns']=time.monotonic_ns()
 if errs:raise RuntimeError('policy worker failed '+repr(errs))
 sample('second-model-done')
 # A new preplanned continuation, never a replay of the interrupted action.
 prior=record['actions'][-1] if record.get('actions') else {}
 rel=prior.get('execution',{}).get('releases',[])
 post={'mode':os.environ['POST_MODE'],'status':'not_eligible','original_effect':'unknown','replay':False}
 record['post_watch']=post
 if record.get('monitor',{}).get('status')=='change_detected' and prior.get('status')=='execution_failed' and rel and all(x.get('verified') and not x.get('keys_down') and not x.get('buttons_down') for x in rel):
  review=bridge.review_window(w.id);post['review']=review
  if review.get('status')!='reviewed':raise RuntimeError('fresh review failed')
  stale=bridge.keyboard('game',mint['offset'],tail=[{'op':'key_chord','keys':['f']}],expires_at_ns=time.monotonic_ns()+2_000_000_000)
  post['old_alias']=stale
  if stale.get('status')!='refused' or stale.get('input_dispatched') is not False:raise RuntimeError('old alias admitted')
  source=bridge.observe();rgb=bridge.history[source['sequence']][1]
  box=(geom[0]+32,geom[1]+408,geom[0]+90,geom[1]+450)
  from PIL import Image
  expected=hashlib.sha256(Image.open('/candidate/49.png').convert('RGB').tobytes()).hexdigest()
  actual=hashlib.sha256(rgb.crop(box).tobytes()).hexdigest()
  post['source']={'sequence':source['sequence'],'crop_sha256':actual,'expected_sha256':expected,'binding':source['pointer_binding']}
  if actual!=expected:post['status']='unrecognized_withheld'
  elif post['mode']=='withhold':post['status']='control_withheld'
  elif post['mode']=='fire':
   anchor=[geom[0]+44,geom[1]+geom[3]-54];ref=bridge.mint_reference('post_watch',source['sequence'],anchor,region_size=(24,38));checks=[]
   tail2=[{'op':'key_state','key':'f','down':True},{'op':'wait_update','timeout_ms':85},{'op':'key_state','key':'f','down':False}]
   def check_post(stage,native,image):
    digest=hashlib.sha256(image.crop(box).tobytes()).hexdigest();same=native['pointer_binding']==source['pointer_binding'];valid=digest==expected and same
    checks.append({'stage':stage,'sequence':native['sequence'],'crop_sha256':digest,'binding_equal':same,'eligible':valid,'observed_ns':time.monotonic_ns()});return valid
   with bridge.cancellation_scope('post-watch-token'):
    with bridge.input_guard('post_watch',ref['offset'],tail=tail2,verify=check_post,interaction='keyboard'):
     resumed=bridge.keyboard('post_watch',ref['offset'],tail=tail2,expires_at_ns=time.monotonic_ns()+2_000_000_000)
   post['status']=resumed.get('status');post['action']=resumed;post['checks']=checks
  else:raise RuntimeError('invalid post mode')
 (out/'post-watch.json').write_text(json.dumps(post,indent=2)+'\n')
 sample('after-post-watch')
 # Passive, bounded visual follow-up; no input and no simulator counters feed it.
 from PIL import Image
 expected48=hashlib.sha256(Image.open('/candidate/48.png').convert('RGB').tobytes()).hexdigest()
 expected49=hashlib.sha256(Image.open('/candidate/49.png').convert('RGB').tobytes()).hexdigest()
 started=time.monotonic_ns();visual_deadline=started+600_000_000;visual={'status':'not_eligible','started_ns':started,'deadline_ns':visual_deadline,'observations':[],'input_dispatched':False}
 if expected48==expected49:raise RuntimeError('visual templates ambiguous')
 if post.get('status') in ('completed','control_withheld'):
  visual['status']='timeout_unknown'
  while time.monotonic_ns()<visual_deadline:
   if os.environ['REFRESH_MODE']=='advance':
    t0=time.monotonic_ns();game.advance_action(1,True);t1=time.monotonic_ns()
    visual.setdefault('fixture_advances',[]).append({'started_ns':t0,'ended_ns':t1})
   if os.environ['REFRESH_MODE']=='peek':
    p0=time.monotonic_ns();game.get_state();p1=time.monotonic_ns()
    visual.setdefault('fixture_peeks',[]).append({'started_ns':p0,'ended_ns':p1})
   v=bridge.observe();pixels=bridge.history[v['sequence']][1];digest=hashlib.sha256(pixels.crop(box).tobytes()).hexdigest();checked=time.monotonic_ns()
   row={'sequence':v['sequence'],'crop_sha256':digest,'checked_ns':checked,'binding_equal':v['pointer_binding']==post['source']['binding']};visual['observations'].append(row)
   if checked>=visual_deadline:break
   if not row['binding_equal']:visual['status']='binding_unknown';break
   if digest==expected48:visual['status']='visual_48';break
   if digest!=expected49:visual['status']='unrecognized_unknown';break
   time.sleep(.015)
 visual['ended_ns']=time.monotonic_ns();visual['template48_sha256']=expected48;visual['template49_sha256']=expected49
 record['post_effect_visual']=visual;(out/'post-effect-visual.json').write_text(json.dumps(visual,indent=2)+'\n')
 sample('after-effect-review')
 for _ in range(8):
  if game.is_episode_finished():break
  time.sleep(.25);sample('post-model')
 screenshot('end');last=record['samples'][-1];record['displacement']=math.dist([before['x'],before['y']],[last['x'],last['y']]);record['health_delta']=last['health']-before['health'];record['kill_delta']=last['kills']-before['kills'];record['labels_seen']=sorted(set(y for x in record['samples'] for y in x['visible_labels']))
 record['close']=owner.close();owner=None
 keys=d.query_keymap();record['keys_down_after']=[key for key in ('w','e','d','a','f') if (lambda code:code and bool(keys[code//8]&(1<<(code%8))))(d.keysym_to_keycode(XK.string_to_keysym(key)))];record['status']='completed'

except BaseException as e:record['status']='error';record['error']=repr(e);(out/'traceback.txt').write_text(traceback.format_exc())
finally:
 if owner is not None:
  try:record['finally_close']=owner.close()
  except BaseException as e:record['close_error']=repr(e)
 if game is not None:
  try:game.close()
  except BaseException as e:record['game_close_error']=repr(e)
 if d is not None:d.close()
 if x is not None and x.poll() is None:
  try:os.killpg(x.pid,signal.SIGTERM);x.wait(timeout=3)
  except BaseException as e:record['xvfb_close_error']=repr(e)
 (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')

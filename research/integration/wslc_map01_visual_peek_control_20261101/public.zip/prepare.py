import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parent
old=root.parent/'map01-visual-refresh-control-20261101'
manifest=json.loads((old/'frozen-manifest.json').read_text())
for name,digest in manifest.items():
    data=(old/name).read_bytes();assert hashlib.sha256(data).hexdigest()==digest
    p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
runner=root/'runner.py'; text=runner.read_text(encoding='utf8')
needle="   v=bridge.observe();pixels=bridge.history[v['sequence']][1];"
replacement="""   if os.environ['REFRESH_MODE']=='peek':
    p0=time.monotonic_ns();game.get_state();p1=time.monotonic_ns()
    visual.setdefault('fixture_peeks',[]).append({'started_ns':p0,'ended_ns':p1})
   v=bridge.observe();pixels=bridge.history[v['sequence']][1];"""
assert text.count(needle)==1
runner.write_text(text.replace(needle,replacement),encoding='utf8',newline='\n')
manifest['runner.py']=hashlib.sha256(runner.read_bytes()).hexdigest()
(root/'frozen-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf8')
launch=(old/'launch.py').read_text(encoding='utf8').replace("'map01-refreshcontrol-'","'map01-peekcontrol-'")
(root/'launch.py').write_text(launch,encoding='utf8',newline='\n')
arms=[('ex01','fire'),('ex02','withhold')]
for ident,mode in arms:
    p=root/ident;p.mkdir();(p/'output').mkdir();(p/'exchange').mkdir()
    c={'allocation':ident,'route':'watch','seed':991040,'hud':'on','post_mode':mode,'refresh_mode':'peek',
       'order':['ex01:fire:peek','ex02:withhold:peek'],'freeze_main':'8d1a58321b9ed5d0c2bbed2063587483563cf107',
       'image':'sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25',
       'manifest_sha256':hashlib.sha256((root/'frozen-manifest.json').read_bytes()).hexdigest(),
       'launcher_sha256':hashlib.sha256((root/'launch.py').read_bytes()).hexdigest(),
       'intervention':'call game.get_state() before each HUD capture and discard the result; do not explicitly call advance_action during review',
       'criterion':'record exact visual 48, 49 timeout or unknown within cooperative 600ms; verify original cancellation, releases, fresh binding, no replay and withheld control',
       'stop':'one attempt per arm, no success retry; unknown remains unknown; stop block on unresolved input or infrastructure error',
       'limits':'two independent games, fixed seed/layout/templates; simulator API may itself synchronize or alter scheduling and is not available to ordinary screenshot-only controller'}
    (p/'conditions.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf8')
print('read-only simulator peek control frozen')

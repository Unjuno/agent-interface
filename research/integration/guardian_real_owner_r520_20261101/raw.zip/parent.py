import array,json,os,socket,subprocess,sys,threading,time,uuid
from pathlib import Path
from Xlib import X,XK,display
from runtime.cli_v1.owned_guarded_session import OwnedGuardedSessionOwner
from runtime.guarded_x11_v1.private_display_owner import PrivateDisplayOwner

def main():
    out=Path('/out');root=Path('/tmp/r520-session');root.mkdir()
    owner=PrivateDisplayOwner(root/'display');session=owner.start(timeout_s=5)
    os.environ['XAUTHORITY']=str(session.authority)
    app=display.Display(session.display)
    win=app.screen().root.create_window(10,10,200,120,0,app.screen().root_depth,
        X.InputOutput,X.CopyFromParent,event_mask=X.KeyPressMask|X.KeyReleaseMask)
    win.map();win.set_input_focus(X.RevertToParent,X.CurrentTime);app.sync()
    gc=win.create_gc(foreground=app.screen().white_pixel);win.fill_rectangle(gc,16,16,8,8);app.sync()
    guard=OwnedGuardedSessionOwner({'app':win.id},root/'guard',session.display,
        process_identity=True,query_worker=True,prestarted_cancel_supervisor=True)
    guard._ensure_started()
    def invoke(name,op,args):
        p=root/name;p.mkdir();return guard.invoke_guarded(op,args,p)
    obs=invoke('observe','guarded_observe',{})
    mint=invoke('mint','guarded_mint',{'alias':'field','source_sequence':obs['source']['sequence'],
        'point':[30,30],'region_size':[12,12]})
    (out/'old-observe.json').write_text(json.dumps(obs,indent=2,default=str))
    (out/'old-mint.json').write_text(json.dumps(mint,indent=2,default=str))
    if mint.get('status')!='minted':raise RuntimeError('mint failed '+repr(mint))
    def action():
        try:invoke('action','guarded_input',{'alias':'field','offset':mint['offset'],
            'interaction':'keyboard','observe_after':False,
            'tail':[{'op':'key_state','key':'a','down':True},{'op':'wait_update','timeout_ms':5000},
                    {'op':'key_state','key':'a','down':False}]})
        except BaseException:pass
    thread=threading.Thread(target=action,daemon=True);thread.start()
    code=app.keysym_to_keycode(XK.string_to_keysym('a'));deadline=time.monotonic()+3;pressed=False;down=False
    while time.monotonic()<deadline:
        bits=app.query_keymap();down=bool(bits[code//8] & (1 << (code%8)))
        while app.pending_events():
            ev=app.next_event()
            if ev.type==X.KeyPress and ev.detail==code:pressed=True
        if pressed and down:break
        time.sleep(.01)
    if not pressed or not down:raise RuntimeError('held key not observed')
    owner_pid=guard._process.pid;supervisor_pid=guard._cleanup_supervisor._process.pid
    left,right=socket.socketpair();token=uuid.uuid4().hex
    guardian=subprocess.Popen([sys.executable,'/fixture/guardian.py',str(right.fileno()),str(out),token],
        pass_fds=(right.fileno(),),start_new_session=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    right.close();left.settimeout(5)
    fds=[os.pidfd_open(owner_pid),os.pidfd_open(supervisor_pid)]
    left.sendmsg([b'P'],[(socket.SOL_SOCKET,socket.SCM_RIGHTS,array.array('i',fds))])
    if left.recv(1)!=b'R':raise RuntimeError('guardian not ready')
    left.sendall(b'C')
    if left.recv(1)!=b'A':raise RuntimeError('guardian did not commit')
    print(json.dumps({'owner_pid':owner_pid,'supervisor_pid':supervisor_pid,'guardian_pid':guardian.pid,
        'display_pid':owner._process.pid,'display':session.display,'authority':str(session.authority),
        'token':token,'old_press_observed':pressed,'old_key_down':down,'action_thread_alive':thread.is_alive(),
        'committed':True}),flush=True)
    if sys.stdin.buffer.read(1)!=b'X':raise RuntimeError('observer failed to pin')
    os._exit(0)
if __name__=='__main__':main()

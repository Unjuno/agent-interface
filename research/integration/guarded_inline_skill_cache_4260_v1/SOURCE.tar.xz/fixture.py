import argparse, json, sys, time, tkinter as tk
from pathlib import Path

STATES = {
    'A': {'target': (470, 250, 570, 300), 'marker':'#3498db'},
    'B': {'target': (330, 180, 430, 230), 'marker':'#9b59b6'},
    'A_MUT': {'target': (190, 245, 290, 295), 'marker':'#f1c40f'},
    'C': {'target': (90, 115, 190, 165), 'marker':'#1abc9c'},
}
class App:
    def __init__(self, journal):
        self.journal=Path(journal); self.state='A'; self.generation=1; self.seq=0
        self.root=tk.Tk(); self.root.title('InlineSkillCacheFixture'); self.root.geometry('640x360+0+0'); self.root.resizable(False,False)
        self.cv=tk.Canvas(self.root,width=640,height=360,bg='#ecf0f1',highlightthickness=0); self.cv.pack()
        self.cv.bind('<Button-1>',self.click)
        self.render(); self.root.after(30,self.poll_stdin)
    def emit(self,obj):
        obj={'t_ns':time.monotonic_ns(),**obj}
        with self.journal.open('a',encoding='utf-8') as f: f.write(json.dumps(obj,sort_keys=True)+'\n')
    def render(self):
        self.cv.delete('all'); s=STATES[self.state]
        self.cv.create_rectangle(0,0,639,359,fill='#ecf0f1',outline='')
        self.cv.create_rectangle(5,5,24,24,fill=s['marker'],outline='')
        self.cv.create_text(80,18,text='semantic operation: ACTIVATE(save)',fill='#2c3e50',anchor='w')
        # decoy is always visible and visually distinct
        self.cv.create_rectangle(430,90,530,140,fill='#e74c3c',outline='')
        self.cv.create_text(480,115,text='DELETE',fill='white')
        x1,y1,x2,y2=s['target']
        self.cv.create_rectangle(x1,y1,x2,y2,fill='#2ecc71',outline='')
        self.cv.create_text((x1+x2)//2,(y1+y2)//2,text='SAVE',fill='black')
        self.cv.create_text(10,340,text=f'state={self.state} gen={self.generation}',fill='#7f8c8d',anchor='w')
        self.root.update_idletasks()
    def click(self,e):
        s=STATES[self.state]; x1,y1,x2,y2=s['target']
        self.seq+=1
        if x1<=e.x<=x2 and y1<=e.y<=y2:
            self.emit({'event':'effect','effect':'SAVE_ACTIVATED','state':self.state,'generation':self.generation,'seq':self.seq,'x':e.x,'y':e.y})
        elif 430<=e.x<=530 and 90<=e.y<=140:
            self.emit({'event':'wrong_effect','effect':'DELETE_ACTIVATED','state':self.state,'generation':self.generation,'seq':self.seq,'x':e.x,'y':e.y})
        else:
            self.emit({'event':'miss','state':self.state,'generation':self.generation,'seq':self.seq,'x':e.x,'y':e.y})
    def poll_stdin(self):
        import select
        while select.select([sys.stdin],[],[],0)[0]:
            line=sys.stdin.readline()
            if not line: self.root.destroy(); return
            cmd=json.loads(line)
            if cmd['op']=='set':
                self.state=cmd['state']; self.generation=int(cmd['generation']); self.render()
                print(json.dumps({'ok':True,'state':self.state,'generation':self.generation}),flush=True)
            elif cmd['op']=='ping': print(json.dumps({'ok':True}),flush=True)
            elif cmd['op']=='quit': self.root.destroy(); return
        self.root.after(20,self.poll_stdin)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--journal',required=True); a=ap.parse_args()
    Path(a.journal).write_text('',encoding='utf-8'); App(a.journal).root.mainloop()
if __name__=='__main__': main()

import unittest
from runner import Cache
class T(unittest.TestCase):
 def test_k2_lru(self):
  c=Cache(2);c.install('a',1,(1,1));c.install('b',1,(2,2));self.assertIsNotNone(c.lookup('a',1));c.install('c',1,(3,3));self.assertIsNone(c.lookup('b',1))
 def test_generation(self):
  c=Cache(2);c.install('a',1,(1,1));self.assertIsNone(c.lookup('a',2))
 def test_guard(self):
  c=Cache(2);c.install('a',1,(1,1));self.assertIsNone(c.lookup('b',1))
if __name__=='__main__':unittest.main()

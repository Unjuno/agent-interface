from __future__ import annotations
import argparse, hashlib, json, os, subprocess, sys, time
from pathlib import Path
from Xlib import X, display
from Xlib.ext import xtest

W,H=640,360
TARGET=(46,204,113) # RGB #2ecc71
MARKER=(5,5,20,20)
SCHEDULE=[
 ('a_cold','A',1),('a_warm','A',1),('b_cold','B',1),('b_warm','B',1),
 ('a_warm_return','A',1),('a_mut_guard_change','A_MUT',1),('c_unseen','C',1),('a_oldlooking_newgen','A',2),
]

def pixel_bytes(d,x,y,w,h):
    root=d.screen().root; im=root.get_image(x,y,w,h,X.ZPixmap,0xffffffff)
    return im.data

def marker_hash(d): return hashlib.sha256(pixel_bytes(d,*MARKER)).hexdigest()

def generic_resolve(d):
    data=pixel_bytes(d,0,0,W,H)
    # Xvfb 24/32bpp data is B,G,R,0. Scan for target green.
    xs=[]; ys=[]; comps=0
    for y in range(H):
      row=y*W*4
      for x in range(W):
        i=row+x*4; b,g,r=data[i],data[i+1],data[i+2]; comps+=1
        if (r,g,b)==TARGET: xs.append(x); ys.append(y)
    if not xs: raise RuntimeError('target not found')
    return (round((min(xs)+max(xs))/2),round((min(ys)+max(ys))/2)), comps

def click(d,x,y):
    root=d.screen().root; root.warp_pointer(x,y); d.sync()
    xtest.fake_input(d,X.ButtonPress,1); d.sync(); xtest.fake_input(d,X.ButtonRelease,1); d.sync()

def buttons_neutral(d): return (d.screen().root.query_pointer().mask & 0x1f00)==0

def wait_journal(path,n,timeout=2):
    end=time.time()+timeout
    while time.time()<end:
      rows=[json.loads(x) for x in path.read_text().splitlines() if x.strip()]
      if len(rows)>=n:return rows
      time.sleep(.02)
    return [json.loads(x) for x in path.read_text().splitlines() if x.strip()]

class Cache:
    def __init__(self,k=2): self.k=k; self.entries=[]; self.tick=0
    def lookup(self,gh,gen):
      self.tick+=1
      for e in self.entries:
        if e['guard_hash']==gh and e['generation']==gen:
          e['last']=self.tick; return e
      return None
    def install(self,gh,gen,xy):
      self.tick+=1
      # exact same guard/gen replace
      self.entries=[e for e in self.entries if not(e['guard_hash']==gh and e['generation']==gen)]
      if len(self.entries)>=self.k:self.entries.sort(key=lambda e:e['last']);self.entries.pop(0)
      self.entries.append({'guard_hash':gh,'generation':gen,'xy':list(xy),'last':self.tick})

def run_session(root,policy,rep,display_num):
    out=root/f'{policy}-r{rep}'; out.mkdir(parents=True)
    env=os.environ.copy(); env['DISPLAY']=f':{display_num}'; xauth=out/'Xauthority.empty'; xauth.write_bytes(b''); env['XAUTHORITY']=str(xauth); os.environ['XAUTHORITY']=str(xauth)
    xv=subprocess.Popen(['Xvfb',env['DISPLAY'],'-screen','0',f'{W}x{H}x24','-nolisten','tcp','-ac'],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
    time.sleep(.15)
    journal=out/'journal.jsonl'
    app=subprocess.Popen([sys.executable,str(Path(__file__).with_name('fixture.py')),'--journal',str(journal)],env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1)
    d=display.Display(env['DISPLAY']); time.sleep(.2)
    app.stdin.write(json.dumps({'op':'ping'})+'\n'); app.stdin.flush(); app.stdout.readline()
    cache=Cache(2); rows=[]; jn=0
    try:
      for name,state,gen in SCHEDULE:
        app.stdin.write(json.dumps({'op':'set','state':state,'generation':gen})+'\n'); app.stdin.flush(); ack=json.loads(app.stdout.readline()); time.sleep(.05)
        gh=marker_hash(d); guard_pixels=MARKER[2]*MARKER[3]
        generic_calls=0; generic_pixels=0; cache_hit=False; deopt=False
        if policy=='GENERIC_PATH':
          xy,comps=generic_resolve(d); generic_calls=1;generic_pixels=comps
        else:
          e=cache.lookup(gh,gen)
          if e:
            cache_hit=True;xy=tuple(e['xy'])
          else:
            deopt=True;xy,comps=generic_resolve(d);generic_calls=1;generic_pixels=comps;cache.install(gh,gen,xy)
        click(d,*xy); jn+=1; jr=wait_journal(journal,jn)
        effect=jr[-1]
        rows.append({'case':name,'state':state,'generation':gen,'policy':policy,'guard_hash':gh,'cache_hit':cache_hit,'deopt':deopt,'xy':list(xy),'generic_calls':generic_calls,'generic_pixels':generic_pixels,'guard_pixels':guard_pixels if policy!='GENERIC_PATH' else 0,'effect_event':effect['event'],'effect':effect.get('effect'),'effect_state':effect['state'],'effect_generation':effect['generation'],'buttons_neutral':buttons_neutral(d),'cache_size':len(cache.entries)})
      app.stdin.write(json.dumps({'op':'quit'})+'\n');app.stdin.flush();app.wait(timeout=3)
    finally:
      try:d.close()
      except:pass
      if app.poll() is None:app.kill()
      xv.terminate();
      try:xv.wait(timeout=2)
      except:xv.kill()
    (out/'rows.json').write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
    return rows

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',required=True,type=Path);ap.add_argument('--reps',type=int,default=3);ap.add_argument('--display-base',type=int,default=710);a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=False)
 allrows=[]
 for rep in range(a.reps):
  for pi,pol in enumerate(['GENERIC_PATH','GUARDED_INLINE_CACHE']):
   allrows+=run_session(a.out,pol,rep,a.display_base+rep*2+pi)
 summary={'rows':allrows,'reps':a.reps,'schedule':[x[0] for x in SCHEDULE]}
 (a.out/'RAW.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
 print(json.dumps({'rows':len(allrows),'out':str(a.out)}))
if __name__=='__main__':main()

import copy,json,sys
from pathlib import Path
from audit import audit_obj
raw=json.loads(Path(sys.argv[1]).read_text())
mut=[]
def test(name,fn):
 x=copy.deepcopy(raw);fn(x);res=audit_obj(x);mut.append({'name':name,'rejected':bool(res['errors']),'errors':res['errors'][:4]})
test('wrong_effect',lambda x:x['rows'][0].update(effect_event='wrong_effect',effect='DELETE_ACTIVATED'))
test('false_warm_miss',lambda x:next(r for r in x['rows'] if r['policy']=='GUARDED_INLINE_CACHE' and r['case']=='a_warm').update(cache_hit=False,deopt=True,generic_calls=1))
test('false_mut_hit',lambda x:next(r for r in x['rows'] if r['policy']=='GUARDED_INLINE_CACHE' and r['case']=='a_mut_guard_change').update(cache_hit=True,deopt=False,generic_calls=0))
test('false_gen_hit',lambda x:next(r for r in x['rows'] if r['policy']=='GUARDED_INLINE_CACHE' and r['case']=='a_oldlooking_newgen').update(cache_hit=True,deopt=False,generic_calls=0))
test('nonneutral',lambda x:x['rows'][3].update(buttons_neutral=False))
test('lineage',lambda x:x['rows'][2].update(effect_generation=999))
test('remove_row',lambda x:x['rows'].pop())
test('no_work_reduction',lambda x:[r.update(generic_pixels=640*360) for r in x['rows'] if r['policy']=='GUARDED_INLINE_CACHE'])
out={'controls':mut,'rejected':sum(m['rejected'] for m in mut),'total':len(mut)}
print(json.dumps(out,indent=2));raise SystemExit(0 if out['rejected']==out['total'] else 1)

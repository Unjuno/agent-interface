import argparse,json,hashlib
from pathlib import Path
SCHEDULE=['a_cold','a_warm','b_cold','b_warm','a_warm_return','a_mut_guard_change','c_unseen','a_oldlooking_newgen']
EXPECTED_CACHE={'a_cold':False,'a_warm':True,'b_cold':False,'b_warm':True,'a_warm_return':True,'a_mut_guard_change':False,'c_unseen':False,'a_oldlooking_newgen':False}
def audit_obj(obj):
 rows=obj['rows']; errs=[]
 if len(rows)!=obj['reps']*16:errs.append('row_count')
 by={}
 for r in rows:
  k=(r['policy'],r['case']);by.setdefault(k,[]).append(r)
  if r['effect_event']!='effect' or r['effect']!='SAVE_ACTIVATED':errs.append('effect:'+str(k))
  if not r['buttons_neutral']:errs.append('buttons:'+str(k))
  if r['effect_state']!=r['state'] or r['effect_generation']!=r['generation']:errs.append('effect_lineage:'+str(k))
 for case in SCHEDULE:
  for r in by.get(('GENERIC_PATH',case),[]):
   if r['generic_calls']!=1 or r['cache_hit'] or r['deopt']:errs.append('generic_policy:'+case)
  for r in by.get(('GUARDED_INLINE_CACHE',case),[]):
   if r['cache_hit']!=EXPECTED_CACHE[case]:errs.append('cache_expected:'+case)
   if r['cache_hit'] and (r['generic_calls']!=0 or r['deopt']):errs.append('hit_work:'+case)
   if not r['cache_hit'] and (r['generic_calls']!=1 or not r['deopt']):errs.append('deopt_work:'+case)
 # primary semantic-work endpoint: full-frame generic pixel comparisons
 generic=sum(r['generic_pixels'] for r in rows if r['policy']=='GENERIC_PATH')
 cache=sum(r['generic_pixels'] for r in rows if r['policy']=='GUARDED_INLINE_CACHE')
 guard=sum(r['guard_pixels'] for r in rows if r['policy']=='GUARDED_INLINE_CACHE')
 if not cache < generic:errs.append('no_generic_work_reduction')
 # all three warm cases must hit every rep
 for case in ['a_warm','b_warm','a_warm_return']:
  if not all(r['cache_hit'] for r in by.get(('GUARDED_INLINE_CACHE',case),[])):errs.append('warm_miss:'+case)
 # all invalid/unseen/gen cases deopt every rep
 for case in ['a_mut_guard_change','c_unseen','a_oldlooking_newgen']:
  if not all(r['deopt'] and not r['cache_hit'] for r in by.get(('GUARDED_INLINE_CACHE',case),[])):errs.append('unsafe_non_deopt:'+case)
 decision='PASS_GUARDED_INLINE_SKILL_CACHE_SCOPED' if not errs else 'FAIL_OR_HOLD'
 return {'decision':decision,'errors':errs,'rows':len(rows),'generic_fullscan_pixels':generic,'cache_fullscan_pixels':cache,'cache_guard_pixels':guard,'fullscan_reduction_fraction':1-cache/generic if generic else None,'wrong_effects':sum(r['effect_event']!='effect' for r in rows),'cache_hits':sum(r['cache_hit'] for r in rows if r['policy']=='GUARDED_INLINE_CACHE'),'deopts':sum(r['deopt'] for r in rows if r['policy']=='GUARDED_INLINE_CACHE')}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('raw',type=Path);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();obj=json.loads(a.raw.read_text());res=audit_obj(obj);a.out.write_text(json.dumps(res,indent=2,sort_keys=True)+'\n');print(json.dumps(res,indent=2,sort_keys=True));raise SystemExit(0 if not res['errors'] else 1)
if __name__=='__main__':main()

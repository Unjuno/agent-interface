# Guarded inline skill cache — formal result

Issue #4260. Decision: **PASS_GUARDED_INLINE_SKILL_CACHE_SCOPED**.

## First frozen outcome

- formal rows: 48/48
- formal invocations/reruns/replacements/tuning: 1/0/0/0
- wrong application effects: 0
- candidate warm cache hits: 9/9 expected warm calls
- candidate deoptimizations: 15 (all cold/incompatible/unseen/generation-mismatch calls)
- GENERIC_PATH full-frame semantic scan work: 5,529,600 pixels
- GUARDED_INLINE_CACHE full-frame semantic scan work: 3,456,000 pixels
- candidate guard acquisition: 9,600 pixels
- full-frame semantic-scan reduction: 37.5%
- independent raw audit: errors=[]
- coherent corruption controls rejected: 8/8
- every click produced independently journaled SAVE_ACTIVATED and terminal Button1 neutral.

## Interpretation

In this one real Xvfb/Tk call-site fixture, K=2 guarded specialization reused current-state-compatible target coordinates on the three preregistered warm phases per repetition. Guard mutation, unseen shape, and pixel-old-looking but generation-new state never reused the specialization; they deoptimized to the unchanged full current semantic resolver. The measured benefit is deterministic generic pixel-scan work, not frontier-model tokens or general GUI latency.

## Preserved failures

Construction-01 STOP_SETUP_XAUTHORITY and construction-02 STOP_SETUP_XAUTHORITY_PARENT_ENV occurred before any operation row and remain retained. Construction-03 was eligible but excluded from formal. No formal rerun or result-driven tuning occurred.

## Scope / C / U

The guard is an exact 20x20 marker hash plus trusted generation in a cooperative fixture. This does not establish automatic guard synthesis, semantic identity under hidden dependencies, token savings, model quality, cross-application transfer, or production readiness. K=2 can thrash on richer polymorphism.

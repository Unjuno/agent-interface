import json,os,signal,subprocess,time,traceback,hashlib,math,threading
from pathlib import Path
from Xlib import X,display,error,XK
import vizdoom as vd
from runtime.cli_v1.mcp_guarded import GuardedSessionOwner

out=Path('/out');route=os.environ['ROUTE'];x=None;d=None;game=None;owner=None;monitor_worker=None
record={'route':route,'status':'running','task_success':None,'samples':[],'model_calls':0,'events':{}}
try:
 deadline=time.monotonic()+100
 while not Path('/exchange/ready.json').exists():
  if time.monotonic()>deadline:raise TimeoutError('host model session not ready')
  time.sleep(.05)
 os.environ['DISPLAY']=':153';os.environ['SDL_VIDEODRIVER']='x11';os.environ['HOME']='/tmp';os.environ['XDG_CACHE_HOME']='/tmp/cache'
 log=(out/'xvfb.log').open('wb');x=subprocess.Popen(['Xvfb',':153','-screen','0','1280x1024x24','-nolisten','tcp'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 for _ in range(100):
  try:d=display.Display(':153');break
  except Exception:time.sleep(.05)
 if d is None:raise RuntimeError('Xvfb unavailable')
 cfg=Path('/tmp/doom-keys.ini');cfg.write_text('[Doom.Bindings]\nw=+forward\ne=+use\nd=+right\na=+left\nf=+attack\n')
 pkg=Path(vd.__file__).resolve().parent;iwad=pkg/'freedoom2.wad';record['iwad_sha256']=hashlib.sha256(iwad.read_bytes()).hexdigest()
 game=vd.DoomGame();game.set_doom_game_path(str(iwad));game.set_doom_scenario_path('');game.set_doom_map('MAP01');game.set_doom_config_path(str(cfg));game.set_mode(vd.Mode.ASYNC_SPECTATOR);game.set_ticrate(35);game.set_seed(int(os.environ['GAME_SEED']));game.set_doom_skill(1);game.set_episode_timeout(2100);game.set_window_visible(True);game.set_console_enabled(False);game.set_sound_enabled(False);game.set_screen_resolution(vd.ScreenResolution.RES_640X480);game.set_available_buttons([vd.Button.MOVE_FORWARD,vd.Button.USE,vd.Button.TURN_RIGHT,vd.Button.TURN_LEFT,vd.Button.ATTACK]);game.set_labels_buffer_enabled(True);game.set_objects_info_enabled(True);game.set_available_game_variables([vd.GameVariable.POSITION_X,vd.GameVariable.POSITION_Y,vd.GameVariable.HEALTH,vd.GameVariable.KILLCOUNT,vd.GameVariable.ANGLE,vd.GameVariable.SELECTED_WEAPON_AMMO,vd.GameVariable.HITCOUNT,vd.GameVariable.DAMAGECOUNT,vd.GameVariable.HITS_TAKEN,vd.GameVariable.DAMAGE_TAKEN]);game.init()
 windows=[]
 for _ in range(250):
  windows=[]
  for w in d.screen().root.query_tree().children:
   try:
    title=w.get_wm_name()
    if title and 'DOOM' in title.upper() and w.get_attributes().map_state==X.IsViewable:windows.append(w)
   except error.BadWindow:pass
  if len(windows)==1:break
  if len(windows)>1:raise RuntimeError('ambiguous game window')
  time.sleep(.02)
 if len(windows)!=1:raise RuntimeError('game window unavailable')
 w=windows[0];d.set_input_focus(w.id,X.RevertToParent,X.CurrentTime);d.sync();time.sleep(.5)
 owner=GuardedSessionOwner({'app':w.id},out/'owner',':153',process_identity=True,query_worker=True);owner.get();bridge=owner.bridge;obs=bridge.observe();geom=obs['pointer_binding']['geometry'];point=[geom[0]+44,geom[1]+geom[3]-54];mint=bridge.mint_reference('game',obs['sequence'],point,region_size=(24,38));record['observation']=obs;record['mint']=mint
 def sample(label):
  game.advance_action(1,True);state=game.get_state();labels=[] if state is None else [str(x.object_name) for x in state.labels];objects=[] if state is None else [{'name':str(x.name),'id':int(x.id),'x':float(x.position_x),'y':float(x.position_y)} for x in state.objects]
  s={'label':label,'host_ns':time.monotonic_ns(),'tic':game.get_episode_time(),'x':game.get_game_variable(vd.GameVariable.POSITION_X),'y':game.get_game_variable(vd.GameVariable.POSITION_Y),'angle':game.get_game_variable(vd.GameVariable.ANGLE),'health':game.get_game_variable(vd.GameVariable.HEALTH),'kills':game.get_game_variable(vd.GameVariable.KILLCOUNT),'ammo':game.get_game_variable(vd.GameVariable.SELECTED_WEAPON_AMMO),'hits':game.get_game_variable(vd.GameVariable.HITCOUNT),'damage':game.get_game_variable(vd.GameVariable.DAMAGECOUNT),'hits_taken':game.get_game_variable(vd.GameVariable.HITS_TAKEN),'damage_taken':game.get_game_variable(vd.GameVariable.DAMAGE_TAKEN),'finished':game.is_episode_finished(),'visible_labels':labels,'label_boxes':[] if state is None else [{'name':str(q.object_name),'id':int(q.object_id),'x':int(q.x),'y':int(q.y),'width':int(q.width),'height':int(q.height)} for q in state.labels],'objects':objects}
  if state is not None and label in ('fourth-frame-oracle','fifth-frame-oracle','shadow-oracle','recovery-action-before'):
   from PIL import Image
   arr=state.screen_buffer
   if len(arr.shape)!=3:raise RuntimeError('unexpected oracle screen dimensions')
   if arr.shape[0] in (3,4):arr=arr.transpose(1,2,0)
   if arr.shape[2] not in (3,4):raise RuntimeError('unexpected oracle screen channels')
   oracle_file='oracle-'+label+'.png';Image.fromarray(arr).convert('RGB').save(out/oracle_file);blob=(out/oracle_file).read_bytes();s['oracle_image']={'path':oracle_file,'sha256':hashlib.sha256(blob).hexdigest(),'state_number':int(state.number),'width':int(arr.shape[1]),'height':int(arr.shape[0])}
  record['samples'].append(s);(out/'samples.jsonl').open('a').write(json.dumps(s)+'\n');return s
 def screenshot(label):
  from PIL import Image
  g=w.get_geometry();raw=w.get_image(0,0,g.width,g.height,X.ZPixmap,0xffffffff);Image.frombytes('RGB',(g.width,g.height),raw.data,'raw','BGRX').save(out/('scene-'+label+'.png'))
 def run_action(alias,tail):
  source=bridge.observe();anchor=[geom[0]+geom[2]//2,geom[1]+geom[3]-100] if alias in ('turn','forward3','fire') else point;ref=bridge.mint_reference(alias,source['sequence'],anchor,region_size=(24,38));owner.dispatch_attempted=True
  result=bridge.keyboard(alias,ref['offset'],tail=tail,expires_at_ns=time.monotonic_ns()+4_000_000_000);(out/('action-'+alias+'.json')).write_text(json.dumps(result,indent=2)+'\n');record.setdefault('actions',[]).append(result)
  releases=result.get('execution',{}).get('releases',[])
  if result.get('status')!='completed' or not releases or not all(r.get('verified') and not r.get('keys_down') and not r.get('buttons_down') for r in releases):raise RuntimeError('action or release not confirmed')
 before=sample('before');screenshot('before')
 run_action('forward1',[{'op':'key_state','key':'w','down':True},{'op':'wait_update','timeout_ms':2000},{'op':'key_state','key':'w','down':False}]);sample('forward1');time.sleep(.8);sample('settle1')
 run_action('turn',[{'op':'key_state','key':'a','down':True},{'op':'wait_update','timeout_ms':900},{'op':'key_state','key':'a','down':False}]);sample('turn');screenshot('at-turn')
 def ask_start(i,source):
  artifact=source['native']['artifact'];image=Path(artifact['path']).read_bytes();digest=hashlib.sha256(image).hexdigest()
  if digest!=artifact['sha256']:raise RuntimeError('model image hash mismatch')
  Path(f'/exchange/image-{i}.png').write_bytes(image);q={'id':f'pilot-{i}','image_sha256':digest,'source_sequence':source['sequence']};tmp=Path(f'/exchange/request-{i}.tmp');tmp.write_text(json.dumps(q));os.replace(tmp,f'/exchange/request-{i}.json');record['events'][f'request_{i}_ns']=time.monotonic_ns()
  limit=time.monotonic()+15
  while not Path(f'/exchange/started-{i}.json').exists():
   if time.monotonic()>limit:raise TimeoutError('model did not start')
   time.sleep(.01)
  record['events'][f'start_{i}_observed_ns']=time.monotonic_ns()
 def wait_done(i,worker=None):
  deadline=time.monotonic()+25
  while time.monotonic()<deadline and not game.is_episode_finished():
   time.sleep(.2);sample(f'pending-{i}')
   if Path(f'/exchange/done-{i}.json').exists():break
  else:raise TimeoutError('model done not observed')
  record['events'][f'done_{i}_observed_ns']=time.monotonic_ns()
  if worker is not None:
   worker.join(5)
   if worker.is_alive():raise TimeoutError('policy worker did not finish')
  value=json.loads(Path(f'/exchange/done-{i}.json').read_text())
  if value.get('ok') is not True:raise RuntimeError('model response invalid')
  return value
 first_source=bridge.observe();first_rgb=bridge.history[first_source['sequence']][1];ask_start(1,first_source);sample('policy-start');first=wait_done(1);record['model_calls']=1;record['policy_response']=first
 policy=dict(first['grounding']);record['original_policy']=dict(policy)
 if policy['action']=='fire':policy['duration_ms']=500
 px,py=policy['target_x'],policy['target_y'];current=bridge.observe();current_rgb=bridge.history[current['sequence']][1];bounds=0<=px-4<px+4<=first_rgb.width and 0<=py-4<py+4<=first_rgb.height
 old=first_rgb.crop((px-4,py-4,px+4,py+4)).tobytes() if bounds else b'';now=current_rgb.crop((px-4,py-4,px+4,py+4)).tobytes() if bounds else b''
 distinct=len(set(tuple(old[i:i+3]) for i in range(0,len(old),3))) if old else 0
 center=abs(px-(geom[0]+geom[2]//2))<=40 and abs(py-(geom[1]+geom[3]//2))<=60
 patch_difference=sum(abs(a-b) for a,b in zip(old,now))/len(old) if old and len(old)==len(now) else 999
 eligible=bounds and center and distinct>=2 and patch_difference<=32 and first_source['pointer_binding']==current['pointer_binding']
 record['policy_gate']={'eligible':eligible,'bounds':bounds,'center':center,'patch_mean_abs_difference':patch_difference,'tolerance':32,'distinct_colors':distinct,'old_patch_sha256':hashlib.sha256(old).hexdigest(),'current_patch_sha256':hashlib.sha256(now).hexdigest(),'binding_equal':first_source['pointer_binding']==current['pointer_binding'],'policy':policy,'source_sequence':first_source['sequence'],'checked_sequence':current['sequence']};(out/'policy-gate.json').write_text(json.dumps(record['policy_gate'],indent=2)+'\n')
 ask_start(2,current);sample('second-pending-start');errs=[];worker=None;overlay=None;guard_events=[]
 if route in ('watch','inject') and policy['action']=='fire' and eligible and not Path('/exchange/done-2.json').exists():
  def fire():
   try:
    record['events']['policy_started_ns']=time.monotonic_ns();source=bridge.observe();anchor=[geom[0]+geom[2]//2,geom[1]+geom[3]-100];ref=bridge.mint_reference('fire',source['sequence'],anchor,region_size=(24,38));tail=[{'op':'key_state','key':'f','down':True},{'op':'wait_update','timeout_ms':policy['duration_ms']},{'op':'key_state','key':'f','down':False}];owner.dispatch_attempted=True
    def verify(stage,native,image):
     patch=image.crop((px-4,py-4,px+4,py+4)).tobytes();binding=native['pointer_binding']==current['pointer_binding'];difference=sum(abs(a-b) for a,b in zip(patch,now))/len(now) if len(patch)==len(now) and now else 999;valid=difference<=32 and binding and center;guard_events.append({'stage':stage,'sequence':native['sequence'],'patch_sha256':hashlib.sha256(patch).hexdigest(),'mean_abs_difference':difference,'tolerance':32,'binding_equal':binding,'eligible':valid,'observed_ns':time.monotonic_ns()});return valid
    with bridge.cancellation_scope('policy-token'):
     with bridge.input_guard('fire',ref['offset'],tail=tail,verify=verify,interaction='keyboard'):
      outcome=bridge.keyboard('fire',ref['offset'],tail=tail,expires_at_ns=time.monotonic_ns()+3_000_000_000)
    (out/'action-fire.json').write_text(json.dumps(outcome,indent=2)+'\n');record.setdefault('actions',[]).append(outcome);record['events']['policy_finished_ns']=time.monotonic_ns();record['policy_disposition']='completed' if outcome.get('status')=='completed' else 'refused_or_failed'
   except BaseException as exc:errs.append(repr(exc));record['policy_disposition']='worker_error'
   finally:(out/'policy-guard-events.json').write_text(json.dumps(guard_events,indent=2)+'\n')
  record['policy_disposition']='started';worker=threading.Thread(target=fire);worker.start()
  if route in ('watch','inject'):
   from bounded_patch_watch_v1 import BoundedPatchWatch
   class XProbe:
    def __init__(self):
     self.display=display.Display(':153');self.code=self.display.keysym_to_keycode(XK.string_to_keysym('f'));self.index=0;self.overlay=None
    def held(self):
     keys=self.display.query_keymap();return bool(self.code and keys[self.code//8]&(1<<(self.code%8)))
    def capture(self):
     if route=='inject' and self.index==1:
      self.overlay=self.display.screen().root.create_window(px-4,py-4,8,8,0,self.display.screen().root_depth,X.InputOutput,X.CopyFromParent,override_redirect=1,background_pixel=0xff00ff)
      self.overlay.map();self.overlay.configure(stack_mode=X.Above);self.display.sync();record['events']['overlay_mapped_ns']=time.monotonic_ns()
     raw=self.display.screen().root.get_image(px-4,py-4,8,8,X.ZPixmap,0xffffffff)
     from PIL import Image
     im=Image.frombytes('RGB',(8,8),raw.data,'raw','BGRX');data=im.tobytes();file='monitor-%03d.png'%self.index;im.save(out/file);self.index+=1
     return data,{'image':file,'patch_sha256':hashlib.sha256(data).hexdigest()}
    def close(self):
     if self.overlay is not None:self.overlay.destroy();self.display.sync()
     self.display.close()
   watch=BoundedPatchWatch(open_probe=XProbe,reference=now,token='policy-token',cancel=bridge.request_cancel,interval_s=.025,deadline_s=2,max_samples=100,threshold=32)
   watch.start();monitor_worker=watch
 elif route in ('watch','inject'):record['policy_disposition']='no_action_policy_or_gate'
 else:raise RuntimeError('unknown route')
 second=wait_done(2,worker);record['model_calls']=2;record['second_response']=second
 if monitor_worker is not None:
  record['monitor']=monitor_worker.join(3)
  if record['monitor']['status']=='running':raise TimeoutError('monitor worker still running; custody unresolved')
  if record['monitor']['status']=='monitor_error':raise RuntimeError('monitor error; see retained record')
 if overlay is not None:overlay.destroy();d.sync();record['events']['overlay_removed_ns']=time.monotonic_ns()
 if errs:raise RuntimeError('policy worker failed '+repr(errs))
 if record.get('monitor',{}).get('status')!='change_detected':raise RuntimeError('no cancellation trigger; recovery inconclusive')
 prior=record['actions'][-1];releases=prior.get('execution',{}).get('releases',[])
 if prior.get('status')!='execution_failed' or not releases or not releases[-1].get('verified') or releases[-1].get('keys_down') or releases[-1].get('buttons_down'):raise RuntimeError('prior release unresolved; no recovery')
 record['events']['recovery_start_ns']=time.monotonic_ns();sample('recovery-before');review=bridge.review_window(w.id);record['recovery_review']=review
 if review.get('status')!='reviewed' or review.get('authority_granted') is not False or review.get('input_dispatched') is not False:raise RuntimeError('review failed; no recovery')
 fresh=review['observation'];fresh_rgb=bridge.history[fresh['sequence']][1];ask_start(3,fresh);third=wait_done(3);record['model_calls']=3;record['third_response']=third;decision=third['grounding'];record['recovery_policy']=decision
 # A turn is a separate bounded action, never an implicit shot. Revalidate
 # the third-call target before turning; then ask a fourth call on a new frame.
 rx0,ry0=decision['target_x'],decision['target_y'];pre=bridge.observe();pre_rgb=bridge.history[pre['sequence']][1];valid0=decision['action']=='fire' and 0<=rx0-4<rx0+4<=fresh_rgb.width and 0<=ry0-4<ry0+4<=fresh_rgb.height
 old0=fresh_rgb.crop((rx0-4,ry0-4,rx0+4,ry0+4)).tobytes() if valid0 else b'';new0=pre_rgb.crop((rx0-4,ry0-4,rx0+4,ry0+4)).tobytes() if valid0 else b'';diff0=sum(abs(a-b) for a,b in zip(old0,new0))/len(old0) if old0 and len(old0)==len(new0) else 999;dx=rx0-(geom[0]+geom[2]//2);dy=ry0-(geom[1]+geom[3]//2);distinct0=len(set(tuple(old0[i:i+3]) for i in range(0,len(old0),3))) if old0 else 0
 turn_ok=valid0 and pre['pointer_binding']==fresh['pointer_binding'] and distinct0>=2 and diff0<=32 and 40<abs(dx)<=120 and abs(dy)<=60
 record['turn_gate']={'eligible':turn_ok,'dx':dx,'dy':dy,'difference':diff0,'distinct_colors':distinct0,'binding_equal':pre['pointer_binding']==fresh['pointer_binding'],'source_sequence':fresh['sequence'],'checked_sequence':pre['sequence'],'source_sha256':hashlib.sha256(old0).hexdigest(),'checked_sha256':hashlib.sha256(new0).hexdigest()}
 if turn_ok:
  key='d' if dx>0 else 'a';sample('aim-before');run_action('aim_turn',[{'op':'key_state','key':key,'down':True},{'op':'wait_update','timeout_ms':100},{'op':'key_state','key':key,'down':False}]);sample('aim-after');record['turn_direction']=key;record['turn_disposition']='completed'
 else:record['turn_disposition']='not_eligible'
 sample('fourth-frame-oracle');fresh=bridge.observe();fresh_rgb=bridge.history[fresh['sequence']][1];ask_start(4,fresh);fourth=wait_done(4);record['model_calls']=4;record['fourth_response']=fourth;decision=fourth['grounding'];record['recovery_policy']=decision
 marker=None
 for attempt in range(2):
  if decision['action']=='fire':
   rx,ry=decision['target_x'],decision['target_y']
   if attempt==0 and 8<=rx<1272 and 8<=ry<1016 and abs(rx-(geom[0]+geom[2]//2))<=40 and abs(ry-(geom[1]+geom[3]//2))<=60:
    marker=d.screen().root.create_window(rx-4,ry-4,8,8,0,d.screen().root_depth,X.InputOutput,X.CopyFromParent,override_redirect=1,background_pixel=0x808080);marker.map();marker.configure(stack_mode=X.Above);d.sync();record['events']['shadow_overlay_mapped_ns']=time.monotonic_ns()
   if attempt==0:sample('shadow-oracle')
   latest=bridge.observe();latest_rgb=bridge.history[latest['sequence']][1];inside=0<=rx-4<rx+4<=fresh_rgb.width and 0<=ry-4<ry+4<=fresh_rgb.height;center=abs(rx-(geom[0]+geom[2]//2))<=40 and abs(ry-(geom[1]+geom[3]//2))<=60
   old3=fresh_rgb.crop((rx-4,ry-4,rx+4,ry+4)).tobytes() if inside else b'';new3=latest_rgb.crop((rx-4,ry-4,rx+4,ry+4)).tobytes() if inside else b'';diff3=sum(abs(a-b) for a,b in zip(old3,new3))/len(old3) if old3 and len(old3)==len(new3) else 999;binding=latest['pointer_binding']==fresh['pointer_binding'];distinct=len(set(tuple(old3[i:i+3]) for i in range(0,len(old3),3))) if old3 else 0
   record['recovery_gate']={'bounds':inside,'center':center,'binding_equal':binding,'difference':diff3,'distinct_colors':distinct,'eligible':inside and center and binding and distinct>=2 and diff3<=32,'source_sequence':fresh['sequence'],'checked_sequence':latest['sequence'],'source_sha256':hashlib.sha256(old3).hexdigest(),'checked_sha256':hashlib.sha256(new3).hexdigest()}
   if record['recovery_gate']['eligible']:
    sample('recovery-action-before');source3=bridge.observe();ref3=bridge.mint_reference('recovery',source3['sequence'],[rx,ry],region_size=(24,38));tail3=[{'op':'key_state','key':'f','down':True},{'op':'wait_update','timeout_ms':200},{'op':'key_state','key':'f','down':False}];guard3=[]
    def verify3(stage,native,image):
     patch=image.crop((rx-4,ry-4,rx+4,ry+4)).tobytes();d3=sum(abs(a-b) for a,b in zip(patch,new3))/len(new3) if len(patch)==len(new3) and new3 else 999;binding3=native['pointer_binding']==latest['pointer_binding'];valid=d3<=32 and binding3 and center;guard3.append({'stage':stage,'sequence':native['sequence'],'mean_abs_difference':d3,'patch_sha256':hashlib.sha256(patch).hexdigest(),'binding_equal':binding3,'eligible':valid});return valid
    owner.dispatch_attempted=True
    with bridge.input_guard('recovery',ref3['offset'],tail=tail3,verify=verify3,interaction='keyboard'):
     action3=bridge.keyboard('recovery',ref3['offset'],tail=tail3,expires_at_ns=time.monotonic_ns()+3_000_000_000)
    (out/'action-recovery.json').write_text(json.dumps(action3,indent=2)+'\n');(out/'recovery-guard-events.json').write_text(json.dumps(guard3,indent=2)+'\n');record['recovery_action']=action3
    release3=action3.get('execution',{}).get('releases',[])
    if action3.get('status')!='completed' or not release3 or not release3[-1].get('verified') or release3[-1].get('keys_down') or release3[-1].get('buttons_down'):raise RuntimeError('recovery action or release unconfirmed')
    sample('recovery-action-after');record['recovery_disposition']='completed'
   else:record['recovery_disposition']='refused_stale_or_unbound'
  else:record['recovery_disposition']='model_idle'
  record.setdefault('recovery_attempts',[]).append({'model_call':4+attempt,'policy':decision,'gate':record.get('recovery_gate'),'disposition':record['recovery_disposition']})
  gate_retry=record.get('recovery_gate',{})
  if attempt==0 and record['recovery_disposition']=='refused_stale_or_unbound' and gate_retry.get('bounds') and gate_retry.get('center') and gate_retry.get('binding_equal') and gate_retry.get('distinct_colors',0)>=2 and gate_retry.get('difference',0)>32:
   # Shadow only: no candidate is ever used to authorize input.
   from PIL import ImageChops,ImageStat
   shadow_start=time.monotonic_ns();half=8;template=fresh_rgb.crop((rx-half,ry-half,rx+half,ry+half));candidates=[]
   for ddy in range(-60,61,2):
    for ddx in range(-80,81,2):
     cx,cy=rx+ddx,ry+ddy
     if not (0<=cx-half and cx+half<=latest_rgb.width and 0<=cy-half and cy+half<=latest_rgb.height):continue
     patch=latest_rgb.crop((cx-half,cy-half,cx+half,cy+half));score=sum(ImageStat.Stat(ImageChops.difference(template,patch)).mean)/3;candidates.append((score,ddx,ddy))
   candidates.sort();best=candidates[0];runner=next((q for q in candidates[1:] if abs(q[1]-best[1])>16 or abs(q[2]-best[2])>16),None);shadow_end=time.monotonic_ns();gap=runner[0]-best[0] if runner else None
   record['shadow_match']={'source_sequence':fresh['sequence'],'checked_sequence':latest['sequence'],'origin':[rx,ry],'candidate':[rx+best[1],ry+best[2]],'best_difference':best[0],'runner_up_difference':runner[0] if runner else None,'gap':gap,'candidate_count':len(candidates),'elapsed_ns':shadow_end-shadow_start,'started_ns':shadow_start,'ended_ns':shadow_end,'shadow_only':True,'would_accept':bool(runner is not None and best[0]<=8 and gap>=5)}
   if marker is not None:marker.destroy();d.sync();marker=None;record['events']['shadow_overlay_removed_ns']=time.monotonic_ns()
   vector_start=time.monotonic_ns()
   import numpy as np
   from shadow_patch_match_v1 import search as shadow_search
   srcarr=np.asarray(fresh_rgb,dtype=np.uint8);dstarr=np.asarray(latest_rgb,dtype=np.uint8);module_result=shadow_search(srcarr,dstarr,(rx,ry));vector_end=time.monotonic_ns()
   if (module_result['candidate']!=(rx+best[1],ry+best[2]) or module_result['candidate_count']!=len(candidates) or abs(module_result['best_sum']/768-best[0])>1e-9 or (runner is None)!=(module_result['runner_sum'] is None) or (runner is not None and abs(module_result['runner_sum']/768-runner[0])>1e-9) or module_result['authority_granted'] or not module_result['requires_revalidation']):raise RuntimeError('module summary mismatch; no input')
   record['shadow_module']={'started_ns':vector_start,'ended_ns':vector_end,'elapsed_ns':vector_end-vector_start,'result':module_result,'numpy':np.__version__,'shadow_only':True}
   sample('fifth-frame-oracle');fresh=bridge.observe();fresh_rgb=bridge.history[fresh['sequence']][1];ask_start(5,fresh);fifth=wait_done(5);record['model_calls']=5;record['fifth_response']=fifth;decision=fifth['grounding'];record['recovery_policy']=decision;record.pop('recovery_gate',None);continue
  break
 if marker is not None:marker.destroy();d.sync();marker=None;record['events']['shadow_overlay_removed_ns']=time.monotonic_ns()
 record['events']['recovery_end_ns']=time.monotonic_ns()
 sample('second-model-done')
 for _ in range(8):
  if game.is_episode_finished():break
  time.sleep(.25);sample('post-model')
 screenshot('end');last=record['samples'][-1];record['displacement']=math.dist([before['x'],before['y']],[last['x'],last['y']]);record['health_delta']=last['health']-before['health'];record['kill_delta']=last['kills']-before['kills'];record['labels_seen']=sorted(set(y for x in record['samples'] for y in x['visible_labels']))
 record['close']=owner.close();owner=None
 keys=d.query_keymap();record['keys_down_after']=[key for key in ('w','e','d','a','f') if (lambda code:code and bool(keys[code//8]&(1<<(code%8))))(d.keysym_to_keycode(XK.string_to_keysym(key)))];record['status']='completed'

except BaseException as e:record['status']='error';record['error']=repr(e);(out/'traceback.txt').write_text(traceback.format_exc())
finally:
 if owner is not None:
  try:record['finally_close']=owner.close()
  except BaseException as e:record['close_error']=repr(e)
 if game is not None:
  try:game.close()
  except BaseException as e:record['game_close_error']=repr(e)
 if d is not None:d.close()
 if x is not None and x.poll() is None:
  try:os.killpg(x.pid,signal.SIGTERM);x.wait(timeout=3)
  except BaseException as e:record['xvfb_close_error']=repr(e)
 (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')

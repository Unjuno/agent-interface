import os,time,json,signal,subprocess,traceback,hashlib
from pathlib import Path
from Xlib import X,display,error,XK
from Xlib.ext import xtest
import vizdoom as vd
out=Path('/out');mode=os.environ['MODE'];r={'mode':mode,'status':'running','samples':[]};d=None;game=None;x=None
try:
 os.environ.update(DISPLAY=':163',SDL_VIDEODRIVER='x11',HOME='/tmp',XDG_CACHE_HOME='/tmp/cache')
 x=subprocess.Popen(['Xvfb',':163','-screen','0','1280x1024x24','-nolisten','tcp'],stdout=subprocess.DEVNULL,stderr=(out/'xvfb.log').open('wb'),start_new_session=True)
 for _ in range(100):
  try:d=display.Display(':163');break
  except Exception:time.sleep(.05)
 if d is None:raise RuntimeError('Xvfb unavailable')
 cfg=Path('/tmp/doom-grab.ini');cfg.write_text('[Doom.Bindings]\nf=+attack\n')
 wad=Path(vd.__file__).resolve().parent/'freedoom2.wad';r['iwad_sha256']=hashlib.sha256(wad.read_bytes()).hexdigest()
 game=vd.DoomGame();game.set_doom_game_path(str(wad));game.set_doom_scenario_path('');game.set_doom_map('MAP01');game.set_doom_config_path(str(cfg));game.set_mode(vd.Mode.ASYNC_SPECTATOR);game.set_ticrate(35);game.set_seed(991031);game.set_doom_skill(1);game.set_episode_timeout(2100);game.set_window_visible(True);game.set_sound_enabled(False);game.set_available_buttons([vd.Button.ATTACK]);game.set_available_game_variables([vd.GameVariable.SELECTED_WEAPON_AMMO,vd.GameVariable.HEALTH,vd.GameVariable.KILLCOUNT]);game.init()
 windows=[]
 for _ in range(250):
  windows=[]
  for w in d.screen().root.query_tree().children:
   try:
    title=w.get_wm_name()
    if title and 'DOOM' in title.upper() and w.get_attributes().map_state==X.IsViewable:windows.append(w)
   except error.BadWindow:pass
  if len(windows)==1:break
  if len(windows)>1:raise RuntimeError('ambiguous game window')
  time.sleep(.02)
 if len(windows)!=1:raise RuntimeError('game window unavailable')
 w=windows[0];d.set_input_focus(w.id,X.RevertToParent,X.CurrentTime);d.sync();time.sleep(.5)
 def sample(label):
  game.advance_action(1,True);s={'label':label,'host_ns':time.monotonic_ns(),'tic':game.get_episode_time(),'ammo':game.get_game_variable(vd.GameVariable.SELECTED_WEAPON_AMMO),'health':game.get_game_variable(vd.GameVariable.HEALTH),'kills':game.get_game_variable(vd.GameVariable.KILLCOUNT)};r['samples'].append(s);return s
 sample('before');code=d.keysym_to_keycode(XK.string_to_keysym('f'));r['keycode']=code;r['events']={};grabbed=False
 try:
  if mode in ('grab','short'):d.grab_server();d.sync();grabbed=True;r['events']['grab_confirmed_ns']=time.monotonic_ns()
  elif mode!='normal':raise ValueError('bad mode')
  r['events']['press_requested_ns']=time.monotonic_ns();xtest.fake_input(d,X.KeyPress,code);d.sync();r['events']['press_confirmed_ns']=time.monotonic_ns();keys=d.query_keymap();r['down_during']=bool(keys[code//8]&(1<<(code%8)))
  if mode=='short':
   d.ungrab_server();d.sync();grabbed=False;r['events']['ungrab_confirmed_ns']=time.monotonic_ns();keys=d.query_keymap();r['down_after_ungrab']=bool(keys[code//8]&(1<<(code%8)))
  time.sleep(.085)
  r['events']['release_requested_ns']=time.monotonic_ns();xtest.fake_input(d,X.KeyRelease,code);d.sync();r['events']['release_confirmed_ns']=time.monotonic_ns();keys=d.query_keymap();r['down_after']=bool(keys[code//8]&(1<<(code%8)))
 finally:
  if 'release_confirmed_ns' not in r['events']:
   try:xtest.fake_input(d,X.KeyRelease,code);d.sync();r['events']['emergency_release_ns']=time.monotonic_ns()
   except BaseException as exc:r['emergency_release_error']=repr(exc)
  if grabbed:d.ungrab_server();d.sync();r['events']['ungrab_confirmed_ns']=time.monotonic_ns()
 sample('after')
 for _ in range(15):time.sleep(.05);sample('later')
 r['status']='completed'
except BaseException as e:r['status']='error';r['error']=repr(e);(out/'traceback.txt').write_text(traceback.format_exc())
finally:
 if game is not None:
  try:game.close()
  except BaseException as e:r['game_close_error']=repr(e)
 if d is not None:d.close()
 if x is not None and x.poll() is None:
  try:os.killpg(x.pid,signal.SIGTERM);x.wait(timeout=3)
  except BaseException as e:r['xvfb_close_error']=repr(e)
 (out/'result.json').write_text(json.dumps(r,indent=2)+'\n')

import json,os,time
from pathlib import Path
from Xlib import X,display
from Xlib.ext import xtest

def guarded_calc_click(request):
 d=display.Display(':153');root=d.screen().root;pid=os.getpid();base=d.display.info.resource_id_base;session=request['session_id'];out=Path('/out');info={'owner_pid':pid,'resource_base':base,'session_id':session,'operation_id':request['operation_id'],'target':request['target'],'point':request['point'],'buttons':['left']}
 with (out/'custody.json').open('x') as f:json.dump(info,f);f.flush();os.fsync(f.fileno())
 x,y=request['point'];xtest.fake_input(d,X.MotionNotify,x=x,y=y);d.sync();d.grab_server();d.sync();window=root;chain=[root.id]
 for _ in range(64):
  child=window.translate_coords(root,x,y).child
  if child in (None,X.NONE,0):break
  ident=getattr(child,'id',child)
  if ident in chain:raise RuntimeError('cycle')
  chain.append(ident);window=d.create_resource_object('window',ident)
 else:raise RuntimeError('excessive chain')
 if request['target'] not in chain:d.ungrab_server();d.sync();return {'status':'unknown','reason':'target_excluded','operation_id':request['operation_id'],'session_id':session}
 xtest.fake_input(d,X.ButtonPress,1);xtest.fake_input(d,X.ButtonRelease,1);d.sync();sent=time.monotonic_ns();d.ungrab_server();d.sync();(out/'pair-synced.json').write_text(json.dumps({'sent_ns':sent,'scheduled_late_ns':sent+2_000_000_000,'chain':chain}))
 time.sleep(2);(out/'late.json').write_text('worker continued after delay')
 return {'status':'completed','operation_id':request['operation_id'],'session_id':session}

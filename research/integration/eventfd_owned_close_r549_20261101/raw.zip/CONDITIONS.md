# Owned-session notifier close prototype r549

Before this run, execute three explicitly ordered Linux tests: normal spawned
Fake X owner close should terminate its child and close its parent eventfd;
injected notifier close OSError should leave cleanup UNKNOWN and unverified;
and concurrent owner start/close is gated after child spawn but before parent
registration, requiring no live owner after close. The third is expected to
fail for the current prototype. Tests inject interleavings and failures; they
are not natural failure-rate measurements or actual X input.

Run once in the pinned image
sha256:bd191d30ea94871a1d3ca717252cd07a276e8ef7d1bcb4a130b63935ce075425,
Docker network disabled, 1 CPU, 1 GiB, no pull, source read-only, Python normal
mode and bytecode disabled. Save base and working diff before execution, stdout
and exit. Each fixture attempts to retire its own child. No physical input,
actual cancellation, release verification, MAP01 or display-server queue is
involved. Missing fixture observations or unrelated failures are errors.

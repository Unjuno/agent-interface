#!/usr/bin/env python3
import json, pathlib, sys
from science import compute
root = pathlib.Path(__file__).resolve().parent
fixture = json.loads((root / "fixture.json").read_text())
out = compute(fixture)
out.update({"formal_invocations": 1, "formal_reruns": 0, "schema": "integrated-wall-decomposition-rescue-result-v2"})
path = pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else root / "RESULT.json"
if path.exists(): raise SystemExit("RESULT_EXISTS")
path.write_text(json.dumps(out, indent=2, sort_keys=True)+"\n")
print(out["decision"])

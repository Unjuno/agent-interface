#!/usr/bin/env python3
import json, pathlib, sys
from decimal import Decimal
from science import compute
root = pathlib.Path(__file__).resolve().parent
fixture = json.loads((root / "fixture.json").read_text())
result_path = pathlib.Path(sys.argv[1])
result = json.loads(result_path.read_text())
expected = compute(fixture)
errors=[]
allowed_top={'decision','rows','deltas','checks','formal_invocations','formal_reruns','schema'}
if set(result) != allowed_top: errors.append('schema_keys')
if result.get("decision") != expected["decision"]: errors.append("decision")
if result.get("rows") != expected["rows"]: errors.append("rows")
if result.get("deltas") != expected["deltas"]: errors.append("deltas")
if result.get("checks") != expected["checks"]: errors.append("checks")
if result.get("formal_invocations") != 1 or result.get("formal_reruns") != 0: errors.append("formal_counts")
text=result_path.read_text()
if '"local_time"' in text: errors.append("forbidden_local_time_label")
for row in result.get("rows",[]):
    if row.get("timing_attribution") is not False: errors.append("timing_attribution")
    if Decimal(row["retained_model_stage_ms"]) + Decimal(row["unattributed_remainder_ms"]) != Decimal(row["phase_complete_wall_ms"]): errors.append("row_identity")
for d in result.get("deltas",[]):
    if Decimal(d["persistent_model_stage_delta_ms"]) + Decimal(d["persistent_remainder_delta_ms"]) != Decimal(d["persistent_wall_delta_ms"]): errors.append("delta_identity")
out={"audit":"PASS" if not errors else "FAIL","errors":errors,"recomputed_decision":expected["decision"]}
print(json.dumps(out,indent=2,sort_keys=True))
raise SystemExit(0 if not errors else 2)

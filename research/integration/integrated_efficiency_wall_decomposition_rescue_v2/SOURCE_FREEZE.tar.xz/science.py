from __future__ import annotations
from decimal import Decimal

ARMS = ("plain", "ephemeral", "persistent")
EXPECTED_BLOBS = {
    "integrated_audit": "e32fae1480f56e296a47ec7f4dd57ad21d09e35a",
    "preflight_wall_audit": "8c51999e72616167143682861c1cb1e8eb3d44ce",
    "phase_ledger_result": "808dd787d64620997c091accb2446d1928a16294",
}

def D(x):
    return Decimal(str(x))

def arm_row(name, src):
    wall = D(src["phase_complete_wall_ms"])
    task_model = D(src["task_image_model_wait_ms"])
    preflight_model = D(src["preflight_model_subprocess_lifetime_ms"])
    model_stage = task_model + preflight_model
    remainder = wall - model_stage
    return {
        "arm": name,
        "phase_complete_wall_ms": str(wall),
        "task_image_model_wait_ms": str(task_model),
        "preflight_model_subprocess_lifetime_ms": str(preflight_model),
        "retained_model_stage_ms": str(model_stage),
        "unattributed_remainder_ms": str(remainder),
        "model_stage_share": str(model_stage / wall),
        "unattributed_share": str(remainder / wall),
        "local_observations": int(src["local_observations"]),
        "durable_calls": int(src["durable_calls"]),
        "timing_attribution": False,
        "remainder_label": "unattributed_remainder_ms",
    }

def compute(fixture):
    if fixture.get("source_blobs") != EXPECTED_BLOBS:
        raise ValueError("SOURCE_BLOB_IDENTITY_MISMATCH")
    rows = {a: arm_row(a, fixture["arms"][a]) for a in ARMS}
    p = rows["persistent"]
    deltas = {}
    for c in ("plain", "ephemeral"):
        q = rows[c]
        wd = D(p["phase_complete_wall_ms"]) - D(q["phase_complete_wall_ms"])
        md = D(p["retained_model_stage_ms"]) - D(q["retained_model_stage_ms"])
        rd = D(p["unattributed_remainder_ms"]) - D(q["unattributed_remainder_ms"])
        deltas[c] = {
            "control": c,
            "persistent_wall_delta_ms": str(wd),
            "persistent_model_stage_delta_ms": str(md),
            "persistent_remainder_delta_ms": str(rd),
            "identity_holds": wd == md + rd,
        }
    checks = {
        "model_stage_lower_than_plain": D(p["retained_model_stage_ms"]) < D(rows["plain"]["retained_model_stage_ms"]),
        "model_stage_lower_than_ephemeral": D(p["retained_model_stage_ms"]) < D(rows["ephemeral"]["retained_model_stage_ms"]),
        "remainder_higher_than_plain": D(p["unattributed_remainder_ms"]) > D(rows["plain"]["unattributed_remainder_ms"]),
        "remainder_higher_than_ephemeral": D(p["unattributed_remainder_ms"]) > D(rows["ephemeral"]["unattributed_remainder_ms"]),
        "delta_identities": all(v["identity_holds"] for v in deltas.values()),
        "nonnegative_components": all(D(r["retained_model_stage_ms"]) >= 0 and D(r["unattributed_remainder_ms"]) >= 0 for r in rows.values()),
        "model_stage_within_wall": all(D(r["retained_model_stage_ms"]) <= D(r["phase_complete_wall_ms"]) for r in rows.values()),
        "timing_attribution_false": all(r["timing_attribution"] is False for r in rows.values()),
        "remainder_label_exact": all(r["remainder_label"] == "unattributed_remainder_ms" for r in rows.values()),
    }
    decision = "PASS_RETAINED_WALL_DECOMPOSITION_RESCUED_SCOPED" if all(checks.values()) else "FAIL_DECOMPOSITION_CLAIM"
    return {"decision": decision, "rows": [rows[a] for a in ARMS], "deltas": [deltas[c] for c in ("plain","ephemeral")], "checks": checks}

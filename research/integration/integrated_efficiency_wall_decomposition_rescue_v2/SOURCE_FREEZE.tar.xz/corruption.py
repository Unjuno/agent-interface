#!/usr/bin/env python3
import copy,json,pathlib,tempfile,subprocess,sys
from science import compute
root=pathlib.Path(__file__).resolve().parent
fixture=json.loads((root/'fixture.json').read_text())
controls={}
# 1 source identity drift
x=copy.deepcopy(fixture); x['source_blobs']['integrated_audit']='0'*40
try: compute(x); controls['source_identity_drift']=False
except ValueError: controls['source_identity_drift']=True
# create a canonical result in temp
base=compute(fixture); base.update({'formal_invocations':1,'formal_reruns':0,'schema':'integrated-wall-decomposition-rescue-result-v2'})
def audit_mut(name, mut):
    y=copy.deepcopy(base); mut(y)
    with tempfile.NamedTemporaryFile('w',delete=False,suffix='.json') as f:
        json.dump(y,f,indent=2,sort_keys=True); f.write('\n'); p=f.name
    cp=subprocess.run([sys.executable,str(root/'audit.py'),p],capture_output=True,text=True)
    controls[name]=(cp.returncode!=0)
    pathlib.Path(p).unlink()
audit_mut('forbidden_local_time', lambda y: y['rows'][0].__setitem__('local_time', y['rows'][0]['unattributed_remainder_ms']))
audit_mut('modified_model_subprocess_effect', lambda y: y['rows'][0].__setitem__('retained_model_stage_ms','0'))
audit_mut('broken_wall_delta', lambda y: y['deltas'][0].__setitem__('persistent_wall_delta_ms','0'))
audit_mut('timing_attribution_laundered', lambda y: y['rows'][1].__setitem__('timing_attribution',True))
audit_mut('cached_tokens_added_as_input_accounting', lambda y: y.__setitem__('actual_input_tokens_including_cached', 999999))
out={'controls':controls,'all_rejected':all(controls.values())}
print(json.dumps(out,indent=2,sort_keys=True))
raise SystemExit(0 if out['all_rejected'] else 3)

import os,time,json,signal,subprocess,traceback,hashlib
from pathlib import Path
from Xlib import X,display,error,XK
from Xlib.ext import xtest
from PIL import Image
import vizdoom as vd
from runtime.guarded_x11_v1.cancel_supervisor import PrestartedCancellationSupervisor,x11_cancel_worker
from worker_module import guarded_worker

def main():
 out=Path('/out');mode=os.environ['MODE'];r={'mode':mode,'status':'running','samples':[],'task_success':None};d=None;game=None;x=None;owner=None;cleanup=None;code=None
 try:
  os.environ.update(DISPLAY=':163',SDL_VIDEODRIVER='x11',HOME='/tmp',XDG_CACHE_HOME='/tmp/cache')
  x=subprocess.Popen(['Xvfb',':163','-screen','0','1280x1024x24','-nolisten','tcp'],stdout=subprocess.DEVNULL,stderr=(out/'xvfb.log').open('wb'),start_new_session=True)
  for _ in range(100):
   try:d=display.Display(':163');break
   except Exception:time.sleep(.05)
  if d is None:raise RuntimeError('Xvfb unavailable')
  cfg=Path('/tmp/doom-custody.ini');cfg.write_text('[Doom.Bindings]\nf=+attack\n');wad=Path(vd.__file__).resolve().parent/'freedoom2.wad';r['iwad_sha256']=hashlib.sha256(wad.read_bytes()).hexdigest()
  game=vd.DoomGame();game.set_doom_game_path(str(wad));game.set_doom_scenario_path('');game.set_doom_map('MAP01');game.set_doom_config_path(str(cfg));game.set_mode(vd.Mode.ASYNC_SPECTATOR);game.set_ticrate(35);game.set_seed(991031);game.set_doom_skill(1);game.set_episode_timeout(2100);game.set_window_visible(True);game.set_sound_enabled(False);game.set_render_hud(True);game.set_screen_resolution(vd.ScreenResolution.RES_640X480);game.set_available_buttons([vd.Button.ATTACK]);game.set_available_game_variables([vd.GameVariable.SELECTED_WEAPON_AMMO,vd.GameVariable.HEALTH,vd.GameVariable.KILLCOUNT]);game.init()
  windows=[]
  for _ in range(250):
   windows=[]
   for w in d.screen().root.query_tree().children:
    try:
     title=w.get_wm_name()
     if title and 'DOOM' in title.upper() and w.get_attributes().map_state==X.IsViewable:windows.append(w)
    except error.BadWindow:pass
   if len(windows)==1:break
   if len(windows)>1:raise RuntimeError('ambiguous game window')
   time.sleep(.02)
  if len(windows)!=1:raise RuntimeError('game window unavailable')
  w=windows[0];d.set_input_focus(w.id,X.RevertToParent,X.CurrentTime);d.sync();time.sleep(.5);code=d.keysym_to_keycode(XK.string_to_keysym('f'))
  def sample(label):
   game.advance_action(1,True);s={'label':label,'host_ns':time.monotonic_ns(),'tic':game.get_episode_time(),'ammo':game.get_game_variable(vd.GameVariable.SELECTED_WEAPON_AMMO),'health':game.get_game_variable(vd.GameVariable.HEALTH),'kills':game.get_game_variable(vd.GameVariable.KILLCOUNT)};r['samples'].append(s);return s
  sample('before');g=w.get_geometry();raw=w.get_image(0,0,g.width,g.height,X.ZPixmap,0xffffffff);img=Image.frombytes('RGB',(g.width,g.height),raw.data,'raw','BGRX');img.save(out/'baseline.png');baseline=hashlib.sha256(img.crop((32,408,90,450)).tobytes()).hexdigest()
  sid='map01-short-grab-custody';cleanup=PrestartedCancellationSupervisor(x11_cancel_worker,expected_session_id=sid,startup_timeout_s=5.0);owner=PrestartedCancellationSupervisor(guarded_worker,expected_session_id=sid,startup_timeout_s=5.0);r['ready']={'owner_pid':owner.pid,'cleanup_pid':cleanup.pid,'baseline_hash':baseline,'before_input_ns':time.monotonic_ns()}
  req={'operation_id':'attack-1','session_id':sid,'target':w.id,'baseline_hash':baseline,'mode':mode};outcome=owner.run(req,deadline_monotonic_ns=time.monotonic_ns()+800_000_000);r['owner_outcome']=outcome
  custody=json.loads((out/'custody.json').read_text());down=json.loads((out/'down.json').read_text());r['custody']=custody;r['down']=down
  keys=d.query_keymap();r['down_after_owner']=bool(keys[code//8]&(1<<(code%8)));r['after_owner_ns']=time.monotonic_ns()
  if mode=='crash':
   if outcome.get('reason')!='transaction_deadline' or outcome.get('worker_retired') is not True:raise RuntimeError('owner not deadline-retired')
   creq={'operation_id':'cleanup-1','session_id':sid,'x_resource_base':custody['resource_base'],'owner_pid':custody['owner_pid'],'owner_process_retired':True,'owner_process_exitcode':outcome['worker_exitcode'],'display_name':':163','keys':custody['keys'],'buttons':[],'binding_revision':0,'owner_generation':custody['owner_generation']}
   r['cleanup']=cleanup.run(creq,deadline_monotonic_ns=time.monotonic_ns()+2_000_000_000)
  elif mode!='normal':raise ValueError('bad mode')
  keys=d.query_keymap();r['down_after_cleanup']=bool(keys[code//8]&(1<<(code%8)));r['after_cleanup_ns']=time.monotonic_ns();sample('after-cleanup')
  while time.monotonic_ns()<down['scheduled_late_ns']+200_000_000:time.sleep(.03)
  sample('after-late');keys=d.query_keymap();r['down_after_late']=bool(keys[code//8]&(1<<(code%8)));r['late_artifact']=(out/'late.json').exists();r['status']='completed'
 except BaseException as e:r['status']='error';r['error']=repr(e);(out/'traceback.txt').write_text(traceback.format_exc())
 finally:
  if owner is not None:owner.close()
  if cleanup is not None:cleanup.close()
  if d is not None and code is not None:
   try:
    keys=d.query_keymap()
    if keys[code//8]&(1<<(code%8)):xtest.fake_input(d,X.KeyRelease,code);d.sync();r['fallback_release']=True
   except BaseException as e:r['fallback_error']=repr(e)
  if game is not None:
   try:game.close()
   except BaseException as e:r['game_close_error']=repr(e)
  if d is not None:d.close()
  if x is not None and x.poll() is None:
   try:os.killpg(x.pid,signal.SIGTERM);x.wait(timeout=3)
   except BaseException as e:r['xvfb_close_error']=repr(e)
  (out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
if __name__=='__main__':main()

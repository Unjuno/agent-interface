import hashlib,json,os,time
from pathlib import Path
from Xlib import X,display,XK
from Xlib.ext import xtest
from PIL import Image

def guarded_worker(request):
 d=display.Display(':163');out=Path('/out');base=d.display.info.resource_id_base;pid=os.getpid();sid=request['session_id'];code=d.keysym_to_keycode(XK.string_to_keysym('f'));generation={'session_id':sid,'child_pid':pid,'x_resource_base':base,'binding_revision':0}
 custody={'owner_pid':pid,'resource_base':base,'owner_generation':generation,'keys':{'f':code},'buttons':[],'target':request['target']}
 with (out/'custody.json').open('x') as f:json.dump(custody,f);f.flush();os.fsync(f.fileno())
 grab=False;pressed=False
 try:
  d.grab_server();d.sync();grab=True;acquired=time.monotonic_ns();w=d.create_resource_object('window',request['target']);g=w.get_geometry();raw=w.get_image(0,0,g.width,g.height,X.ZPixmap,0xffffffff);image=Image.frombytes('RGB',(g.width,g.height),raw.data,'raw','BGRX');digest=hashlib.sha256(image.crop((32,408,90,450)).tobytes()).hexdigest()
  if digest!=request['baseline_hash']:return {'operation_id':request['operation_id'],'session_id':sid,'status':'refused','reason':'crop_mismatch'}
  xtest.fake_input(d,X.KeyPress,code);pressed=True;d.sync();down=time.monotonic_ns();d.ungrab_server();d.sync();grab=False;ungrab=time.monotonic_ns()
  with (out/'down.json').open('x') as f:json.dump({'grab_ns':acquired,'down_ns':down,'ungrab_ns':ungrab,'scheduled_late_ns':ungrab+2_000_000_000,'crop_sha256':digest},f);f.flush();os.fsync(f.fileno())
  time.sleep(2.0 if request['mode']=='crash' else .085)
  xtest.fake_input(d,X.KeyRelease,code);d.sync();pressed=False
  if request['mode']=='crash':
   xtest.fake_input(d,X.KeyPress,code);xtest.fake_input(d,X.KeyRelease,code);d.sync();(out/'late.json').write_text('late input sent')
  return {'operation_id':request['operation_id'],'session_id':sid,'status':'completed','release_ns':time.monotonic_ns()}
 finally:
  if pressed:xtest.fake_input(d,X.KeyRelease,code);d.sync()
  if grab:d.ungrab_server();d.sync()
  d.close()

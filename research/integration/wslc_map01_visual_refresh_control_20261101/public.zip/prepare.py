import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parent
old=root.parent/'map01-hud-visible-effect-20261101'
manifest=json.loads((old/'frozen-manifest.json').read_text())
for name,digest in manifest.items():
    data=(old/name).read_bytes();assert hashlib.sha256(data).hexdigest()==digest
    target=root/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
runner=root/'runner.py'; text=runner.read_text(encoding='utf8')
needle="  while time.monotonic_ns()<visual_deadline:\n   v=bridge.observe();"
replacement="""  while time.monotonic_ns()<visual_deadline:
   if os.environ['REFRESH_MODE']=='advance':
    t0=time.monotonic_ns();game.advance_action(1,True);t1=time.monotonic_ns()
    visual.setdefault('fixture_advances',[]).append({'started_ns':t0,'ended_ns':t1})
   v=bridge.observe();"""
assert text.count(needle)==1
runner.write_text(text.replace(needle,replacement),encoding='utf8',newline='\n')
manifest['runner.py']=hashlib.sha256(runner.read_bytes()).hexdigest()
(root/'frozen-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf8')
launch=(old/'launch.py').read_text(encoding='utf8')
launch=launch.replace("'--env','POST_MODE='+c['post_mode'],","'--env','POST_MODE='+c['post_mode'],'--env','REFRESH_MODE='+c['refresh_mode'],")
assert "'REFRESH_MODE='+c['refresh_mode']" in launch
launch=launch.replace("'map01-visibleeffect-'","'map01-refreshcontrol-'")
(root/'launch.py').write_text(launch,encoding='utf8',newline='\n')
arms=[('ew01','fire','passive'),('ew02','fire','advance'),('ew03','withhold','advance'),('ew04','withhold','passive')]
for ident,mode,refresh in arms:
    p=root/ident;p.mkdir();(p/'output').mkdir();(p/'exchange').mkdir()
    c={'allocation':ident,'route':'watch','seed':991040,'hud':'on','post_mode':mode,'refresh_mode':refresh,
       'order':[f'{i}:{m}:{r}' for i,m,r in arms],'freeze_main':'82f5d02c5c813dbc7c8246137687badac9b3f84f',
       'image':'sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25',
       'manifest_sha256':hashlib.sha256((root/'frozen-manifest.json').read_bytes()).hexdigest(),
       'launcher_sha256':hashlib.sha256((root/'launch.py').read_bytes()).hexdigest(),
       'intervention':'before each passive HUD capture either call game.advance_action(1,True) as fixture or do not; no score or hidden state is provided to recognizer',
       'criterion':'record 48 recognition, 49 timeout or unknown within cooperative 600ms; preserve prior watch/review/alias checks, all inputs and releases, independent controls and simulator samples',
       'stop':'one attempt per arm, no success retry; unknown remains unknown; stop block on unresolved input or infrastructure error',
       'limits':'separate sequential games and fixed seed/layout/template; simulator frame-advance changes environment and is not a production screen API'}
    (p/'conditions.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf8')
print('four-way visual refresh control frozen')

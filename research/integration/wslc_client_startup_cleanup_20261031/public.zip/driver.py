import json,subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parent;p=root/sys.argv[1];c=json.loads((p/'conditions.json').read_text());out=p/'out'
cmd=['wslc','run','--rm','--name','startup-cleanup-'+c['allocation']+'-20261031','--network','none','--cpus','1','--memory','1g','--pull','never','--entrypoint','/bin/sh','--mount',f'type=bind,source={root / "source"},target=/source,readonly','--mount',f'type=bind,source={root / "run.sh"},target=/run.sh,readonly','--mount',f'type=bind,source={out},target=/out','--env','CASE='+c['case'],'sha256:9841e60e91b1c037a8e7de6a7cb9737558352b15f052912d92af819487fe02ba','/run.sh']
t=time.monotonic()
try:
 r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60);v={'exit_code':r.returncode,'elapsed_seconds':round(time.monotonic()-t,3),'timeout':False};(out/'stdout.bin').write_bytes(r.stdout);(out/'stderr.bin').write_bytes(r.stderr)
except subprocess.TimeoutExpired as e:
 v={'exit_code':None,'elapsed_seconds':round(time.monotonic()-t,3),'timeout':True};(out/'stdout.bin').write_bytes(e.stdout or b'');(out/'stderr.bin').write_bytes(e.stderr or b'')
(out/'launcher.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8');print(json.dumps(v));raise SystemExit(0 if v['exit_code']==0 else 1)

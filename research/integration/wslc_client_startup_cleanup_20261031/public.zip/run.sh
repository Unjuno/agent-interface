#!/bin/sh
set -eu
Xvfb :91 -screen 0 1280x800x24 -nolisten tcp -ac >/out/xvfb.log 2>&1 &
xpid=$!
trap 'kill "$xpid" 2>/dev/null || true' EXIT
export DISPLAY=:91 PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH=/source/research/live_control:/source/research/observation_gating:/source/research/observation_tiles:/source/research/real_apps_v1:/source
sleep 1
openbox --sm-disable >/out/openbox.log 2>&1 &
python3 - <<'PY'
import json,os
from pathlib import Path
from integrated_efficiency_client_v1 import RuntimeClient
case=os.environ['CASE'];os.environ['AGENT_INTERFACE_CHROMIUM']='/missing/chromium-for-negative-control' if case=='missing' else '/usr/bin/chromium'
c=RuntimeClient(Path('/out')/'client',991038);record={'case':case,'model_calls':0}
try:
 try:
  c.start()
  if case!='valid':raise AssertionError('missing executable unexpectedly reached ready')
  record.update(status='ready',app=c.ready.get('app'),ready_event=c.ready.get('event'))
 finally:
  if case=='valid':c.close()
except RuntimeError as e:
 if case!='missing' or 'runtime did not emit ready' not in str(e):raise
 record.update(status='expected_failure',error_type=type(e).__name__,message=str(e),child_exited=c.process.poll() is not None,stderr_closed=c.errors.closed,temp_removed=not Path(c.temporary.name).exists(),stderr_has_missing='FileNotFoundError' in (Path('/out')/'client/stderr.txt').read_text())
 if not all(record[k] for k in ('child_exited','stderr_closed','temp_removed','stderr_has_missing')):raise AssertionError('incomplete cleanup')
Path('/out/receipt.json').write_text(json.dumps(record,indent=2)+'\n')
PY

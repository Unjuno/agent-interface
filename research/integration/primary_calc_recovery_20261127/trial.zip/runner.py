"""One isolated Calc task with injected partial input and explicit primary recovery."""
import hashlib,json,os,select,shutil,signal,subprocess,time,traceback,xml.etree.ElementTree as ET
from pathlib import Path
from Xlib import X,XK,display
from PIL import Image
OUT=Path('/out'); INPUT=Path('/input'); actors=[];logs=[];d=None
FIXTURE='462beebbcb020ccf49af3cc49520f789a816cc3fb97597cefbd6940ffc26aeb1'
NAMEBOX='2e86f3a0f6d87ee4fb4e5ffeb7cfd159d715cb5f6f8177b0ede83784d49088cf'
env=dict(os.environ,DISPLAY=':153',HOME='/tmp',PYTHONPATH='/src',SAL_USE_VCLPLUGIN='gen')
result={'schema':'primary-calc-recovery-v1','passed':False,'model_calls':0,'input_attempted':False,
        'scope':'one scripted Calc task with first keydown and first release fault; no arbitrary crash'}
def save(name,obj):
 with (OUT/name).open('x',encoding='utf8') as f:json.dump(obj,f,sort_keys=True,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def spawn(name,args):
 f=(OUT/(name+'.log')).open('xb');logs.append(f);p=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);actors.append(p);return p
def neutral():
 keys=d.query_keymap();mask=d.screen().root.query_pointer().mask
 return {'keys_down':[i for i in range(256) if keys[i//8]&(1<<(i%8))],'buttons_mask':mask&(X.Button1Mask|X.Button2Mask|X.Button3Mask|X.Button4Mask|X.Button5Mask)}
class Primary:
 def __init__(self,name,args):
  self.name=name;self.lines=0
  config={'host':{'command':'/usr/bin/python3','args':args,'evidenceDirectory':'/out/'+name+'-host'},'route':'guarded-local','exchangeDirectory':'/out/'+name+'-exchange'}
  save(name+'-config.json',config);err=(OUT/(name+'.stderr')).open('xb');logs.append(err)
  self.p=subprocess.Popen(['/usr/local/bin/node','/input/host/primary_stdio.mjs','--config','/out/'+name+'-config.json'],env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,start_new_session=True,bufsize=0);actors.append(self.p)
  if self.read()['status']!='ready':raise ValueError(name+' not ready')
 def read(self):
  buf=bytearray();deadline=time.monotonic()+30
  while not buf.endswith(b'\n'):
   left=deadline-time.monotonic()
   if left<=0 or not select.select([self.p.stdout],[],[],left)[0]:raise TimeoutError(self.name+' response timeout')
   b=os.read(self.p.stdout.fileno(),1)
   if not b:raise ValueError(self.name+' stdout closed')
   buf.extend(b)
   if len(buf)>2000000:raise ValueError('oversize')
  self.lines+=1;row=json.loads(buf);save(self.name+'-line-%02d.json'%self.lines,row);return row
 def command(self,i,method,args):
  self.p.stdin.write((json.dumps({'id':i,'method':method,'args':args},separators=(',',':'))+'\n').encode());self.p.stdin.flush();return self.read()
 def expect(self,i,method,args):
  row=self.command(i,method,args)
  if row.get('status')!='returned':raise ValueError(self.name+' '+method+' failed: '+str(row.get('status')))
  return row
 def reply(self,i):return json.loads((OUT/(self.name+'-exchange')/('original-reply-%d.json'%i)).read_text())
 def finish(self):
  self.p.stdin.close()
  if self.read()['status']!='terminal':raise ValueError('terminal missing')
  self.p.wait(timeout=10)
  if self.p.returncode!=0:raise ValueError('primary exit failed')
try:
 if hashlib.sha256((INPUT/'blank.fods').read_bytes()).hexdigest()!=FIXTURE:raise ValueError('fixture differs')
 shutil.copyfile(INPUT/'blank.fods','/tmp/blank.fods')
 spawn('xvfb',['Xvfb',':153','-screen','0','1280x800x24','-nolisten','tcp','-ac'])
 for i in range(100):
  try:d=display.Display(':153');break
  except Exception:time.sleep(.05)
 if d is None:raise ValueError('no X')
 spawn('openbox',['openbox','--sm-disable'])
 calc=spawn('calc',['libreoffice','-env:UserInstallation=file:///tmp/primary-calc-profile','--calc','--nologo','--norestore','--nofirststartwizard','/tmp/blank.fods'])
 def walk(w,depth=0):
  if depth>6:return []
  rows=[]
  for c in w.query_tree().children:
   try:
    title=c.get_wm_name();title=title.decode(errors='replace') if isinstance(title,bytes) else str(title or '')
    rows.append((c.id,title,c.get_attributes().map_state));rows.extend(walk(c,depth+1))
   except Exception:pass
  return rows
 deadline=time.monotonic()+25;found=[]
 while time.monotonic()<deadline:
  found=[x for x in walk(d.screen().root) if 'blank.fods' in x[1].lower() and 'calc' in x[1].lower() and x[2]==X.IsViewable]
  if len(found)==1:break
  if len(found)>1 or calc.poll() is not None:raise ValueError('ambiguous or exited Calc')
  time.sleep(.05)
 if len(found)!=1:raise ValueError('Calc not found')
 time.sleep(1);save('target.json',{'id':found[0][0],'title':found[0][1]});save('targets.json',{'app':found[0][0]})
 first=Primary('first',['/input/relay.py'])
 first.expect(1,'observe',[])
 with Image.open(OUT/'first-exchange/image-1-1.png') as im:
  if hashlib.sha256(im.convert('RGB').crop((0,97,42,119)).tobytes()).hexdigest()!=NAMEBOX:raise ValueError('initial A1 not matched')
 first.expect(2,'review',[1,{'task':'calc-731','phase':'initial','reason':'Inspected fixture-specific A1 name-box pixels in original image.'}])
 first.expect(3,'mint',['entry',1,[440,28],[30,14]])
 first.expect(4,'acknowledgeText',[2,{'task':'calc-731','phase':'mint','reason':'Read original entry registration.'}])
 (OUT/'first-server/arm-recovery-fault').write_text('arm once',encoding='ascii')
 result['input_attempted']=True
 failed=first.expect(5,'input',['entry',[15,7],'keyboard',[{'op':'text','text':'731'}]])
 reply=first.reply(5);meta=json.loads(reply['result']['content'][0]['text']);save('first-failure.json',meta)
 if meta.get('status')!='execution_failed' or meta['session']['recovery_required'] is not True or not failed['result']['caller_state']['stopped']:raise ValueError('fault not confirmed')
 keycode=d.keysym_to_keycode(XK.string_to_keysym('7'));before=neutral();save('before-recovery.json',before)
 if keycode not in before['keys_down']:raise ValueError('7 key not held')
 revision=meta['session']['binding_revision'];first.expect(6,'call',['interface_guarded_recover_input',{'current_binding_revision':revision}])
 recover=json.loads(first.reply(6)['result']['content'][0]['text']);save('recovery.json',recover)
 if recover['status']!='input_recovered' or not recover['release']['verified']:raise ValueError('release not verified')
 after=neutral();save('after-recovery.json',after)
 if after!={'keys_down':[],'buttons_mask':0}:raise ValueError('not neutral after recovery')
 first.expect(7,'call',['interface_close',{}]);first.finish()
 second=Primary('second',['-m','runtime.cli_v1.mcp_relay','--','--targets','/out/targets.json','--output-directory','/out/second-server','--session-mode','guarded-x11','--display',':153'])
 second.expect(1,'observe',[]);capture=second.reply(1);obs=json.loads(capture['result']['content'][0]['text'])
 with Image.open(OUT/'second-exchange/image-1-1.png') as im:
  im=im.convert('RGB')
  if hashlib.sha256(im.crop((0,97,42,119)).tobytes()).hexdigest()!=NAMEBOX:raise ValueError('recovery A1 not matched')
  im.crop((230,97,275,119)).resize((450,220),Image.Resampling.NEAREST).save(OUT/'recovery-formula.png')
 proc=subprocess.run(['tesseract','/out/recovery-formula.png','stdout','--psm','8','-c','tessedit_char_whitelist=0123456789'],capture_output=True,text=True,timeout=5)
 save('ocr.json',{'text':proc.stdout.strip(),'stderr':proc.stderr,'exit_code':proc.returncode,'image_sha256':hashlib.sha256((OUT/'recovery-formula.png').read_bytes()).hexdigest()})
 if proc.returncode!=0 or proc.stdout.strip()!='7':raise ValueError('expected observed partial value 7 unavailable')
 second.expect(2,'review',[1,{'task':'calc-731','phase':'recovery','reason':'Inspected A1 name box and OCR of formula bar; observed partial 7 in original image.'}])
 second.expect(3,'mint',['continue',obs['source']['sequence'],[440,28],[30,14]])
 second.expect(4,'acknowledgeText',[2,{'task':'calc-731','phase':'mint','reason':'Read original continuation reference.'}])
 row=second.expect(5,'input',['continue',[15,7],'keyboard',[{'op':'text','text':'31'},{'op':'key_chord','keys':['ENTER']},{'op':'wait_update','timeout_ms':300},{'op':'key_chord','keys':['CTRL','s']}]])
 if row['result']['caller_state']['stopped']:raise ValueError('continuation stopped')
 path=Path('/tmp/blank.fods');end=time.monotonic()+5
 while time.monotonic()<end and hashlib.sha256(path.read_bytes()).hexdigest()==FIXTURE:time.sleep(.05)
 data=path.read_bytes();(OUT/'saved.fods').write_bytes(data)
 ns={'t':'urn:oasis:names:tc:opendocument:xmlns:table:1.0','o':'urn:oasis:names:tc:opendocument:xmlns:office:1.0'}
 cell=ET.fromstring(data).find('.//t:table/t:table-row/t:table-cell',ns)
 if cell is None or cell.get('{'+ns['o']+'}value')!='731' or cell.get('{'+ns['t']+'}formula') is not None:raise ValueError('saved value differs')
 second.expect(6,'call',['interface_close',{}]);second.finish()
 final=neutral();save('final-neutral.json',final)
 if final!={'keys_down':[],'buttons_mask':0}:raise ValueError('final nonneutral')
 result.update(passed=True,observed_partial='7',saved_sha256=hashlib.sha256(data).hexdigest())
except Exception as error:
 result.update(error_type=type(error).__name__,error=str(error));(OUT/'traceback.txt').write_text(traceback.format_exc())
finally:
 if d is not None:
  try:save('final-observed-neutral.json',neutral());d.close()
  except Exception as error:result.update(passed=False,neutral_error=str(error))
 for p in reversed(actors):
  if p.poll() is None:
   try:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=3)
   except Exception:
    try:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=3)
    except Exception as error:result.update(passed=False,cleanup_error=str(error))
 for f in logs:f.close()
 save('result.json',result)

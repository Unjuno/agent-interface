"""One observed dict-iterator behavioral mismatch; does not mutate source."""
import importlib.util,json,pathlib,sys
root=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(root/'src'))
spec=importlib.util.spec_from_file_location('historical_history',str(root/'history_baseline.py'))
historical=importlib.util.module_from_spec(spec);spec.loader.exec_module(historical)
from runtime.guarded_x11_v1.history import ObservationHistory as Hybrid
results={}
for name,cls in [('baseline',historical.ObservationHistory),('hybrid',Hybrid)]:
    history=cls();history._records[1]='one';history._records[2]='two'
    iterator=iter(history._records);first=next(iterator);history._records[3]='three'
    try:results[name]={'first':first,'remaining':list(iterator),'error':None}
    except Exception as error:results[name]={'first':first,'remaining':None,'error':type(error).__name__}
print(json.dumps(results,indent=2))

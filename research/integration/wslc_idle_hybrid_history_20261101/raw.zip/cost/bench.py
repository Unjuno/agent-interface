"""Metadata-only costs for the actual hybrid ObservationHistory candidate."""
import json,os,pathlib,random,statistics,time
from PIL import Image
from history_baseline import ObservationHistory as Baseline
from runtime.guarded_x11_v1.history import ObservationHistory as Hybrid

def main():
    order=os.environ['SIZE_ORDER'];sizes=[1000,10000,100000]
    if order=='descending':sizes.reverse()
    elif order!='ascending':raise ValueError('bad order')
    image=Image.new('RGB',(16,16));obs={'native':{'width':16,'height':16,'sha256':'raw','artifact':{'path':'unused','sha256':'encoded','source_raw_sha256':'raw'}}}
    value=(obs,image);record=(obs,('unused','encoded',(16,16)));rows=[]
    for size in sizes:
        baseline=Baseline();hybrid=Hybrid()
        baseline._records={i:record for i in range(1,size+1)}
        for i in range(1,size+1):hybrid._records[i]=record
        for i in (size-1,size):baseline._decoded[i]=image;hybrid._decoded[i]=image
        assert len(baseline)==len(hybrid)==size
        rng=random.Random(3191+size);keys=[rng.randrange(1,size+1) for _ in range(1024)]
        names=('baseline_stage','hybrid_stage','baseline_random','hybrid_random')
        samples={name:[] for name in names}
        for trial in range(41):
            for name in (names if trial%2==0 else names[::-1]):
                history=baseline if name.startswith('baseline') else hybrid
                start=time.perf_counter_ns()
                if name.endswith('stage'):
                    staged=history.fork();staged[size+1]=value;del staged
                else:
                    count=sum(len(history._records[k]) for k in keys)
                elapsed=time.perf_counter_ns()-start
                if name.endswith('random'):assert count==2048
                samples[name].append(elapsed)
        fallback=[]
        for _ in range(9):
            staged=hybrid.fork();start=time.perf_counter_ns();staged[size//2]=value;elapsed=time.perf_counter_ns()-start
            assert staged._records._fallback is not None and hybrid._records._fallback is None
            fallback.append(elapsed);del staged
        rows.append({'size':size,'samples_ns':samples,'medians_ns':{n:statistics.median(v) for n,v in samples.items()},
                     'fallback_overwrite_ns':fallback,'fallback_median_ns':statistics.median(fallback)})
    result={'status':'completed','order':order,'repetitions':41,'fallback_repetitions':9,'rows':rows}
    pathlib.Path('/out/result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()

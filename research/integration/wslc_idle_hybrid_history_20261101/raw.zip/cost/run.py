import hashlib,json,pathlib,subprocess,sys,time
root=pathlib.Path(__file__).resolve().parent;p=root/sys.argv[1];c=json.loads((p/'conditions.json').read_text())
if hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()!=c['manifest_sha256']:raise RuntimeError('manifest changed')
for name,digest in json.loads((root/'manifest.json').read_text()).items():
    if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('source changed '+name)
cmd=['wslc','run','--rm','--name',c['allocation'],'--network','none','--cpus','1','--memory','1g','--pull','never',
     '--mount',f'type=bind,source={root},target=/case,readonly','--mount',f'type=bind,source={p / "output"},target=/out',
     '--env','PYTHONPATH=/case/src:/case','--env','PYTHONDONTWRITEBYTECODE=1','--env','SIZE_ORDER='+c['order'],
     '--entrypoint','timeout',c['image'],'--signal=TERM','--kill-after=3s','90s','python3','-B','/case/bench.py']
start=time.monotonic()
with (p/'stdout').open('wb') as a,(p/'stderr').open('wb') as b:
    process=subprocess.run(cmd,stdout=a,stderr=b,timeout=110,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
(p/'launcher-result.json').write_text(json.dumps({'returncode':process.returncode,'elapsed_seconds':time.monotonic()-start},indent=2)+'\n')
print(json.dumps({'returncode':process.returncode}),flush=True);sys.exit(process.returncode)

"""Real Xvfb; instrument staging in a direct bridge, then score a fresh task."""
import json, os, pathlib, subprocess, sys, threading, time, traceback
from Xlib import X, display
from runtime.guarded_x11_v1.bridge import NativeHandleBridge
from runtime.guarded_x11_v1.history import ObservationHistory
from runtime.cli_v1.owned_guarded_session import OwnedGuardedSessionOwner

def main():
    out = pathlib.Path('/out'); mode = os.environ['CONTROL_MODE']
    r = {'status': 'started', 'mode': mode, 'events': []}
    def mark(name): r['events'].append({'name': name, 'ns': time.monotonic_ns()})
    server = target = conn = bridge = fresh = worker = None
    entered, resume = threading.Event(), threading.Event()
    original = ObservationHistory.__setitem__
    try:
        server = subprocess.Popen(['Xvfb', ':196', '-screen', '0', '640x480x24', '-nolisten', 'tcp'], stdout=(out/'xvfb.log').open('wb'), stderr=subprocess.STDOUT)
        for _ in range(100):
            if server.poll() is not None: raise RuntimeError('Xvfb exited')
            try: conn = display.Display(':196'); break
            except Exception: time.sleep(.05)
        if conn is None: raise RuntimeError('Xvfb unavailable')
        target = subprocess.Popen(['python3', '-B', '/target.py'], stdout=(out/'target.stdout').open('wb'), stderr=(out/'target.stderr').open('wb'), env=dict(os.environ, TEST_DISPLAY=':196'))
        until = time.monotonic()+4
        while not (out/'target-ready.json').exists():
            if target.poll() is not None or time.monotonic() >= until: raise RuntimeError('target unavailable')
            time.sleep(.01)
        ready = json.loads((out/'target-ready.json').read_text())
        window = conn.create_resource_object('window', ready['xid']); conn.set_input_focus(window, X.RevertToParent, X.CurrentTime); conn.sync()
        assert not any(bytes(conn.query_keymap())) and not (conn.screen().root.query_pointer().mask & 0x1f00)
        bridge = NativeHandleBridge(':196', {'app': window.id}, 'app', str(out/'bridge'), process_identity=True, query_worker=True, observation_worker=True)
        def pause(history, key, value):
            original(history, key, value); mark('staged'); entered.set()
            if not resume.wait(3): raise RuntimeError('staging fixture timeout')
            mark('stage_resumed')
        ObservationHistory.__setitem__ = pause
        capture = {}
        def invoke():
            try: capture['observation'] = bridge.observe_idle_until(time.monotonic_ns()+5_000_000_000)
            except Exception as e: capture['error'] = type(e).__name__ + ': ' + str(e)
            finally: mark('capture_returned')
        with bridge.cancellation_scope('staging', cancel_when_idle=True, single_idle_observation=True):
            worker = threading.Thread(target=invoke); worker.start()
            if not entered.wait(3): raise RuntimeError('staging not reached')
            r['sequence_while_staged'] = bridge.sequence; r['visible_while_staged'] = 1 in bridge.history
            try: bridge.mint_reference('uncommitted', 1, [30,30], region_size=(12,12)); r['mint_while_staged'] = 'unexpected_success'
            except KeyError: r['mint_while_staged'] = 'rejected'
            if mode == 'cancel': r['cancel'] = bridge.request_cancel('staging'); mark('cancel_returned')
            elif mode != 'publish': raise RuntimeError('unknown mode')
            resume.set(); worker.join(3)
            if worker.is_alive(): raise RuntimeError('capture did not finish')
            r['capture'] = capture; r['sequence_after'] = bridge.sequence; r['visible_after'] = 1 in bridge.history
            assert r['sequence_while_staged'] == 0 and not r['visible_while_staged'] and r['mint_while_staged'] == 'rejected'
            if mode == 'cancel':
                assert r['cancel']['status'] == 'cancel_requested' and 'error' in capture and bridge.sequence == 0 and not r['visible_after']
            else:
                assert capture['observation']['sequence'] == 1 and bridge.sequence == 1 and r['visible_after']
        ObservationHistory.__setitem__ = original
        bridge.close(); bridge = None; mark('bridge_closed')
        (out/'fresh').mkdir(); fresh = OwnedGuardedSessionOwner({'app':window.id},out/'fresh',':196',process_identity=True,query_worker=True,observation_worker=True)
        fresh.get(); obs = fresh.observe_idle_until(deadline_ns=time.monotonic_ns()+3_000_000_000,cancel_token='fresh')
        g=obs['source']['pointer_binding']['geometry']; (out/'mint').mkdir(); (out/'action').mkdir()
        minted=fresh.invoke_guarded('guarded_mint',{'alias':'field','source_sequence':obs['source']['sequence'],'point':[g[0]+20,g[1]+20],'region_size':[12,12]},out/'mint')
        action=fresh.invoke_guarded('guarded_input',{'alias':'field','offset':minted['offset'],'interaction':'keyboard','observe_after':False,'tail':[{'op':'key_chord','keys':['a']}]},out/'action')
        r['mint']=minted; r['action']=action; mark('fresh_action_returned')
        until=time.monotonic()+2
        while time.monotonic()<until:
            try: target_result=json.loads((out/'target-events.json').read_text())
            except (FileNotFoundError, json.JSONDecodeError): time.sleep(.01); continue
            if target_result['value']=='a' and any(e['type']=='release' and e['key']=='a' for e in target_result['events']): break
            time.sleep(.01)
        else: raise RuntimeError('target effect/release absent')
        r['target_result']=target_result; r['fresh_close']=fresh.close(); fresh=None
        conn.sync(); r['input_neutral']=not any(bytes(conn.query_keymap())) and not (conn.screen().root.query_pointer().mask & 0x1f00)
        assert minted['status']=='minted' and action['status']=='completed' and action['result']['execution']['releases'][-1]['verified'] and r['input_neutral']
        r['status']='passed'
    except BaseException as e:
        r.update(status='failed',error=repr(e),traceback=traceback.format_exc())
    finally:
        resume.set(); ObservationHistory.__setitem__ = original
        if worker is not None and worker.is_alive(): worker.join(3)
        for name, obj in [('bridge',bridge),('fresh',fresh)]:
            if obj is not None:
                try: r[name+'_cleanup']=obj.close()
                except Exception as e: r[name+'_cleanup_error']=repr(e); r['status']='failed'
        if target is not None:
            (out/'target-stop').write_text('stop')
            try: target.wait(timeout=3)
            except subprocess.TimeoutExpired: target.terminate(); target.wait(); r['status']='failed'
            r['target_exit']=target.returncode
        if conn is not None: conn.close()
        if server is not None and server.poll() is None:
            server.terminate()
            try: server.wait(timeout=5)
            except subprocess.TimeoutExpired: server.kill(); server.wait(); r['status']='failed'
        r['server_exit']=None if server is None else server.poll()
        (out/'result.json').write_text(json.dumps(r,indent=2)+'\n'); print(json.dumps(r),flush=True)
    sys.exit(0 if r['status']=='passed' else 1)

if __name__ == "__main__": main()

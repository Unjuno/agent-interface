# Source acquisition / retained local limitations

No formal case was started during acquisition. GitHub direct DNS and Docker CLI were unavailable in this supplied container. Unsupported generic artifact/workflow collection GETs returned INVALID_ARGUMENT; the dedicated artifact download action succeeded.

First acquired artifact10611580885 (177970 bytes; SHA256 6a83f5e9b37d3c6ab7bdedb39aebd728d5391e3964f4231f9d528c26ca5dd4b1) preceded the current CLI diagnostics. It was inspected only and excluded, not patched into a candidate. Correct artifact10614238401 from run35540217528 contains25 source files matching pinned main Git blobs, plus two newline-only packaging initializers. SOURCE_PARITY.json defines the exact selected closure. No package installation or repository/runtime mutation occurred.

Previous r9b2 20-session pilot ZIP SHA256 848c480aff09c59016cdf033f3974974a63ac0f01207939db53a2dcfe94c6a9c is a conversation artifact, not duplicated in this new evidence. Its immutable read-only audit reproduced1749 checks and12 controls. No historical GUI run was repeated or pooled. Its four source files are copied unchanged here.

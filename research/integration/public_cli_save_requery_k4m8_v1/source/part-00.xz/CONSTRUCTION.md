# Excluded construction, before public source freeze

attempt01: actual prefix/save/native observation completed; gate expected Tk client in focus ancestry but focused native wrapper was the client's parent. STOP_FOCUS_NOT_READY before suffix, app supervisor exit -15, no terminal key observation inferred. Raw and original run.py retained. Not a formal outcome.

Preformal repair: accept only exact focused client/descendant or its immediately observed non-screen-root native parent, additionally require app focus .entry and no live modal. No shared runtime or inherited app/policy changed.

attempt02: two cases (one lost outcome recovered; one stale source refused). Both complete; raw audit894 checks/errors=[];12 effective corruption controls reject. attempt03: four separate cases NO_REQUERY missing, twice-missing candidate, canceled candidate, changed-queue candidate; audit1555 checks/errors=[]. No construction row enters formal.

First unit wrapper used nonexistent Admission.reason for three checks. All14 tests ran, three wrapper errors; original test source/stdout/stderr retained. Before freeze, corrected field to actual Admission.error. Unchanged14 tests pass. Source gates/scheduling/interface semantics are unaffected.

Final source includes outer launcher receipts; no formal process has yet started. Original acquisition limitations and previous pilot audit are retained separately.

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
import zipfile
from unittest import mock
from pathlib import Path

from runtime.distribution_v2.build import FIXED_TIME, GENERATED, SOURCE_FILES, SUPPORT, build


class PortableDistributionTests(unittest.TestCase):
    def test_optional_host_bundle_uses_exact_committed_files_and_refuses_conflict(self):
        import hashlib
        from runtime.distribution_v2.build import HOST_SOURCE_FILES
        root = Path(__file__).resolve().parents[2]
        revision = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip()
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            plain = build(root, td/'plain.pyz', td/'plain.json', td/'plain.sum')
            bundled = build(root, td/'bundle.pyz', td/'bundle.json', td/'bundle.sum', host_directory=td/'host')
            self.assertEqual((td/'plain.pyz').read_bytes(), (td/'bundle.pyz').read_bytes())
            self.assertNotIn('host_bundle', plain)
            self.assertTrue((td/'host/FEEDBACK.md').is_file(), 'linked feedback guide must ship with host')
            self.assertTrue((td/'host/primary_exchange.mjs').is_file(), 'primary exchange adapter must ship with host')
            self.assertTrue((td/'host/primary_stdio.mjs').is_file(), 'primary stdio entry must ship with host')
            meta = json.loads((td/'host/HOST_MANIFEST.json').read_bytes())
            self.assertEqual(meta['source_revision'], revision)
            for rel in HOST_SOURCE_FILES:
                expected = subprocess.check_output(['git', '-C', str(root), 'show', f'{revision}:{rel}'])
                self.assertEqual((td/'host'/Path(rel).name).read_bytes(), expected)
            for line in (td/'host/SHA256SUMS').read_text().splitlines():
                digest, name = line.split('  ', 1)
                self.assertEqual(hashlib.sha256((td/'host'/name).read_bytes()).hexdigest(), digest)
            before = {p: p.read_bytes() for p in td.rglob('*') if p.is_file()}
            with self.assertRaises(FileExistsError):
                build(root, td/'bundle.pyz', td/'bundle.json', td/'bundle.sum', host_directory=td/'host')
            self.assertEqual({p: p.read_bytes() for p in td.rglob('*') if p.is_file()}, before)

    def test_guarded_method_available_without_optional_dependencies(self):
        root = Path(__file__).resolve().parents[2]
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            archive = td/'runtime.pyz'
            build(root, archive, td/'manifest.json', td/'sum')
            code = """
import sys
sys.path.insert(0, sys.argv[1])
from runtime.guarded_x11_v1.form import fill_and_submit
events = []
class Bridge:
    def click(self, alias, offset, **kwargs):
        events.append(alias)
        return {'status':'completed','recovery_required':False,
            'execution':{'releases':[{'verified':True,'keys_down':[],'buttons_down':[]}]}}
result = fill_and_submit(Bridge(), {'field':('field',[3,3]), 'submit':('save',[2,2])},
    'text', wait_ms=0, on_step=lambda name, result: events.append(name))
assert events == ['field','entered','save','saved']
assert result['task_success'] is None and result['replay_allowed'] is False
assert 'PIL' not in sys.modules and 'Xlib' not in sys.modules
print('archive method passed without optional dependencies')
"""
            run = subprocess.run([sys.executable, '-I', '-S', '-c', code, str(archive)],
                                 cwd=td, capture_output=True, text=True, timeout=30)
            self.assertEqual(run.returncode, 0, run.stdout + run.stderr)

    def test_public_validation_outside_checkout_without_dependencies(self):
        root = Path(__file__).resolve().parents[2]
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            out = td / 'runtime.pyz'
            build(root, out, td / 'manifest.json', td / 'sum')
            path = td / 'program.json'
            valid = {'schema': 'agent-interface/program-v1', 'program_id': 'portable',
                     'source': {'observation_seq': 0, 'binding_revision': 0},
                     'authority': {'lease_id': 'expired', 'expires_at_ns': 1},
                     'terminal': {'release_all_required': True},
                     'ops': [{'op': 'release_all'}]}
            for raw, code, status in [(json.dumps(valid), 0, 'valid'),
                                      ('{}', 1, 'invalid'), ('{', 2, 'input_error')]:
                path.write_text(raw, encoding='utf-8')
                result = subprocess.run([sys.executable, '-S', str(out), 'validate',
                                         '--program', str(path)], cwd=td,
                                        capture_output=True, text=True, timeout=10)
                self.assertEqual(result.returncode, code, result.stderr)
                self.assertEqual(result.stderr, '')
                row = json.loads(result.stdout)
                self.assertEqual(row['status'], status)
                self.assertIs(row['side_effect_authority'], False)
                self.assertEqual(row['runtime_admission'], 'not_evaluated')
                self.assertEqual(path.read_text(encoding='utf-8'), raw)

    def test_cli_remains_usable_without_optional_mcp_dependency(self):
        root = Path(__file__).resolve().parents[2]
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            out = td/'runtime.pyz'
            build(root, out, td/'manifest.json', td/'sum')
            doctor = subprocess.run([sys.executable, '-S', str(out), 'doctor', '--check-dependencies'],
                                    cwd=td, capture_output=True, text=True)
            self.assertEqual(doctor.returncode, 0, doctor.stderr)
            self.assertEqual(json.loads(doctor.stdout)['schema'], 'agent-interface/runtime-doctor-v1')
            self.assertTrue(all(row['discoverable'] is False for row in
                                json.loads(doctor.stdout)['dependency_inventory']['modules']))
            mcp = subprocess.run([sys.executable, '-S', str(out), 'mcp', '--help'],
                                 cwd=td, capture_output=True, text=True)
            self.assertEqual(mcp.returncode, 2)
            self.assertIn('optional dependency mcp==1.30.0', mcp.stderr)
            self.assertEqual(mcp.stdout, '')
            relay = subprocess.run([sys.executable, '-S', str(out), 'relay', '--help'],
                                   cwd=td, capture_output=True, text=True)
            self.assertEqual(relay.returncode, 2)
            self.assertIn('optional dependency mcp==1.30.0', relay.stderr)
            self.assertEqual(relay.stdout, '')


    def test_build_pins_source_even_when_head_moves_between_files(self):
        from runtime.distribution_v2 import build as builder
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            def git(*args):
                return subprocess.check_output(['git', '-C', str(root), *args], stderr=subprocess.STDOUT).decode().strip()
            git('init')
            for value in ('old', 'new'):
                for name in ('a.py', 'b.py'):
                    (root/name).write_text(value)
                git('add', 'a.py', 'b.py')
                git('-c', 'user.name=Fixture', '-c', 'user.email=fixture@example.invalid', 'commit', '-m', value)
                if value == 'old': old = git('rev-parse', 'HEAD')
            pinned = git('rev-parse', 'HEAD')
            original = builder._source_bytes
            def read(path, rel, revision):
                data = original(path, rel, revision)
                if rel == 'a.py':
                    git('update-ref', 'HEAD', old, pinned)
                return data
            with mock.patch.object(builder, 'SOURCE_FILES', ('a.py', 'b.py')), \
                 mock.patch.object(builder, '_source_bytes', side_effect=read):
                result = build(root, root/'out.pyz', root/'manifest.json', root/'sums')
            self.assertEqual(git('rev-parse', 'HEAD'), old)
            self.assertEqual(result['source_revision'], pinned)
            with zipfile.ZipFile(root/'out.pyz') as archive:
                self.assertEqual(archive.read('a.py'), b'new')
                self.assertEqual(archive.read('b.py'), b'new')
                self.assertEqual(json.loads(archive.read('BUILD.json'))['source_revision'], pinned)

    def test_missing_commit_does_not_fall_back_to_working_files(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root/'.git').mkdir()
            with self.assertRaises(RuntimeError):
                build(root, root/'out.pyz', root/'manifest.json', root/'sums')
            self.assertFalse((root/'out.pyz').exists())
            self.assertFalse((root/'manifest.json').exists())

    def test_build_is_byte_deterministic_and_doctor_runs(self):
        root = Path(__file__).resolve().parents[2]
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            a = td / "a.pyz"; b = td / "b.pyz"
            ma = td / "a.json"; mb = td / "b.json"
            sa = td / "a.sum"; sb = td / "b.sum"
            ra = build(root, a, ma, sa); rb = build(root, b, mb, sb)
            self.assertEqual(a.read_bytes(), b.read_bytes())
            self.assertEqual(ra["sha256"], rb["sha256"])
            proc = subprocess.run([sys.executable, str(a), "doctor"], capture_output=True, text=True, check=True)
            rows = proc.stdout.strip().splitlines()
            self.assertEqual(len(rows), 1)
            doctor = json.loads(rows[0])
            self.assertEqual(doctor["schema"], "agent-interface/runtime-doctor-v1")
            self.assertFalse(doctor["side_effect_authority"])

    def test_archive_closure_has_only_promoted_executable_modules(self):
        root = Path(__file__).resolve().parents[2]
        with tempfile.TemporaryDirectory() as td:
            td = Path(td); out = td / "runtime.pyz"
            result = build(root, out, td / "manifest.json", td / "sum")
            expected = sorted(list(SOURCE_FILES) + list(GENERATED) + ["SUPPORT.json", "BUILD.json"])
            self.assertEqual(result["entries"], expected)
            with zipfile.ZipFile(out) as archive:
                self.assertEqual(archive.namelist(), expected)
                for info in archive.infolist():
                    self.assertEqual(info.date_time, FIXED_TIME)
                support = json.loads(archive.read("SUPPORT.json"))
                self.assertEqual(support, SUPPORT)
                self.assertFalse(support["wayland"]["promoted"])
            self.assertFalse(any("test" in name.lower() or "fixture" in name.lower() or "research" in name.lower() for name in expected))

    def test_portable_archive_includes_guarded_win32_api_and_dependency(self):
        root = Path(__file__).resolve().parents[2]
        guarded_sources = {
            "runtime/guarded_win32_v1/__init__.py",
            "runtime/guarded_win32_v1/bridge.py",
            "runtime/guarded_win32_v1/effect.py",
            "runtime/guarded_win32_v1/fresh.py",
            "runtime/guarded_win32_v1/pixel_worker.py",
            "runtime/guarded_win32_v1/reference.py",
            "runtime/guarded_win32_v1/retained.py",
            "runtime/guarded_win32_v1/supervisor.py",
            "runtime/guarded_win32_v1/worker_effect.py",
        }
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            archive_path = td / "runtime.pyz"
            build(root, archive_path, td / "manifest.json", td / "sum")
            with zipfile.ZipFile(archive_path) as archive:
                missing = sorted(guarded_sources - set(archive.namelist()))
                self.assertEqual(missing, [])
                support = json.loads(archive.read("SUPPORT.json"))
                self.assertEqual(
                    support["optional_dependencies"]["guarded_win32_python_api"],
                    ["Pillow"],
                )

    def test_malformed_targets_fail_before_native_backend(self):
        root = Path(__file__).resolve().parents[2]
        with tempfile.TemporaryDirectory() as td:
            td = Path(td); out = td / "runtime.pyz"
            build(root, out, td / "manifest.json", td / "sum")
            program = td / "program.json"; program.write_text("{}", encoding="utf-8")
            targets = td / "targets.json"; targets.write_text("{}", encoding="utf-8")
            proc = subprocess.run([
                sys.executable, str(out), "dispatch", "--program", str(program), "--targets", str(targets),
                "--current-observation-seq", "0", "--current-binding-revision", "0",
            ], capture_output=True, text=True)
            self.assertNotEqual(proc.returncode, 0)
            row = json.loads(proc.stdout)
            self.assertEqual(row["status"], "backend_unavailable")
            observation = subprocess.run([
                sys.executable, str(out), "observe", "--targets", str(targets),
                "--target", "fixture", "--frame", "window_client", "--region", "0", "0", "10", "10",
            ], capture_output=True, text=True)
            self.assertNotEqual(observation.returncode, 0)
            self.assertEqual(json.loads(observation.stdout)["status"], "backend_unavailable")


if __name__ == "__main__":
    unittest.main()

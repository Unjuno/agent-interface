import os,time,json,signal,subprocess,shutil,hashlib,io
from pathlib import Path
from Xlib import X,XK,display
from Xlib.ext import xtest
from PIL import Image
from runtime.cli_v1.mcp_guarded import GuardedSessionOwner
from runtime.guarded_x11_v1.cancel_supervisor import PrestartedCancellationSupervisor,x11_cancel_worker
from crop_pixel_cue import create_reference,classify
from pair_saved_oracle import score_saved

def main():
 out=Path('/out');env=dict(os.environ,DISPLAY=':153',HOME='/tmp',SAL_USE_VCLPLUGIN='gen');actors=[];handles=[];d=None;owner=None;owner_sup=None;cleanup_sup=None;target_stopped=False;calc_pid=None
 try:
  def spawn(name,args):
   f=(out/(name+'.log')).open('wb');handles.append(f);p=subprocess.Popen(args,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);actors.append(p);return p
  spawn('xvfb',['Xvfb',':153','-screen','0','1280x800x24','-nolisten','tcp','-ac'])
  for _ in range(100):
   try:d=display.Display(':153');break
   except Exception:time.sleep(.05)
  if d is None:raise RuntimeError('X unavailable')
  if hashlib.sha256(Path('/in/blank.fods').read_bytes()).hexdigest()!='462beebbcb020ccf49af3cc49520f789a816cc3fb97597cefbd6940ffc26aeb1':raise RuntimeError('fixture differs')
  shutil.copyfile('/in/blank.fods','/tmp/blank.fods');spawn('openbox',['openbox','--sm-disable']);lo=spawn('calc',['libreoffice','-env:UserInstallation=file:///tmp/observe-profile','--calc','--nologo','--norestore','--nofirststartwizard','/tmp/blank.fods'])
  def walk(w,depth=0):
   if depth>6:return []
   result=[]
   for child in w.query_tree().children:
    try:
     title=child.get_wm_name();title=title.decode(errors='replace') if isinstance(title,bytes) else str(title or '');result.append((child.id,title,child.get_attributes().map_state));result+=walk(child,depth+1)
    except Exception:pass
   return result
  end=time.monotonic()+20;found=[]
  while time.monotonic()<end:
   found=[r for r in walk(d.screen().root) if 'blank.fods' in r[1].lower() and 'calc' in r[1].lower() and r[2]==X.IsViewable]
   if len(found)==1:break
   if len(found)>1 or lo.poll() is not None:raise RuntimeError('target ambiguous or exited')
   time.sleep(.05)
  if len(found)!=1:raise RuntimeError('target unavailable')
  time.sleep(1);owner=GuardedSessionOwner({'app':found[0][0]},out/'owner',':153');owner.get();b=owner.bridge;before=b.observe();before_image=b.history[before['sequence']][1]
  if hashlib.sha256(before_image.crop((0,97,42,119)).tobytes()).hexdigest()!='2e86f3a0f6d87ee4fb4e5ffeb7cfd159d715cb5f6f8177b0ede83784d49088cf':raise RuntimeError('initial A1 namebox differs')
  entry=b.mint_reference('entry',before['sequence'],[440,28],region_size=(30,14));tail=[{'op':'text','text':'731','gap_ms':1},{'op':'key_chord','keys':['Return']},{'op':'wait_update','timeout_ms':100},{'op':'text','text':'864','gap_ms':1},{'op':'key_chord','keys':['Return']},{'op':'wait_update','timeout_ms':100}]
  entry_result=b.keyboard('entry',entry['offset'],tail=tail,expires_at_ns=time.monotonic_ns()+3_000_000_000);(out/'entry-result.json').write_text(json.dumps(entry_result,indent=2)+'\n');releases=entry_result.get('execution',{}).get('releases',[])
  if entry_result.get('status')!='completed' or not releases or not all(x.get('verified') is True and not x.get('keys_down') and not x.get('buttons_down') for x in releases):raise RuntimeError('entry failed or release unknown')
  filled=b.observe();filled_img=b.history[filled['sequence']][1];reference=create_reference(Image.open('/in/reference.png').convert('RGB'));cue=classify(filled_img,reference);(out/'filled-cue.json').write_text(json.dumps({'sequence':filled['sequence'],'cue':cue},indent=2)+'\n')
  if cue!='filled':raise RuntimeError('known reviewed filled pixels unavailable')
  initial=Path('/tmp/blank.fods').read_bytes();baseline=hashlib.sha256(initial).hexdigest()
  if baseline!='462beebbcb020ccf49af3cc49520f789a816cc3fb97597cefbd6940ffc26aeb1':raise RuntimeError('file changed before save')
  window=d.create_resource_object('window',found[0][0]);prop=window.get_full_property(d.intern_atom('_NET_WM_PID'),X.AnyPropertyType)
  if prop is None or len(prop.value)!=1:raise RuntimeError('target pid unavailable')
  calc_pid=int(prop.value[0]);cmd=Path('/proc/'+str(calc_pid)+'/cmdline').read_bytes()
  if b'soffice.bin' not in cmd or os.getpgid(calc_pid)!=lo.pid:raise RuntimeError('target not owned Calc process')
  mode=os.environ['MODE'];(out/'targets.json').write_text(json.dumps({'app':found[0][0]}));session_result=None
  async def transport_trial():
   nonlocal target_stopped
   import asyncio,base64,sys
   from mcp import ClientSession,StdioServerParameters
   from mcp.client.stdio import stdio_client
   params=StdioServerParameters(command=sys.executable,args=['-B','-m','runtime.cli_v1.mcp_server','--targets',str(out/'targets.json'),'--output-directory',str(out/'mcp-receipts'),'--display',':153','--session-mode','guarded-x11','--guarded-process-identity','--guarded-query-worker'],cwd='/src')
   def meta(reply):
    if reply.isError:raise RuntimeError('MCP tool error: '+str(reply.content)[:500])
    return json.loads(reply.content[0].text)
   with (out/'mcp-stderr.log').open('w') as err:
    async with stdio_client(params,errlog=err) as (reader,writer):
     async with ClientSession(reader,writer) as client:
      await client.initialize();reply=await client.call_tool('interface_guarded_observe',{});obs=meta(reply);(out/'mcp-observe.json').write_text(json.dumps(obs,indent=2)+'\n')
      if obs.get('status')!='observed':raise RuntimeError('MCP observation unavailable')
      images=[c for c in reply.content if getattr(c,'type',None)=='image']
      if len(images)!=1:raise RuntimeError('MCP image unavailable')
      data=base64.b64decode(images[0].data,validate=True);(out/'mcp-image.png').write_bytes(data);expected=obs['source']['native']['artifact']['sha256']
      if hashlib.sha256(data).hexdigest()!=expected:raise RuntimeError('MCP image mismatch')
      minted=meta(await client.call_tool('interface_guarded_mint',{'alias':'save','source_sequence':obs['source']['sequence'],'point':[440,28],'region_size':[30,14]}));(out/'mcp-mint.json').write_text(json.dumps(minted,indent=2)+'\n')
      if minted.get('status')!='minted':raise RuntimeError('MCP mint refused')
      if mode=='stopped':
       os.kill(calc_pid,signal.SIGSTOP);target_stopped=True;limit=time.monotonic()+1
       while time.monotonic()<limit:
        if '\nState:\tT' in Path('/proc/'+str(calc_pid)+'/status').read_text():break
        await asyncio.sleep(.005)
       else:raise RuntimeError('Calc not stopped')
       (out/'target-stopped.json').write_text(json.dumps({'pid':calc_pid,'stopped_ns':time.monotonic_ns(),'state':'T'}))
      args={'alias':'save','offset':minted['offset'],'interaction':'keyboard','tail':[{'op':'key_chord','keys':['CTRL','s']},{'op':'wait_update','timeout_ms':2000},{'op':'key_chord','keys':['F2']}],'observe_after':False,'wait_for_result_ms':0};submitted=time.monotonic_ns();first=meta(await client.call_tool('interface_guarded_input',args));(out/'mcp-initial.json').write_text(json.dumps(first,indent=2)+'\n');checks=[]
      if first.get('status')=='pending':
       call_id=first['call_id'];limit=time.monotonic()+5
       if True:
        await asyncio.sleep(.5);cancel_requested_ns=time.monotonic_ns();cancel=meta(await client.call_tool('interface_guarded_cancel',{'call_id':call_id}));(out/'mcp-cancel.json').write_text(json.dumps({'requested_ns':cancel_requested_ns,'response':cancel},indent=2)+'\n')
       while True:
        row=meta(await client.call_tool('interface_results',{'call_id':call_id,'include_image':False}));checks.append({'status':row.get('status'),'observed_ns':time.monotonic_ns()})
        if row.get('status')!='pending':break
        if time.monotonic()>=limit:raise TimeoutError('MCP result did not settle')
        await asyncio.sleep(.02)
      else:row=first;call_id=first.get('call_id')
      terminal_ns=time.monotonic_ns();(out/'mcp-terminal.json').write_text(json.dumps(row,indent=2)+'\n');(out/'mcp-polls.json').write_text(json.dumps(checks,indent=2)+'\n')
      if row.get('status') not in ('completed','execution_failed','cancelled'):raise RuntimeError('MCP terminal status unexpected')
      probe_args={'alias':'save','offset':minted['offset'],'interaction':'keyboard','tail':[{'op':'key_chord','keys':['F3']}],'observe_after':False,'wait_for_result_ms':10000};reply=await client.call_tool('interface_guarded_input',probe_args);probe={'is_error':bool(reply.isError),'payload':json.loads(reply.content[0].text)};(out/'post-terminal-probe.json').write_text(json.dumps(probe,indent=2)+'\n')
      mid=Path('/tmp/blank.fods').read_bytes();mid_ns=time.monotonic_ns();(out/'mid.fods').write_bytes(mid)
      if target_stopped:os.kill(calc_pid,signal.SIGCONT);target_stopped=False;(out/'target-resumed.json').write_text(json.dumps({'pid':calc_pid,'resumed_ns':time.monotonic_ns()}))
      limit=time.monotonic()+3
      while time.monotonic()<limit:
       after=Path('/tmp/blank.fods').read_bytes()
       if score_saved(after).get('pass_effect') is True:break
       await asyncio.sleep(.05)
      after_ns=time.monotonic_ns();(out/'after.fods').write_bytes(after)
      decoy=d.screen().root.create_window(0,0,16,16,0,d.screen().root_depth,X.InputOutput,X.CopyFromParent);d.sync();(out/'decoy.json').write_text(json.dumps({'window_id':decoy.id,'mapped':False,'focus':getattr(d.get_input_focus().focus,'id',None)}))
      badreply=await client.call_tool('interface_guarded_review_window',{'window_id':decoy.id});bad={'is_error':bool(badreply.isError),'payload':json.loads(badreply.content[0].text)};(out/'failed-review.json').write_text(json.dumps(bad,indent=2)+'\n')
      if bad['payload'].get('status')!='needs_review':raise RuntimeError('wrong-window review unexpectedly accepted')
      blockedargs={'alias':'save','offset':minted['offset'],'interaction':'keyboard','tail':[{'op':'key_chord','keys':['F3']}],'observe_after':False,'wait_for_result_ms':10000};blockedreply=await client.call_tool('interface_guarded_input',blockedargs);blocked={'is_error':bool(blockedreply.isError),'payload':json.loads(blockedreply.content[0].text)};(out/'after-failed-review-input.json').write_text(json.dumps(blocked,indent=2)+'\n')
      if blocked['payload'].get('status')!='refused':raise RuntimeError('input accepted after failed review')
      mintreply=await client.call_tool('interface_guarded_mint',{'alias':'bad','source_sequence':obs['source']['sequence'],'point':[440,28],'region_size':[30,14]});badmint={'is_error':bool(mintreply.isError),'payload':json.loads(mintreply.content[0].text)};(out/'after-failed-review-mint.json').write_text(json.dumps(badmint,indent=2)+'\n')
      if badmint['payload'].get('status')!='refused':raise RuntimeError('mint accepted after failed review')
      reply=await client.call_tool('interface_guarded_review_window',{'window_id':found[0][0]});review=meta(reply);(out/'mcp-review.json').write_text(json.dumps(review,indent=2)+'\n')
      if review.get('status')!='reviewed':raise RuntimeError('review refused')
      review_images=[c for c in reply.content if getattr(c,'type',None)=='image']
      if len(review_images)!=1:raise RuntimeError('review image unavailable')
      review_image=base64.b64decode(review_images[0].data,validate=True);(out/'review-image.png').write_bytes(review_image)
      if hashlib.sha256(review_image).hexdigest()!=review['source']['native']['artifact']['sha256']:raise RuntimeError('review image hash mismatch')
      oldargs={'alias':'save','offset':minted['offset'],'interaction':'keyboard','tail':[{'op':'key_chord','keys':['F3']}],'observe_after':False,'wait_for_result_ms':10000};oldreply=await client.call_tool('interface_guarded_input',oldargs);old={'is_error':bool(oldreply.isError),'payload':json.loads(oldreply.content[0].text)};(out/'post-review-old-alias.json').write_text(json.dumps(old,indent=2)+'\n')
      if old['payload'].get('status')!='refused':raise RuntimeError('old alias was not refused after review')
      fresh=meta(await client.call_tool('interface_guarded_mint',{'alias':'resume','source_sequence':review['source']['sequence'],'point':[440,28],'region_size':[30,14]}));(out/'mcp-remint.json').write_text(json.dumps(fresh,indent=2)+'\n')
      if fresh.get('status')!='minted':raise RuntimeError('fresh mint refused')
      newargs={'alias':'resume','offset':fresh['offset'],'interaction':'keyboard','tail':[{'op':'text','text':'975','gap_ms':1},{'op':'key_chord','keys':['Return']},{'op':'key_chord','keys':['CTRL','s']}],'observe_after':False,'wait_for_result_ms':10000};newreply=await client.call_tool('interface_guarded_input',newargs);new={'is_error':bool(newreply.isError),'payload':json.loads(newreply.content[0].text)};(out/'recovery-input.json').write_text(json.dumps(new,indent=2)+'\n')
      await asyncio.sleep(1);(out/'after-recovery.fods').write_bytes(Path('/tmp/blank.fods').read_bytes())
      close=meta(await client.call_tool('interface_close',{}));(out/'mcp-close.json').write_text(json.dumps(close,indent=2)+'\n')
      return {'submitted_ns':submitted,'terminal_ns':terminal_ns,'mid_observed_ns':mid_ns,'after_observed_ns':after_ns,'initial_status':first.get('status'),'call_id':call_id,'mid_sha256':hashlib.sha256(mid).hexdigest(),'after_sha256':hashlib.sha256(after).hexdigest(),'mid_score':score_saved(mid),'after_score':score_saved(after)}
  import asyncio
  session_result=asyncio.run(transport_trial());keys=d.query_keymap();ctrl=d.keysym_to_keycode(XK.string_to_keysym('Control_L'));key=d.keysym_to_keycode(XK.string_to_keysym('s'));pressed=[name for name,code in [('Control_L',ctrl),('s',key)] if keys[code//8]&(1<<(code%8))];mask=int(d.screen().root.query_pointer().mask)&(X.Button1Mask|X.Button2Mask|X.Button3Mask);record={'mode':mode,'target':found[0][0],'calc_pid':calc_pid,'baseline_sha256':baseline,'filled_sequence':filled['sequence'],'keys_down':pressed,'buttons_after':mask,**session_result};(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
 finally:
  if target_stopped and calc_pid is not None:os.kill(calc_pid,signal.SIGCONT);target_stopped=False
  if owner_sup is not None:owner_sup.close()
  if cleanup_sup is not None:cleanup_sup.close()
  if owner is not None:(out/'owner-close.json').write_text(json.dumps(owner.close(),indent=2)+'\n')
  if d is not None:
   try:
    keymap=d.query_keymap();codes=[d.keysym_to_keycode(XK.string_to_keysym(name)) for name in ('Control_L','s')];held=[code for code in codes if code and keymap[code//8]&(1<<(code%8))]
    if held:
     for code in held:xtest.fake_input(d,X.KeyRelease,code)
     d.sync();(out/'fallback-keys.txt').write_text('fallback key release required')
    if int(d.screen().root.query_pointer().mask)&X.Button1Mask:xtest.fake_input(d,X.ButtonRelease,1);d.sync();(out/'fallback-release.txt').write_text('fallback required')
   finally:d.close()
  for p in reversed(actors):
   if p.poll() is None:
    try:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=3)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=3)
    except ProcessLookupError:pass
  for f in handles:f.close()

if __name__=='__main__':main()

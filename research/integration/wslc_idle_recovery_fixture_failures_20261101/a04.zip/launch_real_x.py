import hashlib,json,os,pathlib,subprocess,sys,time
root=pathlib.Path(__file__).resolve().parent
out=root/'real-x-a04'
out.mkdir(exist_ok=False)
(out/'output').mkdir()
files=[p for p in (root/'src').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']+[root/'real_x_trial.py',root/'target.py',root/'launch_real_x.py']
manifest={str(p.relative_to(root)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
conditions={'allocation':'idle-real-x-a04-20261101','base_main':'8fa7f49b008695cea56b16e68811ea8755d857af',
 'image':'sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25',
 'limits':'one CPU, 1 GiB, network none, pull never, private Xvfb; WSLc memory limit excludes swap',
 'order':'separate X client target, healthy capture, server stopped and observed, 500ms idle capture and observed pending, resume, retire old session, create fresh session and enter a into target',
 'criteria':'stopped and pending observed; timeout with no late old source; fresh guarded keyboard succeeds and releases, independent target records a press and release and value a, neutral input before/after',
 'stop':'single attempt; preserve failure; no retry for success',
 'scope':'successor to a03, whose invalid hyphenated alias failed before input; changes alias to fresh_field only; prototype and synthetic X target only; no model, held-input recovery or MAP01 claim',
 'manifest_sha256':hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest()}
(out/'conditions.json').write_text(json.dumps(conditions,indent=2)+'\n')
for name,digest in manifest.items():
 if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('frozen source changed: '+name)
cmd=['wslc','run','--rm','--name',conditions['allocation'],'--network','none','--cpus','1','--memory','1g','--pull','never',
 '--mount',f'type=bind,source={root / "src"},target=/src,readonly',
 '--mount',f'type=bind,source={root / "real_x_trial.py"},target=/trial.py,readonly',
 '--mount',f'type=bind,source={root / "target.py"},target=/target.py,readonly',
 '--mount',f'type=bind,source={out / "output"},target=/out',
 '--env','PYTHONPATH=/src','--env','PYTHONDONTWRITEBYTECODE=1','--entrypoint','timeout',conditions['image'],
 '--signal=TERM','--kill-after=3s','30s','python3','-B','/trial.py']
(out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
started=time.monotonic()
with (out/'stdout').open('wb') as stdout,(out/'stderr').open('wb') as stderr:
 proc=subprocess.run(cmd,stdout=stdout,stderr=stderr,timeout=50,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
result={'returncode':proc.returncode,'elapsed_seconds':time.monotonic()-started}
(out/'launcher-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
sys.exit(proc.returncode)

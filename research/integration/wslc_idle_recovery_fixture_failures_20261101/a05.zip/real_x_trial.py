"""Stopped capture followed by fresh-session input to a separate X client."""
import json,os,pathlib,signal,subprocess,sys,threading,time,traceback
from Xlib import X,display
from runtime.guarded_x11_v1.bridge import NativeHandleBridge
from runtime.backends.x11_v1.backend import X11BackendError
out=pathlib.Path('/out');result={'status':'started','events':[]};events=result['events']
def mark(name,**kw):events.append({'name':name,'ns':time.monotonic_ns(),**kw})
def state(pid):
 return next(line.split()[1] for line in pathlib.Path(f'/proc/{pid}/status').read_text().splitlines() if line.startswith('State:'))
server=target=connection=old=fresh=thread=None
try:
 server=subprocess.Popen(['Xvfb',':195','-screen','0','640x480x24','-nolisten','tcp'],stdout=(out/'xvfb.log').open('wb'),stderr=subprocess.STDOUT)
 for _ in range(100):
  if server.poll() is not None:raise RuntimeError('Xvfb exited')
  try:connection=display.Display(':195');break
  except Exception:time.sleep(.05)
 if connection is None:raise RuntimeError('Xvfb unavailable')
 target=subprocess.Popen(['python3','-B','/target.py'],stdout=(out/'target.stdout').open('wb'),stderr=(out/'target.stderr').open('wb'))
 until=time.monotonic()+4
 while not (out/'target-ready.json').exists():
  if target.poll() is not None or time.monotonic()>=until:raise RuntimeError('target unavailable')
  time.sleep(.01)
 ready=json.loads((out/'target-ready.json').read_text());window=connection.create_resource_object('window',ready['xid'])
 connection.set_input_focus(window,X.RevertToParent,X.CurrentTime);connection.sync()
 before=bytes(connection.query_keymap());pointer_before=connection.screen().root.query_pointer().mask
 old=NativeHandleBridge(':195',{'app':window.id},'app','/out/old',process_identity=True,query_worker=True,observation_worker=True)
 with old.cancellation_scope('healthy',cancel_when_idle=True,single_idle_observation=True):
  result['initial_sequence']=old.observe_idle_until(time.monotonic_ns()+2_000_000_000)['sequence']
 os.kill(server.pid,signal.SIGSTOP);mark('stop_sent');until=time.monotonic()+2
 while state(server.pid)!='T':
  if time.monotonic()>=until:raise RuntimeError('server did not stop')
  time.sleep(.002)
 mark('stop_observed',state=state(server.pid))
 deadline=time.monotonic_ns()+500_000_000;result['deadline_ns']=deadline;capture={}
 def invoke():
  mark('capture_started')
  try:
   with old.cancellation_scope('stopped',cancel_when_idle=True,single_idle_observation=True):old.observe_idle_until(deadline)
   capture['status']='unexpected_source'
  except X11BackendError:capture['status']='unavailable'
  except BaseException as e:capture.update(status='error',error=repr(e))
  finally:mark('capture_returned',**capture)
 thread=threading.Thread(target=invoke);thread.start();pending=False
 while time.monotonic_ns()<deadline and thread.is_alive():
  snap=old._observations.snapshot()
  if snap['pending'] and snap['thread_alive'] and state(server.pid)=='T':mark('pending_while_stopped');pending=True;break
  time.sleep(.002)
 if not pending:raise RuntimeError('pending stopped capture not observed')
 thread.join(2)
 if thread.is_alive():raise RuntimeError('capture did not return')
 result['capture']=capture;result['state_before_resume']=state(server.pid);result['old_sequence_before_resume']=old.sequence
 result['worker_before_resume']=old._observations.snapshot()
 os.kill(server.pid,signal.SIGCONT);mark('resumed')
 until=time.monotonic()+3
 while old._observations.snapshot()['thread_alive'] and time.monotonic()<until:time.sleep(.02)
 result['worker_after_resume']=old._observations.snapshot();result['old_sequence_after_resume']=old.sequence
 result['old_review_required']=old.review_required
 old.close();old=None;mark('old_closed')
 fresh=NativeHandleBridge(':195',{'app':window.id},'app','/out/fresh',process_identity=True,query_worker=True,observation_worker=True)
 with fresh.cancellation_scope('fresh-capture',cancel_when_idle=True,single_idle_observation=True):
  obs=fresh.observe_idle_until(time.monotonic_ns()+2_000_000_000)
 g=obs['pointer_binding']['geometry'];offset=fresh.mint('fresh_field',obs['sequence'],[g[0]+20,g[1]+20],region_size=[12,12])
 with fresh.cancellation_scope('fresh-keyboard'):
  action=fresh.keyboard('fresh_field',offset,tail=[{'op':'key_chord','keys':['a']}])
 result['action']=action;mark('action_returned')
 until=time.monotonic()+2
 while time.monotonic()<until:
  if (out/'target-events.json').exists():
   target_result=json.loads((out/'target-events.json').read_text())
   if target_result['value']=='a' and any(e['type']=='release' and e['key']=='a' for e in target_result['events']):break
  time.sleep(.01)
 else:raise RuntimeError('target did not record expected input and release')
 result['target_result']=target_result
 fresh.close();fresh=None;mark('fresh_closed')
 connection.sync();after=bytes(connection.query_keymap());pointer_after=connection.screen().root.query_pointer().mask
 result['input_neutral_before_after']=not any(before) and not any(after) and (pointer_before&0x1f00)==0 and (pointer_after&0x1f00)==0
 assert result['initial_sequence']==1 and capture['status']=='unavailable' and result['state_before_resume']=='T'
 assert result['old_sequence_before_resume']==result['old_sequence_after_resume']==1 and result['old_review_required']
 assert result['worker_before_resume']['retired'] and not result['worker_after_resume']['thread_alive']
 assert action['status']=='completed' and action['execution']['releases'][-1]['verified']
 assert result['input_neutral_before_after'] and target_result['value']=='a'
 result['status']='passed'
except BaseException as e:result.update(status='failed',error=repr(e),traceback=traceback.format_exc())
finally:
 if server is not None and server.poll() is None:
  try:os.kill(server.pid,signal.SIGCONT)
  except ProcessLookupError:pass
 if thread is not None and thread.is_alive():thread.join(3)
 for name,owner in [('old',old),('fresh',fresh)]:
  if owner is not None:
   try:owner.close()
   except Exception as e:result[name+'_close_error']=repr(e);result['status']='failed'
 if target is not None:
  (out/'target-stop').write_text('stop')
  try:target.wait(timeout=3)
  except subprocess.TimeoutExpired:target.terminate();target.wait();result['status']='failed'
  result['target_exit']=target.returncode
 if connection is not None:connection.close()
 if server is not None and server.poll() is None:
  server.terminate()
  try:server.wait(timeout=5)
  except subprocess.TimeoutExpired:server.kill();server.wait();result['status']='failed'
 result['server_exit']=None if server is None else server.poll()
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
sys.exit(0 if result['status']=='passed' else 1)

import hashlib,json,os,subprocess,sys,time,uuid
from pathlib import Path
root=Path(sys.argv[1]);sys.path.insert(0,str(root/'source'))
from job_host import JobHost
from identity import k,creation,member
files=('source/job_host.py','source/win_job_spawn.py','source/codex_app_server_client_v2.py','source/identity.py','source/fake_server.py','source/host.py','audit.py')
result={'status':'UNKNOWN','started_ns':time.monotonic_ns(),'source_sha256':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in files},'cases':[]}
try:
 source_commit='11ecaa75393c9c403ca32f34c6716bcff85f823f'
 blob=subprocess.run(['git','show',source_commit+':research/live_control/codex_app_server_client_v2.py'],capture_output=True,check=True).stdout
 if blob!=(root/'source/codex_app_server_client_v2.py').read_bytes():raise RuntimeError('client source mismatch')
 result['client_git_commit']=source_commit;result['client_blob_matches']=True
 for mode in ('normal','held'):
  case=root/mode;case.mkdir(exist_ok=False);nonce=uuid.uuid4().hex;child=None;verified=False;host=None;rec={'mode':mode,'nonce':nonce,'started_ns':time.monotonic_ns()}
  try:
   env={k:os.environ[k] for k in ('SYSTEMROOT','WINDIR','TEMP','TMP','PATH') if k in os.environ};env['PYTHONUTF8']='1'
   host=JobHost([sys.executable,'-u',str(root/'source/host.py'),str(case),mode,nonce],case,cwd=str(case),environment=env)
   host.start();rec['host_pid']=host.process.pid;rec['host_start_complete']=True
   if mode=='held':
    until=time.monotonic()+8
    while not (case/'child.ready').exists():
     if time.monotonic()>=until:raise TimeoutError('grandchild marker timeout')
     time.sleep(.05)
    ready=json.loads((case/'child.ready').read_text());rec['child_ready']=ready
    if ready.get('nonce')!=nonce:raise RuntimeError('nonce mismatch')
    child=k.OpenProcess(0x00101001,False,ready['pid'])
    if not child:raise OSError('OpenProcess')
    actual=creation(child);rec['child_creation_observed']=actual
    if actual!=ready['creation'] or not member(child,host.process.job):raise RuntimeError('child identity or membership mismatch')
    verified=True;rec['child_membership_verified']=True;rec['child_before_host_wait']=k.WaitForSingleObject(child,0)
    if rec['child_before_host_wait']!=258:raise RuntimeError('child not active')
   rec['host_wait']=host.wait(timeout_s=15)
   if (case/'host-result.json').exists():rec['host_result']=json.loads((case/'host-result.json').read_text())
   if child:rec['child_before_job_close']=k.WaitForSingleObject(child,0)
  except BaseException as e:rec.update(error_type=type(e).__name__,error=str(e))
  finally:
   if host is not None:
    try:rec['host_cleanup']=host.close(timeout_s=5)
    except BaseException as e:rec['host_cleanup_error']=type(e).__name__
   try:
    if child and verified:
     rec['child_after_job_close']=k.WaitForSingleObject(child,5000)
     if rec['child_after_job_close']!=0:
      rec['fallback_called']=True;rec['fallback_ok']=bool(k.TerminateProcess(child,1));rec['fallback_wait']=k.WaitForSingleObject(child,5000)
   except BaseException as e:rec['child_cleanup_error']=type(e).__name__
   try:
    if child:rec['child_handle_closed']=bool(k.CloseHandle(child))
   except BaseException as e:rec['child_handle_close_error']=type(e).__name__
   rec['ended_ns']=time.monotonic_ns()
   try:
    with (case/'case-result.json').open('x',encoding='utf-8') as output:output.write(json.dumps(rec,indent=2)+'\n')
   except BaseException as e:rec['case_write_error']=type(e).__name__
   result['cases'].append(rec)
  if mode=='normal' and not (not rec.get('case_write_error') and rec.get('host_wait',{}).get('exit_code')==0 and rec.get('host_result',{}).get('answer')=={'echo':'hello'} and rec.get('host_result',{}).get('close_returned') is True and rec.get('host_cleanup',{}).get('status')=='closed_scoped'):
   raise RuntimeError('normal case not complete; next case not started')
 normal,held=result['cases']
 if (normal.get('host_wait',{}).get('exit_code')==0 and normal.get('host_result',{}).get('answer')=={'echo':'hello'} and normal.get('host_result',{}).get('close_returned') is True and normal.get('host_cleanup',{}).get('status')=='closed_scoped'
     and held.get('host_wait',{}).get('exit_code')==1 and held.get('host_result',{}).get('answer')=={'echo':'hello'} and held.get('host_result',{}).get('close_error_type')=='TimeoutError' and held.get('host_result',{}).get('reader_alive') is True
     and held.get('child_membership_verified') is True and not held.get('case_write_error') and held.get('child_before_job_close')==258 and held.get('host_cleanup',{}).get('status')=='closed_scoped' and held.get('child_after_job_close')==0 and held.get('child_handle_closed') is True and not held.get('fallback_called')):
  result['status']='scoped_synthetic_protocol_observed'
except BaseException as e:result.update(error_type=type(e).__name__,error=str(e))
finally:
 result['ended_ns']=time.monotonic_ns();(root/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'status':result['status'],'case_count':len(result['cases']),'error_type':result.get('error_type')}))

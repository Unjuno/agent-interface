import json,os,subprocess,sys,time
from pathlib import Path
from identity import creation
root=Path(sys.argv[1]);mode=sys.argv[2];nonce=sys.argv[3]
if mode=='held':
 child=subprocess.Popen([sys.executable,'-c','import time;time.sleep(30)'],close_fds=False,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
 r={'nonce':nonce,'pid':child.pid,'creation':creation(int(child._handle)),'time_ns':time.monotonic_ns()}
 with (root/'child.tmp').open('x',encoding='utf-8') as f:json.dump(r,f)
 os.replace(root/'child.tmp',root/'child.ready')
for line in sys.stdin:
 q=json.loads(line);response={'id':q['id'],'result':{'echo':q.get('params',{}).get('text')}}
 print(json.dumps(response),flush=True)

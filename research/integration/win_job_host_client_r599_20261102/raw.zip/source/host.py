import json,sys,time
from pathlib import Path
from codex_app_server_client_v2 import CodexAppServerClient
root=Path(sys.argv[1]);mode=sys.argv[2];nonce=sys.argv[3];client=None;r={'status':'UNKNOWN','mode':mode,'started_ns':time.monotonic_ns()}
try:
 client=CodexAppServerClient([sys.executable,'-u',str(Path(__file__).with_name('fake_server.py')),str(root),mode,nonce],cwd=root,journal_path=root/'protocol.jsonl')
 answer=client.request('fixture/echo',{'text':'hello'},timeout=5);r['answer']=answer
 try:client.close(timeout=1.5);r['close_returned']=True
 except BaseException as e:r['close_returned']=False;r['close_error_type']=type(e).__name__
 r['reader_alive']=client._reader.is_alive()
 if answer=={'echo':'hello'}:r['status']='echo_observed'
except BaseException as e:r.update(error_type=type(e).__name__,error=str(e))
finally:
 r['ended_ns']=time.monotonic_ns();(root/'host-result.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps({'status':r['status'],'close_returned':r.get('close_returned'),'close_error_type':r.get('close_error_type')}),flush=True)
raise SystemExit(0 if r.get('status')=='echo_observed' and r.get('close_returned') is True else 1)

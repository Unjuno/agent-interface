import hashlib,json,pathlib,zipfile
root=pathlib.Path(__file__).resolve().parent;manifest=json.loads((root/'manifest.json').read_text())
for n,d in manifest.items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==d
arms=['cleanup-p01','cleanup-p02']
for arm in arms:
    p=root/arm;c=json.loads((p/'conditions.json').read_text());r=json.loads((p/'output/result.json').read_text())
    assert c['manifest_sha256']==hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()
    assert r['status']=='passed' and r['mode']==c['mode'] and json.loads((p/'launcher-result.json').read_text())['returncode']==0
    assert r['parent_auth_before_owner']==r['parent_auth_after_owner']==r['parent_auth_after_fresh']=='/out/invalid-parent-authority'
    assert r['old_key_down_before_stop'] and r['old_cancel']['cleanup_status']=='UNKNOWN' and not r['old_cancel']['release_confirmed'] and not r['old_cancel']['replay_allowed']
    assert r['old_cancel']['owner_input_obligations']['keys'].get('a') and not r['old_thread_alive'] and r['old_call'].get('error')=='EOFError()'
    ev={e['name']:e['ns'] for e in r['events']};order=['old_effect_and_hold','old_server_stopped','cleanup_worker_entered','old_server_resumed','old_cancel_returned','independent_key_readback','fresh_action_returned']
    assert [ev[n] for n in order]==sorted(ev[n] for n in order)
    old=r['old_target_before_fixture'];assert old['value']=='a' and old['events'][0]['type']=='press'
    if r['mode']=='correct':
        assert not r['a_down_after_cancel'] and r['old_cancel']['owner_release_attempt']['status']=='readback_verified'
        assert any(e['type']=='release' and e['key']=='a' for e in old['events']) and 'fixture_release_old_hold' not in ev
    else:
        assert r['a_down_after_cancel'] and r['old_cancel']['owner_client_disconnect']['reason']=='xres_query_failed'
        assert not any(e['type']=='release' and e['key']=='a' for e in old['events']) and 'fixture_release_old_hold' in ev
    assert r['fresh_target']['value']=='a' and r['action']['result']['execution']['releases'][-1]['verified'] and r['fresh_neutral_after_task']
    assert r['target_exitcodes']==[0,0] and r['server_exitcodes']==[-9]
dest=root.parent/'guarded-motion-deadline-r01/research/integration/wslc_cleanup_child_authority_20261101';dest.mkdir(parents=True,exist_ok=False)
paths=[root/n for n in manifest]+[root/'manifest.json',pathlib.Path(__file__)]
for arm in arms:
    p=root/arm;paths += [p/'conditions.json',p/'launcher-result.json',p/'stdout',p/'stderr']+[x for x in (p/'output').rglob('*') if x.is_file() and x.name!='authority' and 'display-owner-' not in '/'.join(x.parts)]
public={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
with zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in paths:z.write(p,p.relative_to(root).as_posix())
    z.writestr('public-manifest.json',json.dumps(public,indent=2,sort_keys=True)+'\n')
with zipfile.ZipFile(dest/'raw.zip') as z:
    for n,d in public.items():assert hashlib.sha256(z.read(n)).hexdigest()==d
print('validated',len(public),'files; sha256',hashlib.sha256((dest/'raw.zip').read_bytes()).hexdigest())

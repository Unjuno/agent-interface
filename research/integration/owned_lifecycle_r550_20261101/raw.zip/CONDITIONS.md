# Owned startup and close prototype r550

Before the run, execute three explicitly ordered cases once: direct owned
start/close race, MCP manual busy-close retry, and MCP lifespan shutdown during
direct startup. A parent-side gate pauses `Process.start()` after the real child
spawn but before the parent stores the process object. The first two cases
should pass with the candidate; the third is expected to fail if shutdown returns
while the child remains alive. Missing gate, fixture or cleanup failures are
errors. A private direct-start path is used to force this interleaving; natural
frequency and real MCP input are not evaluated.

Use pre-existing image sha256:bd191d30ea94871a1d3ca717252cd07a276e8ef7d1bcb4a130b63935ce075425,
Docker `--network none --cpus 1 --memory 1g --pull never`, source mounted
read-only, Python normal mode. Capture base, exact working diff, output and exit
before/after execution. Fake X owner, no user GUI, network or physical input.
Unconfirmed shutdown is not safe recovery, input release or task success. The
candidate remains a draft until shutdown custody, concurrent cancellation and
failure paths are resolved.

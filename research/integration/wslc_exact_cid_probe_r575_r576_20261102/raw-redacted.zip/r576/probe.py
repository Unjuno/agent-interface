import json, os, re, subprocess, sys, time, uuid
from pathlib import Path
root=Path(sys.argv[1]);root.mkdir(parents=False,exist_ok=False)
id=uuid.uuid4().hex; name='ai-r576-'+id[:16]; label='agent-interface.r576='+id
cidpath=root/'container.cid'; image='sha256:6150a4f3c779a51b3ac6a7d93bc1d0450803325efb7ab38ade8b1aaf79c33e25';events=[];owned=False;cid=None;proc=None
flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
def mark(event,**kw):
 events.append(dict(event=event,ns=time.monotonic_ns(),**kw));(root/'events.json').write_text(json.dumps(events,indent=2)+'\n',encoding='utf-8')
def command(tag,args,limit=8):
 mark(tag+'_begin');r=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=limit,creationflags=flags)
 (root/(tag+'.stdout')).write_bytes(r.stdout);(root/(tag+'.stderr')).write_bytes(r.stderr);mark(tag+'_end',exit=r.returncode)
 return r
args=['wslc','run','--rm','--name',name,'--label',label,'--cidfile',str(cidpath),'--network','none','--cpus','1','--memory','1g','--pull','never','--entrypoint','python3',image,'-c','import time; time.sleep(10)']
(root/'command.json').write_text(json.dumps({'argv':args,'run_id':id},indent=2)+'\n',encoding='utf-8');result={'status':'UNKNOWN','run_id':id,'container_name':name}
try:
 with (root/'run.stdout').open('wb') as out,(root/'run.stderr').open('wb') as err:
  mark('run_begin');proc=subprocess.Popen(args,stdout=out,stderr=err,creationflags=flags)
  end=time.monotonic()+8
  while time.monotonic()<end:
   if cidpath.exists():
    candidate=cidpath.read_text().strip()
    if re.fullmatch(r'[0-9a-f]{64}',candidate):cid=candidate;break
   if proc.poll() is not None:raise RuntimeError('client exited before valid CID')
   time.sleep(.05)
  if cid is None:raise TimeoutError('valid CID not observed')
  result['cid']=cid;mark('cid_observed',cid=cid)
  inspect=command('running_inspect',['wslc','container','inspect',cid,'--format','json'])
  if inspect.returncode!=0:raise RuntimeError('inspect failed')
  obj=json.loads(inspect.stdout.decode('utf-8-sig'));row=obj[0] if isinstance(obj,list) and len(obj)==1 else obj
  if not isinstance(row,dict) or row.get('Id')!=cid or row.get('Config',{}).get('Labels',{}).get('agent-interface.r576')!=id:raise RuntimeError('identity/label mismatch')
  owned=True;mark('identity_matched')
  listed=command('running_list',['wslc','container','list','--all','--filter','id='+cid,'--format','json'])
  if listed.returncode!=0:raise RuntimeError('running list failed')
  mark('waiting_for_exit');exitcode=proc.wait(timeout=20);mark('client_exited',exit=exitcode)
  if exitcode!=0:raise RuntimeError('run client failed')
  after=command('after_list',['wslc','container','list','--all','--filter','id='+cid,'--format','json'])
  if after.returncode!=0:raise RuntimeError('post list failed')
  mark('post_list_observed');result.update(status='OBSERVED',run_exit=exitcode)
except BaseException as exc:
 result.update(status='UNKNOWN',error_type=type(exc).__name__,error=str(exc))
finally:
 if proc is not None and proc.poll() is None:
  if owned and cid:
   try: command('cleanup_stop',['wslc','container','stop','--time','2',cid],limit=8)
   except BaseException as exc:mark('cleanup_stop_error',type=type(exc).__name__)
  try:proc.wait(timeout=4)
  except subprocess.TimeoutExpired:
   proc.kill();proc.wait(timeout=4);mark('client_killed_cleanup_unknown')
 result['owned_identity_confirmed']=owned;result['client_exit']=None if proc is None else proc.poll();result['cid']=cid
 (root/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(result));sys.exit(0 if result['status']=='OBSERVED' else 1)

import json, re, sys
from pathlib import Path
p=Path(sys.argv[1]); result=json.loads((p/'result.json').read_text()); events=json.loads((p/'events.json').read_text());cid=(p/'container.cid').read_text().strip();run=result['run_id']
def require(ok,why):
 if not ok:raise ValueError(why)
def event(name):
 rows=[e for e in events if e['event']==name];require(len(rows)==1,'event '+name);return rows[0]
require(re.fullmatch('[0-9a-f]{64}',cid) is not None,'CID format')
require(result['cid']==cid and result['owned_identity_confirmed'] is True,'CID/owner receipt')
inspect=json.loads((p/'running_inspect.stdout').read_bytes().decode('utf-8-sig'))
require(isinstance(inspect,list) and len(inspect)==1,'inspect count')
row=inspect[0];require(row.get('Id')==cid,'inspect CID');require(row.get('Config',{}).get('Labels',{}).get('agent-interface.r576')==run,'label')
running=[json.loads(line) for line in (p/'running_list.stdout').read_text(encoding='utf-8-sig').splitlines() if line.strip()]
require(len(running)==1 and running[0].get('ID')==cid[:12],'filtered running CID')
require('agent-interface.r576='+run in running[0].get('Labels',''),'running label')
require((p/'after_list.stdout').read_bytes()==b'' and (p/'after_list.stderr').read_bytes()==b'','post-list bytes')
for n in ('running_inspect_end','running_list_end','client_exited','after_list_end'):require(event(n)['exit']==0,n+' exit')
require(event('running_list_end')['ns']<event('client_exited')['ns']<event('after_list_end')['ns'],'time ordering')
require(not any(e['event'].startswith('cleanup_') or e['event']=='client_killed_cleanup_unknown' for e in events),'unexpected cleanup')
print(json.dumps({'status':'AUDITED_SCOPED','cid':cid,'run_id':run,'running_exact_inspect_and_label':True,'running_filter_id_prefix':True,'post_filter_empty':True,'client_exit':0,'limits':'one client/runtime; no GUI/input/release/task; filter absence inferred only for tested command'}))

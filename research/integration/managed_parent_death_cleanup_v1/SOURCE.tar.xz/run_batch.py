import json, subprocess, sys
from pathlib import Path
SRC=Path(__file__).resolve().parent
SCHEDULE=[(p,e,r) for r in range(2) for e in ['MANAGER_NORMAL_EXIT','MANAGER_SIGKILL','EXPLICIT_CANCEL','CLIENT_DISCONNECT'] for p in ['NO_PARENT_DEATH_CHANNEL','OWNERSHIP_PIPE']]
def main():
    out=Path(sys.argv[1]); bi=int(sys.argv[2]); out.mkdir(parents=True,exist_ok=False)
    rows=[]
    for idx,(p,e,r) in enumerate(SCHEDULE[bi*8:(bi+1)*8],start=bi*8):
        case=out/f'case-{idx:02d}-{p}-{e}-r{r}'
        cp=subprocess.run([sys.executable,'-B',str(SRC/'run_case.py'),str(case),p,e,str(r)],capture_output=True,text=True,timeout=5)
        (case/'outer.json').write_text(json.dumps({"argv":cp.args,"returncode":cp.returncode,"stdout":cp.stdout,"stderr":cp.stderr},indent=2,sort_keys=True)+'\n')
        if cp.returncode!=0: raise SystemExit(cp.returncode)
        rows.append(json.loads(cp.stdout))
    (out/'ROWS.json').write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
    print(json.dumps({"batch":bi,"cases":len(rows),"status":"COMPLETE"},sort_keys=True))
if __name__=='__main__': main()

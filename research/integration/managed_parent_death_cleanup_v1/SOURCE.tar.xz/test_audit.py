import json, shutil, subprocess, sys, tempfile
from pathlib import Path
SRC=Path(__file__).resolve().parent

def run_audit(root):
    return subprocess.run([sys.executable,'-B',str(SRC/'audit.py'),str(root),'16'],capture_output=True,text=True)
def main():
    formal=Path(sys.argv[1]); controls=[]
    mutations=[
      ('missing_case', lambda r: shutil.rmtree(sorted(r.glob('batch*/case-*'))[0])),
      ('sentinel_dead', lambda r: _set(sorted(r.glob('batch*/case-*'))[0],'scored.json','sentinel','present',False)),
      ('candidate_worker_live', lambda r: _set_case(r,'OWNERSHIP_PIPE','MANAGER_SIGKILL','scored.json','worker','present',True)),
      ('candidate_helper_live', lambda r: _set_case(r,'OWNERSHIP_PIPE','MANAGER_NORMAL_EXIT','scored.json','helper','present',True)),
      ('missing_receipt', lambda r: _set_case(r,'OWNERSHIP_PIPE','EXPLICIT_CANCEL','scored.json','receipt',None)),
      ('wrong_receipt_reason', lambda r: _set_case(r,'OWNERSHIP_PIPE','MANAGER_NORMAL_EXIT','scored.json','receipt','reason','bad')),
      ('baseline_worker_absent', lambda r: _set_case(r,'NO_PARENT_DEATH_CHANNEL','MANAGER_SIGKILL','scored.json','worker','present',False)),
      ('client_cleanup', lambda r: _set_case(r,'OWNERSHIP_PIPE','CLIENT_DISCONNECT','scored.json','helper','present',False)),
      ('outer_nonzero', lambda r: _set_outer(r,1)),
      ('final_residue', lambda r: _set(sorted(r.glob('batch*/case-*'))[0],'final.json','worker','present',True)),
    ]
    for name,fn in mutations:
      with tempfile.TemporaryDirectory() as d:
        cp=Path(d)/'formal'; shutil.copytree(formal,cp); intact=run_audit(cp).returncode==0; fn(cp); rejected=run_audit(cp).returncode!=0
        controls.append({'name':name,'intact_pass':intact,'mutation_rejected':rejected})
    print(json.dumps({'status':'PASS_CONTROLS' if all(x['intact_pass'] and x['mutation_rejected'] for x in controls) else 'FAIL','count':len(controls),'controls':controls},indent=2,sort_keys=True))
    raise SystemExit(0 if all(x['intact_pass'] and x['mutation_rejected'] for x in controls) else 1)
def _set(case,file,*args):
    p=case/file; d=json.loads(p.read_text()); *path,val=args
    cur=d
    for k in path[:-1]:
      if cur.get(k) is None: cur[k]={}
      cur=cur[k]
    cur[path[-1]]=val; p.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
def _set_case(root,pol,event,file,*args):
    c=next(c for c in sorted(root.glob('batch*/case-*')) if pol in c.name and event in c.name); _set(c,file,*args)
def _set_outer(root,rc):
    c=sorted(root.glob('batch*/case-*'))[0]; p=c/'outer.json'; d=json.loads(p.read_text()); d['returncode']=rc; p.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
if __name__=='__main__': main()

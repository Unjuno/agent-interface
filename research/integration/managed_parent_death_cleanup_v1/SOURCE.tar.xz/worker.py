import json, os, select, signal, subprocess, sys, time
from pathlib import Path
root=Path(sys.argv[1]); policy=sys.argv[2]; ownership_fd=int(sys.argv[3])
helper_info=root/'helper.json'; receipt=root/'cleanup_receipt.json'; worker_info=root/'worker.json'
helper=subprocess.Popen([sys.executable,'-B',str(Path(__file__).with_name('helper.py')),str(helper_info)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=False)
for _ in range(100):
    if helper_info.exists(): break
    time.sleep(0.01)
worker_info.write_text(json.dumps({"pid":os.getpid(),"ppid":os.getppid(),"pgid":os.getpgid(0),"sid":os.getsid(0),"helper_pid":helper.pid,"start_ns":time.monotonic_ns()},sort_keys=True)+"\n")

def cleanup(reason):
    t0=time.monotonic_ns(); escalated=False
    try: helper.terminate()
    except ProcessLookupError: pass
    try: rc=helper.wait(timeout=0.35)
    except subprocess.TimeoutExpired:
        escalated=True
        try: helper.kill()
        except ProcessLookupError: pass
        rc=helper.wait(timeout=0.35)
    receipt.write_text(json.dumps({"reason":reason,"worker_pid":os.getpid(),"helper_pid":helper.pid,"helper_returncode":rc,"escalated":escalated,"started_ns":t0,"finished_ns":time.monotonic_ns()},sort_keys=True)+"\n")
    return 0
signal.signal(signal.SIGTERM, lambda s,f: (cleanup('worker_sigterm'), sys.exit(0)))
if policy=='OWNERSHIP_PIPE':
    while True:
        r,_,_=select.select([ownership_fd],[],[],0.1)
        if r:
            b=os.read(ownership_fd,1)
            if b==b'':
                sys.exit(cleanup('ownership_eof'))
else:
    while True: time.sleep(0.1)

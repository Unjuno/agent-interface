import os, signal, sys, time, json
from pathlib import Path
out=Path(sys.argv[1])
start={"pid":os.getpid(),"ppid":os.getppid(),"pgid":os.getpgid(0),"sid":os.getsid(0),"start_ns":time.monotonic_ns()}
out.write_text(json.dumps(start,sort_keys=True)+"\n")
term=False
def on_term(sig,frame):
    global term
    term=True
signal.signal(signal.SIGTERM,on_term)
while not term:
    time.sleep(0.02)
sys.exit(0)

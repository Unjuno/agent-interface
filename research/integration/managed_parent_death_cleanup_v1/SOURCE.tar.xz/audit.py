import json, sys
from pathlib import Path

def load(p): return json.loads(p.read_text())
def alive(s): return bool(s.get('present')) and s.get('state') not in ('Z','X')
def main():
    root=Path(sys.argv[1]); expected=int(sys.argv[2]) if len(sys.argv)>2 else 16
    cases=sorted(root.glob('batch*/case-*')); cases = cases or sorted([p for p in root.iterdir() if p.is_dir() and (p/'ready.json').exists()])
    errors=[]; checks=0; counts={}
    if len(cases)!=expected: errors.append(f'case_count:{len(cases)}'); checks+=1
    for c in cases:
        ready=load(c/'ready.json'); scored=load(c/'scored.json'); final=load(c/'final.json'); outer=load(c/'outer.json') if (c/'outer.json').exists() else None; checks+=4
        p,e=ready['policy'],ready['event']; counts[(p,e)]=counts.get((p,e),0)+1
        if expected==16 and (outer is None or outer['returncode']!=0): errors.append(f'{c.name}:outer'); checks+=1
        if not alive(scored['sentinel']): errors.append(f'{c.name}:sentinel'); checks+=1
        wa=alive(scored['worker']); ha=alive(scored['helper']); receipt=scored['receipt']
        if p=='NO_PARENT_DEATH_CHANNEL':
            if not (wa and ha): errors.append(f'{c.name}:baseline_not_live')
            if receipt is not None: errors.append(f'{c.name}:baseline_receipt')
            checks+=2
        else:
            if e in ('MANAGER_NORMAL_EXIT','MANAGER_SIGKILL','EXPLICIT_CANCEL'):
                if wa or ha: errors.append(f'{c.name}:owned_residue')
                if not receipt or receipt.get('reason')!='ownership_eof' or receipt.get('helper_returncode') is None: errors.append(f'{c.name}:receipt')
                checks+=3
            elif e=='CLIENT_DISCONNECT':
                if not (wa and ha): errors.append(f'{c.name}:client_disconnect_cleanup')
                if receipt is not None: errors.append(f'{c.name}:client_receipt')
                checks+=2
        if any(final[k].get('present') for k in ('manager','worker','helper','sentinel')): errors.append(f'{c.name}:final_residue')
        checks+=1
    if expected==16:
      for p in ('NO_PARENT_DEATH_CHANNEL','OWNERSHIP_PIPE'):
        for e in ('MANAGER_NORMAL_EXIT','MANAGER_SIGKILL','EXPLICIT_CANCEL','CLIENT_DISCONNECT'):
          if counts.get((p,e))!=2: errors.append(f'cell:{p}:{e}:{counts.get((p,e))}')
          checks+=1
    out={"status":"PASS_PARENT_DEATH_OWNERSHIP_CHANNEL_SCOPED" if not errors and expected==16 else ("PASS_PREFIX_AUDIT" if not errors else "FAIL"),"cases":len(cases),"checks":checks,"errors":errors}
    print(json.dumps(out,indent=2,sort_keys=True)); raise SystemExit(0 if not errors else 1)
if __name__=='__main__': main()

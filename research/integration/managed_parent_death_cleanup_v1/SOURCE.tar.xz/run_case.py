import ctypes, json, os, signal, subprocess, sys, tempfile, time
from pathlib import Path
SRC=Path(__file__).resolve().parent
# Become a Linux child subreaper so orphaned workers can be observed/reaped deterministically.
libc=ctypes.CDLL(None); PR_SET_CHILD_SUBREAPER=36
if libc.prctl(PR_SET_CHILD_SUBREAPER,1,0,0,0)!=0: raise OSError('prctl subreaper failed')

def proc_state(pid):
    p=Path(f'/proc/{pid}/stat')
    if not p.exists(): return {"present":False}
    s=p.read_text().split(); return {"present":True,"state":s[2],"ppid":int(s[3]),"pgid":int(s[4]),"sid":int(s[5]),"start_ticks":int(s[21])}
def wait_file(p,timeout=2):
    end=time.monotonic()+timeout
    while time.monotonic()<end:
        if p.exists(): return json.loads(p.read_text())
        time.sleep(.01)
    raise RuntimeError(f'missing {p}')
def kill(pid,sig):
    try: os.kill(pid,sig); return True
    except ProcessLookupError: return False
def reap_nonblock(pid):
    try:
        got,status=os.waitpid(pid,os.WNOHANG); return got==pid
    except ChildProcessError:
        return False
def reap_wait(pid,timeout=.6):
    end=time.monotonic()+timeout
    while time.monotonic()<end:
        if reap_nonblock(pid): return True
        if not Path(f'/proc/{pid}').exists(): return True
        time.sleep(.01)
    return False

def main():
    out=Path(sys.argv[1]); policy=sys.argv[2]; event=sys.argv[3]; rep=int(sys.argv[4]); out.mkdir(parents=True,exist_ok=False)
    sentinel=subprocess.Popen([sys.executable,'-B','-c','import time; time.sleep(60)'],start_new_session=True)
    manager=subprocess.Popen([sys.executable,'-B',str(SRC/'manager.py'),str(out),policy],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
    m=wait_file(out/'manager.json'); w=wait_file(out/'worker.json'); h=wait_file(out/'helper.json')
    ready={"policy":policy,"event":event,"rep":rep,"manager":m,"worker":w,"helper":h,"sentinel":{"pid":sentinel.pid,"state":proc_state(sentinel.pid)},"ready_ns":time.monotonic_ns()}
    (out/'ready.json').write_text(json.dumps(ready,indent=2,sort_keys=True)+'\n')
    if event=='MANAGER_SIGKILL':
        kill(manager.pid,signal.SIGKILL)
    else:
        manager.stdin.write(('NORMAL_EXIT' if event=='MANAGER_NORMAL_EXIT' else event)+'\n'); manager.stdin.flush()
        if event in ('EXPLICIT_CANCEL','CLIENT_DISCONNECT'):
            ack=manager.stdout.readline().strip(); (out/'command_ack.txt').write_text(ack+'\n')
    time.sleep(.45)
    manager.poll()
    reap_nonblock(w['pid']); reap_nonblock(h['pid'])
    scored={"manager":proc_state(manager.pid),"worker":proc_state(w['pid']),"helper":proc_state(h['pid']),"sentinel":proc_state(sentinel.pid),"receipt":json.loads((out/'cleanup_receipt.json').read_text()) if (out/'cleanup_receipt.json').exists() else None,"scored_ns":time.monotonic_ns()}
    (out/'scored.json').write_text(json.dumps(scored,indent=2,sort_keys=True)+'\n')
    # rescue after score
    for pid in [manager.pid,w['pid'],h['pid']]: kill(pid,signal.SIGTERM)
    time.sleep(.1)
    for pid in [manager.pid,w['pid'],h['pid']]: kill(pid,signal.SIGKILL)
    kill(sentinel.pid,signal.SIGTERM)
    try: manager.wait(timeout=.5)
    except subprocess.TimeoutExpired:
        kill(manager.pid,signal.SIGKILL); manager.wait(timeout=.5)
    try: sentinel.wait(timeout=.5)
    except subprocess.TimeoutExpired:
        kill(sentinel.pid,signal.SIGKILL); sentinel.wait(timeout=.5)
    reap_wait(w['pid']); reap_wait(h['pid']); time.sleep(.03)
    final={"manager":proc_state(manager.pid),"worker":proc_state(w['pid']),"helper":proc_state(h['pid']),"sentinel":proc_state(sentinel.pid),"manager_returncode":manager.returncode,"sentinel_returncode":sentinel.returncode,"finished_ns":time.monotonic_ns()}
    (out/'final.json').write_text(json.dumps(final,indent=2,sort_keys=True)+'\n')
    print(json.dumps({"policy":policy,"event":event,"rep":rep,"scored":scored,"final":final},sort_keys=True))
if __name__=='__main__': main()

import json, os, subprocess, sys, time
from pathlib import Path
root=Path(sys.argv[1]); policy=sys.argv[2]
manager_info=root/'manager.json'; worker_info=root/'worker.json'; events=root/'manager_events.jsonl'
client_r,client_w=os.pipe()
if policy=='OWNERSHIP_PIPE':
    own_r,own_w=os.pipe(); own_arg=str(own_r); passfds=(own_r,)
else:
    own_r=own_w=-1; own_arg='-1'; passfds=()
worker=subprocess.Popen([sys.executable,'-B',str(Path(__file__).with_name('worker.py')),str(root),policy,own_arg],pass_fds=passfds,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
if own_r>=0: os.close(own_r)
manager_info.write_text(json.dumps({"pid":os.getpid(),"ppid":os.getppid(),"pgid":os.getpgid(0),"sid":os.getsid(0),"worker_pid":worker.pid,"client_r":client_r,"client_w":client_w,"ownership_w":own_w,"start_ns":time.monotonic_ns()},sort_keys=True)+"\n")
def ev(kind,**kw):
    with events.open('a') as f: f.write(json.dumps({"kind":kind,"ns":time.monotonic_ns(),**kw},sort_keys=True)+"\n")
for line in sys.stdin:
    cmd=line.strip()
    if not cmd: continue
    ev('command',cmd=cmd)
    if cmd=='NORMAL_EXIT':
        ev('normal_exit'); sys.exit(0)
    elif cmd=='EXPLICIT_CANCEL':
        if own_w>=0:
            os.close(own_w); own_w=-1; ev('ownership_closed')
            try:
                rc=worker.wait(timeout=0.8); ev('worker_reaped_after_cancel',returncode=rc)
            except subprocess.TimeoutExpired:
                ev('worker_not_reaped_after_cancel')
        else: ev('baseline_cancel_noop')
    elif cmd=='CLIENT_DISCONNECT':
        if client_w>=0:
            os.close(client_w); client_w=-1; ev('client_closed')
    elif cmd=='SHUTDOWN':
        if own_w>=0: os.close(own_w); own_w=-1
        try: worker.terminate()
        except ProcessLookupError: pass
        try: worker.wait(timeout=0.5)
        except subprocess.TimeoutExpired:
            try: worker.kill()
            except ProcessLookupError: pass
            worker.wait(timeout=0.5)
        sys.exit(0)
    sys.stdout.write(json.dumps({"ack":cmd,"ns":time.monotonic_ns()})+'\n'); sys.stdout.flush()

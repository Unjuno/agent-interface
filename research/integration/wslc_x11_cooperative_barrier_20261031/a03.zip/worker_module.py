import json,os,time
from pathlib import Path
from Xlib import X,display
from Xlib.ext import xtest

def send_then_stall(request):
 out=Path('/out');d=display.Display(':163');root=d.screen().root;pid=os.getpid();base=d.display.info.resource_id_base;info={'owner_pid':pid,'resource_base':base,'session_id':request['session_id'],'operation_id':request['operation_id'],'target':request['target'],'buttons':['left']}
 with (out/'custody.json').open('x') as f:json.dump(info,f);f.flush();os.fsync(f.fileno())
 xtest.fake_input(d,X.MotionNotify,x=100,y=100);d.sync();d.grab_server();d.sync();hit=root.translate_coords(root,100,100).child;hit_id=getattr(hit,'id',hit)
 if hit_id!=request['target']:d.ungrab_server();d.sync();return {'status':'unknown','reason':'target_changed','operation_id':request['operation_id'],'session_id':request['session_id']}
 xtest.fake_input(d,X.ButtonPress,1);xtest.fake_input(d,X.ButtonRelease,1);d.sync();sent=time.monotonic_ns();d.ungrab_server();d.sync();(out/'pair-synced.json').write_text(json.dumps({'sent_ns':sent,'target':hit_id,'scheduled_late_ns':sent+2_000_000_000}))
 time.sleep(2);xtest.fake_input(d,X.ButtonPress,1);xtest.fake_input(d,X.ButtonRelease,1);d.sync();(out/'late.json').write_text('late pair requested')
 return {'status':'completed','operation_id':request['operation_id'],'session_id':request['session_id']}

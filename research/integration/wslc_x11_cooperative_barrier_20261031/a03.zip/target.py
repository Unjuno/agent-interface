import json,os,time,threading
from pathlib import Path
from Xlib import X,display
out=Path('/out');d=display.Display(':163');root=d.screen().root;atom=d.intern_atom('AGENT_FIXTURE_BARRIER');w=root.create_window(50,50,200,200,0,d.screen().root_depth,X.InputOutput,X.CopyFromParent,override_redirect=1,background_pixel=d.screen().white_pixel,event_mask=X.ButtonPressMask|X.ButtonReleaseMask);w.map();d.sync();(out/'target-ready.json').write_text(json.dumps({'pid':os.getpid(),'window':w.id,'ready_ns':time.monotonic_ns()}));events=[];ack=False;deadline=time.monotonic()+10
def effect():
 if os.environ['TARGET_MODE']=='async':time.sleep(1.8)
 (out/'target-effect.json').write_text(json.dumps({'effect':'button_pair_handled','effect_ns':time.monotonic_ns()},indent=2)+'\n')
while time.monotonic()<deadline:
 while d.pending_events():
  e=d.next_event()
  if e.type in (X.ButtonPress,X.ButtonRelease):
   events.append({'type':e.type,'window':getattr(e.window,'id',None),'detail':e.detail,'handled_ns':time.monotonic_ns()});(out/'target-events.json').write_text(json.dumps(events,indent=2)+'\n')
   if e.type==X.ButtonRelease:
    if os.environ['TARGET_MODE']=='async':threading.Thread(target=effect,daemon=True).start()
    else:effect()
  elif e.type==X.ClientMessage and e.client_type==atom:
   nonce=int(e.data[1][0]);record={'nonce':nonce,'window':w.id,'target_pid':os.getpid(),'ack_ns':time.monotonic_ns(),'release_seen':any(x['type']==X.ButtonRelease for x in events),'effect_exists_at_ack':(out/'target-effect.json').exists()};(out/'barrier-ack.json').write_text(json.dumps(record,indent=2)+'\n');ack=True
 if ack and (out/'target-effect.json').exists():d.close();raise SystemExit(0)
 time.sleep(.01)
raise TimeoutError('target barrier/effect not completed')
